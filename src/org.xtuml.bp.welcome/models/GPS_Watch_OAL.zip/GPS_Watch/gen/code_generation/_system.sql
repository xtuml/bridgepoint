-- root-types-contained: SystemModel_c,PackageableElement_c,DataType_c,CoreDataType_c,UserDataType_c
-- BP 7.1 content: StreamData syschar: 3 persistence-version: 7.1.6

INSERT INTO S_SYS
	VALUES (1,
	'GPS_Watch',
	1);
INSERT INTO EP_PKG
	VALUES (2,
	1,
	1,
	'GPS_Watch',
	'',
	0);
INSERT INTO PE_PE
	VALUES (3,
	1,
	2,
	0,
	2);
INSERT INTO C_C
	VALUES (3,
	0,
	0,
	'GPS_Watch',
	'',
	0,
	0,
	0,
	'');
INSERT INTO C_PO
	VALUES (4,
	3,
	'UI',
	0,
	0);
INSERT INTO C_IR
	VALUES (5,
	6,
	0,
	4);
INSERT INTO C_R
	VALUES (5,
	'UI',
	'',
	'Unnamed Interface',
	'GPS_Watch::UI::UI');
INSERT INTO SPR_REP
	VALUES (7,
	8,
	5);
INSERT INTO SPR_RO
	VALUES (7,
	'setTime',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (9,
	7);
INSERT INTO ACT_ACT
	VALUES (9,
	'interface operation',
	0,
	10,
	0,
	0,
	'UI::UI::setTime',
	0);
INSERT INTO ACT_BLK
	VALUES (10,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	9,
	0);
INSERT INTO SPR_REP
	VALUES (11,
	12,
	5);
INSERT INTO SPR_RO
	VALUES (11,
	'setData',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (13,
	11);
INSERT INTO ACT_ACT
	VALUES (13,
	'interface operation',
	0,
	14,
	0,
	0,
	'UI::UI::setData',
	0);
INSERT INTO ACT_BLK
	VALUES (14,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	13,
	0);
INSERT INTO SPR_REP
	VALUES (15,
	16,
	5);
INSERT INTO SPR_RO
	VALUES (15,
	'startTest',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (17,
	15);
INSERT INTO ACT_ACT
	VALUES (17,
	'interface operation',
	0,
	18,
	0,
	0,
	'UI::UI::startTest',
	0);
INSERT INTO ACT_BLK
	VALUES (18,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	17,
	0);
INSERT INTO SPR_REP
	VALUES (19,
	20,
	5);
INSERT INTO SPR_RO
	VALUES (19,
	'setIndicator',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (21,
	19);
INSERT INTO ACT_ACT
	VALUES (21,
	'interface operation',
	0,
	22,
	0,
	0,
	'UI::UI::setIndicator',
	0);
INSERT INTO ACT_BLK
	VALUES (22,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	21,
	0);
INSERT INTO C_PO
	VALUES (23,
	3,
	'Location',
	0,
	0);
INSERT INTO C_IR
	VALUES (24,
	25,
	0,
	23);
INSERT INTO C_R
	VALUES (24,
	'LocationProvider',
	'',
	'Unnamed Interface',
	'GPS_Watch::Location::LocationProvider');
INSERT INTO SPR_REP
	VALUES (26,
	27,
	24);
INSERT INTO SPR_RO
	VALUES (26,
	'getLocation',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (28,
	26);
INSERT INTO ACT_ACT
	VALUES (28,
	'interface operation',
	0,
	29,
	0,
	0,
	'Location::LocationProvider::getLocation',
	0);
INSERT INTO ACT_BLK
	VALUES (29,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	28,
	0);
INSERT INTO SPR_REP
	VALUES (30,
	31,
	24);
INSERT INTO SPR_RO
	VALUES (30,
	'registerListener',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (32,
	30);
INSERT INTO ACT_ACT
	VALUES (32,
	'interface operation',
	0,
	33,
	0,
	0,
	'Location::LocationProvider::registerListener',
	0);
INSERT INTO ACT_BLK
	VALUES (33,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	32,
	0);
INSERT INTO SPR_REP
	VALUES (34,
	35,
	24);
INSERT INTO SPR_RO
	VALUES (34,
	'unregisterListener',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (36,
	34);
INSERT INTO ACT_ACT
	VALUES (36,
	'interface operation',
	0,
	37,
	0,
	0,
	'Location::LocationProvider::unregisterListener',
	0);
INSERT INTO ACT_BLK
	VALUES (37,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	36,
	0);
INSERT INTO SPR_REP
	VALUES (38,
	39,
	24);
INSERT INTO SPR_RO
	VALUES (38,
	'getDistance',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (40,
	38);
INSERT INTO ACT_ACT
	VALUES (40,
	'interface operation',
	0,
	41,
	0,
	0,
	'Location::LocationProvider::getDistance',
	0);
INSERT INTO ACT_BLK
	VALUES (41,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	40,
	0);
INSERT INTO C_PO
	VALUES (42,
	3,
	'Tracking',
	0,
	0);
INSERT INTO C_IR
	VALUES (43,
	44,
	0,
	42);
INSERT INTO C_R
	VALUES (43,
	'Tracking',
	'',
	'Unnamed Interface',
	'GPS_Watch::Tracking::Tracking');
INSERT INTO SPR_REP
	VALUES (45,
	46,
	43);
INSERT INTO SPR_RO
	VALUES (45,
	'heartRateChanged',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (47,
	45);
INSERT INTO ACT_ACT
	VALUES (47,
	'interface operation',
	0,
	48,
	0,
	0,
	'Tracking::Tracking::heartRateChanged',
	0);
INSERT INTO ACT_BLK
	VALUES (48,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	47,
	0);
INSERT INTO SPR_REP
	VALUES (49,
	50,
	43);
INSERT INTO SPR_RO
	VALUES (49,
	'setTargetPressed',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (51,
	49);
INSERT INTO ACT_ACT
	VALUES (51,
	'interface operation',
	0,
	52,
	0,
	0,
	'Tracking::Tracking::setTargetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (52,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	51,
	0);
INSERT INTO SPR_REP
	VALUES (53,
	54,
	43);
INSERT INTO SPR_RO
	VALUES (53,
	'startStopPressed',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (55,
	53);
INSERT INTO ACT_ACT
	VALUES (55,
	'interface operation',
	0,
	56,
	0,
	0,
	'Tracking::Tracking::startStopPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (56,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	55,
	0);
INSERT INTO SPR_REP
	VALUES (57,
	58,
	43);
INSERT INTO SPR_RO
	VALUES (57,
	'lapResetPressed',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (59,
	57);
INSERT INTO ACT_ACT
	VALUES (59,
	'interface operation',
	0,
	60,
	0,
	0,
	'Tracking::Tracking::lapResetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (60,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	59,
	0);
INSERT INTO SPR_REP
	VALUES (61,
	62,
	43);
INSERT INTO SPR_RO
	VALUES (61,
	'lightPressed',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (63,
	61);
INSERT INTO ACT_ACT
	VALUES (63,
	'interface operation',
	0,
	64,
	0,
	0,
	'Tracking::Tracking::lightPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (64,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	63,
	0);
INSERT INTO SPR_REP
	VALUES (65,
	66,
	43);
INSERT INTO SPR_RO
	VALUES (65,
	'modePressed',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (67,
	65);
INSERT INTO ACT_ACT
	VALUES (67,
	'interface operation',
	0,
	68,
	0,
	0,
	'Tracking::Tracking::modePressed',
	0);
INSERT INTO ACT_BLK
	VALUES (68,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	67,
	0);
INSERT INTO SPR_REP
	VALUES (69,
	70,
	43);
INSERT INTO SPR_RO
	VALUES (69,
	'newGoalSpec',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (71,
	69);
INSERT INTO ACT_ACT
	VALUES (71,
	'interface operation',
	0,
	72,
	0,
	0,
	'Tracking::Tracking::newGoalSpec',
	0);
INSERT INTO ACT_BLK
	VALUES (72,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	71,
	0);
INSERT INTO C_PO
	VALUES (73,
	3,
	'HeartRateMonitor',
	0,
	0);
INSERT INTO C_IR
	VALUES (74,
	75,
	0,
	73);
INSERT INTO C_R
	VALUES (74,
	'HeartRateProvider',
	'',
	'Unnamed Interface',
	'GPS_Watch::HeartRateMonitor::HeartRateProvider');
INSERT INTO SPR_REP
	VALUES (76,
	77,
	74);
INSERT INTO SPR_RO
	VALUES (76,
	'registerListener',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (78,
	76);
INSERT INTO ACT_ACT
	VALUES (78,
	'interface operation',
	0,
	79,
	0,
	0,
	'HeartRateMonitor::HeartRateProvider::registerListener',
	0);
INSERT INTO ACT_BLK
	VALUES (79,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	78,
	0);
INSERT INTO SPR_REP
	VALUES (80,
	81,
	74);
INSERT INTO SPR_RO
	VALUES (80,
	'unregisterListener',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (82,
	80);
INSERT INTO ACT_ACT
	VALUES (82,
	'interface operation',
	0,
	83,
	0,
	0,
	'HeartRateMonitor::HeartRateProvider::unregisterListener',
	0);
INSERT INTO ACT_BLK
	VALUES (83,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	82,
	0);
INSERT INTO C_PO
	VALUES (84,
	3,
	'UI__TRACK',
	0,
	0);
INSERT INTO C_IR
	VALUES (85,
	86,
	0,
	84);
INSERT INTO C_P
	VALUES (85,
	'UI_Tracking',
	'Unnamed Interface',
	'',
	'GPS_Watch::UI__TRACK::UI_Tracking');
INSERT INTO SPR_PEP
	VALUES (87,
	88,
	85);
INSERT INTO SPR_PO
	VALUES (87,
	'setTargetPressed',
	'',
	'Tracking::setTargetPressed();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (89,
	87);
INSERT INTO ACT_ACT
	VALUES (89,
	'interface operation',
	0,
	90,
	0,
	0,
	'UI__TRACK::UI_Tracking::setTargetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (90,
	0,
	0,
	0,
	'Tracking',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	89,
	0);
INSERT INTO ACT_SMT
	VALUES (91,
	90,
	0,
	1,
	1,
	'UI__TRACK::UI_Tracking::setTargetPressed line: 1');
INSERT INTO ACT_IOP
	VALUES (91,
	1,
	11,
	1,
	1,
	0,
	49,
	0);
INSERT INTO SPR_PEP
	VALUES (92,
	93,
	85);
INSERT INTO SPR_PO
	VALUES (92,
	'startStopPressed',
	'',
	'Tracking::startStopPressed();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (94,
	92);
INSERT INTO ACT_ACT
	VALUES (94,
	'interface operation',
	0,
	95,
	0,
	0,
	'UI__TRACK::UI_Tracking::startStopPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (95,
	0,
	0,
	0,
	'Tracking',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	94,
	0);
INSERT INTO ACT_SMT
	VALUES (96,
	95,
	0,
	1,
	1,
	'UI__TRACK::UI_Tracking::startStopPressed line: 1');
INSERT INTO ACT_IOP
	VALUES (96,
	1,
	11,
	1,
	1,
	0,
	53,
	0);
INSERT INTO SPR_PEP
	VALUES (97,
	98,
	85);
INSERT INTO SPR_PO
	VALUES (97,
	'lapResetPressed',
	'',
	'Tracking::lapResetPressed();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (99,
	97);
INSERT INTO ACT_ACT
	VALUES (99,
	'interface operation',
	0,
	100,
	0,
	0,
	'UI__TRACK::UI_Tracking::lapResetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (100,
	0,
	0,
	0,
	'Tracking',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	99,
	0);
INSERT INTO ACT_SMT
	VALUES (101,
	100,
	0,
	1,
	1,
	'UI__TRACK::UI_Tracking::lapResetPressed line: 1');
INSERT INTO ACT_IOP
	VALUES (101,
	1,
	11,
	1,
	1,
	0,
	57,
	0);
INSERT INTO SPR_PEP
	VALUES (102,
	103,
	85);
INSERT INTO SPR_PO
	VALUES (102,
	'lightPressed',
	'',
	'Tracking::lightPressed();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (104,
	102);
INSERT INTO ACT_ACT
	VALUES (104,
	'interface operation',
	0,
	105,
	0,
	0,
	'UI__TRACK::UI_Tracking::lightPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (105,
	0,
	0,
	0,
	'Tracking',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	104,
	0);
INSERT INTO ACT_SMT
	VALUES (106,
	105,
	0,
	1,
	1,
	'UI__TRACK::UI_Tracking::lightPressed line: 1');
INSERT INTO ACT_IOP
	VALUES (106,
	1,
	11,
	1,
	1,
	0,
	61,
	0);
INSERT INTO SPR_PEP
	VALUES (107,
	108,
	85);
INSERT INTO SPR_PO
	VALUES (107,
	'modePressed',
	'',
	'Tracking::modePressed();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (109,
	107);
INSERT INTO ACT_ACT
	VALUES (109,
	'interface operation',
	0,
	110,
	0,
	0,
	'UI__TRACK::UI_Tracking::modePressed',
	0);
INSERT INTO ACT_BLK
	VALUES (110,
	0,
	0,
	0,
	'Tracking',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	109,
	0);
INSERT INTO ACT_SMT
	VALUES (111,
	110,
	0,
	1,
	1,
	'UI__TRACK::UI_Tracking::modePressed line: 1');
INSERT INTO ACT_IOP
	VALUES (111,
	1,
	11,
	1,
	1,
	0,
	65,
	0);
INSERT INTO SPR_PEP
	VALUES (112,
	113,
	85);
INSERT INTO SPR_PO
	VALUES (112,
	'newGoalSpec',
	'',
	'if ( param.criteriaType == UIGoalCriteria::HeartRate )
  if ( param.spanType == UIGoalSpan::Distance )
    Tracking::newGoalSpec( spanType:GoalSpan::Distance, criteriaType:GoalCriteria::HeartRate, 
        span:param.span, maximum:param.maximum, minimum:param.minimum, sequenceNumber:param.sequenceNumber);
  elif ( param.spanType == UIGoalSpan::Time )
    Tracking::newGoalSpec( spanType:GoalSpan::Time, criteriaType:GoalCriteria::HeartRate, 
        span:param.span, maximum:param.maximum, minimum:param.minimum, sequenceNumber:param.sequenceNumber);
  end if;
elif ( param.criteriaType == UIGoalCriteria::Pace )
  if ( param.spanType == UIGoalSpan::Distance )
    Tracking::newGoalSpec( spanType:GoalSpan::Distance, criteriaType:GoalCriteria::Pace, 
        span:param.span, maximum:param.maximum, minimum:param.minimum, sequenceNumber:param.sequenceNumber);
  elif ( param.spanType == UIGoalSpan::Time )
    Tracking::newGoalSpec( spanType:GoalSpan::Time, criteriaType:GoalCriteria::Pace, 
        span:param.span, maximum:param.maximum, minimum:param.minimum, sequenceNumber:param.sequenceNumber);
  end if;
end if;',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (114,
	112);
INSERT INTO ACT_ACT
	VALUES (114,
	'interface operation',
	0,
	115,
	0,
	0,
	'UI__TRACK::UI_Tracking::newGoalSpec',
	0);
INSERT INTO ACT_BLK
	VALUES (115,
	0,
	0,
	0,
	'',
	'',
	'',
	9,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	9,
	30,
	0,
	114,
	0);
INSERT INTO ACT_SMT
	VALUES (116,
	115,
	0,
	1,
	1,
	'UI__TRACK::UI_Tracking::newGoalSpec line: 1');
INSERT INTO ACT_IF
	VALUES (116,
	117,
	118,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (119,
	115,
	0,
	9,
	1,
	'UI__TRACK::UI_Tracking::newGoalSpec line: 9');
INSERT INTO ACT_EL
	VALUES (119,
	120,
	121,
	116);
INSERT INTO V_VAL
	VALUES (122,
	0,
	0,
	1,
	12,
	23,
	0,
	0,
	0,
	0,
	123,
	115);
INSERT INTO V_PVL
	VALUES (122,
	0,
	0,
	0,
	124);
INSERT INTO V_VAL
	VALUES (118,
	0,
	0,
	1,
	12,
	52,
	0,
	0,
	0,
	0,
	125,
	115);
INSERT INTO V_BIN
	VALUES (118,
	126,
	122,
	'==');
INSERT INTO V_VAL
	VALUES (126,
	0,
	0,
	1,
	44,
	52,
	0,
	0,
	0,
	0,
	123,
	115);
INSERT INTO V_LEN
	VALUES (126,
	127,
	1,
	28);
INSERT INTO V_VAL
	VALUES (128,
	0,
	0,
	9,
	14,
	25,
	0,
	0,
	0,
	0,
	123,
	115);
INSERT INTO V_PVL
	VALUES (128,
	0,
	0,
	0,
	124);
INSERT INTO V_VAL
	VALUES (121,
	0,
	0,
	9,
	14,
	49,
	0,
	0,
	0,
	0,
	125,
	115);
INSERT INTO V_BIN
	VALUES (121,
	129,
	128,
	'==');
INSERT INTO V_VAL
	VALUES (129,
	0,
	0,
	9,
	46,
	49,
	0,
	0,
	0,
	0,
	123,
	115);
INSERT INTO V_LEN
	VALUES (129,
	130,
	9,
	30);
INSERT INTO ACT_BLK
	VALUES (117,
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	5,
	28,
	0,
	114,
	0);
INSERT INTO ACT_SMT
	VALUES (131,
	117,
	0,
	2,
	3,
	'UI__TRACK::UI_Tracking::newGoalSpec line: 2');
INSERT INTO ACT_IF
	VALUES (131,
	132,
	133,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (134,
	117,
	0,
	5,
	3,
	'UI__TRACK::UI_Tracking::newGoalSpec line: 5');
INSERT INTO ACT_EL
	VALUES (134,
	135,
	136,
	131);
INSERT INTO V_VAL
	VALUES (137,
	0,
	0,
	2,
	14,
	21,
	0,
	0,
	0,
	0,
	138,
	117);
INSERT INTO V_PVL
	VALUES (137,
	0,
	0,
	0,
	139);
INSERT INTO V_VAL
	VALUES (133,
	0,
	0,
	2,
	14,
	45,
	0,
	0,
	0,
	0,
	125,
	117);
INSERT INTO V_BIN
	VALUES (133,
	140,
	137,
	'==');
INSERT INTO V_VAL
	VALUES (140,
	0,
	0,
	2,
	38,
	45,
	0,
	0,
	0,
	0,
	138,
	117);
INSERT INTO V_LEN
	VALUES (140,
	141,
	2,
	26);
INSERT INTO V_VAL
	VALUES (142,
	0,
	0,
	5,
	16,
	23,
	0,
	0,
	0,
	0,
	138,
	117);
INSERT INTO V_PVL
	VALUES (142,
	0,
	0,
	0,
	139);
INSERT INTO V_VAL
	VALUES (136,
	0,
	0,
	5,
	16,
	43,
	0,
	0,
	0,
	0,
	125,
	117);
INSERT INTO V_BIN
	VALUES (136,
	143,
	142,
	'==');
INSERT INTO V_VAL
	VALUES (143,
	0,
	0,
	5,
	40,
	43,
	0,
	0,
	0,
	0,
	138,
	117);
INSERT INTO V_LEN
	VALUES (143,
	144,
	5,
	28);
INSERT INTO ACT_BLK
	VALUES (132,
	0,
	0,
	0,
	'Tracking',
	'',
	'',
	3,
	5,
	3,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	3,
	70,
	0,
	114,
	0);
INSERT INTO ACT_SMT
	VALUES (145,
	132,
	0,
	3,
	5,
	'UI__TRACK::UI_Tracking::newGoalSpec line: 3');
INSERT INTO ACT_IOP
	VALUES (145,
	3,
	15,
	3,
	5,
	0,
	69,
	0);
INSERT INTO V_VAL
	VALUES (146,
	0,
	0,
	3,
	47,
	54,
	0,
	0,
	0,
	0,
	147,
	132);
INSERT INTO V_LEN
	VALUES (146,
	148,
	3,
	37);
INSERT INTO V_PAR
	VALUES (146,
	145,
	0,
	'spanType',
	149,
	3,
	28);
INSERT INTO V_VAL
	VALUES (149,
	0,
	0,
	3,
	84,
	92,
	0,
	0,
	0,
	0,
	150,
	132);
INSERT INTO V_LEN
	VALUES (149,
	151,
	3,
	70);
INSERT INTO V_PAR
	VALUES (149,
	145,
	0,
	'criteriaType',
	152,
	3,
	57);
INSERT INTO V_VAL
	VALUES (152,
	0,
	0,
	4,
	20,
	23,
	0,
	0,
	0,
	0,
	153,
	132);
INSERT INTO V_PVL
	VALUES (152,
	0,
	0,
	0,
	154);
INSERT INTO V_PAR
	VALUES (152,
	145,
	0,
	'span',
	155,
	4,
	9);
INSERT INTO V_VAL
	VALUES (155,
	0,
	0,
	4,
	40,
	46,
	0,
	0,
	0,
	0,
	153,
	132);
INSERT INTO V_PVL
	VALUES (155,
	0,
	0,
	0,
	156);
INSERT INTO V_PAR
	VALUES (155,
	145,
	0,
	'maximum',
	157,
	4,
	26);
INSERT INTO V_VAL
	VALUES (157,
	0,
	0,
	4,
	63,
	69,
	0,
	0,
	0,
	0,
	153,
	132);
INSERT INTO V_PVL
	VALUES (157,
	0,
	0,
	0,
	158);
INSERT INTO V_PAR
	VALUES (157,
	145,
	0,
	'minimum',
	159,
	4,
	49);
INSERT INTO V_VAL
	VALUES (159,
	0,
	0,
	4,
	93,
	106,
	0,
	0,
	0,
	0,
	160,
	132);
INSERT INTO V_PVL
	VALUES (159,
	0,
	0,
	0,
	161);
INSERT INTO V_PAR
	VALUES (159,
	145,
	0,
	'sequenceNumber',
	0,
	4,
	72);
INSERT INTO ACT_BLK
	VALUES (135,
	0,
	0,
	0,
	'Tracking',
	'',
	'',
	6,
	5,
	6,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	6,
	66,
	0,
	114,
	0);
INSERT INTO ACT_SMT
	VALUES (162,
	135,
	0,
	6,
	5,
	'UI__TRACK::UI_Tracking::newGoalSpec line: 6');
INSERT INTO ACT_IOP
	VALUES (162,
	6,
	15,
	6,
	5,
	0,
	69,
	0);
INSERT INTO V_VAL
	VALUES (163,
	0,
	0,
	6,
	47,
	50,
	0,
	0,
	0,
	0,
	147,
	135);
INSERT INTO V_LEN
	VALUES (163,
	164,
	6,
	37);
INSERT INTO V_PAR
	VALUES (163,
	162,
	0,
	'spanType',
	165,
	6,
	28);
INSERT INTO V_VAL
	VALUES (165,
	0,
	0,
	6,
	80,
	88,
	0,
	0,
	0,
	0,
	150,
	135);
INSERT INTO V_LEN
	VALUES (165,
	151,
	6,
	66);
INSERT INTO V_PAR
	VALUES (165,
	162,
	0,
	'criteriaType',
	166,
	6,
	53);
INSERT INTO V_VAL
	VALUES (166,
	0,
	0,
	7,
	20,
	23,
	0,
	0,
	0,
	0,
	153,
	135);
INSERT INTO V_PVL
	VALUES (166,
	0,
	0,
	0,
	154);
INSERT INTO V_PAR
	VALUES (166,
	162,
	0,
	'span',
	167,
	7,
	9);
INSERT INTO V_VAL
	VALUES (167,
	0,
	0,
	7,
	40,
	46,
	0,
	0,
	0,
	0,
	153,
	135);
INSERT INTO V_PVL
	VALUES (167,
	0,
	0,
	0,
	156);
INSERT INTO V_PAR
	VALUES (167,
	162,
	0,
	'maximum',
	168,
	7,
	26);
INSERT INTO V_VAL
	VALUES (168,
	0,
	0,
	7,
	63,
	69,
	0,
	0,
	0,
	0,
	153,
	135);
INSERT INTO V_PVL
	VALUES (168,
	0,
	0,
	0,
	158);
INSERT INTO V_PAR
	VALUES (168,
	162,
	0,
	'minimum',
	169,
	7,
	49);
INSERT INTO V_VAL
	VALUES (169,
	0,
	0,
	7,
	93,
	106,
	0,
	0,
	0,
	0,
	160,
	135);
INSERT INTO V_PVL
	VALUES (169,
	0,
	0,
	0,
	161);
INSERT INTO V_PAR
	VALUES (169,
	162,
	0,
	'sequenceNumber',
	0,
	7,
	72);
INSERT INTO ACT_BLK
	VALUES (120,
	0,
	0,
	0,
	'',
	'',
	'',
	13,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	13,
	28,
	0,
	114,
	0);
INSERT INTO ACT_SMT
	VALUES (170,
	120,
	0,
	10,
	3,
	'UI__TRACK::UI_Tracking::newGoalSpec line: 10');
INSERT INTO ACT_IF
	VALUES (170,
	171,
	172,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (173,
	120,
	0,
	13,
	3,
	'UI__TRACK::UI_Tracking::newGoalSpec line: 13');
INSERT INTO ACT_EL
	VALUES (173,
	174,
	175,
	170);
INSERT INTO V_VAL
	VALUES (176,
	0,
	0,
	10,
	14,
	21,
	0,
	0,
	0,
	0,
	138,
	120);
INSERT INTO V_PVL
	VALUES (176,
	0,
	0,
	0,
	139);
INSERT INTO V_VAL
	VALUES (172,
	0,
	0,
	10,
	14,
	45,
	0,
	0,
	0,
	0,
	125,
	120);
INSERT INTO V_BIN
	VALUES (172,
	177,
	176,
	'==');
INSERT INTO V_VAL
	VALUES (177,
	0,
	0,
	10,
	38,
	45,
	0,
	0,
	0,
	0,
	138,
	120);
INSERT INTO V_LEN
	VALUES (177,
	141,
	10,
	26);
INSERT INTO V_VAL
	VALUES (178,
	0,
	0,
	13,
	16,
	23,
	0,
	0,
	0,
	0,
	138,
	120);
INSERT INTO V_PVL
	VALUES (178,
	0,
	0,
	0,
	139);
INSERT INTO V_VAL
	VALUES (175,
	0,
	0,
	13,
	16,
	43,
	0,
	0,
	0,
	0,
	125,
	120);
INSERT INTO V_BIN
	VALUES (175,
	179,
	178,
	'==');
INSERT INTO V_VAL
	VALUES (179,
	0,
	0,
	13,
	40,
	43,
	0,
	0,
	0,
	0,
	138,
	120);
INSERT INTO V_LEN
	VALUES (179,
	144,
	13,
	28);
INSERT INTO ACT_BLK
	VALUES (171,
	0,
	0,
	0,
	'Tracking',
	'',
	'',
	11,
	5,
	11,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	11,
	70,
	0,
	114,
	0);
INSERT INTO ACT_SMT
	VALUES (180,
	171,
	0,
	11,
	5,
	'UI__TRACK::UI_Tracking::newGoalSpec line: 11');
INSERT INTO ACT_IOP
	VALUES (180,
	11,
	15,
	11,
	5,
	0,
	69,
	0);
INSERT INTO V_VAL
	VALUES (181,
	0,
	0,
	11,
	47,
	54,
	0,
	0,
	0,
	0,
	147,
	171);
INSERT INTO V_LEN
	VALUES (181,
	148,
	11,
	37);
INSERT INTO V_PAR
	VALUES (181,
	180,
	0,
	'spanType',
	182,
	11,
	28);
INSERT INTO V_VAL
	VALUES (182,
	0,
	0,
	11,
	84,
	87,
	0,
	0,
	0,
	0,
	150,
	171);
INSERT INTO V_LEN
	VALUES (182,
	183,
	11,
	70);
INSERT INTO V_PAR
	VALUES (182,
	180,
	0,
	'criteriaType',
	184,
	11,
	57);
INSERT INTO V_VAL
	VALUES (184,
	0,
	0,
	12,
	20,
	23,
	0,
	0,
	0,
	0,
	153,
	171);
INSERT INTO V_PVL
	VALUES (184,
	0,
	0,
	0,
	154);
INSERT INTO V_PAR
	VALUES (184,
	180,
	0,
	'span',
	185,
	12,
	9);
INSERT INTO V_VAL
	VALUES (185,
	0,
	0,
	12,
	40,
	46,
	0,
	0,
	0,
	0,
	153,
	171);
INSERT INTO V_PVL
	VALUES (185,
	0,
	0,
	0,
	156);
INSERT INTO V_PAR
	VALUES (185,
	180,
	0,
	'maximum',
	186,
	12,
	26);
INSERT INTO V_VAL
	VALUES (186,
	0,
	0,
	12,
	63,
	69,
	0,
	0,
	0,
	0,
	153,
	171);
INSERT INTO V_PVL
	VALUES (186,
	0,
	0,
	0,
	158);
INSERT INTO V_PAR
	VALUES (186,
	180,
	0,
	'minimum',
	187,
	12,
	49);
INSERT INTO V_VAL
	VALUES (187,
	0,
	0,
	12,
	93,
	106,
	0,
	0,
	0,
	0,
	160,
	171);
INSERT INTO V_PVL
	VALUES (187,
	0,
	0,
	0,
	161);
INSERT INTO V_PAR
	VALUES (187,
	180,
	0,
	'sequenceNumber',
	0,
	12,
	72);
INSERT INTO ACT_BLK
	VALUES (174,
	0,
	0,
	0,
	'Tracking',
	'',
	'',
	14,
	5,
	14,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	14,
	66,
	0,
	114,
	0);
INSERT INTO ACT_SMT
	VALUES (188,
	174,
	0,
	14,
	5,
	'UI__TRACK::UI_Tracking::newGoalSpec line: 14');
INSERT INTO ACT_IOP
	VALUES (188,
	14,
	15,
	14,
	5,
	0,
	69,
	0);
INSERT INTO V_VAL
	VALUES (189,
	0,
	0,
	14,
	47,
	50,
	0,
	0,
	0,
	0,
	147,
	174);
INSERT INTO V_LEN
	VALUES (189,
	164,
	14,
	37);
INSERT INTO V_PAR
	VALUES (189,
	188,
	0,
	'spanType',
	190,
	14,
	28);
INSERT INTO V_VAL
	VALUES (190,
	0,
	0,
	14,
	80,
	83,
	0,
	0,
	0,
	0,
	150,
	174);
INSERT INTO V_LEN
	VALUES (190,
	183,
	14,
	66);
INSERT INTO V_PAR
	VALUES (190,
	188,
	0,
	'criteriaType',
	191,
	14,
	53);
INSERT INTO V_VAL
	VALUES (191,
	0,
	0,
	15,
	20,
	23,
	0,
	0,
	0,
	0,
	153,
	174);
INSERT INTO V_PVL
	VALUES (191,
	0,
	0,
	0,
	154);
INSERT INTO V_PAR
	VALUES (191,
	188,
	0,
	'span',
	192,
	15,
	9);
INSERT INTO V_VAL
	VALUES (192,
	0,
	0,
	15,
	40,
	46,
	0,
	0,
	0,
	0,
	153,
	174);
INSERT INTO V_PVL
	VALUES (192,
	0,
	0,
	0,
	156);
INSERT INTO V_PAR
	VALUES (192,
	188,
	0,
	'maximum',
	193,
	15,
	26);
INSERT INTO V_VAL
	VALUES (193,
	0,
	0,
	15,
	63,
	69,
	0,
	0,
	0,
	0,
	153,
	174);
INSERT INTO V_PVL
	VALUES (193,
	0,
	0,
	0,
	158);
INSERT INTO V_PAR
	VALUES (193,
	188,
	0,
	'minimum',
	194,
	15,
	49);
INSERT INTO V_VAL
	VALUES (194,
	0,
	0,
	15,
	93,
	106,
	0,
	0,
	0,
	0,
	160,
	174);
INSERT INTO V_PVL
	VALUES (194,
	0,
	0,
	0,
	161);
INSERT INTO V_PAR
	VALUES (194,
	188,
	0,
	'sequenceNumber',
	0,
	15,
	72);
INSERT INTO C_PO
	VALUES (195,
	3,
	'HeartRateMonitor__HRChange',
	0,
	0);
INSERT INTO C_IR
	VALUES (196,
	197,
	0,
	195);
INSERT INTO C_P
	VALUES (196,
	'HRChange',
	'Unnamed Interface',
	'',
	'GPS_Watch::HeartRateMonitor__HRChange::HRChange');
INSERT INTO SPR_PEP
	VALUES (198,
	199,
	196);
INSERT INTO SPR_PO
	VALUES (198,
	'heartRateChanged',
	'',
	'Tracking::heartRateChanged( heartRate:param.heartRate );',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (200,
	198);
INSERT INTO ACT_ACT
	VALUES (200,
	'interface operation',
	0,
	201,
	0,
	0,
	'HeartRateMonitor__HRChange::HRChange::heartRateChanged',
	0);
INSERT INTO ACT_BLK
	VALUES (201,
	0,
	0,
	0,
	'Tracking',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	200,
	0);
INSERT INTO ACT_SMT
	VALUES (202,
	201,
	0,
	1,
	1,
	'HeartRateMonitor__HRChange::HRChange::heartRateChanged line: 1');
INSERT INTO ACT_IOP
	VALUES (202,
	1,
	11,
	1,
	1,
	0,
	45,
	0);
INSERT INTO V_VAL
	VALUES (203,
	0,
	0,
	1,
	45,
	53,
	0,
	0,
	0,
	0,
	160,
	201);
INSERT INTO V_PVL
	VALUES (203,
	0,
	0,
	0,
	204);
INSERT INTO V_PAR
	VALUES (203,
	202,
	0,
	'heartRate',
	0,
	1,
	29);
INSERT INTO C_PO
	VALUES (205,
	3,
	'Tracking__UI',
	0,
	0);
INSERT INTO C_IR
	VALUES (206,
	207,
	0,
	205);
INSERT INTO C_P
	VALUES (206,
	'Tracking_UI',
	'Unnamed Interface',
	'',
	'GPS_Watch::Tracking__UI::Tracking_UI');
INSERT INTO SPR_PEP
	VALUES (208,
	209,
	206);
INSERT INTO SPR_PO
	VALUES (208,
	'setData',
	'',
	'if (param.unit == Unit::km)
  UI::setData(value: param.value, unit: UIUnit::km);
elif (param.unit == Unit::meters)
  UI::setData(value: param.value, unit: UIUnit::meters);
elif (param.unit == Unit::minPerKm)
  UI::setData(value: param.value, unit: UIUnit::minPerKm);
elif (param.unit == Unit::kmPerHour)
  UI::setData(value: param.value, unit: UIUnit::kmPerHour);
elif (param.unit == Unit::miles)
  UI::setData(value: param.value, unit: UIUnit::miles);
elif (param.unit == Unit::yards)
  UI::setData(value: param.value, unit: UIUnit::yards);
elif (param.unit == Unit::feet)
  UI::setData(value: param.value, unit: UIUnit::feet);
elif (param.unit == Unit::minPerMile)
  UI::setData(value: param.value, unit: UIUnit::minPerMile);
elif (param.unit == Unit::mph)
  UI::setData(value: param.value, unit: UIUnit::mph);
elif (param.unit == Unit::bpm)
  UI::setData(value: param.value, unit: UIUnit::bpm);
elif (param.unit == Unit::laps)
  UI::setData(value: param.value, unit: UIUnit::laps);
end if;',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (210,
	208);
INSERT INTO ACT_ACT
	VALUES (210,
	'interface operation',
	0,
	211,
	0,
	0,
	'Tracking__UI::Tracking_UI::setData',
	0);
INSERT INTO ACT_BLK
	VALUES (211,
	0,
	0,
	0,
	'',
	'',
	'',
	21,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	21,
	21,
	0,
	210,
	0);
INSERT INTO ACT_SMT
	VALUES (212,
	211,
	0,
	1,
	1,
	'Tracking__UI::Tracking_UI::setData line: 1');
INSERT INTO ACT_IF
	VALUES (212,
	213,
	214,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (215,
	211,
	0,
	3,
	1,
	'Tracking__UI::Tracking_UI::setData line: 3');
INSERT INTO ACT_EL
	VALUES (215,
	216,
	217,
	212);
INSERT INTO ACT_SMT
	VALUES (218,
	211,
	0,
	5,
	1,
	'Tracking__UI::Tracking_UI::setData line: 5');
INSERT INTO ACT_EL
	VALUES (218,
	219,
	220,
	212);
INSERT INTO ACT_SMT
	VALUES (221,
	211,
	0,
	7,
	1,
	'Tracking__UI::Tracking_UI::setData line: 7');
INSERT INTO ACT_EL
	VALUES (221,
	222,
	223,
	212);
INSERT INTO ACT_SMT
	VALUES (224,
	211,
	0,
	9,
	1,
	'Tracking__UI::Tracking_UI::setData line: 9');
INSERT INTO ACT_EL
	VALUES (224,
	225,
	226,
	212);
INSERT INTO ACT_SMT
	VALUES (227,
	211,
	0,
	11,
	1,
	'Tracking__UI::Tracking_UI::setData line: 11');
INSERT INTO ACT_EL
	VALUES (227,
	228,
	229,
	212);
INSERT INTO ACT_SMT
	VALUES (230,
	211,
	0,
	13,
	1,
	'Tracking__UI::Tracking_UI::setData line: 13');
INSERT INTO ACT_EL
	VALUES (230,
	231,
	232,
	212);
INSERT INTO ACT_SMT
	VALUES (233,
	211,
	0,
	15,
	1,
	'Tracking__UI::Tracking_UI::setData line: 15');
INSERT INTO ACT_EL
	VALUES (233,
	234,
	235,
	212);
INSERT INTO ACT_SMT
	VALUES (236,
	211,
	0,
	17,
	1,
	'Tracking__UI::Tracking_UI::setData line: 17');
INSERT INTO ACT_EL
	VALUES (236,
	237,
	238,
	212);
INSERT INTO ACT_SMT
	VALUES (239,
	211,
	0,
	19,
	1,
	'Tracking__UI::Tracking_UI::setData line: 19');
INSERT INTO ACT_EL
	VALUES (239,
	240,
	241,
	212);
INSERT INTO ACT_SMT
	VALUES (242,
	211,
	0,
	21,
	1,
	'Tracking__UI::Tracking_UI::setData line: 21');
INSERT INTO ACT_EL
	VALUES (242,
	243,
	244,
	212);
INSERT INTO V_VAL
	VALUES (245,
	0,
	0,
	1,
	11,
	14,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_PVL
	VALUES (245,
	0,
	0,
	0,
	247);
INSERT INTO V_VAL
	VALUES (214,
	0,
	0,
	1,
	11,
	26,
	0,
	0,
	0,
	0,
	125,
	211);
INSERT INTO V_BIN
	VALUES (214,
	248,
	245,
	'==');
INSERT INTO V_VAL
	VALUES (248,
	0,
	0,
	1,
	25,
	26,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_LEN
	VALUES (248,
	249,
	1,
	19);
INSERT INTO V_VAL
	VALUES (250,
	0,
	0,
	3,
	13,
	16,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_PVL
	VALUES (250,
	0,
	0,
	0,
	247);
INSERT INTO V_VAL
	VALUES (217,
	0,
	0,
	3,
	13,
	32,
	0,
	0,
	0,
	0,
	125,
	211);
INSERT INTO V_BIN
	VALUES (217,
	251,
	250,
	'==');
INSERT INTO V_VAL
	VALUES (251,
	0,
	0,
	3,
	27,
	32,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_LEN
	VALUES (251,
	252,
	3,
	21);
INSERT INTO V_VAL
	VALUES (253,
	0,
	0,
	5,
	13,
	16,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_PVL
	VALUES (253,
	0,
	0,
	0,
	247);
INSERT INTO V_VAL
	VALUES (220,
	0,
	0,
	5,
	13,
	34,
	0,
	0,
	0,
	0,
	125,
	211);
INSERT INTO V_BIN
	VALUES (220,
	254,
	253,
	'==');
INSERT INTO V_VAL
	VALUES (254,
	0,
	0,
	5,
	27,
	34,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_LEN
	VALUES (254,
	255,
	5,
	21);
INSERT INTO V_VAL
	VALUES (256,
	0,
	0,
	7,
	13,
	16,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_PVL
	VALUES (256,
	0,
	0,
	0,
	247);
INSERT INTO V_VAL
	VALUES (223,
	0,
	0,
	7,
	13,
	35,
	0,
	0,
	0,
	0,
	125,
	211);
INSERT INTO V_BIN
	VALUES (223,
	257,
	256,
	'==');
INSERT INTO V_VAL
	VALUES (257,
	0,
	0,
	7,
	27,
	35,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_LEN
	VALUES (257,
	258,
	7,
	21);
INSERT INTO V_VAL
	VALUES (259,
	0,
	0,
	9,
	13,
	16,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_PVL
	VALUES (259,
	0,
	0,
	0,
	247);
INSERT INTO V_VAL
	VALUES (226,
	0,
	0,
	9,
	13,
	31,
	0,
	0,
	0,
	0,
	125,
	211);
INSERT INTO V_BIN
	VALUES (226,
	260,
	259,
	'==');
INSERT INTO V_VAL
	VALUES (260,
	0,
	0,
	9,
	27,
	31,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_LEN
	VALUES (260,
	261,
	9,
	21);
INSERT INTO V_VAL
	VALUES (262,
	0,
	0,
	11,
	13,
	16,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_PVL
	VALUES (262,
	0,
	0,
	0,
	247);
INSERT INTO V_VAL
	VALUES (229,
	0,
	0,
	11,
	13,
	31,
	0,
	0,
	0,
	0,
	125,
	211);
INSERT INTO V_BIN
	VALUES (229,
	263,
	262,
	'==');
INSERT INTO V_VAL
	VALUES (263,
	0,
	0,
	11,
	27,
	31,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_LEN
	VALUES (263,
	264,
	11,
	21);
INSERT INTO V_VAL
	VALUES (265,
	0,
	0,
	13,
	13,
	16,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_PVL
	VALUES (265,
	0,
	0,
	0,
	247);
INSERT INTO V_VAL
	VALUES (232,
	0,
	0,
	13,
	13,
	30,
	0,
	0,
	0,
	0,
	125,
	211);
INSERT INTO V_BIN
	VALUES (232,
	266,
	265,
	'==');
INSERT INTO V_VAL
	VALUES (266,
	0,
	0,
	13,
	27,
	30,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_LEN
	VALUES (266,
	267,
	13,
	21);
INSERT INTO V_VAL
	VALUES (268,
	0,
	0,
	15,
	13,
	16,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_PVL
	VALUES (268,
	0,
	0,
	0,
	247);
INSERT INTO V_VAL
	VALUES (235,
	0,
	0,
	15,
	13,
	36,
	0,
	0,
	0,
	0,
	125,
	211);
INSERT INTO V_BIN
	VALUES (235,
	269,
	268,
	'==');
INSERT INTO V_VAL
	VALUES (269,
	0,
	0,
	15,
	27,
	36,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_LEN
	VALUES (269,
	270,
	15,
	21);
INSERT INTO V_VAL
	VALUES (271,
	0,
	0,
	17,
	13,
	16,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_PVL
	VALUES (271,
	0,
	0,
	0,
	247);
INSERT INTO V_VAL
	VALUES (238,
	0,
	0,
	17,
	13,
	29,
	0,
	0,
	0,
	0,
	125,
	211);
INSERT INTO V_BIN
	VALUES (238,
	272,
	271,
	'==');
INSERT INTO V_VAL
	VALUES (272,
	0,
	0,
	17,
	27,
	29,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_LEN
	VALUES (272,
	273,
	17,
	21);
INSERT INTO V_VAL
	VALUES (274,
	0,
	0,
	19,
	13,
	16,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_PVL
	VALUES (274,
	0,
	0,
	0,
	247);
INSERT INTO V_VAL
	VALUES (241,
	0,
	0,
	19,
	13,
	29,
	0,
	0,
	0,
	0,
	125,
	211);
INSERT INTO V_BIN
	VALUES (241,
	275,
	274,
	'==');
INSERT INTO V_VAL
	VALUES (275,
	0,
	0,
	19,
	27,
	29,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_LEN
	VALUES (275,
	276,
	19,
	21);
INSERT INTO V_VAL
	VALUES (277,
	0,
	0,
	21,
	13,
	16,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_PVL
	VALUES (277,
	0,
	0,
	0,
	247);
INSERT INTO V_VAL
	VALUES (244,
	0,
	0,
	21,
	13,
	30,
	0,
	0,
	0,
	0,
	125,
	211);
INSERT INTO V_BIN
	VALUES (244,
	278,
	277,
	'==');
INSERT INTO V_VAL
	VALUES (278,
	0,
	0,
	21,
	27,
	30,
	0,
	0,
	0,
	0,
	246,
	211);
INSERT INTO V_LEN
	VALUES (278,
	279,
	21,
	21);
INSERT INTO ACT_BLK
	VALUES (213,
	0,
	0,
	0,
	'UI',
	'',
	'',
	2,
	3,
	2,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	2,
	41,
	0,
	210,
	0);
INSERT INTO ACT_SMT
	VALUES (280,
	213,
	0,
	2,
	3,
	'Tracking__UI::Tracking_UI::setData line: 2');
INSERT INTO ACT_IOP
	VALUES (280,
	2,
	7,
	2,
	3,
	0,
	11,
	0);
INSERT INTO V_VAL
	VALUES (281,
	0,
	0,
	2,
	28,
	32,
	0,
	0,
	0,
	0,
	153,
	213);
INSERT INTO V_PVL
	VALUES (281,
	0,
	0,
	0,
	282);
INSERT INTO V_PAR
	VALUES (281,
	280,
	0,
	'value',
	283,
	2,
	15);
INSERT INTO V_VAL
	VALUES (283,
	0,
	0,
	2,
	49,
	50,
	0,
	0,
	0,
	0,
	284,
	213);
INSERT INTO V_LEN
	VALUES (283,
	285,
	2,
	41);
INSERT INTO V_PAR
	VALUES (283,
	280,
	0,
	'unit',
	0,
	2,
	35);
INSERT INTO ACT_BLK
	VALUES (216,
	0,
	0,
	0,
	'UI',
	'',
	'',
	4,
	3,
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	4,
	41,
	0,
	210,
	0);
INSERT INTO ACT_SMT
	VALUES (286,
	216,
	0,
	4,
	3,
	'Tracking__UI::Tracking_UI::setData line: 4');
INSERT INTO ACT_IOP
	VALUES (286,
	4,
	7,
	4,
	3,
	0,
	11,
	0);
INSERT INTO V_VAL
	VALUES (287,
	0,
	0,
	4,
	28,
	32,
	0,
	0,
	0,
	0,
	153,
	216);
INSERT INTO V_PVL
	VALUES (287,
	0,
	0,
	0,
	282);
INSERT INTO V_PAR
	VALUES (287,
	286,
	0,
	'value',
	288,
	4,
	15);
INSERT INTO V_VAL
	VALUES (288,
	0,
	0,
	4,
	49,
	54,
	0,
	0,
	0,
	0,
	284,
	216);
INSERT INTO V_LEN
	VALUES (288,
	289,
	4,
	41);
INSERT INTO V_PAR
	VALUES (288,
	286,
	0,
	'unit',
	0,
	4,
	35);
INSERT INTO ACT_BLK
	VALUES (219,
	0,
	0,
	0,
	'UI',
	'',
	'',
	6,
	3,
	6,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	6,
	41,
	0,
	210,
	0);
INSERT INTO ACT_SMT
	VALUES (290,
	219,
	0,
	6,
	3,
	'Tracking__UI::Tracking_UI::setData line: 6');
INSERT INTO ACT_IOP
	VALUES (290,
	6,
	7,
	6,
	3,
	0,
	11,
	0);
INSERT INTO V_VAL
	VALUES (291,
	0,
	0,
	6,
	28,
	32,
	0,
	0,
	0,
	0,
	153,
	219);
INSERT INTO V_PVL
	VALUES (291,
	0,
	0,
	0,
	282);
INSERT INTO V_PAR
	VALUES (291,
	290,
	0,
	'value',
	292,
	6,
	15);
INSERT INTO V_VAL
	VALUES (292,
	0,
	0,
	6,
	49,
	56,
	0,
	0,
	0,
	0,
	284,
	219);
INSERT INTO V_LEN
	VALUES (292,
	293,
	6,
	41);
INSERT INTO V_PAR
	VALUES (292,
	290,
	0,
	'unit',
	0,
	6,
	35);
INSERT INTO ACT_BLK
	VALUES (222,
	0,
	0,
	0,
	'UI',
	'',
	'',
	8,
	3,
	8,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	8,
	41,
	0,
	210,
	0);
INSERT INTO ACT_SMT
	VALUES (294,
	222,
	0,
	8,
	3,
	'Tracking__UI::Tracking_UI::setData line: 8');
INSERT INTO ACT_IOP
	VALUES (294,
	8,
	7,
	8,
	3,
	0,
	11,
	0);
INSERT INTO V_VAL
	VALUES (295,
	0,
	0,
	8,
	28,
	32,
	0,
	0,
	0,
	0,
	153,
	222);
INSERT INTO V_PVL
	VALUES (295,
	0,
	0,
	0,
	282);
INSERT INTO V_PAR
	VALUES (295,
	294,
	0,
	'value',
	296,
	8,
	15);
INSERT INTO V_VAL
	VALUES (296,
	0,
	0,
	8,
	49,
	57,
	0,
	0,
	0,
	0,
	284,
	222);
INSERT INTO V_LEN
	VALUES (296,
	297,
	8,
	41);
INSERT INTO V_PAR
	VALUES (296,
	294,
	0,
	'unit',
	0,
	8,
	35);
INSERT INTO ACT_BLK
	VALUES (225,
	0,
	0,
	0,
	'UI',
	'',
	'',
	10,
	3,
	10,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	10,
	41,
	0,
	210,
	0);
INSERT INTO ACT_SMT
	VALUES (298,
	225,
	0,
	10,
	3,
	'Tracking__UI::Tracking_UI::setData line: 10');
INSERT INTO ACT_IOP
	VALUES (298,
	10,
	7,
	10,
	3,
	0,
	11,
	0);
INSERT INTO V_VAL
	VALUES (299,
	0,
	0,
	10,
	28,
	32,
	0,
	0,
	0,
	0,
	153,
	225);
INSERT INTO V_PVL
	VALUES (299,
	0,
	0,
	0,
	282);
INSERT INTO V_PAR
	VALUES (299,
	298,
	0,
	'value',
	300,
	10,
	15);
INSERT INTO V_VAL
	VALUES (300,
	0,
	0,
	10,
	49,
	53,
	0,
	0,
	0,
	0,
	284,
	225);
INSERT INTO V_LEN
	VALUES (300,
	301,
	10,
	41);
INSERT INTO V_PAR
	VALUES (300,
	298,
	0,
	'unit',
	0,
	10,
	35);
INSERT INTO ACT_BLK
	VALUES (228,
	0,
	0,
	0,
	'UI',
	'',
	'',
	12,
	3,
	12,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	12,
	41,
	0,
	210,
	0);
INSERT INTO ACT_SMT
	VALUES (302,
	228,
	0,
	12,
	3,
	'Tracking__UI::Tracking_UI::setData line: 12');
INSERT INTO ACT_IOP
	VALUES (302,
	12,
	7,
	12,
	3,
	0,
	11,
	0);
INSERT INTO V_VAL
	VALUES (303,
	0,
	0,
	12,
	28,
	32,
	0,
	0,
	0,
	0,
	153,
	228);
INSERT INTO V_PVL
	VALUES (303,
	0,
	0,
	0,
	282);
INSERT INTO V_PAR
	VALUES (303,
	302,
	0,
	'value',
	304,
	12,
	15);
INSERT INTO V_VAL
	VALUES (304,
	0,
	0,
	12,
	49,
	53,
	0,
	0,
	0,
	0,
	284,
	228);
INSERT INTO V_LEN
	VALUES (304,
	305,
	12,
	41);
INSERT INTO V_PAR
	VALUES (304,
	302,
	0,
	'unit',
	0,
	12,
	35);
INSERT INTO ACT_BLK
	VALUES (231,
	0,
	0,
	0,
	'UI',
	'',
	'',
	14,
	3,
	14,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	14,
	41,
	0,
	210,
	0);
INSERT INTO ACT_SMT
	VALUES (306,
	231,
	0,
	14,
	3,
	'Tracking__UI::Tracking_UI::setData line: 14');
INSERT INTO ACT_IOP
	VALUES (306,
	14,
	7,
	14,
	3,
	0,
	11,
	0);
INSERT INTO V_VAL
	VALUES (307,
	0,
	0,
	14,
	28,
	32,
	0,
	0,
	0,
	0,
	153,
	231);
INSERT INTO V_PVL
	VALUES (307,
	0,
	0,
	0,
	282);
INSERT INTO V_PAR
	VALUES (307,
	306,
	0,
	'value',
	308,
	14,
	15);
INSERT INTO V_VAL
	VALUES (308,
	0,
	0,
	14,
	49,
	52,
	0,
	0,
	0,
	0,
	284,
	231);
INSERT INTO V_LEN
	VALUES (308,
	309,
	14,
	41);
INSERT INTO V_PAR
	VALUES (308,
	306,
	0,
	'unit',
	0,
	14,
	35);
INSERT INTO ACT_BLK
	VALUES (234,
	0,
	0,
	0,
	'UI',
	'',
	'',
	16,
	3,
	16,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	16,
	41,
	0,
	210,
	0);
INSERT INTO ACT_SMT
	VALUES (310,
	234,
	0,
	16,
	3,
	'Tracking__UI::Tracking_UI::setData line: 16');
INSERT INTO ACT_IOP
	VALUES (310,
	16,
	7,
	16,
	3,
	0,
	11,
	0);
INSERT INTO V_VAL
	VALUES (311,
	0,
	0,
	16,
	28,
	32,
	0,
	0,
	0,
	0,
	153,
	234);
INSERT INTO V_PVL
	VALUES (311,
	0,
	0,
	0,
	282);
INSERT INTO V_PAR
	VALUES (311,
	310,
	0,
	'value',
	312,
	16,
	15);
INSERT INTO V_VAL
	VALUES (312,
	0,
	0,
	16,
	49,
	58,
	0,
	0,
	0,
	0,
	284,
	234);
INSERT INTO V_LEN
	VALUES (312,
	313,
	16,
	41);
INSERT INTO V_PAR
	VALUES (312,
	310,
	0,
	'unit',
	0,
	16,
	35);
INSERT INTO ACT_BLK
	VALUES (237,
	0,
	0,
	0,
	'UI',
	'',
	'',
	18,
	3,
	18,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	18,
	41,
	0,
	210,
	0);
INSERT INTO ACT_SMT
	VALUES (314,
	237,
	0,
	18,
	3,
	'Tracking__UI::Tracking_UI::setData line: 18');
INSERT INTO ACT_IOP
	VALUES (314,
	18,
	7,
	18,
	3,
	0,
	11,
	0);
INSERT INTO V_VAL
	VALUES (315,
	0,
	0,
	18,
	28,
	32,
	0,
	0,
	0,
	0,
	153,
	237);
INSERT INTO V_PVL
	VALUES (315,
	0,
	0,
	0,
	282);
INSERT INTO V_PAR
	VALUES (315,
	314,
	0,
	'value',
	316,
	18,
	15);
INSERT INTO V_VAL
	VALUES (316,
	0,
	0,
	18,
	49,
	51,
	0,
	0,
	0,
	0,
	284,
	237);
INSERT INTO V_LEN
	VALUES (316,
	317,
	18,
	41);
INSERT INTO V_PAR
	VALUES (316,
	314,
	0,
	'unit',
	0,
	18,
	35);
INSERT INTO ACT_BLK
	VALUES (240,
	0,
	0,
	0,
	'UI',
	'',
	'',
	20,
	3,
	20,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	20,
	41,
	0,
	210,
	0);
INSERT INTO ACT_SMT
	VALUES (318,
	240,
	0,
	20,
	3,
	'Tracking__UI::Tracking_UI::setData line: 20');
INSERT INTO ACT_IOP
	VALUES (318,
	20,
	7,
	20,
	3,
	0,
	11,
	0);
INSERT INTO V_VAL
	VALUES (319,
	0,
	0,
	20,
	28,
	32,
	0,
	0,
	0,
	0,
	153,
	240);
INSERT INTO V_PVL
	VALUES (319,
	0,
	0,
	0,
	282);
INSERT INTO V_PAR
	VALUES (319,
	318,
	0,
	'value',
	320,
	20,
	15);
INSERT INTO V_VAL
	VALUES (320,
	0,
	0,
	20,
	49,
	51,
	0,
	0,
	0,
	0,
	284,
	240);
INSERT INTO V_LEN
	VALUES (320,
	321,
	20,
	41);
INSERT INTO V_PAR
	VALUES (320,
	318,
	0,
	'unit',
	0,
	20,
	35);
INSERT INTO ACT_BLK
	VALUES (243,
	0,
	0,
	0,
	'UI',
	'',
	'',
	22,
	3,
	22,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	22,
	41,
	0,
	210,
	0);
INSERT INTO ACT_SMT
	VALUES (322,
	243,
	0,
	22,
	3,
	'Tracking__UI::Tracking_UI::setData line: 22');
INSERT INTO ACT_IOP
	VALUES (322,
	22,
	7,
	22,
	3,
	0,
	11,
	0);
INSERT INTO V_VAL
	VALUES (323,
	0,
	0,
	22,
	28,
	32,
	0,
	0,
	0,
	0,
	153,
	243);
INSERT INTO V_PVL
	VALUES (323,
	0,
	0,
	0,
	282);
INSERT INTO V_PAR
	VALUES (323,
	322,
	0,
	'value',
	324,
	22,
	15);
INSERT INTO V_VAL
	VALUES (324,
	0,
	0,
	22,
	49,
	52,
	0,
	0,
	0,
	0,
	284,
	243);
INSERT INTO V_LEN
	VALUES (324,
	325,
	22,
	41);
INSERT INTO V_PAR
	VALUES (324,
	322,
	0,
	'unit',
	0,
	22,
	35);
INSERT INTO SPR_PEP
	VALUES (326,
	327,
	206);
INSERT INTO SPR_PO
	VALUES (326,
	'setIndicator',
	'',
	'if ( param.indicator == Indicator::Blank  )
  UI::setIndicator( indicator: UIIndicator::Blank );
elif ( param.indicator == Indicator::Down )
  UI::setIndicator( indicator: UIIndicator::Down );
elif ( param.indicator == Indicator::Flat )
  UI::setIndicator( indicator: UIIndicator::Flat );
elif ( param.indicator == Indicator::Up )
  UI::setIndicator( indicator: UIIndicator::Up );
end if;',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (328,
	326);
INSERT INTO ACT_ACT
	VALUES (328,
	'interface operation',
	0,
	329,
	0,
	0,
	'Tracking__UI::Tracking_UI::setIndicator',
	0);
INSERT INTO ACT_BLK
	VALUES (329,
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	7,
	27,
	0,
	328,
	0);
INSERT INTO ACT_SMT
	VALUES (330,
	329,
	0,
	1,
	1,
	'Tracking__UI::Tracking_UI::setIndicator line: 1');
INSERT INTO ACT_IF
	VALUES (330,
	331,
	332,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (333,
	329,
	0,
	3,
	1,
	'Tracking__UI::Tracking_UI::setIndicator line: 3');
INSERT INTO ACT_EL
	VALUES (333,
	334,
	335,
	330);
INSERT INTO ACT_SMT
	VALUES (336,
	329,
	0,
	5,
	1,
	'Tracking__UI::Tracking_UI::setIndicator line: 5');
INSERT INTO ACT_EL
	VALUES (336,
	337,
	338,
	330);
INSERT INTO ACT_SMT
	VALUES (339,
	329,
	0,
	7,
	1,
	'Tracking__UI::Tracking_UI::setIndicator line: 7');
INSERT INTO ACT_EL
	VALUES (339,
	340,
	341,
	330);
INSERT INTO V_VAL
	VALUES (342,
	0,
	0,
	1,
	12,
	20,
	0,
	0,
	0,
	0,
	343,
	329);
INSERT INTO V_PVL
	VALUES (342,
	0,
	0,
	0,
	344);
INSERT INTO V_VAL
	VALUES (332,
	0,
	0,
	1,
	12,
	40,
	0,
	0,
	0,
	0,
	125,
	329);
INSERT INTO V_BIN
	VALUES (332,
	345,
	342,
	'==');
INSERT INTO V_VAL
	VALUES (345,
	0,
	0,
	1,
	36,
	40,
	0,
	0,
	0,
	0,
	343,
	329);
INSERT INTO V_LEN
	VALUES (345,
	346,
	1,
	25);
INSERT INTO V_VAL
	VALUES (347,
	0,
	0,
	3,
	14,
	22,
	0,
	0,
	0,
	0,
	343,
	329);
INSERT INTO V_PVL
	VALUES (347,
	0,
	0,
	0,
	344);
INSERT INTO V_VAL
	VALUES (335,
	0,
	0,
	3,
	14,
	41,
	0,
	0,
	0,
	0,
	125,
	329);
INSERT INTO V_BIN
	VALUES (335,
	348,
	347,
	'==');
INSERT INTO V_VAL
	VALUES (348,
	0,
	0,
	3,
	38,
	41,
	0,
	0,
	0,
	0,
	343,
	329);
INSERT INTO V_LEN
	VALUES (348,
	349,
	3,
	27);
INSERT INTO V_VAL
	VALUES (350,
	0,
	0,
	5,
	14,
	22,
	0,
	0,
	0,
	0,
	343,
	329);
INSERT INTO V_PVL
	VALUES (350,
	0,
	0,
	0,
	344);
INSERT INTO V_VAL
	VALUES (338,
	0,
	0,
	5,
	14,
	41,
	0,
	0,
	0,
	0,
	125,
	329);
INSERT INTO V_BIN
	VALUES (338,
	351,
	350,
	'==');
INSERT INTO V_VAL
	VALUES (351,
	0,
	0,
	5,
	38,
	41,
	0,
	0,
	0,
	0,
	343,
	329);
INSERT INTO V_LEN
	VALUES (351,
	352,
	5,
	27);
INSERT INTO V_VAL
	VALUES (353,
	0,
	0,
	7,
	14,
	22,
	0,
	0,
	0,
	0,
	343,
	329);
INSERT INTO V_PVL
	VALUES (353,
	0,
	0,
	0,
	344);
INSERT INTO V_VAL
	VALUES (341,
	0,
	0,
	7,
	14,
	39,
	0,
	0,
	0,
	0,
	125,
	329);
INSERT INTO V_BIN
	VALUES (341,
	354,
	353,
	'==');
INSERT INTO V_VAL
	VALUES (354,
	0,
	0,
	7,
	38,
	39,
	0,
	0,
	0,
	0,
	343,
	329);
INSERT INTO V_LEN
	VALUES (354,
	355,
	7,
	27);
INSERT INTO ACT_BLK
	VALUES (331,
	0,
	0,
	0,
	'UI',
	'',
	'',
	2,
	3,
	2,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	2,
	32,
	0,
	328,
	0);
INSERT INTO ACT_SMT
	VALUES (356,
	331,
	0,
	2,
	3,
	'Tracking__UI::Tracking_UI::setIndicator line: 2');
INSERT INTO ACT_IOP
	VALUES (356,
	2,
	7,
	2,
	3,
	0,
	19,
	0);
INSERT INTO V_VAL
	VALUES (357,
	0,
	0,
	2,
	45,
	49,
	0,
	0,
	0,
	0,
	358,
	331);
INSERT INTO V_LEN
	VALUES (357,
	359,
	2,
	32);
INSERT INTO V_PAR
	VALUES (357,
	356,
	0,
	'indicator',
	0,
	2,
	21);
INSERT INTO ACT_BLK
	VALUES (334,
	0,
	0,
	0,
	'UI',
	'',
	'',
	4,
	3,
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	4,
	32,
	0,
	328,
	0);
INSERT INTO ACT_SMT
	VALUES (360,
	334,
	0,
	4,
	3,
	'Tracking__UI::Tracking_UI::setIndicator line: 4');
INSERT INTO ACT_IOP
	VALUES (360,
	4,
	7,
	4,
	3,
	0,
	19,
	0);
INSERT INTO V_VAL
	VALUES (361,
	0,
	0,
	4,
	45,
	48,
	0,
	0,
	0,
	0,
	358,
	334);
INSERT INTO V_LEN
	VALUES (361,
	362,
	4,
	32);
INSERT INTO V_PAR
	VALUES (361,
	360,
	0,
	'indicator',
	0,
	4,
	21);
INSERT INTO ACT_BLK
	VALUES (337,
	0,
	0,
	0,
	'UI',
	'',
	'',
	6,
	3,
	6,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	6,
	32,
	0,
	328,
	0);
INSERT INTO ACT_SMT
	VALUES (363,
	337,
	0,
	6,
	3,
	'Tracking__UI::Tracking_UI::setIndicator line: 6');
INSERT INTO ACT_IOP
	VALUES (363,
	6,
	7,
	6,
	3,
	0,
	19,
	0);
INSERT INTO V_VAL
	VALUES (364,
	0,
	0,
	6,
	45,
	48,
	0,
	0,
	0,
	0,
	358,
	337);
INSERT INTO V_LEN
	VALUES (364,
	365,
	6,
	32);
INSERT INTO V_PAR
	VALUES (364,
	363,
	0,
	'indicator',
	0,
	6,
	21);
INSERT INTO ACT_BLK
	VALUES (340,
	0,
	0,
	0,
	'UI',
	'',
	'',
	8,
	3,
	8,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	8,
	32,
	0,
	328,
	0);
INSERT INTO ACT_SMT
	VALUES (366,
	340,
	0,
	8,
	3,
	'Tracking__UI::Tracking_UI::setIndicator line: 8');
INSERT INTO ACT_IOP
	VALUES (366,
	8,
	7,
	8,
	3,
	0,
	19,
	0);
INSERT INTO V_VAL
	VALUES (367,
	0,
	0,
	8,
	45,
	46,
	0,
	0,
	0,
	0,
	358,
	340);
INSERT INTO V_LEN
	VALUES (367,
	368,
	8,
	32);
INSERT INTO V_PAR
	VALUES (367,
	366,
	0,
	'indicator',
	0,
	8,
	21);
INSERT INTO SPR_PEP
	VALUES (369,
	370,
	206);
INSERT INTO SPR_PO
	VALUES (369,
	'setTime',
	'',
	'UI::setTime( time:param.time );',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (371,
	369);
INSERT INTO ACT_ACT
	VALUES (371,
	'interface operation',
	0,
	372,
	0,
	0,
	'Tracking__UI::Tracking_UI::setTime',
	0);
INSERT INTO ACT_BLK
	VALUES (372,
	0,
	0,
	0,
	'UI',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	371,
	0);
INSERT INTO ACT_SMT
	VALUES (373,
	372,
	0,
	1,
	1,
	'Tracking__UI::Tracking_UI::setTime line: 1');
INSERT INTO ACT_IOP
	VALUES (373,
	1,
	5,
	1,
	1,
	0,
	7,
	0);
INSERT INTO V_VAL
	VALUES (374,
	0,
	0,
	1,
	25,
	28,
	0,
	0,
	0,
	0,
	160,
	372);
INSERT INTO V_PVL
	VALUES (374,
	0,
	0,
	0,
	375);
INSERT INTO V_PAR
	VALUES (374,
	373,
	0,
	'time',
	0,
	1,
	14);
INSERT INTO C_PO
	VALUES (376,
	3,
	'Tracking__LOC',
	0,
	0);
INSERT INTO C_IR
	VALUES (377,
	378,
	0,
	376);
INSERT INTO C_P
	VALUES (377,
	'Tracking_Location',
	'Unnamed Interface',
	'',
	'GPS_Watch::Tracking__LOC::Tracking_Location');
INSERT INTO SPR_PEP
	VALUES (379,
	380,
	377);
INSERT INTO SPR_PO
	VALUES (379,
	'getDistance',
	'',
	'distance = param.result;
Location::getDistance( result:distance, fromLat:param.fromLat, fromLong:param.fromLong, toLat:param.toLat, toLong: param.toLong);
param.result = distance;',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (381,
	379);
INSERT INTO ACT_ACT
	VALUES (381,
	'interface operation',
	0,
	382,
	0,
	0,
	'Tracking__LOC::Tracking_Location::getDistance',
	0);
INSERT INTO ACT_BLK
	VALUES (382,
	0,
	0,
	0,
	'Location',
	'',
	'',
	3,
	1,
	2,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	381,
	0);
INSERT INTO ACT_SMT
	VALUES (383,
	382,
	384,
	1,
	1,
	'Tracking__LOC::Tracking_Location::getDistance line: 1');
INSERT INTO ACT_AI
	VALUES (383,
	385,
	386,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (384,
	382,
	387,
	2,
	1,
	'Tracking__LOC::Tracking_Location::getDistance line: 2');
INSERT INTO ACT_IOP
	VALUES (384,
	2,
	11,
	2,
	1,
	0,
	38,
	0);
INSERT INTO ACT_SMT
	VALUES (387,
	382,
	0,
	3,
	1,
	'Tracking__LOC::Tracking_Location::getDistance line: 3');
INSERT INTO ACT_AI
	VALUES (387,
	388,
	389,
	0,
	0);
INSERT INTO V_VAL
	VALUES (386,
	1,
	1,
	1,
	1,
	8,
	0,
	0,
	0,
	0,
	153,
	382);
INSERT INTO V_TVL
	VALUES (386,
	390);
INSERT INTO V_VAL
	VALUES (385,
	0,
	0,
	1,
	18,
	23,
	0,
	0,
	0,
	0,
	153,
	382);
INSERT INTO V_PVL
	VALUES (385,
	0,
	0,
	0,
	391);
INSERT INTO V_VAL
	VALUES (392,
	0,
	0,
	2,
	31,
	38,
	0,
	0,
	0,
	0,
	153,
	382);
INSERT INTO V_TVL
	VALUES (392,
	390);
INSERT INTO V_PAR
	VALUES (392,
	384,
	0,
	'result',
	393,
	2,
	24);
INSERT INTO V_VAL
	VALUES (393,
	0,
	0,
	2,
	55,
	61,
	0,
	0,
	0,
	0,
	153,
	382);
INSERT INTO V_PVL
	VALUES (393,
	0,
	0,
	0,
	394);
INSERT INTO V_PAR
	VALUES (393,
	384,
	0,
	'fromLat',
	395,
	2,
	41);
INSERT INTO V_VAL
	VALUES (395,
	0,
	0,
	2,
	79,
	86,
	0,
	0,
	0,
	0,
	153,
	382);
INSERT INTO V_PVL
	VALUES (395,
	0,
	0,
	0,
	396);
INSERT INTO V_PAR
	VALUES (395,
	384,
	0,
	'fromLong',
	397,
	2,
	64);
INSERT INTO V_VAL
	VALUES (397,
	0,
	0,
	2,
	101,
	105,
	0,
	0,
	0,
	0,
	153,
	382);
INSERT INTO V_PVL
	VALUES (397,
	0,
	0,
	0,
	398);
INSERT INTO V_PAR
	VALUES (397,
	384,
	0,
	'toLat',
	399,
	2,
	89);
INSERT INTO V_VAL
	VALUES (399,
	0,
	0,
	2,
	122,
	127,
	0,
	0,
	0,
	0,
	153,
	382);
INSERT INTO V_PVL
	VALUES (399,
	0,
	0,
	0,
	400);
INSERT INTO V_PAR
	VALUES (399,
	384,
	0,
	'toLong',
	0,
	2,
	108);
INSERT INTO V_VAL
	VALUES (389,
	1,
	0,
	3,
	7,
	12,
	0,
	0,
	0,
	0,
	153,
	382);
INSERT INTO V_PVL
	VALUES (389,
	0,
	0,
	0,
	391);
INSERT INTO V_VAL
	VALUES (388,
	0,
	0,
	3,
	16,
	23,
	0,
	0,
	0,
	0,
	153,
	382);
INSERT INTO V_TVL
	VALUES (388,
	390);
INSERT INTO V_VAR
	VALUES (390,
	382,
	'distance',
	1,
	153);
INSERT INTO V_TRN
	VALUES (390,
	0,
	'');
INSERT INTO SPR_PEP
	VALUES (401,
	402,
	377);
INSERT INTO SPR_PO
	VALUES (401,
	'getLocation',
	'',
	'// Transient varible is used here to workaround a bug (#10160)
lat = param.latitude;
longi = param.longitude;
Location::getLocation( latitude:lat, longitude: longi);
param.latitude = lat;
param.longitude = longi;
',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (403,
	401);
INSERT INTO ACT_ACT
	VALUES (403,
	'interface operation',
	0,
	404,
	0,
	0,
	'Tracking__LOC::Tracking_Location::getLocation',
	0);
INSERT INTO ACT_BLK
	VALUES (404,
	0,
	0,
	0,
	'Location',
	'',
	'',
	6,
	1,
	4,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	403,
	0);
INSERT INTO ACT_SMT
	VALUES (405,
	404,
	406,
	2,
	1,
	'Tracking__LOC::Tracking_Location::getLocation line: 2');
INSERT INTO ACT_AI
	VALUES (405,
	407,
	408,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (406,
	404,
	409,
	3,
	1,
	'Tracking__LOC::Tracking_Location::getLocation line: 3');
INSERT INTO ACT_AI
	VALUES (406,
	410,
	411,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (409,
	404,
	412,
	4,
	1,
	'Tracking__LOC::Tracking_Location::getLocation line: 4');
INSERT INTO ACT_IOP
	VALUES (409,
	4,
	11,
	4,
	1,
	0,
	26,
	0);
INSERT INTO ACT_SMT
	VALUES (412,
	404,
	413,
	5,
	1,
	'Tracking__LOC::Tracking_Location::getLocation line: 5');
INSERT INTO ACT_AI
	VALUES (412,
	414,
	415,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (413,
	404,
	0,
	6,
	1,
	'Tracking__LOC::Tracking_Location::getLocation line: 6');
INSERT INTO ACT_AI
	VALUES (413,
	416,
	417,
	0,
	0);
INSERT INTO V_VAL
	VALUES (408,
	1,
	1,
	2,
	1,
	3,
	0,
	0,
	0,
	0,
	153,
	404);
INSERT INTO V_TVL
	VALUES (408,
	418);
INSERT INTO V_VAL
	VALUES (407,
	0,
	0,
	2,
	13,
	20,
	0,
	0,
	0,
	0,
	153,
	404);
INSERT INTO V_PVL
	VALUES (407,
	0,
	0,
	0,
	419);
INSERT INTO V_VAL
	VALUES (411,
	1,
	1,
	3,
	1,
	5,
	0,
	0,
	0,
	0,
	153,
	404);
INSERT INTO V_TVL
	VALUES (411,
	420);
INSERT INTO V_VAL
	VALUES (410,
	0,
	0,
	3,
	15,
	23,
	0,
	0,
	0,
	0,
	153,
	404);
INSERT INTO V_PVL
	VALUES (410,
	0,
	0,
	0,
	421);
INSERT INTO V_VAL
	VALUES (422,
	0,
	0,
	4,
	33,
	35,
	0,
	0,
	0,
	0,
	153,
	404);
INSERT INTO V_TVL
	VALUES (422,
	418);
INSERT INTO V_PAR
	VALUES (422,
	409,
	0,
	'latitude',
	423,
	4,
	24);
INSERT INTO V_VAL
	VALUES (423,
	0,
	0,
	4,
	49,
	53,
	0,
	0,
	0,
	0,
	153,
	404);
INSERT INTO V_TVL
	VALUES (423,
	420);
INSERT INTO V_PAR
	VALUES (423,
	409,
	0,
	'longitude',
	0,
	4,
	38);
INSERT INTO V_VAL
	VALUES (415,
	1,
	0,
	5,
	7,
	14,
	0,
	0,
	0,
	0,
	153,
	404);
INSERT INTO V_PVL
	VALUES (415,
	0,
	0,
	0,
	419);
INSERT INTO V_VAL
	VALUES (414,
	0,
	0,
	5,
	18,
	20,
	0,
	0,
	0,
	0,
	153,
	404);
INSERT INTO V_TVL
	VALUES (414,
	418);
INSERT INTO V_VAL
	VALUES (417,
	1,
	0,
	6,
	7,
	15,
	0,
	0,
	0,
	0,
	153,
	404);
INSERT INTO V_PVL
	VALUES (417,
	0,
	0,
	0,
	421);
INSERT INTO V_VAL
	VALUES (416,
	0,
	0,
	6,
	19,
	23,
	0,
	0,
	0,
	0,
	153,
	404);
INSERT INTO V_TVL
	VALUES (416,
	420);
INSERT INTO V_VAR
	VALUES (418,
	404,
	'lat',
	1,
	153);
INSERT INTO V_TRN
	VALUES (418,
	0,
	'');
INSERT INTO V_VAR
	VALUES (420,
	404,
	'longi',
	1,
	153);
INSERT INTO V_TRN
	VALUES (420,
	0,
	'');
INSERT INTO SPR_PEP
	VALUES (424,
	425,
	377);
INSERT INTO SPR_PO
	VALUES (424,
	'registerListener',
	'',
	'Location::registerListener();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (426,
	424);
INSERT INTO ACT_ACT
	VALUES (426,
	'interface operation',
	0,
	427,
	0,
	0,
	'Tracking__LOC::Tracking_Location::registerListener',
	0);
INSERT INTO ACT_BLK
	VALUES (427,
	0,
	0,
	0,
	'Location',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	426,
	0);
INSERT INTO ACT_SMT
	VALUES (428,
	427,
	0,
	1,
	1,
	'Tracking__LOC::Tracking_Location::registerListener line: 1');
INSERT INTO ACT_IOP
	VALUES (428,
	1,
	11,
	1,
	1,
	0,
	30,
	0);
INSERT INTO SPR_PEP
	VALUES (429,
	430,
	377);
INSERT INTO SPR_PO
	VALUES (429,
	'unregisterListener',
	'',
	'Location::unregisterListener();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (431,
	429);
INSERT INTO ACT_ACT
	VALUES (431,
	'interface operation',
	0,
	432,
	0,
	0,
	'Tracking__LOC::Tracking_Location::unregisterListener',
	0);
INSERT INTO ACT_BLK
	VALUES (432,
	0,
	0,
	0,
	'Location',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	431,
	0);
INSERT INTO ACT_SMT
	VALUES (433,
	432,
	0,
	1,
	1,
	'Tracking__LOC::Tracking_Location::unregisterListener line: 1');
INSERT INTO ACT_IOP
	VALUES (433,
	1,
	11,
	1,
	1,
	0,
	34,
	0);
INSERT INTO C_PO
	VALUES (434,
	3,
	'Tracking__HR',
	0,
	0);
INSERT INTO C_IR
	VALUES (435,
	436,
	0,
	434);
INSERT INTO C_P
	VALUES (435,
	'Tracking_HeartRateMonitor',
	'Unnamed Interface',
	'',
	'GPS_Watch::Tracking__HR::Tracking_HeartRateMonitor');
INSERT INTO SPR_PEP
	VALUES (437,
	438,
	435);
INSERT INTO SPR_PO
	VALUES (437,
	'registerListener',
	'',
	' HeartRateMonitor::registerListener();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (439,
	437);
INSERT INTO ACT_ACT
	VALUES (439,
	'interface operation',
	0,
	440,
	0,
	0,
	'Tracking__HR::Tracking_HeartRateMonitor::registerListener',
	0);
INSERT INTO ACT_BLK
	VALUES (440,
	0,
	0,
	0,
	'HeartRateMonitor',
	'',
	'',
	1,
	2,
	1,
	2,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	439,
	0);
INSERT INTO ACT_SMT
	VALUES (441,
	440,
	0,
	1,
	2,
	'Tracking__HR::Tracking_HeartRateMonitor::registerListener line: 1');
INSERT INTO ACT_IOP
	VALUES (441,
	1,
	20,
	1,
	2,
	0,
	76,
	0);
INSERT INTO SPR_PEP
	VALUES (442,
	443,
	435);
INSERT INTO SPR_PO
	VALUES (442,
	'unregisterListener',
	'',
	' HeartRateMonitor::unregisterListener();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (444,
	442);
INSERT INTO ACT_ACT
	VALUES (444,
	'interface operation',
	0,
	445,
	0,
	0,
	'Tracking__HR::Tracking_HeartRateMonitor::unregisterListener',
	0);
INSERT INTO ACT_BLK
	VALUES (445,
	0,
	0,
	0,
	'HeartRateMonitor',
	'',
	'',
	1,
	2,
	1,
	2,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	444,
	0);
INSERT INTO ACT_SMT
	VALUES (446,
	445,
	0,
	1,
	2,
	'Tracking__HR::Tracking_HeartRateMonitor::unregisterListener line: 1');
INSERT INTO ACT_IOP
	VALUES (446,
	1,
	20,
	1,
	2,
	0,
	80,
	0);
INSERT INTO PE_PE
	VALUES (447,
	1,
	2,
	0,
	21);
INSERT INTO CL_IC
	VALUES (447,
	448,
	0,
	0,
	0,
	'',
	'UI::UI::UI',
	'');
INSERT INTO CL_POR
	VALUES (447,
	0,
	'',
	449);
INSERT INTO CL_IIR
	VALUES (450,
	451,
	449,
	0,
	'UI',
	'');
INSERT INTO CL_IP
	VALUES (450,
	'UI',
	'');
INSERT INTO CL_IPINS
	VALUES (452,
	450);
INSERT INTO CL_POR
	VALUES (447,
	453,
	'TRACK',
	454);
INSERT INTO CL_IIR
	VALUES (455,
	456,
	454,
	0,
	'UI_Tracking',
	'');
INSERT INTO CL_IR
	VALUES (455,
	457,
	'UI_Tracking',
	'');
INSERT INTO PE_PE
	VALUES (458,
	1,
	2,
	0,
	21);
INSERT INTO CL_IC
	VALUES (458,
	459,
	0,
	0,
	0,
	'',
	'Tracking::Tracking::Tracking',
	'');
INSERT INTO CL_POR
	VALUES (458,
	460,
	'Tracking',
	461);
INSERT INTO CL_IIR
	VALUES (462,
	463,
	461,
	0,
	'Tracking',
	'');
INSERT INTO CL_IP
	VALUES (462,
	'Tracking',
	'');
INSERT INTO CL_IPINS
	VALUES (464,
	462);
INSERT INTO CL_POR
	VALUES (458,
	465,
	'HR',
	466);
INSERT INTO CL_IIR
	VALUES (467,
	468,
	466,
	0,
	'Tracking_HeartRateMonitor',
	'');
INSERT INTO CL_IR
	VALUES (467,
	469,
	'Tracking_HeartRateMonitor',
	'');
INSERT INTO CL_POR
	VALUES (458,
	470,
	'LOC',
	471);
INSERT INTO CL_IIR
	VALUES (472,
	473,
	471,
	0,
	'Tracking_Location',
	'');
INSERT INTO CL_IR
	VALUES (472,
	474,
	'Tracking_Location',
	'');
INSERT INTO CL_POR
	VALUES (458,
	475,
	'UI',
	476);
INSERT INTO CL_IIR
	VALUES (477,
	478,
	476,
	0,
	'Tracking_UI',
	'');
INSERT INTO CL_IR
	VALUES (477,
	479,
	'Tracking_UI',
	'');
INSERT INTO PE_PE
	VALUES (480,
	1,
	2,
	0,
	21);
INSERT INTO CL_IC
	VALUES (480,
	481,
	0,
	0,
	0,
	'',
	'HeartRateMonitor::HeartRateMonitor::HeartRateMonitor',
	'');
INSERT INTO CL_POR
	VALUES (480,
	0,
	'',
	482);
INSERT INTO CL_IIR
	VALUES (483,
	484,
	482,
	0,
	'HeartRateProvider',
	'');
INSERT INTO CL_IP
	VALUES (483,
	'HeartRateProvider',
	'');
INSERT INTO CL_IPINS
	VALUES (485,
	483);
INSERT INTO CL_POR
	VALUES (480,
	486,
	'HRChange',
	487);
INSERT INTO CL_IIR
	VALUES (488,
	489,
	487,
	0,
	'HRChange',
	'');
INSERT INTO CL_IR
	VALUES (488,
	490,
	'HRChange',
	'');
INSERT INTO PE_PE
	VALUES (491,
	1,
	2,
	0,
	21);
INSERT INTO CL_IC
	VALUES (491,
	492,
	0,
	0,
	0,
	'',
	'Location::Location::Location',
	'');
INSERT INTO CL_POR
	VALUES (491,
	493,
	'LOC',
	494);
INSERT INTO CL_IIR
	VALUES (495,
	496,
	494,
	0,
	'LocationProvider',
	'');
INSERT INTO CL_IP
	VALUES (495,
	'LocationProvider',
	'');
INSERT INTO CL_IPINS
	VALUES (497,
	495);
INSERT INTO PE_PE
	VALUES (464,
	1,
	2,
	0,
	22);
INSERT INTO C_SF
	VALUES (464,
	43,
	463,
	'',
	'Tracking::Tracking::Tracking -o)- GPS_Watch::Tracking::Tracking');
INSERT INTO PE_PE
	VALUES (457,
	1,
	2,
	0,
	22);
INSERT INTO C_SF
	VALUES (457,
	456,
	85,
	'',
	'GPS_Watch::UI__TRACK::UI_Tracking -o)- UI::TRACK::UI_Tracking');
INSERT INTO PE_PE
	VALUES (469,
	1,
	2,
	0,
	22);
INSERT INTO C_SF
	VALUES (469,
	468,
	435,
	'',
	'GPS_Watch::Tracking__HR::Tracking_HeartRateMonitor -o)- Tracking::HR::Tracking_HeartRateMonitor');
INSERT INTO PE_PE
	VALUES (474,
	1,
	2,
	0,
	22);
INSERT INTO C_SF
	VALUES (474,
	473,
	377,
	'',
	'GPS_Watch::Tracking__LOC::Tracking_Location -o)- Tracking::LOC::Tracking_Location');
INSERT INTO PE_PE
	VALUES (479,
	1,
	2,
	0,
	22);
INSERT INTO C_SF
	VALUES (479,
	478,
	206,
	'',
	'GPS_Watch::Tracking__UI::Tracking_UI -o)- Tracking::UI::Tracking_UI');
INSERT INTO PE_PE
	VALUES (490,
	1,
	2,
	0,
	22);
INSERT INTO C_SF
	VALUES (490,
	489,
	196,
	'',
	'GPS_Watch::HeartRateMonitor__HRChange::HRChange -o)- HeartRateMonitor::HRChange::HRChange');
INSERT INTO PE_PE
	VALUES (452,
	1,
	2,
	0,
	22);
INSERT INTO C_SF
	VALUES (452,
	5,
	451,
	'',
	'UI::UI::UI -o)- GPS_Watch::UI::UI');
INSERT INTO PE_PE
	VALUES (497,
	1,
	2,
	0,
	22);
INSERT INTO C_SF
	VALUES (497,
	24,
	496,
	'',
	'Location::LOC::LocationProvider -o)- GPS_Watch::Location::LocationProvider');
INSERT INTO PE_PE
	VALUES (485,
	1,
	2,
	0,
	22);
INSERT INTO C_SF
	VALUES (485,
	74,
	484,
	'',
	'HeartRateMonitor::HeartRateMonitor::HeartRateProvider -o)- GPS_Watch::HeartRateMonitor::HeartRateProvider');
INSERT INTO EP_PKG
	VALUES (498,
	1,
	1,
	'Informal_Diagrams',
	'',
	0);
INSERT INTO PE_PE
	VALUES (499,
	1,
	498,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (499,
	0,
	1,
	'Analysis',
	'',
	0);
INSERT INTO PE_PE
	VALUES (500,
	1,
	499,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (500,
	0,
	1,
	'Start_Stop_Reset',
	'',
	0);
INSERT INTO PE_PE
	VALUES (501,
	1,
	500,
	0,
	14);
INSERT INTO SQ_P
	VALUES (501,
	0);
INSERT INTO SQ_COP
	VALUES (501,
	0,
	'UI',
	'UI',
	'',
	0);
INSERT INTO PE_PE
	VALUES (502,
	1,
	500,
	0,
	14);
INSERT INTO SQ_P
	VALUES (502,
	0);
INSERT INTO SQ_COP
	VALUES (502,
	0,
	'Tracking',
	'Tracking',
	'',
	0);
INSERT INTO PE_PE
	VALUES (503,
	1,
	500,
	0,
	14);
INSERT INTO SQ_P
	VALUES (503,
	0);
INSERT INTO SQ_AP
	VALUES (503,
	'User',
	'',
	0);
INSERT INTO PE_PE
	VALUES (504,
	1,
	500,
	0,
	14);
INSERT INTO SQ_P
	VALUES (504,
	0);
INSERT INTO SQ_COP
	VALUES (504,
	0,
	'Location',
	'Location',
	'',
	0);
INSERT INTO PE_PE
	VALUES (505,
	1,
	500,
	0,
	14);
INSERT INTO SQ_P
	VALUES (505,
	0);
INSERT INTO SQ_COP
	VALUES (505,
	0,
	'HeartRateMonitor',
	'HeartRateMonitor',
	'',
	0);
INSERT INTO PE_PE
	VALUES (506,
	1,
	500,
	0,
	14);
INSERT INTO SQ_P
	VALUES (506,
	0);
INSERT INTO SQ_LS
	VALUES (506,
	503,
	'',
	0);
INSERT INTO PE_PE
	VALUES (507,
	1,
	500,
	0,
	14);
INSERT INTO SQ_P
	VALUES (507,
	0);
INSERT INTO MSG_M
	VALUES (508,
	506,
	507,
	0);
INSERT INTO MSG_SM
	VALUES (508,
	'press_start_stop_button',
	'',
	'',
	'',
	'',
	0,
	'press_start_stop_button',
	'');
INSERT INTO MSG_ISM
	VALUES (508);
INSERT INTO MSG_M
	VALUES (509,
	506,
	507,
	0);
INSERT INTO MSG_SM
	VALUES (509,
	'press_start_stop_button',
	'',
	'',
	'',
	'',
	0,
	'press_start_stop_button',
	'');
INSERT INTO MSG_ISM
	VALUES (509);
INSERT INTO MSG_M
	VALUES (510,
	506,
	507,
	0);
INSERT INTO MSG_SM
	VALUES (510,
	'press_lap_reset_button',
	'',
	'',
	'',
	'',
	0,
	'press_lap_reset_button',
	'');
INSERT INTO MSG_ISM
	VALUES (510);
INSERT INTO SQ_LS
	VALUES (507,
	501,
	'',
	0);
INSERT INTO SQ_TM
	VALUES (511,
	'provide updates to client every <interval> microseconds',
	507,
	'');
INSERT INTO PE_PE
	VALUES (512,
	1,
	500,
	0,
	14);
INSERT INTO SQ_P
	VALUES (512,
	0);
INSERT INTO MSG_M
	VALUES (513,
	507,
	512,
	0);
INSERT INTO MSG_SM
	VALUES (513,
	'startStopPressed',
	'',
	'',
	'',
	'',
	0,
	'startStopPressed',
	'');
INSERT INTO MSG_ISM
	VALUES (513);
INSERT INTO MSG_M
	VALUES (514,
	515,
	512,
	0);
INSERT INTO MSG_SM
	VALUES (514,
	'locationUpdate',
	'',
	'',
	'',
	'',
	0,
	'locationUpdate',
	'');
INSERT INTO MSG_ISM
	VALUES (514);
INSERT INTO MSG_M
	VALUES (516,
	515,
	512,
	0);
INSERT INTO MSG_SM
	VALUES (516,
	'locationUpdate',
	'',
	'',
	'',
	'',
	0,
	'locationUpdate',
	'');
INSERT INTO MSG_ISM
	VALUES (516);
INSERT INTO MSG_M
	VALUES (517,
	515,
	512,
	0);
INSERT INTO MSG_SM
	VALUES (517,
	'locationUpdate',
	'',
	'',
	'',
	'',
	0,
	'locationUpdate',
	'');
INSERT INTO MSG_ISM
	VALUES (517);
INSERT INTO MSG_M
	VALUES (518,
	515,
	512,
	0);
INSERT INTO MSG_SM
	VALUES (518,
	'locationUpdate',
	'',
	'',
	'',
	'',
	0,
	'locationUpdate',
	'');
INSERT INTO MSG_ISM
	VALUES (518);
INSERT INTO MSG_M
	VALUES (519,
	520,
	512,
	0);
INSERT INTO MSG_SM
	VALUES (519,
	'heartRateChanged',
	'',
	'',
	'',
	'',
	0,
	'heartRateChanged',
	'');
INSERT INTO MSG_ISM
	VALUES (519);
INSERT INTO MSG_M
	VALUES (521,
	520,
	512,
	0);
INSERT INTO MSG_SM
	VALUES (521,
	'heartRateChanged',
	'',
	'',
	'',
	'',
	0,
	'heartRateChanged',
	'');
INSERT INTO MSG_ISM
	VALUES (521);
INSERT INTO MSG_M
	VALUES (522,
	507,
	512,
	0);
INSERT INTO MSG_SM
	VALUES (522,
	'startStopPressed',
	'',
	'',
	'',
	'',
	0,
	'startStopPressed',
	'');
INSERT INTO MSG_ISM
	VALUES (522);
INSERT INTO MSG_M
	VALUES (523,
	507,
	512,
	0);
INSERT INTO MSG_SM
	VALUES (523,
	'lapResetPressed',
	'',
	'',
	'',
	'',
	0,
	'lapResetPressed',
	'');
INSERT INTO MSG_ISM
	VALUES (523);
INSERT INTO SQ_LS
	VALUES (512,
	502,
	'',
	0);
INSERT INTO SQ_TM
	VALUES (524,
	'Clear track and reset all cached values',
	512,
	'');
INSERT INTO PE_PE
	VALUES (515,
	1,
	500,
	0,
	14);
INSERT INTO SQ_P
	VALUES (515,
	0);
INSERT INTO MSG_M
	VALUES (525,
	512,
	515,
	0);
INSERT INTO MSG_SM
	VALUES (525,
	'registerListener',
	'',
	'',
	'',
	'',
	0,
	'registerListener',
	'');
INSERT INTO MSG_ISM
	VALUES (525);
INSERT INTO MSG_A
	VALUES (526,
	525,
	0,
	'interval',
	'',
	'interval',
	'',
	0);
INSERT INTO MSG_IA
	VALUES (526);
INSERT INTO MSG_M
	VALUES (527,
	512,
	515,
	0);
INSERT INTO MSG_SM
	VALUES (527,
	'unregisterListener',
	'',
	'',
	'',
	'',
	0,
	'unregisterListener',
	'');
INSERT INTO MSG_ISM
	VALUES (527);
INSERT INTO SQ_LS
	VALUES (515,
	504,
	'',
	0);
INSERT INTO SQ_TM
	VALUES (528,
	'',
	515,
	'');
INSERT INTO SQ_TS
	VALUES (529,
	530,
	528,
	'provide updates to client every 2 seconds',
	'');
INSERT INTO SQ_TM
	VALUES (530,
	'',
	515,
	'');
INSERT INTO PE_PE
	VALUES (520,
	1,
	500,
	0,
	14);
INSERT INTO SQ_P
	VALUES (520,
	0);
INSERT INTO MSG_M
	VALUES (531,
	512,
	520,
	0);
INSERT INTO MSG_SM
	VALUES (531,
	'registerListener',
	'',
	'',
	'',
	'',
	0,
	'registerListener',
	'');
INSERT INTO MSG_ISM
	VALUES (531);
INSERT INTO MSG_M
	VALUES (532,
	512,
	520,
	0);
INSERT INTO MSG_SM
	VALUES (532,
	'unregisterListener',
	'',
	'',
	'',
	'',
	0,
	'unregisterListener',
	'');
INSERT INTO MSG_ISM
	VALUES (532);
INSERT INTO SQ_LS
	VALUES (520,
	505,
	'',
	0);
INSERT INTO SQ_TM
	VALUES (533,
	'',
	520,
	'');
INSERT INTO SQ_TS
	VALUES (534,
	535,
	533,
	'provide updates to client every 3 seconds',
	'');
INSERT INTO SQ_TM
	VALUES (535,
	'',
	520,
	'');
INSERT INTO PE_PE
	VALUES (508,
	1,
	500,
	0,
	17);
INSERT INTO PE_PE
	VALUES (509,
	1,
	500,
	0,
	17);
INSERT INTO PE_PE
	VALUES (510,
	1,
	500,
	0,
	17);
INSERT INTO PE_PE
	VALUES (513,
	1,
	500,
	0,
	17);
INSERT INTO PE_PE
	VALUES (514,
	1,
	500,
	0,
	17);
INSERT INTO PE_PE
	VALUES (516,
	1,
	500,
	0,
	17);
INSERT INTO PE_PE
	VALUES (517,
	1,
	500,
	0,
	17);
INSERT INTO PE_PE
	VALUES (518,
	1,
	500,
	0,
	17);
INSERT INTO PE_PE
	VALUES (519,
	1,
	500,
	0,
	17);
INSERT INTO PE_PE
	VALUES (521,
	1,
	500,
	0,
	17);
INSERT INTO PE_PE
	VALUES (522,
	1,
	500,
	0,
	17);
INSERT INTO PE_PE
	VALUES (523,
	1,
	500,
	0,
	17);
INSERT INTO PE_PE
	VALUES (525,
	1,
	500,
	0,
	17);
INSERT INTO PE_PE
	VALUES (527,
	1,
	500,
	0,
	17);
INSERT INTO PE_PE
	VALUES (531,
	1,
	500,
	0,
	17);
INSERT INTO PE_PE
	VALUES (532,
	1,
	500,
	0,
	17);
INSERT INTO PE_PE
	VALUES (536,
	1,
	498,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (536,
	0,
	1,
	'RequirementsClarification',
	'',
	0);
INSERT INTO PE_PE
	VALUES (537,
	1,
	536,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (537,
	0,
	1,
	'UC01 - SimpleWorkout',
	'',
	0);
INSERT INTO PE_PE
	VALUES (538,
	1,
	537,
	0,
	14);
INSERT INTO SQ_P
	VALUES (538,
	0);
INSERT INTO IA_UCP
	VALUES (538,
	'UC01-SimpleWorkout',
	'Pre-conditions
	No track logs exist on the device.
	Timer is stopped.
	Elapsed time is zero.
	Accumulated distance is zero.
	Display shows elapsed time and accumulated distance.

Post-conditions
	A track log exists on the device.
	Timer is stopped.
	Elapsed time and distance are displayed.
	

Scenario
	1.	User pushes the start/stop button and begins moving (walking, running, flying, cycling, etc.).
	2.	The timer starts.
	3.	Throughout the workout, the display shows:
		a.	Accumulated distance
		b.	Elapsed time
	4.	Periodically throughout the workout the device stores, in the active track log, 
	    the current location of the device.
	5.	User pushes the start/stop button.
	6.	The elapsed time and distance stop accumulating.
	');
INSERT INTO PE_PE
	VALUES (539,
	1,
	537,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (539,
	0,
	1,
	'Sequence Diagram',
	'',
	0);
INSERT INTO PE_PE
	VALUES (540,
	1,
	539,
	0,
	14);
INSERT INTO SQ_P
	VALUES (540,
	0);
INSERT INTO SQ_AP
	VALUES (540,
	'User',
	'',
	0);
INSERT INTO PE_PE
	VALUES (541,
	1,
	539,
	0,
	14);
INSERT INTO SQ_P
	VALUES (541,
	0);
INSERT INTO SQ_COP
	VALUES (541,
	0,
	'Watch Application',
	'Watch Application',
	'',
	0);
INSERT INTO PE_PE
	VALUES (542,
	1,
	539,
	0,
	14);
INSERT INTO SQ_P
	VALUES (542,
	0);
INSERT INTO SQ_COP
	VALUES (542,
	0,
	'GPS Chipset',
	'GPS Chipset',
	'',
	0);
INSERT INTO PE_PE
	VALUES (543,
	1,
	539,
	0,
	14);
INSERT INTO SQ_P
	VALUES (543,
	0);
INSERT INTO MSG_M
	VALUES (544,
	545,
	543,
	0);
INSERT INTO MSG_AM
	VALUES (544,
	'Start/Stop Button Pressed',
	'',
	'',
	'',
	'',
	0,
	'Start/Stop Button Pressed',
	'1');
INSERT INTO MSG_IAM
	VALUES (544);
INSERT INTO MSG_M
	VALUES (546,
	545,
	543,
	0);
INSERT INTO MSG_AM
	VALUES (546,
	'Start/Stop Button Pressed',
	'',
	'',
	'',
	'',
	0,
	'Start/Stop Button Pressed',
	'10');
INSERT INTO MSG_IAM
	VALUES (546);
INSERT INTO MSG_M
	VALUES (547,
	548,
	543,
	0);
INSERT INTO MSG_AM
	VALUES (547,
	'Location Update',
	'',
	'',
	'',
	'',
	0,
	'Location Update',
	'5');
INSERT INTO MSG_IAM
	VALUES (547);
INSERT INTO MSG_M
	VALUES (549,
	548,
	543,
	0);
INSERT INTO MSG_AM
	VALUES (549,
	'Location Update',
	'',
	'',
	'',
	'',
	0,
	'Location Update',
	'8');
INSERT INTO MSG_IAM
	VALUES (549);
INSERT INTO SQ_LS
	VALUES (543,
	541,
	'',
	0);
INSERT INTO SQ_TM
	VALUES (550,
	'',
	543,
	'');
INSERT INTO SQ_TS
	VALUES (551,
	552,
	550,
	'Location Update Interval',
	'');
INSERT INTO SQ_TM
	VALUES (552,
	'',
	543,
	'');
INSERT INTO PE_PE
	VALUES (548,
	1,
	539,
	0,
	14);
INSERT INTO SQ_P
	VALUES (548,
	0);
INSERT INTO MSG_M
	VALUES (553,
	0,
	548,
	0);
INSERT INTO MSG_AM
	VALUES (553,
	'Start Sending Locations',
	'',
	'',
	'',
	'',
	0,
	'Start Sending Locations',
	'3');
INSERT INTO MSG_IAM
	VALUES (553);
INSERT INTO MSG_M
	VALUES (554,
	543,
	548,
	0);
INSERT INTO MSG_AM
	VALUES (554,
	'Stop Sending Locations',
	'',
	'',
	'',
	'',
	0,
	'Stop Sending Locations',
	'12');
INSERT INTO MSG_IAM
	VALUES (554);
INSERT INTO SQ_LS
	VALUES (548,
	542,
	'',
	0);
INSERT INTO PE_PE
	VALUES (545,
	1,
	539,
	0,
	14);
INSERT INTO SQ_P
	VALUES (545,
	0);
INSERT INTO SQ_LS
	VALUES (545,
	540,
	'',
	0);
INSERT INTO PE_PE
	VALUES (555,
	1,
	539,
	0,
	14);
INSERT INTO SQ_P
	VALUES (555,
	0);
INSERT INTO SQ_COP
	VALUES (555,
	0,
	'User Interface',
	'User Interface',
	'',
	0);
INSERT INTO PE_PE
	VALUES (556,
	1,
	539,
	0,
	14);
INSERT INTO SQ_P
	VALUES (556,
	0);
INSERT INTO MSG_M
	VALUES (557,
	543,
	556,
	0);
INSERT INTO MSG_AM
	VALUES (557,
	'Display Distance and Elapsed Time',
	'',
	'',
	'',
	'',
	0,
	'Display Distance and Elapsed Time',
	'2');
INSERT INTO MSG_IAM
	VALUES (557);
INSERT INTO MSG_M
	VALUES (558,
	543,
	556,
	0);
INSERT INTO MSG_AM
	VALUES (558,
	'Display Distance and Elapsed Time',
	'',
	'',
	'',
	'',
	0,
	'Display Distance and Elapsed Time',
	'7');
INSERT INTO MSG_IAM
	VALUES (558);
INSERT INTO MSG_M
	VALUES (559,
	543,
	556,
	0);
INSERT INTO MSG_AM
	VALUES (559,
	'Display Distance and Elapsed Time',
	'',
	'',
	'',
	'',
	0,
	'Display Distance and Elapsed Time',
	'11');
INSERT INTO MSG_IAM
	VALUES (559);
INSERT INTO SQ_LS
	VALUES (556,
	555,
	'',
	0);
INSERT INTO PE_PE
	VALUES (560,
	1,
	539,
	0,
	14);
INSERT INTO SQ_P
	VALUES (560,
	0);
INSERT INTO SQ_CP
	VALUES (560,
	0,
	'TrackLog',
	'TrackLog',
	'',
	0);
INSERT INTO MSG_M
	VALUES (561,
	543,
	560,
	0);
INSERT INTO MSG_AM
	VALUES (561,
	'Create Track Log',
	'',
	'',
	'',
	'',
	0,
	'Create Track Log',
	'4');
INSERT INTO MSG_IAM
	VALUES (561);
INSERT INTO PE_PE
	VALUES (562,
	1,
	539,
	0,
	14);
INSERT INTO SQ_P
	VALUES (562,
	0);
INSERT INTO SQ_CP
	VALUES (562,
	0,
	'Track Point',
	'Track Point',
	'',
	0);
INSERT INTO MSG_M
	VALUES (563,
	543,
	562,
	0);
INSERT INTO MSG_AM
	VALUES (563,
	'Create Track Point',
	'',
	'',
	'',
	'',
	0,
	'Create Track Point',
	'6');
INSERT INTO MSG_IAM
	VALUES (563);
INSERT INTO PE_PE
	VALUES (564,
	1,
	539,
	0,
	14);
INSERT INTO SQ_P
	VALUES (564,
	0);
INSERT INTO SQ_CP
	VALUES (564,
	0,
	'Track Point',
	'Track Point',
	'',
	0);
INSERT INTO MSG_M
	VALUES (565,
	543,
	564,
	0);
INSERT INTO MSG_AM
	VALUES (565,
	'Create Track Point',
	'',
	'',
	'',
	'',
	0,
	'Create Track Point',
	'9');
INSERT INTO MSG_IAM
	VALUES (565);
INSERT INTO PE_PE
	VALUES (544,
	1,
	539,
	0,
	17);
INSERT INTO PE_PE
	VALUES (557,
	1,
	539,
	0,
	17);
INSERT INTO PE_PE
	VALUES (561,
	1,
	539,
	0,
	17);
INSERT INTO PE_PE
	VALUES (563,
	1,
	539,
	0,
	17);
INSERT INTO PE_PE
	VALUES (558,
	1,
	539,
	0,
	17);
INSERT INTO PE_PE
	VALUES (565,
	1,
	539,
	0,
	17);
INSERT INTO PE_PE
	VALUES (546,
	1,
	539,
	0,
	17);
INSERT INTO PE_PE
	VALUES (553,
	1,
	539,
	0,
	17);
INSERT INTO PE_PE
	VALUES (547,
	1,
	539,
	0,
	17);
INSERT INTO PE_PE
	VALUES (549,
	1,
	539,
	0,
	17);
INSERT INTO PE_PE
	VALUES (559,
	1,
	539,
	0,
	17);
INSERT INTO PE_PE
	VALUES (554,
	1,
	539,
	0,
	17);
INSERT INTO PE_PE
	VALUES (566,
	1,
	537,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (566,
	0,
	1,
	'ActivityDiagram',
	'',
	0);
INSERT INTO PE_PE
	VALUES (567,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (567,
	0);
INSERT INTO A_OBJ
	VALUES (567,
	'User',
	'');
INSERT INTO PE_PE
	VALUES (568,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (568,
	0);
INSERT INTO A_OBJ
	VALUES (568,
	'Application',
	'');
INSERT INTO PE_PE
	VALUES (569,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (569,
	0);
INSERT INTO A_OBJ
	VALUES (569,
	'GPS Chipset',
	'');
INSERT INTO PE_PE
	VALUES (570,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (570,
	0);
INSERT INTO A_ACT
	VALUES (570);
INSERT INTO A_AE
	VALUES (570);
INSERT INTO A_AEA
	VALUES (570,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (571,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (571,
	0);
INSERT INTO A_ACT
	VALUES (571);
INSERT INTO A_SS
	VALUES (571,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (572,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (572,
	0);
INSERT INTO A_ACT
	VALUES (572);
INSERT INTO A_GA
	VALUES (572,
	'Start Stopwatch',
	'');
INSERT INTO PE_PE
	VALUES (573,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (573,
	0);
INSERT INTO A_ACT
	VALUES (573);
INSERT INTO A_GA
	VALUES (573,
	'Start Tracking Location',
	'');
INSERT INTO PE_PE
	VALUES (574,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (574,
	0);
INSERT INTO A_CTL
	VALUES (574);
INSERT INTO A_FJ
	VALUES (574,
	'',
	'');
INSERT INTO PE_PE
	VALUES (575,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (575,
	0);
INSERT INTO A_ACT
	VALUES (575);
INSERT INTO A_GA
	VALUES (575,
	'Periodically Update Display',
	'In this case the display shows elapsed time and accumulated distance.');
INSERT INTO PE_PE
	VALUES (576,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (576,
	0);
INSERT INTO A_CTL
	VALUES (576);
INSERT INTO A_FJ
	VALUES (576,
	'',
	'');
INSERT INTO PE_PE
	VALUES (577,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (577,
	0);
INSERT INTO A_ACT
	VALUES (577);
INSERT INTO A_SS
	VALUES (577,
	'Start Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (578,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (578,
	0);
INSERT INTO A_ACT
	VALUES (578);
INSERT INTO A_AE
	VALUES (578);
INSERT INTO A_AEA
	VALUES (578,
	'Start Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (579,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (579,
	0);
INSERT INTO A_ACT
	VALUES (579);
INSERT INTO A_SS
	VALUES (579,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (580,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (580,
	0);
INSERT INTO A_ACT
	VALUES (580);
INSERT INTO A_AE
	VALUES (580);
INSERT INTO A_AEA
	VALUES (580,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (581,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (581,
	0);
INSERT INTO A_CTL
	VALUES (581);
INSERT INTO A_FJ
	VALUES (581,
	'',
	'');
INSERT INTO PE_PE
	VALUES (582,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (582,
	0);
INSERT INTO A_ACT
	VALUES (582);
INSERT INTO A_GA
	VALUES (582,
	'Stop Stopwatch',
	'');
INSERT INTO PE_PE
	VALUES (583,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (583,
	0);
INSERT INTO A_ACT
	VALUES (583);
INSERT INTO A_GA
	VALUES (583,
	'Stop Tracking Location',
	'');
INSERT INTO PE_PE
	VALUES (584,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (584,
	0);
INSERT INTO A_ACT
	VALUES (584);
INSERT INTO A_SS
	VALUES (584,
	'Stop Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (585,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (585,
	0);
INSERT INTO A_ACT
	VALUES (585);
INSERT INTO A_GA
	VALUES (585,
	'Periodically Supply Location',
	'');
INSERT INTO PE_PE
	VALUES (586,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (586,
	0);
INSERT INTO A_ACT
	VALUES (586);
INSERT INTO A_SS
	VALUES (586,
	'Location',
	'');
INSERT INTO PE_PE
	VALUES (587,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (587,
	0);
INSERT INTO A_ACT
	VALUES (587);
INSERT INTO A_AE
	VALUES (587);
INSERT INTO A_AEA
	VALUES (587,
	'Location',
	'');
INSERT INTO PE_PE
	VALUES (588,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (588,
	0);
INSERT INTO A_ACT
	VALUES (588);
INSERT INTO A_GA
	VALUES (588,
	'Calculate Accumulated Distance',
	'');
INSERT INTO PE_PE
	VALUES (589,
	1,
	566,
	0,
	18);
INSERT INTO A_N
	VALUES (589,
	0);
INSERT INTO A_ACT
	VALUES (589);
INSERT INTO A_AE
	VALUES (589);
INSERT INTO A_AEA
	VALUES (589,
	'Stop Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (590,
	1,
	566,
	0,
	11);
INSERT INTO A_AP
	VALUES (590,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (591,
	1,
	566,
	0,
	11);
INSERT INTO A_AP
	VALUES (591,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (592,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (592,
	0,
	'',
	'',
	570,
	571);
INSERT INTO PE_PE
	VALUES (593,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (593,
	0,
	'',
	'',
	574,
	570);
INSERT INTO PE_PE
	VALUES (594,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (594,
	0,
	'',
	'',
	576,
	573);
INSERT INTO PE_PE
	VALUES (595,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (595,
	0,
	'',
	'',
	576,
	572);
INSERT INTO PE_PE
	VALUES (596,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (596,
	0,
	'',
	'',
	575,
	576);
INSERT INTO PE_PE
	VALUES (597,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (597,
	0,
	'',
	'',
	578,
	577);
INSERT INTO PE_PE
	VALUES (598,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (598,
	0,
	'',
	'',
	572,
	574);
INSERT INTO PE_PE
	VALUES (599,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (599,
	0,
	'',
	'',
	573,
	574);
INSERT INTO PE_PE
	VALUES (600,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (600,
	0,
	'',
	'',
	577,
	574);
INSERT INTO PE_PE
	VALUES (601,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (601,
	0,
	'',
	'',
	580,
	579);
INSERT INTO PE_PE
	VALUES (602,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (602,
	0,
	'',
	'',
	582,
	581);
INSERT INTO PE_PE
	VALUES (603,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (603,
	0,
	'',
	'',
	583,
	581);
INSERT INTO PE_PE
	VALUES (604,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (604,
	0,
	'',
	'',
	584,
	581);
INSERT INTO PE_PE
	VALUES (605,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (605,
	0,
	'',
	'',
	585,
	578);
INSERT INTO PE_PE
	VALUES (606,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (606,
	0,
	'',
	'',
	587,
	586);
INSERT INTO PE_PE
	VALUES (607,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (607,
	0,
	'',
	'',
	586,
	585);
INSERT INTO PE_PE
	VALUES (608,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (608,
	0,
	'',
	'',
	588,
	587);
INSERT INTO PE_PE
	VALUES (609,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (609,
	0,
	'',
	'',
	589,
	584);
INSERT INTO PE_PE
	VALUES (610,
	1,
	566,
	0,
	12);
INSERT INTO A_E
	VALUES (610,
	0,
	'',
	'',
	581,
	580);
INSERT INTO PE_PE
	VALUES (611,
	1,
	536,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (611,
	0,
	1,
	'UC02 - ClearLogs',
	'',
	0);
INSERT INTO PE_PE
	VALUES (612,
	1,
	611,
	0,
	14);
INSERT INTO SQ_P
	VALUES (612,
	0);
INSERT INTO IA_UCP
	VALUES (612,
	'UC02 - ClearLogs',
	'Pre-conditions
	Track logs exist on the device.
	Heart Rate logs exist on the device.
	Timer is stopped.
	Display shows elapsed time and accumulated distance.

Post-conditions
	No track logs exist on the device.
	No heart rate logs exist on the device.
	No goals exist on the device.
	Timer is stopped.
	Elapsed time is zero.
	Accumulated distance is zero.
	Display shows elapsed time and accumulated distance.	

Scenario
	1.	User pushes the lap/reset button while the timer is stopped.
	2. 	Track logs are removed.
	3.  Heart rate logs are removed.
	4.  Goals are removed.
	5.	Timer is reset, making elapsed time zero.
	6.	Accumulated distance is reset to zero. 
	
');
INSERT INTO PE_PE
	VALUES (613,
	1,
	611,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (613,
	0,
	1,
	'ActivityDiagram',
	'',
	0);
INSERT INTO PE_PE
	VALUES (614,
	1,
	613,
	0,
	18);
INSERT INTO A_N
	VALUES (614,
	0);
INSERT INTO A_OBJ
	VALUES (614,
	'User',
	'');
INSERT INTO PE_PE
	VALUES (615,
	1,
	613,
	0,
	18);
INSERT INTO A_N
	VALUES (615,
	0);
INSERT INTO A_OBJ
	VALUES (615,
	'Application',
	'');
INSERT INTO PE_PE
	VALUES (616,
	1,
	613,
	0,
	18);
INSERT INTO A_N
	VALUES (616,
	0);
INSERT INTO A_OBJ
	VALUES (616,
	'GPS Chipset',
	'');
INSERT INTO PE_PE
	VALUES (617,
	1,
	613,
	0,
	18);
INSERT INTO A_N
	VALUES (617,
	0);
INSERT INTO A_ACT
	VALUES (617);
INSERT INTO A_AE
	VALUES (617);
INSERT INTO A_AEA
	VALUES (617,
	'Lap/Reset Pushed',
	'');
INSERT INTO PE_PE
	VALUES (618,
	1,
	613,
	0,
	18);
INSERT INTO A_N
	VALUES (618,
	0);
INSERT INTO A_ACT
	VALUES (618);
INSERT INTO A_SS
	VALUES (618,
	'Lap/Reset Pushed',
	'');
INSERT INTO PE_PE
	VALUES (619,
	1,
	613,
	0,
	18);
INSERT INTO A_N
	VALUES (619,
	0);
INSERT INTO A_ACT
	VALUES (619);
INSERT INTO A_GA
	VALUES (619,
	'Reset elapsed time',
	'');
INSERT INTO PE_PE
	VALUES (620,
	1,
	613,
	0,
	18);
INSERT INTO A_N
	VALUES (620,
	0);
INSERT INTO A_ACT
	VALUES (620);
INSERT INTO A_GA
	VALUES (620,
	'Delete Stored Locations',
	'"Stored locations" is an example of multiple terms used to describe a track point. 
Other synonyms for track point that may be used in the model are  
	Stored location data
	GPS data
	Satellite data
');
INSERT INTO PE_PE
	VALUES (621,
	1,
	613,
	0,
	18);
INSERT INTO A_N
	VALUES (621,
	0);
INSERT INTO A_CTL
	VALUES (621);
INSERT INTO A_FJ
	VALUES (621,
	'',
	'');
INSERT INTO PE_PE
	VALUES (622,
	1,
	613,
	0,
	18);
INSERT INTO A_N
	VALUES (622,
	0);
INSERT INTO A_ACT
	VALUES (622);
INSERT INTO A_GA
	VALUES (622,
	'Periodically Update Display',
	'In this case the display shows elapsed time and accumulated distance.');
INSERT INTO PE_PE
	VALUES (623,
	1,
	613,
	0,
	18);
INSERT INTO A_N
	VALUES (623,
	0);
INSERT INTO A_CTL
	VALUES (623);
INSERT INTO A_FJ
	VALUES (623,
	'',
	'');
INSERT INTO PE_PE
	VALUES (624,
	1,
	613,
	0,
	18);
INSERT INTO A_N
	VALUES (624,
	0);
INSERT INTO A_ACT
	VALUES (624);
INSERT INTO A_SS
	VALUES (624,
	'Stop Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (625,
	1,
	613,
	0,
	18);
INSERT INTO A_N
	VALUES (625,
	0);
INSERT INTO A_ACT
	VALUES (625);
INSERT INTO A_AE
	VALUES (625);
INSERT INTO A_AEA
	VALUES (625,
	'Stop Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (626,
	1,
	613,
	0,
	18);
INSERT INTO A_N
	VALUES (626,
	0);
INSERT INTO A_ACT
	VALUES (626);
INSERT INTO A_SS
	VALUES (626,
	'Stop Sending Heart Rate',
	'');
INSERT INTO PE_PE
	VALUES (627,
	1,
	613,
	0,
	18);
INSERT INTO A_N
	VALUES (627,
	0);
INSERT INTO A_ACT
	VALUES (627);
INSERT INTO A_AE
	VALUES (627);
INSERT INTO A_AEA
	VALUES (627,
	'Stop Sending Heart Rate',
	'');
INSERT INTO PE_PE
	VALUES (628,
	1,
	613,
	0,
	18);
INSERT INTO A_N
	VALUES (628,
	0);
INSERT INTO A_OBJ
	VALUES (628,
	'Heart Rate Chipset',
	'');
INSERT INTO PE_PE
	VALUES (629,
	1,
	613,
	0,
	18);
INSERT INTO A_N
	VALUES (629,
	0);
INSERT INTO A_ACT
	VALUES (629);
INSERT INTO A_GA
	VALUES (629,
	'Delete Heart Rate Logs',
	'');
INSERT INTO PE_PE
	VALUES (630,
	1,
	613,
	0,
	11);
INSERT INTO A_AP
	VALUES (630,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (631,
	1,
	613,
	0,
	11);
INSERT INTO A_AP
	VALUES (631,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (632,
	1,
	613,
	0,
	11);
INSERT INTO A_AP
	VALUES (632,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (633,
	1,
	613,
	0,
	12);
INSERT INTO A_E
	VALUES (633,
	0,
	'',
	'',
	617,
	618);
INSERT INTO PE_PE
	VALUES (634,
	1,
	613,
	0,
	12);
INSERT INTO A_E
	VALUES (634,
	0,
	'',
	'',
	621,
	617);
INSERT INTO PE_PE
	VALUES (635,
	1,
	613,
	0,
	12);
INSERT INTO A_E
	VALUES (635,
	0,
	'',
	'',
	623,
	620);
INSERT INTO PE_PE
	VALUES (636,
	1,
	613,
	0,
	12);
INSERT INTO A_E
	VALUES (636,
	0,
	'',
	'',
	623,
	619);
INSERT INTO PE_PE
	VALUES (637,
	1,
	613,
	0,
	12);
INSERT INTO A_E
	VALUES (637,
	0,
	'',
	'',
	622,
	623);
INSERT INTO PE_PE
	VALUES (638,
	1,
	613,
	0,
	12);
INSERT INTO A_E
	VALUES (638,
	0,
	'',
	'',
	619,
	621);
INSERT INTO PE_PE
	VALUES (639,
	1,
	613,
	0,
	12);
INSERT INTO A_E
	VALUES (639,
	0,
	'',
	'',
	620,
	621);
INSERT INTO PE_PE
	VALUES (640,
	1,
	613,
	0,
	12);
INSERT INTO A_E
	VALUES (640,
	0,
	'',
	'',
	625,
	624);
INSERT INTO PE_PE
	VALUES (641,
	1,
	613,
	0,
	12);
INSERT INTO A_E
	VALUES (641,
	0,
	'',
	'',
	624,
	621);
INSERT INTO PE_PE
	VALUES (642,
	1,
	613,
	0,
	12);
INSERT INTO A_E
	VALUES (642,
	0,
	'',
	'',
	627,
	626);
INSERT INTO PE_PE
	VALUES (643,
	1,
	613,
	0,
	12);
INSERT INTO A_E
	VALUES (643,
	0,
	'',
	'',
	626,
	621);
INSERT INTO PE_PE
	VALUES (644,
	1,
	613,
	0,
	12);
INSERT INTO A_E
	VALUES (644,
	0,
	'',
	'',
	629,
	621);
INSERT INTO PE_PE
	VALUES (645,
	1,
	613,
	0,
	12);
INSERT INTO A_E
	VALUES (645,
	0,
	'',
	'',
	623,
	629);
INSERT INTO PE_PE
	VALUES (646,
	1,
	536,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (646,
	0,
	1,
	'UC03 - MultiLapWorkout',
	'',
	0);
INSERT INTO PE_PE
	VALUES (647,
	1,
	646,
	0,
	14);
INSERT INTO SQ_P
	VALUES (647,
	0);
INSERT INTO IA_UCP
	VALUES (647,
	'UC03 - MultiLapWorkout',
	'Pre-conditions
	No track logs exist on the device.
	Timer is stopped.
	Elapsed time is zero.
	Accumulated distance is zero.
	Display shows elapsed time and accumulated distance.

Post-conditions
	A track log exists on the device.
	A lap marker exists on the device.
	Timer is stopped.
	Display shows lap count of one.
	
Scenario
	1.	User pushes the start/stop button and begins moving (walking, running, flying, cycling, etc.).
	2.	The timer starts.
	3.	The display shows:
		a.	Accumulated distance
		b.	Elapsed time
	4.	Periodically throughout the workout the device stores, in the active track log, 
	    the current location of the device.
	5.  User pushes mode button
	6.	Display shows lap count is zero.
	5.  User pushes Lap button
	6	A lap marker indicating the current location and time, is stored.
	7.	Display shows lap count is one.
	7.  User pushes the start/stop button.
	8.	The elapsed time and distance stop accumulating.
	9.	Display shows lap count is one.
	
	');
INSERT INTO PE_PE
	VALUES (648,
	1,
	646,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (648,
	0,
	1,
	'ActivityDiagram',
	'',
	0);
INSERT INTO PE_PE
	VALUES (649,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (649,
	0);
INSERT INTO A_OBJ
	VALUES (649,
	'User',
	'');
INSERT INTO PE_PE
	VALUES (650,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (650,
	0);
INSERT INTO A_OBJ
	VALUES (650,
	'Application',
	'');
INSERT INTO PE_PE
	VALUES (651,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (651,
	0);
INSERT INTO A_OBJ
	VALUES (651,
	'GPS Chipset',
	'');
INSERT INTO PE_PE
	VALUES (652,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (652,
	0);
INSERT INTO A_ACT
	VALUES (652);
INSERT INTO A_AE
	VALUES (652);
INSERT INTO A_AEA
	VALUES (652,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (653,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (653,
	0);
INSERT INTO A_ACT
	VALUES (653);
INSERT INTO A_SS
	VALUES (653,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (654,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (654,
	0);
INSERT INTO A_ACT
	VALUES (654);
INSERT INTO A_GA
	VALUES (654,
	'Start Stopwatch',
	'');
INSERT INTO PE_PE
	VALUES (655,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (655,
	0);
INSERT INTO A_ACT
	VALUES (655);
INSERT INTO A_GA
	VALUES (655,
	'Start Tracking Location',
	'');
INSERT INTO PE_PE
	VALUES (656,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (656,
	0);
INSERT INTO A_CTL
	VALUES (656);
INSERT INTO A_FJ
	VALUES (656,
	'',
	'');
INSERT INTO PE_PE
	VALUES (657,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (657,
	0);
INSERT INTO A_ACT
	VALUES (657);
INSERT INTO A_GA
	VALUES (657,
	'Periodically Update Display',
	'In this case the display shows elapsed time and accumulated distance.');
INSERT INTO PE_PE
	VALUES (658,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (658,
	0);
INSERT INTO A_CTL
	VALUES (658);
INSERT INTO A_FJ
	VALUES (658,
	'',
	'');
INSERT INTO PE_PE
	VALUES (659,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (659,
	0);
INSERT INTO A_ACT
	VALUES (659);
INSERT INTO A_SS
	VALUES (659,
	'Start Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (660,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (660,
	0);
INSERT INTO A_ACT
	VALUES (660);
INSERT INTO A_AE
	VALUES (660);
INSERT INTO A_AEA
	VALUES (660,
	'Start Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (661,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (661,
	0);
INSERT INTO A_ACT
	VALUES (661);
INSERT INTO A_SS
	VALUES (661,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (662,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (662,
	0);
INSERT INTO A_ACT
	VALUES (662);
INSERT INTO A_AE
	VALUES (662);
INSERT INTO A_AEA
	VALUES (662,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (663,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (663,
	0);
INSERT INTO A_CTL
	VALUES (663);
INSERT INTO A_FJ
	VALUES (663,
	'',
	'');
INSERT INTO PE_PE
	VALUES (664,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (664,
	0);
INSERT INTO A_ACT
	VALUES (664);
INSERT INTO A_GA
	VALUES (664,
	'Stop Stopwatch',
	'');
INSERT INTO PE_PE
	VALUES (665,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (665,
	0);
INSERT INTO A_ACT
	VALUES (665);
INSERT INTO A_GA
	VALUES (665,
	'Stop Tracking Location',
	'');
INSERT INTO PE_PE
	VALUES (666,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (666,
	0);
INSERT INTO A_ACT
	VALUES (666);
INSERT INTO A_SS
	VALUES (666,
	'Stop Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (667,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (667,
	0);
INSERT INTO A_ACT
	VALUES (667);
INSERT INTO A_GA
	VALUES (667,
	'Periodically Supply Location',
	'');
INSERT INTO PE_PE
	VALUES (668,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (668,
	0);
INSERT INTO A_ACT
	VALUES (668);
INSERT INTO A_SS
	VALUES (668,
	'Location',
	'');
INSERT INTO PE_PE
	VALUES (669,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (669,
	0);
INSERT INTO A_ACT
	VALUES (669);
INSERT INTO A_AE
	VALUES (669);
INSERT INTO A_AEA
	VALUES (669,
	'Location',
	'');
INSERT INTO PE_PE
	VALUES (670,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (670,
	0);
INSERT INTO A_ACT
	VALUES (670);
INSERT INTO A_GA
	VALUES (670,
	'Calculate Accumulated Distance',
	'');
INSERT INTO PE_PE
	VALUES (671,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (671,
	0);
INSERT INTO A_ACT
	VALUES (671);
INSERT INTO A_AE
	VALUES (671);
INSERT INTO A_AEA
	VALUES (671,
	'Stop Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (672,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (672,
	0);
INSERT INTO A_ACT
	VALUES (672);
INSERT INTO A_SS
	VALUES (672,
	'Lap/Reset  Pushed',
	'');
INSERT INTO PE_PE
	VALUES (673,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (673,
	0);
INSERT INTO A_ACT
	VALUES (673);
INSERT INTO A_AE
	VALUES (673);
INSERT INTO A_AEA
	VALUES (673,
	'Lap/Reset Pushed',
	'');
INSERT INTO PE_PE
	VALUES (674,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (674,
	0);
INSERT INTO A_ACT
	VALUES (674);
INSERT INTO A_GA
	VALUES (674,
	'Store Lap data',
	'');
INSERT INTO PE_PE
	VALUES (675,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (675,
	0);
INSERT INTO A_ACT
	VALUES (675);
INSERT INTO A_SS
	VALUES (675,
	'Mode  Pushed',
	'');
INSERT INTO PE_PE
	VALUES (676,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (676,
	0);
INSERT INTO A_ACT
	VALUES (676);
INSERT INTO A_AE
	VALUES (676);
INSERT INTO A_AEA
	VALUES (676,
	'Mode Pushed',
	'');
INSERT INTO PE_PE
	VALUES (677,
	1,
	648,
	0,
	18);
INSERT INTO A_N
	VALUES (677,
	0);
INSERT INTO A_ACT
	VALUES (677);
INSERT INTO A_GA
	VALUES (677,
	'Display Lap Count',
	'');
INSERT INTO PE_PE
	VALUES (678,
	1,
	648,
	0,
	11);
INSERT INTO A_AP
	VALUES (678,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (679,
	1,
	648,
	0,
	11);
INSERT INTO A_AP
	VALUES (679,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (680,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (680,
	0,
	'',
	'',
	652,
	653);
INSERT INTO PE_PE
	VALUES (681,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (681,
	0,
	'',
	'',
	656,
	652);
INSERT INTO PE_PE
	VALUES (682,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (682,
	0,
	'',
	'',
	658,
	655);
INSERT INTO PE_PE
	VALUES (683,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (683,
	0,
	'',
	'',
	658,
	654);
INSERT INTO PE_PE
	VALUES (684,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (684,
	0,
	'',
	'',
	657,
	658);
INSERT INTO PE_PE
	VALUES (685,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (685,
	0,
	'',
	'',
	660,
	659);
INSERT INTO PE_PE
	VALUES (686,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (686,
	0,
	'',
	'',
	654,
	656);
INSERT INTO PE_PE
	VALUES (687,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (687,
	0,
	'',
	'',
	655,
	656);
INSERT INTO PE_PE
	VALUES (688,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (688,
	0,
	'',
	'',
	659,
	656);
INSERT INTO PE_PE
	VALUES (689,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (689,
	0,
	'',
	'',
	662,
	661);
INSERT INTO PE_PE
	VALUES (690,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (690,
	0,
	'',
	'',
	664,
	663);
INSERT INTO PE_PE
	VALUES (691,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (691,
	0,
	'',
	'',
	665,
	663);
INSERT INTO PE_PE
	VALUES (692,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (692,
	0,
	'',
	'',
	666,
	663);
INSERT INTO PE_PE
	VALUES (693,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (693,
	0,
	'',
	'',
	667,
	660);
INSERT INTO PE_PE
	VALUES (694,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (694,
	0,
	'',
	'',
	669,
	668);
INSERT INTO PE_PE
	VALUES (695,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (695,
	0,
	'',
	'',
	668,
	667);
INSERT INTO PE_PE
	VALUES (696,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (696,
	0,
	'',
	'',
	670,
	669);
INSERT INTO PE_PE
	VALUES (697,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (697,
	0,
	'',
	'',
	671,
	666);
INSERT INTO PE_PE
	VALUES (698,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (698,
	0,
	'',
	'',
	663,
	662);
INSERT INTO PE_PE
	VALUES (699,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (699,
	0,
	'',
	'',
	673,
	672);
INSERT INTO PE_PE
	VALUES (700,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (700,
	0,
	'',
	'',
	674,
	673);
INSERT INTO PE_PE
	VALUES (701,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (701,
	0,
	'',
	'',
	676,
	675);
INSERT INTO PE_PE
	VALUES (702,
	1,
	648,
	0,
	12);
INSERT INTO A_E
	VALUES (702,
	0,
	'',
	'',
	677,
	676);
INSERT INTO PE_PE
	VALUES (703,
	1,
	536,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (703,
	0,
	1,
	'UC04 - WorkoutWithPause',
	'',
	0);
INSERT INTO PE_PE
	VALUES (704,
	1,
	703,
	0,
	14);
INSERT INTO SQ_P
	VALUES (704,
	0);
INSERT INTO IA_UCP
	VALUES (704,
	'UC04 - WorkoutWithPause',
	'Pre-conditions
	No track logs exist on the device.
	Timer is stopped.
	Elapsed time is zero.
	Accumulated distance is zero.
	Display shows elapsed time and accumulated distance.


Post-conditions
	A track log exists on the device.
	Timer is stopped.
	Elapsed time and distance are displayed.

Scenario
	1.	User pushes the start/stop button and begins moving (walking, running, flying, cycling, etc.).
	2.	The timer starts.
	3.	Throughout the workout, the display shows:
		a.	Accumulated distance
		b.	Elapsed time
	4.	Periodically throughout the workout the device stores, in the active track log, 
	    the current location of the device.
	5.	User pushes the start/stop button.
	6.	The timer stops.
	7.	The elapsed time and distance stop accumulating.
	8.  User pushes the start/stop button and begins moving again.
	9.	The timer starts.
	10.	The elapsed time and distance start accumulating.
	11. User pushes the start/stop button.
	12.	The timer stops.
	13. The elapsed time and distance stop accumulating.
	14. Display shows elapsed time and accumulated distance.
	
	');
INSERT INTO PE_PE
	VALUES (705,
	1,
	703,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (705,
	0,
	1,
	'ActivityDiagram',
	'',
	0);
INSERT INTO PE_PE
	VALUES (706,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (706,
	0);
INSERT INTO A_OBJ
	VALUES (706,
	'User',
	'');
INSERT INTO PE_PE
	VALUES (707,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (707,
	0);
INSERT INTO A_OBJ
	VALUES (707,
	'Application',
	'');
INSERT INTO PE_PE
	VALUES (708,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (708,
	0);
INSERT INTO A_OBJ
	VALUES (708,
	'GPS Chipset',
	'');
INSERT INTO PE_PE
	VALUES (709,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (709,
	0);
INSERT INTO A_ACT
	VALUES (709);
INSERT INTO A_AE
	VALUES (709);
INSERT INTO A_AEA
	VALUES (709,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (710,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (710,
	0);
INSERT INTO A_ACT
	VALUES (710);
INSERT INTO A_SS
	VALUES (710,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (711,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (711,
	0);
INSERT INTO A_ACT
	VALUES (711);
INSERT INTO A_GA
	VALUES (711,
	'Start Stopwatch',
	'');
INSERT INTO PE_PE
	VALUES (712,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (712,
	0);
INSERT INTO A_ACT
	VALUES (712);
INSERT INTO A_GA
	VALUES (712,
	'Start Tracking Location',
	'');
INSERT INTO PE_PE
	VALUES (713,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (713,
	0);
INSERT INTO A_CTL
	VALUES (713);
INSERT INTO A_FJ
	VALUES (713,
	'',
	'');
INSERT INTO PE_PE
	VALUES (714,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (714,
	0);
INSERT INTO A_CTL
	VALUES (714);
INSERT INTO A_FJ
	VALUES (714,
	'',
	'');
INSERT INTO PE_PE
	VALUES (715,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (715,
	0);
INSERT INTO A_ACT
	VALUES (715);
INSERT INTO A_SS
	VALUES (715,
	'Start Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (716,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (716,
	0);
INSERT INTO A_ACT
	VALUES (716);
INSERT INTO A_AE
	VALUES (716);
INSERT INTO A_AEA
	VALUES (716,
	'Start Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (717,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (717,
	0);
INSERT INTO A_CTL
	VALUES (717);
INSERT INTO A_FJ
	VALUES (717,
	'',
	'');
INSERT INTO PE_PE
	VALUES (718,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (718,
	0);
INSERT INTO A_ACT
	VALUES (718);
INSERT INTO A_GA
	VALUES (718,
	'Stop Tracking Location',
	'');
INSERT INTO PE_PE
	VALUES (719,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (719,
	0);
INSERT INTO A_ACT
	VALUES (719);
INSERT INTO A_SS
	VALUES (719,
	'Stop Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (720,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (720,
	0);
INSERT INTO A_ACT
	VALUES (720);
INSERT INTO A_GA
	VALUES (720,
	'Periodically Supply Location',
	'');
INSERT INTO PE_PE
	VALUES (721,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (721,
	0);
INSERT INTO A_ACT
	VALUES (721);
INSERT INTO A_SS
	VALUES (721,
	'Location',
	'');
INSERT INTO PE_PE
	VALUES (722,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (722,
	0);
INSERT INTO A_ACT
	VALUES (722);
INSERT INTO A_AE
	VALUES (722);
INSERT INTO A_AEA
	VALUES (722,
	'Location',
	'');
INSERT INTO PE_PE
	VALUES (723,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (723,
	0);
INSERT INTO A_ACT
	VALUES (723);
INSERT INTO A_GA
	VALUES (723,
	'Calculate Accumulated Distance',
	'');
INSERT INTO PE_PE
	VALUES (724,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (724,
	0);
INSERT INTO A_ACT
	VALUES (724);
INSERT INTO A_AE
	VALUES (724);
INSERT INTO A_AEA
	VALUES (724,
	'Stop Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (725,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (725,
	0);
INSERT INTO A_ACT
	VALUES (725);
INSERT INTO A_GA
	VALUES (725,
	'Stop Stopwatch',
	'');
INSERT INTO PE_PE
	VALUES (726,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (726,
	0);
INSERT INTO A_ACT
	VALUES (726);
INSERT INTO A_GA
	VALUES (726,
	'Periodically Update Display',
	'In this case the display shows elapsed time and accumulated distance.');
INSERT INTO PE_PE
	VALUES (727,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (727,
	0);
INSERT INTO A_ACT
	VALUES (727);
INSERT INTO A_SS
	VALUES (727,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (728,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (728,
	0);
INSERT INTO A_ACT
	VALUES (728);
INSERT INTO A_AE
	VALUES (728);
INSERT INTO A_AEA
	VALUES (728,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (729,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (729,
	0);
INSERT INTO A_ACT
	VALUES (729);
INSERT INTO A_AE
	VALUES (729);
INSERT INTO A_AEA
	VALUES (729,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (730,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (730,
	0);
INSERT INTO A_ACT
	VALUES (730);
INSERT INTO A_SS
	VALUES (730,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (731,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (731,
	0);
INSERT INTO A_ACT
	VALUES (731);
INSERT INTO A_GA
	VALUES (731,
	'Start Stopwatch',
	'');
INSERT INTO PE_PE
	VALUES (732,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (732,
	0);
INSERT INTO A_ACT
	VALUES (732);
INSERT INTO A_GA
	VALUES (732,
	'Start Tracking Location',
	'');
INSERT INTO PE_PE
	VALUES (733,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (733,
	0);
INSERT INTO A_ACT
	VALUES (733);
INSERT INTO A_SS
	VALUES (733,
	'Start Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (734,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (734,
	0);
INSERT INTO A_ACT
	VALUES (734);
INSERT INTO A_AE
	VALUES (734);
INSERT INTO A_AEA
	VALUES (734,
	'Location',
	'');
INSERT INTO PE_PE
	VALUES (735,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (735,
	0);
INSERT INTO A_ACT
	VALUES (735);
INSERT INTO A_GA
	VALUES (735,
	'Calculate Accumulated Distance',
	'');
INSERT INTO PE_PE
	VALUES (736,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (736,
	0);
INSERT INTO A_ACT
	VALUES (736);
INSERT INTO A_AE
	VALUES (736);
INSERT INTO A_AEA
	VALUES (736,
	'Start Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (737,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (737,
	0);
INSERT INTO A_ACT
	VALUES (737);
INSERT INTO A_GA
	VALUES (737,
	'Periodically Supply Location',
	'');
INSERT INTO PE_PE
	VALUES (738,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (738,
	0);
INSERT INTO A_ACT
	VALUES (738);
INSERT INTO A_SS
	VALUES (738,
	'Location',
	'');
INSERT INTO PE_PE
	VALUES (739,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (739,
	0);
INSERT INTO A_CTL
	VALUES (739);
INSERT INTO A_FJ
	VALUES (739,
	'',
	'');
INSERT INTO PE_PE
	VALUES (740,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (740,
	0);
INSERT INTO A_ACT
	VALUES (740);
INSERT INTO A_GA
	VALUES (740,
	'Stop Tracking Location',
	'');
INSERT INTO PE_PE
	VALUES (741,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (741,
	0);
INSERT INTO A_ACT
	VALUES (741);
INSERT INTO A_SS
	VALUES (741,
	'Stop Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (742,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (742,
	0);
INSERT INTO A_ACT
	VALUES (742);
INSERT INTO A_GA
	VALUES (742,
	'Stop Stopwatch',
	'');
INSERT INTO PE_PE
	VALUES (743,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (743,
	0);
INSERT INTO A_ACT
	VALUES (743);
INSERT INTO A_SS
	VALUES (743,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (744,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (744,
	0);
INSERT INTO A_ACT
	VALUES (744);
INSERT INTO A_AE
	VALUES (744);
INSERT INTO A_AEA
	VALUES (744,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (745,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (745,
	0);
INSERT INTO A_ACT
	VALUES (745);
INSERT INTO A_AE
	VALUES (745);
INSERT INTO A_AEA
	VALUES (745,
	'Stop Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (746,
	1,
	705,
	0,
	18);
INSERT INTO A_N
	VALUES (746,
	0);
INSERT INTO A_CTL
	VALUES (746);
INSERT INTO A_FJ
	VALUES (746,
	'',
	'');
INSERT INTO PE_PE
	VALUES (747,
	1,
	705,
	0,
	11);
INSERT INTO A_AP
	VALUES (747,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (748,
	1,
	705,
	0,
	11);
INSERT INTO A_AP
	VALUES (748,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (749,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (749,
	0,
	'',
	'',
	709,
	710);
INSERT INTO PE_PE
	VALUES (750,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (750,
	0,
	'',
	'',
	714,
	712);
INSERT INTO PE_PE
	VALUES (751,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (751,
	0,
	'',
	'',
	714,
	711);
INSERT INTO PE_PE
	VALUES (752,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (752,
	0,
	'',
	'',
	716,
	715);
INSERT INTO PE_PE
	VALUES (753,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (753,
	0,
	'',
	'',
	711,
	713);
INSERT INTO PE_PE
	VALUES (754,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (754,
	0,
	'',
	'',
	712,
	713);
INSERT INTO PE_PE
	VALUES (755,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (755,
	0,
	'',
	'',
	715,
	713);
INSERT INTO PE_PE
	VALUES (756,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (756,
	0,
	'',
	'',
	718,
	717);
INSERT INTO PE_PE
	VALUES (757,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (757,
	0,
	'',
	'',
	719,
	717);
INSERT INTO PE_PE
	VALUES (758,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (758,
	0,
	'',
	'',
	720,
	716);
INSERT INTO PE_PE
	VALUES (759,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (759,
	0,
	'',
	'',
	722,
	721);
INSERT INTO PE_PE
	VALUES (760,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (760,
	0,
	'',
	'',
	721,
	720);
INSERT INTO PE_PE
	VALUES (761,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (761,
	0,
	'',
	'',
	723,
	722);
INSERT INTO PE_PE
	VALUES (762,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (762,
	0,
	'',
	'',
	724,
	719);
INSERT INTO PE_PE
	VALUES (763,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (763,
	0,
	'',
	'',
	725,
	717);
INSERT INTO PE_PE
	VALUES (764,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (764,
	0,
	'',
	'',
	726,
	714);
INSERT INTO PE_PE
	VALUES (765,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (765,
	0,
	'',
	'',
	713,
	709);
INSERT INTO PE_PE
	VALUES (766,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (766,
	0,
	'',
	'',
	728,
	727);
INSERT INTO PE_PE
	VALUES (767,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (767,
	0,
	'',
	'',
	717,
	728);
INSERT INTO PE_PE
	VALUES (768,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (768,
	0,
	'',
	'',
	737,
	736);
INSERT INTO PE_PE
	VALUES (769,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (769,
	0,
	'',
	'',
	729,
	730);
INSERT INTO PE_PE
	VALUES (770,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (770,
	0,
	'',
	'',
	736,
	733);
INSERT INTO PE_PE
	VALUES (771,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (771,
	0,
	'',
	'',
	738,
	737);
INSERT INTO PE_PE
	VALUES (772,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (772,
	0,
	'',
	'',
	734,
	738);
INSERT INTO PE_PE
	VALUES (773,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (773,
	0,
	'',
	'',
	735,
	734);
INSERT INTO PE_PE
	VALUES (774,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (774,
	0,
	'',
	'',
	739,
	729);
INSERT INTO PE_PE
	VALUES (775,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (775,
	0,
	'',
	'',
	731,
	739);
INSERT INTO PE_PE
	VALUES (776,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (776,
	0,
	'',
	'',
	732,
	739);
INSERT INTO PE_PE
	VALUES (777,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (777,
	0,
	'',
	'',
	733,
	739);
INSERT INTO PE_PE
	VALUES (778,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (778,
	0,
	'',
	'',
	744,
	743);
INSERT INTO PE_PE
	VALUES (779,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (779,
	0,
	'',
	'',
	745,
	741);
INSERT INTO PE_PE
	VALUES (780,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (780,
	0,
	'',
	'',
	741,
	746);
INSERT INTO PE_PE
	VALUES (781,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (781,
	0,
	'',
	'',
	746,
	744);
INSERT INTO PE_PE
	VALUES (782,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (782,
	0,
	'',
	'',
	742,
	746);
INSERT INTO PE_PE
	VALUES (783,
	1,
	705,
	0,
	12);
INSERT INTO A_E
	VALUES (783,
	0,
	'',
	'',
	740,
	746);
INSERT INTO PE_PE
	VALUES (784,
	1,
	536,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (784,
	0,
	1,
	'UC05 - AchievingPaceOverDistanceGoal',
	'',
	0);
INSERT INTO PE_PE
	VALUES (785,
	1,
	784,
	0,
	14);
INSERT INTO SQ_P
	VALUES (785,
	0);
INSERT INTO IA_UCP
	VALUES (785,
	'UC05-AchievingPaceOverDistanceGoal',
	'Pre-conditions
	No Track logs exist on the device.
	Timer is stopped.
	Elapsed time is zero. 
	Accumulated distance is zero.
	Display shows elapsed time and accumulated distance.

Post-conditions
	A track log exists on the device
	A pace over distance goal exists on the device.
	An indication of when during the workout the goal was being met exists on the device.
	Timer is stopped.
	Elapsed time and distance are displayed.

Scenario
	1.  User establishes a single goal for maintaining a bounded pace over a certain distance.
	2.	User pushes the start/stop button and begins moving (walking, running, flying, cycling, etc.).
	3.	The timer starts.
	4.	The display shows:
		a.	Accumulated distance
		b.	Elapsed time
	5.	Periodically throughout the workout the device stores, in the active track log, 
	    the current location of the device.
	6.  User pushes Set Target button
	7.	Evaluation of the goal begins.
	8.  The device stores an indication of when during the workout the goal is being met.
	    In this case the goal is being met across the entire distance of the goal.
	9.	The display shows:
		a.	Accumulated distance
		b.	Elapsed time
		c.  An indication of whether the current goal condition is being met.
	10.	User pushes the start/stop button.
	11.	The timer stops.
	12. The elapsed time and distance stop accumulating.
	');
INSERT INTO PE_PE
	VALUES (786,
	1,
	784,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (786,
	0,
	1,
	'ActivityDiagram',
	'',
	0);
INSERT INTO PE_PE
	VALUES (787,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (787,
	0);
INSERT INTO A_OBJ
	VALUES (787,
	'User',
	'');
INSERT INTO PE_PE
	VALUES (788,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (788,
	0);
INSERT INTO A_OBJ
	VALUES (788,
	'Application',
	'');
INSERT INTO PE_PE
	VALUES (789,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (789,
	0);
INSERT INTO A_OBJ
	VALUES (789,
	'GPS Chipset',
	'');
INSERT INTO PE_PE
	VALUES (790,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (790,
	0);
INSERT INTO A_ACT
	VALUES (790);
INSERT INTO A_AE
	VALUES (790);
INSERT INTO A_AEA
	VALUES (790,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (791,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (791,
	0);
INSERT INTO A_ACT
	VALUES (791);
INSERT INTO A_SS
	VALUES (791,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (792,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (792,
	0);
INSERT INTO A_ACT
	VALUES (792);
INSERT INTO A_GA
	VALUES (792,
	'Start Stopwatch',
	'');
INSERT INTO PE_PE
	VALUES (793,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (793,
	0);
INSERT INTO A_ACT
	VALUES (793);
INSERT INTO A_GA
	VALUES (793,
	'Start Tracking Location',
	'');
INSERT INTO PE_PE
	VALUES (794,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (794,
	0);
INSERT INTO A_CTL
	VALUES (794);
INSERT INTO A_FJ
	VALUES (794,
	'',
	'');
INSERT INTO PE_PE
	VALUES (795,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (795,
	0);
INSERT INTO A_ACT
	VALUES (795);
INSERT INTO A_GA
	VALUES (795,
	'Periodically Update Display',
	'In this case the display shows elapsed time and accumulated distance.');
INSERT INTO PE_PE
	VALUES (796,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (796,
	0);
INSERT INTO A_CTL
	VALUES (796);
INSERT INTO A_FJ
	VALUES (796,
	'',
	'');
INSERT INTO PE_PE
	VALUES (797,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (797,
	0);
INSERT INTO A_ACT
	VALUES (797);
INSERT INTO A_SS
	VALUES (797,
	'Start Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (798,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (798,
	0);
INSERT INTO A_ACT
	VALUES (798);
INSERT INTO A_AE
	VALUES (798);
INSERT INTO A_AEA
	VALUES (798,
	'Start Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (799,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (799,
	0);
INSERT INTO A_ACT
	VALUES (799);
INSERT INTO A_SS
	VALUES (799,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (800,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (800,
	0);
INSERT INTO A_ACT
	VALUES (800);
INSERT INTO A_AE
	VALUES (800);
INSERT INTO A_AEA
	VALUES (800,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (801,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (801,
	0);
INSERT INTO A_CTL
	VALUES (801);
INSERT INTO A_FJ
	VALUES (801,
	'',
	'');
INSERT INTO PE_PE
	VALUES (802,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (802,
	0);
INSERT INTO A_ACT
	VALUES (802);
INSERT INTO A_GA
	VALUES (802,
	'Stop Stopwatch',
	'');
INSERT INTO PE_PE
	VALUES (803,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (803,
	0);
INSERT INTO A_ACT
	VALUES (803);
INSERT INTO A_GA
	VALUES (803,
	'Stop Tracking Location',
	'');
INSERT INTO PE_PE
	VALUES (804,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (804,
	0);
INSERT INTO A_ACT
	VALUES (804);
INSERT INTO A_SS
	VALUES (804,
	'Stop Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (805,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (805,
	0);
INSERT INTO A_ACT
	VALUES (805);
INSERT INTO A_GA
	VALUES (805,
	'Periodically Supply Location',
	'');
INSERT INTO PE_PE
	VALUES (806,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (806,
	0);
INSERT INTO A_ACT
	VALUES (806);
INSERT INTO A_SS
	VALUES (806,
	'Location',
	'');
INSERT INTO PE_PE
	VALUES (807,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (807,
	0);
INSERT INTO A_ACT
	VALUES (807);
INSERT INTO A_AE
	VALUES (807);
INSERT INTO A_AEA
	VALUES (807,
	'Location',
	'');
INSERT INTO PE_PE
	VALUES (808,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (808,
	0);
INSERT INTO A_ACT
	VALUES (808);
INSERT INTO A_GA
	VALUES (808,
	'Calculate Accumulated Distance',
	'');
INSERT INTO PE_PE
	VALUES (809,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (809,
	0);
INSERT INTO A_ACT
	VALUES (809);
INSERT INTO A_AE
	VALUES (809);
INSERT INTO A_AEA
	VALUES (809,
	'Stop Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (810,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (810,
	0);
INSERT INTO A_ACT
	VALUES (810);
INSERT INTO A_SS
	VALUES (810,
	'Establish Pace over Distance Goal',
	'');
INSERT INTO PE_PE
	VALUES (811,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (811,
	0);
INSERT INTO A_ACT
	VALUES (811);
INSERT INTO A_AE
	VALUES (811);
INSERT INTO A_AEA
	VALUES (811,
	'Establish Pace Over Distance Goal',
	'');
INSERT INTO PE_PE
	VALUES (812,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (812,
	0);
INSERT INTO A_ACT
	VALUES (812);
INSERT INTO A_GA
	VALUES (812,
	'Create Pace over Distance Goal',
	'');
INSERT INTO PE_PE
	VALUES (813,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (813,
	0);
INSERT INTO A_ACT
	VALUES (813);
INSERT INTO A_GA
	VALUES (813,
	'Periodically Determine Goal Disposition',
	'');
INSERT INTO PE_PE
	VALUES (814,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (814,
	0);
INSERT INTO A_ACT
	VALUES (814);
INSERT INTO A_SS
	VALUES (814,
	'Set Target',
	'');
INSERT INTO PE_PE
	VALUES (815,
	1,
	786,
	0,
	18);
INSERT INTO A_N
	VALUES (815,
	0);
INSERT INTO A_ACT
	VALUES (815);
INSERT INTO A_AE
	VALUES (815);
INSERT INTO A_AEA
	VALUES (815,
	'Set Target',
	'');
INSERT INTO PE_PE
	VALUES (816,
	1,
	786,
	0,
	11);
INSERT INTO A_AP
	VALUES (816,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (817,
	1,
	786,
	0,
	11);
INSERT INTO A_AP
	VALUES (817,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (818,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (818,
	0,
	'',
	'',
	790,
	791);
INSERT INTO PE_PE
	VALUES (819,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (819,
	0,
	'',
	'',
	794,
	790);
INSERT INTO PE_PE
	VALUES (820,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (820,
	0,
	'',
	'',
	796,
	793);
INSERT INTO PE_PE
	VALUES (821,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (821,
	0,
	'',
	'',
	796,
	792);
INSERT INTO PE_PE
	VALUES (822,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (822,
	0,
	'',
	'',
	795,
	796);
INSERT INTO PE_PE
	VALUES (823,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (823,
	0,
	'',
	'',
	798,
	797);
INSERT INTO PE_PE
	VALUES (824,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (824,
	0,
	'',
	'',
	792,
	794);
INSERT INTO PE_PE
	VALUES (825,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (825,
	0,
	'',
	'',
	793,
	794);
INSERT INTO PE_PE
	VALUES (826,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (826,
	0,
	'',
	'',
	797,
	794);
INSERT INTO PE_PE
	VALUES (827,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (827,
	0,
	'',
	'',
	800,
	799);
INSERT INTO PE_PE
	VALUES (828,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (828,
	0,
	'',
	'',
	802,
	801);
INSERT INTO PE_PE
	VALUES (829,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (829,
	0,
	'',
	'',
	803,
	801);
INSERT INTO PE_PE
	VALUES (830,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (830,
	0,
	'',
	'',
	804,
	801);
INSERT INTO PE_PE
	VALUES (831,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (831,
	0,
	'',
	'',
	805,
	798);
INSERT INTO PE_PE
	VALUES (832,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (832,
	0,
	'',
	'',
	807,
	806);
INSERT INTO PE_PE
	VALUES (833,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (833,
	0,
	'',
	'',
	806,
	805);
INSERT INTO PE_PE
	VALUES (834,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (834,
	0,
	'',
	'',
	809,
	804);
INSERT INTO PE_PE
	VALUES (835,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (835,
	0,
	'',
	'',
	801,
	800);
INSERT INTO PE_PE
	VALUES (836,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (836,
	0,
	'',
	'',
	811,
	810);
INSERT INTO PE_PE
	VALUES (837,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (837,
	0,
	'',
	'',
	812,
	811);
INSERT INTO PE_PE
	VALUES (838,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (838,
	0,
	'',
	'',
	808,
	807);
INSERT INTO PE_PE
	VALUES (839,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (839,
	0,
	'',
	'',
	815,
	814);
INSERT INTO PE_PE
	VALUES (840,
	1,
	786,
	0,
	12);
INSERT INTO A_E
	VALUES (840,
	0,
	'',
	'',
	813,
	815);
INSERT INTO PE_PE
	VALUES (841,
	1,
	536,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (841,
	0,
	1,
	'UC06___AchievingHeartRateOverTimeGoal',
	'',
	0);
INSERT INTO PE_PE
	VALUES (842,
	1,
	841,
	0,
	14);
INSERT INTO SQ_P
	VALUES (842,
	0);
INSERT INTO IA_UCP
	VALUES (842,
	'UC06-AchievingHeartRateOverTimeGoal',
	'Pre-conditions
	No Track logs exist on the device.
	Timer is stopped.
	Elapsed time is zero. 
	Accumulated distance is zero.
	Display shows elapsed time and accumulated distance.

Post-conditions
	A track log exists on the device.
	A heart rate over time goal exists on the device.
	A heart rate log exists on the device.
	An indication of when during the workout the goal was being met exists on the device.
	Timer is stopped.
	Elapsed time and current heart rate are displayed.
	

Scenario
	1.  User establishes a single goal of maintaining a bounded heart rate over a period of time.
	2.	User pushes the start/stop button and begins moving (walking, running, flying, cycling, etc.).
	3.	The timer starts.
	4.  User pushes the Mode button until heart rate is displayed.
	5.	The display shows:
		a.	Current heart rate
		b.	Elapsed time
	6.  Periodically throughout the workout the device stores the current heart rate of the user.
	7.	User pushes Set Target button.
	8.	Evaluation of the goal starts.
	9.  The device stores an indication of when during the workout the goal is being met.
	    In this case the goal is being met throughout the duration of the goal.
	10.	The display shows:
		a.	Current heart rate
		b.	Elapsed time
		c.  An indication of whether the current goal conditon is being met.
	11.	User pushes the start/stop button.
	12.	The timer stops.
	13. The elapsed time, distance, and heart rate samples stop accumulating.');
INSERT INTO PE_PE
	VALUES (843,
	1,
	841,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (843,
	0,
	1,
	'ActivityDiagram',
	'',
	0);
INSERT INTO PE_PE
	VALUES (844,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (844,
	0);
INSERT INTO A_OBJ
	VALUES (844,
	'User',
	'');
INSERT INTO PE_PE
	VALUES (845,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (845,
	0);
INSERT INTO A_OBJ
	VALUES (845,
	'Application',
	'');
INSERT INTO PE_PE
	VALUES (846,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (846,
	0);
INSERT INTO A_OBJ
	VALUES (846,
	'GPS_Chipset',
	'');
INSERT INTO PE_PE
	VALUES (847,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (847,
	0);
INSERT INTO A_ACT
	VALUES (847);
INSERT INTO A_AE
	VALUES (847);
INSERT INTO A_AEA
	VALUES (847,
	'Start_Stop_Pushed',
	'');
INSERT INTO PE_PE
	VALUES (848,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (848,
	0);
INSERT INTO A_ACT
	VALUES (848);
INSERT INTO A_SS
	VALUES (848,
	'Start_Stop_Pushed',
	'');
INSERT INTO PE_PE
	VALUES (849,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (849,
	0);
INSERT INTO A_ACT
	VALUES (849);
INSERT INTO A_GA
	VALUES (849,
	'Start_Stopwatch',
	'');
INSERT INTO PE_PE
	VALUES (850,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (850,
	0);
INSERT INTO A_ACT
	VALUES (850);
INSERT INTO A_GA
	VALUES (850,
	'Start_Tracking_Location',
	'');
INSERT INTO PE_PE
	VALUES (851,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (851,
	0);
INSERT INTO A_CTL
	VALUES (851);
INSERT INTO A_FJ
	VALUES (851,
	'',
	'');
INSERT INTO PE_PE
	VALUES (852,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (852,
	0);
INSERT INTO A_ACT
	VALUES (852);
INSERT INTO A_GA
	VALUES (852,
	'Periodically_Update_Display',
	'In this case the display shows elapsed time and accumulated distance.');
INSERT INTO PE_PE
	VALUES (853,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (853,
	0);
INSERT INTO A_CTL
	VALUES (853);
INSERT INTO A_FJ
	VALUES (853,
	'',
	'');
INSERT INTO PE_PE
	VALUES (854,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (854,
	0);
INSERT INTO A_ACT
	VALUES (854);
INSERT INTO A_SS
	VALUES (854,
	'Start_Sending_Location',
	'');
INSERT INTO PE_PE
	VALUES (855,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (855,
	0);
INSERT INTO A_ACT
	VALUES (855);
INSERT INTO A_AE
	VALUES (855);
INSERT INTO A_AEA
	VALUES (855,
	'Start_Sending_Location',
	'');
INSERT INTO PE_PE
	VALUES (856,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (856,
	0);
INSERT INTO A_ACT
	VALUES (856);
INSERT INTO A_SS
	VALUES (856,
	'Start_Stop_Pushed',
	'');
INSERT INTO PE_PE
	VALUES (857,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (857,
	0);
INSERT INTO A_ACT
	VALUES (857);
INSERT INTO A_AE
	VALUES (857);
INSERT INTO A_AEA
	VALUES (857,
	'Start_Stop_Pushed',
	'');
INSERT INTO PE_PE
	VALUES (858,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (858,
	0);
INSERT INTO A_CTL
	VALUES (858);
INSERT INTO A_FJ
	VALUES (858,
	'',
	'');
INSERT INTO PE_PE
	VALUES (859,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (859,
	0);
INSERT INTO A_ACT
	VALUES (859);
INSERT INTO A_GA
	VALUES (859,
	'Stop_Stopwatch',
	'');
INSERT INTO PE_PE
	VALUES (860,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (860,
	0);
INSERT INTO A_ACT
	VALUES (860);
INSERT INTO A_GA
	VALUES (860,
	'Stop_Tracking_Location',
	'');
INSERT INTO PE_PE
	VALUES (861,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (861,
	0);
INSERT INTO A_ACT
	VALUES (861);
INSERT INTO A_SS
	VALUES (861,
	'Stop_Sending_Location',
	'');
INSERT INTO PE_PE
	VALUES (862,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (862,
	0);
INSERT INTO A_ACT
	VALUES (862);
INSERT INTO A_GA
	VALUES (862,
	'Periodically_Supply_Location',
	'');
INSERT INTO PE_PE
	VALUES (863,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (863,
	0);
INSERT INTO A_ACT
	VALUES (863);
INSERT INTO A_SS
	VALUES (863,
	'Location',
	'');
INSERT INTO PE_PE
	VALUES (864,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (864,
	0);
INSERT INTO A_ACT
	VALUES (864);
INSERT INTO A_AE
	VALUES (864);
INSERT INTO A_AEA
	VALUES (864,
	'Location',
	'');
INSERT INTO PE_PE
	VALUES (865,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (865,
	0);
INSERT INTO A_ACT
	VALUES (865);
INSERT INTO A_GA
	VALUES (865,
	'Calculate_Accumulated_Distance',
	'');
INSERT INTO PE_PE
	VALUES (866,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (866,
	0);
INSERT INTO A_ACT
	VALUES (866);
INSERT INTO A_AE
	VALUES (866);
INSERT INTO A_AEA
	VALUES (866,
	'Stop_Sending_Location',
	'');
INSERT INTO PE_PE
	VALUES (867,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (867,
	0);
INSERT INTO A_ACT
	VALUES (867);
INSERT INTO A_SS
	VALUES (867,
	'Establish_Heart_Rate_over_Time_Goal',
	'');
INSERT INTO PE_PE
	VALUES (868,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (868,
	0);
INSERT INTO A_ACT
	VALUES (868);
INSERT INTO A_AE
	VALUES (868);
INSERT INTO A_AEA
	VALUES (868,
	'Establish_Heart_Rate_over_Time_Goal',
	'');
INSERT INTO PE_PE
	VALUES (869,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (869,
	0);
INSERT INTO A_ACT
	VALUES (869);
INSERT INTO A_GA
	VALUES (869,
	'Create_Heart_Rate_over_Time_Goal',
	'');
INSERT INTO PE_PE
	VALUES (870,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (870,
	0);
INSERT INTO A_OBJ
	VALUES (870,
	'Heart_Rate_Monitor',
	'');
INSERT INTO PE_PE
	VALUES (871,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (871,
	0);
INSERT INTO A_ACT
	VALUES (871);
INSERT INTO A_SS
	VALUES (871,
	'Start_Sending_Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (872,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (872,
	0);
INSERT INTO A_ACT
	VALUES (872);
INSERT INTO A_GA
	VALUES (872,
	'Periodically_Supply_Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (873,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (873,
	0);
INSERT INTO A_ACT
	VALUES (873);
INSERT INTO A_SS
	VALUES (873,
	'Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (874,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (874,
	0);
INSERT INTO A_ACT
	VALUES (874);
INSERT INTO A_AE
	VALUES (874);
INSERT INTO A_AEA
	VALUES (874,
	'Start_Sending_Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (875,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (875,
	0);
INSERT INTO A_ACT
	VALUES (875);
INSERT INTO A_SS
	VALUES (875,
	'Stop_Sending_Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (876,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (876,
	0);
INSERT INTO A_ACT
	VALUES (876);
INSERT INTO A_AE
	VALUES (876);
INSERT INTO A_AEA
	VALUES (876,
	'Stop_Sending_Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (877,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (877,
	0);
INSERT INTO A_ACT
	VALUES (877);
INSERT INTO A_AE
	VALUES (877);
INSERT INTO A_AEA
	VALUES (877,
	'Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (878,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (878,
	0);
INSERT INTO A_ACT
	VALUES (878);
INSERT INTO A_GA
	VALUES (878,
	'Periodically_Determine_Goal_Disposition',
	'');
INSERT INTO PE_PE
	VALUES (879,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (879,
	0);
INSERT INTO A_ACT
	VALUES (879);
INSERT INTO A_GA
	VALUES (879,
	'Start_Tracking_Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (880,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (880,
	0);
INSERT INTO A_ACT
	VALUES (880);
INSERT INTO A_GA
	VALUES (880,
	'Stop_Tracking_Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (881,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (881,
	0);
INSERT INTO A_ACT
	VALUES (881);
INSERT INTO A_SS
	VALUES (881,
	'Set_Target',
	'');
INSERT INTO PE_PE
	VALUES (882,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (882,
	0);
INSERT INTO A_ACT
	VALUES (882);
INSERT INTO A_AE
	VALUES (882);
INSERT INTO A_AEA
	VALUES (882,
	'Set_Target',
	'');
INSERT INTO PE_PE
	VALUES (883,
	1,
	843,
	0,
	18);
INSERT INTO A_N
	VALUES (883,
	0);
INSERT INTO A_ACT
	VALUES (883);
INSERT INTO A_GA
	VALUES (883,
	'Store_Heart_Rate_Sample',
	'');
INSERT INTO PE_PE
	VALUES (884,
	1,
	843,
	0,
	11);
INSERT INTO A_AP
	VALUES (884,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (885,
	1,
	843,
	0,
	11);
INSERT INTO A_AP
	VALUES (885,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (886,
	1,
	843,
	0,
	11);
INSERT INTO A_AP
	VALUES (886,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (887,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (887,
	0,
	'',
	'',
	847,
	848);
INSERT INTO PE_PE
	VALUES (888,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (888,
	0,
	'',
	'',
	851,
	847);
INSERT INTO PE_PE
	VALUES (889,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (889,
	0,
	'',
	'',
	853,
	850);
INSERT INTO PE_PE
	VALUES (890,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (890,
	0,
	'',
	'',
	853,
	849);
INSERT INTO PE_PE
	VALUES (891,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (891,
	0,
	'',
	'',
	852,
	853);
INSERT INTO PE_PE
	VALUES (892,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (892,
	0,
	'',
	'',
	855,
	854);
INSERT INTO PE_PE
	VALUES (893,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (893,
	0,
	'',
	'',
	849,
	851);
INSERT INTO PE_PE
	VALUES (894,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (894,
	0,
	'',
	'',
	850,
	851);
INSERT INTO PE_PE
	VALUES (895,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (895,
	0,
	'',
	'',
	854,
	851);
INSERT INTO PE_PE
	VALUES (896,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (896,
	0,
	'',
	'',
	857,
	856);
INSERT INTO PE_PE
	VALUES (897,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (897,
	0,
	'',
	'',
	859,
	858);
INSERT INTO PE_PE
	VALUES (898,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (898,
	0,
	'',
	'',
	860,
	858);
INSERT INTO PE_PE
	VALUES (899,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (899,
	0,
	'',
	'',
	861,
	858);
INSERT INTO PE_PE
	VALUES (900,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (900,
	0,
	'',
	'',
	862,
	855);
INSERT INTO PE_PE
	VALUES (901,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (901,
	0,
	'',
	'',
	864,
	863);
INSERT INTO PE_PE
	VALUES (902,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (902,
	0,
	'',
	'',
	863,
	862);
INSERT INTO PE_PE
	VALUES (903,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (903,
	0,
	'',
	'',
	866,
	861);
INSERT INTO PE_PE
	VALUES (904,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (904,
	0,
	'',
	'',
	858,
	857);
INSERT INTO PE_PE
	VALUES (905,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (905,
	0,
	'',
	'',
	868,
	867);
INSERT INTO PE_PE
	VALUES (906,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (906,
	0,
	'',
	'',
	869,
	868);
INSERT INTO PE_PE
	VALUES (907,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (907,
	0,
	'',
	'',
	871,
	851);
INSERT INTO PE_PE
	VALUES (908,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (908,
	0,
	'',
	'',
	873,
	872);
INSERT INTO PE_PE
	VALUES (909,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (909,
	0,
	'',
	'',
	874,
	871);
INSERT INTO PE_PE
	VALUES (910,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (910,
	0,
	'',
	'',
	872,
	874);
INSERT INTO PE_PE
	VALUES (911,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (911,
	0,
	'',
	'',
	876,
	875);
INSERT INTO PE_PE
	VALUES (912,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (912,
	0,
	'',
	'',
	875,
	858);
INSERT INTO PE_PE
	VALUES (913,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (913,
	0,
	'',
	'',
	877,
	873);
INSERT INTO PE_PE
	VALUES (914,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (914,
	0,
	'',
	'',
	865,
	864);
INSERT INTO PE_PE
	VALUES (915,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (915,
	0,
	'',
	'',
	853,
	879);
INSERT INTO PE_PE
	VALUES (916,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (916,
	0,
	'',
	'',
	879,
	851);
INSERT INTO PE_PE
	VALUES (917,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (917,
	0,
	'',
	'',
	880,
	858);
INSERT INTO PE_PE
	VALUES (918,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (918,
	0,
	'',
	'',
	878,
	882);
INSERT INTO PE_PE
	VALUES (919,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (919,
	0,
	'',
	'',
	882,
	881);
INSERT INTO PE_PE
	VALUES (920,
	1,
	843,
	0,
	12);
INSERT INTO A_E
	VALUES (920,
	0,
	'',
	'',
	883,
	877);
INSERT INTO PE_PE
	VALUES (921,
	1,
	536,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (921,
	0,
	1,
	'UC07___FailingPaceOverDistanceGoal',
	'',
	0);
INSERT INTO PE_PE
	VALUES (922,
	1,
	921,
	0,
	14);
INSERT INTO SQ_P
	VALUES (922,
	0);
INSERT INTO IA_UCP
	VALUES (922,
	'UC07___FailingPaceOverDistanceGoal',
	'Pre-conditions
	No Track logs exist on the device.
	Timer is stopped.
	Elapsed time is zero. 
	Accumulated distance is zero.
	Display shows elapsed time and accumulated distance.

Post-conditions
	A track log exists on the device.
	A pace over distance goal exists on the device.
	An indication of when during the workout the goal was being met exists on the device.
	Timer is stopped.
	Elapsed time and pace are displayed.

Scenario
	1.  User establishes a single goal for maintaining a bounded pace over a certain distance.
	2.	User pushes the start/stop button and begins moving (walking, running, flying, cycling, etc.).
	3.	The timer starts.
	4.  User pushes the Mode button until pace is displayed.
	5.	The display shows:
		a.	Current pace
		b.	Elapsed time
	6.	Periodically throughout the workout the device stores, in the active track log, 
	    the current location of the device.
	7.  User pushes Set Target button
	8.	Evaluation of the goal starts.
	9.  The device stores an indication of when during the workout the goal is being met.
	    In this case the goal is being met across only a portion of the distance specified.
	10.	The display shows:
		a.	Current pace
		b.	Elapsed time
		c.  An indication of whether the current goal is being met.
	11.	User pushes the start/stop button.
	12.	The timer stops.
	13. The elapsed time and distance stop accumulating.
	');
INSERT INTO PE_PE
	VALUES (923,
	1,
	921,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (923,
	0,
	1,
	'ActivityDiagram',
	'',
	0);
INSERT INTO PE_PE
	VALUES (924,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (924,
	0);
INSERT INTO A_OBJ
	VALUES (924,
	'User',
	'');
INSERT INTO PE_PE
	VALUES (925,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (925,
	0);
INSERT INTO A_OBJ
	VALUES (925,
	'Application',
	'');
INSERT INTO PE_PE
	VALUES (926,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (926,
	0);
INSERT INTO A_OBJ
	VALUES (926,
	'GPS Chipset',
	'');
INSERT INTO PE_PE
	VALUES (927,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (927,
	0);
INSERT INTO A_ACT
	VALUES (927);
INSERT INTO A_AE
	VALUES (927);
INSERT INTO A_AEA
	VALUES (927,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (928,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (928,
	0);
INSERT INTO A_ACT
	VALUES (928);
INSERT INTO A_SS
	VALUES (928,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (929,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (929,
	0);
INSERT INTO A_ACT
	VALUES (929);
INSERT INTO A_GA
	VALUES (929,
	'Start Stopwatch',
	'');
INSERT INTO PE_PE
	VALUES (930,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (930,
	0);
INSERT INTO A_ACT
	VALUES (930);
INSERT INTO A_GA
	VALUES (930,
	'Start Tracking Location',
	'');
INSERT INTO PE_PE
	VALUES (931,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (931,
	0);
INSERT INTO A_CTL
	VALUES (931);
INSERT INTO A_FJ
	VALUES (931,
	'',
	'');
INSERT INTO PE_PE
	VALUES (932,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (932,
	0);
INSERT INTO A_ACT
	VALUES (932);
INSERT INTO A_GA
	VALUES (932,
	'Periodically Update Display',
	'In this case the display shows elapsed time and accumulated distance.');
INSERT INTO PE_PE
	VALUES (933,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (933,
	0);
INSERT INTO A_CTL
	VALUES (933);
INSERT INTO A_FJ
	VALUES (933,
	'',
	'');
INSERT INTO PE_PE
	VALUES (934,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (934,
	0);
INSERT INTO A_ACT
	VALUES (934);
INSERT INTO A_SS
	VALUES (934,
	'Start Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (935,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (935,
	0);
INSERT INTO A_ACT
	VALUES (935);
INSERT INTO A_AE
	VALUES (935);
INSERT INTO A_AEA
	VALUES (935,
	'Start Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (936,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (936,
	0);
INSERT INTO A_ACT
	VALUES (936);
INSERT INTO A_SS
	VALUES (936,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (937,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (937,
	0);
INSERT INTO A_ACT
	VALUES (937);
INSERT INTO A_AE
	VALUES (937);
INSERT INTO A_AEA
	VALUES (937,
	'Start/Stop Pushed',
	'');
INSERT INTO PE_PE
	VALUES (938,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (938,
	0);
INSERT INTO A_CTL
	VALUES (938);
INSERT INTO A_FJ
	VALUES (938,
	'',
	'');
INSERT INTO PE_PE
	VALUES (939,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (939,
	0);
INSERT INTO A_ACT
	VALUES (939);
INSERT INTO A_GA
	VALUES (939,
	'Stop Stopwatch',
	'');
INSERT INTO PE_PE
	VALUES (940,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (940,
	0);
INSERT INTO A_ACT
	VALUES (940);
INSERT INTO A_GA
	VALUES (940,
	'Stop Tracking Location',
	'');
INSERT INTO PE_PE
	VALUES (941,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (941,
	0);
INSERT INTO A_ACT
	VALUES (941);
INSERT INTO A_SS
	VALUES (941,
	'Stop Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (942,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (942,
	0);
INSERT INTO A_ACT
	VALUES (942);
INSERT INTO A_GA
	VALUES (942,
	'Periodically Supply Location',
	'');
INSERT INTO PE_PE
	VALUES (943,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (943,
	0);
INSERT INTO A_ACT
	VALUES (943);
INSERT INTO A_SS
	VALUES (943,
	'Location',
	'');
INSERT INTO PE_PE
	VALUES (944,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (944,
	0);
INSERT INTO A_ACT
	VALUES (944);
INSERT INTO A_AE
	VALUES (944);
INSERT INTO A_AEA
	VALUES (944,
	'Location',
	'');
INSERT INTO PE_PE
	VALUES (945,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (945,
	0);
INSERT INTO A_ACT
	VALUES (945);
INSERT INTO A_GA
	VALUES (945,
	'Calculate Accumulated Distance',
	'');
INSERT INTO PE_PE
	VALUES (946,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (946,
	0);
INSERT INTO A_ACT
	VALUES (946);
INSERT INTO A_AE
	VALUES (946);
INSERT INTO A_AEA
	VALUES (946,
	'Stop Sending Location',
	'');
INSERT INTO PE_PE
	VALUES (947,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (947,
	0);
INSERT INTO A_ACT
	VALUES (947);
INSERT INTO A_SS
	VALUES (947,
	'Establish Pace over Distance Goal',
	'');
INSERT INTO PE_PE
	VALUES (948,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (948,
	0);
INSERT INTO A_ACT
	VALUES (948);
INSERT INTO A_AE
	VALUES (948);
INSERT INTO A_AEA
	VALUES (948,
	'Establish Pace Over Distance Goal',
	'');
INSERT INTO PE_PE
	VALUES (949,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (949,
	0);
INSERT INTO A_ACT
	VALUES (949);
INSERT INTO A_GA
	VALUES (949,
	'Create Pace over Distance Goal',
	'');
INSERT INTO PE_PE
	VALUES (950,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (950,
	0);
INSERT INTO A_ACT
	VALUES (950);
INSERT INTO A_GA
	VALUES (950,
	'Periodically Determine Goal Disposition',
	'');
INSERT INTO PE_PE
	VALUES (951,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (951,
	0);
INSERT INTO A_ACT
	VALUES (951);
INSERT INTO A_SS
	VALUES (951,
	'Set Target',
	'');
INSERT INTO PE_PE
	VALUES (952,
	1,
	923,
	0,
	18);
INSERT INTO A_N
	VALUES (952,
	0);
INSERT INTO A_ACT
	VALUES (952);
INSERT INTO A_AE
	VALUES (952);
INSERT INTO A_AEA
	VALUES (952,
	'Set Target',
	'');
INSERT INTO PE_PE
	VALUES (953,
	1,
	923,
	0,
	11);
INSERT INTO A_AP
	VALUES (953,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (954,
	1,
	923,
	0,
	11);
INSERT INTO A_AP
	VALUES (954,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (955,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (955,
	0,
	'',
	'',
	927,
	928);
INSERT INTO PE_PE
	VALUES (956,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (956,
	0,
	'',
	'',
	931,
	927);
INSERT INTO PE_PE
	VALUES (957,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (957,
	0,
	'',
	'',
	933,
	930);
INSERT INTO PE_PE
	VALUES (958,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (958,
	0,
	'',
	'',
	933,
	929);
INSERT INTO PE_PE
	VALUES (959,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (959,
	0,
	'',
	'',
	932,
	933);
INSERT INTO PE_PE
	VALUES (960,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (960,
	0,
	'',
	'',
	935,
	934);
INSERT INTO PE_PE
	VALUES (961,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (961,
	0,
	'',
	'',
	929,
	931);
INSERT INTO PE_PE
	VALUES (962,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (962,
	0,
	'',
	'',
	930,
	931);
INSERT INTO PE_PE
	VALUES (963,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (963,
	0,
	'',
	'',
	934,
	931);
INSERT INTO PE_PE
	VALUES (964,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (964,
	0,
	'',
	'',
	937,
	936);
INSERT INTO PE_PE
	VALUES (965,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (965,
	0,
	'',
	'',
	939,
	938);
INSERT INTO PE_PE
	VALUES (966,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (966,
	0,
	'',
	'',
	940,
	938);
INSERT INTO PE_PE
	VALUES (967,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (967,
	0,
	'',
	'',
	941,
	938);
INSERT INTO PE_PE
	VALUES (968,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (968,
	0,
	'',
	'',
	942,
	935);
INSERT INTO PE_PE
	VALUES (969,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (969,
	0,
	'',
	'',
	944,
	943);
INSERT INTO PE_PE
	VALUES (970,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (970,
	0,
	'',
	'',
	943,
	942);
INSERT INTO PE_PE
	VALUES (971,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (971,
	0,
	'',
	'',
	946,
	941);
INSERT INTO PE_PE
	VALUES (972,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (972,
	0,
	'',
	'',
	938,
	937);
INSERT INTO PE_PE
	VALUES (973,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (973,
	0,
	'',
	'',
	948,
	947);
INSERT INTO PE_PE
	VALUES (974,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (974,
	0,
	'',
	'',
	949,
	948);
INSERT INTO PE_PE
	VALUES (975,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (975,
	0,
	'',
	'',
	945,
	944);
INSERT INTO PE_PE
	VALUES (976,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (976,
	0,
	'',
	'',
	952,
	951);
INSERT INTO PE_PE
	VALUES (977,
	1,
	923,
	0,
	12);
INSERT INTO A_E
	VALUES (977,
	0,
	'',
	'',
	950,
	952);
INSERT INTO PE_PE
	VALUES (978,
	1,
	536,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (978,
	0,
	1,
	'UC08___MultiGoalWorkoutWithFailureAndSuccess',
	'',
	0);
INSERT INTO PE_PE
	VALUES (979,
	1,
	978,
	0,
	14);
INSERT INTO SQ_P
	VALUES (979,
	0);
INSERT INTO IA_UCP
	VALUES (979,
	'UC08___MultiGoalWorkoutWithFailureAndSuccess',
	'Pre-conditions
	No Track logs exist on the device.
	Timer is stopped.
	Elapsed time is zero. 
	Accumulated distance is zero.
	Display shows elapsed time and accumulated distance.

Post-conditions
	A track log exists on the device.
	A pace over distance goal exists on the device.
	A heart rate over time goal exists on the device.
	A heart rate log exists on the device.
	An indication of when during the workout the active goal was being met exists on the device.
	Timer is stopped.
	Current heart rate and elapsed time are displayed.

Scenario
	1.  User establishes a goal for maintaining a bounded pace over a certain distance.
	2.	User establishes a goal for maintaining a bounded heart rate over a certain time period.
	3.	User pushes the start/stop button and begins moving (walking, running, flying, cycling, etc.).
	4.	The timer starts.
	5.  User pushes the Mode button until pace is displayed.
	6.	The display shows:
		a.	Current pace
		b.	Elapsed time
	7.	Periodically throughout the workout the device stores, in the active track log, 
	    the current location of the device.
	8.  Periodically throughout the workout, the device stores, in a log, 
		the heart rate of the user.
	9.	User pushes Set Target button.
	10.	Evaluation of the pace over distance goal starts.
	11. The device stores an indication of when during the workout the pace goal being met. 
	12.	The display shows:
		a.	Current pace
		b.	Elapsed time
		c.  An indication of whether the current goal is being met.
	13. After covering the distance of the pace goal, device switches to heart rate goal.
	14. Evaluation of the heart rate over time goal starts.
	15. User pushes the Mode button until heart rate is displayed.
	16. The display shows:
	    a.  Current heart rate
	    b.  Elapsed time
	    c.  An indication of whether the current goal is being met.
	15. The device stores an indication of when during the workout the heart rate goal is being met.
	16. When the specified time for the heart rate goal elapses the device stops evaluating goals.
	17.	User pushes the start/stop button.
	18.	The timer stops.
	19. The elapsed time, distance, and heart rate samples stop accumulating.

	');
INSERT INTO PE_PE
	VALUES (980,
	1,
	978,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (980,
	0,
	1,
	'ActivityDiagram',
	'',
	0);
INSERT INTO PE_PE
	VALUES (981,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (981,
	0);
INSERT INTO A_OBJ
	VALUES (981,
	'User',
	'');
INSERT INTO PE_PE
	VALUES (982,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (982,
	0);
INSERT INTO A_OBJ
	VALUES (982,
	'Application',
	'');
INSERT INTO PE_PE
	VALUES (983,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (983,
	0);
INSERT INTO A_OBJ
	VALUES (983,
	'GPS_Chipset',
	'');
INSERT INTO PE_PE
	VALUES (984,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (984,
	0);
INSERT INTO A_ACT
	VALUES (984);
INSERT INTO A_AE
	VALUES (984);
INSERT INTO A_AEA
	VALUES (984,
	'Start_Stop_Pushed',
	'');
INSERT INTO PE_PE
	VALUES (985,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (985,
	0);
INSERT INTO A_ACT
	VALUES (985);
INSERT INTO A_SS
	VALUES (985,
	'Start_Stop_Pushed',
	'');
INSERT INTO PE_PE
	VALUES (986,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (986,
	0);
INSERT INTO A_ACT
	VALUES (986);
INSERT INTO A_GA
	VALUES (986,
	'Start_Stopwatch',
	'');
INSERT INTO PE_PE
	VALUES (987,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (987,
	0);
INSERT INTO A_ACT
	VALUES (987);
INSERT INTO A_GA
	VALUES (987,
	'Start_Tracking_Location',
	'');
INSERT INTO PE_PE
	VALUES (988,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (988,
	0);
INSERT INTO A_CTL
	VALUES (988);
INSERT INTO A_FJ
	VALUES (988,
	'',
	'');
INSERT INTO PE_PE
	VALUES (989,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (989,
	0);
INSERT INTO A_ACT
	VALUES (989);
INSERT INTO A_GA
	VALUES (989,
	'Periodically_Update_Display',
	'In this case the display shows elapsed time and accumulated distance.');
INSERT INTO PE_PE
	VALUES (990,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (990,
	0);
INSERT INTO A_CTL
	VALUES (990);
INSERT INTO A_FJ
	VALUES (990,
	'',
	'');
INSERT INTO PE_PE
	VALUES (991,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (991,
	0);
INSERT INTO A_ACT
	VALUES (991);
INSERT INTO A_SS
	VALUES (991,
	'Start_Sending_Location',
	'');
INSERT INTO PE_PE
	VALUES (992,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (992,
	0);
INSERT INTO A_ACT
	VALUES (992);
INSERT INTO A_AE
	VALUES (992);
INSERT INTO A_AEA
	VALUES (992,
	'Start_Sending_Location',
	'');
INSERT INTO PE_PE
	VALUES (993,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (993,
	0);
INSERT INTO A_ACT
	VALUES (993);
INSERT INTO A_SS
	VALUES (993,
	'Start_Stop_Pushed',
	'');
INSERT INTO PE_PE
	VALUES (994,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (994,
	0);
INSERT INTO A_ACT
	VALUES (994);
INSERT INTO A_AE
	VALUES (994);
INSERT INTO A_AEA
	VALUES (994,
	'Start_Stop_Pushed',
	'');
INSERT INTO PE_PE
	VALUES (995,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (995,
	0);
INSERT INTO A_CTL
	VALUES (995);
INSERT INTO A_FJ
	VALUES (995,
	'',
	'');
INSERT INTO PE_PE
	VALUES (996,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (996,
	0);
INSERT INTO A_ACT
	VALUES (996);
INSERT INTO A_GA
	VALUES (996,
	'Stop_Stopwatch',
	'');
INSERT INTO PE_PE
	VALUES (997,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (997,
	0);
INSERT INTO A_ACT
	VALUES (997);
INSERT INTO A_GA
	VALUES (997,
	'Stop_Tracking_Location',
	'');
INSERT INTO PE_PE
	VALUES (998,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (998,
	0);
INSERT INTO A_ACT
	VALUES (998);
INSERT INTO A_SS
	VALUES (998,
	'Stop_Sending_Location',
	'');
INSERT INTO PE_PE
	VALUES (999,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (999,
	0);
INSERT INTO A_ACT
	VALUES (999);
INSERT INTO A_GA
	VALUES (999,
	'Periodically_Supply_Location',
	'');
INSERT INTO PE_PE
	VALUES (1000,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1000,
	0);
INSERT INTO A_ACT
	VALUES (1000);
INSERT INTO A_SS
	VALUES (1000,
	'Location',
	'');
INSERT INTO PE_PE
	VALUES (1001,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1001,
	0);
INSERT INTO A_ACT
	VALUES (1001);
INSERT INTO A_AE
	VALUES (1001);
INSERT INTO A_AEA
	VALUES (1001,
	'Location',
	'');
INSERT INTO PE_PE
	VALUES (1002,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1002,
	0);
INSERT INTO A_ACT
	VALUES (1002);
INSERT INTO A_GA
	VALUES (1002,
	'Calculate_Accumulated_Distance',
	'');
INSERT INTO PE_PE
	VALUES (1003,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1003,
	0);
INSERT INTO A_ACT
	VALUES (1003);
INSERT INTO A_AE
	VALUES (1003);
INSERT INTO A_AEA
	VALUES (1003,
	'Stop_Sending_Location',
	'');
INSERT INTO PE_PE
	VALUES (1004,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1004,
	0);
INSERT INTO A_ACT
	VALUES (1004);
INSERT INTO A_SS
	VALUES (1004,
	'Establish_Heart_Rate_Over_Time_Goal',
	'');
INSERT INTO PE_PE
	VALUES (1005,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1005,
	0);
INSERT INTO A_ACT
	VALUES (1005);
INSERT INTO A_AE
	VALUES (1005);
INSERT INTO A_AEA
	VALUES (1005,
	'Establish_Heart_Rate_Over_Time_Goal',
	'');
INSERT INTO PE_PE
	VALUES (1006,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1006,
	0);
INSERT INTO A_ACT
	VALUES (1006);
INSERT INTO A_GA
	VALUES (1006,
	'Create_Heart_Rate_over_Time_Goal',
	'');
INSERT INTO PE_PE
	VALUES (1007,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1007,
	0);
INSERT INTO A_ACT
	VALUES (1007);
INSERT INTO A_SS
	VALUES (1007,
	'Establish_Pace_over_Distance_Goal',
	'');
INSERT INTO PE_PE
	VALUES (1008,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1008,
	0);
INSERT INTO A_ACT
	VALUES (1008);
INSERT INTO A_AE
	VALUES (1008);
INSERT INTO A_AEA
	VALUES (1008,
	'Establish_Pace_Over_Distance_Goal',
	'');
INSERT INTO PE_PE
	VALUES (1009,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1009,
	0);
INSERT INTO A_ACT
	VALUES (1009);
INSERT INTO A_GA
	VALUES (1009,
	'Create_Pace_over_Distance_Goal',
	'');
INSERT INTO PE_PE
	VALUES (1010,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1010,
	0);
INSERT INTO A_ACT
	VALUES (1010);
INSERT INTO A_GA
	VALUES (1010,
	'Activate_Heart_Rate_Goal',
	'');
INSERT INTO PE_PE
	VALUES (1011,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1011,
	0);
INSERT INTO A_CTL
	VALUES (1011);
INSERT INTO A_DM
	VALUES (1011,
	'Distance for Pace Goal Exhausted?',
	'');
INSERT INTO PE_PE
	VALUES (1012,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1012,
	0);
INSERT INTO A_ACT
	VALUES (1012);
INSERT INTO A_GA
	VALUES (1012,
	'Stop_Tracking_Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (1013,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1013,
	0);
INSERT INTO A_ACT
	VALUES (1013);
INSERT INTO A_SS
	VALUES (1013,
	'Stop_Sending_Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (1014,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1014,
	0);
INSERT INTO A_ACT
	VALUES (1014);
INSERT INTO A_AE
	VALUES (1014);
INSERT INTO A_AEA
	VALUES (1014,
	'Stop_Sending_Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (1015,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1015,
	0);
INSERT INTO A_ACT
	VALUES (1015);
INSERT INTO A_GA
	VALUES (1015,
	'Start_Tracking_Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (1016,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1016,
	0);
INSERT INTO A_ACT
	VALUES (1016);
INSERT INTO A_SS
	VALUES (1016,
	'Start_Sending_Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (1017,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1017,
	0);
INSERT INTO A_OBJ
	VALUES (1017,
	'Heart_Rate_Chipset',
	'');
INSERT INTO PE_PE
	VALUES (1018,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1018,
	0);
INSERT INTO A_ACT
	VALUES (1018);
INSERT INTO A_AE
	VALUES (1018);
INSERT INTO A_AEA
	VALUES (1018,
	'Start_Sending_Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (1019,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1019,
	0);
INSERT INTO A_ACT
	VALUES (1019);
INSERT INTO A_GA
	VALUES (1019,
	'Periodically Supply  Heart Rate',
	'');
INSERT INTO PE_PE
	VALUES (1020,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1020,
	0);
INSERT INTO A_ACT
	VALUES (1020);
INSERT INTO A_SS
	VALUES (1020,
	'Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (1021,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1021,
	0);
INSERT INTO A_ACT
	VALUES (1021);
INSERT INTO A_AE
	VALUES (1021);
INSERT INTO A_AEA
	VALUES (1021,
	'Heart_Rate',
	'');
INSERT INTO PE_PE
	VALUES (1022,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1022,
	0);
INSERT INTO A_ACT
	VALUES (1022);
INSERT INTO A_GA
	VALUES (1022,
	'Periodically_Determine_Goal_Disposition',
	'');
INSERT INTO PE_PE
	VALUES (1023,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1023,
	0);
INSERT INTO A_ACT
	VALUES (1023);
INSERT INTO A_SS
	VALUES (1023,
	'Set_Target',
	'');
INSERT INTO PE_PE
	VALUES (1024,
	1,
	980,
	0,
	18);
INSERT INTO A_N
	VALUES (1024,
	0);
INSERT INTO A_ACT
	VALUES (1024);
INSERT INTO A_AE
	VALUES (1024);
INSERT INTO A_AEA
	VALUES (1024,
	'Set_Target',
	'');
INSERT INTO PE_PE
	VALUES (1025,
	1,
	980,
	0,
	11);
INSERT INTO A_AP
	VALUES (1025,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (1026,
	1,
	980,
	0,
	11);
INSERT INTO A_AP
	VALUES (1026,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (1027,
	1,
	980,
	0,
	11);
INSERT INTO A_AP
	VALUES (1027,
	0,
	'',
	'');
INSERT INTO PE_PE
	VALUES (1028,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1028,
	0,
	'',
	'',
	984,
	985);
INSERT INTO PE_PE
	VALUES (1029,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1029,
	0,
	'',
	'',
	988,
	984);
INSERT INTO PE_PE
	VALUES (1030,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1030,
	0,
	'',
	'',
	990,
	987);
INSERT INTO PE_PE
	VALUES (1031,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1031,
	0,
	'',
	'',
	990,
	986);
INSERT INTO PE_PE
	VALUES (1032,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1032,
	0,
	'',
	'',
	989,
	990);
INSERT INTO PE_PE
	VALUES (1033,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1033,
	0,
	'',
	'',
	992,
	991);
INSERT INTO PE_PE
	VALUES (1034,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1034,
	0,
	'',
	'',
	986,
	988);
INSERT INTO PE_PE
	VALUES (1035,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1035,
	0,
	'',
	'',
	987,
	988);
INSERT INTO PE_PE
	VALUES (1036,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1036,
	0,
	'',
	'',
	991,
	988);
INSERT INTO PE_PE
	VALUES (1037,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1037,
	0,
	'',
	'',
	994,
	993);
INSERT INTO PE_PE
	VALUES (1038,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1038,
	0,
	'',
	'',
	996,
	995);
INSERT INTO PE_PE
	VALUES (1039,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1039,
	0,
	'',
	'',
	997,
	995);
INSERT INTO PE_PE
	VALUES (1040,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1040,
	0,
	'',
	'',
	998,
	995);
INSERT INTO PE_PE
	VALUES (1041,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1041,
	0,
	'',
	'',
	999,
	992);
INSERT INTO PE_PE
	VALUES (1042,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1042,
	0,
	'',
	'',
	1001,
	1000);
INSERT INTO PE_PE
	VALUES (1043,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1043,
	0,
	'',
	'',
	1000,
	999);
INSERT INTO PE_PE
	VALUES (1044,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1044,
	0,
	'',
	'',
	1003,
	998);
INSERT INTO PE_PE
	VALUES (1045,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1045,
	0,
	'',
	'',
	995,
	994);
INSERT INTO PE_PE
	VALUES (1046,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1046,
	0,
	'',
	'',
	1005,
	1004);
INSERT INTO PE_PE
	VALUES (1047,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1047,
	0,
	'',
	'',
	1006,
	1005);
INSERT INTO PE_PE
	VALUES (1048,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1048,
	0,
	'',
	'',
	1008,
	1007);
INSERT INTO PE_PE
	VALUES (1049,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1049,
	0,
	'',
	'',
	1009,
	1008);
INSERT INTO PE_PE
	VALUES (1050,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1050,
	0,
	'',
	'',
	1012,
	995);
INSERT INTO PE_PE
	VALUES (1051,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1051,
	0,
	'',
	'',
	1014,
	1013);
INSERT INTO PE_PE
	VALUES (1052,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1052,
	0,
	'',
	'',
	1015,
	988);
INSERT INTO PE_PE
	VALUES (1053,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1053,
	0,
	'',
	'',
	990,
	1015);
INSERT INTO PE_PE
	VALUES (1054,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1054,
	0,
	'',
	'',
	1019,
	1018);
INSERT INTO PE_PE
	VALUES (1055,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1055,
	0,
	'',
	'',
	1020,
	1019);
INSERT INTO PE_PE
	VALUES (1056,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1056,
	0,
	'',
	'',
	1021,
	1020);
INSERT INTO PE_PE
	VALUES (1057,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1057,
	0,
	'',
	'',
	1016,
	988);
INSERT INTO PE_PE
	VALUES (1058,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1058,
	0,
	'',
	'',
	1018,
	1016);
INSERT INTO PE_PE
	VALUES (1059,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1059,
	0,
	'',
	'',
	1011,
	1002);
INSERT INTO PE_PE
	VALUES (1060,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1060,
	0,
	'',
	'',
	1010,
	1011);
INSERT INTO PE_PE
	VALUES (1061,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1061,
	0,
	'',
	'',
	1022,
	1024);
INSERT INTO PE_PE
	VALUES (1062,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1062,
	0,
	'',
	'',
	1024,
	1023);
INSERT INTO PE_PE
	VALUES (1063,
	1,
	980,
	0,
	12);
INSERT INTO A_E
	VALUES (1063,
	0,
	'',
	'',
	1002,
	1001);
INSERT INTO PE_PE
	VALUES (1064,
	1,
	536,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (1064,
	0,
	1,
	'Overview',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1065,
	1,
	1064,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1065,
	0);
INSERT INTO IA_UCP
	VALUES (1065,
	'UC01 - SimpleWorkout',
	'');
INSERT INTO PE_PE
	VALUES (1066,
	1,
	1064,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1066,
	0);
INSERT INTO IA_UCP
	VALUES (1066,
	'UC02 - ClearLogs',
	'');
INSERT INTO PE_PE
	VALUES (1067,
	1,
	1064,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1067,
	0);
INSERT INTO UC_UCA
	VALUES (1068,
	1067,
	1065);
INSERT INTO UC_E
	VALUES (1068,
	'');
INSERT INTO IA_UCP
	VALUES (1067,
	'UC03 - Multi-lapWorkout',
	'');
INSERT INTO PE_PE
	VALUES (1069,
	1,
	1064,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1069,
	0);
INSERT INTO UC_UCA
	VALUES (1070,
	1069,
	1065);
INSERT INTO UC_I
	VALUES (1070,
	'');
INSERT INTO IA_UCP
	VALUES (1069,
	'UC04 - WorkoutWithPause',
	'');
INSERT INTO PE_PE
	VALUES (1071,
	1,
	1064,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1071,
	0);
INSERT INTO IA_UCP
	VALUES (1071,
	'UC05 - AchievingPaceOverDistanceGoal',
	'');
INSERT INTO PE_PE
	VALUES (1072,
	1,
	1064,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1072,
	0);
INSERT INTO IA_UCP
	VALUES (1072,
	'UC06 - AchievingHeartRateOverTimeGoal',
	'');
INSERT INTO PE_PE
	VALUES (1073,
	1,
	1064,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1073,
	0);
INSERT INTO IA_UCP
	VALUES (1073,
	'UC07 - FailingPaceOverDistanceGoal',
	'');
INSERT INTO PE_PE
	VALUES (1074,
	1,
	1064,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1074,
	0);
INSERT INTO UC_UCA
	VALUES (1075,
	1074,
	1072);
INSERT INTO UC_I
	VALUES (1075,
	'');
INSERT INTO UC_UCA
	VALUES (1076,
	1074,
	1071);
INSERT INTO UC_E
	VALUES (1076,
	'');
INSERT INTO IA_UCP
	VALUES (1074,
	'UC08 - MultiGoalWorkoutWithFailureAndSuccess',
	'');
INSERT INTO PE_PE
	VALUES (1077,
	1,
	1064,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1077,
	0);
INSERT INTO SQ_AP
	VALUES (1077,
	'User',
	'',
	0);
INSERT INTO UC_UCA
	VALUES (1078,
	1077,
	1066);
INSERT INTO UC_BA
	VALUES (1078,
	'');
INSERT INTO UC_UCA
	VALUES (1079,
	1077,
	1067);
INSERT INTO UC_BA
	VALUES (1079,
	'');
INSERT INTO UC_UCA
	VALUES (1080,
	1077,
	1069);
INSERT INTO UC_BA
	VALUES (1080,
	'');
INSERT INTO UC_UCA
	VALUES (1081,
	1077,
	1074);
INSERT INTO UC_BA
	VALUES (1081,
	'');
INSERT INTO UC_UCA
	VALUES (1082,
	1077,
	1073);
INSERT INTO UC_BA
	VALUES (1082,
	'');
INSERT INTO PE_PE
	VALUES (1078,
	1,
	1064,
	0,
	16);
INSERT INTO PE_PE
	VALUES (1079,
	1,
	1064,
	0,
	16);
INSERT INTO PE_PE
	VALUES (1080,
	1,
	1064,
	0,
	16);
INSERT INTO PE_PE
	VALUES (1068,
	1,
	1064,
	0,
	14);
INSERT INTO PE_PE
	VALUES (1070,
	1,
	1064,
	0,
	16);
INSERT INTO PE_PE
	VALUES (1075,
	1,
	1064,
	0,
	16);
INSERT INTO PE_PE
	VALUES (1076,
	1,
	1064,
	0,
	14);
INSERT INTO PE_PE
	VALUES (1081,
	1,
	1064,
	0,
	16);
INSERT INTO PE_PE
	VALUES (1082,
	1,
	1064,
	0,
	16);
INSERT INTO PE_PE
	VALUES (1083,
	1,
	498,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (1083,
	0,
	1,
	'Sequences',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1084,
	1,
	1083,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (1084,
	0,
	1,
	'Stopwatch',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1085,
	1,
	1084,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1085,
	0);
INSERT INTO SQ_AP
	VALUES (1085,
	'User',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1086,
	1,
	1084,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1086,
	0);
INSERT INTO SQ_COP
	VALUES (1086,
	448,
	'UI::UI::UI',
	'Informal Component',
	'',
	1);
INSERT INTO PE_PE
	VALUES (1087,
	1,
	1084,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1087,
	0);
INSERT INTO SQ_COP
	VALUES (1087,
	459,
	'Tracking::Tracking::Tracking',
	'Informal Component',
	'',
	1);
INSERT INTO PE_PE
	VALUES (1088,
	1,
	1084,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1088,
	0);
INSERT INTO SQ_LS
	VALUES (1088,
	1085,
	'',
	0);
INSERT INTO PE_PE
	VALUES (1089,
	1,
	1084,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1089,
	0);
INSERT INTO SQ_LS
	VALUES (1089,
	1086,
	'',
	0);
INSERT INTO PE_PE
	VALUES (1090,
	1,
	1084,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1090,
	0);
INSERT INTO SQ_LS
	VALUES (1090,
	1087,
	'',
	0);
INSERT INTO PE_PE
	VALUES (1091,
	1,
	1084,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1091,
	0);
INSERT INTO SQ_EEP
	VALUES (1091,
	0,
	'GUI_Bridge_EE',
	'GUI_Bridge_EE',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1092,
	1,
	1084,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1092,
	0);
INSERT INTO MSG_M
	VALUES (1093,
	1089,
	1092,
	0);
INSERT INTO MSG_SM
	VALUES (1093,
	'setTime_0_',
	'',
	'',
	'',
	'',
	0,
	'setTime_0_',
	'');
INSERT INTO MSG_ISM
	VALUES (1093);
INSERT INTO MSG_M
	VALUES (1094,
	1089,
	1092,
	0);
INSERT INTO MSG_SM
	VALUES (1094,
	'setTime__new_time__',
	'',
	'',
	'',
	'',
	0,
	'setTime__new_time__',
	'');
INSERT INTO MSG_ISM
	VALUES (1094);
INSERT INTO SQ_LS
	VALUES (1092,
	1091,
	'',
	0);
INSERT INTO PE_PE
	VALUES (1095,
	1,
	1084,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1095,
	0);
INSERT INTO SQ_CP
	VALUES (1095,
	0,
	'Tracking::WorkoutTimer',
	'Tracking::WorkoutTimer',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1096,
	1,
	1084,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1096,
	0);
INSERT INTO MSG_M
	VALUES (1097,
	1090,
	1096,
	0);
INSERT INTO MSG_AM
	VALUES (1097,
	'startStopPressed_event',
	'',
	'',
	'',
	'',
	0,
	'startStopPressed_event',
	'');
INSERT INTO MSG_IAM
	VALUES (1097);
INSERT INTO MSG_M
	VALUES (1098,
	1096,
	1096,
	0);
INSERT INTO MSG_AM
	VALUES (1098,
	'tick',
	'',
	'',
	'',
	'',
	0,
	'tick',
	'');
INSERT INTO MSG_IAM
	VALUES (1098);
INSERT INTO SQ_LS
	VALUES (1096,
	1095,
	'',
	0);
INSERT INTO SQ_TM
	VALUES (1099,
	'',
	1096,
	'');
INSERT INTO SQ_TS
	VALUES (1100,
	1101,
	1099,
	'1 second ticking loop',
	'');
INSERT INTO SQ_TM
	VALUES (1101,
	'',
	1096,
	'');
INSERT INTO PE_PE
	VALUES (1093,
	1,
	1084,
	0,
	17);
INSERT INTO PE_PE
	VALUES (1094,
	1,
	1084,
	0,
	17);
INSERT INTO PE_PE
	VALUES (1097,
	1,
	1084,
	0,
	17);
INSERT INTO PE_PE
	VALUES (1098,
	1,
	1084,
	0,
	17);
INSERT INTO PE_PE
	VALUES (1102,
	1,
	1083,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (1102,
	0,
	1,
	'Start_Stop_Reset_Formalized',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1103,
	1,
	1102,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1103,
	0);
INSERT INTO SQ_AP
	VALUES (1103,
	'User',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1104,
	1,
	1102,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1104,
	0);
INSERT INTO SQ_COP
	VALUES (1104,
	448,
	'UI::UI::UI',
	'Informal Component',
	'',
	1);
INSERT INTO PE_PE
	VALUES (1105,
	1,
	1102,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1105,
	0);
INSERT INTO SQ_COP
	VALUES (1105,
	459,
	'Tracking::Tracking::Tracking',
	'Informal Component',
	'',
	1);
INSERT INTO PE_PE
	VALUES (1106,
	1,
	1102,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1106,
	0);
INSERT INTO SQ_COP
	VALUES (1106,
	492,
	'Location::Location::Location',
	'Informal Component',
	'',
	1);
INSERT INTO PE_PE
	VALUES (1107,
	1,
	1102,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1107,
	0);
INSERT INTO SQ_COP
	VALUES (1107,
	481,
	'HeartRateMonitor::HeartRateMonitor::HeartRateMonitor',
	'Informal Component',
	'',
	1);
INSERT INTO PE_PE
	VALUES (1108,
	1,
	1102,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1108,
	0);
INSERT INTO SQ_LS
	VALUES (1108,
	1103,
	'',
	0);
INSERT INTO PE_PE
	VALUES (1109,
	1,
	1102,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1109,
	0);
INSERT INTO SQ_LS
	VALUES (1109,
	1104,
	'',
	0);
INSERT INTO PE_PE
	VALUES (1110,
	1,
	1102,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1110,
	0);
INSERT INTO SQ_LS
	VALUES (1110,
	1105,
	'',
	0);
INSERT INTO SQ_TM
	VALUES (1111,
	'Clear track and reset all cached values',
	1110,
	'');
INSERT INTO PE_PE
	VALUES (1112,
	1,
	1102,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1112,
	0);
INSERT INTO SQ_LS
	VALUES (1112,
	1106,
	'',
	0);
INSERT INTO SQ_TM
	VALUES (1113,
	'',
	1112,
	'');
INSERT INTO SQ_TS
	VALUES (1114,
	1115,
	1113,
	'Provide updates to client every 2 seconds',
	'');
INSERT INTO SQ_TM
	VALUES (1115,
	'',
	1112,
	'');
INSERT INTO PE_PE
	VALUES (1116,
	1,
	1102,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1116,
	0);
INSERT INTO SQ_LS
	VALUES (1116,
	1107,
	'',
	0);
INSERT INTO SQ_TM
	VALUES (1117,
	'',
	1116,
	'');
INSERT INTO SQ_TS
	VALUES (1118,
	1119,
	1117,
	'Provide updates to clients every 3 seconds',
	'');
INSERT INTO SQ_TM
	VALUES (1119,
	'',
	1116,
	'');
INSERT INTO PE_PE
	VALUES (1120,
	1,
	1083,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (1120,
	0,
	1,
	'Backlight',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1121,
	1,
	1120,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1121,
	0);
INSERT INTO SQ_AP
	VALUES (1121,
	'User',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1122,
	1,
	1120,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1122,
	0);
INSERT INTO SQ_COP
	VALUES (1122,
	448,
	'UI::UI::UI',
	'Informal Component',
	'',
	1);
INSERT INTO PE_PE
	VALUES (1123,
	1,
	1120,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1123,
	0);
INSERT INTO SQ_EEP
	VALUES (1123,
	0,
	'Graphical_User_Interface_EE',
	'Graphical_User_Interface_EE',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1124,
	1,
	1120,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1124,
	0);
INSERT INTO SQ_LS
	VALUES (1124,
	1121,
	'',
	0);
INSERT INTO PE_PE
	VALUES (1125,
	1,
	1120,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1125,
	0);
INSERT INTO SQ_LS
	VALUES (1125,
	1122,
	'',
	0);
INSERT INTO SQ_TM
	VALUES (1126,
	'',
	1125,
	'');
INSERT INTO PE_PE
	VALUES (1127,
	1,
	1120,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1127,
	0);
INSERT INTO MSG_M
	VALUES (1128,
	1125,
	1127,
	0);
INSERT INTO MSG_AM
	VALUES (1128,
	'feedLightPressedEvent(evt)',
	'',
	'',
	'',
	'',
	0,
	'feedLightPressedEvent(evt)',
	'');
INSERT INTO MSG_IAM
	VALUES (1128);
INSERT INTO SQ_LS
	VALUES (1127,
	1123,
	'',
	0);
INSERT INTO SQ_TM
	VALUES (1129,
	'',
	1127,
	'');
INSERT INTO SQ_TS
	VALUES (1130,
	1131,
	1129,
	'Turns on backlight, sets 5 second timer, when it expires, turns off backlight',
	'');
INSERT INTO SQ_TM
	VALUES (1131,
	'',
	1127,
	'');
INSERT INTO PE_PE
	VALUES (1128,
	1,
	1120,
	0,
	17);
INSERT INTO PE_PE
	VALUES (1132,
	1,
	498,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (1132,
	0,
	1,
	'Use_Cases',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1133,
	1,
	1132,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1133,
	0);
INSERT INTO SQ_AP
	VALUES (1133,
	'Runner',
	'',
	0);
INSERT INTO UC_UCA
	VALUES (1134,
	1133,
	1135);
INSERT INTO PE_PE
	VALUES (1135,
	1,
	1132,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1135,
	0);
INSERT INTO UC_UCA
	VALUES (1136,
	1135,
	1137);
INSERT INTO IA_UCP
	VALUES (1135,
	'Perform_exercise_routine',
	'');
INSERT INTO PE_PE
	VALUES (1137,
	1,
	1132,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1137,
	0);
INSERT INTO IA_UCP
	VALUES (1137,
	'Record_Info',
	'');
INSERT INTO PE_PE
	VALUES (1134,
	1,
	1132,
	0,
	16);
INSERT INTO PE_PE
	VALUES (1136,
	1,
	1132,
	0,
	16);
INSERT INTO PE_PE
	VALUES (1138,
	1,
	1132,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (1138,
	0,
	1,
	'Record_Info',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1139,
	1,
	1138,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1139,
	0);
INSERT INTO SQ_AP
	VALUES (1139,
	'Data Recorder',
	'',
	0);
INSERT INTO UC_UCA
	VALUES (1140,
	1139,
	1141);
INSERT INTO PE_PE
	VALUES (1141,
	1,
	1138,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1141,
	0);
INSERT INTO UC_UCA
	VALUES (1142,
	1141,
	1143);
INSERT INTO UC_UCA
	VALUES (1144,
	1141,
	1145);
INSERT INTO UC_UCA
	VALUES (1146,
	1141,
	1147);
INSERT INTO IA_UCP
	VALUES (1141,
	'Store_information',
	'');
INSERT INTO PE_PE
	VALUES (1143,
	1,
	1138,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1143,
	0);
INSERT INTO IA_UCP
	VALUES (1143,
	'Retrieve heart rate',
	'');
INSERT INTO PE_PE
	VALUES (1145,
	1,
	1138,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1145,
	0);
INSERT INTO IA_UCP
	VALUES (1145,
	'Retrieve_location',
	'');
INSERT INTO PE_PE
	VALUES (1147,
	1,
	1138,
	0,
	14);
INSERT INTO SQ_P
	VALUES (1147,
	0);
INSERT INTO IA_UCP
	VALUES (1147,
	'Retrieve_time',
	'');
INSERT INTO PE_PE
	VALUES (1140,
	1,
	1138,
	0,
	16);
INSERT INTO PE_PE
	VALUES (1142,
	1,
	1138,
	0,
	16);
INSERT INTO PE_PE
	VALUES (1144,
	1,
	1138,
	0,
	16);
INSERT INTO PE_PE
	VALUES (1146,
	1,
	1138,
	0,
	16);
INSERT INTO PE_PE
	VALUES (1148,
	1,
	498,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (1148,
	0,
	1,
	'Activities',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1149,
	1,
	1148,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (1149,
	0,
	1,
	'Exercise',
	'This activity expands on the generic use case: Perform exercise routine.',
	0);
INSERT INTO PE_PE
	VALUES (1150,
	1,
	1149,
	0,
	18);
INSERT INTO A_N
	VALUES (1150,
	0);
INSERT INTO A_CTL
	VALUES (1150);
INSERT INTO A_INI
	VALUES (1150,
	'');
INSERT INTO PE_PE
	VALUES (1151,
	1,
	1149,
	0,
	18);
INSERT INTO A_N
	VALUES (1151,
	0);
INSERT INTO A_ACT
	VALUES (1151);
INSERT INTO A_GA
	VALUES (1151,
	'Record_heart_rate',
	'');
INSERT INTO PE_PE
	VALUES (1152,
	1,
	1149,
	0,
	18);
INSERT INTO A_N
	VALUES (1152,
	0);
INSERT INTO A_ACT
	VALUES (1152);
INSERT INTO A_GA
	VALUES (1152,
	'Record_location',
	'');
INSERT INTO PE_PE
	VALUES (1153,
	1,
	1149,
	0,
	18);
INSERT INTO A_N
	VALUES (1153,
	0);
INSERT INTO A_ACT
	VALUES (1153);
INSERT INTO A_GA
	VALUES (1153,
	'Record_time',
	'');
INSERT INTO PE_PE
	VALUES (1154,
	1,
	1149,
	0,
	18);
INSERT INTO A_N
	VALUES (1154,
	0);
INSERT INTO A_ACT
	VALUES (1154);
INSERT INTO A_GA
	VALUES (1154,
	'Update_display',
	'');
INSERT INTO PE_PE
	VALUES (1155,
	1,
	1149,
	0,
	18);
INSERT INTO A_N
	VALUES (1155,
	0);
INSERT INTO A_ACT
	VALUES (1155);
INSERT INTO A_GA
	VALUES (1155,
	'Turn_on_Backlight_for_5_seconds',
	'');
INSERT INTO PE_PE
	VALUES (1156,
	1,
	1149,
	0,
	18);
INSERT INTO A_N
	VALUES (1156,
	0);
INSERT INTO A_CTL
	VALUES (1156);
INSERT INTO A_FJ
	VALUES (1156,
	'',
	'');
INSERT INTO PE_PE
	VALUES (1157,
	1,
	1149,
	0,
	18);
INSERT INTO A_N
	VALUES (1157,
	0);
INSERT INTO A_ACT
	VALUES (1157);
INSERT INTO A_GA
	VALUES (1157,
	'Cycle_to_next_display_mode',
	'');
INSERT INTO PE_PE
	VALUES (1158,
	1,
	1149,
	0,
	18);
INSERT INTO A_N
	VALUES (1158,
	0);
INSERT INTO A_ACT
	VALUES (1158);
INSERT INTO A_GA
	VALUES (1158,
	'Update_display',
	'');
INSERT INTO PE_PE
	VALUES (1159,
	1,
	1149,
	0,
	18);
INSERT INTO A_N
	VALUES (1159,
	0);
INSERT INTO A_CTL
	VALUES (1159);
INSERT INTO A_DM
	VALUES (1159,
	'already running?',
	'');
INSERT INTO PE_PE
	VALUES (1160,
	1,
	1149,
	0,
	18);
INSERT INTO A_N
	VALUES (1160,
	0);
INSERT INTO A_ACT
	VALUES (1160);
INSERT INTO A_GA
	VALUES (1160,
	'Reset_display_to_zero',
	'');
INSERT INTO PE_PE
	VALUES (1161,
	1,
	1149,
	0,
	18);
INSERT INTO A_N
	VALUES (1161,
	0);
INSERT INTO A_ACT
	VALUES (1161);
INSERT INTO A_GA
	VALUES (1161,
	'Stop_Recording',
	'');
INSERT INTO PE_PE
	VALUES (1162,
	1,
	1149,
	0,
	18);
INSERT INTO A_N
	VALUES (1162,
	0);
INSERT INTO A_CTL
	VALUES (1162);
INSERT INTO A_FJ
	VALUES (1162,
	'',
	'');
INSERT INTO PE_PE
	VALUES (1163,
	1,
	1149,
	0,
	18);
INSERT INTO A_N
	VALUES (1163,
	0);
INSERT INTO A_ACT
	VALUES (1163);
INSERT INTO A_GA
	VALUES (1163,
	'Idle_wait',
	'');
INSERT INTO PE_PE
	VALUES (1164,
	1,
	1149,
	0,
	18);
INSERT INTO A_N
	VALUES (1164,
	0);
INSERT INTO A_CTL
	VALUES (1164);
INSERT INTO A_FJ
	VALUES (1164,
	'',
	'');
INSERT INTO PE_PE
	VALUES (1165,
	1,
	1149,
	0,
	18);
INSERT INTO A_N
	VALUES (1165,
	0);
INSERT INTO A_CTL
	VALUES (1165);
INSERT INTO A_FJ
	VALUES (1165,
	'',
	'');
INSERT INTO PE_PE
	VALUES (1166,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1166,
	0,
	'',
	'',
	1156,
	1155);
INSERT INTO PE_PE
	VALUES (1167,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1167,
	0,
	'',
	'',
	1158,
	1157);
INSERT INTO PE_PE
	VALUES (1168,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1168,
	0,
	'',
	'',
	1156,
	1158);
INSERT INTO PE_PE
	VALUES (1169,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1169,
	0,
	'backlight button pressed',
	'',
	1155,
	1156);
INSERT INTO PE_PE
	VALUES (1170,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1170,
	0,
	'mode button pressed',
	'',
	1157,
	1156);
INSERT INTO PE_PE
	VALUES (1171,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1171,
	0,
	'start/stop pressed',
	'',
	1159,
	1156);
INSERT INTO PE_PE
	VALUES (1172,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1172,
	0,
	'no',
	'',
	1162,
	1159);
INSERT INTO PE_PE
	VALUES (1173,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1173,
	0,
	'',
	'',
	1163,
	1154);
INSERT INTO PE_PE
	VALUES (1174,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1174,
	0,
	'',
	'',
	1154,
	1164);
INSERT INTO PE_PE
	VALUES (1175,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1175,
	0,
	'',
	'',
	1164,
	1151);
INSERT INTO PE_PE
	VALUES (1176,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1176,
	0,
	'',
	'',
	1164,
	1152);
INSERT INTO PE_PE
	VALUES (1177,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1177,
	0,
	'',
	'',
	1164,
	1153);
INSERT INTO PE_PE
	VALUES (1178,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1178,
	0,
	'',
	'',
	1151,
	1162);
INSERT INTO PE_PE
	VALUES (1179,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1179,
	0,
	'',
	'',
	1152,
	1162);
INSERT INTO PE_PE
	VALUES (1180,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1180,
	0,
	'',
	'',
	1153,
	1162);
INSERT INTO PE_PE
	VALUES (1181,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1181,
	0,
	'yes',
	'',
	1161,
	1159);
INSERT INTO PE_PE
	VALUES (1182,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1182,
	0,
	'',
	'',
	1156,
	1161);
INSERT INTO PE_PE
	VALUES (1183,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1183,
	0,
	'',
	'',
	1156,
	1160);
INSERT INTO PE_PE
	VALUES (1184,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1184,
	0,
	'lap/reset pressed',
	'',
	1160,
	1156);
INSERT INTO PE_PE
	VALUES (1185,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1185,
	0,
	'',
	'',
	1156,
	1150);
INSERT INTO PE_PE
	VALUES (1186,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1186,
	0,
	'timer tick',
	'',
	1165,
	1163);
INSERT INTO PE_PE
	VALUES (1187,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1187,
	0,
	'',
	'',
	1162,
	1165);
INSERT INTO PE_PE
	VALUES (1188,
	1,
	1149,
	0,
	12);
INSERT INTO A_E
	VALUES (1188,
	0,
	'',
	'',
	1156,
	1165);
INSERT INTO EP_PKG
	VALUES (1189,
	1,
	1,
	'Shared_EEs',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1190,
	1,
	1189,
	0,
	5);
INSERT INTO S_EE
	VALUES (1190,
	'Architecture',
	'',
	'ARCH',
	0,
	'',
	'Architecture',
	1);
INSERT INTO S_BRG
	VALUES (1191,
	1190,
	'shutdown',
	'',
	0,
	1192,
	'control stop;',
	1,
	'',
	0);
INSERT INTO ACT_BRB
	VALUES (1193,
	1191);
INSERT INTO ACT_ACT
	VALUES (1193,
	'bridge',
	0,
	1194,
	0,
	0,
	'Architecture::shutdown',
	0);
INSERT INTO ACT_BLK
	VALUES (1194,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1193,
	0);
INSERT INTO ACT_SMT
	VALUES (1195,
	1194,
	0,
	1,
	1,
	'Architecture::shutdown line: 1');
INSERT INTO ACT_CTL
	VALUES (1195);
INSERT INTO PE_PE
	VALUES (1196,
	1,
	1189,
	0,
	5);
INSERT INTO S_EE
	VALUES (1196,
	'Logging',
	'',
	'LOG',
	0,
	'',
	'Logging',
	1);
INSERT INTO S_BRG
	VALUES (1197,
	1196,
	'LogSuccess',
	'',
	0,
	1192,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1198,
	1197,
	'message',
	1199,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1200,
	1197);
INSERT INTO ACT_ACT
	VALUES (1200,
	'bridge',
	0,
	1201,
	0,
	0,
	'Logging::LogSuccess',
	0);
INSERT INTO ACT_BLK
	VALUES (1201,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1200,
	0);
INSERT INTO S_BRG
	VALUES (1202,
	1196,
	'LogFailure',
	'',
	0,
	1192,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1203,
	1202,
	'message',
	1199,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1204,
	1202);
INSERT INTO ACT_ACT
	VALUES (1204,
	'bridge',
	0,
	1205,
	0,
	0,
	'Logging::LogFailure',
	0);
INSERT INTO ACT_BLK
	VALUES (1205,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1204,
	0);
INSERT INTO S_BRG
	VALUES (1206,
	1196,
	'LogInfo',
	'',
	0,
	1192,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1207,
	1206,
	'message',
	1199,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1208,
	1206);
INSERT INTO ACT_ACT
	VALUES (1208,
	'bridge',
	0,
	1209,
	0,
	0,
	'Logging::LogInfo',
	0);
INSERT INTO ACT_BLK
	VALUES (1209,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1208,
	0);
INSERT INTO S_BRG
	VALUES (1210,
	1196,
	'LogDate',
	'',
	0,
	1192,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1211,
	1210,
	'd',
	1212,
	0,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (1213,
	1210,
	'message',
	1199,
	0,
	'',
	1211,
	'');
INSERT INTO ACT_BRB
	VALUES (1214,
	1210);
INSERT INTO ACT_ACT
	VALUES (1214,
	'bridge',
	0,
	1215,
	0,
	0,
	'Logging::LogDate',
	0);
INSERT INTO ACT_BLK
	VALUES (1215,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1214,
	0);
INSERT INTO S_BRG
	VALUES (1216,
	1196,
	'LogTime',
	'',
	0,
	1192,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1217,
	1216,
	't',
	1218,
	0,
	'',
	1219,
	'');
INSERT INTO S_BPARM
	VALUES (1219,
	1216,
	'message',
	1199,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1220,
	1216);
INSERT INTO ACT_ACT
	VALUES (1220,
	'bridge',
	0,
	1221,
	0,
	0,
	'Logging::LogTime',
	0);
INSERT INTO ACT_BLK
	VALUES (1221,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1220,
	0);
INSERT INTO S_BRG
	VALUES (1222,
	1196,
	'LogReal',
	'',
	0,
	1192,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1223,
	1222,
	'r',
	153,
	0,
	'',
	1224,
	'');
INSERT INTO S_BPARM
	VALUES (1224,
	1222,
	'message',
	1199,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1225,
	1222);
INSERT INTO ACT_ACT
	VALUES (1225,
	'bridge',
	0,
	1226,
	0,
	0,
	'Logging::LogReal',
	0);
INSERT INTO ACT_BLK
	VALUES (1226,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1225,
	0);
INSERT INTO S_BRG
	VALUES (1227,
	1196,
	'LogInteger',
	'',
	0,
	1192,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1228,
	1227,
	'message',
	160,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1229,
	1227);
INSERT INTO ACT_ACT
	VALUES (1229,
	'bridge',
	0,
	1230,
	0,
	0,
	'Logging::LogInteger',
	0);
INSERT INTO ACT_BLK
	VALUES (1230,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1229,
	0);
INSERT INTO PE_PE
	VALUES (1231,
	1,
	1189,
	0,
	5);
INSERT INTO S_EE
	VALUES (1231,
	'Time',
	'The Time external entity provides date, timestamp, and timer related operations.',
	'TIM',
	0,
	'',
	'Time',
	1);
INSERT INTO S_BRG
	VALUES (1232,
	1231,
	'current_date',
	'',
	1,
	1212,
	'',
	1,
	'',
	0);
INSERT INTO ACT_BRB
	VALUES (1233,
	1232);
INSERT INTO ACT_ACT
	VALUES (1233,
	'bridge',
	0,
	1234,
	0,
	0,
	'Time::current_date',
	0);
INSERT INTO ACT_BLK
	VALUES (1234,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1233,
	0);
INSERT INTO S_BRG
	VALUES (1235,
	1231,
	'create_date',
	'',
	1,
	1212,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1236,
	1235,
	'second',
	160,
	0,
	'',
	1237,
	'');
INSERT INTO S_BPARM
	VALUES (1238,
	1235,
	'minute',
	160,
	0,
	'',
	1239,
	'');
INSERT INTO S_BPARM
	VALUES (1239,
	1235,
	'hour',
	160,
	0,
	'',
	1240,
	'');
INSERT INTO S_BPARM
	VALUES (1240,
	1235,
	'day',
	160,
	0,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (1237,
	1235,
	'month',
	160,
	0,
	'',
	1238,
	'');
INSERT INTO S_BPARM
	VALUES (1241,
	1235,
	'year',
	160,
	0,
	'',
	1236,
	'');
INSERT INTO ACT_BRB
	VALUES (1242,
	1235);
INSERT INTO ACT_ACT
	VALUES (1242,
	'bridge',
	0,
	1243,
	0,
	0,
	'Time::create_date',
	0);
INSERT INTO ACT_BLK
	VALUES (1243,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1242,
	0);
INSERT INTO S_BRG
	VALUES (1244,
	1231,
	'get_second',
	'',
	1,
	160,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1245,
	1244,
	'date',
	1212,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1246,
	1244);
INSERT INTO ACT_ACT
	VALUES (1246,
	'bridge',
	0,
	1247,
	0,
	0,
	'Time::get_second',
	0);
INSERT INTO ACT_BLK
	VALUES (1247,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1246,
	0);
INSERT INTO S_BRG
	VALUES (1248,
	1231,
	'get_minute',
	'',
	1,
	160,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1249,
	1248,
	'date',
	1212,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1250,
	1248);
INSERT INTO ACT_ACT
	VALUES (1250,
	'bridge',
	0,
	1251,
	0,
	0,
	'Time::get_minute',
	0);
INSERT INTO ACT_BLK
	VALUES (1251,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1250,
	0);
INSERT INTO S_BRG
	VALUES (1252,
	1231,
	'get_hour',
	'',
	1,
	160,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1253,
	1252,
	'date',
	1212,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1254,
	1252);
INSERT INTO ACT_ACT
	VALUES (1254,
	'bridge',
	0,
	1255,
	0,
	0,
	'Time::get_hour',
	0);
INSERT INTO ACT_BLK
	VALUES (1255,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1254,
	0);
INSERT INTO S_BRG
	VALUES (1256,
	1231,
	'get_day',
	'',
	1,
	160,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1257,
	1256,
	'date',
	1212,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1258,
	1256);
INSERT INTO ACT_ACT
	VALUES (1258,
	'bridge',
	0,
	1259,
	0,
	0,
	'Time::get_day',
	0);
INSERT INTO ACT_BLK
	VALUES (1259,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1258,
	0);
INSERT INTO S_BRG
	VALUES (1260,
	1231,
	'get_month',
	'',
	1,
	160,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1261,
	1260,
	'date',
	1212,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1262,
	1260);
INSERT INTO ACT_ACT
	VALUES (1262,
	'bridge',
	0,
	1263,
	0,
	0,
	'Time::get_month',
	0);
INSERT INTO ACT_BLK
	VALUES (1263,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1262,
	0);
INSERT INTO S_BRG
	VALUES (1264,
	1231,
	'get_year',
	'',
	1,
	160,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1265,
	1264,
	'date',
	1212,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1266,
	1264);
INSERT INTO ACT_ACT
	VALUES (1266,
	'bridge',
	0,
	1267,
	0,
	0,
	'Time::get_year',
	0);
INSERT INTO ACT_BLK
	VALUES (1267,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1266,
	0);
INSERT INTO S_BRG
	VALUES (1268,
	1231,
	'current_clock',
	'',
	1,
	1218,
	'',
	1,
	'',
	0);
INSERT INTO ACT_BRB
	VALUES (1269,
	1268);
INSERT INTO ACT_ACT
	VALUES (1269,
	'bridge',
	0,
	1270,
	0,
	0,
	'Time::current_clock',
	0);
INSERT INTO ACT_BLK
	VALUES (1270,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1269,
	0);
INSERT INTO S_BRG
	VALUES (1271,
	1231,
	'timer_start',
	'This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Returns the instance
handle of the timer.',
	1,
	1272,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1273,
	1271,
	'microseconds',
	160,
	0,
	'',
	1274,
	'');
INSERT INTO S_BPARM
	VALUES (1274,
	1271,
	'event_inst',
	1275,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1276,
	1271);
INSERT INTO ACT_ACT
	VALUES (1276,
	'bridge',
	0,
	1277,
	0,
	0,
	'Time::timer_start',
	0);
INSERT INTO ACT_BLK
	VALUES (1277,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1276,
	0);
INSERT INTO S_BRG
	VALUES (1278,
	1231,
	'timer_start_recurring',
	'This bridge operation starts a timer set to expire in the specified number of
microseconds, generating the passed event upon expiration. Upon expiration, the
timer will be restarted and fire again in the specified number of microseconds
generating the passed event. This bridge operation returns the instance handle
of the timer.',
	1,
	1272,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1279,
	1278,
	'microseconds',
	160,
	0,
	'',
	1280,
	'');
INSERT INTO S_BPARM
	VALUES (1280,
	1278,
	'event_inst',
	1275,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1281,
	1278);
INSERT INTO ACT_ACT
	VALUES (1281,
	'bridge',
	0,
	1282,
	0,
	0,
	'Time::timer_start_recurring',
	0);
INSERT INTO ACT_BLK
	VALUES (1282,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1281,
	0);
INSERT INTO S_BRG
	VALUES (1283,
	1231,
	'timer_remaining_time',
	'Returns the time remaining (in microseconds) for the passed timer instance. If
the timer has expired, a zero value is returned.',
	1,
	160,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1284,
	1283,
	'timer_inst_ref',
	1272,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1285,
	1283);
INSERT INTO ACT_ACT
	VALUES (1285,
	'bridge',
	0,
	1286,
	0,
	0,
	'Time::timer_remaining_time',
	0);
INSERT INTO ACT_BLK
	VALUES (1286,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1285,
	0);
INSERT INTO S_BRG
	VALUES (1287,
	1231,
	'timer_reset_time',
	'This bridge operation attempts to set the passed existing timer to expire in
the specified number of microseconds. If the timer exists (that is, it has not
expired), a TRUE value is returned. If the timer no longer exists, a FALSE value
is returned.',
	1,
	125,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1288,
	1287,
	'timer_inst_ref',
	1272,
	0,
	'',
	1289,
	'');
INSERT INTO S_BPARM
	VALUES (1289,
	1287,
	'microseconds',
	160,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1290,
	1287);
INSERT INTO ACT_ACT
	VALUES (1290,
	'bridge',
	0,
	1291,
	0,
	0,
	'Time::timer_reset_time',
	0);
INSERT INTO ACT_BLK
	VALUES (1291,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1290,
	0);
INSERT INTO S_BRG
	VALUES (1292,
	1231,
	'timer_add_time',
	'This bridge operation attempts to add the specified number of microseconds to a
passed existing timer. If the timer exists (that is, it has not expired), a TRUE
value is returned. If the timer no longer exists, a FALSE value is returned.',
	1,
	125,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1293,
	1292,
	'timer_inst_ref',
	1272,
	0,
	'',
	1294,
	'');
INSERT INTO S_BPARM
	VALUES (1294,
	1292,
	'microseconds',
	160,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1295,
	1292);
INSERT INTO ACT_ACT
	VALUES (1295,
	'bridge',
	0,
	1296,
	0,
	0,
	'Time::timer_add_time',
	0);
INSERT INTO ACT_BLK
	VALUES (1296,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1295,
	0);
INSERT INTO S_BRG
	VALUES (1297,
	1231,
	'timer_cancel',
	'This bridge operation cancels and deletes the passed timer instance. If the 
timer exists (that is, it had not expired), a TRUE value is returned. If the
timer no longer exists, a FALSE value is returned.',
	1,
	125,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1298,
	1297,
	'timer_inst_ref',
	1272,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1299,
	1297);
INSERT INTO ACT_ACT
	VALUES (1299,
	'bridge',
	0,
	1300,
	0,
	0,
	'Time::timer_cancel',
	0);
INSERT INTO ACT_BLK
	VALUES (1300,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1299,
	0);
INSERT INTO PE_PE
	VALUES (1301,
	1,
	1189,
	0,
	5);
INSERT INTO S_EE
	VALUES (1301,
	'Math',
	'',
	'MATH',
	0,
	'',
	'Math',
	1);
INSERT INTO S_BRG
	VALUES (1302,
	1301,
	'sqrt',
	'',
	0,
	153,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (1303,
	1302,
	'x',
	153,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (1304,
	1302);
INSERT INTO ACT_ACT
	VALUES (1304,
	'bridge',
	0,
	1305,
	0,
	0,
	'Math::sqrt',
	0);
INSERT INTO ACT_BLK
	VALUES (1305,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1304,
	0);
INSERT INTO PE_PE
	VALUES (1192,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (1192,
	0,
	'void',
	'',
	'');
INSERT INTO S_CDT
	VALUES (1192,
	0);
INSERT INTO PE_PE
	VALUES (125,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (125,
	0,
	'boolean',
	'',
	'');
INSERT INTO S_CDT
	VALUES (125,
	1);
INSERT INTO PE_PE
	VALUES (160,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (160,
	0,
	'integer',
	'',
	'');
INSERT INTO S_CDT
	VALUES (160,
	2);
INSERT INTO PE_PE
	VALUES (153,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (153,
	0,
	'real',
	'',
	'');
INSERT INTO S_CDT
	VALUES (153,
	3);
INSERT INTO PE_PE
	VALUES (1199,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (1199,
	0,
	'string',
	'',
	'');
INSERT INTO S_CDT
	VALUES (1199,
	4);
INSERT INTO PE_PE
	VALUES (1306,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (1306,
	0,
	'unique_id',
	'',
	'');
INSERT INTO S_CDT
	VALUES (1306,
	5);
INSERT INTO PE_PE
	VALUES (1307,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (1307,
	0,
	'state<State_Model>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (1307,
	6);
INSERT INTO PE_PE
	VALUES (1308,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (1308,
	0,
	'same_as<Base_Attribute>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (1308,
	7);
INSERT INTO PE_PE
	VALUES (1309,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (1309,
	0,
	'inst_ref<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (1309,
	8);
INSERT INTO PE_PE
	VALUES (1310,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (1310,
	0,
	'inst_ref_set<Object>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (1310,
	9);
INSERT INTO PE_PE
	VALUES (1275,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (1275,
	0,
	'inst<Event>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (1275,
	10);
INSERT INTO PE_PE
	VALUES (1311,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (1311,
	0,
	'inst<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (1311,
	11);
INSERT INTO PE_PE
	VALUES (1312,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (1312,
	0,
	'inst_ref<Mapping>',
	'',
	'');
INSERT INTO S_CDT
	VALUES (1312,
	12);
INSERT INTO PE_PE
	VALUES (1313,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (1313,
	0,
	'component_ref',
	'',
	'');
INSERT INTO S_CDT
	VALUES (1313,
	13);
INSERT INTO PE_PE
	VALUES (1212,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (1212,
	0,
	'date',
	'',
	'');
INSERT INTO S_UDT
	VALUES (1212,
	1311,
	1,
	'');
INSERT INTO PE_PE
	VALUES (1272,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (1272,
	0,
	'inst_ref<Timer>',
	'',
	'');
INSERT INTO S_UDT
	VALUES (1272,
	1312,
	3,
	'');
INSERT INTO PE_PE
	VALUES (1218,
	1,
	0,
	0,
	3);
INSERT INTO S_DT
	VALUES (1218,
	0,
	'timestamp',
	'',
	'');
INSERT INTO S_UDT
	VALUES (1218,
	1311,
	2,
	'');
-- root-types-contained: SystemModel_c
-- BP 7.1 content: StreamData syschar: 3 persistence-version: 7.1.6

INSERT INTO S_SYS
	VALUES (1371,
	'Tracking',
	1);
INSERT INTO EP_PKG
	VALUES (1344,
	1371,
	1371,
	'Tracking',
	'',
	0);
INSERT INTO PE_PE
	VALUES (459,
	1,
	1344,
	0,
	2);
INSERT INTO C_C
	VALUES (459,
	0,
	0,
	'Tracking',
	'The Tracking component encapsulates the entire application software. This is the 
only component in the system from which code will be generated for the final 
product.',
	0,
	0,
	0,
	'');
INSERT INTO C_PO
	VALUES (460,
	459,
	'Tracking',
	0,
	0);
INSERT INTO C_IR
	VALUES (463,
	44,
	0,
	460);
INSERT INTO C_P
	VALUES (463,
	'Tracking',
	'Unnamed Interface',
	'',
	'Tracking::Tracking::Tracking');
INSERT INTO SPR_PEP
	VALUES (1330,
	46,
	463);
INSERT INTO SPR_PO
	VALUES (1330,
	'heartRateChanged',
	'',
	'::heartRateChanged( heartRate:param.heartRate );',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (1372,
	1330);
INSERT INTO ACT_ACT
	VALUES (1372,
	'interface operation',
	0,
	1373,
	0,
	0,
	'Tracking::Tracking::heartRateChanged',
	0);
INSERT INTO ACT_BLK
	VALUES (1373,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1372,
	0);
INSERT INTO ACT_SMT
	VALUES (1374,
	1373,
	0,
	1,
	1,
	'Tracking::Tracking::heartRateChanged line: 1');
INSERT INTO ACT_FNC
	VALUES (1374,
	1375,
	1,
	3);
INSERT INTO V_VAL
	VALUES (1376,
	0,
	0,
	1,
	37,
	45,
	0,
	0,
	0,
	0,
	160,
	1373);
INSERT INTO V_PVL
	VALUES (1376,
	0,
	0,
	0,
	1337);
INSERT INTO V_PAR
	VALUES (1376,
	1374,
	0,
	'heartRate',
	0,
	1,
	21);
INSERT INTO SPR_PEP
	VALUES (1331,
	50,
	463);
INSERT INTO SPR_PO
	VALUES (1331,
	'setTargetPressed',
	'',
	'::setTargetPressed();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (1377,
	1331);
INSERT INTO ACT_ACT
	VALUES (1377,
	'interface operation',
	0,
	1378,
	0,
	0,
	'Tracking::Tracking::setTargetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (1378,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1377,
	0);
INSERT INTO ACT_SMT
	VALUES (1379,
	1378,
	0,
	1,
	1,
	'Tracking::Tracking::setTargetPressed line: 1');
INSERT INTO ACT_FNC
	VALUES (1379,
	1380,
	1,
	3);
INSERT INTO SPR_PEP
	VALUES (1332,
	54,
	463);
INSERT INTO SPR_PO
	VALUES (1332,
	'startStopPressed',
	'',
	'::startStopPressed();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (1381,
	1332);
INSERT INTO ACT_ACT
	VALUES (1381,
	'interface operation',
	0,
	1382,
	0,
	0,
	'Tracking::Tracking::startStopPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (1382,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1381,
	0);
INSERT INTO ACT_SMT
	VALUES (1383,
	1382,
	0,
	1,
	1,
	'Tracking::Tracking::startStopPressed line: 1');
INSERT INTO ACT_FNC
	VALUES (1383,
	1384,
	1,
	3);
INSERT INTO SPR_PEP
	VALUES (1333,
	58,
	463);
INSERT INTO SPR_PO
	VALUES (1333,
	'lapResetPressed',
	'',
	'::lapResetPressed();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (1385,
	1333);
INSERT INTO ACT_ACT
	VALUES (1385,
	'interface operation',
	0,
	1386,
	0,
	0,
	'Tracking::Tracking::lapResetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (1386,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1385,
	0);
INSERT INTO ACT_SMT
	VALUES (1387,
	1386,
	0,
	1,
	1,
	'Tracking::Tracking::lapResetPressed line: 1');
INSERT INTO ACT_FNC
	VALUES (1387,
	1388,
	1,
	3);
INSERT INTO SPR_PEP
	VALUES (1334,
	62,
	463);
INSERT INTO SPR_PO
	VALUES (1334,
	'lightPressed',
	'',
	'::lightPressed();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (1389,
	1334);
INSERT INTO ACT_ACT
	VALUES (1389,
	'interface operation',
	0,
	1390,
	0,
	0,
	'Tracking::Tracking::lightPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (1390,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1389,
	0);
INSERT INTO ACT_SMT
	VALUES (1391,
	1390,
	0,
	1,
	1,
	'Tracking::Tracking::lightPressed line: 1');
INSERT INTO ACT_FNC
	VALUES (1391,
	1392,
	1,
	3);
INSERT INTO SPR_PEP
	VALUES (1335,
	66,
	463);
INSERT INTO SPR_PO
	VALUES (1335,
	'modePressed',
	'',
	'::modePressed();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (1393,
	1335);
INSERT INTO ACT_ACT
	VALUES (1393,
	'interface operation',
	0,
	1394,
	0,
	0,
	'Tracking::Tracking::modePressed',
	0);
INSERT INTO ACT_BLK
	VALUES (1394,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1393,
	0);
INSERT INTO ACT_SMT
	VALUES (1395,
	1394,
	0,
	1,
	1,
	'Tracking::Tracking::modePressed line: 1');
INSERT INTO ACT_FNC
	VALUES (1395,
	1396,
	1,
	3);
INSERT INTO SPR_PEP
	VALUES (1336,
	70,
	463);
INSERT INTO SPR_PO
	VALUES (1336,
	'newGoalSpec',
	'',
	'::newGoalSpec( spanType:param.spanType, criteriaType:param.criteriaType, 
			span:param.span, maximum:param.maximum, minimum:param.minimum, sequenceNumber: param.sequenceNumber);',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (1397,
	1336);
INSERT INTO ACT_ACT
	VALUES (1397,
	'interface operation',
	0,
	1398,
	0,
	0,
	'Tracking::Tracking::newGoalSpec',
	0);
INSERT INTO ACT_BLK
	VALUES (1398,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1397,
	0);
INSERT INTO ACT_SMT
	VALUES (1399,
	1398,
	0,
	1,
	1,
	'Tracking::Tracking::newGoalSpec line: 1');
INSERT INTO ACT_FNC
	VALUES (1399,
	1400,
	1,
	3);
INSERT INTO V_VAL
	VALUES (1401,
	0,
	0,
	1,
	31,
	38,
	0,
	0,
	0,
	0,
	147,
	1398);
INSERT INTO V_PVL
	VALUES (1401,
	0,
	0,
	0,
	1338);
INSERT INTO V_PAR
	VALUES (1401,
	1399,
	0,
	'spanType',
	1402,
	1,
	16);
INSERT INTO V_VAL
	VALUES (1402,
	0,
	0,
	1,
	60,
	71,
	0,
	0,
	0,
	0,
	150,
	1398);
INSERT INTO V_PVL
	VALUES (1402,
	0,
	0,
	0,
	1339);
INSERT INTO V_PAR
	VALUES (1402,
	1399,
	0,
	'criteriaType',
	1403,
	1,
	41);
INSERT INTO V_VAL
	VALUES (1403,
	0,
	0,
	2,
	15,
	18,
	0,
	0,
	0,
	0,
	153,
	1398);
INSERT INTO V_PVL
	VALUES (1403,
	0,
	0,
	0,
	1340);
INSERT INTO V_PAR
	VALUES (1403,
	1399,
	0,
	'span',
	1404,
	2,
	4);
INSERT INTO V_VAL
	VALUES (1404,
	0,
	0,
	2,
	35,
	41,
	0,
	0,
	0,
	0,
	153,
	1398);
INSERT INTO V_PVL
	VALUES (1404,
	0,
	0,
	0,
	1341);
INSERT INTO V_PAR
	VALUES (1404,
	1399,
	0,
	'maximum',
	1405,
	2,
	21);
INSERT INTO V_VAL
	VALUES (1405,
	0,
	0,
	2,
	58,
	64,
	0,
	0,
	0,
	0,
	153,
	1398);
INSERT INTO V_PVL
	VALUES (1405,
	0,
	0,
	0,
	1342);
INSERT INTO V_PAR
	VALUES (1405,
	1399,
	0,
	'minimum',
	1406,
	2,
	44);
INSERT INTO V_VAL
	VALUES (1406,
	0,
	0,
	2,
	89,
	102,
	0,
	0,
	0,
	0,
	160,
	1398);
INSERT INTO V_PVL
	VALUES (1406,
	0,
	0,
	0,
	1343);
INSERT INTO V_PAR
	VALUES (1406,
	1399,
	0,
	'sequenceNumber',
	0,
	2,
	67);
INSERT INTO C_PO
	VALUES (465,
	459,
	'HR',
	0,
	0);
INSERT INTO C_IR
	VALUES (468,
	436,
	0,
	465);
INSERT INTO C_R
	VALUES (468,
	'Tracking_HeartRateMonitor',
	'',
	'Unnamed Interface',
	'Tracking::HR::Tracking_HeartRateMonitor');
INSERT INTO SPR_REP
	VALUES (1345,
	438,
	468);
INSERT INTO SPR_RO
	VALUES (1345,
	'registerListener',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (1407,
	1345);
INSERT INTO ACT_ACT
	VALUES (1407,
	'interface operation',
	0,
	1408,
	0,
	0,
	'HR::Tracking_HeartRateMonitor::registerListener',
	0);
INSERT INTO ACT_BLK
	VALUES (1408,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1407,
	0);
INSERT INTO SPR_REP
	VALUES (1346,
	443,
	468);
INSERT INTO SPR_RO
	VALUES (1346,
	'unregisterListener',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (1409,
	1346);
INSERT INTO ACT_ACT
	VALUES (1409,
	'interface operation',
	0,
	1410,
	0,
	0,
	'HR::Tracking_HeartRateMonitor::unregisterListener',
	0);
INSERT INTO ACT_BLK
	VALUES (1410,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1409,
	0);
INSERT INTO C_PO
	VALUES (470,
	459,
	'LOC',
	0,
	0);
INSERT INTO C_IR
	VALUES (473,
	378,
	0,
	470);
INSERT INTO C_R
	VALUES (473,
	'Tracking_Location',
	'',
	'Unnamed Interface',
	'Tracking::LOC::Tracking_Location');
INSERT INTO SPR_REP
	VALUES (1347,
	380,
	473);
INSERT INTO SPR_RO
	VALUES (1347,
	'getDistance',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (1411,
	1347);
INSERT INTO ACT_ACT
	VALUES (1411,
	'interface operation',
	0,
	1412,
	0,
	0,
	'LOC::Tracking_Location::getDistance',
	0);
INSERT INTO ACT_BLK
	VALUES (1412,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1411,
	0);
INSERT INTO SPR_REP
	VALUES (1348,
	402,
	473);
INSERT INTO SPR_RO
	VALUES (1348,
	'getLocation',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (1413,
	1348);
INSERT INTO ACT_ACT
	VALUES (1413,
	'interface operation',
	0,
	1414,
	0,
	0,
	'LOC::Tracking_Location::getLocation',
	0);
INSERT INTO ACT_BLK
	VALUES (1414,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1413,
	0);
INSERT INTO SPR_REP
	VALUES (1349,
	425,
	473);
INSERT INTO SPR_RO
	VALUES (1349,
	'registerListener',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (1415,
	1349);
INSERT INTO ACT_ACT
	VALUES (1415,
	'interface operation',
	0,
	1416,
	0,
	0,
	'LOC::Tracking_Location::registerListener',
	0);
INSERT INTO ACT_BLK
	VALUES (1416,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1415,
	0);
INSERT INTO SPR_REP
	VALUES (1350,
	430,
	473);
INSERT INTO SPR_RO
	VALUES (1350,
	'unregisterListener',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (1417,
	1350);
INSERT INTO ACT_ACT
	VALUES (1417,
	'interface operation',
	0,
	1418,
	0,
	0,
	'LOC::Tracking_Location::unregisterListener',
	0);
INSERT INTO ACT_BLK
	VALUES (1418,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1417,
	0);
INSERT INTO C_PO
	VALUES (475,
	459,
	'UI',
	0,
	0);
INSERT INTO C_IR
	VALUES (478,
	207,
	0,
	475);
INSERT INTO C_R
	VALUES (478,
	'Tracking_UI',
	'',
	'Unnamed Interface',
	'Tracking::UI::Tracking_UI');
INSERT INTO SPR_REP
	VALUES (1351,
	209,
	478);
INSERT INTO SPR_RO
	VALUES (1351,
	'setData',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (1419,
	1351);
INSERT INTO ACT_ACT
	VALUES (1419,
	'interface operation',
	0,
	1420,
	0,
	0,
	'UI::Tracking_UI::setData',
	0);
INSERT INTO ACT_BLK
	VALUES (1420,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1419,
	0);
INSERT INTO SPR_REP
	VALUES (1352,
	327,
	478);
INSERT INTO SPR_RO
	VALUES (1352,
	'setIndicator',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (1421,
	1352);
INSERT INTO ACT_ACT
	VALUES (1421,
	'interface operation',
	0,
	1422,
	0,
	0,
	'UI::Tracking_UI::setIndicator',
	0);
INSERT INTO ACT_BLK
	VALUES (1422,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1421,
	0);
INSERT INTO SPR_REP
	VALUES (1353,
	370,
	478);
INSERT INTO SPR_RO
	VALUES (1353,
	'setTime',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (1423,
	1353);
INSERT INTO ACT_ACT
	VALUES (1423,
	'interface operation',
	0,
	1424,
	0,
	0,
	'UI::Tracking_UI::setTime',
	0);
INSERT INTO ACT_BLK
	VALUES (1424,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1423,
	0);
INSERT INTO PE_PE
	VALUES (1425,
	1,
	0,
	459,
	7);
INSERT INTO EP_PKG
	VALUES (1425,
	0,
	1371,
	'TargetTesting',
	'Contains facilities for testing generated code.',
	0);
INSERT INTO PE_PE
	VALUES (1426,
	1,
	1425,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (1426,
	0,
	'Initialize',
	'',
	'// Create a workout session and everything required to support it.
WorkoutSession::initialize();',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (1427,
	1426);
INSERT INTO ACT_ACT
	VALUES (1427,
	'function',
	0,
	1428,
	0,
	0,
	'Initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (1428,
	0,
	0,
	0,
	'WorkoutSession',
	'',
	'',
	2,
	1,
	2,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1427,
	0);
INSERT INTO ACT_SMT
	VALUES (1429,
	1428,
	0,
	2,
	1,
	'Initialize line: 2');
INSERT INTO ACT_TFM
	VALUES (1429,
	1430,
	0,
	2,
	17,
	2,
	1);
INSERT INTO PE_PE
	VALUES (1431,
	1,
	1425,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (1431,
	0,
	'GoalTest_1',
	'',
	'// Initialize the system.
::Initialize();

// Create some goal specifications.
::newGoalSpec( 
  sequenceNumber: 1,
  minimum: 2.0,
  maximum: 8.0,
  span: 150.0,
  criteriaType: GoalCriteria::Pace,
  spanType: GoalSpan::Distance );
  
::newGoalSpec( 
  sequenceNumber: 2,
  minimum: 60.0,
  maximum: 80.0,
  span: 10,
  criteriaType: GoalCriteria::HeartRate,
  spanType: GoalSpan::Time );
  
::newGoalSpec( 
  sequenceNumber: 3,
  minimum: 5.0,
  maximum: 6.0,
  span: 15,
  criteriaType: GoalCriteria::Pace,
  spanType: GoalSpan::Time );
  
::newGoalSpec( 
  sequenceNumber: 4,
  minimum: 1.0,
  maximum: 2.0,
  span: 15,
  criteriaType: GoalCriteria::Pace,
  spanType: GoalSpan::Time );
  ',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (1432,
	1431);
INSERT INTO ACT_ACT
	VALUES (1432,
	'function',
	0,
	1433,
	0,
	0,
	'GoalTest_1',
	0);
INSERT INTO ACT_BLK
	VALUES (1433,
	0,
	0,
	0,
	'',
	'',
	'',
	29,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	35,
	13,
	0,
	1432,
	0);
INSERT INTO ACT_SMT
	VALUES (1434,
	1433,
	1435,
	2,
	1,
	'GoalTest_1 line: 2');
INSERT INTO ACT_FNC
	VALUES (1434,
	1426,
	2,
	3);
INSERT INTO ACT_SMT
	VALUES (1435,
	1433,
	1436,
	5,
	1,
	'GoalTest_1 line: 5');
INSERT INTO ACT_FNC
	VALUES (1435,
	1400,
	5,
	3);
INSERT INTO ACT_SMT
	VALUES (1436,
	1433,
	1437,
	13,
	1,
	'GoalTest_1 line: 13');
INSERT INTO ACT_FNC
	VALUES (1436,
	1400,
	13,
	3);
INSERT INTO ACT_SMT
	VALUES (1437,
	1433,
	1438,
	21,
	1,
	'GoalTest_1 line: 21');
INSERT INTO ACT_FNC
	VALUES (1437,
	1400,
	21,
	3);
INSERT INTO ACT_SMT
	VALUES (1438,
	1433,
	0,
	29,
	1,
	'GoalTest_1 line: 29');
INSERT INTO ACT_FNC
	VALUES (1438,
	1400,
	29,
	3);
INSERT INTO V_VAL
	VALUES (1439,
	0,
	0,
	6,
	19,
	19,
	0,
	0,
	0,
	0,
	160,
	1433);
INSERT INTO V_LIN
	VALUES (1439,
	'1');
INSERT INTO V_PAR
	VALUES (1439,
	1435,
	0,
	'sequenceNumber',
	1440,
	6,
	3);
INSERT INTO V_VAL
	VALUES (1440,
	0,
	0,
	7,
	12,
	14,
	0,
	0,
	0,
	0,
	153,
	1433);
INSERT INTO V_LRL
	VALUES (1440,
	'2.0');
INSERT INTO V_PAR
	VALUES (1440,
	1435,
	0,
	'minimum',
	1441,
	7,
	3);
INSERT INTO V_VAL
	VALUES (1441,
	0,
	0,
	8,
	12,
	14,
	0,
	0,
	0,
	0,
	153,
	1433);
INSERT INTO V_LRL
	VALUES (1441,
	'8.0');
INSERT INTO V_PAR
	VALUES (1441,
	1435,
	0,
	'maximum',
	1442,
	8,
	3);
INSERT INTO V_VAL
	VALUES (1442,
	0,
	0,
	9,
	9,
	13,
	0,
	0,
	0,
	0,
	153,
	1433);
INSERT INTO V_LRL
	VALUES (1442,
	'150.0');
INSERT INTO V_PAR
	VALUES (1442,
	1435,
	0,
	'span',
	1443,
	9,
	3);
INSERT INTO V_VAL
	VALUES (1443,
	0,
	0,
	10,
	31,
	34,
	0,
	0,
	0,
	0,
	150,
	1433);
INSERT INTO V_LEN
	VALUES (1443,
	183,
	10,
	17);
INSERT INTO V_PAR
	VALUES (1443,
	1435,
	0,
	'criteriaType',
	1444,
	10,
	3);
INSERT INTO V_VAL
	VALUES (1444,
	0,
	0,
	11,
	23,
	30,
	0,
	0,
	0,
	0,
	147,
	1433);
INSERT INTO V_LEN
	VALUES (1444,
	148,
	11,
	13);
INSERT INTO V_PAR
	VALUES (1444,
	1435,
	0,
	'spanType',
	0,
	11,
	3);
INSERT INTO V_VAL
	VALUES (1445,
	0,
	0,
	14,
	19,
	19,
	0,
	0,
	0,
	0,
	160,
	1433);
INSERT INTO V_LIN
	VALUES (1445,
	'2');
INSERT INTO V_PAR
	VALUES (1445,
	1436,
	0,
	'sequenceNumber',
	1446,
	14,
	3);
INSERT INTO V_VAL
	VALUES (1446,
	0,
	0,
	15,
	12,
	15,
	0,
	0,
	0,
	0,
	153,
	1433);
INSERT INTO V_LRL
	VALUES (1446,
	'60.0');
INSERT INTO V_PAR
	VALUES (1446,
	1436,
	0,
	'minimum',
	1447,
	15,
	3);
INSERT INTO V_VAL
	VALUES (1447,
	0,
	0,
	16,
	12,
	15,
	0,
	0,
	0,
	0,
	153,
	1433);
INSERT INTO V_LRL
	VALUES (1447,
	'80.0');
INSERT INTO V_PAR
	VALUES (1447,
	1436,
	0,
	'maximum',
	1448,
	16,
	3);
INSERT INTO V_VAL
	VALUES (1448,
	0,
	0,
	17,
	9,
	10,
	0,
	0,
	0,
	0,
	160,
	1433);
INSERT INTO V_LIN
	VALUES (1448,
	'10');
INSERT INTO V_PAR
	VALUES (1448,
	1436,
	0,
	'span',
	1449,
	17,
	3);
INSERT INTO V_VAL
	VALUES (1449,
	0,
	0,
	18,
	31,
	39,
	0,
	0,
	0,
	0,
	150,
	1433);
INSERT INTO V_LEN
	VALUES (1449,
	151,
	18,
	17);
INSERT INTO V_PAR
	VALUES (1449,
	1436,
	0,
	'criteriaType',
	1450,
	18,
	3);
INSERT INTO V_VAL
	VALUES (1450,
	0,
	0,
	19,
	23,
	26,
	0,
	0,
	0,
	0,
	147,
	1433);
INSERT INTO V_LEN
	VALUES (1450,
	164,
	19,
	13);
INSERT INTO V_PAR
	VALUES (1450,
	1436,
	0,
	'spanType',
	0,
	19,
	3);
INSERT INTO V_VAL
	VALUES (1451,
	0,
	0,
	22,
	19,
	19,
	0,
	0,
	0,
	0,
	160,
	1433);
INSERT INTO V_LIN
	VALUES (1451,
	'3');
INSERT INTO V_PAR
	VALUES (1451,
	1437,
	0,
	'sequenceNumber',
	1452,
	22,
	3);
INSERT INTO V_VAL
	VALUES (1452,
	0,
	0,
	23,
	12,
	14,
	0,
	0,
	0,
	0,
	153,
	1433);
INSERT INTO V_LRL
	VALUES (1452,
	'5.0');
INSERT INTO V_PAR
	VALUES (1452,
	1437,
	0,
	'minimum',
	1453,
	23,
	3);
INSERT INTO V_VAL
	VALUES (1453,
	0,
	0,
	24,
	12,
	14,
	0,
	0,
	0,
	0,
	153,
	1433);
INSERT INTO V_LRL
	VALUES (1453,
	'6.0');
INSERT INTO V_PAR
	VALUES (1453,
	1437,
	0,
	'maximum',
	1454,
	24,
	3);
INSERT INTO V_VAL
	VALUES (1454,
	0,
	0,
	25,
	9,
	10,
	0,
	0,
	0,
	0,
	160,
	1433);
INSERT INTO V_LIN
	VALUES (1454,
	'15');
INSERT INTO V_PAR
	VALUES (1454,
	1437,
	0,
	'span',
	1455,
	25,
	3);
INSERT INTO V_VAL
	VALUES (1455,
	0,
	0,
	26,
	31,
	34,
	0,
	0,
	0,
	0,
	150,
	1433);
INSERT INTO V_LEN
	VALUES (1455,
	183,
	26,
	17);
INSERT INTO V_PAR
	VALUES (1455,
	1437,
	0,
	'criteriaType',
	1456,
	26,
	3);
INSERT INTO V_VAL
	VALUES (1456,
	0,
	0,
	27,
	23,
	26,
	0,
	0,
	0,
	0,
	147,
	1433);
INSERT INTO V_LEN
	VALUES (1456,
	164,
	27,
	13);
INSERT INTO V_PAR
	VALUES (1456,
	1437,
	0,
	'spanType',
	0,
	27,
	3);
INSERT INTO V_VAL
	VALUES (1457,
	0,
	0,
	30,
	19,
	19,
	0,
	0,
	0,
	0,
	160,
	1433);
INSERT INTO V_LIN
	VALUES (1457,
	'4');
INSERT INTO V_PAR
	VALUES (1457,
	1438,
	0,
	'sequenceNumber',
	1458,
	30,
	3);
INSERT INTO V_VAL
	VALUES (1458,
	0,
	0,
	31,
	12,
	14,
	0,
	0,
	0,
	0,
	153,
	1433);
INSERT INTO V_LRL
	VALUES (1458,
	'1.0');
INSERT INTO V_PAR
	VALUES (1458,
	1438,
	0,
	'minimum',
	1459,
	31,
	3);
INSERT INTO V_VAL
	VALUES (1459,
	0,
	0,
	32,
	12,
	14,
	0,
	0,
	0,
	0,
	153,
	1433);
INSERT INTO V_LRL
	VALUES (1459,
	'2.0');
INSERT INTO V_PAR
	VALUES (1459,
	1438,
	0,
	'maximum',
	1460,
	32,
	3);
INSERT INTO V_VAL
	VALUES (1460,
	0,
	0,
	33,
	9,
	10,
	0,
	0,
	0,
	0,
	160,
	1433);
INSERT INTO V_LIN
	VALUES (1460,
	'15');
INSERT INTO V_PAR
	VALUES (1460,
	1438,
	0,
	'span',
	1461,
	33,
	3);
INSERT INTO V_VAL
	VALUES (1461,
	0,
	0,
	34,
	31,
	34,
	0,
	0,
	0,
	0,
	150,
	1433);
INSERT INTO V_LEN
	VALUES (1461,
	183,
	34,
	17);
INSERT INTO V_PAR
	VALUES (1461,
	1438,
	0,
	'criteriaType',
	1462,
	34,
	3);
INSERT INTO V_VAL
	VALUES (1462,
	0,
	0,
	35,
	23,
	26,
	0,
	0,
	0,
	0,
	147,
	1433);
INSERT INTO V_LEN
	VALUES (1462,
	164,
	35,
	13);
INSERT INTO V_PAR
	VALUES (1462,
	1438,
	0,
	'spanType',
	0,
	35,
	3);
INSERT INTO PE_PE
	VALUES (1463,
	1,
	0,
	459,
	7);
INSERT INTO EP_PKG
	VALUES (1463,
	0,
	1371,
	'functions',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1375,
	1,
	1463,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (1375,
	0,
	'heartRateChanged',
	'',
	'// Find the singleton instance of the workout session
// and forward this signal, as an event, to it.
// If there is no active workout session, then this 
// sample is simply ignored and not recorded.

select any session from instances of WorkoutSession;
if (not empty session)
  session.addHeartRateSample(heartRate: param.heartRate);
end if;',
	1192,
	1,
	'',
	0);
INSERT INTO S_SPARM
	VALUES (1464,
	1375,
	'heartRate',
	160,
	0,
	'',
	0,
	'');
INSERT INTO ACT_FNB
	VALUES (1465,
	1375);
INSERT INTO ACT_ACT
	VALUES (1465,
	'function',
	0,
	1466,
	0,
	0,
	'heartRateChanged',
	0);
INSERT INTO ACT_BLK
	VALUES (1466,
	1,
	0,
	0,
	'',
	'',
	'',
	7,
	1,
	6,
	38,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1465,
	0);
INSERT INTO ACT_SMT
	VALUES (1467,
	1466,
	1468,
	6,
	1,
	'heartRateChanged line: 6');
INSERT INTO ACT_FIO
	VALUES (1467,
	1469,
	1,
	'any',
	1470,
	6,
	38);
INSERT INTO ACT_SMT
	VALUES (1468,
	1466,
	0,
	7,
	1,
	'heartRateChanged line: 7');
INSERT INTO ACT_IF
	VALUES (1468,
	1471,
	1472,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1473,
	0,
	0,
	7,
	15,
	21,
	0,
	0,
	0,
	0,
	1309,
	1466);
INSERT INTO V_IRF
	VALUES (1473,
	1469);
INSERT INTO V_VAL
	VALUES (1474,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1466);
INSERT INTO V_UNY
	VALUES (1474,
	1473,
	'empty');
INSERT INTO V_VAL
	VALUES (1472,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1466);
INSERT INTO V_UNY
	VALUES (1472,
	1474,
	'not');
INSERT INTO V_VAR
	VALUES (1469,
	1466,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1469,
	0,
	1470);
INSERT INTO ACT_BLK
	VALUES (1471,
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1465,
	0);
INSERT INTO ACT_SMT
	VALUES (1475,
	1471,
	0,
	8,
	3,
	'heartRateChanged line: 8');
INSERT INTO ACT_TFM
	VALUES (1475,
	1476,
	1469,
	8,
	11,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1477,
	0,
	0,
	8,
	47,
	55,
	0,
	0,
	0,
	0,
	160,
	1471);
INSERT INTO V_PVL
	VALUES (1477,
	0,
	1464,
	0,
	0);
INSERT INTO V_PAR
	VALUES (1477,
	1475,
	0,
	'heartRate',
	0,
	8,
	30);
INSERT INTO PE_PE
	VALUES (1380,
	1,
	1463,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (1380,
	0,
	'setTargetPressed',
	'',
	'// If a goal is currently executing, advance to the next one,
//   otherwise start the first specified goal, if it exists.
Goal::nextGoal();',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (1478,
	1380);
INSERT INTO ACT_ACT
	VALUES (1478,
	'function',
	0,
	1479,
	0,
	0,
	'setTargetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (1479,
	0,
	0,
	0,
	'Goal',
	'',
	'',
	3,
	1,
	3,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1478,
	0);
INSERT INTO ACT_SMT
	VALUES (1480,
	1479,
	0,
	3,
	1,
	'setTargetPressed line: 3');
INSERT INTO ACT_TFM
	VALUES (1480,
	1481,
	0,
	3,
	7,
	3,
	1);
INSERT INTO PE_PE
	VALUES (1384,
	1,
	1463,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (1384,
	0,
	'startStopPressed',
	'',
	'// If necessary, create a workout session and everything required to 
// support it.  Then, forward this signal to the workout timer.

WorkoutSession::initialize();

// Forward this signal, as an event, to the singleton instance of WorkoutTimer.
select any workoutTimer from instances of WorkoutTimer;
generate WorkoutTimer1:startStopPressed() to workoutTimer;',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (1482,
	1384);
INSERT INTO ACT_ACT
	VALUES (1482,
	'function',
	0,
	1483,
	0,
	0,
	'startStopPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (1483,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	8,
	1,
	7,
	43,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1482,
	0);
INSERT INTO ACT_SMT
	VALUES (1484,
	1483,
	1485,
	4,
	1,
	'startStopPressed line: 4');
INSERT INTO ACT_TFM
	VALUES (1484,
	1430,
	0,
	4,
	17,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES (1485,
	1483,
	1486,
	7,
	1,
	'startStopPressed line: 7');
INSERT INTO ACT_FIO
	VALUES (1485,
	1487,
	1,
	'any',
	1488,
	7,
	43);
INSERT INTO ACT_SMT
	VALUES (1486,
	1483,
	0,
	8,
	1,
	'startStopPressed line: 8');
INSERT INTO E_ESS
	VALUES (1486,
	1,
	0,
	8,
	10,
	8,
	24,
	7,
	43,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (1486);
INSERT INTO E_GSME
	VALUES (1486,
	1489);
INSERT INTO E_GEN
	VALUES (1486,
	1487);
INSERT INTO V_VAR
	VALUES (1487,
	1483,
	'workoutTimer',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1487,
	0,
	1488);
INSERT INTO PE_PE
	VALUES (1388,
	1,
	1463,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (1388,
	0,
	'lapResetPressed',
	'',
	'// Find the singleton instance of the workout timer 
// and forward this signal, as an event, to it.

select any workoutTimer from instances of WorkoutTimer;
if (not empty workoutTimer)
  generate WorkoutTimer2:lapResetPressed() to workoutTimer;
else
  LOG::LogFailure( message:"Tracking:UI:lapResetPressed - No WorkoutTimer, so nothing to do." );
end if;
',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (1490,
	1388);
INSERT INTO ACT_ACT
	VALUES (1490,
	'function',
	0,
	1491,
	0,
	0,
	'lapResetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (1491,
	1,
	0,
	0,
	'',
	'',
	'',
	7,
	1,
	4,
	43,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1490,
	0);
INSERT INTO ACT_SMT
	VALUES (1492,
	1491,
	1493,
	4,
	1,
	'lapResetPressed line: 4');
INSERT INTO ACT_FIO
	VALUES (1492,
	1494,
	1,
	'any',
	1488,
	4,
	43);
INSERT INTO ACT_SMT
	VALUES (1493,
	1491,
	0,
	5,
	1,
	'lapResetPressed line: 5');
INSERT INTO ACT_IF
	VALUES (1493,
	1495,
	1496,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1497,
	1491,
	0,
	7,
	1,
	'lapResetPressed line: 7');
INSERT INTO ACT_E
	VALUES (1497,
	1498,
	1493);
INSERT INTO V_VAL
	VALUES (1499,
	0,
	0,
	5,
	15,
	26,
	0,
	0,
	0,
	0,
	1309,
	1491);
INSERT INTO V_IRF
	VALUES (1499,
	1494);
INSERT INTO V_VAL
	VALUES (1500,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1491);
INSERT INTO V_UNY
	VALUES (1500,
	1499,
	'empty');
INSERT INTO V_VAL
	VALUES (1496,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1491);
INSERT INTO V_UNY
	VALUES (1496,
	1500,
	'not');
INSERT INTO V_VAR
	VALUES (1494,
	1491,
	'workoutTimer',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1494,
	0,
	1488);
INSERT INTO ACT_BLK
	VALUES (1495,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	6,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1490,
	0);
INSERT INTO ACT_SMT
	VALUES (1501,
	1495,
	0,
	6,
	3,
	'lapResetPressed line: 6');
INSERT INTO E_ESS
	VALUES (1501,
	1,
	0,
	6,
	12,
	6,
	26,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (1501);
INSERT INTO E_GSME
	VALUES (1501,
	1502);
INSERT INTO E_GEN
	VALUES (1501,
	1494);
INSERT INTO ACT_BLK
	VALUES (1498,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	8,
	3,
	8,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1490,
	0);
INSERT INTO ACT_SMT
	VALUES (1503,
	1498,
	0,
	8,
	3,
	'lapResetPressed line: 8');
INSERT INTO ACT_BRG
	VALUES (1503,
	1202,
	8,
	8,
	8,
	3);
INSERT INTO V_VAL
	VALUES (1504,
	0,
	0,
	8,
	28,
	92,
	0,
	0,
	0,
	0,
	1199,
	1498);
INSERT INTO V_LST
	VALUES (1504,
	'Tracking:UI:lapResetPressed - No WorkoutTimer, so nothing to do.');
INSERT INTO V_PAR
	VALUES (1504,
	1503,
	0,
	'message',
	0,
	8,
	20);
INSERT INTO PE_PE
	VALUES (1392,
	1,
	1463,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (1392,
	0,
	'lightPressed',
	'',
	'',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (1505,
	1392);
INSERT INTO ACT_ACT
	VALUES (1505,
	'function',
	0,
	1506,
	0,
	0,
	'lightPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (1506,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1505,
	0);
INSERT INTO PE_PE
	VALUES (1396,
	1,
	1463,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (1396,
	0,
	'modePressed',
	'',
	'// Notify the display to change modes.

// Find the display related to the singleton instance of 
//   workout session (if it exists), and notify it.
select any session from instances of WorkoutSession;
if ( not empty session )
  select one display related by session->Display[R7.''current_status_indicated_on''];
  generate Display1:modeChange to display;
end if;',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (1507,
	1396);
INSERT INTO ACT_ACT
	VALUES (1507,
	'function',
	0,
	1508,
	0,
	0,
	'modePressed',
	0);
INSERT INTO ACT_BLK
	VALUES (1508,
	1,
	0,
	0,
	'',
	'',
	'',
	6,
	1,
	5,
	38,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1507,
	0);
INSERT INTO ACT_SMT
	VALUES (1509,
	1508,
	1510,
	5,
	1,
	'modePressed line: 5');
INSERT INTO ACT_FIO
	VALUES (1509,
	1511,
	1,
	'any',
	1470,
	5,
	38);
INSERT INTO ACT_SMT
	VALUES (1510,
	1508,
	0,
	6,
	1,
	'modePressed line: 6');
INSERT INTO ACT_IF
	VALUES (1510,
	1512,
	1513,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1514,
	0,
	0,
	6,
	16,
	22,
	0,
	0,
	0,
	0,
	1309,
	1508);
INSERT INTO V_IRF
	VALUES (1514,
	1511);
INSERT INTO V_VAL
	VALUES (1515,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1508);
INSERT INTO V_UNY
	VALUES (1515,
	1514,
	'empty');
INSERT INTO V_VAL
	VALUES (1513,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1508);
INSERT INTO V_UNY
	VALUES (1513,
	1515,
	'not');
INSERT INTO V_VAR
	VALUES (1511,
	1508,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1511,
	0,
	1470);
INSERT INTO ACT_BLK
	VALUES (1512,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	8,
	3,
	7,
	42,
	0,
	0,
	7,
	50,
	7,
	53,
	0,
	0,
	0,
	1507,
	0);
INSERT INTO ACT_SMT
	VALUES (1516,
	1512,
	1517,
	7,
	3,
	'modePressed line: 7');
INSERT INTO ACT_SEL
	VALUES (1516,
	1518,
	1,
	'one',
	1519);
INSERT INTO ACT_SR
	VALUES (1516);
INSERT INTO ACT_LNK
	VALUES (1520,
	'current_status_indicated_on',
	1516,
	1521,
	0,
	2,
	1522,
	7,
	42,
	7,
	50,
	7,
	53);
INSERT INTO ACT_SMT
	VALUES (1517,
	1512,
	0,
	8,
	3,
	'modePressed line: 8');
INSERT INTO E_ESS
	VALUES (1517,
	1,
	0,
	8,
	12,
	8,
	21,
	7,
	42,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (1517);
INSERT INTO E_GSME
	VALUES (1517,
	1523);
INSERT INTO E_GEN
	VALUES (1517,
	1518);
INSERT INTO V_VAL
	VALUES (1519,
	0,
	0,
	7,
	33,
	39,
	0,
	0,
	0,
	0,
	1309,
	1512);
INSERT INTO V_IRF
	VALUES (1519,
	1511);
INSERT INTO V_VAR
	VALUES (1518,
	1512,
	'display',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1518,
	0,
	1522);
INSERT INTO PE_PE
	VALUES (1400,
	1,
	1463,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (1400,
	0,
	'newGoalSpec',
	'',
	'// Create a new goal specification and relate it to the
//   singleton instance of workout session if it exists.
select any session from instances of WorkoutSession;
if ( not empty session )
  create object instance goalSpec of GoalSpec;
  goalSpec.sequenceNumber = param.sequenceNumber;
  goalSpec.minimum = param.minimum;
  goalSpec.maximum = param.maximum;
  goalSpec.span = param.span;
  goalSpec.criteriaType = param.criteriaType;
  goalSpec.spanType = param.spanType;
  relate goalSpec to session across R10.''included_in'';
end if;',
	1192,
	1,
	'',
	0);
INSERT INTO S_SPARM
	VALUES (1524,
	1400,
	'spanType',
	147,
	0,
	'',
	0,
	'');
INSERT INTO S_SPARM
	VALUES (1525,
	1400,
	'criteriaType',
	150,
	0,
	'',
	1524,
	'');
INSERT INTO S_SPARM
	VALUES (1526,
	1400,
	'span',
	153,
	0,
	'',
	1525,
	'');
INSERT INTO S_SPARM
	VALUES (1527,
	1400,
	'maximum',
	153,
	0,
	'',
	1526,
	'');
INSERT INTO S_SPARM
	VALUES (1528,
	1400,
	'minimum',
	153,
	0,
	'',
	1527,
	'');
INSERT INTO S_SPARM
	VALUES (1529,
	1400,
	'sequenceNumber',
	160,
	0,
	'',
	1528,
	'');
INSERT INTO ACT_FNB
	VALUES (1530,
	1400);
INSERT INTO ACT_ACT
	VALUES (1530,
	'function',
	0,
	1531,
	0,
	0,
	'newGoalSpec',
	0);
INSERT INTO ACT_BLK
	VALUES (1531,
	1,
	0,
	0,
	'',
	'',
	'',
	4,
	1,
	3,
	38,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1530,
	0);
INSERT INTO ACT_SMT
	VALUES (1532,
	1531,
	1533,
	3,
	1,
	'newGoalSpec line: 3');
INSERT INTO ACT_FIO
	VALUES (1532,
	1534,
	1,
	'any',
	1470,
	3,
	38);
INSERT INTO ACT_SMT
	VALUES (1533,
	1531,
	0,
	4,
	1,
	'newGoalSpec line: 4');
INSERT INTO ACT_IF
	VALUES (1533,
	1535,
	1536,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1537,
	0,
	0,
	4,
	16,
	22,
	0,
	0,
	0,
	0,
	1309,
	1531);
INSERT INTO V_IRF
	VALUES (1537,
	1534);
INSERT INTO V_VAL
	VALUES (1538,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1531);
INSERT INTO V_UNY
	VALUES (1538,
	1537,
	'empty');
INSERT INTO V_VAL
	VALUES (1536,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1531);
INSERT INTO V_UNY
	VALUES (1536,
	1538,
	'not');
INSERT INTO V_VAR
	VALUES (1534,
	1531,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1534,
	0,
	1470);
INSERT INTO ACT_BLK
	VALUES (1535,
	0,
	0,
	0,
	'included_in',
	'',
	'',
	12,
	3,
	5,
	38,
	0,
	0,
	12,
	37,
	12,
	41,
	0,
	0,
	0,
	1530,
	0);
INSERT INTO ACT_SMT
	VALUES (1539,
	1535,
	1540,
	5,
	3,
	'newGoalSpec line: 5');
INSERT INTO ACT_CR
	VALUES (1539,
	1541,
	1,
	1542,
	5,
	38);
INSERT INTO ACT_SMT
	VALUES (1540,
	1535,
	1543,
	6,
	3,
	'newGoalSpec line: 6');
INSERT INTO ACT_AI
	VALUES (1540,
	1544,
	1545,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1543,
	1535,
	1546,
	7,
	3,
	'newGoalSpec line: 7');
INSERT INTO ACT_AI
	VALUES (1543,
	1547,
	1548,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1546,
	1535,
	1549,
	8,
	3,
	'newGoalSpec line: 8');
INSERT INTO ACT_AI
	VALUES (1546,
	1550,
	1551,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1549,
	1535,
	1552,
	9,
	3,
	'newGoalSpec line: 9');
INSERT INTO ACT_AI
	VALUES (1549,
	1553,
	1554,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1552,
	1535,
	1555,
	10,
	3,
	'newGoalSpec line: 10');
INSERT INTO ACT_AI
	VALUES (1552,
	1556,
	1557,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1555,
	1535,
	1558,
	11,
	3,
	'newGoalSpec line: 11');
INSERT INTO ACT_AI
	VALUES (1555,
	1559,
	1560,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1558,
	1535,
	0,
	12,
	3,
	'newGoalSpec line: 12');
INSERT INTO ACT_REL
	VALUES (1558,
	1541,
	1534,
	'included_in',
	1561,
	12,
	37,
	12,
	41);
INSERT INTO V_VAL
	VALUES (1562,
	1,
	0,
	6,
	3,
	10,
	0,
	0,
	0,
	0,
	1309,
	1535);
INSERT INTO V_IRF
	VALUES (1562,
	1541);
INSERT INTO V_VAL
	VALUES (1545,
	1,
	0,
	6,
	12,
	25,
	0,
	0,
	0,
	0,
	160,
	1535);
INSERT INTO V_AVL
	VALUES (1545,
	1562,
	1542,
	1563);
INSERT INTO V_VAL
	VALUES (1544,
	0,
	0,
	6,
	35,
	48,
	0,
	0,
	0,
	0,
	160,
	1535);
INSERT INTO V_PVL
	VALUES (1544,
	0,
	1529,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1564,
	1,
	0,
	7,
	3,
	10,
	0,
	0,
	0,
	0,
	1309,
	1535);
INSERT INTO V_IRF
	VALUES (1564,
	1541);
INSERT INTO V_VAL
	VALUES (1548,
	1,
	0,
	7,
	12,
	18,
	0,
	0,
	0,
	0,
	153,
	1535);
INSERT INTO V_AVL
	VALUES (1548,
	1564,
	1542,
	1565);
INSERT INTO V_VAL
	VALUES (1547,
	0,
	0,
	7,
	28,
	34,
	0,
	0,
	0,
	0,
	153,
	1535);
INSERT INTO V_PVL
	VALUES (1547,
	0,
	1528,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1566,
	1,
	0,
	8,
	3,
	10,
	0,
	0,
	0,
	0,
	1309,
	1535);
INSERT INTO V_IRF
	VALUES (1566,
	1541);
INSERT INTO V_VAL
	VALUES (1551,
	1,
	0,
	8,
	12,
	18,
	0,
	0,
	0,
	0,
	153,
	1535);
INSERT INTO V_AVL
	VALUES (1551,
	1566,
	1542,
	1567);
INSERT INTO V_VAL
	VALUES (1550,
	0,
	0,
	8,
	28,
	34,
	0,
	0,
	0,
	0,
	153,
	1535);
INSERT INTO V_PVL
	VALUES (1550,
	0,
	1527,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1568,
	1,
	0,
	9,
	3,
	10,
	0,
	0,
	0,
	0,
	1309,
	1535);
INSERT INTO V_IRF
	VALUES (1568,
	1541);
INSERT INTO V_VAL
	VALUES (1554,
	1,
	0,
	9,
	12,
	15,
	0,
	0,
	0,
	0,
	153,
	1535);
INSERT INTO V_AVL
	VALUES (1554,
	1568,
	1542,
	1569);
INSERT INTO V_VAL
	VALUES (1553,
	0,
	0,
	9,
	25,
	28,
	0,
	0,
	0,
	0,
	153,
	1535);
INSERT INTO V_PVL
	VALUES (1553,
	0,
	1526,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1570,
	1,
	0,
	10,
	3,
	10,
	0,
	0,
	0,
	0,
	1309,
	1535);
INSERT INTO V_IRF
	VALUES (1570,
	1541);
INSERT INTO V_VAL
	VALUES (1557,
	1,
	0,
	10,
	12,
	23,
	0,
	0,
	0,
	0,
	150,
	1535);
INSERT INTO V_AVL
	VALUES (1557,
	1570,
	1542,
	1571);
INSERT INTO V_VAL
	VALUES (1556,
	0,
	0,
	10,
	33,
	44,
	0,
	0,
	0,
	0,
	150,
	1535);
INSERT INTO V_PVL
	VALUES (1556,
	0,
	1525,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1572,
	1,
	0,
	11,
	3,
	10,
	0,
	0,
	0,
	0,
	1309,
	1535);
INSERT INTO V_IRF
	VALUES (1572,
	1541);
INSERT INTO V_VAL
	VALUES (1560,
	1,
	0,
	11,
	12,
	19,
	0,
	0,
	0,
	0,
	147,
	1535);
INSERT INTO V_AVL
	VALUES (1560,
	1572,
	1542,
	1573);
INSERT INTO V_VAL
	VALUES (1559,
	0,
	0,
	11,
	29,
	36,
	0,
	0,
	0,
	0,
	147,
	1535);
INSERT INTO V_PVL
	VALUES (1559,
	0,
	1524,
	0,
	0);
INSERT INTO V_VAR
	VALUES (1541,
	1535,
	'goalSpec',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1541,
	0,
	1542);
INSERT INTO PE_PE
	VALUES (1574,
	1,
	0,
	459,
	7);
INSERT INTO EP_PKG
	VALUES (1574,
	0,
	1371,
	'Tracking',
	'',
	0);
INSERT INTO PE_PE
	VALUES (1470,
	1,
	1574,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (1470,
	'WorkoutSession',
	7,
	'WorkoutSession',
	'Each instance represents a single workout session.  

Presently, the device supports only a single session, 
but future releases may support multiple sessions.  
Even in that case, only a single session is executing 
at any given time.  Other sessions represent completed
or planned workout sessions.',
	0);
INSERT INTO O_TFR
	VALUES (1476,
	1470,
	'addHeartRateSample',
	'',
	1192,
	1,
	'// Add a new heart-rate sample and notify the UI of the current heart rate.

select one workoutTimer related by self->WorkoutTimer[R8.''is_timed_by''];

// Create and initialize a new heart-rate sample.
create object instance sample of HeartRateSample; sample.time = workoutTimer.time;
sample.heartRate = param.heartRate;
relate self to sample across R6.''tracks_heart_rate_over_time_as'';

// Notify UI of the new heart rate.
select one display related by self->Display[R7.''current_status_indicated_on''];
generate Display2:refresh to display;',
	1,
	'',
	0,
	0);
INSERT INTO O_TPARM
	VALUES (1575,
	1476,
	'heartRate',
	160,
	0,
	'',
	0,
	'');
INSERT INTO ACT_OPB
	VALUES (1576,
	1476);
INSERT INTO ACT_ACT
	VALUES (1576,
	'operation',
	0,
	1577,
	0,
	0,
	'WorkoutSession::addHeartRateSample',
	0);
INSERT INTO ACT_BLK
	VALUES (1577,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	12,
	1,
	11,
	37,
	0,
	0,
	11,
	45,
	11,
	48,
	0,
	0,
	0,
	1576,
	0);
INSERT INTO ACT_SMT
	VALUES (1578,
	1577,
	1579,
	3,
	1,
	'WorkoutSession::addHeartRateSample line: 3');
INSERT INTO ACT_SEL
	VALUES (1578,
	1580,
	1,
	'one',
	1581);
INSERT INTO ACT_SR
	VALUES (1578);
INSERT INTO ACT_LNK
	VALUES (1582,
	'is_timed_by',
	1578,
	1583,
	0,
	2,
	1488,
	3,
	42,
	3,
	55,
	3,
	58);
INSERT INTO ACT_SMT
	VALUES (1579,
	1577,
	1584,
	6,
	1,
	'WorkoutSession::addHeartRateSample line: 6');
INSERT INTO ACT_CR
	VALUES (1579,
	1585,
	1,
	1586,
	6,
	34);
INSERT INTO ACT_SMT
	VALUES (1584,
	1577,
	1587,
	6,
	51,
	'WorkoutSession::addHeartRateSample line: 6');
INSERT INTO ACT_AI
	VALUES (1584,
	1588,
	1589,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1587,
	1577,
	1590,
	7,
	1,
	'WorkoutSession::addHeartRateSample line: 7');
INSERT INTO ACT_AI
	VALUES (1587,
	1591,
	1592,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1590,
	1577,
	1593,
	8,
	1,
	'WorkoutSession::addHeartRateSample line: 8');
INSERT INTO ACT_REL
	VALUES (1590,
	1594,
	1585,
	'tracks_heart_rate_over_time_as',
	1595,
	8,
	30,
	8,
	33);
INSERT INTO ACT_SMT
	VALUES (1593,
	1577,
	1596,
	11,
	1,
	'WorkoutSession::addHeartRateSample line: 11');
INSERT INTO ACT_SEL
	VALUES (1593,
	1597,
	1,
	'one',
	1598);
INSERT INTO ACT_SR
	VALUES (1593);
INSERT INTO ACT_LNK
	VALUES (1599,
	'current_status_indicated_on',
	1593,
	1521,
	0,
	2,
	1522,
	11,
	37,
	11,
	45,
	11,
	48);
INSERT INTO ACT_SMT
	VALUES (1596,
	1577,
	0,
	12,
	1,
	'WorkoutSession::addHeartRateSample line: 12');
INSERT INTO E_ESS
	VALUES (1596,
	1,
	0,
	12,
	10,
	12,
	19,
	11,
	37,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (1596);
INSERT INTO E_GSME
	VALUES (1596,
	1600);
INSERT INTO E_GEN
	VALUES (1596,
	1597);
INSERT INTO V_VAL
	VALUES (1581,
	0,
	0,
	3,
	36,
	39,
	0,
	0,
	0,
	0,
	1309,
	1577);
INSERT INTO V_IRF
	VALUES (1581,
	1594);
INSERT INTO V_VAL
	VALUES (1601,
	1,
	0,
	6,
	51,
	56,
	0,
	0,
	0,
	0,
	1309,
	1577);
INSERT INTO V_IRF
	VALUES (1601,
	1585);
INSERT INTO V_VAL
	VALUES (1589,
	1,
	0,
	6,
	58,
	61,
	0,
	0,
	0,
	0,
	160,
	1577);
INSERT INTO V_AVL
	VALUES (1589,
	1601,
	1586,
	1602);
INSERT INTO V_VAL
	VALUES (1603,
	0,
	0,
	6,
	65,
	76,
	0,
	0,
	0,
	0,
	1309,
	1577);
INSERT INTO V_IRF
	VALUES (1603,
	1580);
INSERT INTO V_VAL
	VALUES (1588,
	0,
	0,
	6,
	78,
	81,
	0,
	0,
	0,
	0,
	160,
	1577);
INSERT INTO V_AVL
	VALUES (1588,
	1603,
	1488,
	1604);
INSERT INTO V_VAL
	VALUES (1605,
	1,
	0,
	7,
	1,
	6,
	0,
	0,
	0,
	0,
	1309,
	1577);
INSERT INTO V_IRF
	VALUES (1605,
	1585);
INSERT INTO V_VAL
	VALUES (1592,
	1,
	0,
	7,
	8,
	16,
	0,
	0,
	0,
	0,
	160,
	1577);
INSERT INTO V_AVL
	VALUES (1592,
	1605,
	1586,
	1606);
INSERT INTO V_VAL
	VALUES (1591,
	0,
	0,
	7,
	26,
	34,
	0,
	0,
	0,
	0,
	160,
	1577);
INSERT INTO V_PVL
	VALUES (1591,
	0,
	0,
	1575,
	0);
INSERT INTO V_VAL
	VALUES (1598,
	0,
	0,
	11,
	31,
	34,
	0,
	0,
	0,
	0,
	1309,
	1577);
INSERT INTO V_IRF
	VALUES (1598,
	1594);
INSERT INTO V_VAR
	VALUES (1580,
	1577,
	'workoutTimer',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1580,
	0,
	1488);
INSERT INTO V_VAR
	VALUES (1594,
	1577,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1594,
	0,
	1470);
INSERT INTO V_VAR
	VALUES (1585,
	1577,
	'sample',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1585,
	0,
	1586);
INSERT INTO V_VAR
	VALUES (1597,
	1577,
	'display',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1597,
	0,
	1522);
INSERT INTO O_TFR
	VALUES (1607,
	1470,
	'clearHeartRateSamples',
	'',
	1192,
	1,
	'select many samples related by self->HeartRateSample[R6];
for each sample in samples
  unrelate self from sample across R6;
  delete object instance sample;
end for;',
	1,
	'',
	1476,
	0);
INSERT INTO ACT_OPB
	VALUES (1608,
	1607);
INSERT INTO ACT_ACT
	VALUES (1608,
	'operation',
	0,
	1609,
	0,
	0,
	'WorkoutSession::clearHeartRateSamples',
	0);
INSERT INTO ACT_BLK
	VALUES (1609,
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	38,
	0,
	0,
	1,
	54,
	0,
	0,
	0,
	0,
	0,
	1608,
	0);
INSERT INTO ACT_SMT
	VALUES (1610,
	1609,
	1611,
	1,
	1,
	'WorkoutSession::clearHeartRateSamples line: 1');
INSERT INTO ACT_SEL
	VALUES (1610,
	1612,
	1,
	'many',
	1613);
INSERT INTO ACT_SR
	VALUES (1610);
INSERT INTO ACT_LNK
	VALUES (1614,
	'',
	1610,
	1595,
	0,
	3,
	1586,
	1,
	38,
	1,
	54,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1611,
	1609,
	0,
	2,
	1,
	'WorkoutSession::clearHeartRateSamples line: 2');
INSERT INTO ACT_FOR
	VALUES (1611,
	1615,
	1,
	1616,
	1612,
	1586);
INSERT INTO V_VAL
	VALUES (1613,
	0,
	0,
	1,
	32,
	35,
	0,
	0,
	0,
	0,
	1309,
	1609);
INSERT INTO V_IRF
	VALUES (1613,
	1617);
INSERT INTO V_VAR
	VALUES (1612,
	1609,
	'samples',
	1,
	1310);
INSERT INTO V_INS
	VALUES (1612,
	1586);
INSERT INTO V_VAR
	VALUES (1617,
	1609,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1617,
	0,
	1470);
INSERT INTO V_VAR
	VALUES (1616,
	1609,
	'sample',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1616,
	1,
	1586);
INSERT INTO ACT_BLK
	VALUES (1615,
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	3,
	36,
	0,
	0,
	0,
	0,
	0,
	1608,
	0);
INSERT INTO ACT_SMT
	VALUES (1618,
	1615,
	1619,
	3,
	3,
	'WorkoutSession::clearHeartRateSamples line: 3');
INSERT INTO ACT_UNR
	VALUES (1618,
	1617,
	1616,
	'',
	1595,
	3,
	36,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1619,
	1615,
	0,
	4,
	3,
	'WorkoutSession::clearHeartRateSamples line: 4');
INSERT INTO ACT_DEL
	VALUES (1619,
	1616);
INSERT INTO O_TFR
	VALUES (1430,
	1470,
	'initialize',
	'',
	1192,
	0,
	'// Unless a workout session already exists, create and initialize a 
// workout session, workout timer, and tracklog, and relate them all.

select any session from instances of WorkoutSession;

if ( empty session )

  // Create a workout session.
  create object instance session of WorkoutSession;
  session.startTime = TIM::current_clock();
  session.accumulatedDistance = 0.0;

  // Create a workout timer.
  create object instance workoutTimer of WorkoutTimer;
  workoutTimer.initialize();

  // Create a track log.
  create object instance trackLog of TrackLog;
  
  // Create a display.
  create object instance display of Display;

  // Relate them all together.
  relate trackLog to session across R4.''represents_path_for'';
  relate workoutTimer to session across R8.''acts_as_the_stopwatch_for'';
  relate display to session across R7.''indicates_current_status_of'';
  
end if;
',
	1,
	'',
	1607,
	0);
INSERT INTO ACT_OPB
	VALUES (1620,
	1430);
INSERT INTO ACT_ACT
	VALUES (1620,
	'class operation',
	0,
	1621,
	0,
	0,
	'WorkoutSession::initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (1621,
	1,
	0,
	0,
	'',
	'',
	'',
	6,
	1,
	4,
	38,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1620,
	0);
INSERT INTO ACT_SMT
	VALUES (1622,
	1621,
	1623,
	4,
	1,
	'WorkoutSession::initialize line: 4');
INSERT INTO ACT_FIO
	VALUES (1622,
	1624,
	1,
	'any',
	1470,
	4,
	38);
INSERT INTO ACT_SMT
	VALUES (1623,
	1621,
	0,
	6,
	1,
	'WorkoutSession::initialize line: 6');
INSERT INTO ACT_IF
	VALUES (1623,
	1625,
	1626,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1627,
	0,
	0,
	6,
	12,
	18,
	0,
	0,
	0,
	0,
	1309,
	1621);
INSERT INTO V_IRF
	VALUES (1627,
	1624);
INSERT INTO V_VAL
	VALUES (1626,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1621);
INSERT INTO V_UNY
	VALUES (1626,
	1627,
	'empty');
INSERT INTO V_VAR
	VALUES (1624,
	1621,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1624,
	0,
	1470);
INSERT INTO ACT_BLK
	VALUES (1625,
	0,
	0,
	0,
	'indicates_current_status_of',
	'',
	'',
	26,
	3,
	21,
	37,
	0,
	0,
	26,
	36,
	26,
	39,
	0,
	0,
	0,
	1620,
	0);
INSERT INTO ACT_SMT
	VALUES (1628,
	1625,
	1629,
	9,
	3,
	'WorkoutSession::initialize line: 9');
INSERT INTO ACT_CR
	VALUES (1628,
	1624,
	0,
	1470,
	9,
	37);
INSERT INTO ACT_SMT
	VALUES (1629,
	1625,
	1630,
	10,
	3,
	'WorkoutSession::initialize line: 10');
INSERT INTO ACT_AI
	VALUES (1629,
	1631,
	1632,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1630,
	1625,
	1633,
	11,
	3,
	'WorkoutSession::initialize line: 11');
INSERT INTO ACT_AI
	VALUES (1630,
	1634,
	1635,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1633,
	1625,
	1636,
	14,
	3,
	'WorkoutSession::initialize line: 14');
INSERT INTO ACT_CR
	VALUES (1633,
	1637,
	1,
	1488,
	14,
	42);
INSERT INTO ACT_SMT
	VALUES (1636,
	1625,
	1638,
	15,
	3,
	'WorkoutSession::initialize line: 15');
INSERT INTO ACT_TFM
	VALUES (1636,
	1639,
	1637,
	15,
	16,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1638,
	1625,
	1640,
	18,
	3,
	'WorkoutSession::initialize line: 18');
INSERT INTO ACT_CR
	VALUES (1638,
	1641,
	1,
	1642,
	18,
	38);
INSERT INTO ACT_SMT
	VALUES (1640,
	1625,
	1643,
	21,
	3,
	'WorkoutSession::initialize line: 21');
INSERT INTO ACT_CR
	VALUES (1640,
	1644,
	1,
	1522,
	21,
	37);
INSERT INTO ACT_SMT
	VALUES (1643,
	1625,
	1645,
	24,
	3,
	'WorkoutSession::initialize line: 24');
INSERT INTO ACT_REL
	VALUES (1643,
	1641,
	1624,
	'represents_path_for',
	1646,
	24,
	37,
	24,
	40);
INSERT INTO ACT_SMT
	VALUES (1645,
	1625,
	1647,
	25,
	3,
	'WorkoutSession::initialize line: 25');
INSERT INTO ACT_REL
	VALUES (1645,
	1637,
	1624,
	'acts_as_the_stopwatch_for',
	1583,
	25,
	41,
	25,
	44);
INSERT INTO ACT_SMT
	VALUES (1647,
	1625,
	0,
	26,
	3,
	'WorkoutSession::initialize line: 26');
INSERT INTO ACT_REL
	VALUES (1647,
	1644,
	1624,
	'indicates_current_status_of',
	1521,
	26,
	36,
	26,
	39);
INSERT INTO V_VAL
	VALUES (1648,
	1,
	0,
	10,
	3,
	9,
	0,
	0,
	0,
	0,
	1309,
	1625);
INSERT INTO V_IRF
	VALUES (1648,
	1624);
INSERT INTO V_VAL
	VALUES (1632,
	1,
	0,
	10,
	11,
	19,
	0,
	0,
	0,
	0,
	1218,
	1625);
INSERT INTO V_AVL
	VALUES (1632,
	1648,
	1470,
	1649);
INSERT INTO V_VAL
	VALUES (1631,
	0,
	0,
	10,
	28,
	-1,
	0,
	0,
	0,
	0,
	1218,
	1625);
INSERT INTO V_BRV
	VALUES (1631,
	1268,
	1,
	10,
	23);
INSERT INTO V_VAL
	VALUES (1650,
	1,
	0,
	11,
	3,
	9,
	0,
	0,
	0,
	0,
	1309,
	1625);
INSERT INTO V_IRF
	VALUES (1650,
	1624);
INSERT INTO V_VAL
	VALUES (1635,
	1,
	0,
	11,
	11,
	29,
	0,
	0,
	0,
	0,
	153,
	1625);
INSERT INTO V_AVL
	VALUES (1635,
	1650,
	1470,
	1651);
INSERT INTO V_VAL
	VALUES (1634,
	0,
	0,
	11,
	33,
	35,
	0,
	0,
	0,
	0,
	153,
	1625);
INSERT INTO V_LRL
	VALUES (1634,
	'0.0');
INSERT INTO V_VAR
	VALUES (1637,
	1625,
	'workoutTimer',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1637,
	0,
	1488);
INSERT INTO V_VAR
	VALUES (1641,
	1625,
	'trackLog',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1641,
	0,
	1642);
INSERT INTO V_VAR
	VALUES (1644,
	1625,
	'display',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1644,
	0,
	1522);
INSERT INTO O_TFR
	VALUES (1652,
	1470,
	'reset',
	'',
	1192,
	1,
	'// Reset this session, including the timer, track log, goal specifications,
// goals, and achievement records.

// Reset the timer.
select one workoutTimer related by self->WorkoutTimer[R8.''is_timed_by''];
workoutTimer.initialize();

// Reset the track log.
select one trackLog related by self->TrackLog[R4.''captures_path_in''];
trackLog.clearTrackPoints();
trackLog.clearLapMarkers();

// Remove all goal specifications.
select many goalSpecs related by self->GoalSpec[R10.''includes''];
for each goalSpec in goalSpecs
  unrelate self from goalSpec across R10.''includes'';
  delete object instance goalSpec;
end for;

// Remove any currently executing goal and open achievement record.
select one executingGoal related by self->Goal[R11.''is_currently_executing''];
if ( not empty executingGoal )
  select one openAchievement related by executingGoal->Achievement[R14.''has_open''];
  if ( not empty openAchievement )
    unrelate openAchievement from executingGoal across R14.''is_open_for'';
    delete object instance openAchievement;
  end if;
  unrelate self from executingGoal across R11.''is_currently_executing'';
  delete object instance executingGoal;
end if;

// Remove all other goals and achievement records.
select many goals related by self->Goal[R13.''has_executed''];
for each goal in goals
  select many achievements related by goal->Achievement[R12.''has_recorded''];
  for each achievement in achievements
    unrelate goal from achievement across R12.''has_recorded'';
    delete object instance achievement;
  end for;
  unrelate self from goal across R13.''has_executed'';
  delete object instance goal;
end for;

// Reset the session.
self.accumulatedDistance = 0.0;
self.clearHeartRateSamples();
',
	1,
	'',
	1430,
	0);
INSERT INTO ACT_OPB
	VALUES (1653,
	1652);
INSERT INTO ACT_ACT
	VALUES (1653,
	'operation',
	0,
	1654,
	0,
	0,
	'WorkoutSession::reset',
	0);
INSERT INTO ACT_BLK
	VALUES (1654,
	1,
	0,
	0,
	'',
	'',
	'',
	46,
	1,
	33,
	36,
	0,
	0,
	33,
	41,
	33,
	45,
	0,
	0,
	0,
	1653,
	0);
INSERT INTO ACT_SMT
	VALUES (1655,
	1654,
	1656,
	5,
	1,
	'WorkoutSession::reset line: 5');
INSERT INTO ACT_SEL
	VALUES (1655,
	1657,
	1,
	'one',
	1658);
INSERT INTO ACT_SR
	VALUES (1655);
INSERT INTO ACT_LNK
	VALUES (1659,
	'is_timed_by',
	1655,
	1583,
	0,
	2,
	1488,
	5,
	42,
	5,
	55,
	5,
	58);
INSERT INTO ACT_SMT
	VALUES (1656,
	1654,
	1660,
	6,
	1,
	'WorkoutSession::reset line: 6');
INSERT INTO ACT_TFM
	VALUES (1656,
	1639,
	1657,
	6,
	14,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1660,
	1654,
	1661,
	9,
	1,
	'WorkoutSession::reset line: 9');
INSERT INTO ACT_SEL
	VALUES (1660,
	1662,
	1,
	'one',
	1663);
INSERT INTO ACT_SR
	VALUES (1660);
INSERT INTO ACT_LNK
	VALUES (1664,
	'captures_path_in',
	1660,
	1646,
	0,
	2,
	1642,
	9,
	38,
	9,
	47,
	9,
	50);
INSERT INTO ACT_SMT
	VALUES (1661,
	1654,
	1665,
	10,
	1,
	'WorkoutSession::reset line: 10');
INSERT INTO ACT_TFM
	VALUES (1661,
	1666,
	1662,
	10,
	10,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1665,
	1654,
	1667,
	11,
	1,
	'WorkoutSession::reset line: 11');
INSERT INTO ACT_TFM
	VALUES (1665,
	1668,
	1662,
	11,
	10,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1667,
	1654,
	1669,
	14,
	1,
	'WorkoutSession::reset line: 14');
INSERT INTO ACT_SEL
	VALUES (1667,
	1670,
	1,
	'many',
	1671);
INSERT INTO ACT_SR
	VALUES (1667);
INSERT INTO ACT_LNK
	VALUES (1672,
	'includes',
	1667,
	1561,
	0,
	3,
	1542,
	14,
	40,
	14,
	49,
	14,
	53);
INSERT INTO ACT_SMT
	VALUES (1669,
	1654,
	1673,
	15,
	1,
	'WorkoutSession::reset line: 15');
INSERT INTO ACT_FOR
	VALUES (1669,
	1674,
	1,
	1675,
	1670,
	1542);
INSERT INTO ACT_SMT
	VALUES (1673,
	1654,
	1676,
	21,
	1,
	'WorkoutSession::reset line: 21');
INSERT INTO ACT_SEL
	VALUES (1673,
	1677,
	1,
	'one',
	1678);
INSERT INTO ACT_SR
	VALUES (1673);
INSERT INTO ACT_LNK
	VALUES (1679,
	'is_currently_executing',
	1673,
	1680,
	0,
	2,
	1681,
	21,
	43,
	21,
	48,
	21,
	52);
INSERT INTO ACT_SMT
	VALUES (1676,
	1654,
	1682,
	22,
	1,
	'WorkoutSession::reset line: 22');
INSERT INTO ACT_IF
	VALUES (1676,
	1683,
	1684,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1682,
	1654,
	1685,
	33,
	1,
	'WorkoutSession::reset line: 33');
INSERT INTO ACT_SEL
	VALUES (1682,
	1686,
	1,
	'many',
	1687);
INSERT INTO ACT_SR
	VALUES (1682);
INSERT INTO ACT_LNK
	VALUES (1688,
	'has_executed',
	1682,
	1689,
	0,
	3,
	1681,
	33,
	36,
	33,
	41,
	33,
	45);
INSERT INTO ACT_SMT
	VALUES (1685,
	1654,
	1690,
	34,
	1,
	'WorkoutSession::reset line: 34');
INSERT INTO ACT_FOR
	VALUES (1685,
	1691,
	1,
	1692,
	1686,
	1681);
INSERT INTO ACT_SMT
	VALUES (1690,
	1654,
	1693,
	45,
	1,
	'WorkoutSession::reset line: 45');
INSERT INTO ACT_AI
	VALUES (1690,
	1694,
	1695,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1693,
	1654,
	0,
	46,
	1,
	'WorkoutSession::reset line: 46');
INSERT INTO ACT_TFM
	VALUES (1693,
	1607,
	1696,
	46,
	6,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1658,
	0,
	0,
	5,
	36,
	39,
	0,
	0,
	0,
	0,
	1309,
	1654);
INSERT INTO V_IRF
	VALUES (1658,
	1696);
INSERT INTO V_VAL
	VALUES (1663,
	0,
	0,
	9,
	32,
	35,
	0,
	0,
	0,
	0,
	1309,
	1654);
INSERT INTO V_IRF
	VALUES (1663,
	1696);
INSERT INTO V_VAL
	VALUES (1671,
	0,
	0,
	14,
	34,
	37,
	0,
	0,
	0,
	0,
	1309,
	1654);
INSERT INTO V_IRF
	VALUES (1671,
	1696);
INSERT INTO V_VAL
	VALUES (1678,
	0,
	0,
	21,
	37,
	40,
	0,
	0,
	0,
	0,
	1309,
	1654);
INSERT INTO V_IRF
	VALUES (1678,
	1696);
INSERT INTO V_VAL
	VALUES (1697,
	0,
	0,
	22,
	16,
	28,
	0,
	0,
	0,
	0,
	1309,
	1654);
INSERT INTO V_IRF
	VALUES (1697,
	1677);
INSERT INTO V_VAL
	VALUES (1698,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1654);
INSERT INTO V_UNY
	VALUES (1698,
	1697,
	'empty');
INSERT INTO V_VAL
	VALUES (1684,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1654);
INSERT INTO V_UNY
	VALUES (1684,
	1698,
	'not');
INSERT INTO V_VAL
	VALUES (1687,
	0,
	0,
	33,
	30,
	33,
	0,
	0,
	0,
	0,
	1309,
	1654);
INSERT INTO V_IRF
	VALUES (1687,
	1696);
INSERT INTO V_VAL
	VALUES (1699,
	1,
	0,
	45,
	1,
	4,
	0,
	0,
	0,
	0,
	1309,
	1654);
INSERT INTO V_IRF
	VALUES (1699,
	1696);
INSERT INTO V_VAL
	VALUES (1695,
	1,
	0,
	45,
	6,
	24,
	0,
	0,
	0,
	0,
	153,
	1654);
INSERT INTO V_AVL
	VALUES (1695,
	1699,
	1470,
	1651);
INSERT INTO V_VAL
	VALUES (1694,
	0,
	0,
	45,
	28,
	30,
	0,
	0,
	0,
	0,
	153,
	1654);
INSERT INTO V_LRL
	VALUES (1694,
	'0.0');
INSERT INTO V_VAR
	VALUES (1657,
	1654,
	'workoutTimer',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1657,
	0,
	1488);
INSERT INTO V_VAR
	VALUES (1696,
	1654,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1696,
	0,
	1470);
INSERT INTO V_VAR
	VALUES (1662,
	1654,
	'trackLog',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1662,
	0,
	1642);
INSERT INTO V_VAR
	VALUES (1670,
	1654,
	'goalSpecs',
	1,
	1310);
INSERT INTO V_INS
	VALUES (1670,
	1542);
INSERT INTO V_VAR
	VALUES (1675,
	1654,
	'goalSpec',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1675,
	1,
	1542);
INSERT INTO V_VAR
	VALUES (1677,
	1654,
	'executingGoal',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1677,
	0,
	1681);
INSERT INTO V_VAR
	VALUES (1686,
	1654,
	'goals',
	1,
	1310);
INSERT INTO V_INS
	VALUES (1686,
	1681);
INSERT INTO V_VAR
	VALUES (1692,
	1654,
	'goal',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1692,
	1,
	1681);
INSERT INTO ACT_BLK
	VALUES (1674,
	0,
	0,
	0,
	'includes',
	'',
	'',
	17,
	3,
	0,
	0,
	0,
	0,
	16,
	38,
	16,
	42,
	0,
	0,
	0,
	1653,
	0);
INSERT INTO ACT_SMT
	VALUES (1700,
	1674,
	1701,
	16,
	3,
	'WorkoutSession::reset line: 16');
INSERT INTO ACT_UNR
	VALUES (1700,
	1696,
	1675,
	'includes',
	1561,
	16,
	38,
	16,
	42);
INSERT INTO ACT_SMT
	VALUES (1701,
	1674,
	0,
	17,
	3,
	'WorkoutSession::reset line: 17');
INSERT INTO ACT_DEL
	VALUES (1701,
	1675);
INSERT INTO ACT_BLK
	VALUES (1683,
	1,
	0,
	0,
	'is_currently_executing',
	'',
	'',
	29,
	3,
	23,
	56,
	0,
	0,
	28,
	43,
	28,
	47,
	0,
	0,
	0,
	1653,
	0);
INSERT INTO ACT_SMT
	VALUES (1702,
	1683,
	1703,
	23,
	3,
	'WorkoutSession::reset line: 23');
INSERT INTO ACT_SEL
	VALUES (1702,
	1704,
	1,
	'one',
	1705);
INSERT INTO ACT_SR
	VALUES (1702);
INSERT INTO ACT_LNK
	VALUES (1706,
	'has_open',
	1702,
	1707,
	0,
	2,
	1708,
	23,
	56,
	23,
	68,
	23,
	72);
INSERT INTO ACT_SMT
	VALUES (1703,
	1683,
	1709,
	24,
	3,
	'WorkoutSession::reset line: 24');
INSERT INTO ACT_IF
	VALUES (1703,
	1710,
	1711,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1709,
	1683,
	1712,
	28,
	3,
	'WorkoutSession::reset line: 28');
INSERT INTO ACT_UNR
	VALUES (1709,
	1696,
	1677,
	'is_currently_executing',
	1680,
	28,
	43,
	28,
	47);
INSERT INTO ACT_SMT
	VALUES (1712,
	1683,
	0,
	29,
	3,
	'WorkoutSession::reset line: 29');
INSERT INTO ACT_DEL
	VALUES (1712,
	1677);
INSERT INTO V_VAL
	VALUES (1705,
	0,
	0,
	23,
	41,
	53,
	0,
	0,
	0,
	0,
	1309,
	1683);
INSERT INTO V_IRF
	VALUES (1705,
	1677);
INSERT INTO V_VAL
	VALUES (1713,
	0,
	0,
	24,
	18,
	32,
	0,
	0,
	0,
	0,
	1309,
	1683);
INSERT INTO V_IRF
	VALUES (1713,
	1704);
INSERT INTO V_VAL
	VALUES (1714,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1683);
INSERT INTO V_UNY
	VALUES (1714,
	1713,
	'empty');
INSERT INTO V_VAL
	VALUES (1711,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1683);
INSERT INTO V_UNY
	VALUES (1711,
	1714,
	'not');
INSERT INTO V_VAR
	VALUES (1704,
	1683,
	'openAchievement',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1704,
	0,
	1708);
INSERT INTO ACT_BLK
	VALUES (1710,
	0,
	0,
	0,
	'is_open_for',
	'',
	'',
	26,
	5,
	0,
	0,
	0,
	0,
	25,
	56,
	25,
	60,
	0,
	0,
	0,
	1653,
	0);
INSERT INTO ACT_SMT
	VALUES (1715,
	1710,
	1716,
	25,
	5,
	'WorkoutSession::reset line: 25');
INSERT INTO ACT_UNR
	VALUES (1715,
	1704,
	1677,
	'is_open_for',
	1707,
	25,
	56,
	25,
	60);
INSERT INTO ACT_SMT
	VALUES (1716,
	1710,
	0,
	26,
	5,
	'WorkoutSession::reset line: 26');
INSERT INTO ACT_DEL
	VALUES (1716,
	1704);
INSERT INTO ACT_BLK
	VALUES (1691,
	1,
	0,
	0,
	'has_executed',
	'',
	'',
	41,
	3,
	35,
	45,
	0,
	0,
	40,
	34,
	40,
	38,
	0,
	0,
	0,
	1653,
	0);
INSERT INTO ACT_SMT
	VALUES (1717,
	1691,
	1718,
	35,
	3,
	'WorkoutSession::reset line: 35');
INSERT INTO ACT_SEL
	VALUES (1717,
	1719,
	1,
	'many',
	1720);
INSERT INTO ACT_SR
	VALUES (1717);
INSERT INTO ACT_LNK
	VALUES (1721,
	'has_recorded',
	1717,
	1722,
	0,
	3,
	1708,
	35,
	45,
	35,
	57,
	35,
	61);
INSERT INTO ACT_SMT
	VALUES (1718,
	1691,
	1723,
	36,
	3,
	'WorkoutSession::reset line: 36');
INSERT INTO ACT_FOR
	VALUES (1718,
	1724,
	1,
	1725,
	1719,
	1708);
INSERT INTO ACT_SMT
	VALUES (1723,
	1691,
	1726,
	40,
	3,
	'WorkoutSession::reset line: 40');
INSERT INTO ACT_UNR
	VALUES (1723,
	1696,
	1692,
	'has_executed',
	1689,
	40,
	34,
	40,
	38);
INSERT INTO ACT_SMT
	VALUES (1726,
	1691,
	0,
	41,
	3,
	'WorkoutSession::reset line: 41');
INSERT INTO ACT_DEL
	VALUES (1726,
	1692);
INSERT INTO V_VAL
	VALUES (1720,
	0,
	0,
	35,
	39,
	42,
	0,
	0,
	0,
	0,
	1309,
	1691);
INSERT INTO V_IRF
	VALUES (1720,
	1692);
INSERT INTO V_VAR
	VALUES (1719,
	1691,
	'achievements',
	1,
	1310);
INSERT INTO V_INS
	VALUES (1719,
	1708);
INSERT INTO V_VAR
	VALUES (1725,
	1691,
	'achievement',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1725,
	1,
	1708);
INSERT INTO ACT_BLK
	VALUES (1724,
	0,
	0,
	0,
	'has_recorded',
	'',
	'',
	38,
	5,
	0,
	0,
	0,
	0,
	37,
	43,
	37,
	47,
	0,
	0,
	0,
	1653,
	0);
INSERT INTO ACT_SMT
	VALUES (1727,
	1724,
	1728,
	37,
	5,
	'WorkoutSession::reset line: 37');
INSERT INTO ACT_UNR
	VALUES (1727,
	1692,
	1725,
	'has_recorded',
	1722,
	37,
	43,
	37,
	47);
INSERT INTO ACT_SMT
	VALUES (1728,
	1724,
	0,
	38,
	5,
	'WorkoutSession::reset line: 38');
INSERT INTO ACT_DEL
	VALUES (1728,
	1725);
INSERT INTO O_TFR
	VALUES (1729,
	1470,
	'getCurrentSpeed',
	'',
	153,
	1,
	'// Calculate the current speed, expressed in km per hour, by summing 
// the straight-line distance between each of several of the most recent 
// track points and then dividing that sum by the elapsed time between 
// the first and last point in the subset used for the calculation.

select one lastPoint related by self->TrackLog[R4.''captures_path_in'']->TrackPoint[R3.''has_last''];
speed = 0.0;
if ( not empty lastPoint )
  cursor = lastPoint;
  Speed::initialize();
  select any spd from instances of Speed;
  index = spd.SpeedAveragingWindow;  // Number of track points to use when calculating average speed.
  totalDistance = 0.0;
  elapsedTime = 0.0;  // Explicit delcaration because a Real is required for a later calculation.
  elapsedTime = lastPoint.time;
  while ( index > 0 )
    select one previousPoint related by cursor->TrackPoint[R2.preceeds];
    if ( empty previousPoint )
      break;
    end if;
    distance = 0.0;
    send LOC::getDistance( result:distance, fromLat:cursor.latitude, fromLong: cursor.longitude, toLat: previousPoint.latitude, toLong: previousPoint.longitude );
    totalDistance = totalDistance + distance;
    index = index - 1;
    cursor = previousPoint;
  end while;
  elapsedTime = elapsedTime - cursor.time;
  speed = (totalDistance / 1000) / (elapsedTime / spd.SecondsPerHour);
end if;

return speed;',
	1,
	'',
	1652,
	0);
INSERT INTO ACT_OPB
	VALUES (1730,
	1729);
INSERT INTO ACT_ACT
	VALUES (1730,
	'operation',
	0,
	1731,
	0,
	0,
	'WorkoutSession::getCurrentSpeed',
	0);
INSERT INTO ACT_BLK
	VALUES (1731,
	1,
	0,
	0,
	'',
	'',
	'',
	31,
	1,
	6,
	72,
	0,
	0,
	6,
	83,
	6,
	86,
	0,
	0,
	0,
	1730,
	0);
INSERT INTO ACT_SMT
	VALUES (1732,
	1731,
	1733,
	6,
	1,
	'WorkoutSession::getCurrentSpeed line: 6');
INSERT INTO ACT_SEL
	VALUES (1732,
	1734,
	1,
	'one',
	1735);
INSERT INTO ACT_SR
	VALUES (1732);
INSERT INTO ACT_LNK
	VALUES (1736,
	'captures_path_in',
	1732,
	1646,
	1737,
	2,
	1642,
	6,
	39,
	6,
	48,
	6,
	51);
INSERT INTO ACT_LNK
	VALUES (1737,
	'has_last',
	0,
	1738,
	0,
	2,
	1739,
	6,
	72,
	6,
	83,
	6,
	86);
INSERT INTO ACT_SMT
	VALUES (1733,
	1731,
	1740,
	7,
	1,
	'WorkoutSession::getCurrentSpeed line: 7');
INSERT INTO ACT_AI
	VALUES (1733,
	1741,
	1742,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1740,
	1731,
	1743,
	8,
	1,
	'WorkoutSession::getCurrentSpeed line: 8');
INSERT INTO ACT_IF
	VALUES (1740,
	1744,
	1745,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1743,
	1731,
	0,
	31,
	1,
	'WorkoutSession::getCurrentSpeed line: 31');
INSERT INTO ACT_RET
	VALUES (1743,
	1746);
INSERT INTO V_VAL
	VALUES (1735,
	0,
	0,
	6,
	33,
	36,
	0,
	0,
	0,
	0,
	1309,
	1731);
INSERT INTO V_IRF
	VALUES (1735,
	1747);
INSERT INTO V_VAL
	VALUES (1742,
	1,
	1,
	7,
	1,
	5,
	0,
	0,
	0,
	0,
	153,
	1731);
INSERT INTO V_TVL
	VALUES (1742,
	1748);
INSERT INTO V_VAL
	VALUES (1741,
	0,
	0,
	7,
	9,
	11,
	0,
	0,
	0,
	0,
	153,
	1731);
INSERT INTO V_LRL
	VALUES (1741,
	'0.0');
INSERT INTO V_VAL
	VALUES (1749,
	0,
	0,
	8,
	16,
	24,
	0,
	0,
	0,
	0,
	1309,
	1731);
INSERT INTO V_IRF
	VALUES (1749,
	1734);
INSERT INTO V_VAL
	VALUES (1750,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1731);
INSERT INTO V_UNY
	VALUES (1750,
	1749,
	'empty');
INSERT INTO V_VAL
	VALUES (1745,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1731);
INSERT INTO V_UNY
	VALUES (1745,
	1750,
	'not');
INSERT INTO V_VAL
	VALUES (1746,
	0,
	0,
	31,
	8,
	12,
	0,
	0,
	0,
	0,
	153,
	1731);
INSERT INTO V_TVL
	VALUES (1746,
	1748);
INSERT INTO V_VAR
	VALUES (1734,
	1731,
	'lastPoint',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1734,
	0,
	1739);
INSERT INTO V_VAR
	VALUES (1747,
	1731,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1747,
	0,
	1470);
INSERT INTO V_VAR
	VALUES (1748,
	1731,
	'speed',
	1,
	153);
INSERT INTO V_TRN
	VALUES (1748,
	0,
	'');
INSERT INTO ACT_BLK
	VALUES (1744,
	1,
	0,
	0,
	'Speed',
	'',
	'',
	28,
	3,
	11,
	36,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1730,
	0);
INSERT INTO ACT_SMT
	VALUES (1751,
	1744,
	1752,
	9,
	3,
	'WorkoutSession::getCurrentSpeed line: 9');
INSERT INTO ACT_AI
	VALUES (1751,
	1753,
	1754,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1752,
	1744,
	1755,
	10,
	3,
	'WorkoutSession::getCurrentSpeed line: 10');
INSERT INTO ACT_TFM
	VALUES (1752,
	1756,
	0,
	10,
	10,
	10,
	3);
INSERT INTO ACT_SMT
	VALUES (1755,
	1744,
	1757,
	11,
	3,
	'WorkoutSession::getCurrentSpeed line: 11');
INSERT INTO ACT_FIO
	VALUES (1755,
	1758,
	1,
	'any',
	1759,
	11,
	36);
INSERT INTO ACT_SMT
	VALUES (1757,
	1744,
	1760,
	12,
	3,
	'WorkoutSession::getCurrentSpeed line: 12');
INSERT INTO ACT_AI
	VALUES (1757,
	1761,
	1762,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1760,
	1744,
	1763,
	13,
	3,
	'WorkoutSession::getCurrentSpeed line: 13');
INSERT INTO ACT_AI
	VALUES (1760,
	1764,
	1765,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1763,
	1744,
	1766,
	14,
	3,
	'WorkoutSession::getCurrentSpeed line: 14');
INSERT INTO ACT_AI
	VALUES (1763,
	1767,
	1768,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1766,
	1744,
	1769,
	15,
	3,
	'WorkoutSession::getCurrentSpeed line: 15');
INSERT INTO ACT_AI
	VALUES (1766,
	1770,
	1771,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1769,
	1744,
	1772,
	16,
	3,
	'WorkoutSession::getCurrentSpeed line: 16');
INSERT INTO ACT_WHL
	VALUES (1769,
	1773,
	1774);
INSERT INTO ACT_SMT
	VALUES (1772,
	1744,
	1775,
	27,
	3,
	'WorkoutSession::getCurrentSpeed line: 27');
INSERT INTO ACT_AI
	VALUES (1772,
	1776,
	1777,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1775,
	1744,
	0,
	28,
	3,
	'WorkoutSession::getCurrentSpeed line: 28');
INSERT INTO ACT_AI
	VALUES (1775,
	1778,
	1779,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1754,
	1,
	1,
	9,
	3,
	8,
	0,
	0,
	0,
	0,
	1309,
	1744);
INSERT INTO V_IRF
	VALUES (1754,
	1780);
INSERT INTO V_VAL
	VALUES (1753,
	0,
	0,
	9,
	12,
	20,
	0,
	0,
	0,
	0,
	1309,
	1744);
INSERT INTO V_IRF
	VALUES (1753,
	1734);
INSERT INTO V_VAL
	VALUES (1762,
	1,
	1,
	12,
	3,
	7,
	0,
	0,
	0,
	0,
	160,
	1744);
INSERT INTO V_TVL
	VALUES (1762,
	1781);
INSERT INTO V_VAL
	VALUES (1782,
	0,
	0,
	12,
	11,
	13,
	0,
	0,
	0,
	0,
	1309,
	1744);
INSERT INTO V_IRF
	VALUES (1782,
	1758);
INSERT INTO V_VAL
	VALUES (1761,
	0,
	0,
	12,
	15,
	34,
	0,
	0,
	0,
	0,
	160,
	1744);
INSERT INTO V_AVL
	VALUES (1761,
	1782,
	1759,
	1783);
INSERT INTO V_VAL
	VALUES (1765,
	1,
	1,
	13,
	3,
	15,
	0,
	0,
	0,
	0,
	153,
	1744);
INSERT INTO V_TVL
	VALUES (1765,
	1784);
INSERT INTO V_VAL
	VALUES (1764,
	0,
	0,
	13,
	19,
	21,
	0,
	0,
	0,
	0,
	153,
	1744);
INSERT INTO V_LRL
	VALUES (1764,
	'0.0');
INSERT INTO V_VAL
	VALUES (1768,
	1,
	1,
	14,
	3,
	13,
	0,
	0,
	0,
	0,
	153,
	1744);
INSERT INTO V_TVL
	VALUES (1768,
	1785);
INSERT INTO V_VAL
	VALUES (1767,
	0,
	0,
	14,
	17,
	19,
	0,
	0,
	0,
	0,
	153,
	1744);
INSERT INTO V_LRL
	VALUES (1767,
	'0.0');
INSERT INTO V_VAL
	VALUES (1771,
	1,
	0,
	15,
	3,
	13,
	0,
	0,
	0,
	0,
	153,
	1744);
INSERT INTO V_TVL
	VALUES (1771,
	1785);
INSERT INTO V_VAL
	VALUES (1786,
	0,
	0,
	15,
	17,
	25,
	0,
	0,
	0,
	0,
	1309,
	1744);
INSERT INTO V_IRF
	VALUES (1786,
	1734);
INSERT INTO V_VAL
	VALUES (1770,
	0,
	0,
	15,
	27,
	30,
	0,
	0,
	0,
	0,
	160,
	1744);
INSERT INTO V_AVL
	VALUES (1770,
	1786,
	1739,
	1787);
INSERT INTO V_VAL
	VALUES (1788,
	0,
	0,
	16,
	11,
	15,
	0,
	0,
	0,
	0,
	160,
	1744);
INSERT INTO V_TVL
	VALUES (1788,
	1781);
INSERT INTO V_VAL
	VALUES (1773,
	0,
	0,
	16,
	11,
	19,
	0,
	0,
	0,
	0,
	125,
	1744);
INSERT INTO V_BIN
	VALUES (1773,
	1789,
	1788,
	'>');
INSERT INTO V_VAL
	VALUES (1789,
	0,
	0,
	16,
	19,
	19,
	0,
	0,
	0,
	0,
	160,
	1744);
INSERT INTO V_LIN
	VALUES (1789,
	'0');
INSERT INTO V_VAL
	VALUES (1777,
	1,
	0,
	27,
	3,
	13,
	0,
	0,
	0,
	0,
	153,
	1744);
INSERT INTO V_TVL
	VALUES (1777,
	1785);
INSERT INTO V_VAL
	VALUES (1790,
	0,
	0,
	27,
	17,
	27,
	0,
	0,
	0,
	0,
	153,
	1744);
INSERT INTO V_TVL
	VALUES (1790,
	1785);
INSERT INTO V_VAL
	VALUES (1776,
	0,
	0,
	27,
	17,
	41,
	0,
	0,
	0,
	0,
	153,
	1744);
INSERT INTO V_BIN
	VALUES (1776,
	1791,
	1790,
	'-');
INSERT INTO V_VAL
	VALUES (1792,
	0,
	0,
	27,
	31,
	36,
	0,
	0,
	0,
	0,
	1309,
	1744);
INSERT INTO V_IRF
	VALUES (1792,
	1780);
INSERT INTO V_VAL
	VALUES (1791,
	0,
	0,
	27,
	38,
	41,
	0,
	0,
	0,
	0,
	160,
	1744);
INSERT INTO V_AVL
	VALUES (1791,
	1792,
	1739,
	1787);
INSERT INTO V_VAL
	VALUES (1779,
	1,
	0,
	28,
	3,
	7,
	0,
	0,
	0,
	0,
	153,
	1744);
INSERT INTO V_TVL
	VALUES (1779,
	1748);
INSERT INTO V_VAL
	VALUES (1793,
	0,
	0,
	28,
	12,
	24,
	0,
	0,
	0,
	0,
	153,
	1744);
INSERT INTO V_TVL
	VALUES (1793,
	1784);
INSERT INTO V_VAL
	VALUES (1794,
	0,
	0,
	28,
	12,
	31,
	0,
	0,
	0,
	0,
	153,
	1744);
INSERT INTO V_BIN
	VALUES (1794,
	1795,
	1793,
	'/');
INSERT INTO V_VAL
	VALUES (1795,
	0,
	0,
	28,
	28,
	31,
	0,
	0,
	0,
	0,
	160,
	1744);
INSERT INTO V_LIN
	VALUES (1795,
	'1000');
INSERT INTO V_VAL
	VALUES (1778,
	0,
	0,
	28,
	12,
	68,
	0,
	0,
	0,
	0,
	153,
	1744);
INSERT INTO V_BIN
	VALUES (1778,
	1796,
	1794,
	'/');
INSERT INTO V_VAL
	VALUES (1797,
	0,
	0,
	28,
	37,
	47,
	0,
	0,
	0,
	0,
	153,
	1744);
INSERT INTO V_TVL
	VALUES (1797,
	1785);
INSERT INTO V_VAL
	VALUES (1796,
	0,
	0,
	28,
	37,
	68,
	0,
	0,
	0,
	0,
	153,
	1744);
INSERT INTO V_BIN
	VALUES (1796,
	1798,
	1797,
	'/');
INSERT INTO V_VAL
	VALUES (1799,
	0,
	0,
	28,
	51,
	53,
	0,
	0,
	0,
	0,
	1309,
	1744);
INSERT INTO V_IRF
	VALUES (1799,
	1758);
INSERT INTO V_VAL
	VALUES (1798,
	0,
	0,
	28,
	55,
	68,
	0,
	0,
	0,
	0,
	160,
	1744);
INSERT INTO V_AVL
	VALUES (1798,
	1799,
	1759,
	1800);
INSERT INTO V_VAR
	VALUES (1780,
	1744,
	'cursor',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1780,
	0,
	1739);
INSERT INTO V_VAR
	VALUES (1758,
	1744,
	'spd',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1758,
	0,
	1759);
INSERT INTO V_VAR
	VALUES (1781,
	1744,
	'index',
	1,
	160);
INSERT INTO V_TRN
	VALUES (1781,
	0,
	'');
INSERT INTO V_VAR
	VALUES (1784,
	1744,
	'totalDistance',
	1,
	153);
INSERT INTO V_TRN
	VALUES (1784,
	0,
	'');
INSERT INTO V_VAR
	VALUES (1785,
	1744,
	'elapsedTime',
	1,
	153);
INSERT INTO V_TRN
	VALUES (1785,
	0,
	'');
INSERT INTO ACT_BLK
	VALUES (1774,
	1,
	0,
	0,
	'LOC',
	'',
	'',
	25,
	5,
	22,
	10,
	0,
	0,
	17,
	60,
	17,
	63,
	0,
	0,
	0,
	1730,
	0);
INSERT INTO ACT_SMT
	VALUES (1801,
	1774,
	1802,
	17,
	5,
	'WorkoutSession::getCurrentSpeed line: 17');
INSERT INTO ACT_SEL
	VALUES (1801,
	1803,
	1,
	'one',
	1804);
INSERT INTO ACT_SR
	VALUES (1801);
INSERT INTO ACT_LNK
	VALUES (1805,
	'preceeds',
	1801,
	1806,
	0,
	2,
	1739,
	17,
	49,
	17,
	60,
	17,
	63);
INSERT INTO ACT_SMT
	VALUES (1802,
	1774,
	1807,
	18,
	5,
	'WorkoutSession::getCurrentSpeed line: 18');
INSERT INTO ACT_IF
	VALUES (1802,
	1808,
	1809,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1807,
	1774,
	1810,
	21,
	5,
	'WorkoutSession::getCurrentSpeed line: 21');
INSERT INTO ACT_AI
	VALUES (1807,
	1811,
	1812,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1810,
	1774,
	1813,
	22,
	5,
	'WorkoutSession::getCurrentSpeed line: 22');
INSERT INTO ACT_IOP
	VALUES (1810,
	22,
	15,
	22,
	10,
	0,
	1347,
	0);
INSERT INTO ACT_SMT
	VALUES (1813,
	1774,
	1814,
	23,
	5,
	'WorkoutSession::getCurrentSpeed line: 23');
INSERT INTO ACT_AI
	VALUES (1813,
	1815,
	1816,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1814,
	1774,
	1817,
	24,
	5,
	'WorkoutSession::getCurrentSpeed line: 24');
INSERT INTO ACT_AI
	VALUES (1814,
	1818,
	1819,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1817,
	1774,
	0,
	25,
	5,
	'WorkoutSession::getCurrentSpeed line: 25');
INSERT INTO ACT_AI
	VALUES (1817,
	1820,
	1821,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1804,
	0,
	0,
	17,
	41,
	46,
	0,
	0,
	0,
	0,
	1309,
	1774);
INSERT INTO V_IRF
	VALUES (1804,
	1780);
INSERT INTO V_VAL
	VALUES (1822,
	0,
	0,
	18,
	16,
	28,
	0,
	0,
	0,
	0,
	1309,
	1774);
INSERT INTO V_IRF
	VALUES (1822,
	1803);
INSERT INTO V_VAL
	VALUES (1809,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1774);
INSERT INTO V_UNY
	VALUES (1809,
	1822,
	'empty');
INSERT INTO V_VAL
	VALUES (1812,
	1,
	1,
	21,
	5,
	12,
	0,
	0,
	0,
	0,
	153,
	1774);
INSERT INTO V_TVL
	VALUES (1812,
	1823);
INSERT INTO V_VAL
	VALUES (1811,
	0,
	0,
	21,
	16,
	18,
	0,
	0,
	0,
	0,
	153,
	1774);
INSERT INTO V_LRL
	VALUES (1811,
	'0.0');
INSERT INTO V_VAL
	VALUES (1824,
	0,
	0,
	22,
	35,
	42,
	0,
	0,
	0,
	0,
	153,
	1774);
INSERT INTO V_TVL
	VALUES (1824,
	1823);
INSERT INTO V_PAR
	VALUES (1824,
	1810,
	0,
	'result',
	1825,
	22,
	28);
INSERT INTO V_VAL
	VALUES (1826,
	0,
	0,
	22,
	53,
	58,
	0,
	0,
	0,
	0,
	1309,
	1774);
INSERT INTO V_IRF
	VALUES (1826,
	1780);
INSERT INTO V_VAL
	VALUES (1825,
	0,
	0,
	22,
	60,
	67,
	0,
	0,
	0,
	0,
	153,
	1774);
INSERT INTO V_AVL
	VALUES (1825,
	1826,
	1739,
	1827);
INSERT INTO V_PAR
	VALUES (1825,
	1810,
	0,
	'fromLat',
	1828,
	22,
	45);
INSERT INTO V_VAL
	VALUES (1829,
	0,
	0,
	22,
	80,
	85,
	0,
	0,
	0,
	0,
	1309,
	1774);
INSERT INTO V_IRF
	VALUES (1829,
	1780);
INSERT INTO V_VAL
	VALUES (1828,
	0,
	0,
	22,
	87,
	95,
	0,
	0,
	0,
	0,
	153,
	1774);
INSERT INTO V_AVL
	VALUES (1828,
	1829,
	1739,
	1830);
INSERT INTO V_PAR
	VALUES (1828,
	1810,
	0,
	'fromLong',
	1831,
	22,
	70);
INSERT INTO V_VAL
	VALUES (1832,
	0,
	0,
	22,
	105,
	117,
	0,
	0,
	0,
	0,
	1309,
	1774);
INSERT INTO V_IRF
	VALUES (1832,
	1803);
INSERT INTO V_VAL
	VALUES (1831,
	0,
	0,
	22,
	119,
	126,
	0,
	0,
	0,
	0,
	153,
	1774);
INSERT INTO V_AVL
	VALUES (1831,
	1832,
	1739,
	1827);
INSERT INTO V_PAR
	VALUES (1831,
	1810,
	0,
	'toLat',
	1833,
	22,
	98);
INSERT INTO V_VAL
	VALUES (1834,
	0,
	0,
	22,
	137,
	149,
	0,
	0,
	0,
	0,
	1309,
	1774);
INSERT INTO V_IRF
	VALUES (1834,
	1803);
INSERT INTO V_VAL
	VALUES (1833,
	0,
	0,
	22,
	151,
	159,
	0,
	0,
	0,
	0,
	153,
	1774);
INSERT INTO V_AVL
	VALUES (1833,
	1834,
	1739,
	1830);
INSERT INTO V_PAR
	VALUES (1833,
	1810,
	0,
	'toLong',
	0,
	22,
	129);
INSERT INTO V_VAL
	VALUES (1816,
	1,
	0,
	23,
	5,
	17,
	0,
	0,
	0,
	0,
	153,
	1774);
INSERT INTO V_TVL
	VALUES (1816,
	1784);
INSERT INTO V_VAL
	VALUES (1835,
	0,
	0,
	23,
	21,
	33,
	0,
	0,
	0,
	0,
	153,
	1774);
INSERT INTO V_TVL
	VALUES (1835,
	1784);
INSERT INTO V_VAL
	VALUES (1815,
	0,
	0,
	23,
	21,
	44,
	0,
	0,
	0,
	0,
	153,
	1774);
INSERT INTO V_BIN
	VALUES (1815,
	1836,
	1835,
	'+');
INSERT INTO V_VAL
	VALUES (1836,
	0,
	0,
	23,
	37,
	44,
	0,
	0,
	0,
	0,
	153,
	1774);
INSERT INTO V_TVL
	VALUES (1836,
	1823);
INSERT INTO V_VAL
	VALUES (1819,
	1,
	0,
	24,
	5,
	9,
	0,
	0,
	0,
	0,
	160,
	1774);
INSERT INTO V_TVL
	VALUES (1819,
	1781);
INSERT INTO V_VAL
	VALUES (1837,
	0,
	0,
	24,
	13,
	17,
	0,
	0,
	0,
	0,
	160,
	1774);
INSERT INTO V_TVL
	VALUES (1837,
	1781);
INSERT INTO V_VAL
	VALUES (1818,
	0,
	0,
	24,
	13,
	21,
	0,
	0,
	0,
	0,
	160,
	1774);
INSERT INTO V_BIN
	VALUES (1818,
	1838,
	1837,
	'-');
INSERT INTO V_VAL
	VALUES (1838,
	0,
	0,
	24,
	21,
	21,
	0,
	0,
	0,
	0,
	160,
	1774);
INSERT INTO V_LIN
	VALUES (1838,
	'1');
INSERT INTO V_VAL
	VALUES (1821,
	1,
	0,
	25,
	5,
	10,
	0,
	0,
	0,
	0,
	1309,
	1774);
INSERT INTO V_IRF
	VALUES (1821,
	1780);
INSERT INTO V_VAL
	VALUES (1820,
	0,
	0,
	25,
	14,
	26,
	0,
	0,
	0,
	0,
	1309,
	1774);
INSERT INTO V_IRF
	VALUES (1820,
	1803);
INSERT INTO V_VAR
	VALUES (1803,
	1774,
	'previousPoint',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1803,
	0,
	1739);
INSERT INTO V_VAR
	VALUES (1823,
	1774,
	'distance',
	1,
	153);
INSERT INTO V_TRN
	VALUES (1823,
	0,
	'');
INSERT INTO ACT_BLK
	VALUES (1808,
	0,
	0,
	0,
	'',
	'',
	'',
	19,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1730,
	0);
INSERT INTO ACT_SMT
	VALUES (1839,
	1808,
	0,
	19,
	7,
	'WorkoutSession::getCurrentSpeed line: 19');
INSERT INTO ACT_BRK
	VALUES (1839);
INSERT INTO O_TFR
	VALUES (1840,
	1470,
	'getCurrentPace',
	'',
	153,
	1,
	'// Calculate current pace from current speed, converting from km/hour to minutes/km.
result = 0.0;
if ( self.getCurrentSpeed() != 0.0 )
  result = 60.0 / self.getCurrentSpeed();
else
  result = 0.0;
end if;

return result;',
	1,
	'',
	1729,
	0);
INSERT INTO ACT_OPB
	VALUES (1841,
	1840);
INSERT INTO ACT_ACT
	VALUES (1841,
	'operation',
	0,
	1842,
	0,
	0,
	'WorkoutSession::getCurrentPace',
	0);
INSERT INTO ACT_BLK
	VALUES (1842,
	0,
	0,
	0,
	'',
	'',
	'',
	9,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1841,
	0);
INSERT INTO ACT_SMT
	VALUES (1843,
	1842,
	1844,
	2,
	1,
	'WorkoutSession::getCurrentPace line: 2');
INSERT INTO ACT_AI
	VALUES (1843,
	1845,
	1846,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1844,
	1842,
	1847,
	3,
	1,
	'WorkoutSession::getCurrentPace line: 3');
INSERT INTO ACT_IF
	VALUES (1844,
	1848,
	1849,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1850,
	1842,
	0,
	5,
	1,
	'WorkoutSession::getCurrentPace line: 5');
INSERT INTO ACT_E
	VALUES (1850,
	1851,
	1844);
INSERT INTO ACT_SMT
	VALUES (1847,
	1842,
	0,
	9,
	1,
	'WorkoutSession::getCurrentPace line: 9');
INSERT INTO ACT_RET
	VALUES (1847,
	1852);
INSERT INTO V_VAL
	VALUES (1846,
	1,
	1,
	2,
	1,
	6,
	0,
	0,
	0,
	0,
	153,
	1842);
INSERT INTO V_TVL
	VALUES (1846,
	1853);
INSERT INTO V_VAL
	VALUES (1845,
	0,
	0,
	2,
	10,
	12,
	0,
	0,
	0,
	0,
	153,
	1842);
INSERT INTO V_LRL
	VALUES (1845,
	'0.0');
INSERT INTO V_VAL
	VALUES (1854,
	0,
	0,
	3,
	11,
	-1,
	0,
	0,
	0,
	0,
	153,
	1842);
INSERT INTO V_TRV
	VALUES (1854,
	1729,
	1855,
	1,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1849,
	0,
	0,
	3,
	11,
	34,
	0,
	0,
	0,
	0,
	125,
	1842);
INSERT INTO V_BIN
	VALUES (1849,
	1856,
	1854,
	'!=');
INSERT INTO V_VAL
	VALUES (1856,
	0,
	0,
	3,
	32,
	34,
	0,
	0,
	0,
	0,
	153,
	1842);
INSERT INTO V_LRL
	VALUES (1856,
	'0.0');
INSERT INTO V_VAL
	VALUES (1852,
	0,
	0,
	9,
	8,
	13,
	0,
	0,
	0,
	0,
	153,
	1842);
INSERT INTO V_TVL
	VALUES (1852,
	1853);
INSERT INTO V_VAR
	VALUES (1853,
	1842,
	'result',
	1,
	153);
INSERT INTO V_TRN
	VALUES (1853,
	0,
	'');
INSERT INTO V_VAR
	VALUES (1855,
	1842,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1855,
	0,
	1470);
INSERT INTO ACT_BLK
	VALUES (1848,
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1841,
	0);
INSERT INTO ACT_SMT
	VALUES (1857,
	1848,
	0,
	4,
	3,
	'WorkoutSession::getCurrentPace line: 4');
INSERT INTO ACT_AI
	VALUES (1857,
	1858,
	1859,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1859,
	1,
	0,
	4,
	3,
	8,
	0,
	0,
	0,
	0,
	153,
	1848);
INSERT INTO V_TVL
	VALUES (1859,
	1853);
INSERT INTO V_VAL
	VALUES (1860,
	0,
	0,
	4,
	12,
	15,
	0,
	0,
	0,
	0,
	153,
	1848);
INSERT INTO V_LRL
	VALUES (1860,
	'60.0');
INSERT INTO V_VAL
	VALUES (1858,
	0,
	0,
	4,
	12,
	-1,
	0,
	0,
	0,
	0,
	153,
	1848);
INSERT INTO V_BIN
	VALUES (1858,
	1861,
	1860,
	'/');
INSERT INTO V_VAL
	VALUES (1861,
	0,
	0,
	4,
	24,
	-1,
	0,
	0,
	0,
	0,
	153,
	1848);
INSERT INTO V_TRV
	VALUES (1861,
	1729,
	1855,
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (1851,
	0,
	0,
	0,
	'',
	'',
	'',
	6,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1841,
	0);
INSERT INTO ACT_SMT
	VALUES (1862,
	1851,
	0,
	6,
	3,
	'WorkoutSession::getCurrentPace line: 6');
INSERT INTO ACT_AI
	VALUES (1862,
	1863,
	1864,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1864,
	1,
	0,
	6,
	3,
	8,
	0,
	0,
	0,
	0,
	153,
	1851);
INSERT INTO V_TVL
	VALUES (1864,
	1853);
INSERT INTO V_VAL
	VALUES (1863,
	0,
	0,
	6,
	12,
	14,
	0,
	0,
	0,
	0,
	153,
	1851);
INSERT INTO V_LRL
	VALUES (1863,
	'0.0');
INSERT INTO O_TFR
	VALUES (1865,
	1470,
	'getCurrentHeartRate',
	'',
	160,
	1,
	'// Calculate sliding average using the most recent samples.

HeartRateConstants::initialize();
select any hrc from instances of HeartRateConstants;
select one workoutTimer related by self->WorkoutTimer[R8.''is_timed_by''];
select many samples related by self->HeartRateSample[R6.''tracks_heart_rate_over_time_as''] where ( selected.time >= ( workoutTimer.time - (hrc.HeartRateSamplingPeriod * hrc.HeartRateAveragingWindow) ) );
numberOfSamples = 0;
sum = 0;
result = 0;
for each sample in samples
  numberOfSamples = numberOfSamples + 1;
  sum = sum + sample.heartRate;
end for;
if ( numberOfSamples > 0 )
  result = sum / numberOfSamples;
end if;

return result;',
	1,
	'',
	1840,
	0);
INSERT INTO ACT_OPB
	VALUES (1866,
	1865);
INSERT INTO ACT_ACT
	VALUES (1866,
	'operation',
	0,
	1867,
	0,
	0,
	'WorkoutSession::getCurrentHeartRate',
	0);
INSERT INTO ACT_BLK
	VALUES (1867,
	1,
	0,
	1,
	'',
	'',
	'',
	18,
	1,
	6,
	38,
	0,
	0,
	6,
	54,
	6,
	57,
	0,
	0,
	0,
	1866,
	0);
INSERT INTO ACT_SMT
	VALUES (1868,
	1867,
	1869,
	3,
	1,
	'WorkoutSession::getCurrentHeartRate line: 3');
INSERT INTO ACT_TFM
	VALUES (1868,
	1870,
	0,
	3,
	21,
	3,
	1);
INSERT INTO ACT_SMT
	VALUES (1869,
	1867,
	1871,
	4,
	1,
	'WorkoutSession::getCurrentHeartRate line: 4');
INSERT INTO ACT_FIO
	VALUES (1869,
	1872,
	1,
	'any',
	1873,
	4,
	34);
INSERT INTO ACT_SMT
	VALUES (1871,
	1867,
	1874,
	5,
	1,
	'WorkoutSession::getCurrentHeartRate line: 5');
INSERT INTO ACT_SEL
	VALUES (1871,
	1875,
	1,
	'one',
	1876);
INSERT INTO ACT_SR
	VALUES (1871);
INSERT INTO ACT_LNK
	VALUES (1877,
	'is_timed_by',
	1871,
	1583,
	0,
	2,
	1488,
	5,
	42,
	5,
	55,
	5,
	58);
INSERT INTO ACT_SMT
	VALUES (1874,
	1867,
	1878,
	6,
	1,
	'WorkoutSession::getCurrentHeartRate line: 6');
INSERT INTO ACT_SEL
	VALUES (1874,
	1879,
	1,
	'many',
	1880);
INSERT INTO ACT_SRW
	VALUES (1874,
	1881);
INSERT INTO ACT_LNK
	VALUES (1882,
	'tracks_heart_rate_over_time_as',
	1874,
	1595,
	0,
	3,
	1586,
	6,
	38,
	6,
	54,
	6,
	57);
INSERT INTO ACT_SMT
	VALUES (1878,
	1867,
	1883,
	7,
	1,
	'WorkoutSession::getCurrentHeartRate line: 7');
INSERT INTO ACT_AI
	VALUES (1878,
	1884,
	1885,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1883,
	1867,
	1886,
	8,
	1,
	'WorkoutSession::getCurrentHeartRate line: 8');
INSERT INTO ACT_AI
	VALUES (1883,
	1887,
	1888,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1886,
	1867,
	1889,
	9,
	1,
	'WorkoutSession::getCurrentHeartRate line: 9');
INSERT INTO ACT_AI
	VALUES (1886,
	1890,
	1891,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1889,
	1867,
	1892,
	10,
	1,
	'WorkoutSession::getCurrentHeartRate line: 10');
INSERT INTO ACT_FOR
	VALUES (1889,
	1893,
	1,
	1894,
	1879,
	1586);
INSERT INTO ACT_SMT
	VALUES (1892,
	1867,
	1895,
	14,
	1,
	'WorkoutSession::getCurrentHeartRate line: 14');
INSERT INTO ACT_IF
	VALUES (1892,
	1896,
	1897,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1895,
	1867,
	0,
	18,
	1,
	'WorkoutSession::getCurrentHeartRate line: 18');
INSERT INTO ACT_RET
	VALUES (1895,
	1898);
INSERT INTO V_VAL
	VALUES (1876,
	0,
	0,
	5,
	36,
	39,
	0,
	0,
	0,
	0,
	1309,
	1867);
INSERT INTO V_IRF
	VALUES (1876,
	1899);
INSERT INTO V_VAL
	VALUES (1880,
	0,
	0,
	6,
	32,
	35,
	0,
	0,
	0,
	0,
	1309,
	1867);
INSERT INTO V_IRF
	VALUES (1880,
	1899);
INSERT INTO V_VAL
	VALUES (1900,
	0,
	0,
	6,
	99,
	-1,
	0,
	0,
	0,
	0,
	1309,
	1867);
INSERT INTO V_SLR
	VALUES (1900,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1901,
	0,
	0,
	6,
	108,
	111,
	0,
	0,
	0,
	0,
	160,
	1867);
INSERT INTO V_AVL
	VALUES (1901,
	1900,
	1586,
	1602);
INSERT INTO V_VAL
	VALUES (1881,
	0,
	0,
	6,
	108,
	196,
	0,
	0,
	0,
	0,
	125,
	1867);
INSERT INTO V_BIN
	VALUES (1881,
	1902,
	1901,
	'>=');
INSERT INTO V_VAL
	VALUES (1903,
	0,
	0,
	6,
	118,
	129,
	0,
	0,
	0,
	0,
	1309,
	1867);
INSERT INTO V_IRF
	VALUES (1903,
	1875);
INSERT INTO V_VAL
	VALUES (1904,
	0,
	0,
	6,
	131,
	134,
	0,
	0,
	0,
	0,
	160,
	1867);
INSERT INTO V_AVL
	VALUES (1904,
	1903,
	1488,
	1604);
INSERT INTO V_VAL
	VALUES (1902,
	0,
	0,
	6,
	131,
	196,
	0,
	0,
	0,
	0,
	160,
	1867);
INSERT INTO V_BIN
	VALUES (1902,
	1905,
	1904,
	'-');
INSERT INTO V_VAL
	VALUES (1906,
	0,
	0,
	6,
	139,
	141,
	0,
	0,
	0,
	0,
	1309,
	1867);
INSERT INTO V_IRF
	VALUES (1906,
	1872);
INSERT INTO V_VAL
	VALUES (1907,
	0,
	0,
	6,
	143,
	165,
	0,
	0,
	0,
	0,
	160,
	1867);
INSERT INTO V_AVL
	VALUES (1907,
	1906,
	1873,
	1908);
INSERT INTO V_VAL
	VALUES (1905,
	0,
	0,
	6,
	143,
	196,
	0,
	0,
	0,
	0,
	160,
	1867);
INSERT INTO V_BIN
	VALUES (1905,
	1909,
	1907,
	'*');
INSERT INTO V_VAL
	VALUES (1910,
	0,
	0,
	6,
	169,
	171,
	0,
	0,
	0,
	0,
	1309,
	1867);
INSERT INTO V_IRF
	VALUES (1910,
	1872);
INSERT INTO V_VAL
	VALUES (1909,
	0,
	0,
	6,
	173,
	196,
	0,
	0,
	0,
	0,
	160,
	1867);
INSERT INTO V_AVL
	VALUES (1909,
	1910,
	1873,
	1911);
INSERT INTO V_VAL
	VALUES (1885,
	1,
	1,
	7,
	1,
	15,
	0,
	0,
	0,
	0,
	160,
	1867);
INSERT INTO V_TVL
	VALUES (1885,
	1912);
INSERT INTO V_VAL
	VALUES (1884,
	0,
	0,
	7,
	19,
	19,
	0,
	0,
	0,
	0,
	160,
	1867);
INSERT INTO V_LIN
	VALUES (1884,
	'0');
INSERT INTO V_VAL
	VALUES (1888,
	1,
	1,
	8,
	1,
	3,
	0,
	0,
	0,
	0,
	160,
	1867);
INSERT INTO V_TVL
	VALUES (1888,
	1913);
INSERT INTO V_VAL
	VALUES (1887,
	0,
	0,
	8,
	7,
	7,
	0,
	0,
	0,
	0,
	160,
	1867);
INSERT INTO V_LIN
	VALUES (1887,
	'0');
INSERT INTO V_VAL
	VALUES (1891,
	1,
	1,
	9,
	1,
	6,
	0,
	0,
	0,
	0,
	160,
	1867);
INSERT INTO V_TVL
	VALUES (1891,
	1914);
INSERT INTO V_VAL
	VALUES (1890,
	0,
	0,
	9,
	10,
	10,
	0,
	0,
	0,
	0,
	160,
	1867);
INSERT INTO V_LIN
	VALUES (1890,
	'0');
INSERT INTO V_VAL
	VALUES (1915,
	0,
	0,
	14,
	6,
	20,
	0,
	0,
	0,
	0,
	160,
	1867);
INSERT INTO V_TVL
	VALUES (1915,
	1912);
INSERT INTO V_VAL
	VALUES (1897,
	0,
	0,
	14,
	6,
	24,
	0,
	0,
	0,
	0,
	125,
	1867);
INSERT INTO V_BIN
	VALUES (1897,
	1916,
	1915,
	'>');
INSERT INTO V_VAL
	VALUES (1916,
	0,
	0,
	14,
	24,
	24,
	0,
	0,
	0,
	0,
	160,
	1867);
INSERT INTO V_LIN
	VALUES (1916,
	'0');
INSERT INTO V_VAL
	VALUES (1898,
	0,
	0,
	18,
	8,
	13,
	0,
	0,
	0,
	0,
	160,
	1867);
INSERT INTO V_TVL
	VALUES (1898,
	1914);
INSERT INTO V_VAR
	VALUES (1872,
	1867,
	'hrc',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1872,
	0,
	1873);
INSERT INTO V_VAR
	VALUES (1875,
	1867,
	'workoutTimer',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1875,
	0,
	1488);
INSERT INTO V_VAR
	VALUES (1899,
	1867,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1899,
	0,
	1470);
INSERT INTO V_VAR
	VALUES (1879,
	1867,
	'samples',
	1,
	1310);
INSERT INTO V_INS
	VALUES (1879,
	1586);
INSERT INTO V_VAR
	VALUES (1912,
	1867,
	'numberOfSamples',
	1,
	160);
INSERT INTO V_TRN
	VALUES (1912,
	0,
	'');
INSERT INTO V_VAR
	VALUES (1913,
	1867,
	'sum',
	1,
	160);
INSERT INTO V_TRN
	VALUES (1913,
	0,
	'');
INSERT INTO V_VAR
	VALUES (1914,
	1867,
	'result',
	1,
	160);
INSERT INTO V_TRN
	VALUES (1914,
	0,
	'');
INSERT INTO V_VAR
	VALUES (1894,
	1867,
	'sample',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1894,
	1,
	1586);
INSERT INTO ACT_BLK
	VALUES (1893,
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1866,
	0);
INSERT INTO ACT_SMT
	VALUES (1917,
	1893,
	1918,
	11,
	3,
	'WorkoutSession::getCurrentHeartRate line: 11');
INSERT INTO ACT_AI
	VALUES (1917,
	1919,
	1920,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1918,
	1893,
	0,
	12,
	3,
	'WorkoutSession::getCurrentHeartRate line: 12');
INSERT INTO ACT_AI
	VALUES (1918,
	1921,
	1922,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1920,
	1,
	0,
	11,
	3,
	17,
	0,
	0,
	0,
	0,
	160,
	1893);
INSERT INTO V_TVL
	VALUES (1920,
	1912);
INSERT INTO V_VAL
	VALUES (1923,
	0,
	0,
	11,
	21,
	35,
	0,
	0,
	0,
	0,
	160,
	1893);
INSERT INTO V_TVL
	VALUES (1923,
	1912);
INSERT INTO V_VAL
	VALUES (1919,
	0,
	0,
	11,
	21,
	39,
	0,
	0,
	0,
	0,
	160,
	1893);
INSERT INTO V_BIN
	VALUES (1919,
	1924,
	1923,
	'+');
INSERT INTO V_VAL
	VALUES (1924,
	0,
	0,
	11,
	39,
	39,
	0,
	0,
	0,
	0,
	160,
	1893);
INSERT INTO V_LIN
	VALUES (1924,
	'1');
INSERT INTO V_VAL
	VALUES (1922,
	1,
	0,
	12,
	3,
	5,
	0,
	0,
	0,
	0,
	160,
	1893);
INSERT INTO V_TVL
	VALUES (1922,
	1913);
INSERT INTO V_VAL
	VALUES (1925,
	0,
	0,
	12,
	9,
	11,
	0,
	0,
	0,
	0,
	160,
	1893);
INSERT INTO V_TVL
	VALUES (1925,
	1913);
INSERT INTO V_VAL
	VALUES (1921,
	0,
	0,
	12,
	9,
	30,
	0,
	0,
	0,
	0,
	160,
	1893);
INSERT INTO V_BIN
	VALUES (1921,
	1926,
	1925,
	'+');
INSERT INTO V_VAL
	VALUES (1927,
	0,
	0,
	12,
	15,
	20,
	0,
	0,
	0,
	0,
	1309,
	1893);
INSERT INTO V_IRF
	VALUES (1927,
	1894);
INSERT INTO V_VAL
	VALUES (1926,
	0,
	0,
	12,
	22,
	30,
	0,
	0,
	0,
	0,
	160,
	1893);
INSERT INTO V_AVL
	VALUES (1926,
	1927,
	1586,
	1606);
INSERT INTO ACT_BLK
	VALUES (1896,
	0,
	0,
	0,
	'',
	'',
	'',
	15,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1866,
	0);
INSERT INTO ACT_SMT
	VALUES (1928,
	1896,
	0,
	15,
	3,
	'WorkoutSession::getCurrentHeartRate line: 15');
INSERT INTO ACT_AI
	VALUES (1928,
	1929,
	1930,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1930,
	1,
	0,
	15,
	3,
	8,
	0,
	0,
	0,
	0,
	160,
	1896);
INSERT INTO V_TVL
	VALUES (1930,
	1914);
INSERT INTO V_VAL
	VALUES (1931,
	0,
	0,
	15,
	12,
	14,
	0,
	0,
	0,
	0,
	160,
	1896);
INSERT INTO V_TVL
	VALUES (1931,
	1913);
INSERT INTO V_VAL
	VALUES (1929,
	0,
	0,
	15,
	12,
	32,
	0,
	0,
	0,
	0,
	160,
	1896);
INSERT INTO V_BIN
	VALUES (1929,
	1932,
	1931,
	'/');
INSERT INTO V_VAL
	VALUES (1932,
	0,
	0,
	15,
	18,
	32,
	0,
	0,
	0,
	0,
	160,
	1896);
INSERT INTO V_TVL
	VALUES (1932,
	1912);
INSERT INTO O_NBATTR
	VALUES (1649,
	1470);
INSERT INTO O_BATTR
	VALUES (1649,
	1470);
INSERT INTO O_ATTR
	VALUES (1649,
	1470,
	0,
	'startTime',
	'UTC time at which this session commenced.',
	'',
	'startTime',
	0,
	1218,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1651,
	1470);
INSERT INTO O_BATTR
	VALUES (1651,
	1470);
INSERT INTO O_ATTR
	VALUES (1651,
	1470,
	1649,
	'accumulatedDistance',
	'Accumulated distance, expressed in meters, for this workout session.',
	'',
	'accumulatedDistance',
	0,
	153,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	1470);
INSERT INTO O_OIDA
	VALUES (1649,
	1470,
	0,
	'startTime');
INSERT INTO O_ID
	VALUES (1,
	1470);
INSERT INTO O_ID
	VALUES (2,
	1470);
INSERT INTO PE_PE
	VALUES (1488,
	1,
	1574,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (1488,
	'WorkoutTimer',
	1,
	'WorkoutTimer',
	'Represents the stopwatch portion of the device.
This class also knows:
- Track points are stored only when the stopwatch is running.
- If a goal is executing, evaluation of it must be paused when
the timer pauses.
- How to handle the lap/reset signal based on whether the 
stopwatch is currently running.

This is a singleton instance.
',
	0);
INSERT INTO O_TFR
	VALUES (1933,
	1488,
	'activate',
	'',
	1192,
	1,
	'// Start the underlying timer that drives the workout timer.
WorkoutTimerConstants::initialize();
select any wtc from instances of WorkoutTimerConstants;
create event instance evt of WorkoutTimer3:tick() to self; 
self.timer = TIM::timer_start_recurring( event_inst: evt, microseconds: (wtc.timerPeriod * 1000000) );

// Resume evaluation of the currently executing goal, if there is one.
select one executingGoal related by self->WorkoutSession[R8.''acts_as_the_stopwatch_for'']->Goal[R11.''is_currently_executing''];
if ( not empty executingGoal )
  generate Goal2:Evaluate to executingGoal;
end if;

// Resume listening for updates from the GPS and heart monitor.
send LOC::registerListener();
send HR::registerListener();',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (1934,
	1933);
INSERT INTO ACT_ACT
	VALUES (1934,
	'operation',
	0,
	1935,
	0,
	0,
	'WorkoutTimer::activate',
	0);
INSERT INTO ACT_BLK
	VALUES (1935,
	1,
	0,
	0,
	'HR',
	'',
	'',
	15,
	1,
	15,
	6,
	0,
	0,
	8,
	96,
	8,
	100,
	0,
	0,
	0,
	1934,
	0);
INSERT INTO ACT_SMT
	VALUES (1936,
	1935,
	1937,
	2,
	1,
	'WorkoutTimer::activate line: 2');
INSERT INTO ACT_TFM
	VALUES (1936,
	1938,
	0,
	2,
	24,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES (1937,
	1935,
	1939,
	3,
	1,
	'WorkoutTimer::activate line: 3');
INSERT INTO ACT_FIO
	VALUES (1937,
	1940,
	1,
	'any',
	1941,
	3,
	34);
INSERT INTO ACT_SMT
	VALUES (1939,
	1935,
	1942,
	4,
	1,
	'WorkoutTimer::activate line: 4');
INSERT INTO E_ESS
	VALUES (1939,
	1,
	0,
	4,
	30,
	4,
	44,
	3,
	34,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (1939,
	1,
	1943);
INSERT INTO E_CSME
	VALUES (1939,
	1944);
INSERT INTO E_CEI
	VALUES (1939,
	1945);
INSERT INTO ACT_SMT
	VALUES (1942,
	1935,
	1946,
	5,
	1,
	'WorkoutTimer::activate line: 5');
INSERT INTO ACT_AI
	VALUES (1942,
	1947,
	1948,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1946,
	1935,
	1949,
	8,
	1,
	'WorkoutTimer::activate line: 8');
INSERT INTO ACT_SEL
	VALUES (1946,
	1950,
	1,
	'one',
	1951);
INSERT INTO ACT_SR
	VALUES (1946);
INSERT INTO ACT_LNK
	VALUES (1952,
	'acts_as_the_stopwatch_for',
	1946,
	1583,
	1953,
	2,
	1470,
	8,
	43,
	8,
	58,
	8,
	61);
INSERT INTO ACT_LNK
	VALUES (1953,
	'is_currently_executing',
	0,
	1680,
	0,
	2,
	1681,
	8,
	91,
	8,
	96,
	8,
	100);
INSERT INTO ACT_SMT
	VALUES (1949,
	1935,
	1954,
	9,
	1,
	'WorkoutTimer::activate line: 9');
INSERT INTO ACT_IF
	VALUES (1949,
	1955,
	1956,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1954,
	1935,
	1957,
	14,
	1,
	'WorkoutTimer::activate line: 14');
INSERT INTO ACT_IOP
	VALUES (1954,
	14,
	11,
	14,
	6,
	0,
	1349,
	0);
INSERT INTO ACT_SMT
	VALUES (1957,
	1935,
	0,
	15,
	1,
	'WorkoutTimer::activate line: 15');
INSERT INTO ACT_IOP
	VALUES (1957,
	15,
	10,
	15,
	6,
	0,
	1345,
	0);
INSERT INTO V_VAL
	VALUES (1958,
	1,
	0,
	5,
	1,
	4,
	0,
	0,
	0,
	0,
	1309,
	1935);
INSERT INTO V_IRF
	VALUES (1958,
	1945);
INSERT INTO V_VAL
	VALUES (1948,
	1,
	0,
	5,
	6,
	10,
	0,
	0,
	0,
	0,
	1272,
	1935);
INSERT INTO V_AVL
	VALUES (1948,
	1958,
	1488,
	1959);
INSERT INTO V_VAL
	VALUES (1947,
	0,
	0,
	5,
	19,
	-1,
	5,
	42,
	5,
	59,
	1272,
	1935);
INSERT INTO V_BRV
	VALUES (1947,
	1278,
	1,
	5,
	14);
INSERT INTO V_VAL
	VALUES (1960,
	0,
	0,
	5,
	54,
	56,
	0,
	0,
	0,
	0,
	1275,
	1935);
INSERT INTO V_TVL
	VALUES (1960,
	1943);
INSERT INTO V_PAR
	VALUES (1960,
	0,
	1947,
	'event_inst',
	1961,
	5,
	42);
INSERT INTO V_VAL
	VALUES (1962,
	0,
	0,
	5,
	74,
	76,
	0,
	0,
	0,
	0,
	1309,
	1935);
INSERT INTO V_IRF
	VALUES (1962,
	1940);
INSERT INTO V_VAL
	VALUES (1963,
	0,
	0,
	5,
	78,
	88,
	0,
	0,
	0,
	0,
	160,
	1935);
INSERT INTO V_AVL
	VALUES (1963,
	1962,
	1941,
	1964);
INSERT INTO V_VAL
	VALUES (1961,
	0,
	0,
	5,
	78,
	98,
	0,
	0,
	0,
	0,
	160,
	1935);
INSERT INTO V_BIN
	VALUES (1961,
	1965,
	1963,
	'*');
INSERT INTO V_PAR
	VALUES (1961,
	0,
	1947,
	'microseconds',
	0,
	5,
	59);
INSERT INTO V_VAL
	VALUES (1965,
	0,
	0,
	5,
	92,
	98,
	0,
	0,
	0,
	0,
	160,
	1935);
INSERT INTO V_LIN
	VALUES (1965,
	'1000000');
INSERT INTO V_VAL
	VALUES (1951,
	0,
	0,
	8,
	37,
	40,
	0,
	0,
	0,
	0,
	1309,
	1935);
INSERT INTO V_IRF
	VALUES (1951,
	1945);
INSERT INTO V_VAL
	VALUES (1966,
	0,
	0,
	9,
	16,
	28,
	0,
	0,
	0,
	0,
	1309,
	1935);
INSERT INTO V_IRF
	VALUES (1966,
	1950);
INSERT INTO V_VAL
	VALUES (1967,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1935);
INSERT INTO V_UNY
	VALUES (1967,
	1966,
	'empty');
INSERT INTO V_VAL
	VALUES (1956,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1935);
INSERT INTO V_UNY
	VALUES (1956,
	1967,
	'not');
INSERT INTO V_VAR
	VALUES (1940,
	1935,
	'wtc',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1940,
	0,
	1941);
INSERT INTO V_VAR
	VALUES (1943,
	1935,
	'evt',
	1,
	1275);
INSERT INTO V_TRN
	VALUES (1943,
	0,
	'');
INSERT INTO V_VAR
	VALUES (1945,
	1935,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1945,
	0,
	1488);
INSERT INTO V_VAR
	VALUES (1950,
	1935,
	'executingGoal',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1950,
	0,
	1681);
INSERT INTO ACT_BLK
	VALUES (1955,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	10,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1934,
	0);
INSERT INTO ACT_SMT
	VALUES (1968,
	1955,
	0,
	10,
	3,
	'WorkoutTimer::activate line: 10');
INSERT INTO E_ESS
	VALUES (1968,
	1,
	0,
	10,
	12,
	10,
	18,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (1968);
INSERT INTO E_GSME
	VALUES (1968,
	1969);
INSERT INTO E_GEN
	VALUES (1968,
	1950);
INSERT INTO O_TFR
	VALUES (1970,
	1488,
	'deactivate',
	'',
	1192,
	1,
	'// Cancel the timer driving the workout timer, ignoring the return code.
cancelSucceeded = TIM::timer_cancel(timer_inst_ref: self.timer);

// Pause evaluation of the currently executing goal, if there is one.
select one executingGoal related by self->WorkoutSession[R8.''acts_as_the_stopwatch_for'']->Goal[R11.''is_currently_executing''];
if ( not empty executingGoal )
  generate Goal3:Pause to executingGoal;
end if;

// Stop listening for updates from the GPS and heart monitor.
send LOC::unregisterListener();
send HR::unregisterListener();',
	1,
	'',
	1933,
	0);
INSERT INTO ACT_OPB
	VALUES (1971,
	1970);
INSERT INTO ACT_ACT
	VALUES (1971,
	'operation',
	0,
	1972,
	0,
	0,
	'WorkoutTimer::deactivate',
	0);
INSERT INTO ACT_BLK
	VALUES (1972,
	1,
	0,
	0,
	'HR',
	'',
	'',
	12,
	1,
	12,
	6,
	0,
	0,
	5,
	96,
	5,
	100,
	0,
	0,
	0,
	1971,
	0);
INSERT INTO ACT_SMT
	VALUES (1973,
	1972,
	1974,
	2,
	1,
	'WorkoutTimer::deactivate line: 2');
INSERT INTO ACT_AI
	VALUES (1973,
	1975,
	1976,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1974,
	1972,
	1977,
	5,
	1,
	'WorkoutTimer::deactivate line: 5');
INSERT INTO ACT_SEL
	VALUES (1974,
	1978,
	1,
	'one',
	1979);
INSERT INTO ACT_SR
	VALUES (1974);
INSERT INTO ACT_LNK
	VALUES (1980,
	'acts_as_the_stopwatch_for',
	1974,
	1583,
	1981,
	2,
	1470,
	5,
	43,
	5,
	58,
	5,
	61);
INSERT INTO ACT_LNK
	VALUES (1981,
	'is_currently_executing',
	0,
	1680,
	0,
	2,
	1681,
	5,
	91,
	5,
	96,
	5,
	100);
INSERT INTO ACT_SMT
	VALUES (1977,
	1972,
	1982,
	6,
	1,
	'WorkoutTimer::deactivate line: 6');
INSERT INTO ACT_IF
	VALUES (1977,
	1983,
	1984,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (1982,
	1972,
	1985,
	11,
	1,
	'WorkoutTimer::deactivate line: 11');
INSERT INTO ACT_IOP
	VALUES (1982,
	11,
	11,
	11,
	6,
	0,
	1350,
	0);
INSERT INTO ACT_SMT
	VALUES (1985,
	1972,
	0,
	12,
	1,
	'WorkoutTimer::deactivate line: 12');
INSERT INTO ACT_IOP
	VALUES (1985,
	12,
	10,
	12,
	6,
	0,
	1346,
	0);
INSERT INTO V_VAL
	VALUES (1976,
	1,
	1,
	2,
	1,
	15,
	0,
	0,
	0,
	0,
	125,
	1972);
INSERT INTO V_TVL
	VALUES (1976,
	1986);
INSERT INTO V_VAL
	VALUES (1975,
	0,
	0,
	2,
	24,
	-1,
	2,
	37,
	0,
	0,
	125,
	1972);
INSERT INTO V_BRV
	VALUES (1975,
	1297,
	1,
	2,
	19);
INSERT INTO V_VAL
	VALUES (1987,
	0,
	0,
	2,
	53,
	56,
	0,
	0,
	0,
	0,
	1309,
	1972);
INSERT INTO V_IRF
	VALUES (1987,
	1988);
INSERT INTO V_VAL
	VALUES (1989,
	0,
	0,
	2,
	58,
	62,
	0,
	0,
	0,
	0,
	1272,
	1972);
INSERT INTO V_AVL
	VALUES (1989,
	1987,
	1488,
	1959);
INSERT INTO V_PAR
	VALUES (1989,
	0,
	1975,
	'timer_inst_ref',
	0,
	2,
	37);
INSERT INTO V_VAL
	VALUES (1979,
	0,
	0,
	5,
	37,
	40,
	0,
	0,
	0,
	0,
	1309,
	1972);
INSERT INTO V_IRF
	VALUES (1979,
	1988);
INSERT INTO V_VAL
	VALUES (1990,
	0,
	0,
	6,
	16,
	28,
	0,
	0,
	0,
	0,
	1309,
	1972);
INSERT INTO V_IRF
	VALUES (1990,
	1978);
INSERT INTO V_VAL
	VALUES (1991,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1972);
INSERT INTO V_UNY
	VALUES (1991,
	1990,
	'empty');
INSERT INTO V_VAL
	VALUES (1984,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	1972);
INSERT INTO V_UNY
	VALUES (1984,
	1991,
	'not');
INSERT INTO V_VAR
	VALUES (1986,
	1972,
	'cancelSucceeded',
	1,
	125);
INSERT INTO V_TRN
	VALUES (1986,
	0,
	'');
INSERT INTO V_VAR
	VALUES (1988,
	1972,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1988,
	0,
	1488);
INSERT INTO V_VAR
	VALUES (1978,
	1972,
	'executingGoal',
	1,
	1309);
INSERT INTO V_INT
	VALUES (1978,
	0,
	1681);
INSERT INTO ACT_BLK
	VALUES (1983,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1971,
	0);
INSERT INTO ACT_SMT
	VALUES (1992,
	1983,
	0,
	7,
	3,
	'WorkoutTimer::deactivate line: 7');
INSERT INTO E_ESS
	VALUES (1992,
	1,
	0,
	7,
	12,
	7,
	18,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (1992);
INSERT INTO E_GSME
	VALUES (1992,
	1993);
INSERT INTO E_GEN
	VALUES (1992,
	1978);
INSERT INTO O_TFR
	VALUES (1639,
	1488,
	'initialize',
	'',
	1192,
	1,
	'// Initialize this instance.

self.time = 0;',
	1,
	'',
	1970,
	0);
INSERT INTO ACT_OPB
	VALUES (1994,
	1639);
INSERT INTO ACT_ACT
	VALUES (1994,
	'operation',
	0,
	1995,
	0,
	0,
	'WorkoutTimer::initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (1995,
	0,
	0,
	0,
	'',
	'',
	'',
	3,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1994,
	0);
INSERT INTO ACT_SMT
	VALUES (1996,
	1995,
	0,
	3,
	1,
	'WorkoutTimer::initialize line: 3');
INSERT INTO ACT_AI
	VALUES (1996,
	1997,
	1998,
	0,
	0);
INSERT INTO V_VAL
	VALUES (1999,
	1,
	0,
	3,
	1,
	4,
	0,
	0,
	0,
	0,
	1309,
	1995);
INSERT INTO V_IRF
	VALUES (1999,
	2000);
INSERT INTO V_VAL
	VALUES (1998,
	1,
	0,
	3,
	6,
	9,
	0,
	0,
	0,
	0,
	160,
	1995);
INSERT INTO V_AVL
	VALUES (1998,
	1999,
	1488,
	1604);
INSERT INTO V_VAL
	VALUES (1997,
	0,
	0,
	3,
	13,
	13,
	0,
	0,
	0,
	0,
	160,
	1995);
INSERT INTO V_LIN
	VALUES (1997,
	'0');
INSERT INTO V_VAR
	VALUES (2000,
	1995,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2000,
	0,
	1488);
INSERT INTO O_NBATTR
	VALUES (2001,
	1488);
INSERT INTO O_BATTR
	VALUES (2001,
	1488);
INSERT INTO O_ATTR
	VALUES (2001,
	1488,
	1959,
	'current_state',
	'',
	'',
	'current_state',
	0,
	1307,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1604,
	1488);
INSERT INTO O_BATTR
	VALUES (1604,
	1488);
INSERT INTO O_ATTR
	VALUES (1604,
	1488,
	2002,
	'time',
	'Number of seconds elapsed during the associated workout session.
Time elapses only when this timer is running.',
	'',
	'time',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1959,
	1488);
INSERT INTO O_BATTR
	VALUES (1959,
	1488);
INSERT INTO O_ATTR
	VALUES (1959,
	1488,
	1604,
	'timer',
	'Handle for underlying timer mechanism that produces the 
delayed events enabling the timer to track elapsed time.',
	'',
	'timer',
	0,
	1272,
	'',
	'');
INSERT INTO O_REF
	VALUES (1488,
	1470,
	0,
	1649,
	1583,
	2003,
	2004,
	2002,
	2005,
	0,
	0,
	'',
	'WorkoutSession',
	'startTime',
	'R8.''acts_as_the_stopwatch_for''');
INSERT INTO O_RATTR
	VALUES (2002,
	1488,
	1649,
	1470,
	1,
	'startTime');
INSERT INTO O_ATTR
	VALUES (2002,
	1488,
	0,
	'session_startTime',
	'',
	'session_',
	'startTime',
	1,
	1308,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	1488);
INSERT INTO O_OIDA
	VALUES (2002,
	1488,
	0,
	'session_startTime');
INSERT INTO O_ID
	VALUES (1,
	1488);
INSERT INTO O_ID
	VALUES (2,
	1488);
INSERT INTO SM_ISM
	VALUES (2006,
	1488);
INSERT INTO SM_SM
	VALUES (2006,
	'',
	0);
INSERT INTO SM_MOORE
	VALUES (2006);
INSERT INTO SM_LEVT
	VALUES (1489,
	2006,
	0);
INSERT INTO SM_SEVT
	VALUES (1489,
	2006,
	0);
INSERT INTO SM_EVT
	VALUES (1489,
	2006,
	0,
	1,
	'startStopPressed',
	0,
	'',
	'WorkoutTimer1',
	'');
INSERT INTO SM_LEVT
	VALUES (1502,
	2006,
	0);
INSERT INTO SM_SEVT
	VALUES (1502,
	2006,
	0);
INSERT INTO SM_EVT
	VALUES (1502,
	2006,
	0,
	2,
	'lapResetPressed',
	0,
	'',
	'WorkoutTimer2',
	'');
INSERT INTO SM_LEVT
	VALUES (1944,
	2006,
	0);
INSERT INTO SM_SEVT
	VALUES (1944,
	2006,
	0);
INSERT INTO SM_EVT
	VALUES (1944,
	2006,
	0,
	3,
	'tick',
	0,
	'',
	'WorkoutTimer3',
	'');
INSERT INTO SM_LEVT
	VALUES (2007,
	2006,
	0);
INSERT INTO SM_SEVT
	VALUES (2007,
	2006,
	0);
INSERT INTO SM_EVT
	VALUES (2007,
	2006,
	0,
	4,
	'pause',
	0,
	'',
	'WorkoutTimer4',
	'');
INSERT INTO SM_LEVT
	VALUES (2008,
	2006,
	0);
INSERT INTO SM_SEVT
	VALUES (2008,
	2006,
	0);
INSERT INTO SM_EVT
	VALUES (2008,
	2006,
	0,
	5,
	'resume',
	0,
	'',
	'WorkoutTimer5',
	'');
INSERT INTO SM_LEVT
	VALUES (2009,
	2006,
	0);
INSERT INTO SM_SEVT
	VALUES (2009,
	2006,
	0);
INSERT INTO SM_EVT
	VALUES (2009,
	2006,
	0,
	6,
	'startTimer',
	0,
	'',
	'WorkoutTimer6',
	'');
INSERT INTO SM_LEVT
	VALUES (2010,
	2006,
	0);
INSERT INTO SM_SEVT
	VALUES (2010,
	2006,
	0);
INSERT INTO SM_EVT
	VALUES (2010,
	2006,
	0,
	8,
	'lapResetComplete',
	0,
	'',
	'WorkoutTimer8',
	'');
INSERT INTO SM_STATE
	VALUES (2011,
	2006,
	0,
	'stopped',
	1,
	0);
INSERT INTO SM_SEME
	VALUES (2011,
	1489,
	2006,
	0);
INSERT INTO SM_EIGN
	VALUES (2011,
	1502,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2011,
	1502,
	2006,
	0);
INSERT INTO SM_EIGN
	VALUES (2011,
	1944,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2011,
	1944,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2011,
	2007,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2011,
	2007,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2011,
	2008,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2011,
	2008,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2011,
	2009,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2011,
	2009,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2011,
	2010,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2011,
	2010,
	2006,
	0);
INSERT INTO SM_MOAH
	VALUES (2012,
	2006,
	2011);
INSERT INTO SM_AH
	VALUES (2012,
	2006);
INSERT INTO SM_ACT
	VALUES (2012,
	2006,
	1,
	'// Reset the session
select one session related by self->WorkoutSession[R8.''acts_as_the_stopwatch_for''];
session.reset();

// Update the UI.
send UI::setTime(time: self.time);
select one display related by self->WorkoutSession[R8.''acts_as_the_stopwatch_for'']->Display[R7.''current_status_indicated_on''];
generate Display2:refresh to display;',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (2013,
	2006,
	2012);
INSERT INTO ACT_ACT
	VALUES (2013,
	'state',
	0,
	2014,
	0,
	0,
	'WorkoutTimer::stopped',
	0);
INSERT INTO ACT_BLK
	VALUES (2014,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	8,
	1,
	7,
	85,
	0,
	0,
	7,
	93,
	7,
	96,
	0,
	0,
	0,
	2013,
	0);
INSERT INTO ACT_SMT
	VALUES (2015,
	2014,
	2016,
	2,
	1,
	'WorkoutTimer::stopped line: 2');
INSERT INTO ACT_SEL
	VALUES (2015,
	2017,
	1,
	'one',
	2018);
INSERT INTO ACT_SR
	VALUES (2015);
INSERT INTO ACT_LNK
	VALUES (2019,
	'acts_as_the_stopwatch_for',
	2015,
	1583,
	0,
	2,
	1470,
	2,
	37,
	2,
	52,
	2,
	55);
INSERT INTO ACT_SMT
	VALUES (2016,
	2014,
	2020,
	3,
	1,
	'WorkoutTimer::stopped line: 3');
INSERT INTO ACT_TFM
	VALUES (2016,
	1652,
	2017,
	3,
	9,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2020,
	2014,
	2021,
	6,
	1,
	'WorkoutTimer::stopped line: 6');
INSERT INTO ACT_IOP
	VALUES (2020,
	6,
	10,
	6,
	6,
	0,
	1353,
	0);
INSERT INTO ACT_SMT
	VALUES (2021,
	2014,
	2022,
	7,
	1,
	'WorkoutTimer::stopped line: 7');
INSERT INTO ACT_SEL
	VALUES (2021,
	2023,
	1,
	'one',
	2024);
INSERT INTO ACT_SR
	VALUES (2021);
INSERT INTO ACT_LNK
	VALUES (2025,
	'acts_as_the_stopwatch_for',
	2021,
	1583,
	2026,
	2,
	1470,
	7,
	37,
	7,
	52,
	7,
	55);
INSERT INTO ACT_LNK
	VALUES (2026,
	'current_status_indicated_on',
	0,
	1521,
	0,
	2,
	1522,
	7,
	85,
	7,
	93,
	7,
	96);
INSERT INTO ACT_SMT
	VALUES (2022,
	2014,
	0,
	8,
	1,
	'WorkoutTimer::stopped line: 8');
INSERT INTO E_ESS
	VALUES (2022,
	1,
	0,
	8,
	10,
	8,
	19,
	7,
	85,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (2022);
INSERT INTO E_GSME
	VALUES (2022,
	1600);
INSERT INTO E_GEN
	VALUES (2022,
	2023);
INSERT INTO V_VAL
	VALUES (2018,
	0,
	0,
	2,
	31,
	34,
	0,
	0,
	0,
	0,
	1309,
	2014);
INSERT INTO V_IRF
	VALUES (2018,
	2027);
INSERT INTO V_VAL
	VALUES (2028,
	0,
	0,
	6,
	24,
	27,
	0,
	0,
	0,
	0,
	1309,
	2014);
INSERT INTO V_IRF
	VALUES (2028,
	2027);
INSERT INTO V_VAL
	VALUES (2029,
	0,
	0,
	6,
	29,
	32,
	0,
	0,
	0,
	0,
	160,
	2014);
INSERT INTO V_AVL
	VALUES (2029,
	2028,
	1488,
	1604);
INSERT INTO V_PAR
	VALUES (2029,
	2020,
	0,
	'time',
	0,
	6,
	18);
INSERT INTO V_VAL
	VALUES (2024,
	0,
	0,
	7,
	31,
	34,
	0,
	0,
	0,
	0,
	1309,
	2014);
INSERT INTO V_IRF
	VALUES (2024,
	2027);
INSERT INTO V_VAR
	VALUES (2017,
	2014,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2017,
	0,
	1470);
INSERT INTO V_VAR
	VALUES (2027,
	2014,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2027,
	0,
	1488);
INSERT INTO V_VAR
	VALUES (2023,
	2014,
	'display',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2023,
	0,
	1522);
INSERT INTO SM_STATE
	VALUES (2030,
	2006,
	0,
	'running',
	2,
	0);
INSERT INTO SM_SEME
	VALUES (2030,
	1489,
	2006,
	0);
INSERT INTO SM_SEME
	VALUES (2030,
	1502,
	2006,
	0);
INSERT INTO SM_SEME
	VALUES (2030,
	1944,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2030,
	2007,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2030,
	2007,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2030,
	2008,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2030,
	2008,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2030,
	2009,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2030,
	2009,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2030,
	2010,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2030,
	2010,
	2006,
	0);
INSERT INTO SM_MOAH
	VALUES (2031,
	2006,
	2030);
INSERT INTO SM_AH
	VALUES (2031,
	2006);
INSERT INTO SM_ACT
	VALUES (2031,
	2006,
	1,
	'// Update the stopwatch time.
WorkoutTimerConstants::initialize();
select any wtc from instances of WorkoutTimerConstants;
self.time = self.time + wtc.timerPeriod;

// Store a new track point.
select one trackLog related by self->WorkoutSession[R8.''acts_as_the_stopwatch_for'']->TrackLog[R4.''captures_path_in''];
trackLog.addTrackPoint();

// Refresh the user interface.
send UI::setTime(time: self.time);
',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (2032,
	2006,
	2031);
INSERT INTO ACT_ACT
	VALUES (2032,
	'state',
	0,
	2033,
	0,
	0,
	'WorkoutTimer::running',
	0);
INSERT INTO ACT_BLK
	VALUES (2033,
	1,
	0,
	0,
	'UI',
	'',
	'',
	11,
	1,
	11,
	6,
	0,
	0,
	7,
	95,
	7,
	98,
	0,
	0,
	0,
	2032,
	0);
INSERT INTO ACT_SMT
	VALUES (2034,
	2033,
	2035,
	2,
	1,
	'WorkoutTimer::running line: 2');
INSERT INTO ACT_TFM
	VALUES (2034,
	1938,
	0,
	2,
	24,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES (2035,
	2033,
	2036,
	3,
	1,
	'WorkoutTimer::running line: 3');
INSERT INTO ACT_FIO
	VALUES (2035,
	2037,
	1,
	'any',
	1941,
	3,
	34);
INSERT INTO ACT_SMT
	VALUES (2036,
	2033,
	2038,
	4,
	1,
	'WorkoutTimer::running line: 4');
INSERT INTO ACT_AI
	VALUES (2036,
	2039,
	2040,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2038,
	2033,
	2041,
	7,
	1,
	'WorkoutTimer::running line: 7');
INSERT INTO ACT_SEL
	VALUES (2038,
	2042,
	1,
	'one',
	2043);
INSERT INTO ACT_SR
	VALUES (2038);
INSERT INTO ACT_LNK
	VALUES (2044,
	'acts_as_the_stopwatch_for',
	2038,
	1583,
	2045,
	2,
	1470,
	7,
	38,
	7,
	53,
	7,
	56);
INSERT INTO ACT_LNK
	VALUES (2045,
	'captures_path_in',
	0,
	1646,
	0,
	2,
	1642,
	7,
	86,
	7,
	95,
	7,
	98);
INSERT INTO ACT_SMT
	VALUES (2041,
	2033,
	2046,
	8,
	1,
	'WorkoutTimer::running line: 8');
INSERT INTO ACT_TFM
	VALUES (2041,
	2047,
	2042,
	8,
	10,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2046,
	2033,
	0,
	11,
	1,
	'WorkoutTimer::running line: 11');
INSERT INTO ACT_IOP
	VALUES (2046,
	11,
	10,
	11,
	6,
	0,
	1353,
	0);
INSERT INTO V_VAL
	VALUES (2048,
	1,
	0,
	4,
	1,
	4,
	0,
	0,
	0,
	0,
	1309,
	2033);
INSERT INTO V_IRF
	VALUES (2048,
	2049);
INSERT INTO V_VAL
	VALUES (2040,
	1,
	0,
	4,
	6,
	9,
	0,
	0,
	0,
	0,
	160,
	2033);
INSERT INTO V_AVL
	VALUES (2040,
	2048,
	1488,
	1604);
INSERT INTO V_VAL
	VALUES (2050,
	0,
	0,
	4,
	13,
	16,
	0,
	0,
	0,
	0,
	1309,
	2033);
INSERT INTO V_IRF
	VALUES (2050,
	2049);
INSERT INTO V_VAL
	VALUES (2051,
	0,
	0,
	4,
	18,
	21,
	0,
	0,
	0,
	0,
	160,
	2033);
INSERT INTO V_AVL
	VALUES (2051,
	2050,
	1488,
	1604);
INSERT INTO V_VAL
	VALUES (2039,
	0,
	0,
	4,
	18,
	39,
	0,
	0,
	0,
	0,
	160,
	2033);
INSERT INTO V_BIN
	VALUES (2039,
	2052,
	2051,
	'+');
INSERT INTO V_VAL
	VALUES (2053,
	0,
	0,
	4,
	25,
	27,
	0,
	0,
	0,
	0,
	1309,
	2033);
INSERT INTO V_IRF
	VALUES (2053,
	2037);
INSERT INTO V_VAL
	VALUES (2052,
	0,
	0,
	4,
	29,
	39,
	0,
	0,
	0,
	0,
	160,
	2033);
INSERT INTO V_AVL
	VALUES (2052,
	2053,
	1941,
	1964);
INSERT INTO V_VAL
	VALUES (2043,
	0,
	0,
	7,
	32,
	35,
	0,
	0,
	0,
	0,
	1309,
	2033);
INSERT INTO V_IRF
	VALUES (2043,
	2049);
INSERT INTO V_VAL
	VALUES (2054,
	0,
	0,
	11,
	24,
	27,
	0,
	0,
	0,
	0,
	1309,
	2033);
INSERT INTO V_IRF
	VALUES (2054,
	2049);
INSERT INTO V_VAL
	VALUES (2055,
	0,
	0,
	11,
	29,
	32,
	0,
	0,
	0,
	0,
	160,
	2033);
INSERT INTO V_AVL
	VALUES (2055,
	2054,
	1488,
	1604);
INSERT INTO V_PAR
	VALUES (2055,
	2046,
	0,
	'time',
	0,
	11,
	18);
INSERT INTO V_VAR
	VALUES (2037,
	2033,
	'wtc',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2037,
	0,
	1941);
INSERT INTO V_VAR
	VALUES (2049,
	2033,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2049,
	0,
	1488);
INSERT INTO V_VAR
	VALUES (2042,
	2033,
	'trackLog',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2042,
	0,
	1642);
INSERT INTO SM_STATE
	VALUES (2056,
	2006,
	0,
	'paused',
	3,
	0);
INSERT INTO SM_SEME
	VALUES (2056,
	1489,
	2006,
	0);
INSERT INTO SM_SEME
	VALUES (2056,
	1502,
	2006,
	0);
INSERT INTO SM_EIGN
	VALUES (2056,
	1944,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2056,
	1944,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2056,
	2007,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2056,
	2007,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2056,
	2008,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2056,
	2008,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2056,
	2009,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2056,
	2009,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2056,
	2010,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2056,
	2010,
	2006,
	0);
INSERT INTO SM_MOAH
	VALUES (2057,
	2006,
	2056);
INSERT INTO SM_AH
	VALUES (2057,
	2006);
INSERT INTO SM_ACT
	VALUES (2057,
	2006,
	1,
	'self.deactivate();
',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (2058,
	2006,
	2057);
INSERT INTO ACT_ACT
	VALUES (2058,
	'state',
	0,
	2059,
	0,
	0,
	'WorkoutTimer::paused',
	0);
INSERT INTO ACT_BLK
	VALUES (2059,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2058,
	0);
INSERT INTO ACT_SMT
	VALUES (2060,
	2059,
	0,
	1,
	1,
	'WorkoutTimer::paused line: 1');
INSERT INTO ACT_TFM
	VALUES (2060,
	1970,
	2061,
	1,
	6,
	0,
	0);
INSERT INTO V_VAR
	VALUES (2061,
	2059,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2061,
	0,
	1488);
INSERT INTO SM_STATE
	VALUES (2062,
	2006,
	0,
	'processingStart',
	6,
	0);
INSERT INTO SM_CH
	VALUES (2062,
	1489,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2062,
	1489,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2062,
	1502,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2062,
	1502,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2062,
	1944,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2062,
	1944,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2062,
	2007,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2062,
	2007,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2062,
	2008,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2062,
	2008,
	2006,
	0);
INSERT INTO SM_SEME
	VALUES (2062,
	2009,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2062,
	2010,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2062,
	2010,
	2006,
	0);
INSERT INTO SM_MOAH
	VALUES (2063,
	2006,
	2062);
INSERT INTO SM_AH
	VALUES (2063,
	2006);
INSERT INTO SM_ACT
	VALUES (2063,
	2006,
	1,
	'// Start the timer.
self.activate();
generate WorkoutTimer6:startTimer() to self;',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (2064,
	2006,
	2063);
INSERT INTO ACT_ACT
	VALUES (2064,
	'state',
	0,
	2065,
	0,
	0,
	'WorkoutTimer::processingStart',
	0);
INSERT INTO ACT_BLK
	VALUES (2065,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	3,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2064,
	0);
INSERT INTO ACT_SMT
	VALUES (2066,
	2065,
	2067,
	2,
	1,
	'WorkoutTimer::processingStart line: 2');
INSERT INTO ACT_TFM
	VALUES (2066,
	1933,
	2068,
	2,
	6,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2067,
	2065,
	0,
	3,
	1,
	'WorkoutTimer::processingStart line: 3');
INSERT INTO E_ESS
	VALUES (2067,
	1,
	0,
	3,
	10,
	3,
	24,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (2067);
INSERT INTO E_GSME
	VALUES (2067,
	2009);
INSERT INTO E_GEN
	VALUES (2067,
	2068);
INSERT INTO V_VAR
	VALUES (2068,
	2065,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2068,
	0,
	1488);
INSERT INTO SM_STATE
	VALUES (2069,
	2006,
	0,
	'resetLap',
	8,
	0);
INSERT INTO SM_CH
	VALUES (2069,
	1489,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2069,
	1489,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2069,
	1502,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2069,
	1502,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2069,
	1944,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2069,
	1944,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2069,
	2007,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2069,
	2007,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2069,
	2008,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2069,
	2008,
	2006,
	0);
INSERT INTO SM_CH
	VALUES (2069,
	2009,
	2006,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2069,
	2009,
	2006,
	0);
INSERT INTO SM_SEME
	VALUES (2069,
	2010,
	2006,
	0);
INSERT INTO SM_MOAH
	VALUES (2070,
	2006,
	2069);
INSERT INTO SM_AH
	VALUES (2070,
	2006);
INSERT INTO SM_ACT
	VALUES (2070,
	2006,
	1,
	'select any trackLog from instances of TrackLog;
if (not empty trackLog)
  trackLog.addLapMarker();
end if;
generate WorkoutTimer8:lapResetComplete() to self;',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (2071,
	2006,
	2070);
INSERT INTO ACT_ACT
	VALUES (2071,
	'state',
	0,
	2072,
	0,
	0,
	'WorkoutTimer::resetLap',
	0);
INSERT INTO ACT_BLK
	VALUES (2072,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	5,
	1,
	1,
	39,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2071,
	0);
INSERT INTO ACT_SMT
	VALUES (2073,
	2072,
	2074,
	1,
	1,
	'WorkoutTimer::resetLap line: 1');
INSERT INTO ACT_FIO
	VALUES (2073,
	2075,
	1,
	'any',
	1642,
	1,
	39);
INSERT INTO ACT_SMT
	VALUES (2074,
	2072,
	2076,
	2,
	1,
	'WorkoutTimer::resetLap line: 2');
INSERT INTO ACT_IF
	VALUES (2074,
	2077,
	2078,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2076,
	2072,
	0,
	5,
	1,
	'WorkoutTimer::resetLap line: 5');
INSERT INTO E_ESS
	VALUES (2076,
	1,
	0,
	5,
	10,
	5,
	24,
	1,
	39,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (2076);
INSERT INTO E_GSME
	VALUES (2076,
	2010);
INSERT INTO E_GEN
	VALUES (2076,
	2079);
INSERT INTO V_VAL
	VALUES (2080,
	0,
	0,
	2,
	15,
	22,
	0,
	0,
	0,
	0,
	1309,
	2072);
INSERT INTO V_IRF
	VALUES (2080,
	2075);
INSERT INTO V_VAL
	VALUES (2081,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2072);
INSERT INTO V_UNY
	VALUES (2081,
	2080,
	'empty');
INSERT INTO V_VAL
	VALUES (2078,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2072);
INSERT INTO V_UNY
	VALUES (2078,
	2081,
	'not');
INSERT INTO V_VAR
	VALUES (2075,
	2072,
	'trackLog',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2075,
	0,
	1642);
INSERT INTO V_VAR
	VALUES (2079,
	2072,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2079,
	0,
	1488);
INSERT INTO ACT_BLK
	VALUES (2077,
	0,
	0,
	0,
	'',
	'',
	'',
	3,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2071,
	0);
INSERT INTO ACT_SMT
	VALUES (2082,
	2077,
	0,
	3,
	3,
	'WorkoutTimer::resetLap line: 3');
INSERT INTO ACT_TFM
	VALUES (2082,
	2083,
	2075,
	3,
	12,
	0,
	0);
INSERT INTO SM_NSTXN
	VALUES (2084,
	2006,
	2056,
	1502,
	0);
INSERT INTO SM_TAH
	VALUES (2085,
	2006,
	2084);
INSERT INTO SM_AH
	VALUES (2085,
	2006);
INSERT INTO SM_ACT
	VALUES (2085,
	2006,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2086,
	2006,
	2085);
INSERT INTO ACT_ACT
	VALUES (2086,
	'transition',
	0,
	2087,
	0,
	0,
	'WorkoutTimer2: lapResetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (2087,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2086,
	0);
INSERT INTO SM_TXN
	VALUES (2084,
	2006,
	2011,
	0);
INSERT INTO SM_NSTXN
	VALUES (2088,
	2006,
	2011,
	1489,
	0);
INSERT INTO SM_TAH
	VALUES (2089,
	2006,
	2088);
INSERT INTO SM_AH
	VALUES (2089,
	2006);
INSERT INTO SM_ACT
	VALUES (2089,
	2006,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2090,
	2006,
	2089);
INSERT INTO ACT_ACT
	VALUES (2090,
	'transition',
	0,
	2091,
	0,
	0,
	'WorkoutTimer1: startStopPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (2091,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2090,
	0);
INSERT INTO SM_TXN
	VALUES (2088,
	2006,
	2062,
	0);
INSERT INTO SM_NSTXN
	VALUES (2092,
	2006,
	2062,
	2009,
	0);
INSERT INTO SM_TAH
	VALUES (2093,
	2006,
	2092);
INSERT INTO SM_AH
	VALUES (2093,
	2006);
INSERT INTO SM_ACT
	VALUES (2093,
	2006,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2094,
	2006,
	2093);
INSERT INTO ACT_ACT
	VALUES (2094,
	'transition',
	0,
	2095,
	0,
	0,
	'WorkoutTimer6: startTimer',
	0);
INSERT INTO ACT_BLK
	VALUES (2095,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2094,
	0);
INSERT INTO SM_TXN
	VALUES (2092,
	2006,
	2030,
	0);
INSERT INTO SM_NSTXN
	VALUES (2096,
	2006,
	2030,
	1502,
	0);
INSERT INTO SM_TAH
	VALUES (2097,
	2006,
	2096);
INSERT INTO SM_AH
	VALUES (2097,
	2006);
INSERT INTO SM_ACT
	VALUES (2097,
	2006,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2098,
	2006,
	2097);
INSERT INTO ACT_ACT
	VALUES (2098,
	'transition',
	0,
	2099,
	0,
	0,
	'WorkoutTimer2: lapResetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (2099,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2098,
	0);
INSERT INTO SM_TXN
	VALUES (2096,
	2006,
	2069,
	0);
INSERT INTO SM_NSTXN
	VALUES (2100,
	2006,
	2069,
	2010,
	0);
INSERT INTO SM_TAH
	VALUES (2101,
	2006,
	2100);
INSERT INTO SM_AH
	VALUES (2101,
	2006);
INSERT INTO SM_ACT
	VALUES (2101,
	2006,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2102,
	2006,
	2101);
INSERT INTO ACT_ACT
	VALUES (2102,
	'transition',
	0,
	2103,
	0,
	0,
	'WorkoutTimer8: lapResetComplete',
	0);
INSERT INTO ACT_BLK
	VALUES (2103,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2102,
	0);
INSERT INTO SM_TXN
	VALUES (2100,
	2006,
	2030,
	0);
INSERT INTO SM_NSTXN
	VALUES (2104,
	2006,
	2030,
	1944,
	0);
INSERT INTO SM_TAH
	VALUES (2105,
	2006,
	2104);
INSERT INTO SM_AH
	VALUES (2105,
	2006);
INSERT INTO SM_ACT
	VALUES (2105,
	2006,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2106,
	2006,
	2105);
INSERT INTO ACT_ACT
	VALUES (2106,
	'transition',
	0,
	2107,
	0,
	0,
	'WorkoutTimer3: tick',
	0);
INSERT INTO ACT_BLK
	VALUES (2107,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2106,
	0);
INSERT INTO SM_TXN
	VALUES (2104,
	2006,
	2030,
	0);
INSERT INTO SM_NSTXN
	VALUES (2108,
	2006,
	2030,
	1489,
	0);
INSERT INTO SM_TAH
	VALUES (2109,
	2006,
	2108);
INSERT INTO SM_AH
	VALUES (2109,
	2006);
INSERT INTO SM_ACT
	VALUES (2109,
	2006,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2110,
	2006,
	2109);
INSERT INTO ACT_ACT
	VALUES (2110,
	'transition',
	0,
	2111,
	0,
	0,
	'WorkoutTimer1: startStopPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (2111,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2110,
	0);
INSERT INTO SM_TXN
	VALUES (2108,
	2006,
	2056,
	0);
INSERT INTO SM_NSTXN
	VALUES (2112,
	2006,
	2056,
	1489,
	0);
INSERT INTO SM_TAH
	VALUES (2113,
	2006,
	2112);
INSERT INTO SM_AH
	VALUES (2113,
	2006);
INSERT INTO SM_ACT
	VALUES (2113,
	2006,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2114,
	2006,
	2113);
INSERT INTO ACT_ACT
	VALUES (2114,
	'transition',
	0,
	2115,
	0,
	0,
	'WorkoutTimer1: startStopPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (2115,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2114,
	0);
INSERT INTO SM_TXN
	VALUES (2112,
	2006,
	2062,
	0);
INSERT INTO PE_PE
	VALUES (1739,
	1,
	1574,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (1739,
	'TrackPoint',
	3,
	'TrackPoint',
	'Each instance represents a single location through which the device
passed during a workout session.',
	0);
INSERT INTO O_NBATTR
	VALUES (1787,
	1739);
INSERT INTO O_BATTR
	VALUES (1787,
	1739);
INSERT INTO O_ATTR
	VALUES (1787,
	1739,
	2116,
	'time',
	'Number of seconds between start time for the associated workout and recording of this location.
',
	'',
	'time',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1830,
	1739);
INSERT INTO O_BATTR
	VALUES (1830,
	1739);
INSERT INTO O_ATTR
	VALUES (1830,
	1739,
	1787,
	'longitude',
	'Longitude, expressed in decimal degrees where eastern figures are positve
and western ones are negative.',
	'',
	'longitude',
	0,
	153,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1827,
	1739);
INSERT INTO O_BATTR
	VALUES (1827,
	1739);
INSERT INTO O_ATTR
	VALUES (1827,
	1739,
	1830,
	'latitude',
	'Latitude, expressed in decimal degrees, where northern figures are positive
and southern ones are negative.',
	'',
	'latitude',
	0,
	153,
	'',
	'');
INSERT INTO O_REF
	VALUES (1739,
	1642,
	0,
	2117,
	2118,
	2119,
	2120,
	2116,
	2121,
	0,
	0,
	'',
	'TrackLog',
	'session_startTime',
	'R1.''is_start_of''');
INSERT INTO O_REF
	VALUES (1739,
	1642,
	0,
	2117,
	1738,
	2122,
	2123,
	2116,
	2124,
	2121,
	0,
	'',
	'TrackLog',
	'session_startTime',
	'R3.''is_last_for''');
INSERT INTO O_REF
	VALUES (1739,
	1739,
	0,
	2116,
	1806,
	2125,
	2126,
	2116,
	2127,
	2124,
	0,
	'',
	'TrackPoint',
	'session_startTime',
	'R2.''preceeds''');
INSERT INTO O_RATTR
	VALUES (2116,
	1739,
	1649,
	1470,
	1,
	'startTime');
INSERT INTO O_ATTR
	VALUES (2116,
	1739,
	0,
	'session_startTime',
	'



',
	'',
	'session_startTime',
	2,
	1308,
	'',
	'');
INSERT INTO O_REF
	VALUES (1739,
	1739,
	0,
	1787,
	1806,
	2125,
	2126,
	2128,
	2129,
	0,
	0,
	'',
	'TrackPoint',
	'time',
	'R2.''preceeds''');
INSERT INTO O_RATTR
	VALUES (2128,
	1739,
	1787,
	1739,
	1,
	'time');
INSERT INTO O_ATTR
	VALUES (2128,
	1739,
	1827,
	'next_time',
	'',
	'next_',
	'time',
	1,
	1308,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	1739);
INSERT INTO O_OIDA
	VALUES (2116,
	1739,
	0,
	'session_startTime');
INSERT INTO O_OIDA
	VALUES (1787,
	1739,
	0,
	'time');
INSERT INTO O_ID
	VALUES (1,
	1739);
INSERT INTO O_ID
	VALUES (2,
	1739);
INSERT INTO PE_PE
	VALUES (1642,
	1,
	1574,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (1642,
	'TrackLog',
	2,
	'TrackLog',
	'The collection of track points stored during a workout session.

Presently the device supports only a single track log, and it 
is always the active one for the current workout session.
However, future releases may add a capability for storing
multiple track logs on the device.',
	0);
INSERT INTO O_TFR
	VALUES (2047,
	1642,
	'addTrackPoint',
	'',
	1192,
	1,
	'// Add a track point to this track log, update the accumulated distance
// and current speed, and then notify the UI.

// Create a new track point, retrieving the current location from the GPS.
select one workoutTimer related by self->WorkoutSession[R4.''represents_path_for'']->WorkoutTimer[R8.''is_timed_by''];
create object instance trackPoint of TrackPoint; trackPoint.time = workoutTimer.time;
send LOC::getLocation( latitude: trackPoint.latitude, longitude: trackPoint.longitude );

// Add the newly created track point to the track log.
select one firstPoint related by self->TrackPoint[R1];
select one lastPoint related by self->TrackPoint[R3];

// Explicit variable declarations for later use outside if-else clause.
isFirstTrackPoint = false;
lastLatitude = 0.0;
lastLongitude = 0.0;  
if (empty firstPoint)
  isFirstTrackPoint = true;
  relate self to trackPoint across R1.''has_first'';
  relate self to trackPoint across R3.''has_last'';
else 
  // Save last location for use in updating accumulated distance.
  lastLatitude = lastPoint.latitude;
  lastLongitude = lastPoint.longitude;
  unrelate self from lastPoint across R3.''has_last'';
  relate self to trackPoint across R3.''has_last'';
  relate lastPoint to trackPoint across R2.''follows'';
end if;

// Update accumulated distance and current speed.
distance = 0.0;
if (not isFirstTrackPoint)
  send LOC::getDistance( result:distance, fromLat: lastLatitude, fromLong: lastLongitude, toLat: trackPoint.latitude, toLong: trackPoint.longitude );
end if;

select one session related by self->WorkoutSession[R4.''represents_path_for''];
session.accumulatedDistance = session.accumulatedDistance + distance;

// Notify display of of the updated values.
self.updateDisplay();',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (2130,
	2047);
INSERT INTO ACT_ACT
	VALUES (2130,
	'operation',
	0,
	2131,
	0,
	0,
	'TrackLog::addTrackPoint',
	0);
INSERT INTO ACT_BLK
	VALUES (2131,
	1,
	0,
	0,
	'',
	'',
	'',
	40,
	1,
	36,
	37,
	0,
	0,
	36,
	52,
	36,
	55,
	0,
	0,
	0,
	2130,
	0);
INSERT INTO ACT_SMT
	VALUES (2132,
	2131,
	2133,
	5,
	1,
	'TrackLog::addTrackPoint line: 5');
INSERT INTO ACT_SEL
	VALUES (2132,
	2134,
	1,
	'one',
	2135);
INSERT INTO ACT_SR
	VALUES (2132);
INSERT INTO ACT_LNK
	VALUES (2136,
	'represents_path_for',
	2132,
	1646,
	2137,
	2,
	1470,
	5,
	42,
	5,
	57,
	5,
	60);
INSERT INTO ACT_LNK
	VALUES (2137,
	'is_timed_by',
	0,
	1583,
	0,
	2,
	1488,
	5,
	84,
	5,
	97,
	5,
	100);
INSERT INTO ACT_SMT
	VALUES (2133,
	2131,
	2138,
	6,
	1,
	'TrackLog::addTrackPoint line: 6');
INSERT INTO ACT_CR
	VALUES (2133,
	2139,
	1,
	1739,
	6,
	38);
INSERT INTO ACT_SMT
	VALUES (2138,
	2131,
	2140,
	6,
	50,
	'TrackLog::addTrackPoint line: 6');
INSERT INTO ACT_AI
	VALUES (2138,
	2141,
	2142,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2140,
	2131,
	2143,
	7,
	1,
	'TrackLog::addTrackPoint line: 7');
INSERT INTO ACT_IOP
	VALUES (2140,
	7,
	11,
	7,
	6,
	0,
	1348,
	0);
INSERT INTO ACT_SMT
	VALUES (2143,
	2131,
	2144,
	10,
	1,
	'TrackLog::addTrackPoint line: 10');
INSERT INTO ACT_SEL
	VALUES (2143,
	2145,
	1,
	'one',
	2146);
INSERT INTO ACT_SR
	VALUES (2143);
INSERT INTO ACT_LNK
	VALUES (2147,
	'',
	2143,
	2118,
	0,
	2,
	1739,
	10,
	40,
	10,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2144,
	2131,
	2148,
	11,
	1,
	'TrackLog::addTrackPoint line: 11');
INSERT INTO ACT_SEL
	VALUES (2144,
	2149,
	1,
	'one',
	2150);
INSERT INTO ACT_SR
	VALUES (2144);
INSERT INTO ACT_LNK
	VALUES (2151,
	'',
	2144,
	1738,
	0,
	2,
	1739,
	11,
	39,
	11,
	50,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2148,
	2131,
	2152,
	14,
	1,
	'TrackLog::addTrackPoint line: 14');
INSERT INTO ACT_AI
	VALUES (2148,
	2153,
	2154,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2152,
	2131,
	2155,
	15,
	1,
	'TrackLog::addTrackPoint line: 15');
INSERT INTO ACT_AI
	VALUES (2152,
	2156,
	2157,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2155,
	2131,
	2158,
	16,
	1,
	'TrackLog::addTrackPoint line: 16');
INSERT INTO ACT_AI
	VALUES (2155,
	2159,
	2160,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2158,
	2131,
	2161,
	17,
	1,
	'TrackLog::addTrackPoint line: 17');
INSERT INTO ACT_IF
	VALUES (2158,
	2162,
	2163,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2164,
	2131,
	0,
	21,
	1,
	'TrackLog::addTrackPoint line: 21');
INSERT INTO ACT_E
	VALUES (2164,
	2165,
	2158);
INSERT INTO ACT_SMT
	VALUES (2161,
	2131,
	2166,
	31,
	1,
	'TrackLog::addTrackPoint line: 31');
INSERT INTO ACT_AI
	VALUES (2161,
	2167,
	2168,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2166,
	2131,
	2169,
	32,
	1,
	'TrackLog::addTrackPoint line: 32');
INSERT INTO ACT_IF
	VALUES (2166,
	2170,
	2171,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2169,
	2131,
	2172,
	36,
	1,
	'TrackLog::addTrackPoint line: 36');
INSERT INTO ACT_SEL
	VALUES (2169,
	2173,
	1,
	'one',
	2174);
INSERT INTO ACT_SR
	VALUES (2169);
INSERT INTO ACT_LNK
	VALUES (2175,
	'represents_path_for',
	2169,
	1646,
	0,
	2,
	1470,
	36,
	37,
	36,
	52,
	36,
	55);
INSERT INTO ACT_SMT
	VALUES (2172,
	2131,
	2176,
	37,
	1,
	'TrackLog::addTrackPoint line: 37');
INSERT INTO ACT_AI
	VALUES (2172,
	2177,
	2178,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2176,
	2131,
	0,
	40,
	1,
	'TrackLog::addTrackPoint line: 40');
INSERT INTO ACT_TFM
	VALUES (2176,
	2179,
	2180,
	40,
	6,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2135,
	0,
	0,
	5,
	36,
	39,
	0,
	0,
	0,
	0,
	1309,
	2131);
INSERT INTO V_IRF
	VALUES (2135,
	2180);
INSERT INTO V_VAL
	VALUES (2181,
	1,
	0,
	6,
	50,
	59,
	0,
	0,
	0,
	0,
	1309,
	2131);
INSERT INTO V_IRF
	VALUES (2181,
	2139);
INSERT INTO V_VAL
	VALUES (2142,
	1,
	0,
	6,
	61,
	64,
	0,
	0,
	0,
	0,
	160,
	2131);
INSERT INTO V_AVL
	VALUES (2142,
	2181,
	1739,
	1787);
INSERT INTO V_VAL
	VALUES (2182,
	0,
	0,
	6,
	68,
	79,
	0,
	0,
	0,
	0,
	1309,
	2131);
INSERT INTO V_IRF
	VALUES (2182,
	2134);
INSERT INTO V_VAL
	VALUES (2141,
	0,
	0,
	6,
	81,
	84,
	0,
	0,
	0,
	0,
	160,
	2131);
INSERT INTO V_AVL
	VALUES (2141,
	2182,
	1488,
	1604);
INSERT INTO V_VAL
	VALUES (2183,
	0,
	0,
	7,
	34,
	43,
	0,
	0,
	0,
	0,
	1309,
	2131);
INSERT INTO V_IRF
	VALUES (2183,
	2139);
INSERT INTO V_VAL
	VALUES (2184,
	0,
	0,
	7,
	45,
	52,
	0,
	0,
	0,
	0,
	153,
	2131);
INSERT INTO V_AVL
	VALUES (2184,
	2183,
	1739,
	1827);
INSERT INTO V_PAR
	VALUES (2184,
	2140,
	0,
	'latitude',
	2185,
	7,
	24);
INSERT INTO V_VAL
	VALUES (2186,
	0,
	0,
	7,
	66,
	75,
	0,
	0,
	0,
	0,
	1309,
	2131);
INSERT INTO V_IRF
	VALUES (2186,
	2139);
INSERT INTO V_VAL
	VALUES (2185,
	0,
	0,
	7,
	77,
	85,
	0,
	0,
	0,
	0,
	153,
	2131);
INSERT INTO V_AVL
	VALUES (2185,
	2186,
	1739,
	1830);
INSERT INTO V_PAR
	VALUES (2185,
	2140,
	0,
	'longitude',
	0,
	7,
	55);
INSERT INTO V_VAL
	VALUES (2146,
	0,
	0,
	10,
	34,
	37,
	0,
	0,
	0,
	0,
	1309,
	2131);
INSERT INTO V_IRF
	VALUES (2146,
	2180);
INSERT INTO V_VAL
	VALUES (2150,
	0,
	0,
	11,
	33,
	36,
	0,
	0,
	0,
	0,
	1309,
	2131);
INSERT INTO V_IRF
	VALUES (2150,
	2180);
INSERT INTO V_VAL
	VALUES (2154,
	1,
	1,
	14,
	1,
	17,
	0,
	0,
	0,
	0,
	125,
	2131);
INSERT INTO V_TVL
	VALUES (2154,
	2187);
INSERT INTO V_VAL
	VALUES (2153,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2131);
INSERT INTO V_LBO
	VALUES (2153,
	'FALSE');
INSERT INTO V_VAL
	VALUES (2157,
	1,
	1,
	15,
	1,
	12,
	0,
	0,
	0,
	0,
	153,
	2131);
INSERT INTO V_TVL
	VALUES (2157,
	2188);
INSERT INTO V_VAL
	VALUES (2156,
	0,
	0,
	15,
	16,
	18,
	0,
	0,
	0,
	0,
	153,
	2131);
INSERT INTO V_LRL
	VALUES (2156,
	'0.0');
INSERT INTO V_VAL
	VALUES (2160,
	1,
	1,
	16,
	1,
	13,
	0,
	0,
	0,
	0,
	153,
	2131);
INSERT INTO V_TVL
	VALUES (2160,
	2189);
INSERT INTO V_VAL
	VALUES (2159,
	0,
	0,
	16,
	17,
	19,
	0,
	0,
	0,
	0,
	153,
	2131);
INSERT INTO V_LRL
	VALUES (2159,
	'0.0');
INSERT INTO V_VAL
	VALUES (2190,
	0,
	0,
	17,
	11,
	20,
	0,
	0,
	0,
	0,
	1309,
	2131);
INSERT INTO V_IRF
	VALUES (2190,
	2145);
INSERT INTO V_VAL
	VALUES (2163,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2131);
INSERT INTO V_UNY
	VALUES (2163,
	2190,
	'empty');
INSERT INTO V_VAL
	VALUES (2168,
	1,
	1,
	31,
	1,
	8,
	0,
	0,
	0,
	0,
	153,
	2131);
INSERT INTO V_TVL
	VALUES (2168,
	2191);
INSERT INTO V_VAL
	VALUES (2167,
	0,
	0,
	31,
	12,
	14,
	0,
	0,
	0,
	0,
	153,
	2131);
INSERT INTO V_LRL
	VALUES (2167,
	'0.0');
INSERT INTO V_VAL
	VALUES (2192,
	0,
	0,
	32,
	9,
	25,
	0,
	0,
	0,
	0,
	125,
	2131);
INSERT INTO V_TVL
	VALUES (2192,
	2187);
INSERT INTO V_VAL
	VALUES (2171,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2131);
INSERT INTO V_UNY
	VALUES (2171,
	2192,
	'not');
INSERT INTO V_VAL
	VALUES (2174,
	0,
	0,
	36,
	31,
	34,
	0,
	0,
	0,
	0,
	1309,
	2131);
INSERT INTO V_IRF
	VALUES (2174,
	2180);
INSERT INTO V_VAL
	VALUES (2193,
	1,
	0,
	37,
	1,
	7,
	0,
	0,
	0,
	0,
	1309,
	2131);
INSERT INTO V_IRF
	VALUES (2193,
	2173);
INSERT INTO V_VAL
	VALUES (2178,
	1,
	0,
	37,
	9,
	27,
	0,
	0,
	0,
	0,
	153,
	2131);
INSERT INTO V_AVL
	VALUES (2178,
	2193,
	1470,
	1651);
INSERT INTO V_VAL
	VALUES (2194,
	0,
	0,
	37,
	31,
	37,
	0,
	0,
	0,
	0,
	1309,
	2131);
INSERT INTO V_IRF
	VALUES (2194,
	2173);
INSERT INTO V_VAL
	VALUES (2195,
	0,
	0,
	37,
	39,
	57,
	0,
	0,
	0,
	0,
	153,
	2131);
INSERT INTO V_AVL
	VALUES (2195,
	2194,
	1470,
	1651);
INSERT INTO V_VAL
	VALUES (2177,
	0,
	0,
	37,
	39,
	68,
	0,
	0,
	0,
	0,
	153,
	2131);
INSERT INTO V_BIN
	VALUES (2177,
	2196,
	2195,
	'+');
INSERT INTO V_VAL
	VALUES (2196,
	0,
	0,
	37,
	61,
	68,
	0,
	0,
	0,
	0,
	153,
	2131);
INSERT INTO V_TVL
	VALUES (2196,
	2191);
INSERT INTO V_VAR
	VALUES (2134,
	2131,
	'workoutTimer',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2134,
	0,
	1488);
INSERT INTO V_VAR
	VALUES (2180,
	2131,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2180,
	0,
	1642);
INSERT INTO V_VAR
	VALUES (2139,
	2131,
	'trackPoint',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2139,
	0,
	1739);
INSERT INTO V_VAR
	VALUES (2145,
	2131,
	'firstPoint',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2145,
	0,
	1739);
INSERT INTO V_VAR
	VALUES (2149,
	2131,
	'lastPoint',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2149,
	0,
	1739);
INSERT INTO V_VAR
	VALUES (2187,
	2131,
	'isFirstTrackPoint',
	1,
	125);
INSERT INTO V_TRN
	VALUES (2187,
	0,
	'');
INSERT INTO V_VAR
	VALUES (2188,
	2131,
	'lastLatitude',
	1,
	153);
INSERT INTO V_TRN
	VALUES (2188,
	0,
	'');
INSERT INTO V_VAR
	VALUES (2189,
	2131,
	'lastLongitude',
	1,
	153);
INSERT INTO V_TRN
	VALUES (2189,
	0,
	'');
INSERT INTO V_VAR
	VALUES (2191,
	2131,
	'distance',
	1,
	153);
INSERT INTO V_TRN
	VALUES (2191,
	0,
	'');
INSERT INTO V_VAR
	VALUES (2173,
	2131,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2173,
	0,
	1470);
INSERT INTO ACT_BLK
	VALUES (2162,
	0,
	0,
	0,
	'has_last',
	'',
	'',
	20,
	3,
	0,
	0,
	0,
	0,
	20,
	36,
	20,
	39,
	0,
	0,
	0,
	2130,
	0);
INSERT INTO ACT_SMT
	VALUES (2197,
	2162,
	2198,
	18,
	3,
	'TrackLog::addTrackPoint line: 18');
INSERT INTO ACT_AI
	VALUES (2197,
	2199,
	2200,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2198,
	2162,
	2201,
	19,
	3,
	'TrackLog::addTrackPoint line: 19');
INSERT INTO ACT_REL
	VALUES (2198,
	2180,
	2139,
	'has_first',
	2118,
	19,
	36,
	19,
	39);
INSERT INTO ACT_SMT
	VALUES (2201,
	2162,
	0,
	20,
	3,
	'TrackLog::addTrackPoint line: 20');
INSERT INTO ACT_REL
	VALUES (2201,
	2180,
	2139,
	'has_last',
	1738,
	20,
	36,
	20,
	39);
INSERT INTO V_VAL
	VALUES (2200,
	1,
	0,
	18,
	3,
	19,
	0,
	0,
	0,
	0,
	125,
	2162);
INSERT INTO V_TVL
	VALUES (2200,
	2187);
INSERT INTO V_VAL
	VALUES (2199,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2162);
INSERT INTO V_LBO
	VALUES (2199,
	'TRUE');
INSERT INTO ACT_BLK
	VALUES (2165,
	0,
	0,
	0,
	'follows',
	'',
	'',
	27,
	3,
	0,
	0,
	0,
	0,
	27,
	41,
	27,
	44,
	0,
	0,
	0,
	2130,
	0);
INSERT INTO ACT_SMT
	VALUES (2202,
	2165,
	2203,
	23,
	3,
	'TrackLog::addTrackPoint line: 23');
INSERT INTO ACT_AI
	VALUES (2202,
	2204,
	2205,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2203,
	2165,
	2206,
	24,
	3,
	'TrackLog::addTrackPoint line: 24');
INSERT INTO ACT_AI
	VALUES (2203,
	2207,
	2208,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2206,
	2165,
	2209,
	25,
	3,
	'TrackLog::addTrackPoint line: 25');
INSERT INTO ACT_UNR
	VALUES (2206,
	2180,
	2149,
	'has_last',
	1738,
	25,
	39,
	25,
	42);
INSERT INTO ACT_SMT
	VALUES (2209,
	2165,
	2210,
	26,
	3,
	'TrackLog::addTrackPoint line: 26');
INSERT INTO ACT_REL
	VALUES (2209,
	2180,
	2139,
	'has_last',
	1738,
	26,
	36,
	26,
	39);
INSERT INTO ACT_SMT
	VALUES (2210,
	2165,
	0,
	27,
	3,
	'TrackLog::addTrackPoint line: 27');
INSERT INTO ACT_REL
	VALUES (2210,
	2149,
	2139,
	'follows',
	1806,
	27,
	41,
	27,
	44);
INSERT INTO V_VAL
	VALUES (2205,
	1,
	0,
	23,
	3,
	14,
	0,
	0,
	0,
	0,
	153,
	2165);
INSERT INTO V_TVL
	VALUES (2205,
	2188);
INSERT INTO V_VAL
	VALUES (2211,
	0,
	0,
	23,
	18,
	26,
	0,
	0,
	0,
	0,
	1309,
	2165);
INSERT INTO V_IRF
	VALUES (2211,
	2149);
INSERT INTO V_VAL
	VALUES (2204,
	0,
	0,
	23,
	28,
	35,
	0,
	0,
	0,
	0,
	153,
	2165);
INSERT INTO V_AVL
	VALUES (2204,
	2211,
	1739,
	1827);
INSERT INTO V_VAL
	VALUES (2208,
	1,
	0,
	24,
	3,
	15,
	0,
	0,
	0,
	0,
	153,
	2165);
INSERT INTO V_TVL
	VALUES (2208,
	2189);
INSERT INTO V_VAL
	VALUES (2212,
	0,
	0,
	24,
	19,
	27,
	0,
	0,
	0,
	0,
	1309,
	2165);
INSERT INTO V_IRF
	VALUES (2212,
	2149);
INSERT INTO V_VAL
	VALUES (2207,
	0,
	0,
	24,
	29,
	37,
	0,
	0,
	0,
	0,
	153,
	2165);
INSERT INTO V_AVL
	VALUES (2207,
	2212,
	1739,
	1830);
INSERT INTO ACT_BLK
	VALUES (2170,
	0,
	0,
	0,
	'LOC',
	'',
	'',
	33,
	3,
	33,
	8,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2130,
	0);
INSERT INTO ACT_SMT
	VALUES (2213,
	2170,
	0,
	33,
	3,
	'TrackLog::addTrackPoint line: 33');
INSERT INTO ACT_IOP
	VALUES (2213,
	33,
	13,
	33,
	8,
	0,
	1347,
	0);
INSERT INTO V_VAL
	VALUES (2214,
	0,
	0,
	33,
	33,
	40,
	0,
	0,
	0,
	0,
	153,
	2170);
INSERT INTO V_TVL
	VALUES (2214,
	2191);
INSERT INTO V_PAR
	VALUES (2214,
	2213,
	0,
	'result',
	2215,
	33,
	26);
INSERT INTO V_VAL
	VALUES (2215,
	0,
	0,
	33,
	52,
	63,
	0,
	0,
	0,
	0,
	153,
	2170);
INSERT INTO V_TVL
	VALUES (2215,
	2188);
INSERT INTO V_PAR
	VALUES (2215,
	2213,
	0,
	'fromLat',
	2216,
	33,
	43);
INSERT INTO V_VAL
	VALUES (2216,
	0,
	0,
	33,
	76,
	88,
	0,
	0,
	0,
	0,
	153,
	2170);
INSERT INTO V_TVL
	VALUES (2216,
	2189);
INSERT INTO V_PAR
	VALUES (2216,
	2213,
	0,
	'fromLong',
	2217,
	33,
	66);
INSERT INTO V_VAL
	VALUES (2218,
	0,
	0,
	33,
	98,
	107,
	0,
	0,
	0,
	0,
	1309,
	2170);
INSERT INTO V_IRF
	VALUES (2218,
	2139);
INSERT INTO V_VAL
	VALUES (2217,
	0,
	0,
	33,
	109,
	116,
	0,
	0,
	0,
	0,
	153,
	2170);
INSERT INTO V_AVL
	VALUES (2217,
	2218,
	1739,
	1827);
INSERT INTO V_PAR
	VALUES (2217,
	2213,
	0,
	'toLat',
	2219,
	33,
	91);
INSERT INTO V_VAL
	VALUES (2220,
	0,
	0,
	33,
	127,
	136,
	0,
	0,
	0,
	0,
	1309,
	2170);
INSERT INTO V_IRF
	VALUES (2220,
	2139);
INSERT INTO V_VAL
	VALUES (2219,
	0,
	0,
	33,
	138,
	146,
	0,
	0,
	0,
	0,
	153,
	2170);
INSERT INTO V_AVL
	VALUES (2219,
	2220,
	1739,
	1830);
INSERT INTO V_PAR
	VALUES (2219,
	2213,
	0,
	'toLong',
	0,
	33,
	119);
INSERT INTO O_TFR
	VALUES (1666,
	1642,
	'clearTrackPoints',
	'',
	1192,
	1,
	'select one nextPoint related by self->TrackPoint[R1];
select one lastPoint related by self->TrackPoint[R3];

if (not empty lastPoint)
  unrelate self from lastPoint across R3;
end if;

if (not empty nextPoint)
  unrelate self from nextPoint across R1;
end if;

while (not empty nextPoint)
  prevPoint = nextPoint;
  select one nextPoint related by nextPoint->TrackPoint[R2.''follows''];
  if ( not_empty nextPoint )
    unrelate prevPoint from nextPoint across R2.''follows'';
  end if;
  delete object instance prevPoint;
end while;
',
	1,
	'',
	2047,
	0);
INSERT INTO ACT_OPB
	VALUES (2221,
	1666);
INSERT INTO ACT_ACT
	VALUES (2221,
	'operation',
	0,
	2222,
	0,
	0,
	'TrackLog::clearTrackPoints',
	0);
INSERT INTO ACT_BLK
	VALUES (2222,
	1,
	0,
	0,
	'',
	'',
	'',
	12,
	1,
	2,
	39,
	0,
	0,
	2,
	50,
	0,
	0,
	0,
	0,
	0,
	2221,
	0);
INSERT INTO ACT_SMT
	VALUES (2223,
	2222,
	2224,
	1,
	1,
	'TrackLog::clearTrackPoints line: 1');
INSERT INTO ACT_SEL
	VALUES (2223,
	2225,
	1,
	'one',
	2226);
INSERT INTO ACT_SR
	VALUES (2223);
INSERT INTO ACT_LNK
	VALUES (2227,
	'',
	2223,
	2118,
	0,
	2,
	1739,
	1,
	39,
	1,
	50,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2224,
	2222,
	2228,
	2,
	1,
	'TrackLog::clearTrackPoints line: 2');
INSERT INTO ACT_SEL
	VALUES (2224,
	2229,
	1,
	'one',
	2230);
INSERT INTO ACT_SR
	VALUES (2224);
INSERT INTO ACT_LNK
	VALUES (2231,
	'',
	2224,
	1738,
	0,
	2,
	1739,
	2,
	39,
	2,
	50,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2228,
	2222,
	2232,
	4,
	1,
	'TrackLog::clearTrackPoints line: 4');
INSERT INTO ACT_IF
	VALUES (2228,
	2233,
	2234,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2232,
	2222,
	2235,
	8,
	1,
	'TrackLog::clearTrackPoints line: 8');
INSERT INTO ACT_IF
	VALUES (2232,
	2236,
	2237,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2235,
	2222,
	0,
	12,
	1,
	'TrackLog::clearTrackPoints line: 12');
INSERT INTO ACT_WHL
	VALUES (2235,
	2238,
	2239);
INSERT INTO V_VAL
	VALUES (2226,
	0,
	0,
	1,
	33,
	36,
	0,
	0,
	0,
	0,
	1309,
	2222);
INSERT INTO V_IRF
	VALUES (2226,
	2240);
INSERT INTO V_VAL
	VALUES (2230,
	0,
	0,
	2,
	33,
	36,
	0,
	0,
	0,
	0,
	1309,
	2222);
INSERT INTO V_IRF
	VALUES (2230,
	2240);
INSERT INTO V_VAL
	VALUES (2241,
	0,
	0,
	4,
	15,
	23,
	0,
	0,
	0,
	0,
	1309,
	2222);
INSERT INTO V_IRF
	VALUES (2241,
	2229);
INSERT INTO V_VAL
	VALUES (2242,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2222);
INSERT INTO V_UNY
	VALUES (2242,
	2241,
	'empty');
INSERT INTO V_VAL
	VALUES (2234,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2222);
INSERT INTO V_UNY
	VALUES (2234,
	2242,
	'not');
INSERT INTO V_VAL
	VALUES (2243,
	0,
	0,
	8,
	15,
	23,
	0,
	0,
	0,
	0,
	1309,
	2222);
INSERT INTO V_IRF
	VALUES (2243,
	2225);
INSERT INTO V_VAL
	VALUES (2244,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2222);
INSERT INTO V_UNY
	VALUES (2244,
	2243,
	'empty');
INSERT INTO V_VAL
	VALUES (2237,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2222);
INSERT INTO V_UNY
	VALUES (2237,
	2244,
	'not');
INSERT INTO V_VAL
	VALUES (2245,
	0,
	0,
	12,
	18,
	26,
	0,
	0,
	0,
	0,
	1309,
	2222);
INSERT INTO V_IRF
	VALUES (2245,
	2225);
INSERT INTO V_VAL
	VALUES (2246,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2222);
INSERT INTO V_UNY
	VALUES (2246,
	2245,
	'empty');
INSERT INTO V_VAL
	VALUES (2238,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2222);
INSERT INTO V_UNY
	VALUES (2238,
	2246,
	'not');
INSERT INTO V_VAR
	VALUES (2225,
	2222,
	'nextPoint',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2225,
	0,
	1739);
INSERT INTO V_VAR
	VALUES (2240,
	2222,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2240,
	0,
	1642);
INSERT INTO V_VAR
	VALUES (2229,
	2222,
	'lastPoint',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2229,
	0,
	1739);
INSERT INTO ACT_BLK
	VALUES (2233,
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	3,
	0,
	0,
	0,
	0,
	5,
	39,
	0,
	0,
	0,
	0,
	0,
	2221,
	0);
INSERT INTO ACT_SMT
	VALUES (2247,
	2233,
	0,
	5,
	3,
	'TrackLog::clearTrackPoints line: 5');
INSERT INTO ACT_UNR
	VALUES (2247,
	2240,
	2229,
	'',
	1738,
	5,
	39,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (2236,
	0,
	0,
	0,
	'',
	'',
	'',
	9,
	3,
	0,
	0,
	0,
	0,
	9,
	39,
	0,
	0,
	0,
	0,
	0,
	2221,
	0);
INSERT INTO ACT_SMT
	VALUES (2248,
	2236,
	0,
	9,
	3,
	'TrackLog::clearTrackPoints line: 9');
INSERT INTO ACT_UNR
	VALUES (2248,
	2240,
	2225,
	'',
	2118,
	9,
	39,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (2239,
	1,
	0,
	0,
	'',
	'',
	'',
	18,
	3,
	14,
	46,
	0,
	0,
	14,
	57,
	14,
	60,
	0,
	0,
	0,
	2221,
	0);
INSERT INTO ACT_SMT
	VALUES (2249,
	2239,
	2250,
	13,
	3,
	'TrackLog::clearTrackPoints line: 13');
INSERT INTO ACT_AI
	VALUES (2249,
	2251,
	2252,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2250,
	2239,
	2253,
	14,
	3,
	'TrackLog::clearTrackPoints line: 14');
INSERT INTO ACT_SEL
	VALUES (2250,
	2225,
	0,
	'one',
	2254);
INSERT INTO ACT_SR
	VALUES (2250);
INSERT INTO ACT_LNK
	VALUES (2255,
	'follows',
	2250,
	1806,
	0,
	2,
	1739,
	14,
	46,
	14,
	57,
	14,
	60);
INSERT INTO ACT_SMT
	VALUES (2253,
	2239,
	2256,
	15,
	3,
	'TrackLog::clearTrackPoints line: 15');
INSERT INTO ACT_IF
	VALUES (2253,
	2257,
	2258,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2256,
	2239,
	0,
	18,
	3,
	'TrackLog::clearTrackPoints line: 18');
INSERT INTO ACT_DEL
	VALUES (2256,
	2259);
INSERT INTO V_VAL
	VALUES (2252,
	1,
	1,
	13,
	3,
	11,
	0,
	0,
	0,
	0,
	1309,
	2239);
INSERT INTO V_IRF
	VALUES (2252,
	2259);
INSERT INTO V_VAL
	VALUES (2251,
	0,
	0,
	13,
	15,
	23,
	0,
	0,
	0,
	0,
	1309,
	2239);
INSERT INTO V_IRF
	VALUES (2251,
	2225);
INSERT INTO V_VAL
	VALUES (2254,
	0,
	0,
	14,
	35,
	43,
	0,
	0,
	0,
	0,
	1309,
	2239);
INSERT INTO V_IRF
	VALUES (2254,
	2225);
INSERT INTO V_VAL
	VALUES (2260,
	0,
	0,
	15,
	18,
	26,
	0,
	0,
	0,
	0,
	1309,
	2239);
INSERT INTO V_IRF
	VALUES (2260,
	2225);
INSERT INTO V_VAL
	VALUES (2258,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2239);
INSERT INTO V_UNY
	VALUES (2258,
	2260,
	'not_empty');
INSERT INTO V_VAR
	VALUES (2259,
	2239,
	'prevPoint',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2259,
	0,
	1739);
INSERT INTO ACT_BLK
	VALUES (2257,
	0,
	0,
	0,
	'follows',
	'',
	'',
	16,
	5,
	0,
	0,
	0,
	0,
	16,
	46,
	16,
	49,
	0,
	0,
	0,
	2221,
	0);
INSERT INTO ACT_SMT
	VALUES (2261,
	2257,
	0,
	16,
	5,
	'TrackLog::clearTrackPoints line: 16');
INSERT INTO ACT_UNR
	VALUES (2261,
	2259,
	2225,
	'follows',
	1806,
	16,
	46,
	16,
	49);
INSERT INTO O_TFR
	VALUES (2083,
	1642,
	'addLapMarker',
	'',
	1192,
	1,
	'select one timer related by self->WorkoutSession[R4.''represents_path_for'']->WorkoutTimer[R8.''is_timed_by''];
create object instance lapMarker of LapMarker; lapMarker.lapTime = timer.time; 
relate self to lapMarker across R5.''has_laps_defined_by'';

// Notify display of the new value.
self.updateDisplay();',
	1,
	'',
	1666,
	0);
INSERT INTO ACT_OPB
	VALUES (2262,
	2083);
INSERT INTO ACT_ACT
	VALUES (2262,
	'operation',
	0,
	2263,
	0,
	0,
	'TrackLog::addLapMarker',
	0);
INSERT INTO ACT_BLK
	VALUES (2263,
	1,
	0,
	0,
	'has_laps_defined_by',
	'',
	'',
	6,
	1,
	2,
	37,
	0,
	0,
	3,
	33,
	3,
	36,
	0,
	0,
	0,
	2262,
	0);
INSERT INTO ACT_SMT
	VALUES (2264,
	2263,
	2265,
	1,
	1,
	'TrackLog::addLapMarker line: 1');
INSERT INTO ACT_SEL
	VALUES (2264,
	2266,
	1,
	'one',
	2267);
INSERT INTO ACT_SR
	VALUES (2264);
INSERT INTO ACT_LNK
	VALUES (2268,
	'represents_path_for',
	2264,
	1646,
	2269,
	2,
	1470,
	1,
	35,
	1,
	50,
	1,
	53);
INSERT INTO ACT_LNK
	VALUES (2269,
	'is_timed_by',
	0,
	1583,
	0,
	2,
	1488,
	1,
	77,
	1,
	90,
	1,
	93);
INSERT INTO ACT_SMT
	VALUES (2265,
	2263,
	2270,
	2,
	1,
	'TrackLog::addLapMarker line: 2');
INSERT INTO ACT_CR
	VALUES (2265,
	2271,
	1,
	2272,
	2,
	37);
INSERT INTO ACT_SMT
	VALUES (2270,
	2263,
	2273,
	2,
	48,
	'TrackLog::addLapMarker line: 2');
INSERT INTO ACT_AI
	VALUES (2270,
	2274,
	2275,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2273,
	2263,
	2276,
	3,
	1,
	'TrackLog::addLapMarker line: 3');
INSERT INTO ACT_REL
	VALUES (2273,
	2277,
	2271,
	'has_laps_defined_by',
	2278,
	3,
	33,
	3,
	36);
INSERT INTO ACT_SMT
	VALUES (2276,
	2263,
	0,
	6,
	1,
	'TrackLog::addLapMarker line: 6');
INSERT INTO ACT_TFM
	VALUES (2276,
	2179,
	2277,
	6,
	6,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2267,
	0,
	0,
	1,
	29,
	32,
	0,
	0,
	0,
	0,
	1309,
	2263);
INSERT INTO V_IRF
	VALUES (2267,
	2277);
INSERT INTO V_VAL
	VALUES (2279,
	1,
	0,
	2,
	48,
	56,
	0,
	0,
	0,
	0,
	1309,
	2263);
INSERT INTO V_IRF
	VALUES (2279,
	2271);
INSERT INTO V_VAL
	VALUES (2275,
	1,
	0,
	2,
	58,
	64,
	0,
	0,
	0,
	0,
	160,
	2263);
INSERT INTO V_AVL
	VALUES (2275,
	2279,
	2272,
	2280);
INSERT INTO V_VAL
	VALUES (2281,
	0,
	0,
	2,
	68,
	72,
	0,
	0,
	0,
	0,
	1309,
	2263);
INSERT INTO V_IRF
	VALUES (2281,
	2266);
INSERT INTO V_VAL
	VALUES (2274,
	0,
	0,
	2,
	74,
	77,
	0,
	0,
	0,
	0,
	160,
	2263);
INSERT INTO V_AVL
	VALUES (2274,
	2281,
	1488,
	1604);
INSERT INTO V_VAR
	VALUES (2266,
	2263,
	'timer',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2266,
	0,
	1488);
INSERT INTO V_VAR
	VALUES (2277,
	2263,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2277,
	0,
	1642);
INSERT INTO V_VAR
	VALUES (2271,
	2263,
	'lapMarker',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2271,
	0,
	2272);
INSERT INTO O_TFR
	VALUES (1668,
	1642,
	'clearLapMarkers',
	'',
	1192,
	1,
	'select many lapMarkers related by self->LapMarker[R5];
for each lapMarker in lapMarkers
  unrelate self from lapMarker across R5;
  delete object instance lapMarker;
end for;',
	1,
	'',
	2083,
	0);
INSERT INTO ACT_OPB
	VALUES (2282,
	1668);
INSERT INTO ACT_ACT
	VALUES (2282,
	'operation',
	0,
	2283,
	0,
	0,
	'TrackLog::clearLapMarkers',
	0);
INSERT INTO ACT_BLK
	VALUES (2283,
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	41,
	0,
	0,
	1,
	51,
	0,
	0,
	0,
	0,
	0,
	2282,
	0);
INSERT INTO ACT_SMT
	VALUES (2284,
	2283,
	2285,
	1,
	1,
	'TrackLog::clearLapMarkers line: 1');
INSERT INTO ACT_SEL
	VALUES (2284,
	2286,
	1,
	'many',
	2287);
INSERT INTO ACT_SR
	VALUES (2284);
INSERT INTO ACT_LNK
	VALUES (2288,
	'',
	2284,
	2278,
	0,
	3,
	2272,
	1,
	41,
	1,
	51,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2285,
	2283,
	0,
	2,
	1,
	'TrackLog::clearLapMarkers line: 2');
INSERT INTO ACT_FOR
	VALUES (2285,
	2289,
	1,
	2290,
	2286,
	2272);
INSERT INTO V_VAL
	VALUES (2287,
	0,
	0,
	1,
	35,
	38,
	0,
	0,
	0,
	0,
	1309,
	2283);
INSERT INTO V_IRF
	VALUES (2287,
	2291);
INSERT INTO V_VAR
	VALUES (2286,
	2283,
	'lapMarkers',
	1,
	1310);
INSERT INTO V_INS
	VALUES (2286,
	2272);
INSERT INTO V_VAR
	VALUES (2291,
	2283,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2291,
	0,
	1642);
INSERT INTO V_VAR
	VALUES (2290,
	2283,
	'lapMarker',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2290,
	1,
	2272);
INSERT INTO ACT_BLK
	VALUES (2289,
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	3,
	0,
	0,
	0,
	0,
	3,
	39,
	0,
	0,
	0,
	0,
	0,
	2282,
	0);
INSERT INTO ACT_SMT
	VALUES (2292,
	2289,
	2293,
	3,
	3,
	'TrackLog::clearLapMarkers line: 3');
INSERT INTO ACT_UNR
	VALUES (2292,
	2291,
	2290,
	'',
	2278,
	3,
	39,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2293,
	2289,
	0,
	4,
	3,
	'TrackLog::clearLapMarkers line: 4');
INSERT INTO ACT_DEL
	VALUES (2293,
	2290);
INSERT INTO O_TFR
	VALUES (2179,
	1642,
	'updateDisplay',
	'',
	1192,
	1,
	'// Update the display so that newly updated values will be shown.
select one display related by self->WorkoutSession[R4.''represents_path_for'']->Display[R7.''current_status_indicated_on''];
generate Display2:refresh to display;',
	1,
	'',
	1668,
	0);
INSERT INTO ACT_OPB
	VALUES (2294,
	2179);
INSERT INTO ACT_ACT
	VALUES (2294,
	'operation',
	0,
	2295,
	0,
	0,
	'TrackLog::updateDisplay',
	0);
INSERT INTO ACT_BLK
	VALUES (2295,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	3,
	1,
	2,
	79,
	0,
	0,
	2,
	87,
	2,
	90,
	0,
	0,
	0,
	2294,
	0);
INSERT INTO ACT_SMT
	VALUES (2296,
	2295,
	2297,
	2,
	1,
	'TrackLog::updateDisplay line: 2');
INSERT INTO ACT_SEL
	VALUES (2296,
	2298,
	1,
	'one',
	2299);
INSERT INTO ACT_SR
	VALUES (2296);
INSERT INTO ACT_LNK
	VALUES (2300,
	'represents_path_for',
	2296,
	1646,
	2301,
	2,
	1470,
	2,
	37,
	2,
	52,
	2,
	55);
INSERT INTO ACT_LNK
	VALUES (2301,
	'current_status_indicated_on',
	0,
	1521,
	0,
	2,
	1522,
	2,
	79,
	2,
	87,
	2,
	90);
INSERT INTO ACT_SMT
	VALUES (2297,
	2295,
	0,
	3,
	1,
	'TrackLog::updateDisplay line: 3');
INSERT INTO E_ESS
	VALUES (2297,
	1,
	0,
	3,
	10,
	3,
	19,
	2,
	79,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (2297);
INSERT INTO E_GSME
	VALUES (2297,
	1600);
INSERT INTO E_GEN
	VALUES (2297,
	2298);
INSERT INTO V_VAL
	VALUES (2299,
	0,
	0,
	2,
	31,
	34,
	0,
	0,
	0,
	0,
	1309,
	2295);
INSERT INTO V_IRF
	VALUES (2299,
	2302);
INSERT INTO V_VAR
	VALUES (2298,
	2295,
	'display',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2298,
	0,
	1522);
INSERT INTO V_VAR
	VALUES (2302,
	2295,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2302,
	0,
	1642);
INSERT INTO O_REF
	VALUES (1642,
	1470,
	0,
	1649,
	1646,
	2303,
	2304,
	2117,
	2305,
	0,
	0,
	'',
	'WorkoutSession',
	'startTime',
	'R4.''represents_path_for''');
INSERT INTO O_RATTR
	VALUES (2117,
	1642,
	1649,
	1470,
	1,
	'startTime');
INSERT INTO O_ATTR
	VALUES (2117,
	1642,
	0,
	'session_startTime',
	'',
	'session_',
	'startTime',
	1,
	1308,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	1642);
INSERT INTO O_OIDA
	VALUES (2117,
	1642,
	0,
	'session_startTime');
INSERT INTO O_ID
	VALUES (1,
	1642);
INSERT INTO O_ID
	VALUES (2,
	1642);
INSERT INTO PE_PE
	VALUES (2272,
	1,
	1574,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (2272,
	'LapMarker',
	4,
	'LapMarker',
	'Each instance represents a single lap marker.',
	0);
INSERT INTO O_NBATTR
	VALUES (2280,
	2272);
INSERT INTO O_BATTR
	VALUES (2280,
	2272);
INSERT INTO O_ATTR
	VALUES (2280,
	2272,
	2306,
	'lapTime',
	'Number of seconds between start time for the associated workout and this lap marker.',
	'',
	'lapTime',
	0,
	160,
	'',
	'');
INSERT INTO O_REF
	VALUES (2272,
	1642,
	0,
	2117,
	2278,
	2307,
	2308,
	2306,
	2309,
	0,
	0,
	'',
	'TrackLog',
	'session_startTime',
	'R5.''marks_end_of_lap_in''');
INSERT INTO O_RATTR
	VALUES (2306,
	2272,
	1649,
	1470,
	1,
	'startTime');
INSERT INTO O_ATTR
	VALUES (2306,
	2272,
	0,
	'session_startTime',
	'',
	'',
	'session_startTime',
	2,
	1308,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	2272);
INSERT INTO O_OIDA
	VALUES (2306,
	2272,
	0,
	'session_startTime');
INSERT INTO O_OIDA
	VALUES (2280,
	2272,
	0,
	'lapTime');
INSERT INTO O_ID
	VALUES (1,
	2272);
INSERT INTO O_ID
	VALUES (2,
	2272);
INSERT INTO PE_PE
	VALUES (1586,
	1,
	1574,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (1586,
	'HeartRateSample',
	5,
	'HeartRateSample',
	'Each instance represents a single heart-rate sample.',
	0);
INSERT INTO O_NBATTR
	VALUES (1606,
	1586);
INSERT INTO O_BATTR
	VALUES (1606,
	1586);
INSERT INTO O_ATTR
	VALUES (1606,
	1586,
	1602,
	'heartRate',
	'Heart rate expressed in beats per minute.',
	'',
	'heartRate',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1602,
	1586);
INSERT INTO O_BATTR
	VALUES (1602,
	1586);
INSERT INTO O_ATTR
	VALUES (1602,
	1586,
	2310,
	'time',
	'Number of seconds between start time for the associated workout and recording of this heart rate sample.',
	'',
	'time',
	0,
	160,
	'',
	'');
INSERT INTO O_REF
	VALUES (1586,
	1470,
	0,
	1649,
	1595,
	2311,
	2312,
	2310,
	2313,
	0,
	0,
	'',
	'WorkoutSession',
	'startTime',
	'R6.''was_collected_during''');
INSERT INTO O_RATTR
	VALUES (2310,
	1586,
	1649,
	1470,
	1,
	'startTime');
INSERT INTO O_ATTR
	VALUES (2310,
	1586,
	0,
	'session_startTime',
	'',
	'session_',
	'startTime',
	1,
	1308,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	1586);
INSERT INTO O_OIDA
	VALUES (2310,
	1586,
	0,
	'session_startTime');
INSERT INTO O_OIDA
	VALUES (1602,
	1586,
	0,
	'time');
INSERT INTO O_ID
	VALUES (1,
	1586);
INSERT INTO O_ID
	VALUES (2,
	1586);
INSERT INTO PE_PE
	VALUES (1542,
	1,
	1574,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (1542,
	'GoalSpec',
	8,
	'GoalSpec',
	'Each instance specifies one particular workout goal.  The actual execution of the goal
along with evaluation of whether it is currently being achieved is handled by another
class, not this one.

The criteria for the goal are merely numerical figures for comparison against the 
measured quantity.  Accordingly, the terms may create confusion with certain goal
types such as pace.  Since pace is the inverse of speed, a lower number represents
a faster speed.  Even so, when specifying a pace-related goal the value for 
minimum should be the lowest number (fastest pace) and the value for maximum should
be the higher number (slower pace).',
	0);
INSERT INTO O_NBATTR
	VALUES (1565,
	1542);
INSERT INTO O_BATTR
	VALUES (1565,
	1542);
INSERT INTO O_ATTR
	VALUES (1565,
	1542,
	1563,
	'minimum',
	'The minimum value for the quantity associated with the goal.
For example, a minimum heart rate to be maintained.
The units (e.g., beats per minute or minutes per km) for this
attribute are determined by another attribute indicating the 
type of criteria for this goal.',
	'',
	'minimum',
	0,
	153,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1567,
	1542);
INSERT INTO O_BATTR
	VALUES (1567,
	1542);
INSERT INTO O_ATTR
	VALUES (1567,
	1542,
	1565,
	'maximum',
	'The maximum value for the quantity associated with the goal.
For example, a maximum pace to be maintained.
The units (e.g., beats per minute or minutes per km) for this
attribute are determined by another attribute indicating the 
type of criteria for this goal.',
	'',
	'maximum',
	0,
	153,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1569,
	1542);
INSERT INTO O_BATTR
	VALUES (1569,
	1542);
INSERT INTO O_ATTR
	VALUES (1569,
	1542,
	1567,
	'span',
	'The span of the goal.  For example, a time-based goal specifies a span
as a duration or length of time, while a distance-based goal uses specifies
a distance.  The units for this attribute (e.g., seconds or km) are specified 
by another attribute indicating the type of span.
',
	'',
	'span',
	0,
	153,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1571,
	1542);
INSERT INTO O_BATTR
	VALUES (1571,
	1542);
INSERT INTO O_ATTR
	VALUES (1571,
	1542,
	1569,
	'criteriaType',
	'See data type description.',
	'',
	'criteriaType',
	0,
	150,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1573,
	1542);
INSERT INTO O_BATTR
	VALUES (1573,
	1542);
INSERT INTO O_ATTR
	VALUES (1573,
	1542,
	1571,
	'spanType',
	'See data type description.',
	'',
	'spanType',
	0,
	147,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1563,
	1542);
INSERT INTO O_BATTR
	VALUES (1563,
	1542);
INSERT INTO O_ATTR
	VALUES (1563,
	1542,
	2314,
	'sequenceNumber',
	'Workout goals are sequenced according to a number specified by the user when the goal
is specified.  This attribute represents that user-specified number. ',
	'',
	'sequenceNumber',
	0,
	160,
	'',
	'');
INSERT INTO O_REF
	VALUES (1542,
	1470,
	0,
	1649,
	1561,
	2315,
	2316,
	2314,
	2317,
	0,
	0,
	'',
	'WorkoutSession',
	'startTime',
	'R10.''included_in''');
INSERT INTO O_RATTR
	VALUES (2314,
	1542,
	1649,
	1470,
	1,
	'startTime');
INSERT INTO O_ATTR
	VALUES (2314,
	1542,
	0,
	'session_startTime',
	'',
	'session_',
	'startTime',
	1,
	1308,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (2318,
	1542);
INSERT INTO O_BATTR
	VALUES (2318,
	1542);
INSERT INTO O_ATTR
	VALUES (2318,
	1542,
	1573,
	'last_goal_ID',
	'',
	'',
	'last_goal_ID',
	0,
	160,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	1542);
INSERT INTO O_OIDA
	VALUES (1563,
	1542,
	0,
	'sequenceNumber');
INSERT INTO O_OIDA
	VALUES (2314,
	1542,
	0,
	'session_startTime');
INSERT INTO O_ID
	VALUES (1,
	1542);
INSERT INTO O_ID
	VALUES (2,
	1542);
INSERT INTO PE_PE
	VALUES (1681,
	1,
	1574,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (1681,
	'Goal',
	9,
	'Goal',
	'Each instance represents a particular goal as it is executing.
This class knows how to evaluate whether the goal is being achieved 
and whether the goal has completed.',
	0);
INSERT INTO O_TFR
	VALUES (2319,
	1681,
	'initialize',
	'',
	1192,
	0,
	'// Create and activate an instance of a goal specified by
//   the goal specification, if it exists, identified by 
//   the incoming parameter.

// Find the goal specification for this goal, then
//   create and relate this goal to the specification
//   and to the singleton workout session.
select any goalSpec from instances of GoalSpec where ( selected.sequenceNumber == param.sequenceNumber );
if ( not empty goalSpec )
  create object instance goal of Goal; goal.ID = goalSpec.last_goal_ID + 1;
  relate goal to goalSpec across R9.''specified_by'';
  select any session from instances of WorkoutSession;  // WorkoutSession is a singleton
  relate goal to session across R11.''is_currently_executing_within'';
  goalSpec.last_goal_ID = goal.ID;

  // Initialize this goal.
  goal.calculateStart();
  goal.disposition = GoalDisposition::Increase;

  // Start a timer that periodically causes evaluation of goal achievement.
  GoalAchievement::initialize();
  select any goalachievement from instances of GoalAchievement;
  create event instance evaluateEvent of Goal2:Evaluate to goal; goal.evaluationTimer = TIM::timer_start_recurring( event_inst: evaluateEvent, microseconds: goalachievement.evaluationPeriod );
end if;

',
	1,
	'',
	0,
	0);
INSERT INTO O_TPARM
	VALUES (2320,
	2319,
	'sequenceNumber',
	160,
	0,
	'',
	0,
	'Sequence number of the goal specification for which an instance of a goal should be created.');
INSERT INTO ACT_OPB
	VALUES (2321,
	2319);
INSERT INTO ACT_ACT
	VALUES (2321,
	'class operation',
	0,
	2322,
	0,
	0,
	'Goal::initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (2322,
	1,
	0,
	1,
	'',
	'',
	'',
	9,
	1,
	8,
	39,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2321,
	0);
INSERT INTO ACT_SMT
	VALUES (2323,
	2322,
	2324,
	8,
	1,
	'Goal::initialize line: 8');
INSERT INTO ACT_FIW
	VALUES (2323,
	2325,
	1,
	'any',
	2326,
	1542,
	8,
	39);
INSERT INTO ACT_SMT
	VALUES (2324,
	2322,
	0,
	9,
	1,
	'Goal::initialize line: 9');
INSERT INTO ACT_IF
	VALUES (2324,
	2327,
	2328,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2329,
	0,
	0,
	8,
	56,
	-1,
	0,
	0,
	0,
	0,
	1309,
	2322);
INSERT INTO V_SLR
	VALUES (2329,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2330,
	0,
	0,
	8,
	65,
	78,
	0,
	0,
	0,
	0,
	160,
	2322);
INSERT INTO V_AVL
	VALUES (2330,
	2329,
	1542,
	1563);
INSERT INTO V_VAL
	VALUES (2326,
	0,
	0,
	8,
	65,
	102,
	0,
	0,
	0,
	0,
	125,
	2322);
INSERT INTO V_BIN
	VALUES (2326,
	2331,
	2330,
	'==');
INSERT INTO V_VAL
	VALUES (2331,
	0,
	0,
	8,
	89,
	102,
	0,
	0,
	0,
	0,
	160,
	2322);
INSERT INTO V_PVL
	VALUES (2331,
	0,
	0,
	2320,
	0);
INSERT INTO V_VAL
	VALUES (2332,
	0,
	0,
	9,
	16,
	23,
	0,
	0,
	0,
	0,
	1309,
	2322);
INSERT INTO V_IRF
	VALUES (2332,
	2325);
INSERT INTO V_VAL
	VALUES (2333,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2322);
INSERT INTO V_UNY
	VALUES (2333,
	2332,
	'empty');
INSERT INTO V_VAL
	VALUES (2328,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2322);
INSERT INTO V_UNY
	VALUES (2328,
	2333,
	'not');
INSERT INTO V_VAR
	VALUES (2325,
	2322,
	'goalSpec',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2325,
	0,
	1542);
INSERT INTO ACT_BLK
	VALUES (2327,
	1,
	0,
	0,
	'TIM',
	'',
	'',
	23,
	66,
	23,
	89,
	0,
	0,
	13,
	33,
	13,
	37,
	18,
	22,
	0,
	2321,
	0);
INSERT INTO ACT_SMT
	VALUES (2334,
	2327,
	2335,
	10,
	3,
	'Goal::initialize line: 10');
INSERT INTO ACT_CR
	VALUES (2334,
	2336,
	1,
	1681,
	10,
	34);
INSERT INTO ACT_SMT
	VALUES (2335,
	2327,
	2337,
	10,
	40,
	'Goal::initialize line: 10');
INSERT INTO ACT_AI
	VALUES (2335,
	2338,
	2339,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2337,
	2327,
	2340,
	11,
	3,
	'Goal::initialize line: 11');
INSERT INTO ACT_REL
	VALUES (2337,
	2336,
	2325,
	'specified_by',
	2341,
	11,
	34,
	11,
	37);
INSERT INTO ACT_SMT
	VALUES (2340,
	2327,
	2342,
	12,
	3,
	'Goal::initialize line: 12');
INSERT INTO ACT_FIO
	VALUES (2340,
	2343,
	1,
	'any',
	1470,
	12,
	40);
INSERT INTO ACT_SMT
	VALUES (2342,
	2327,
	2344,
	13,
	3,
	'Goal::initialize line: 13');
INSERT INTO ACT_REL
	VALUES (2342,
	2336,
	2343,
	'is_currently_executing_within',
	1680,
	13,
	33,
	13,
	37);
INSERT INTO ACT_SMT
	VALUES (2344,
	2327,
	2345,
	14,
	3,
	'Goal::initialize line: 14');
INSERT INTO ACT_AI
	VALUES (2344,
	2346,
	2347,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2345,
	2327,
	2348,
	17,
	3,
	'Goal::initialize line: 17');
INSERT INTO ACT_TFM
	VALUES (2345,
	2349,
	2336,
	17,
	8,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2348,
	2327,
	2350,
	18,
	3,
	'Goal::initialize line: 18');
INSERT INTO ACT_AI
	VALUES (2348,
	2351,
	2352,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2350,
	2327,
	2353,
	21,
	3,
	'Goal::initialize line: 21');
INSERT INTO ACT_TFM
	VALUES (2350,
	2354,
	0,
	21,
	20,
	21,
	3);
INSERT INTO ACT_SMT
	VALUES (2353,
	2327,
	2355,
	22,
	3,
	'Goal::initialize line: 22');
INSERT INTO ACT_FIO
	VALUES (2353,
	2356,
	1,
	'any',
	2357,
	22,
	48);
INSERT INTO ACT_SMT
	VALUES (2355,
	2327,
	2358,
	23,
	3,
	'Goal::initialize line: 23');
INSERT INTO E_ESS
	VALUES (2355,
	1,
	0,
	23,
	42,
	23,
	48,
	22,
	48,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (2355,
	1,
	2359);
INSERT INTO E_CSME
	VALUES (2355,
	1969);
INSERT INTO E_CEI
	VALUES (2355,
	2336);
INSERT INTO ACT_SMT
	VALUES (2358,
	2327,
	0,
	23,
	66,
	'Goal::initialize line: 23');
INSERT INTO ACT_AI
	VALUES (2358,
	2360,
	2361,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2362,
	1,
	0,
	10,
	40,
	43,
	0,
	0,
	0,
	0,
	1309,
	2327);
INSERT INTO V_IRF
	VALUES (2362,
	2336);
INSERT INTO V_VAL
	VALUES (2339,
	1,
	0,
	10,
	45,
	46,
	0,
	0,
	0,
	0,
	160,
	2327);
INSERT INTO V_AVL
	VALUES (2339,
	2362,
	1681,
	2363);
INSERT INTO V_VAL
	VALUES (2364,
	0,
	0,
	10,
	50,
	57,
	0,
	0,
	0,
	0,
	1309,
	2327);
INSERT INTO V_IRF
	VALUES (2364,
	2325);
INSERT INTO V_VAL
	VALUES (2365,
	0,
	0,
	10,
	59,
	70,
	0,
	0,
	0,
	0,
	160,
	2327);
INSERT INTO V_AVL
	VALUES (2365,
	2364,
	1542,
	2318);
INSERT INTO V_VAL
	VALUES (2338,
	0,
	0,
	10,
	59,
	74,
	0,
	0,
	0,
	0,
	160,
	2327);
INSERT INTO V_BIN
	VALUES (2338,
	2366,
	2365,
	'+');
INSERT INTO V_VAL
	VALUES (2366,
	0,
	0,
	10,
	74,
	74,
	0,
	0,
	0,
	0,
	160,
	2327);
INSERT INTO V_LIN
	VALUES (2366,
	'1');
INSERT INTO V_VAL
	VALUES (2367,
	1,
	0,
	14,
	3,
	10,
	0,
	0,
	0,
	0,
	1309,
	2327);
INSERT INTO V_IRF
	VALUES (2367,
	2325);
INSERT INTO V_VAL
	VALUES (2347,
	1,
	0,
	14,
	12,
	23,
	0,
	0,
	0,
	0,
	160,
	2327);
INSERT INTO V_AVL
	VALUES (2347,
	2367,
	1542,
	2318);
INSERT INTO V_VAL
	VALUES (2368,
	0,
	0,
	14,
	27,
	30,
	0,
	0,
	0,
	0,
	1309,
	2327);
INSERT INTO V_IRF
	VALUES (2368,
	2336);
INSERT INTO V_VAL
	VALUES (2346,
	0,
	0,
	14,
	32,
	33,
	0,
	0,
	0,
	0,
	160,
	2327);
INSERT INTO V_AVL
	VALUES (2346,
	2368,
	1681,
	2363);
INSERT INTO V_VAL
	VALUES (2369,
	1,
	0,
	18,
	3,
	6,
	0,
	0,
	0,
	0,
	1309,
	2327);
INSERT INTO V_IRF
	VALUES (2369,
	2336);
INSERT INTO V_VAL
	VALUES (2352,
	1,
	0,
	18,
	8,
	18,
	0,
	0,
	0,
	0,
	2370,
	2327);
INSERT INTO V_AVL
	VALUES (2352,
	2369,
	1681,
	2371);
INSERT INTO V_VAL
	VALUES (2351,
	0,
	0,
	18,
	39,
	46,
	0,
	0,
	0,
	0,
	2370,
	2327);
INSERT INTO V_LEN
	VALUES (2351,
	2372,
	18,
	22);
INSERT INTO V_VAL
	VALUES (2373,
	1,
	0,
	23,
	66,
	69,
	0,
	0,
	0,
	0,
	1309,
	2327);
INSERT INTO V_IRF
	VALUES (2373,
	2336);
INSERT INTO V_VAL
	VALUES (2361,
	1,
	0,
	23,
	71,
	85,
	0,
	0,
	0,
	0,
	1272,
	2327);
INSERT INTO V_AVL
	VALUES (2361,
	2373,
	1681,
	2374);
INSERT INTO V_VAL
	VALUES (2360,
	0,
	0,
	23,
	94,
	-1,
	23,
	117,
	23,
	144,
	1272,
	2327);
INSERT INTO V_BRV
	VALUES (2360,
	1278,
	1,
	23,
	89);
INSERT INTO V_VAL
	VALUES (2375,
	0,
	0,
	23,
	129,
	141,
	0,
	0,
	0,
	0,
	1275,
	2327);
INSERT INTO V_TVL
	VALUES (2375,
	2359);
INSERT INTO V_PAR
	VALUES (2375,
	0,
	2360,
	'event_inst',
	2376,
	23,
	117);
INSERT INTO V_VAL
	VALUES (2377,
	0,
	0,
	23,
	158,
	172,
	0,
	0,
	0,
	0,
	1309,
	2327);
INSERT INTO V_IRF
	VALUES (2377,
	2356);
INSERT INTO V_VAL
	VALUES (2376,
	0,
	0,
	23,
	174,
	189,
	0,
	0,
	0,
	0,
	160,
	2327);
INSERT INTO V_AVL
	VALUES (2376,
	2377,
	2357,
	2378);
INSERT INTO V_PAR
	VALUES (2376,
	0,
	2360,
	'microseconds',
	0,
	23,
	144);
INSERT INTO V_VAR
	VALUES (2336,
	2327,
	'goal',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2336,
	0,
	1681);
INSERT INTO V_VAR
	VALUES (2343,
	2327,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2343,
	0,
	1470);
INSERT INTO V_VAR
	VALUES (2356,
	2327,
	'goalachievement',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2356,
	0,
	2357);
INSERT INTO V_VAR
	VALUES (2359,
	2327,
	'evaluateEvent',
	1,
	1275);
INSERT INTO V_TRN
	VALUES (2359,
	0,
	'');
INSERT INTO O_TFR
	VALUES (2349,
	1681,
	'calculateStart',
	'',
	1192,
	1,
	'// Based on the span type for this goal, calculate and
//   store the value of the start attribute.
select one goalSpec related by self->GoalSpec[R9.''specified_by''];
if ( goalSpec.spanType == GoalSpan::Time )
  select one workoutTimer related by self->WorkoutSession[R11.''is_currently_executing_within'']->WorkoutTimer[R8.''is_timed_by''];
  self.startingPoint = workoutTimer.time;
elif ( goalSpec.spanType == GoalSpan::Distance )
  select one session related by self->WorkoutSession[R11.''is_currently_executing_within''];
  self.startingPoint = session.accumulatedDistance;
else
  LOG::LogFailure( message: "Goal.calculateStart: Unknown Goal Span Type." );
end if;',
	1,
	'',
	2319,
	0);
INSERT INTO ACT_OPB
	VALUES (2379,
	2349);
INSERT INTO ACT_ACT
	VALUES (2379,
	'operation',
	0,
	2380,
	0,
	0,
	'Goal::calculateStart',
	0);
INSERT INTO ACT_BLK
	VALUES (2380,
	1,
	0,
	0,
	'',
	'',
	'',
	10,
	1,
	3,
	38,
	0,
	0,
	3,
	47,
	3,
	50,
	7,
	29,
	0,
	2379,
	0);
INSERT INTO ACT_SMT
	VALUES (2381,
	2380,
	2382,
	3,
	1,
	'Goal::calculateStart line: 3');
INSERT INTO ACT_SEL
	VALUES (2381,
	2383,
	1,
	'one',
	2384);
INSERT INTO ACT_SR
	VALUES (2381);
INSERT INTO ACT_LNK
	VALUES (2385,
	'specified_by',
	2381,
	2341,
	0,
	2,
	1542,
	3,
	38,
	3,
	47,
	3,
	50);
INSERT INTO ACT_SMT
	VALUES (2382,
	2380,
	0,
	4,
	1,
	'Goal::calculateStart line: 4');
INSERT INTO ACT_IF
	VALUES (2382,
	2386,
	2387,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2388,
	2380,
	0,
	7,
	1,
	'Goal::calculateStart line: 7');
INSERT INTO ACT_EL
	VALUES (2388,
	2389,
	2390,
	2382);
INSERT INTO ACT_SMT
	VALUES (2391,
	2380,
	0,
	10,
	1,
	'Goal::calculateStart line: 10');
INSERT INTO ACT_E
	VALUES (2391,
	2392,
	2382);
INSERT INTO V_VAL
	VALUES (2384,
	0,
	0,
	3,
	32,
	35,
	0,
	0,
	0,
	0,
	1309,
	2380);
INSERT INTO V_IRF
	VALUES (2384,
	2393);
INSERT INTO V_VAL
	VALUES (2394,
	0,
	0,
	4,
	6,
	13,
	0,
	0,
	0,
	0,
	1309,
	2380);
INSERT INTO V_IRF
	VALUES (2394,
	2383);
INSERT INTO V_VAL
	VALUES (2395,
	0,
	0,
	4,
	15,
	22,
	0,
	0,
	0,
	0,
	147,
	2380);
INSERT INTO V_AVL
	VALUES (2395,
	2394,
	1542,
	1573);
INSERT INTO V_VAL
	VALUES (2387,
	0,
	0,
	4,
	15,
	40,
	0,
	0,
	0,
	0,
	125,
	2380);
INSERT INTO V_BIN
	VALUES (2387,
	2396,
	2395,
	'==');
INSERT INTO V_VAL
	VALUES (2396,
	0,
	0,
	4,
	37,
	40,
	0,
	0,
	0,
	0,
	147,
	2380);
INSERT INTO V_LEN
	VALUES (2396,
	164,
	4,
	27);
INSERT INTO V_VAL
	VALUES (2397,
	0,
	0,
	7,
	8,
	15,
	0,
	0,
	0,
	0,
	1309,
	2380);
INSERT INTO V_IRF
	VALUES (2397,
	2383);
INSERT INTO V_VAL
	VALUES (2398,
	0,
	0,
	7,
	17,
	24,
	0,
	0,
	0,
	0,
	147,
	2380);
INSERT INTO V_AVL
	VALUES (2398,
	2397,
	1542,
	1573);
INSERT INTO V_VAL
	VALUES (2390,
	0,
	0,
	7,
	17,
	46,
	0,
	0,
	0,
	0,
	125,
	2380);
INSERT INTO V_BIN
	VALUES (2390,
	2399,
	2398,
	'==');
INSERT INTO V_VAL
	VALUES (2399,
	0,
	0,
	7,
	39,
	46,
	0,
	0,
	0,
	0,
	147,
	2380);
INSERT INTO V_LEN
	VALUES (2399,
	148,
	7,
	29);
INSERT INTO V_VAR
	VALUES (2383,
	2380,
	'goalSpec',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2383,
	0,
	1542);
INSERT INTO V_VAR
	VALUES (2393,
	2380,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2393,
	0,
	1681);
INSERT INTO ACT_BLK
	VALUES (2386,
	1,
	0,
	0,
	'',
	'',
	'',
	6,
	3,
	5,
	97,
	0,
	0,
	5,
	110,
	5,
	113,
	0,
	0,
	0,
	2379,
	0);
INSERT INTO ACT_SMT
	VALUES (2400,
	2386,
	2401,
	5,
	3,
	'Goal::calculateStart line: 5');
INSERT INTO ACT_SEL
	VALUES (2400,
	2402,
	1,
	'one',
	2403);
INSERT INTO ACT_SR
	VALUES (2400);
INSERT INTO ACT_LNK
	VALUES (2404,
	'is_currently_executing_within',
	2400,
	1680,
	2405,
	2,
	1470,
	5,
	44,
	5,
	59,
	5,
	63);
INSERT INTO ACT_LNK
	VALUES (2405,
	'is_timed_by',
	0,
	1583,
	0,
	2,
	1488,
	5,
	97,
	5,
	110,
	5,
	113);
INSERT INTO ACT_SMT
	VALUES (2401,
	2386,
	0,
	6,
	3,
	'Goal::calculateStart line: 6');
INSERT INTO ACT_AI
	VALUES (2401,
	2406,
	2407,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2403,
	0,
	0,
	5,
	38,
	41,
	0,
	0,
	0,
	0,
	1309,
	2386);
INSERT INTO V_IRF
	VALUES (2403,
	2393);
INSERT INTO V_VAL
	VALUES (2408,
	1,
	0,
	6,
	3,
	6,
	0,
	0,
	0,
	0,
	1309,
	2386);
INSERT INTO V_IRF
	VALUES (2408,
	2393);
INSERT INTO V_VAL
	VALUES (2407,
	1,
	0,
	6,
	8,
	20,
	0,
	0,
	0,
	0,
	153,
	2386);
INSERT INTO V_AVL
	VALUES (2407,
	2408,
	1681,
	2409);
INSERT INTO V_VAL
	VALUES (2410,
	0,
	0,
	6,
	24,
	35,
	0,
	0,
	0,
	0,
	1309,
	2386);
INSERT INTO V_IRF
	VALUES (2410,
	2402);
INSERT INTO V_VAL
	VALUES (2406,
	0,
	0,
	6,
	37,
	40,
	0,
	0,
	0,
	0,
	160,
	2386);
INSERT INTO V_AVL
	VALUES (2406,
	2410,
	1488,
	1604);
INSERT INTO V_VAR
	VALUES (2402,
	2386,
	'workoutTimer',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2402,
	0,
	1488);
INSERT INTO ACT_BLK
	VALUES (2389,
	1,
	0,
	0,
	'',
	'',
	'',
	9,
	3,
	8,
	39,
	0,
	0,
	8,
	54,
	8,
	58,
	0,
	0,
	0,
	2379,
	0);
INSERT INTO ACT_SMT
	VALUES (2411,
	2389,
	2412,
	8,
	3,
	'Goal::calculateStart line: 8');
INSERT INTO ACT_SEL
	VALUES (2411,
	2413,
	1,
	'one',
	2414);
INSERT INTO ACT_SR
	VALUES (2411);
INSERT INTO ACT_LNK
	VALUES (2415,
	'is_currently_executing_within',
	2411,
	1680,
	0,
	2,
	1470,
	8,
	39,
	8,
	54,
	8,
	58);
INSERT INTO ACT_SMT
	VALUES (2412,
	2389,
	0,
	9,
	3,
	'Goal::calculateStart line: 9');
INSERT INTO ACT_AI
	VALUES (2412,
	2416,
	2417,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2414,
	0,
	0,
	8,
	33,
	36,
	0,
	0,
	0,
	0,
	1309,
	2389);
INSERT INTO V_IRF
	VALUES (2414,
	2393);
INSERT INTO V_VAL
	VALUES (2418,
	1,
	0,
	9,
	3,
	6,
	0,
	0,
	0,
	0,
	1309,
	2389);
INSERT INTO V_IRF
	VALUES (2418,
	2393);
INSERT INTO V_VAL
	VALUES (2417,
	1,
	0,
	9,
	8,
	20,
	0,
	0,
	0,
	0,
	153,
	2389);
INSERT INTO V_AVL
	VALUES (2417,
	2418,
	1681,
	2409);
INSERT INTO V_VAL
	VALUES (2419,
	0,
	0,
	9,
	24,
	30,
	0,
	0,
	0,
	0,
	1309,
	2389);
INSERT INTO V_IRF
	VALUES (2419,
	2413);
INSERT INTO V_VAL
	VALUES (2416,
	0,
	0,
	9,
	32,
	50,
	0,
	0,
	0,
	0,
	153,
	2389);
INSERT INTO V_AVL
	VALUES (2416,
	2419,
	1470,
	1651);
INSERT INTO V_VAR
	VALUES (2413,
	2389,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2413,
	0,
	1470);
INSERT INTO ACT_BLK
	VALUES (2392,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	11,
	3,
	11,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2379,
	0);
INSERT INTO ACT_SMT
	VALUES (2420,
	2392,
	0,
	11,
	3,
	'Goal::calculateStart line: 11');
INSERT INTO ACT_BRG
	VALUES (2420,
	1202,
	11,
	8,
	11,
	3);
INSERT INTO V_VAL
	VALUES (2421,
	0,
	0,
	11,
	29,
	73,
	0,
	0,
	0,
	0,
	1199,
	2392);
INSERT INTO V_LST
	VALUES (2421,
	'Goal.calculateStart: Unknown Goal Span Type.');
INSERT INTO V_PAR
	VALUES (2421,
	2420,
	0,
	'message',
	0,
	11,
	20);
INSERT INTO O_TFR
	VALUES (2422,
	1681,
	'evaluateAchievement',
	'',
	2370,
	1,
	'// Based on the type of goal, determine whether this one is 
//   currently being achieved and return a value indicating
//   the disposition of the this goal.    

// Find the related goal specification and workout session for this goal.
select one goalSpec related by self->GoalSpec[R9.''specified_by''];
select one session related by self->WorkoutSession[R11.''is_currently_executing_within''];

// Based on the goal criteria type, get the appropriate current value
//   for comparison against the criteria (minimum and maximum).
currentValue = 0.0;  // Explicit declaration
if ( goalSpec.criteriaType == GoalCriteria::HeartRate )
  currentValue = session.getCurrentHeartRate();
elif ( goalSpec.criteriaType == GoalCriteria::Pace )
  currentValue = session.getCurrentPace();
else
  LOG::LogFailure( message: "Goal.evaluateAchievement: Unknown Goal Criteria Type." );
end if;
 
// Compare the current value against the criteria to calculate the return value.
goalDisposition = GoalDisposition::Achieving; 
if ( currentValue < goalSpec.minimum )
  goalDisposition = GoalDisposition::Increase;
elif ( currentValue > goalSpec.maximum )
  goalDisposition = GoalDisposition::Decrease;
end if;

// Invert the disposition value to produce a logical, semantic disposition for
//   goal types, such as pace, that require it.
if ( goalSpec.criteriaType == GoalCriteria::Pace )
  if ( goalDisposition == GoalDisposition::Increase )
    goalDisposition = GoalDisposition::Decrease;
  elif ( goalDisposition == GoalDisposition::Decrease )
    goalDisposition = GoalDisposition::Increase;
  end if;
end if;
 
return( goalDisposition );',
	1,
	'',
	2349,
	0);
INSERT INTO ACT_OPB
	VALUES (2423,
	2422);
INSERT INTO ACT_ACT
	VALUES (2423,
	'operation',
	0,
	2424,
	0,
	0,
	'Goal::evaluateAchievement',
	0);
INSERT INTO ACT_BLK
	VALUES (2424,
	1,
	0,
	0,
	'',
	'',
	'',
	38,
	1,
	7,
	37,
	0,
	0,
	7,
	52,
	7,
	56,
	30,
	31,
	0,
	2423,
	0);
INSERT INTO ACT_SMT
	VALUES (2425,
	2424,
	2426,
	6,
	1,
	'Goal::evaluateAchievement line: 6');
INSERT INTO ACT_SEL
	VALUES (2425,
	2427,
	1,
	'one',
	2428);
INSERT INTO ACT_SR
	VALUES (2425);
INSERT INTO ACT_LNK
	VALUES (2429,
	'specified_by',
	2425,
	2341,
	0,
	2,
	1542,
	6,
	38,
	6,
	47,
	6,
	50);
INSERT INTO ACT_SMT
	VALUES (2426,
	2424,
	2430,
	7,
	1,
	'Goal::evaluateAchievement line: 7');
INSERT INTO ACT_SEL
	VALUES (2426,
	2431,
	1,
	'one',
	2432);
INSERT INTO ACT_SR
	VALUES (2426);
INSERT INTO ACT_LNK
	VALUES (2433,
	'is_currently_executing_within',
	2426,
	1680,
	0,
	2,
	1470,
	7,
	37,
	7,
	52,
	7,
	56);
INSERT INTO ACT_SMT
	VALUES (2430,
	2424,
	2434,
	11,
	1,
	'Goal::evaluateAchievement line: 11');
INSERT INTO ACT_AI
	VALUES (2430,
	2435,
	2436,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2434,
	2424,
	2437,
	12,
	1,
	'Goal::evaluateAchievement line: 12');
INSERT INTO ACT_IF
	VALUES (2434,
	2438,
	2439,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2440,
	2424,
	0,
	14,
	1,
	'Goal::evaluateAchievement line: 14');
INSERT INTO ACT_EL
	VALUES (2440,
	2441,
	2442,
	2434);
INSERT INTO ACT_SMT
	VALUES (2443,
	2424,
	0,
	16,
	1,
	'Goal::evaluateAchievement line: 16');
INSERT INTO ACT_E
	VALUES (2443,
	2444,
	2434);
INSERT INTO ACT_SMT
	VALUES (2437,
	2424,
	2445,
	21,
	1,
	'Goal::evaluateAchievement line: 21');
INSERT INTO ACT_AI
	VALUES (2437,
	2446,
	2447,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2445,
	2424,
	2448,
	22,
	1,
	'Goal::evaluateAchievement line: 22');
INSERT INTO ACT_IF
	VALUES (2445,
	2449,
	2450,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2451,
	2424,
	0,
	24,
	1,
	'Goal::evaluateAchievement line: 24');
INSERT INTO ACT_EL
	VALUES (2451,
	2452,
	2453,
	2445);
INSERT INTO ACT_SMT
	VALUES (2448,
	2424,
	2454,
	30,
	1,
	'Goal::evaluateAchievement line: 30');
INSERT INTO ACT_IF
	VALUES (2448,
	2455,
	2456,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2454,
	2424,
	0,
	38,
	1,
	'Goal::evaluateAchievement line: 38');
INSERT INTO ACT_RET
	VALUES (2454,
	2457);
INSERT INTO V_VAL
	VALUES (2428,
	0,
	0,
	6,
	32,
	35,
	0,
	0,
	0,
	0,
	1309,
	2424);
INSERT INTO V_IRF
	VALUES (2428,
	2458);
INSERT INTO V_VAL
	VALUES (2432,
	0,
	0,
	7,
	31,
	34,
	0,
	0,
	0,
	0,
	1309,
	2424);
INSERT INTO V_IRF
	VALUES (2432,
	2458);
INSERT INTO V_VAL
	VALUES (2436,
	1,
	1,
	11,
	1,
	12,
	0,
	0,
	0,
	0,
	153,
	2424);
INSERT INTO V_TVL
	VALUES (2436,
	2459);
INSERT INTO V_VAL
	VALUES (2435,
	0,
	0,
	11,
	16,
	18,
	0,
	0,
	0,
	0,
	153,
	2424);
INSERT INTO V_LRL
	VALUES (2435,
	'0.0');
INSERT INTO V_VAL
	VALUES (2460,
	0,
	0,
	12,
	6,
	13,
	0,
	0,
	0,
	0,
	1309,
	2424);
INSERT INTO V_IRF
	VALUES (2460,
	2427);
INSERT INTO V_VAL
	VALUES (2461,
	0,
	0,
	12,
	15,
	26,
	0,
	0,
	0,
	0,
	150,
	2424);
INSERT INTO V_AVL
	VALUES (2461,
	2460,
	1542,
	1571);
INSERT INTO V_VAL
	VALUES (2439,
	0,
	0,
	12,
	15,
	53,
	0,
	0,
	0,
	0,
	125,
	2424);
INSERT INTO V_BIN
	VALUES (2439,
	2462,
	2461,
	'==');
INSERT INTO V_VAL
	VALUES (2462,
	0,
	0,
	12,
	45,
	53,
	0,
	0,
	0,
	0,
	150,
	2424);
INSERT INTO V_LEN
	VALUES (2462,
	151,
	12,
	31);
INSERT INTO V_VAL
	VALUES (2463,
	0,
	0,
	14,
	8,
	15,
	0,
	0,
	0,
	0,
	1309,
	2424);
INSERT INTO V_IRF
	VALUES (2463,
	2427);
INSERT INTO V_VAL
	VALUES (2464,
	0,
	0,
	14,
	17,
	28,
	0,
	0,
	0,
	0,
	150,
	2424);
INSERT INTO V_AVL
	VALUES (2464,
	2463,
	1542,
	1571);
INSERT INTO V_VAL
	VALUES (2442,
	0,
	0,
	14,
	17,
	50,
	0,
	0,
	0,
	0,
	125,
	2424);
INSERT INTO V_BIN
	VALUES (2442,
	2465,
	2464,
	'==');
INSERT INTO V_VAL
	VALUES (2465,
	0,
	0,
	14,
	47,
	50,
	0,
	0,
	0,
	0,
	150,
	2424);
INSERT INTO V_LEN
	VALUES (2465,
	183,
	14,
	33);
INSERT INTO V_VAL
	VALUES (2447,
	1,
	1,
	21,
	1,
	15,
	0,
	0,
	0,
	0,
	2370,
	2424);
INSERT INTO V_TVL
	VALUES (2447,
	2466);
INSERT INTO V_VAL
	VALUES (2446,
	0,
	0,
	21,
	36,
	44,
	0,
	0,
	0,
	0,
	2370,
	2424);
INSERT INTO V_LEN
	VALUES (2446,
	2467,
	21,
	19);
INSERT INTO V_VAL
	VALUES (2468,
	0,
	0,
	22,
	6,
	17,
	0,
	0,
	0,
	0,
	153,
	2424);
INSERT INTO V_TVL
	VALUES (2468,
	2459);
INSERT INTO V_VAL
	VALUES (2450,
	0,
	0,
	22,
	6,
	36,
	0,
	0,
	0,
	0,
	125,
	2424);
INSERT INTO V_BIN
	VALUES (2450,
	2469,
	2468,
	'<');
INSERT INTO V_VAL
	VALUES (2470,
	0,
	0,
	22,
	21,
	28,
	0,
	0,
	0,
	0,
	1309,
	2424);
INSERT INTO V_IRF
	VALUES (2470,
	2427);
INSERT INTO V_VAL
	VALUES (2469,
	0,
	0,
	22,
	30,
	36,
	0,
	0,
	0,
	0,
	153,
	2424);
INSERT INTO V_AVL
	VALUES (2469,
	2470,
	1542,
	1565);
INSERT INTO V_VAL
	VALUES (2471,
	0,
	0,
	24,
	8,
	19,
	0,
	0,
	0,
	0,
	153,
	2424);
INSERT INTO V_TVL
	VALUES (2471,
	2459);
INSERT INTO V_VAL
	VALUES (2453,
	0,
	0,
	24,
	8,
	38,
	0,
	0,
	0,
	0,
	125,
	2424);
INSERT INTO V_BIN
	VALUES (2453,
	2472,
	2471,
	'>');
INSERT INTO V_VAL
	VALUES (2473,
	0,
	0,
	24,
	23,
	30,
	0,
	0,
	0,
	0,
	1309,
	2424);
INSERT INTO V_IRF
	VALUES (2473,
	2427);
INSERT INTO V_VAL
	VALUES (2472,
	0,
	0,
	24,
	32,
	38,
	0,
	0,
	0,
	0,
	153,
	2424);
INSERT INTO V_AVL
	VALUES (2472,
	2473,
	1542,
	1567);
INSERT INTO V_VAL
	VALUES (2474,
	0,
	0,
	30,
	6,
	13,
	0,
	0,
	0,
	0,
	1309,
	2424);
INSERT INTO V_IRF
	VALUES (2474,
	2427);
INSERT INTO V_VAL
	VALUES (2475,
	0,
	0,
	30,
	15,
	26,
	0,
	0,
	0,
	0,
	150,
	2424);
INSERT INTO V_AVL
	VALUES (2475,
	2474,
	1542,
	1571);
INSERT INTO V_VAL
	VALUES (2456,
	0,
	0,
	30,
	15,
	48,
	0,
	0,
	0,
	0,
	125,
	2424);
INSERT INTO V_BIN
	VALUES (2456,
	2476,
	2475,
	'==');
INSERT INTO V_VAL
	VALUES (2476,
	0,
	0,
	30,
	45,
	48,
	0,
	0,
	0,
	0,
	150,
	2424);
INSERT INTO V_LEN
	VALUES (2476,
	183,
	30,
	31);
INSERT INTO V_VAL
	VALUES (2457,
	0,
	0,
	38,
	9,
	23,
	0,
	0,
	0,
	0,
	2370,
	2424);
INSERT INTO V_TVL
	VALUES (2457,
	2466);
INSERT INTO V_VAR
	VALUES (2427,
	2424,
	'goalSpec',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2427,
	0,
	1542);
INSERT INTO V_VAR
	VALUES (2458,
	2424,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2458,
	0,
	1681);
INSERT INTO V_VAR
	VALUES (2431,
	2424,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2431,
	0,
	1470);
INSERT INTO V_VAR
	VALUES (2459,
	2424,
	'currentValue',
	1,
	153);
INSERT INTO V_TRN
	VALUES (2459,
	0,
	'');
INSERT INTO V_VAR
	VALUES (2466,
	2424,
	'goalDisposition',
	1,
	2370);
INSERT INTO V_TRN
	VALUES (2466,
	0,
	'');
INSERT INTO ACT_BLK
	VALUES (2438,
	0,
	0,
	0,
	'',
	'',
	'',
	13,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2423,
	0);
INSERT INTO ACT_SMT
	VALUES (2477,
	2438,
	0,
	13,
	3,
	'Goal::evaluateAchievement line: 13');
INSERT INTO ACT_AI
	VALUES (2477,
	2478,
	2479,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2479,
	1,
	0,
	13,
	3,
	14,
	0,
	0,
	0,
	0,
	153,
	2438);
INSERT INTO V_TVL
	VALUES (2479,
	2459);
INSERT INTO V_VAL
	VALUES (2478,
	0,
	0,
	13,
	26,
	-1,
	0,
	0,
	0,
	0,
	160,
	2438);
INSERT INTO V_TRV
	VALUES (2478,
	1865,
	2431,
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (2441,
	0,
	0,
	0,
	'',
	'',
	'',
	15,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2423,
	0);
INSERT INTO ACT_SMT
	VALUES (2480,
	2441,
	0,
	15,
	3,
	'Goal::evaluateAchievement line: 15');
INSERT INTO ACT_AI
	VALUES (2480,
	2481,
	2482,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2482,
	1,
	0,
	15,
	3,
	14,
	0,
	0,
	0,
	0,
	153,
	2441);
INSERT INTO V_TVL
	VALUES (2482,
	2459);
INSERT INTO V_VAL
	VALUES (2481,
	0,
	0,
	15,
	26,
	-1,
	0,
	0,
	0,
	0,
	153,
	2441);
INSERT INTO V_TRV
	VALUES (2481,
	1840,
	2431,
	1,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (2444,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	17,
	3,
	17,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2423,
	0);
INSERT INTO ACT_SMT
	VALUES (2483,
	2444,
	0,
	17,
	3,
	'Goal::evaluateAchievement line: 17');
INSERT INTO ACT_BRG
	VALUES (2483,
	1202,
	17,
	8,
	17,
	3);
INSERT INTO V_VAL
	VALUES (2484,
	0,
	0,
	17,
	29,
	82,
	0,
	0,
	0,
	0,
	1199,
	2444);
INSERT INTO V_LST
	VALUES (2484,
	'Goal.evaluateAchievement: Unknown Goal Criteria Type.');
INSERT INTO V_PAR
	VALUES (2484,
	2483,
	0,
	'message',
	0,
	17,
	20);
INSERT INTO ACT_BLK
	VALUES (2449,
	0,
	0,
	0,
	'',
	'',
	'',
	23,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	23,
	21,
	0,
	2423,
	0);
INSERT INTO ACT_SMT
	VALUES (2485,
	2449,
	0,
	23,
	3,
	'Goal::evaluateAchievement line: 23');
INSERT INTO ACT_AI
	VALUES (2485,
	2486,
	2487,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2487,
	1,
	0,
	23,
	3,
	17,
	0,
	0,
	0,
	0,
	2370,
	2449);
INSERT INTO V_TVL
	VALUES (2487,
	2466);
INSERT INTO V_VAL
	VALUES (2486,
	0,
	0,
	23,
	38,
	45,
	0,
	0,
	0,
	0,
	2370,
	2449);
INSERT INTO V_LEN
	VALUES (2486,
	2372,
	23,
	21);
INSERT INTO ACT_BLK
	VALUES (2452,
	0,
	0,
	0,
	'',
	'',
	'',
	25,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	25,
	21,
	0,
	2423,
	0);
INSERT INTO ACT_SMT
	VALUES (2488,
	2452,
	0,
	25,
	3,
	'Goal::evaluateAchievement line: 25');
INSERT INTO ACT_AI
	VALUES (2488,
	2489,
	2490,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2490,
	1,
	0,
	25,
	3,
	17,
	0,
	0,
	0,
	0,
	2370,
	2452);
INSERT INTO V_TVL
	VALUES (2490,
	2466);
INSERT INTO V_VAL
	VALUES (2489,
	0,
	0,
	25,
	38,
	45,
	0,
	0,
	0,
	0,
	2370,
	2452);
INSERT INTO V_LEN
	VALUES (2489,
	2491,
	25,
	21);
INSERT INTO ACT_BLK
	VALUES (2455,
	0,
	0,
	0,
	'',
	'',
	'',
	33,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	33,
	29,
	0,
	2423,
	0);
INSERT INTO ACT_SMT
	VALUES (2492,
	2455,
	0,
	31,
	3,
	'Goal::evaluateAchievement line: 31');
INSERT INTO ACT_IF
	VALUES (2492,
	2493,
	2494,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2495,
	2455,
	0,
	33,
	3,
	'Goal::evaluateAchievement line: 33');
INSERT INTO ACT_EL
	VALUES (2495,
	2496,
	2497,
	2492);
INSERT INTO V_VAL
	VALUES (2498,
	0,
	0,
	31,
	8,
	22,
	0,
	0,
	0,
	0,
	2370,
	2455);
INSERT INTO V_TVL
	VALUES (2498,
	2466);
INSERT INTO V_VAL
	VALUES (2494,
	0,
	0,
	31,
	8,
	51,
	0,
	0,
	0,
	0,
	125,
	2455);
INSERT INTO V_BIN
	VALUES (2494,
	2499,
	2498,
	'==');
INSERT INTO V_VAL
	VALUES (2499,
	0,
	0,
	31,
	44,
	51,
	0,
	0,
	0,
	0,
	2370,
	2455);
INSERT INTO V_LEN
	VALUES (2499,
	2372,
	31,
	27);
INSERT INTO V_VAL
	VALUES (2500,
	0,
	0,
	33,
	10,
	24,
	0,
	0,
	0,
	0,
	2370,
	2455);
INSERT INTO V_TVL
	VALUES (2500,
	2466);
INSERT INTO V_VAL
	VALUES (2497,
	0,
	0,
	33,
	10,
	53,
	0,
	0,
	0,
	0,
	125,
	2455);
INSERT INTO V_BIN
	VALUES (2497,
	2501,
	2500,
	'==');
INSERT INTO V_VAL
	VALUES (2501,
	0,
	0,
	33,
	46,
	53,
	0,
	0,
	0,
	0,
	2370,
	2455);
INSERT INTO V_LEN
	VALUES (2501,
	2491,
	33,
	29);
INSERT INTO ACT_BLK
	VALUES (2493,
	0,
	0,
	0,
	'',
	'',
	'',
	32,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	32,
	23,
	0,
	2423,
	0);
INSERT INTO ACT_SMT
	VALUES (2502,
	2493,
	0,
	32,
	5,
	'Goal::evaluateAchievement line: 32');
INSERT INTO ACT_AI
	VALUES (2502,
	2503,
	2504,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2504,
	1,
	0,
	32,
	5,
	19,
	0,
	0,
	0,
	0,
	2370,
	2493);
INSERT INTO V_TVL
	VALUES (2504,
	2466);
INSERT INTO V_VAL
	VALUES (2503,
	0,
	0,
	32,
	40,
	47,
	0,
	0,
	0,
	0,
	2370,
	2493);
INSERT INTO V_LEN
	VALUES (2503,
	2491,
	32,
	23);
INSERT INTO ACT_BLK
	VALUES (2496,
	0,
	0,
	0,
	'',
	'',
	'',
	34,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	34,
	23,
	0,
	2423,
	0);
INSERT INTO ACT_SMT
	VALUES (2505,
	2496,
	0,
	34,
	5,
	'Goal::evaluateAchievement line: 34');
INSERT INTO ACT_AI
	VALUES (2505,
	2506,
	2507,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2507,
	1,
	0,
	34,
	5,
	19,
	0,
	0,
	0,
	0,
	2370,
	2496);
INSERT INTO V_TVL
	VALUES (2507,
	2466);
INSERT INTO V_VAL
	VALUES (2506,
	0,
	0,
	34,
	40,
	47,
	0,
	0,
	0,
	0,
	2370,
	2496);
INSERT INTO V_LEN
	VALUES (2506,
	2372,
	34,
	23);
INSERT INTO O_TFR
	VALUES (2508,
	1681,
	'evaluateCompletion',
	'',
	1192,
	1,
	'// Based on the span type for this goal, determine 
//  whether it has been completed, update achievement
//  records as necessary, and advance to the next goal
//  if appropriate.

select one goalSpec related by self->GoalSpec[R9.''specified_by''];

// Based on the span type for the goal, get the elapsed span 
//   for comparison against the specified span for the goal.
elapsedSpan = 0.0;  // Explicit declaration
if ( goalSpec.spanType == GoalSpan::Distance )
  select one session related by self->WorkoutSession[R11.''is_currently_executing_within''];
  elapsedSpan = session.accumulatedDistance - self.startingPoint;
elif ( goalSpec.spanType == GoalSpan::Time )
  select one workoutTimer related by self->WorkoutSession[R11.''is_currently_executing_within'']->WorkoutTimer[R8.''is_timed_by''];
  elapsedSpan = workoutTimer.time - self.startingPoint;
else
  LOG::LogFailure( message: "Goal.evaluateCompletion: Unknown Goal Span Type." );
end if;

// Compare the current value against the specified span to determine 
//   whether the execution of this workout goal is complete.
if ( elapsedSpan >= goalSpec.span )
  select one openAchievement related by self->Achievement[R14.''has_open''];
  if ( not empty openAchievement )
    openAchievement.close();
  end if;
  generate Goal1:Completed to self;
end if;
',
	1,
	'',
	2422,
	0);
INSERT INTO ACT_OPB
	VALUES (2509,
	2508);
INSERT INTO ACT_ACT
	VALUES (2509,
	'operation',
	0,
	2510,
	0,
	0,
	'Goal::evaluateCompletion',
	0);
INSERT INTO ACT_BLK
	VALUES (2510,
	1,
	0,
	0,
	'',
	'',
	'',
	23,
	1,
	6,
	38,
	0,
	0,
	6,
	47,
	6,
	50,
	14,
	29,
	0,
	2509,
	0);
INSERT INTO ACT_SMT
	VALUES (2511,
	2510,
	2512,
	6,
	1,
	'Goal::evaluateCompletion line: 6');
INSERT INTO ACT_SEL
	VALUES (2511,
	2513,
	1,
	'one',
	2514);
INSERT INTO ACT_SR
	VALUES (2511);
INSERT INTO ACT_LNK
	VALUES (2515,
	'specified_by',
	2511,
	2341,
	0,
	2,
	1542,
	6,
	38,
	6,
	47,
	6,
	50);
INSERT INTO ACT_SMT
	VALUES (2512,
	2510,
	2516,
	10,
	1,
	'Goal::evaluateCompletion line: 10');
INSERT INTO ACT_AI
	VALUES (2512,
	2517,
	2518,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2516,
	2510,
	2519,
	11,
	1,
	'Goal::evaluateCompletion line: 11');
INSERT INTO ACT_IF
	VALUES (2516,
	2520,
	2521,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2522,
	2510,
	0,
	14,
	1,
	'Goal::evaluateCompletion line: 14');
INSERT INTO ACT_EL
	VALUES (2522,
	2523,
	2524,
	2516);
INSERT INTO ACT_SMT
	VALUES (2525,
	2510,
	0,
	17,
	1,
	'Goal::evaluateCompletion line: 17');
INSERT INTO ACT_E
	VALUES (2525,
	2526,
	2516);
INSERT INTO ACT_SMT
	VALUES (2519,
	2510,
	0,
	23,
	1,
	'Goal::evaluateCompletion line: 23');
INSERT INTO ACT_IF
	VALUES (2519,
	2527,
	2528,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2514,
	0,
	0,
	6,
	32,
	35,
	0,
	0,
	0,
	0,
	1309,
	2510);
INSERT INTO V_IRF
	VALUES (2514,
	2529);
INSERT INTO V_VAL
	VALUES (2518,
	1,
	1,
	10,
	1,
	11,
	0,
	0,
	0,
	0,
	153,
	2510);
INSERT INTO V_TVL
	VALUES (2518,
	2530);
INSERT INTO V_VAL
	VALUES (2517,
	0,
	0,
	10,
	15,
	17,
	0,
	0,
	0,
	0,
	153,
	2510);
INSERT INTO V_LRL
	VALUES (2517,
	'0.0');
INSERT INTO V_VAL
	VALUES (2531,
	0,
	0,
	11,
	6,
	13,
	0,
	0,
	0,
	0,
	1309,
	2510);
INSERT INTO V_IRF
	VALUES (2531,
	2513);
INSERT INTO V_VAL
	VALUES (2532,
	0,
	0,
	11,
	15,
	22,
	0,
	0,
	0,
	0,
	147,
	2510);
INSERT INTO V_AVL
	VALUES (2532,
	2531,
	1542,
	1573);
INSERT INTO V_VAL
	VALUES (2521,
	0,
	0,
	11,
	15,
	44,
	0,
	0,
	0,
	0,
	125,
	2510);
INSERT INTO V_BIN
	VALUES (2521,
	2533,
	2532,
	'==');
INSERT INTO V_VAL
	VALUES (2533,
	0,
	0,
	11,
	37,
	44,
	0,
	0,
	0,
	0,
	147,
	2510);
INSERT INTO V_LEN
	VALUES (2533,
	148,
	11,
	27);
INSERT INTO V_VAL
	VALUES (2534,
	0,
	0,
	14,
	8,
	15,
	0,
	0,
	0,
	0,
	1309,
	2510);
INSERT INTO V_IRF
	VALUES (2534,
	2513);
INSERT INTO V_VAL
	VALUES (2535,
	0,
	0,
	14,
	17,
	24,
	0,
	0,
	0,
	0,
	147,
	2510);
INSERT INTO V_AVL
	VALUES (2535,
	2534,
	1542,
	1573);
INSERT INTO V_VAL
	VALUES (2524,
	0,
	0,
	14,
	17,
	42,
	0,
	0,
	0,
	0,
	125,
	2510);
INSERT INTO V_BIN
	VALUES (2524,
	2536,
	2535,
	'==');
INSERT INTO V_VAL
	VALUES (2536,
	0,
	0,
	14,
	39,
	42,
	0,
	0,
	0,
	0,
	147,
	2510);
INSERT INTO V_LEN
	VALUES (2536,
	164,
	14,
	29);
INSERT INTO V_VAL
	VALUES (2537,
	0,
	0,
	23,
	6,
	16,
	0,
	0,
	0,
	0,
	153,
	2510);
INSERT INTO V_TVL
	VALUES (2537,
	2530);
INSERT INTO V_VAL
	VALUES (2528,
	0,
	0,
	23,
	6,
	33,
	0,
	0,
	0,
	0,
	125,
	2510);
INSERT INTO V_BIN
	VALUES (2528,
	2538,
	2537,
	'>=');
INSERT INTO V_VAL
	VALUES (2539,
	0,
	0,
	23,
	21,
	28,
	0,
	0,
	0,
	0,
	1309,
	2510);
INSERT INTO V_IRF
	VALUES (2539,
	2513);
INSERT INTO V_VAL
	VALUES (2538,
	0,
	0,
	23,
	30,
	33,
	0,
	0,
	0,
	0,
	153,
	2510);
INSERT INTO V_AVL
	VALUES (2538,
	2539,
	1542,
	1569);
INSERT INTO V_VAR
	VALUES (2513,
	2510,
	'goalSpec',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2513,
	0,
	1542);
INSERT INTO V_VAR
	VALUES (2529,
	2510,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2529,
	0,
	1681);
INSERT INTO V_VAR
	VALUES (2530,
	2510,
	'elapsedSpan',
	1,
	153);
INSERT INTO V_TRN
	VALUES (2530,
	0,
	'');
INSERT INTO ACT_BLK
	VALUES (2520,
	1,
	0,
	0,
	'',
	'',
	'',
	13,
	3,
	12,
	39,
	0,
	0,
	12,
	54,
	12,
	58,
	0,
	0,
	0,
	2509,
	0);
INSERT INTO ACT_SMT
	VALUES (2540,
	2520,
	2541,
	12,
	3,
	'Goal::evaluateCompletion line: 12');
INSERT INTO ACT_SEL
	VALUES (2540,
	2542,
	1,
	'one',
	2543);
INSERT INTO ACT_SR
	VALUES (2540);
INSERT INTO ACT_LNK
	VALUES (2544,
	'is_currently_executing_within',
	2540,
	1680,
	0,
	2,
	1470,
	12,
	39,
	12,
	54,
	12,
	58);
INSERT INTO ACT_SMT
	VALUES (2541,
	2520,
	0,
	13,
	3,
	'Goal::evaluateCompletion line: 13');
INSERT INTO ACT_AI
	VALUES (2541,
	2545,
	2546,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2543,
	0,
	0,
	12,
	33,
	36,
	0,
	0,
	0,
	0,
	1309,
	2520);
INSERT INTO V_IRF
	VALUES (2543,
	2529);
INSERT INTO V_VAL
	VALUES (2546,
	1,
	0,
	13,
	3,
	13,
	0,
	0,
	0,
	0,
	153,
	2520);
INSERT INTO V_TVL
	VALUES (2546,
	2530);
INSERT INTO V_VAL
	VALUES (2547,
	0,
	0,
	13,
	17,
	23,
	0,
	0,
	0,
	0,
	1309,
	2520);
INSERT INTO V_IRF
	VALUES (2547,
	2542);
INSERT INTO V_VAL
	VALUES (2548,
	0,
	0,
	13,
	25,
	43,
	0,
	0,
	0,
	0,
	153,
	2520);
INSERT INTO V_AVL
	VALUES (2548,
	2547,
	1470,
	1651);
INSERT INTO V_VAL
	VALUES (2545,
	0,
	0,
	13,
	25,
	64,
	0,
	0,
	0,
	0,
	153,
	2520);
INSERT INTO V_BIN
	VALUES (2545,
	2549,
	2548,
	'-');
INSERT INTO V_VAL
	VALUES (2550,
	0,
	0,
	13,
	47,
	50,
	0,
	0,
	0,
	0,
	1309,
	2520);
INSERT INTO V_IRF
	VALUES (2550,
	2529);
INSERT INTO V_VAL
	VALUES (2549,
	0,
	0,
	13,
	52,
	64,
	0,
	0,
	0,
	0,
	153,
	2520);
INSERT INTO V_AVL
	VALUES (2549,
	2550,
	1681,
	2409);
INSERT INTO V_VAR
	VALUES (2542,
	2520,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2542,
	0,
	1470);
INSERT INTO ACT_BLK
	VALUES (2523,
	1,
	0,
	0,
	'',
	'',
	'',
	16,
	3,
	15,
	97,
	0,
	0,
	15,
	110,
	15,
	113,
	0,
	0,
	0,
	2509,
	0);
INSERT INTO ACT_SMT
	VALUES (2551,
	2523,
	2552,
	15,
	3,
	'Goal::evaluateCompletion line: 15');
INSERT INTO ACT_SEL
	VALUES (2551,
	2553,
	1,
	'one',
	2554);
INSERT INTO ACT_SR
	VALUES (2551);
INSERT INTO ACT_LNK
	VALUES (2555,
	'is_currently_executing_within',
	2551,
	1680,
	2556,
	2,
	1470,
	15,
	44,
	15,
	59,
	15,
	63);
INSERT INTO ACT_LNK
	VALUES (2556,
	'is_timed_by',
	0,
	1583,
	0,
	2,
	1488,
	15,
	97,
	15,
	110,
	15,
	113);
INSERT INTO ACT_SMT
	VALUES (2552,
	2523,
	0,
	16,
	3,
	'Goal::evaluateCompletion line: 16');
INSERT INTO ACT_AI
	VALUES (2552,
	2557,
	2558,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2554,
	0,
	0,
	15,
	38,
	41,
	0,
	0,
	0,
	0,
	1309,
	2523);
INSERT INTO V_IRF
	VALUES (2554,
	2529);
INSERT INTO V_VAL
	VALUES (2558,
	1,
	0,
	16,
	3,
	13,
	0,
	0,
	0,
	0,
	153,
	2523);
INSERT INTO V_TVL
	VALUES (2558,
	2530);
INSERT INTO V_VAL
	VALUES (2559,
	0,
	0,
	16,
	17,
	28,
	0,
	0,
	0,
	0,
	1309,
	2523);
INSERT INTO V_IRF
	VALUES (2559,
	2553);
INSERT INTO V_VAL
	VALUES (2560,
	0,
	0,
	16,
	30,
	33,
	0,
	0,
	0,
	0,
	160,
	2523);
INSERT INTO V_AVL
	VALUES (2560,
	2559,
	1488,
	1604);
INSERT INTO V_VAL
	VALUES (2557,
	0,
	0,
	16,
	30,
	54,
	0,
	0,
	0,
	0,
	153,
	2523);
INSERT INTO V_BIN
	VALUES (2557,
	2561,
	2560,
	'-');
INSERT INTO V_VAL
	VALUES (2562,
	0,
	0,
	16,
	37,
	40,
	0,
	0,
	0,
	0,
	1309,
	2523);
INSERT INTO V_IRF
	VALUES (2562,
	2529);
INSERT INTO V_VAL
	VALUES (2561,
	0,
	0,
	16,
	42,
	54,
	0,
	0,
	0,
	0,
	153,
	2523);
INSERT INTO V_AVL
	VALUES (2561,
	2562,
	1681,
	2409);
INSERT INTO V_VAR
	VALUES (2553,
	2523,
	'workoutTimer',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2553,
	0,
	1488);
INSERT INTO ACT_BLK
	VALUES (2526,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	18,
	3,
	18,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2509,
	0);
INSERT INTO ACT_SMT
	VALUES (2563,
	2526,
	0,
	18,
	3,
	'Goal::evaluateCompletion line: 18');
INSERT INTO ACT_BRG
	VALUES (2563,
	1202,
	18,
	8,
	18,
	3);
INSERT INTO V_VAL
	VALUES (2564,
	0,
	0,
	18,
	29,
	77,
	0,
	0,
	0,
	0,
	1199,
	2526);
INSERT INTO V_LST
	VALUES (2564,
	'Goal.evaluateCompletion: Unknown Goal Span Type.');
INSERT INTO V_PAR
	VALUES (2564,
	2563,
	0,
	'message',
	0,
	18,
	20);
INSERT INTO ACT_BLK
	VALUES (2527,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	28,
	3,
	24,
	47,
	0,
	0,
	24,
	59,
	24,
	63,
	0,
	0,
	0,
	2509,
	0);
INSERT INTO ACT_SMT
	VALUES (2565,
	2527,
	2566,
	24,
	3,
	'Goal::evaluateCompletion line: 24');
INSERT INTO ACT_SEL
	VALUES (2565,
	2567,
	1,
	'one',
	2568);
INSERT INTO ACT_SR
	VALUES (2565);
INSERT INTO ACT_LNK
	VALUES (2569,
	'has_open',
	2565,
	1707,
	0,
	2,
	1708,
	24,
	47,
	24,
	59,
	24,
	63);
INSERT INTO ACT_SMT
	VALUES (2566,
	2527,
	2570,
	25,
	3,
	'Goal::evaluateCompletion line: 25');
INSERT INTO ACT_IF
	VALUES (2566,
	2571,
	2572,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2570,
	2527,
	0,
	28,
	3,
	'Goal::evaluateCompletion line: 28');
INSERT INTO E_ESS
	VALUES (2570,
	1,
	0,
	28,
	12,
	28,
	18,
	24,
	47,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (2570);
INSERT INTO E_GSME
	VALUES (2570,
	2573);
INSERT INTO E_GEN
	VALUES (2570,
	2529);
INSERT INTO V_VAL
	VALUES (2568,
	0,
	0,
	24,
	41,
	44,
	0,
	0,
	0,
	0,
	1309,
	2527);
INSERT INTO V_IRF
	VALUES (2568,
	2529);
INSERT INTO V_VAL
	VALUES (2574,
	0,
	0,
	25,
	18,
	32,
	0,
	0,
	0,
	0,
	1309,
	2527);
INSERT INTO V_IRF
	VALUES (2574,
	2567);
INSERT INTO V_VAL
	VALUES (2575,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2527);
INSERT INTO V_UNY
	VALUES (2575,
	2574,
	'empty');
INSERT INTO V_VAL
	VALUES (2572,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2527);
INSERT INTO V_UNY
	VALUES (2572,
	2575,
	'not');
INSERT INTO V_VAR
	VALUES (2567,
	2527,
	'openAchievement',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2567,
	0,
	1708);
INSERT INTO ACT_BLK
	VALUES (2571,
	0,
	0,
	0,
	'',
	'',
	'',
	26,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2509,
	0);
INSERT INTO ACT_SMT
	VALUES (2576,
	2571,
	0,
	26,
	5,
	'Goal::evaluateCompletion line: 26');
INSERT INTO ACT_TFM
	VALUES (2576,
	2577,
	2567,
	26,
	21,
	0,
	0);
INSERT INTO O_TFR
	VALUES (1481,
	1681,
	'nextGoal',
	'',
	1192,
	0,
	'// Advance to the next goal or start the first one if one
//   is currently not exectuing.

//  If there is a goal currently executing, notify it that its execution
//    has completed.
//  Otherwise, create and start a goal for the first goal specification
//    if one exists.
select any session from instances of WorkoutSession;  // WorkoutSession is a singleton.
if ( not empty session )
  select one goal related by session->Goal[R11.''is_currently_executing''];
  if ( not empty goal )
    generate Goal1:Completed to goal;
  else
    GoalSpecConstants::initialize();
    select any gsc from instances of GoalSpecConstants;
    Goal::initialize( sequenceNumber: gsc.GoalSpecOrigin );
  end if;
end if;',
	1,
	'',
	2508,
	0);
INSERT INTO ACT_OPB
	VALUES (2578,
	1481);
INSERT INTO ACT_ACT
	VALUES (2578,
	'class operation',
	0,
	2579,
	0,
	0,
	'Goal::nextGoal',
	0);
INSERT INTO ACT_BLK
	VALUES (2579,
	1,
	0,
	0,
	'',
	'',
	'',
	9,
	1,
	8,
	38,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2578,
	0);
INSERT INTO ACT_SMT
	VALUES (2580,
	2579,
	2581,
	8,
	1,
	'Goal::nextGoal line: 8');
INSERT INTO ACT_FIO
	VALUES (2580,
	2582,
	1,
	'any',
	1470,
	8,
	38);
INSERT INTO ACT_SMT
	VALUES (2581,
	2579,
	0,
	9,
	1,
	'Goal::nextGoal line: 9');
INSERT INTO ACT_IF
	VALUES (2581,
	2583,
	2584,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2585,
	0,
	0,
	9,
	16,
	22,
	0,
	0,
	0,
	0,
	1309,
	2579);
INSERT INTO V_IRF
	VALUES (2585,
	2582);
INSERT INTO V_VAL
	VALUES (2586,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2579);
INSERT INTO V_UNY
	VALUES (2586,
	2585,
	'empty');
INSERT INTO V_VAL
	VALUES (2584,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2579);
INSERT INTO V_UNY
	VALUES (2584,
	2586,
	'not');
INSERT INTO V_VAR
	VALUES (2582,
	2579,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2582,
	0,
	1470);
INSERT INTO ACT_BLK
	VALUES (2583,
	1,
	0,
	0,
	'',
	'',
	'',
	13,
	3,
	10,
	39,
	0,
	0,
	10,
	44,
	10,
	48,
	0,
	0,
	0,
	2578,
	0);
INSERT INTO ACT_SMT
	VALUES (2587,
	2583,
	2588,
	10,
	3,
	'Goal::nextGoal line: 10');
INSERT INTO ACT_SEL
	VALUES (2587,
	2589,
	1,
	'one',
	2590);
INSERT INTO ACT_SR
	VALUES (2587);
INSERT INTO ACT_LNK
	VALUES (2591,
	'is_currently_executing',
	2587,
	1680,
	0,
	2,
	1681,
	10,
	39,
	10,
	44,
	10,
	48);
INSERT INTO ACT_SMT
	VALUES (2588,
	2583,
	0,
	11,
	3,
	'Goal::nextGoal line: 11');
INSERT INTO ACT_IF
	VALUES (2588,
	2592,
	2593,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2594,
	2583,
	0,
	13,
	3,
	'Goal::nextGoal line: 13');
INSERT INTO ACT_E
	VALUES (2594,
	2595,
	2588);
INSERT INTO V_VAL
	VALUES (2590,
	0,
	0,
	10,
	30,
	36,
	0,
	0,
	0,
	0,
	1309,
	2583);
INSERT INTO V_IRF
	VALUES (2590,
	2582);
INSERT INTO V_VAL
	VALUES (2596,
	0,
	0,
	11,
	18,
	21,
	0,
	0,
	0,
	0,
	1309,
	2583);
INSERT INTO V_IRF
	VALUES (2596,
	2589);
INSERT INTO V_VAL
	VALUES (2597,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2583);
INSERT INTO V_UNY
	VALUES (2597,
	2596,
	'empty');
INSERT INTO V_VAL
	VALUES (2593,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2583);
INSERT INTO V_UNY
	VALUES (2593,
	2597,
	'not');
INSERT INTO V_VAR
	VALUES (2589,
	2583,
	'goal',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2589,
	0,
	1681);
INSERT INTO ACT_BLK
	VALUES (2592,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	12,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2578,
	0);
INSERT INTO ACT_SMT
	VALUES (2598,
	2592,
	0,
	12,
	5,
	'Goal::nextGoal line: 12');
INSERT INTO E_ESS
	VALUES (2598,
	1,
	0,
	12,
	14,
	12,
	20,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (2598);
INSERT INTO E_GSME
	VALUES (2598,
	2573);
INSERT INTO E_GEN
	VALUES (2598,
	2589);
INSERT INTO ACT_BLK
	VALUES (2595,
	1,
	0,
	0,
	'Goal',
	'',
	'',
	16,
	5,
	16,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2578,
	0);
INSERT INTO ACT_SMT
	VALUES (2599,
	2595,
	2600,
	14,
	5,
	'Goal::nextGoal line: 14');
INSERT INTO ACT_TFM
	VALUES (2599,
	2601,
	0,
	14,
	24,
	14,
	5);
INSERT INTO ACT_SMT
	VALUES (2600,
	2595,
	2602,
	15,
	5,
	'Goal::nextGoal line: 15');
INSERT INTO ACT_FIO
	VALUES (2600,
	2603,
	1,
	'any',
	2604,
	15,
	38);
INSERT INTO ACT_SMT
	VALUES (2602,
	2595,
	0,
	16,
	5,
	'Goal::nextGoal line: 16');
INSERT INTO ACT_TFM
	VALUES (2602,
	2319,
	0,
	16,
	11,
	16,
	5);
INSERT INTO V_VAL
	VALUES (2605,
	0,
	0,
	16,
	39,
	41,
	0,
	0,
	0,
	0,
	1309,
	2595);
INSERT INTO V_IRF
	VALUES (2605,
	2603);
INSERT INTO V_VAL
	VALUES (2606,
	0,
	0,
	16,
	43,
	56,
	0,
	0,
	0,
	0,
	160,
	2595);
INSERT INTO V_AVL
	VALUES (2606,
	2605,
	2604,
	2607);
INSERT INTO V_PAR
	VALUES (2606,
	2602,
	0,
	'sequenceNumber',
	0,
	16,
	23);
INSERT INTO V_VAR
	VALUES (2603,
	2595,
	'gsc',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2603,
	0,
	2604);
INSERT INTO O_NBATTR
	VALUES (2371,
	1681);
INSERT INTO O_BATTR
	VALUES (2371,
	1681);
INSERT INTO O_ATTR
	VALUES (2371,
	1681,
	2409,
	'disposition',
	'The disposition of this goal.  See data type descriptions for details.
This attribute represents the logical or semantic disposition of the goal.
For example, a disposition indicating the need to increase the value in question
for a heart-rate goal means that activity should be increased to drive up the 
heart rate.  Since pace is the inverse of speed, a disposition indicating 
the need to increase the value in question (pace) means that the user must
increase speed, causing a lower (faster) pace number.',
	'',
	'disposition',
	0,
	2370,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (2409,
	1681);
INSERT INTO O_BATTR
	VALUES (2409,
	1681);
INSERT INTO O_ATTR
	VALUES (2409,
	1681,
	2363,
	'startingPoint',
	'Captures the starting point of the span for this particular goal so 
that the end of the goal execution period can be determined.  In other
words, using the value of this attribute together with the span specified
by the associated goal specification, the goal knows when it is finished.

For distance-based goals, it is expressed as the accumulated distance
in meters for the associated workout session at the time this goal
execution commenced.

For time-based goals, it is expressed as the elapsed time in seconds
for the associated workout session at the time this goal execution
commenced.',
	'',
	'startingPoint',
	0,
	153,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (2363,
	1681);
INSERT INTO O_BATTR
	VALUES (2363,
	1681);
INSERT INTO O_ATTR
	VALUES (2363,
	1681,
	2608,
	'ID',
	'An arbitrary identifier.',
	'',
	'ID',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (2609,
	1681);
INSERT INTO O_BATTR
	VALUES (2609,
	1681);
INSERT INTO O_ATTR
	VALUES (2609,
	1681,
	2374,
	'current_state',
	'',
	'',
	'current_state',
	0,
	1307,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (2374,
	1681);
INSERT INTO O_BATTR
	VALUES (2374,
	1681);
INSERT INTO O_ATTR
	VALUES (2374,
	1681,
	2371,
	'evaluationTimer',
	'Handle for the timer used for periodic evaluation of goal achievement.',
	'',
	'evaluationTimer',
	0,
	1272,
	'',
	'');
INSERT INTO O_REF
	VALUES (1681,
	1470,
	0,
	1649,
	1689,
	2610,
	2611,
	2612,
	2613,
	0,
	0,
	'',
	'WorkoutSession',
	'startTime',
	'R13.''was_executed_within''');
INSERT INTO O_REF
	VALUES (1681,
	1542,
	0,
	2314,
	2341,
	2614,
	2615,
	2612,
	2616,
	2613,
	0,
	'',
	'GoalSpec',
	'session_startTime',
	'R9.''specified_by''');
INSERT INTO O_REF
	VALUES (1681,
	1470,
	0,
	1649,
	1680,
	2617,
	2618,
	2612,
	2619,
	2616,
	0,
	'',
	'WorkoutSession',
	'startTime',
	'R11.''is_currently_executing_within''');
INSERT INTO O_RATTR
	VALUES (2612,
	1681,
	1649,
	1470,
	1,
	'startTime');
INSERT INTO O_ATTR
	VALUES (2612,
	1681,
	0,
	'session_startTime',
	'



',
	'session_',
	'startTime',
	1,
	1308,
	'',
	'');
INSERT INTO O_REF
	VALUES (1681,
	1542,
	0,
	1563,
	2341,
	2614,
	2615,
	2608,
	2620,
	0,
	0,
	'',
	'GoalSpec',
	'sequenceNumber',
	'R9.''specified_by''');
INSERT INTO O_RATTR
	VALUES (2608,
	1681,
	1563,
	1542,
	1,
	'sequenceNumber');
INSERT INTO O_ATTR
	VALUES (2608,
	1681,
	2612,
	'spec_sequenceNumber',
	'',
	'spec_',
	'sequenceNumber',
	1,
	1308,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	1681);
INSERT INTO O_OIDA
	VALUES (2612,
	1681,
	0,
	'session_startTime');
INSERT INTO O_OIDA
	VALUES (2363,
	1681,
	0,
	'ID');
INSERT INTO O_OIDA
	VALUES (2608,
	1681,
	0,
	'spec_sequenceNumber');
INSERT INTO O_ID
	VALUES (1,
	1681);
INSERT INTO O_ID
	VALUES (2,
	1681);
INSERT INTO SM_ISM
	VALUES (2621,
	1681);
INSERT INTO SM_SM
	VALUES (2621,
	'',
	0);
INSERT INTO SM_MOORE
	VALUES (2621);
INSERT INTO SM_LEVT
	VALUES (2573,
	2621,
	0);
INSERT INTO SM_SEVT
	VALUES (2573,
	2621,
	0);
INSERT INTO SM_EVT
	VALUES (2573,
	2621,
	0,
	1,
	'Completed',
	0,
	'',
	'Goal1',
	'Indicates that execution of this goal has been completed.  ');
INSERT INTO SM_LEVT
	VALUES (1969,
	2621,
	0);
INSERT INTO SM_SEVT
	VALUES (1969,
	2621,
	0);
INSERT INTO SM_EVT
	VALUES (1969,
	2621,
	0,
	2,
	'Evaluate',
	0,
	'',
	'Goal2',
	'Indicates that this goal should be evaluated for completeness and achievement.');
INSERT INTO SM_LEVT
	VALUES (1993,
	2621,
	0);
INSERT INTO SM_SEVT
	VALUES (1993,
	2621,
	0);
INSERT INTO SM_EVT
	VALUES (1993,
	2621,
	0,
	3,
	'Pause',
	0,
	'',
	'Goal3',
	'');
INSERT INTO SM_LEVT
	VALUES (2622,
	2621,
	0);
INSERT INTO SM_SEVT
	VALUES (2622,
	2621,
	0);
INSERT INTO SM_EVT
	VALUES (2622,
	2621,
	0,
	4,
	'evaluationComplete',
	0,
	'',
	'Goal4',
	'');
INSERT INTO SM_STATE
	VALUES (2623,
	2621,
	0,
	'Executing',
	1,
	0);
INSERT INTO SM_SEME
	VALUES (2623,
	2573,
	2621,
	0);
INSERT INTO SM_SEME
	VALUES (2623,
	1969,
	2621,
	0);
INSERT INTO SM_SEME
	VALUES (2623,
	1993,
	2621,
	0);
INSERT INTO SM_CH
	VALUES (2623,
	2622,
	2621,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2623,
	2622,
	2621,
	0);
INSERT INTO SM_MOAH
	VALUES (2624,
	2621,
	2623);
INSERT INTO SM_AH
	VALUES (2624,
	2621);
INSERT INTO SM_ACT
	VALUES (2624,
	2621,
	1,
	'// Determine whether this goal is currently being achieved.
disposition = self.evaluateAchievement();

// Update achievement records if necessary.  There are four cases:
//   0. Still not achieving this goal. 
//   1. Just started achieving this goal.
//   2. Just stopped achieving this goal.
//   3. Still achieving this goal.
// For cases 0 and 3, there is nothing to be done for achievement records.
// Case 1 requires the creation of a new achievment record, storing the start time.
// Case 2 requires the storing of the end time for the open achievement record.
if ( (self.disposition != GoalDisposition::Achieving) and (disposition == GoalDisposition::Achieving) )
  // Case 1, create achievement record, store start time, relate it as open record.
  select one workoutTimer related by self->WorkoutSession[R11.''is_currently_executing_within'']->WorkoutTimer[R8.''is_timed_by''];
  create object instance achievement of Achievement; achievement.startTime = workoutTimer.time;
  relate self to achievement across R14.''has_open'';
elif ( (self.disposition == GoalDisposition::Achieving) and (disposition != GoalDisposition::Achieving) )
  // Case 2, store end time, relate as recorded record, unrelate as open record.
  select one achievement related by self->Achievement[R14.''has_open''];
  achievement.close();
end if;

// Update disposition of this goal.
self.disposition = disposition;

// Determine whether execution of this goal is complete, 
//  and if so, advance to the next one if it exists.
self.evaluateCompletion();',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (2625,
	2621,
	2624);
INSERT INTO ACT_ACT
	VALUES (2625,
	'state',
	0,
	2626,
	0,
	0,
	'Goal::Executing',
	0);
INSERT INTO ACT_BLK
	VALUES (2626,
	0,
	0,
	0,
	'',
	'',
	'',
	28,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	17,
	77,
	0,
	2625,
	0);
INSERT INTO ACT_SMT
	VALUES (2627,
	2626,
	2628,
	2,
	1,
	'Goal::Executing line: 2');
INSERT INTO ACT_AI
	VALUES (2627,
	2629,
	2630,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2628,
	2626,
	2631,
	12,
	1,
	'Goal::Executing line: 12');
INSERT INTO ACT_IF
	VALUES (2628,
	2632,
	2633,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2634,
	2626,
	0,
	17,
	1,
	'Goal::Executing line: 17');
INSERT INTO ACT_EL
	VALUES (2634,
	2635,
	2636,
	2628);
INSERT INTO ACT_SMT
	VALUES (2631,
	2626,
	2637,
	24,
	1,
	'Goal::Executing line: 24');
INSERT INTO ACT_AI
	VALUES (2631,
	2638,
	2639,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2637,
	2626,
	0,
	28,
	1,
	'Goal::Executing line: 28');
INSERT INTO ACT_TFM
	VALUES (2637,
	2508,
	2640,
	28,
	6,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2630,
	1,
	1,
	2,
	1,
	11,
	0,
	0,
	0,
	0,
	2370,
	2626);
INSERT INTO V_TVL
	VALUES (2630,
	2641);
INSERT INTO V_VAL
	VALUES (2629,
	0,
	0,
	2,
	20,
	-1,
	0,
	0,
	0,
	0,
	2370,
	2626);
INSERT INTO V_TRV
	VALUES (2629,
	2422,
	2640,
	1,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2642,
	0,
	0,
	12,
	7,
	10,
	0,
	0,
	0,
	0,
	1309,
	2626);
INSERT INTO V_IRF
	VALUES (2642,
	2640);
INSERT INTO V_VAL
	VALUES (2643,
	0,
	0,
	12,
	12,
	22,
	0,
	0,
	0,
	0,
	2370,
	2626);
INSERT INTO V_AVL
	VALUES (2643,
	2642,
	1681,
	2371);
INSERT INTO V_VAL
	VALUES (2644,
	0,
	0,
	12,
	12,
	52,
	0,
	0,
	0,
	0,
	125,
	2626);
INSERT INTO V_BIN
	VALUES (2644,
	2645,
	2643,
	'!=');
INSERT INTO V_VAL
	VALUES (2645,
	0,
	0,
	12,
	44,
	52,
	0,
	0,
	0,
	0,
	2370,
	2626);
INSERT INTO V_LEN
	VALUES (2645,
	2467,
	12,
	27);
INSERT INTO V_VAL
	VALUES (2646,
	0,
	0,
	12,
	60,
	70,
	0,
	0,
	0,
	0,
	2370,
	2626);
INSERT INTO V_TVL
	VALUES (2646,
	2641);
INSERT INTO V_VAL
	VALUES (2647,
	0,
	0,
	12,
	60,
	100,
	0,
	0,
	0,
	0,
	125,
	2626);
INSERT INTO V_BIN
	VALUES (2647,
	2648,
	2646,
	'==');
INSERT INTO V_VAL
	VALUES (2648,
	0,
	0,
	12,
	92,
	100,
	0,
	0,
	0,
	0,
	2370,
	2626);
INSERT INTO V_LEN
	VALUES (2648,
	2467,
	12,
	75);
INSERT INTO V_VAL
	VALUES (2633,
	0,
	0,
	12,
	12,
	100,
	0,
	0,
	0,
	0,
	125,
	2626);
INSERT INTO V_BIN
	VALUES (2633,
	2647,
	2644,
	'and');
INSERT INTO V_VAL
	VALUES (2649,
	0,
	0,
	17,
	9,
	12,
	0,
	0,
	0,
	0,
	1309,
	2626);
INSERT INTO V_IRF
	VALUES (2649,
	2640);
INSERT INTO V_VAL
	VALUES (2650,
	0,
	0,
	17,
	14,
	24,
	0,
	0,
	0,
	0,
	2370,
	2626);
INSERT INTO V_AVL
	VALUES (2650,
	2649,
	1681,
	2371);
INSERT INTO V_VAL
	VALUES (2651,
	0,
	0,
	17,
	14,
	54,
	0,
	0,
	0,
	0,
	125,
	2626);
INSERT INTO V_BIN
	VALUES (2651,
	2652,
	2650,
	'==');
INSERT INTO V_VAL
	VALUES (2652,
	0,
	0,
	17,
	46,
	54,
	0,
	0,
	0,
	0,
	2370,
	2626);
INSERT INTO V_LEN
	VALUES (2652,
	2467,
	17,
	29);
INSERT INTO V_VAL
	VALUES (2653,
	0,
	0,
	17,
	62,
	72,
	0,
	0,
	0,
	0,
	2370,
	2626);
INSERT INTO V_TVL
	VALUES (2653,
	2641);
INSERT INTO V_VAL
	VALUES (2654,
	0,
	0,
	17,
	62,
	102,
	0,
	0,
	0,
	0,
	125,
	2626);
INSERT INTO V_BIN
	VALUES (2654,
	2655,
	2653,
	'!=');
INSERT INTO V_VAL
	VALUES (2655,
	0,
	0,
	17,
	94,
	102,
	0,
	0,
	0,
	0,
	2370,
	2626);
INSERT INTO V_LEN
	VALUES (2655,
	2467,
	17,
	77);
INSERT INTO V_VAL
	VALUES (2636,
	0,
	0,
	17,
	14,
	102,
	0,
	0,
	0,
	0,
	125,
	2626);
INSERT INTO V_BIN
	VALUES (2636,
	2654,
	2651,
	'and');
INSERT INTO V_VAL
	VALUES (2656,
	1,
	0,
	24,
	1,
	4,
	0,
	0,
	0,
	0,
	1309,
	2626);
INSERT INTO V_IRF
	VALUES (2656,
	2640);
INSERT INTO V_VAL
	VALUES (2639,
	1,
	0,
	24,
	6,
	16,
	0,
	0,
	0,
	0,
	2370,
	2626);
INSERT INTO V_AVL
	VALUES (2639,
	2656,
	1681,
	2371);
INSERT INTO V_VAL
	VALUES (2638,
	0,
	0,
	24,
	20,
	30,
	0,
	0,
	0,
	0,
	2370,
	2626);
INSERT INTO V_TVL
	VALUES (2638,
	2641);
INSERT INTO V_VAR
	VALUES (2641,
	2626,
	'disposition',
	1,
	2370);
INSERT INTO V_TRN
	VALUES (2641,
	0,
	'');
INSERT INTO V_VAR
	VALUES (2640,
	2626,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2640,
	0,
	1681);
INSERT INTO ACT_BLK
	VALUES (2632,
	1,
	0,
	0,
	'has_open',
	'',
	'',
	16,
	3,
	15,
	41,
	0,
	0,
	16,
	37,
	16,
	41,
	0,
	0,
	0,
	2625,
	0);
INSERT INTO ACT_SMT
	VALUES (2657,
	2632,
	2658,
	14,
	3,
	'Goal::Executing line: 14');
INSERT INTO ACT_SEL
	VALUES (2657,
	2659,
	1,
	'one',
	2660);
INSERT INTO ACT_SR
	VALUES (2657);
INSERT INTO ACT_LNK
	VALUES (2661,
	'is_currently_executing_within',
	2657,
	1680,
	2662,
	2,
	1470,
	14,
	44,
	14,
	59,
	14,
	63);
INSERT INTO ACT_LNK
	VALUES (2662,
	'is_timed_by',
	0,
	1583,
	0,
	2,
	1488,
	14,
	97,
	14,
	110,
	14,
	113);
INSERT INTO ACT_SMT
	VALUES (2658,
	2632,
	2663,
	15,
	3,
	'Goal::Executing line: 15');
INSERT INTO ACT_CR
	VALUES (2658,
	2664,
	1,
	1708,
	15,
	41);
INSERT INTO ACT_SMT
	VALUES (2663,
	2632,
	2665,
	15,
	54,
	'Goal::Executing line: 15');
INSERT INTO ACT_AI
	VALUES (2663,
	2666,
	2667,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2665,
	2632,
	0,
	16,
	3,
	'Goal::Executing line: 16');
INSERT INTO ACT_REL
	VALUES (2665,
	2640,
	2664,
	'has_open',
	1707,
	16,
	37,
	16,
	41);
INSERT INTO V_VAL
	VALUES (2660,
	0,
	0,
	14,
	38,
	41,
	0,
	0,
	0,
	0,
	1309,
	2632);
INSERT INTO V_IRF
	VALUES (2660,
	2640);
INSERT INTO V_VAL
	VALUES (2668,
	1,
	0,
	15,
	54,
	64,
	0,
	0,
	0,
	0,
	1309,
	2632);
INSERT INTO V_IRF
	VALUES (2668,
	2664);
INSERT INTO V_VAL
	VALUES (2667,
	1,
	0,
	15,
	66,
	74,
	0,
	0,
	0,
	0,
	160,
	2632);
INSERT INTO V_AVL
	VALUES (2667,
	2668,
	1708,
	2669);
INSERT INTO V_VAL
	VALUES (2670,
	0,
	0,
	15,
	78,
	89,
	0,
	0,
	0,
	0,
	1309,
	2632);
INSERT INTO V_IRF
	VALUES (2670,
	2659);
INSERT INTO V_VAL
	VALUES (2666,
	0,
	0,
	15,
	91,
	94,
	0,
	0,
	0,
	0,
	160,
	2632);
INSERT INTO V_AVL
	VALUES (2666,
	2670,
	1488,
	1604);
INSERT INTO V_VAR
	VALUES (2659,
	2632,
	'workoutTimer',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2659,
	0,
	1488);
INSERT INTO V_VAR
	VALUES (2664,
	2632,
	'achievement',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2664,
	0,
	1708);
INSERT INTO ACT_BLK
	VALUES (2635,
	1,
	0,
	0,
	'',
	'',
	'',
	20,
	3,
	19,
	43,
	0,
	0,
	19,
	55,
	19,
	59,
	0,
	0,
	0,
	2625,
	0);
INSERT INTO ACT_SMT
	VALUES (2671,
	2635,
	2672,
	19,
	3,
	'Goal::Executing line: 19');
INSERT INTO ACT_SEL
	VALUES (2671,
	2673,
	1,
	'one',
	2674);
INSERT INTO ACT_SR
	VALUES (2671);
INSERT INTO ACT_LNK
	VALUES (2675,
	'has_open',
	2671,
	1707,
	0,
	2,
	1708,
	19,
	43,
	19,
	55,
	19,
	59);
INSERT INTO ACT_SMT
	VALUES (2672,
	2635,
	0,
	20,
	3,
	'Goal::Executing line: 20');
INSERT INTO ACT_TFM
	VALUES (2672,
	2577,
	2673,
	20,
	15,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2674,
	0,
	0,
	19,
	37,
	40,
	0,
	0,
	0,
	0,
	1309,
	2635);
INSERT INTO V_IRF
	VALUES (2674,
	2640);
INSERT INTO V_VAR
	VALUES (2673,
	2635,
	'achievement',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2673,
	0,
	1708);
INSERT INTO SM_STATE
	VALUES (2676,
	2621,
	0,
	'Completed',
	2,
	0);
INSERT INTO SM_EIGN
	VALUES (2676,
	2573,
	2621,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2676,
	2573,
	2621,
	0);
INSERT INTO SM_EIGN
	VALUES (2676,
	1969,
	2621,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2676,
	1969,
	2621,
	0);
INSERT INTO SM_CH
	VALUES (2676,
	1993,
	2621,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2676,
	1993,
	2621,
	0);
INSERT INTO SM_CH
	VALUES (2676,
	2622,
	2621,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2676,
	2622,
	2621,
	0);
INSERT INTO SM_MOAH
	VALUES (2677,
	2621,
	2676);
INSERT INTO SM_AH
	VALUES (2677,
	2621);
INSERT INTO SM_ACT
	VALUES (2677,
	2621,
	1,
	'// Stop executing this goal and begin executing the next one, if there is one.

// Stop the goal-evaluation timer, ignoring the return code which indicates 
//   whether a timer event was in flight when the timer was cancelled.
cancelSucceeded = TIM::timer_cancel( timer_inst_ref: self.evaluationTimer );

// If this goal has an open achievement record, close it.
select one openAchievement related by self->Achievement[R14.''has_open''];
if ( not empty openAchievement )
  openAchievement.close();
end if;

// Add this goal to the collection of those that have already executed.
select one session related by self->WorkoutSession[R11.''is_currently_executing_within''];
relate self to session across R13.''was_executed_within'';

// Remove this goal from the collection of currently executing ones.
unrelate self from session across R11.''is_currently_executing_within'';

// Find the next goal specification in the sequence and start executing it, if it exists.
select one currentGoalSpec related by self->GoalSpec[R9.''specified_by''];

select any nextGoalSpec related by session->GoalSpec[R10.''includes''] where ( selected.sequenceNumber == (currentGoalSpec.sequenceNumber + 1) );
  
if ( not empty nextGoalSpec )
  Goal::initialize( sequenceNumber: nextGoalSpec.sequenceNumber );
end if;
',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (2678,
	2621,
	2677);
INSERT INTO ACT_ACT
	VALUES (2678,
	'state',
	0,
	2679,
	0,
	0,
	'Goal::Completed',
	0);
INSERT INTO ACT_BLK
	VALUES (2679,
	1,
	0,
	1,
	'',
	'',
	'',
	25,
	1,
	23,
	45,
	0,
	0,
	23,
	54,
	23,
	58,
	0,
	0,
	0,
	2678,
	0);
INSERT INTO ACT_SMT
	VALUES (2680,
	2679,
	2681,
	5,
	1,
	'Goal::Completed line: 5');
INSERT INTO ACT_AI
	VALUES (2680,
	2682,
	2683,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2681,
	2679,
	2684,
	8,
	1,
	'Goal::Completed line: 8');
INSERT INTO ACT_SEL
	VALUES (2681,
	2685,
	1,
	'one',
	2686);
INSERT INTO ACT_SR
	VALUES (2681);
INSERT INTO ACT_LNK
	VALUES (2687,
	'has_open',
	2681,
	1707,
	0,
	2,
	1708,
	8,
	45,
	8,
	57,
	8,
	61);
INSERT INTO ACT_SMT
	VALUES (2684,
	2679,
	2688,
	9,
	1,
	'Goal::Completed line: 9');
INSERT INTO ACT_IF
	VALUES (2684,
	2689,
	2690,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2688,
	2679,
	2691,
	14,
	1,
	'Goal::Completed line: 14');
INSERT INTO ACT_SEL
	VALUES (2688,
	2692,
	1,
	'one',
	2693);
INSERT INTO ACT_SR
	VALUES (2688);
INSERT INTO ACT_LNK
	VALUES (2694,
	'is_currently_executing_within',
	2688,
	1680,
	0,
	2,
	1470,
	14,
	37,
	14,
	52,
	14,
	56);
INSERT INTO ACT_SMT
	VALUES (2691,
	2679,
	2695,
	15,
	1,
	'Goal::Completed line: 15');
INSERT INTO ACT_REL
	VALUES (2691,
	2696,
	2692,
	'was_executed_within',
	1689,
	15,
	31,
	15,
	35);
INSERT INTO ACT_SMT
	VALUES (2695,
	2679,
	2697,
	18,
	1,
	'Goal::Completed line: 18');
INSERT INTO ACT_UNR
	VALUES (2695,
	2696,
	2692,
	'is_currently_executing_within',
	1680,
	18,
	35,
	18,
	39);
INSERT INTO ACT_SMT
	VALUES (2697,
	2679,
	2698,
	21,
	1,
	'Goal::Completed line: 21');
INSERT INTO ACT_SEL
	VALUES (2697,
	2699,
	1,
	'one',
	2700);
INSERT INTO ACT_SR
	VALUES (2697);
INSERT INTO ACT_LNK
	VALUES (2701,
	'specified_by',
	2697,
	2341,
	0,
	2,
	1542,
	21,
	45,
	21,
	54,
	21,
	57);
INSERT INTO ACT_SMT
	VALUES (2698,
	2679,
	2702,
	23,
	1,
	'Goal::Completed line: 23');
INSERT INTO ACT_SEL
	VALUES (2698,
	2703,
	1,
	'any',
	2704);
INSERT INTO ACT_SRW
	VALUES (2698,
	2705);
INSERT INTO ACT_LNK
	VALUES (2706,
	'includes',
	2698,
	1561,
	0,
	3,
	1542,
	23,
	45,
	23,
	54,
	23,
	58);
INSERT INTO ACT_SMT
	VALUES (2702,
	2679,
	0,
	25,
	1,
	'Goal::Completed line: 25');
INSERT INTO ACT_IF
	VALUES (2702,
	2707,
	2708,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2683,
	1,
	1,
	5,
	1,
	15,
	0,
	0,
	0,
	0,
	125,
	2679);
INSERT INTO V_TVL
	VALUES (2683,
	2709);
INSERT INTO V_VAL
	VALUES (2682,
	0,
	0,
	5,
	24,
	-1,
	5,
	38,
	0,
	0,
	125,
	2679);
INSERT INTO V_BRV
	VALUES (2682,
	1297,
	1,
	5,
	19);
INSERT INTO V_VAL
	VALUES (2710,
	0,
	0,
	5,
	54,
	57,
	0,
	0,
	0,
	0,
	1309,
	2679);
INSERT INTO V_IRF
	VALUES (2710,
	2696);
INSERT INTO V_VAL
	VALUES (2711,
	0,
	0,
	5,
	59,
	73,
	0,
	0,
	0,
	0,
	1272,
	2679);
INSERT INTO V_AVL
	VALUES (2711,
	2710,
	1681,
	2374);
INSERT INTO V_PAR
	VALUES (2711,
	0,
	2682,
	'timer_inst_ref',
	0,
	5,
	38);
INSERT INTO V_VAL
	VALUES (2686,
	0,
	0,
	8,
	39,
	42,
	0,
	0,
	0,
	0,
	1309,
	2679);
INSERT INTO V_IRF
	VALUES (2686,
	2696);
INSERT INTO V_VAL
	VALUES (2712,
	0,
	0,
	9,
	16,
	30,
	0,
	0,
	0,
	0,
	1309,
	2679);
INSERT INTO V_IRF
	VALUES (2712,
	2685);
INSERT INTO V_VAL
	VALUES (2713,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2679);
INSERT INTO V_UNY
	VALUES (2713,
	2712,
	'empty');
INSERT INTO V_VAL
	VALUES (2690,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2679);
INSERT INTO V_UNY
	VALUES (2690,
	2713,
	'not');
INSERT INTO V_VAL
	VALUES (2693,
	0,
	0,
	14,
	31,
	34,
	0,
	0,
	0,
	0,
	1309,
	2679);
INSERT INTO V_IRF
	VALUES (2693,
	2696);
INSERT INTO V_VAL
	VALUES (2700,
	0,
	0,
	21,
	39,
	42,
	0,
	0,
	0,
	0,
	1309,
	2679);
INSERT INTO V_IRF
	VALUES (2700,
	2696);
INSERT INTO V_VAL
	VALUES (2704,
	0,
	0,
	23,
	36,
	42,
	0,
	0,
	0,
	0,
	1309,
	2679);
INSERT INTO V_IRF
	VALUES (2704,
	2692);
INSERT INTO V_VAL
	VALUES (2714,
	0,
	0,
	23,
	78,
	-1,
	0,
	0,
	0,
	0,
	1309,
	2679);
INSERT INTO V_SLR
	VALUES (2714,
	0,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2715,
	0,
	0,
	23,
	87,
	100,
	0,
	0,
	0,
	0,
	160,
	2679);
INSERT INTO V_AVL
	VALUES (2715,
	2714,
	1542,
	1563);
INSERT INTO V_VAL
	VALUES (2705,
	0,
	0,
	23,
	87,
	139,
	0,
	0,
	0,
	0,
	125,
	2679);
INSERT INTO V_BIN
	VALUES (2705,
	2716,
	2715,
	'==');
INSERT INTO V_VAL
	VALUES (2717,
	0,
	0,
	23,
	106,
	120,
	0,
	0,
	0,
	0,
	1309,
	2679);
INSERT INTO V_IRF
	VALUES (2717,
	2699);
INSERT INTO V_VAL
	VALUES (2718,
	0,
	0,
	23,
	122,
	135,
	0,
	0,
	0,
	0,
	160,
	2679);
INSERT INTO V_AVL
	VALUES (2718,
	2717,
	1542,
	1563);
INSERT INTO V_VAL
	VALUES (2716,
	0,
	0,
	23,
	122,
	139,
	0,
	0,
	0,
	0,
	160,
	2679);
INSERT INTO V_BIN
	VALUES (2716,
	2719,
	2718,
	'+');
INSERT INTO V_VAL
	VALUES (2719,
	0,
	0,
	23,
	139,
	139,
	0,
	0,
	0,
	0,
	160,
	2679);
INSERT INTO V_LIN
	VALUES (2719,
	'1');
INSERT INTO V_VAL
	VALUES (2720,
	0,
	0,
	25,
	16,
	27,
	0,
	0,
	0,
	0,
	1309,
	2679);
INSERT INTO V_IRF
	VALUES (2720,
	2703);
INSERT INTO V_VAL
	VALUES (2721,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2679);
INSERT INTO V_UNY
	VALUES (2721,
	2720,
	'empty');
INSERT INTO V_VAL
	VALUES (2708,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2679);
INSERT INTO V_UNY
	VALUES (2708,
	2721,
	'not');
INSERT INTO V_VAR
	VALUES (2709,
	2679,
	'cancelSucceeded',
	1,
	125);
INSERT INTO V_TRN
	VALUES (2709,
	0,
	'');
INSERT INTO V_VAR
	VALUES (2696,
	2679,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2696,
	0,
	1681);
INSERT INTO V_VAR
	VALUES (2685,
	2679,
	'openAchievement',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2685,
	0,
	1708);
INSERT INTO V_VAR
	VALUES (2692,
	2679,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2692,
	0,
	1470);
INSERT INTO V_VAR
	VALUES (2699,
	2679,
	'currentGoalSpec',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2699,
	0,
	1542);
INSERT INTO V_VAR
	VALUES (2703,
	2679,
	'nextGoalSpec',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2703,
	0,
	1542);
INSERT INTO ACT_BLK
	VALUES (2689,
	0,
	0,
	0,
	'',
	'',
	'',
	10,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2678,
	0);
INSERT INTO ACT_SMT
	VALUES (2722,
	2689,
	0,
	10,
	3,
	'Goal::Completed line: 10');
INSERT INTO ACT_TFM
	VALUES (2722,
	2577,
	2685,
	10,
	19,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (2707,
	0,
	0,
	0,
	'Goal',
	'',
	'',
	26,
	3,
	26,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2678,
	0);
INSERT INTO ACT_SMT
	VALUES (2723,
	2707,
	0,
	26,
	3,
	'Goal::Completed line: 26');
INSERT INTO ACT_TFM
	VALUES (2723,
	2319,
	0,
	26,
	9,
	26,
	3);
INSERT INTO V_VAL
	VALUES (2724,
	0,
	0,
	26,
	37,
	48,
	0,
	0,
	0,
	0,
	1309,
	2707);
INSERT INTO V_IRF
	VALUES (2724,
	2703);
INSERT INTO V_VAL
	VALUES (2725,
	0,
	0,
	26,
	50,
	63,
	0,
	0,
	0,
	0,
	160,
	2707);
INSERT INTO V_AVL
	VALUES (2725,
	2724,
	1542,
	1563);
INSERT INTO V_PAR
	VALUES (2725,
	2723,
	0,
	'sequenceNumber',
	0,
	26,
	21);
INSERT INTO SM_STATE
	VALUES (2726,
	2621,
	0,
	'Paused',
	3,
	0);
INSERT INTO SM_SEME
	VALUES (2726,
	2573,
	2621,
	0);
INSERT INTO SM_SEME
	VALUES (2726,
	1969,
	2621,
	0);
INSERT INTO SM_CH
	VALUES (2726,
	1993,
	2621,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2726,
	1993,
	2621,
	0);
INSERT INTO SM_CH
	VALUES (2726,
	2622,
	2621,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2726,
	2622,
	2621,
	0);
INSERT INTO SM_MOAH
	VALUES (2727,
	2621,
	2726);
INSERT INTO SM_AH
	VALUES (2727,
	2621);
INSERT INTO SM_ACT
	VALUES (2727,
	2621,
	1,
	'// Deactivate evaluation timer, ignoring the return code because this 
//   state model ignores any latent timer events.
cancelSucceeded = TIM::timer_cancel( timer_inst_ref: self.evaluationTimer );',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (2728,
	2621,
	2727);
INSERT INTO ACT_ACT
	VALUES (2728,
	'state',
	0,
	2729,
	0,
	0,
	'Goal::Paused',
	0);
INSERT INTO ACT_BLK
	VALUES (2729,
	0,
	0,
	0,
	'TIM',
	'',
	'',
	3,
	1,
	3,
	19,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2728,
	0);
INSERT INTO ACT_SMT
	VALUES (2730,
	2729,
	0,
	3,
	1,
	'Goal::Paused line: 3');
INSERT INTO ACT_AI
	VALUES (2730,
	2731,
	2732,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2732,
	1,
	1,
	3,
	1,
	15,
	0,
	0,
	0,
	0,
	125,
	2729);
INSERT INTO V_TVL
	VALUES (2732,
	2733);
INSERT INTO V_VAL
	VALUES (2731,
	0,
	0,
	3,
	24,
	-1,
	3,
	38,
	0,
	0,
	125,
	2729);
INSERT INTO V_BRV
	VALUES (2731,
	1297,
	1,
	3,
	19);
INSERT INTO V_VAL
	VALUES (2734,
	0,
	0,
	3,
	54,
	57,
	0,
	0,
	0,
	0,
	1309,
	2729);
INSERT INTO V_IRF
	VALUES (2734,
	2735);
INSERT INTO V_VAL
	VALUES (2736,
	0,
	0,
	3,
	59,
	73,
	0,
	0,
	0,
	0,
	1272,
	2729);
INSERT INTO V_AVL
	VALUES (2736,
	2734,
	1681,
	2374);
INSERT INTO V_PAR
	VALUES (2736,
	0,
	2731,
	'timer_inst_ref',
	0,
	3,
	38);
INSERT INTO V_VAR
	VALUES (2733,
	2729,
	'cancelSucceeded',
	1,
	125);
INSERT INTO V_TRN
	VALUES (2733,
	0,
	'');
INSERT INTO V_VAR
	VALUES (2735,
	2729,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2735,
	0,
	1681);
INSERT INTO SM_STATE
	VALUES (2737,
	2621,
	0,
	'Evaluating',
	4,
	0);
INSERT INTO SM_CH
	VALUES (2737,
	2573,
	2621,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2737,
	2573,
	2621,
	0);
INSERT INTO SM_CH
	VALUES (2737,
	1969,
	2621,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2737,
	1969,
	2621,
	0);
INSERT INTO SM_CH
	VALUES (2737,
	1993,
	2621,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (2737,
	1993,
	2621,
	0);
INSERT INTO SM_SEME
	VALUES (2737,
	2622,
	2621,
	0);
INSERT INTO SM_MOAH
	VALUES (2738,
	2621,
	2737);
INSERT INTO SM_AH
	VALUES (2738,
	2621);
INSERT INTO SM_ACT
	VALUES (2738,
	2621,
	1,
	'// Start a timer that periodically causes evaluation of goal achievement.
GoalAchievement::initialize();
select any goalachievement from instances of GoalAchievement;
create event instance evaluateEvent of Goal2:Evaluate to self; self.evaluationTimer = TIM::timer_start_recurring( event_inst: evaluateEvent, microseconds: goalachievement.evaluationPeriod );

generate Goal4:evaluationComplete() to self;',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (2739,
	2621,
	2738);
INSERT INTO ACT_ACT
	VALUES (2739,
	'state',
	0,
	2740,
	0,
	0,
	'Goal::Evaluating',
	0);
INSERT INTO ACT_BLK
	VALUES (2740,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	6,
	1,
	4,
	87,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2739,
	0);
INSERT INTO ACT_SMT
	VALUES (2741,
	2740,
	2742,
	2,
	1,
	'Goal::Evaluating line: 2');
INSERT INTO ACT_TFM
	VALUES (2741,
	2354,
	0,
	2,
	18,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES (2742,
	2740,
	2743,
	3,
	1,
	'Goal::Evaluating line: 3');
INSERT INTO ACT_FIO
	VALUES (2742,
	2744,
	1,
	'any',
	2357,
	3,
	46);
INSERT INTO ACT_SMT
	VALUES (2743,
	2740,
	2745,
	4,
	1,
	'Goal::Evaluating line: 4');
INSERT INTO E_ESS
	VALUES (2743,
	1,
	0,
	4,
	40,
	4,
	46,
	3,
	46,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (2743,
	1,
	2746);
INSERT INTO E_CSME
	VALUES (2743,
	1969);
INSERT INTO E_CEI
	VALUES (2743,
	2747);
INSERT INTO ACT_SMT
	VALUES (2745,
	2740,
	2748,
	4,
	64,
	'Goal::Evaluating line: 4');
INSERT INTO ACT_AI
	VALUES (2745,
	2749,
	2750,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2748,
	2740,
	0,
	6,
	1,
	'Goal::Evaluating line: 6');
INSERT INTO E_ESS
	VALUES (2748,
	1,
	0,
	6,
	10,
	6,
	16,
	4,
	87,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (2748);
INSERT INTO E_GSME
	VALUES (2748,
	2622);
INSERT INTO E_GEN
	VALUES (2748,
	2747);
INSERT INTO V_VAL
	VALUES (2751,
	1,
	0,
	4,
	64,
	67,
	0,
	0,
	0,
	0,
	1309,
	2740);
INSERT INTO V_IRF
	VALUES (2751,
	2747);
INSERT INTO V_VAL
	VALUES (2750,
	1,
	0,
	4,
	69,
	83,
	0,
	0,
	0,
	0,
	1272,
	2740);
INSERT INTO V_AVL
	VALUES (2750,
	2751,
	1681,
	2374);
INSERT INTO V_VAL
	VALUES (2749,
	0,
	0,
	4,
	92,
	-1,
	4,
	115,
	4,
	142,
	1272,
	2740);
INSERT INTO V_BRV
	VALUES (2749,
	1278,
	1,
	4,
	87);
INSERT INTO V_VAL
	VALUES (2752,
	0,
	0,
	4,
	127,
	139,
	0,
	0,
	0,
	0,
	1275,
	2740);
INSERT INTO V_TVL
	VALUES (2752,
	2746);
INSERT INTO V_PAR
	VALUES (2752,
	0,
	2749,
	'event_inst',
	2753,
	4,
	115);
INSERT INTO V_VAL
	VALUES (2754,
	0,
	0,
	4,
	156,
	170,
	0,
	0,
	0,
	0,
	1309,
	2740);
INSERT INTO V_IRF
	VALUES (2754,
	2744);
INSERT INTO V_VAL
	VALUES (2753,
	0,
	0,
	4,
	172,
	187,
	0,
	0,
	0,
	0,
	160,
	2740);
INSERT INTO V_AVL
	VALUES (2753,
	2754,
	2357,
	2378);
INSERT INTO V_PAR
	VALUES (2753,
	0,
	2749,
	'microseconds',
	0,
	4,
	142);
INSERT INTO V_VAR
	VALUES (2744,
	2740,
	'goalachievement',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2744,
	0,
	2357);
INSERT INTO V_VAR
	VALUES (2746,
	2740,
	'evaluateEvent',
	1,
	1275);
INSERT INTO V_TRN
	VALUES (2746,
	0,
	'');
INSERT INTO V_VAR
	VALUES (2747,
	2740,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2747,
	0,
	1681);
INSERT INTO SM_NSTXN
	VALUES (2755,
	2621,
	2623,
	2573,
	0);
INSERT INTO SM_TAH
	VALUES (2756,
	2621,
	2755);
INSERT INTO SM_AH
	VALUES (2756,
	2621);
INSERT INTO SM_ACT
	VALUES (2756,
	2621,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2757,
	2621,
	2756);
INSERT INTO ACT_ACT
	VALUES (2757,
	'transition',
	0,
	2758,
	0,
	0,
	'Goal1: Completed',
	0);
INSERT INTO ACT_BLK
	VALUES (2758,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2757,
	0);
INSERT INTO SM_TXN
	VALUES (2755,
	2621,
	2676,
	0);
INSERT INTO SM_NSTXN
	VALUES (2759,
	2621,
	2623,
	1969,
	0);
INSERT INTO SM_TAH
	VALUES (2760,
	2621,
	2759);
INSERT INTO SM_AH
	VALUES (2760,
	2621);
INSERT INTO SM_ACT
	VALUES (2760,
	2621,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2761,
	2621,
	2760);
INSERT INTO ACT_ACT
	VALUES (2761,
	'transition',
	0,
	2762,
	0,
	0,
	'Goal2: Evaluate',
	0);
INSERT INTO ACT_BLK
	VALUES (2762,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2761,
	0);
INSERT INTO SM_TXN
	VALUES (2759,
	2621,
	2623,
	0);
INSERT INTO SM_NSTXN
	VALUES (2763,
	2621,
	2623,
	1993,
	0);
INSERT INTO SM_TAH
	VALUES (2764,
	2621,
	2763);
INSERT INTO SM_AH
	VALUES (2764,
	2621);
INSERT INTO SM_ACT
	VALUES (2764,
	2621,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2765,
	2621,
	2764);
INSERT INTO ACT_ACT
	VALUES (2765,
	'transition',
	0,
	2766,
	0,
	0,
	'Goal3: Pause',
	0);
INSERT INTO ACT_BLK
	VALUES (2766,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2765,
	0);
INSERT INTO SM_TXN
	VALUES (2763,
	2621,
	2726,
	0);
INSERT INTO SM_NSTXN
	VALUES (2767,
	2621,
	2726,
	2573,
	0);
INSERT INTO SM_TAH
	VALUES (2768,
	2621,
	2767);
INSERT INTO SM_AH
	VALUES (2768,
	2621);
INSERT INTO SM_ACT
	VALUES (2768,
	2621,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2769,
	2621,
	2768);
INSERT INTO ACT_ACT
	VALUES (2769,
	'transition',
	0,
	2770,
	0,
	0,
	'Goal1: Completed',
	0);
INSERT INTO ACT_BLK
	VALUES (2770,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2769,
	0);
INSERT INTO SM_TXN
	VALUES (2767,
	2621,
	2676,
	0);
INSERT INTO SM_NSTXN
	VALUES (2771,
	2621,
	2737,
	2622,
	0);
INSERT INTO SM_TAH
	VALUES (2772,
	2621,
	2771);
INSERT INTO SM_AH
	VALUES (2772,
	2621);
INSERT INTO SM_ACT
	VALUES (2772,
	2621,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2773,
	2621,
	2772);
INSERT INTO ACT_ACT
	VALUES (2773,
	'transition',
	0,
	2774,
	0,
	0,
	'Goal4: evaluationComplete',
	0);
INSERT INTO ACT_BLK
	VALUES (2774,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2773,
	0);
INSERT INTO SM_TXN
	VALUES (2771,
	2621,
	2623,
	0);
INSERT INTO SM_NSTXN
	VALUES (2775,
	2621,
	2726,
	1969,
	0);
INSERT INTO SM_TAH
	VALUES (2776,
	2621,
	2775);
INSERT INTO SM_AH
	VALUES (2776,
	2621);
INSERT INTO SM_ACT
	VALUES (2776,
	2621,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2777,
	2621,
	2776);
INSERT INTO ACT_ACT
	VALUES (2777,
	'transition',
	0,
	2778,
	0,
	0,
	'Goal2: Evaluate',
	0);
INSERT INTO ACT_BLK
	VALUES (2778,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2777,
	0);
INSERT INTO SM_TXN
	VALUES (2775,
	2621,
	2737,
	0);
INSERT INTO PE_PE
	VALUES (1522,
	1,
	1574,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (1522,
	'Display',
	6,
	'Display',
	'Represents the display for the device, managing the sequence of screens
and displaying the appropriate values based on the current mode of the 
display.  
This is a singleton instance.
',
	0);
INSERT INTO O_TFR
	VALUES (2779,
	1522,
	'goalDispositionIndicator',
	'',
	343,
	0,
	'// Return the indicator value representing the disposition of 
// the currently executing goal, if one exists.  If there is
// no currently executing goal, return Blank.

// Find the currently executing goal (if one exists) associated 
// with the singleton instance of the workout session.
select any session from instances of WorkoutSession;
select one goal related by session->Goal[R11.''is_currently_executing''];

// Convert the disposition of the currently executing goal
// (if it exists) to a UI indicator.
indicator = Indicator::Blank;
if ( not empty goal )
  if ( goal.disposition == GoalDisposition::Increase )
    indicator = Indicator::Up;
  elif ( goal.disposition == GoalDisposition::Decrease )
    indicator = Indicator::Down;
  else
    indicator = Indicator::Flat;
  end if;
end if;

return( indicator );',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (2780,
	2779);
INSERT INTO ACT_ACT
	VALUES (2780,
	'class operation',
	0,
	2781,
	0,
	0,
	'Display::goalDispositionIndicator',
	0);
INSERT INTO ACT_BLK
	VALUES (2781,
	1,
	0,
	0,
	'',
	'',
	'',
	23,
	1,
	8,
	37,
	0,
	0,
	8,
	42,
	8,
	46,
	12,
	13,
	0,
	2780,
	0);
INSERT INTO ACT_SMT
	VALUES (2782,
	2781,
	2783,
	7,
	1,
	'Display::goalDispositionIndicator line: 7');
INSERT INTO ACT_FIO
	VALUES (2782,
	2784,
	1,
	'any',
	1470,
	7,
	38);
INSERT INTO ACT_SMT
	VALUES (2783,
	2781,
	2785,
	8,
	1,
	'Display::goalDispositionIndicator line: 8');
INSERT INTO ACT_SEL
	VALUES (2783,
	2786,
	1,
	'one',
	2787);
INSERT INTO ACT_SR
	VALUES (2783);
INSERT INTO ACT_LNK
	VALUES (2788,
	'is_currently_executing',
	2783,
	1680,
	0,
	2,
	1681,
	8,
	37,
	8,
	42,
	8,
	46);
INSERT INTO ACT_SMT
	VALUES (2785,
	2781,
	2789,
	12,
	1,
	'Display::goalDispositionIndicator line: 12');
INSERT INTO ACT_AI
	VALUES (2785,
	2790,
	2791,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2789,
	2781,
	2792,
	13,
	1,
	'Display::goalDispositionIndicator line: 13');
INSERT INTO ACT_IF
	VALUES (2789,
	2793,
	2794,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2792,
	2781,
	0,
	23,
	1,
	'Display::goalDispositionIndicator line: 23');
INSERT INTO ACT_RET
	VALUES (2792,
	2795);
INSERT INTO V_VAL
	VALUES (2787,
	0,
	0,
	8,
	28,
	34,
	0,
	0,
	0,
	0,
	1309,
	2781);
INSERT INTO V_IRF
	VALUES (2787,
	2784);
INSERT INTO V_VAL
	VALUES (2791,
	1,
	1,
	12,
	1,
	9,
	0,
	0,
	0,
	0,
	343,
	2781);
INSERT INTO V_TVL
	VALUES (2791,
	2796);
INSERT INTO V_VAL
	VALUES (2790,
	0,
	0,
	12,
	24,
	28,
	0,
	0,
	0,
	0,
	343,
	2781);
INSERT INTO V_LEN
	VALUES (2790,
	346,
	12,
	13);
INSERT INTO V_VAL
	VALUES (2797,
	0,
	0,
	13,
	16,
	19,
	0,
	0,
	0,
	0,
	1309,
	2781);
INSERT INTO V_IRF
	VALUES (2797,
	2786);
INSERT INTO V_VAL
	VALUES (2798,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2781);
INSERT INTO V_UNY
	VALUES (2798,
	2797,
	'empty');
INSERT INTO V_VAL
	VALUES (2794,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	2781);
INSERT INTO V_UNY
	VALUES (2794,
	2798,
	'not');
INSERT INTO V_VAL
	VALUES (2795,
	0,
	0,
	23,
	9,
	17,
	0,
	0,
	0,
	0,
	343,
	2781);
INSERT INTO V_TVL
	VALUES (2795,
	2796);
INSERT INTO V_VAR
	VALUES (2784,
	2781,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2784,
	0,
	1470);
INSERT INTO V_VAR
	VALUES (2786,
	2781,
	'goal',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2786,
	0,
	1681);
INSERT INTO V_VAR
	VALUES (2796,
	2781,
	'indicator',
	1,
	343);
INSERT INTO V_TRN
	VALUES (2796,
	0,
	'');
INSERT INTO ACT_BLK
	VALUES (2793,
	0,
	0,
	0,
	'',
	'',
	'',
	18,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	16,
	30,
	0,
	2780,
	0);
INSERT INTO ACT_SMT
	VALUES (2799,
	2793,
	0,
	14,
	3,
	'Display::goalDispositionIndicator line: 14');
INSERT INTO ACT_IF
	VALUES (2799,
	2800,
	2801,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2802,
	2793,
	0,
	16,
	3,
	'Display::goalDispositionIndicator line: 16');
INSERT INTO ACT_EL
	VALUES (2802,
	2803,
	2804,
	2799);
INSERT INTO ACT_SMT
	VALUES (2805,
	2793,
	0,
	18,
	3,
	'Display::goalDispositionIndicator line: 18');
INSERT INTO ACT_E
	VALUES (2805,
	2806,
	2799);
INSERT INTO V_VAL
	VALUES (2807,
	0,
	0,
	14,
	8,
	11,
	0,
	0,
	0,
	0,
	1309,
	2793);
INSERT INTO V_IRF
	VALUES (2807,
	2786);
INSERT INTO V_VAL
	VALUES (2808,
	0,
	0,
	14,
	13,
	23,
	0,
	0,
	0,
	0,
	2370,
	2793);
INSERT INTO V_AVL
	VALUES (2808,
	2807,
	1681,
	2371);
INSERT INTO V_VAL
	VALUES (2801,
	0,
	0,
	14,
	13,
	52,
	0,
	0,
	0,
	0,
	125,
	2793);
INSERT INTO V_BIN
	VALUES (2801,
	2809,
	2808,
	'==');
INSERT INTO V_VAL
	VALUES (2809,
	0,
	0,
	14,
	45,
	52,
	0,
	0,
	0,
	0,
	2370,
	2793);
INSERT INTO V_LEN
	VALUES (2809,
	2372,
	14,
	28);
INSERT INTO V_VAL
	VALUES (2810,
	0,
	0,
	16,
	10,
	13,
	0,
	0,
	0,
	0,
	1309,
	2793);
INSERT INTO V_IRF
	VALUES (2810,
	2786);
INSERT INTO V_VAL
	VALUES (2811,
	0,
	0,
	16,
	15,
	25,
	0,
	0,
	0,
	0,
	2370,
	2793);
INSERT INTO V_AVL
	VALUES (2811,
	2810,
	1681,
	2371);
INSERT INTO V_VAL
	VALUES (2804,
	0,
	0,
	16,
	15,
	54,
	0,
	0,
	0,
	0,
	125,
	2793);
INSERT INTO V_BIN
	VALUES (2804,
	2812,
	2811,
	'==');
INSERT INTO V_VAL
	VALUES (2812,
	0,
	0,
	16,
	47,
	54,
	0,
	0,
	0,
	0,
	2370,
	2793);
INSERT INTO V_LEN
	VALUES (2812,
	2491,
	16,
	30);
INSERT INTO ACT_BLK
	VALUES (2800,
	0,
	0,
	0,
	'',
	'',
	'',
	15,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	15,
	17,
	0,
	2780,
	0);
INSERT INTO ACT_SMT
	VALUES (2813,
	2800,
	0,
	15,
	5,
	'Display::goalDispositionIndicator line: 15');
INSERT INTO ACT_AI
	VALUES (2813,
	2814,
	2815,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2815,
	1,
	0,
	15,
	5,
	13,
	0,
	0,
	0,
	0,
	343,
	2800);
INSERT INTO V_TVL
	VALUES (2815,
	2796);
INSERT INTO V_VAL
	VALUES (2814,
	0,
	0,
	15,
	28,
	29,
	0,
	0,
	0,
	0,
	343,
	2800);
INSERT INTO V_LEN
	VALUES (2814,
	355,
	15,
	17);
INSERT INTO ACT_BLK
	VALUES (2803,
	0,
	0,
	0,
	'',
	'',
	'',
	17,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	17,
	17,
	0,
	2780,
	0);
INSERT INTO ACT_SMT
	VALUES (2816,
	2803,
	0,
	17,
	5,
	'Display::goalDispositionIndicator line: 17');
INSERT INTO ACT_AI
	VALUES (2816,
	2817,
	2818,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2818,
	1,
	0,
	17,
	5,
	13,
	0,
	0,
	0,
	0,
	343,
	2803);
INSERT INTO V_TVL
	VALUES (2818,
	2796);
INSERT INTO V_VAL
	VALUES (2817,
	0,
	0,
	17,
	28,
	31,
	0,
	0,
	0,
	0,
	343,
	2803);
INSERT INTO V_LEN
	VALUES (2817,
	349,
	17,
	17);
INSERT INTO ACT_BLK
	VALUES (2806,
	0,
	0,
	0,
	'',
	'',
	'',
	19,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	19,
	17,
	0,
	2780,
	0);
INSERT INTO ACT_SMT
	VALUES (2819,
	2806,
	0,
	19,
	5,
	'Display::goalDispositionIndicator line: 19');
INSERT INTO ACT_AI
	VALUES (2819,
	2820,
	2821,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2821,
	1,
	0,
	19,
	5,
	13,
	0,
	0,
	0,
	0,
	343,
	2806);
INSERT INTO V_TVL
	VALUES (2821,
	2796);
INSERT INTO V_VAL
	VALUES (2820,
	0,
	0,
	19,
	28,
	31,
	0,
	0,
	0,
	0,
	343,
	2806);
INSERT INTO V_LEN
	VALUES (2820,
	352,
	19,
	17);
INSERT INTO O_NBATTR
	VALUES (2822,
	1522);
INSERT INTO O_BATTR
	VALUES (2822,
	1522);
INSERT INTO O_ATTR
	VALUES (2822,
	1522,
	2823,
	'current_state',
	'',
	'',
	'current_state',
	0,
	1307,
	'',
	'');
INSERT INTO O_REF
	VALUES (1522,
	1470,
	0,
	1649,
	1521,
	2824,
	2825,
	2823,
	2826,
	0,
	0,
	'',
	'WorkoutSession',
	'startTime',
	'R7.''indicates_current_status_of''');
INSERT INTO O_RATTR
	VALUES (2823,
	1522,
	1649,
	1470,
	1,
	'startTime');
INSERT INTO O_ATTR
	VALUES (2823,
	1522,
	0,
	'session_startTime',
	'',
	'session_',
	'startTime',
	1,
	1308,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	1522);
INSERT INTO O_OIDA
	VALUES (2823,
	1522,
	0,
	'session_startTime');
INSERT INTO O_ID
	VALUES (1,
	1522);
INSERT INTO O_ID
	VALUES (2,
	1522);
INSERT INTO SM_ISM
	VALUES (2827,
	1522);
INSERT INTO SM_SM
	VALUES (2827,
	'',
	0);
INSERT INTO SM_MOORE
	VALUES (2827);
INSERT INTO SM_LEVT
	VALUES (1523,
	2827,
	0);
INSERT INTO SM_SEVT
	VALUES (1523,
	2827,
	0);
INSERT INTO SM_EVT
	VALUES (1523,
	2827,
	0,
	1,
	'modeChange',
	0,
	'',
	'Display1',
	'');
INSERT INTO SM_LEVT
	VALUES (1600,
	2827,
	0);
INSERT INTO SM_SEVT
	VALUES (1600,
	2827,
	0);
INSERT INTO SM_EVT
	VALUES (1600,
	2827,
	0,
	2,
	'refresh',
	0,
	'',
	'Display2',
	'');
INSERT INTO SM_STATE
	VALUES (2828,
	2827,
	0,
	'displayDistance',
	1,
	0);
INSERT INTO SM_SEME
	VALUES (2828,
	1523,
	2827,
	0);
INSERT INTO SM_SEME
	VALUES (2828,
	1600,
	2827,
	0);
INSERT INTO SM_MOAH
	VALUES (2829,
	2827,
	2828);
INSERT INTO SM_AH
	VALUES (2829,
	2827);
INSERT INTO SM_ACT
	VALUES (2829,
	2827,
	1,
	'select one session related by self->WorkoutSession[R7.''indicates_current_status_of''];
distance = session.accumulatedDistance;
if ( distance > 1000.0 )
  send UI::setData(value: distance / 1000.0, unit: Unit::km);
else 
  send UI::setData(value: distance, unit: Unit::meters);
end if;
send UI::setIndicator( indicator: Display::goalDispositionIndicator() );',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (2830,
	2827,
	2829);
INSERT INTO ACT_ACT
	VALUES (2830,
	'state',
	0,
	2831,
	0,
	0,
	'Display::displayDistance',
	0);
INSERT INTO ACT_BLK
	VALUES (2831,
	1,
	0,
	0,
	'Display',
	'',
	'',
	8,
	1,
	8,
	35,
	0,
	0,
	1,
	52,
	1,
	55,
	0,
	0,
	0,
	2830,
	0);
INSERT INTO ACT_SMT
	VALUES (2832,
	2831,
	2833,
	1,
	1,
	'Display::displayDistance line: 1');
INSERT INTO ACT_SEL
	VALUES (2832,
	2834,
	1,
	'one',
	2835);
INSERT INTO ACT_SR
	VALUES (2832);
INSERT INTO ACT_LNK
	VALUES (2836,
	'indicates_current_status_of',
	2832,
	1521,
	0,
	2,
	1470,
	1,
	37,
	1,
	52,
	1,
	55);
INSERT INTO ACT_SMT
	VALUES (2833,
	2831,
	2837,
	2,
	1,
	'Display::displayDistance line: 2');
INSERT INTO ACT_AI
	VALUES (2833,
	2838,
	2839,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2837,
	2831,
	2840,
	3,
	1,
	'Display::displayDistance line: 3');
INSERT INTO ACT_IF
	VALUES (2837,
	2841,
	2842,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2843,
	2831,
	0,
	5,
	1,
	'Display::displayDistance line: 5');
INSERT INTO ACT_E
	VALUES (2843,
	2844,
	2837);
INSERT INTO ACT_SMT
	VALUES (2840,
	2831,
	0,
	8,
	1,
	'Display::displayDistance line: 8');
INSERT INTO ACT_IOP
	VALUES (2840,
	8,
	10,
	8,
	6,
	0,
	1352,
	0);
INSERT INTO V_VAL
	VALUES (2835,
	0,
	0,
	1,
	31,
	34,
	0,
	0,
	0,
	0,
	1309,
	2831);
INSERT INTO V_IRF
	VALUES (2835,
	2845);
INSERT INTO V_VAL
	VALUES (2839,
	1,
	1,
	2,
	1,
	8,
	0,
	0,
	0,
	0,
	153,
	2831);
INSERT INTO V_TVL
	VALUES (2839,
	2846);
INSERT INTO V_VAL
	VALUES (2847,
	0,
	0,
	2,
	12,
	18,
	0,
	0,
	0,
	0,
	1309,
	2831);
INSERT INTO V_IRF
	VALUES (2847,
	2834);
INSERT INTO V_VAL
	VALUES (2838,
	0,
	0,
	2,
	20,
	38,
	0,
	0,
	0,
	0,
	153,
	2831);
INSERT INTO V_AVL
	VALUES (2838,
	2847,
	1470,
	1651);
INSERT INTO V_VAL
	VALUES (2848,
	0,
	0,
	3,
	6,
	13,
	0,
	0,
	0,
	0,
	153,
	2831);
INSERT INTO V_TVL
	VALUES (2848,
	2846);
INSERT INTO V_VAL
	VALUES (2842,
	0,
	0,
	3,
	6,
	22,
	0,
	0,
	0,
	0,
	125,
	2831);
INSERT INTO V_BIN
	VALUES (2842,
	2849,
	2848,
	'>');
INSERT INTO V_VAL
	VALUES (2849,
	0,
	0,
	3,
	17,
	22,
	0,
	0,
	0,
	0,
	153,
	2831);
INSERT INTO V_LRL
	VALUES (2849,
	'1000.0');
INSERT INTO V_VAL
	VALUES (2850,
	0,
	0,
	8,
	44,
	-1,
	0,
	0,
	0,
	0,
	343,
	2831);
INSERT INTO V_TRV
	VALUES (2850,
	2779,
	0,
	1,
	8,
	35);
INSERT INTO V_PAR
	VALUES (2850,
	2840,
	0,
	'indicator',
	0,
	8,
	24);
INSERT INTO V_VAR
	VALUES (2834,
	2831,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2834,
	0,
	1470);
INSERT INTO V_VAR
	VALUES (2845,
	2831,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2845,
	0,
	1522);
INSERT INTO V_VAR
	VALUES (2846,
	2831,
	'distance',
	1,
	153);
INSERT INTO V_TRN
	VALUES (2846,
	0,
	'');
INSERT INTO ACT_BLK
	VALUES (2841,
	0,
	0,
	0,
	'UI',
	'',
	'',
	4,
	3,
	4,
	8,
	0,
	0,
	0,
	0,
	0,
	0,
	4,
	52,
	0,
	2830,
	0);
INSERT INTO ACT_SMT
	VALUES (2851,
	2841,
	0,
	4,
	3,
	'Display::displayDistance line: 4');
INSERT INTO ACT_IOP
	VALUES (2851,
	4,
	12,
	4,
	8,
	0,
	1351,
	0);
INSERT INTO V_VAL
	VALUES (2852,
	0,
	0,
	4,
	27,
	34,
	0,
	0,
	0,
	0,
	153,
	2841);
INSERT INTO V_TVL
	VALUES (2852,
	2846);
INSERT INTO V_VAL
	VALUES (2853,
	0,
	0,
	4,
	27,
	43,
	0,
	0,
	0,
	0,
	153,
	2841);
INSERT INTO V_BIN
	VALUES (2853,
	2854,
	2852,
	'/');
INSERT INTO V_PAR
	VALUES (2853,
	2851,
	0,
	'value',
	2855,
	4,
	20);
INSERT INTO V_VAL
	VALUES (2854,
	0,
	0,
	4,
	38,
	43,
	0,
	0,
	0,
	0,
	153,
	2841);
INSERT INTO V_LRL
	VALUES (2854,
	'1000.0');
INSERT INTO V_VAL
	VALUES (2855,
	0,
	0,
	4,
	58,
	59,
	0,
	0,
	0,
	0,
	246,
	2841);
INSERT INTO V_LEN
	VALUES (2855,
	249,
	4,
	52);
INSERT INTO V_PAR
	VALUES (2855,
	2851,
	0,
	'unit',
	0,
	4,
	46);
INSERT INTO ACT_BLK
	VALUES (2844,
	0,
	0,
	0,
	'UI',
	'',
	'',
	6,
	3,
	6,
	8,
	0,
	0,
	0,
	0,
	0,
	0,
	6,
	43,
	0,
	2830,
	0);
INSERT INTO ACT_SMT
	VALUES (2856,
	2844,
	0,
	6,
	3,
	'Display::displayDistance line: 6');
INSERT INTO ACT_IOP
	VALUES (2856,
	6,
	12,
	6,
	8,
	0,
	1351,
	0);
INSERT INTO V_VAL
	VALUES (2857,
	0,
	0,
	6,
	27,
	34,
	0,
	0,
	0,
	0,
	153,
	2844);
INSERT INTO V_TVL
	VALUES (2857,
	2846);
INSERT INTO V_PAR
	VALUES (2857,
	2856,
	0,
	'value',
	2858,
	6,
	20);
INSERT INTO V_VAL
	VALUES (2858,
	0,
	0,
	6,
	49,
	54,
	0,
	0,
	0,
	0,
	246,
	2844);
INSERT INTO V_LEN
	VALUES (2858,
	252,
	6,
	43);
INSERT INTO V_PAR
	VALUES (2858,
	2856,
	0,
	'unit',
	0,
	6,
	37);
INSERT INTO SM_STATE
	VALUES (2859,
	2827,
	0,
	'displaySpeed',
	2,
	0);
INSERT INTO SM_SEME
	VALUES (2859,
	1523,
	2827,
	0);
INSERT INTO SM_SEME
	VALUES (2859,
	1600,
	2827,
	0);
INSERT INTO SM_MOAH
	VALUES (2860,
	2827,
	2859);
INSERT INTO SM_AH
	VALUES (2860,
	2827);
INSERT INTO SM_ACT
	VALUES (2860,
	2827,
	1,
	'select one session related by self->WorkoutSession[R7.''indicates_current_status_of''];
speed = session.getCurrentSpeed();
send UI::setData(value: speed, unit: Unit::kmPerHour);
send UI::setIndicator( indicator: Display::goalDispositionIndicator() );',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (2861,
	2827,
	2860);
INSERT INTO ACT_ACT
	VALUES (2861,
	'state',
	0,
	2862,
	0,
	0,
	'Display::displaySpeed',
	0);
INSERT INTO ACT_BLK
	VALUES (2862,
	1,
	0,
	0,
	'Display',
	'',
	'',
	4,
	1,
	4,
	35,
	0,
	0,
	1,
	52,
	1,
	55,
	3,
	38,
	0,
	2861,
	0);
INSERT INTO ACT_SMT
	VALUES (2863,
	2862,
	2864,
	1,
	1,
	'Display::displaySpeed line: 1');
INSERT INTO ACT_SEL
	VALUES (2863,
	2865,
	1,
	'one',
	2866);
INSERT INTO ACT_SR
	VALUES (2863);
INSERT INTO ACT_LNK
	VALUES (2867,
	'indicates_current_status_of',
	2863,
	1521,
	0,
	2,
	1470,
	1,
	37,
	1,
	52,
	1,
	55);
INSERT INTO ACT_SMT
	VALUES (2864,
	2862,
	2868,
	2,
	1,
	'Display::displaySpeed line: 2');
INSERT INTO ACT_AI
	VALUES (2864,
	2869,
	2870,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2868,
	2862,
	2871,
	3,
	1,
	'Display::displaySpeed line: 3');
INSERT INTO ACT_IOP
	VALUES (2868,
	3,
	10,
	3,
	6,
	0,
	1351,
	0);
INSERT INTO ACT_SMT
	VALUES (2871,
	2862,
	0,
	4,
	1,
	'Display::displaySpeed line: 4');
INSERT INTO ACT_IOP
	VALUES (2871,
	4,
	10,
	4,
	6,
	0,
	1352,
	0);
INSERT INTO V_VAL
	VALUES (2866,
	0,
	0,
	1,
	31,
	34,
	0,
	0,
	0,
	0,
	1309,
	2862);
INSERT INTO V_IRF
	VALUES (2866,
	2872);
INSERT INTO V_VAL
	VALUES (2870,
	1,
	1,
	2,
	1,
	5,
	0,
	0,
	0,
	0,
	153,
	2862);
INSERT INTO V_TVL
	VALUES (2870,
	2873);
INSERT INTO V_VAL
	VALUES (2869,
	0,
	0,
	2,
	17,
	-1,
	0,
	0,
	0,
	0,
	153,
	2862);
INSERT INTO V_TRV
	VALUES (2869,
	1729,
	2865,
	1,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2874,
	0,
	0,
	3,
	25,
	29,
	0,
	0,
	0,
	0,
	153,
	2862);
INSERT INTO V_TVL
	VALUES (2874,
	2873);
INSERT INTO V_PAR
	VALUES (2874,
	2868,
	0,
	'value',
	2875,
	3,
	18);
INSERT INTO V_VAL
	VALUES (2875,
	0,
	0,
	3,
	44,
	52,
	0,
	0,
	0,
	0,
	246,
	2862);
INSERT INTO V_LEN
	VALUES (2875,
	258,
	3,
	38);
INSERT INTO V_PAR
	VALUES (2875,
	2868,
	0,
	'unit',
	0,
	3,
	32);
INSERT INTO V_VAL
	VALUES (2876,
	0,
	0,
	4,
	44,
	-1,
	0,
	0,
	0,
	0,
	343,
	2862);
INSERT INTO V_TRV
	VALUES (2876,
	2779,
	0,
	1,
	4,
	35);
INSERT INTO V_PAR
	VALUES (2876,
	2871,
	0,
	'indicator',
	0,
	4,
	24);
INSERT INTO V_VAR
	VALUES (2865,
	2862,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2865,
	0,
	1470);
INSERT INTO V_VAR
	VALUES (2872,
	2862,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2872,
	0,
	1522);
INSERT INTO V_VAR
	VALUES (2873,
	2862,
	'speed',
	1,
	153);
INSERT INTO V_TRN
	VALUES (2873,
	0,
	'');
INSERT INTO SM_STATE
	VALUES (2877,
	2827,
	0,
	'displayPace',
	3,
	0);
INSERT INTO SM_SEME
	VALUES (2877,
	1523,
	2827,
	0);
INSERT INTO SM_SEME
	VALUES (2877,
	1600,
	2827,
	0);
INSERT INTO SM_MOAH
	VALUES (2878,
	2827,
	2877);
INSERT INTO SM_AH
	VALUES (2878,
	2827);
INSERT INTO SM_ACT
	VALUES (2878,
	2827,
	1,
	'select one session related by self->WorkoutSession[R7.''indicates_current_status_of''];
pace = session.getCurrentPace();
send UI::setData(value: pace, unit: Unit::minPerKm);
send UI::setIndicator( indicator: Display::goalDispositionIndicator() );',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (2879,
	2827,
	2878);
INSERT INTO ACT_ACT
	VALUES (2879,
	'state',
	0,
	2880,
	0,
	0,
	'Display::displayPace',
	0);
INSERT INTO ACT_BLK
	VALUES (2880,
	1,
	0,
	0,
	'Display',
	'',
	'',
	4,
	1,
	4,
	35,
	0,
	0,
	1,
	52,
	1,
	55,
	3,
	37,
	0,
	2879,
	0);
INSERT INTO ACT_SMT
	VALUES (2881,
	2880,
	2882,
	1,
	1,
	'Display::displayPace line: 1');
INSERT INTO ACT_SEL
	VALUES (2881,
	2883,
	1,
	'one',
	2884);
INSERT INTO ACT_SR
	VALUES (2881);
INSERT INTO ACT_LNK
	VALUES (2885,
	'indicates_current_status_of',
	2881,
	1521,
	0,
	2,
	1470,
	1,
	37,
	1,
	52,
	1,
	55);
INSERT INTO ACT_SMT
	VALUES (2882,
	2880,
	2886,
	2,
	1,
	'Display::displayPace line: 2');
INSERT INTO ACT_AI
	VALUES (2882,
	2887,
	2888,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2886,
	2880,
	2889,
	3,
	1,
	'Display::displayPace line: 3');
INSERT INTO ACT_IOP
	VALUES (2886,
	3,
	10,
	3,
	6,
	0,
	1351,
	0);
INSERT INTO ACT_SMT
	VALUES (2889,
	2880,
	0,
	4,
	1,
	'Display::displayPace line: 4');
INSERT INTO ACT_IOP
	VALUES (2889,
	4,
	10,
	4,
	6,
	0,
	1352,
	0);
INSERT INTO V_VAL
	VALUES (2884,
	0,
	0,
	1,
	31,
	34,
	0,
	0,
	0,
	0,
	1309,
	2880);
INSERT INTO V_IRF
	VALUES (2884,
	2890);
INSERT INTO V_VAL
	VALUES (2888,
	1,
	1,
	2,
	1,
	4,
	0,
	0,
	0,
	0,
	153,
	2880);
INSERT INTO V_TVL
	VALUES (2888,
	2891);
INSERT INTO V_VAL
	VALUES (2887,
	0,
	0,
	2,
	16,
	-1,
	0,
	0,
	0,
	0,
	153,
	2880);
INSERT INTO V_TRV
	VALUES (2887,
	1840,
	2883,
	1,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2892,
	0,
	0,
	3,
	25,
	28,
	0,
	0,
	0,
	0,
	153,
	2880);
INSERT INTO V_TVL
	VALUES (2892,
	2891);
INSERT INTO V_PAR
	VALUES (2892,
	2886,
	0,
	'value',
	2893,
	3,
	18);
INSERT INTO V_VAL
	VALUES (2893,
	0,
	0,
	3,
	43,
	50,
	0,
	0,
	0,
	0,
	246,
	2880);
INSERT INTO V_LEN
	VALUES (2893,
	255,
	3,
	37);
INSERT INTO V_PAR
	VALUES (2893,
	2886,
	0,
	'unit',
	0,
	3,
	31);
INSERT INTO V_VAL
	VALUES (2894,
	0,
	0,
	4,
	44,
	-1,
	0,
	0,
	0,
	0,
	343,
	2880);
INSERT INTO V_TRV
	VALUES (2894,
	2779,
	0,
	1,
	4,
	35);
INSERT INTO V_PAR
	VALUES (2894,
	2889,
	0,
	'indicator',
	0,
	4,
	24);
INSERT INTO V_VAR
	VALUES (2883,
	2880,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2883,
	0,
	1470);
INSERT INTO V_VAR
	VALUES (2890,
	2880,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2890,
	0,
	1522);
INSERT INTO V_VAR
	VALUES (2891,
	2880,
	'pace',
	1,
	153);
INSERT INTO V_TRN
	VALUES (2891,
	0,
	'');
INSERT INTO SM_STATE
	VALUES (2895,
	2827,
	0,
	'displayHeartRate',
	4,
	0);
INSERT INTO SM_SEME
	VALUES (2895,
	1523,
	2827,
	0);
INSERT INTO SM_SEME
	VALUES (2895,
	1600,
	2827,
	0);
INSERT INTO SM_MOAH
	VALUES (2896,
	2827,
	2895);
INSERT INTO SM_AH
	VALUES (2896,
	2827);
INSERT INTO SM_ACT
	VALUES (2896,
	2827,
	1,
	'select one session related by self->WorkoutSession[R7.''indicates_current_status_of''];
heartRate = session.getCurrentHeartRate();
send UI::setData(value: heartRate, unit: Unit::bpm);
send UI::setIndicator( indicator: Display::goalDispositionIndicator() );',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (2897,
	2827,
	2896);
INSERT INTO ACT_ACT
	VALUES (2897,
	'state',
	0,
	2898,
	0,
	0,
	'Display::displayHeartRate',
	0);
INSERT INTO ACT_BLK
	VALUES (2898,
	1,
	0,
	0,
	'Display',
	'',
	'',
	4,
	1,
	4,
	35,
	0,
	0,
	1,
	52,
	1,
	55,
	3,
	42,
	0,
	2897,
	0);
INSERT INTO ACT_SMT
	VALUES (2899,
	2898,
	2900,
	1,
	1,
	'Display::displayHeartRate line: 1');
INSERT INTO ACT_SEL
	VALUES (2899,
	2901,
	1,
	'one',
	2902);
INSERT INTO ACT_SR
	VALUES (2899);
INSERT INTO ACT_LNK
	VALUES (2903,
	'indicates_current_status_of',
	2899,
	1521,
	0,
	2,
	1470,
	1,
	37,
	1,
	52,
	1,
	55);
INSERT INTO ACT_SMT
	VALUES (2900,
	2898,
	2904,
	2,
	1,
	'Display::displayHeartRate line: 2');
INSERT INTO ACT_AI
	VALUES (2900,
	2905,
	2906,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2904,
	2898,
	2907,
	3,
	1,
	'Display::displayHeartRate line: 3');
INSERT INTO ACT_IOP
	VALUES (2904,
	3,
	10,
	3,
	6,
	0,
	1351,
	0);
INSERT INTO ACT_SMT
	VALUES (2907,
	2898,
	0,
	4,
	1,
	'Display::displayHeartRate line: 4');
INSERT INTO ACT_IOP
	VALUES (2907,
	4,
	10,
	4,
	6,
	0,
	1352,
	0);
INSERT INTO V_VAL
	VALUES (2902,
	0,
	0,
	1,
	31,
	34,
	0,
	0,
	0,
	0,
	1309,
	2898);
INSERT INTO V_IRF
	VALUES (2902,
	2908);
INSERT INTO V_VAL
	VALUES (2906,
	1,
	1,
	2,
	1,
	9,
	0,
	0,
	0,
	0,
	160,
	2898);
INSERT INTO V_TVL
	VALUES (2906,
	2909);
INSERT INTO V_VAL
	VALUES (2905,
	0,
	0,
	2,
	21,
	-1,
	0,
	0,
	0,
	0,
	160,
	2898);
INSERT INTO V_TRV
	VALUES (2905,
	1865,
	2901,
	1,
	0,
	0);
INSERT INTO V_VAL
	VALUES (2910,
	0,
	0,
	3,
	25,
	33,
	0,
	0,
	0,
	0,
	160,
	2898);
INSERT INTO V_TVL
	VALUES (2910,
	2909);
INSERT INTO V_PAR
	VALUES (2910,
	2904,
	0,
	'value',
	2911,
	3,
	18);
INSERT INTO V_VAL
	VALUES (2911,
	0,
	0,
	3,
	48,
	50,
	0,
	0,
	0,
	0,
	246,
	2898);
INSERT INTO V_LEN
	VALUES (2911,
	276,
	3,
	42);
INSERT INTO V_PAR
	VALUES (2911,
	2904,
	0,
	'unit',
	0,
	3,
	36);
INSERT INTO V_VAL
	VALUES (2912,
	0,
	0,
	4,
	44,
	-1,
	0,
	0,
	0,
	0,
	343,
	2898);
INSERT INTO V_TRV
	VALUES (2912,
	2779,
	0,
	1,
	4,
	35);
INSERT INTO V_PAR
	VALUES (2912,
	2907,
	0,
	'indicator',
	0,
	4,
	24);
INSERT INTO V_VAR
	VALUES (2901,
	2898,
	'session',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2901,
	0,
	1470);
INSERT INTO V_VAR
	VALUES (2908,
	2898,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2908,
	0,
	1522);
INSERT INTO V_VAR
	VALUES (2909,
	2898,
	'heartRate',
	1,
	160);
INSERT INTO V_TRN
	VALUES (2909,
	0,
	'');
INSERT INTO SM_STATE
	VALUES (2913,
	2827,
	0,
	'displayLapCount',
	5,
	0);
INSERT INTO SM_SEME
	VALUES (2913,
	1523,
	2827,
	0);
INSERT INTO SM_SEME
	VALUES (2913,
	1600,
	2827,
	0);
INSERT INTO SM_MOAH
	VALUES (2914,
	2827,
	2913);
INSERT INTO SM_AH
	VALUES (2914,
	2827);
INSERT INTO SM_ACT
	VALUES (2914,
	2827,
	1,
	'select many lapMarkers related by self->WorkoutSession[R7.''indicates_current_status_of'']->TrackLog[R4.''captures_path_in'']->LapMarker[R5.''has_laps_defined_by''];
send UI::setData(value: cardinality lapMarkers, unit: Unit::laps);
send UI::setIndicator( indicator: Display::goalDispositionIndicator() ); 
',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (2915,
	2827,
	2914);
INSERT INTO ACT_ACT
	VALUES (2915,
	'state',
	0,
	2916,
	0,
	0,
	'Display::displayLapCount',
	0);
INSERT INTO ACT_BLK
	VALUES (2916,
	1,
	0,
	0,
	'Display',
	'',
	'',
	3,
	1,
	3,
	35,
	0,
	0,
	1,
	134,
	1,
	137,
	2,
	55,
	0,
	2915,
	0);
INSERT INTO ACT_SMT
	VALUES (2917,
	2916,
	2918,
	1,
	1,
	'Display::displayLapCount line: 1');
INSERT INTO ACT_SEL
	VALUES (2917,
	2919,
	1,
	'many',
	2920);
INSERT INTO ACT_SR
	VALUES (2917);
INSERT INTO ACT_LNK
	VALUES (2921,
	'indicates_current_status_of',
	2917,
	1521,
	2922,
	2,
	1470,
	1,
	41,
	1,
	56,
	1,
	59);
INSERT INTO ACT_LNK
	VALUES (2922,
	'captures_path_in',
	0,
	1646,
	2923,
	2,
	1642,
	1,
	91,
	1,
	100,
	1,
	103);
INSERT INTO ACT_LNK
	VALUES (2923,
	'has_laps_defined_by',
	0,
	2278,
	0,
	3,
	2272,
	1,
	124,
	1,
	134,
	1,
	137);
INSERT INTO ACT_SMT
	VALUES (2918,
	2916,
	2924,
	2,
	1,
	'Display::displayLapCount line: 2');
INSERT INTO ACT_IOP
	VALUES (2918,
	2,
	10,
	2,
	6,
	0,
	1351,
	0);
INSERT INTO ACT_SMT
	VALUES (2924,
	2916,
	0,
	3,
	1,
	'Display::displayLapCount line: 3');
INSERT INTO ACT_IOP
	VALUES (2924,
	3,
	10,
	3,
	6,
	0,
	1352,
	0);
INSERT INTO V_VAL
	VALUES (2920,
	0,
	0,
	1,
	35,
	38,
	0,
	0,
	0,
	0,
	1309,
	2916);
INSERT INTO V_IRF
	VALUES (2920,
	2925);
INSERT INTO V_VAL
	VALUES (2926,
	0,
	0,
	2,
	37,
	46,
	0,
	0,
	0,
	0,
	1310,
	2916);
INSERT INTO V_ISR
	VALUES (2926,
	2919);
INSERT INTO V_VAL
	VALUES (2927,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	160,
	2916);
INSERT INTO V_UNY
	VALUES (2927,
	2926,
	'cardinality');
INSERT INTO V_PAR
	VALUES (2927,
	2918,
	0,
	'value',
	2928,
	2,
	18);
INSERT INTO V_VAL
	VALUES (2928,
	0,
	0,
	2,
	61,
	64,
	0,
	0,
	0,
	0,
	246,
	2916);
INSERT INTO V_LEN
	VALUES (2928,
	279,
	2,
	55);
INSERT INTO V_PAR
	VALUES (2928,
	2918,
	0,
	'unit',
	0,
	2,
	49);
INSERT INTO V_VAL
	VALUES (2929,
	0,
	0,
	3,
	44,
	-1,
	0,
	0,
	0,
	0,
	343,
	2916);
INSERT INTO V_TRV
	VALUES (2929,
	2779,
	0,
	1,
	3,
	35);
INSERT INTO V_PAR
	VALUES (2929,
	2924,
	0,
	'indicator',
	0,
	3,
	24);
INSERT INTO V_VAR
	VALUES (2919,
	2916,
	'lapMarkers',
	1,
	1310);
INSERT INTO V_INS
	VALUES (2919,
	2272);
INSERT INTO V_VAR
	VALUES (2925,
	2916,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2925,
	0,
	1522);
INSERT INTO SM_NSTXN
	VALUES (2930,
	2827,
	2828,
	1523,
	0);
INSERT INTO SM_TAH
	VALUES (2931,
	2827,
	2930);
INSERT INTO SM_AH
	VALUES (2931,
	2827);
INSERT INTO SM_ACT
	VALUES (2931,
	2827,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2932,
	2827,
	2931);
INSERT INTO ACT_ACT
	VALUES (2932,
	'transition',
	0,
	2933,
	0,
	0,
	'Display1: modeChange',
	0);
INSERT INTO ACT_BLK
	VALUES (2933,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2932,
	0);
INSERT INTO SM_TXN
	VALUES (2930,
	2827,
	2859,
	0);
INSERT INTO SM_NSTXN
	VALUES (2934,
	2827,
	2859,
	1523,
	0);
INSERT INTO SM_TAH
	VALUES (2935,
	2827,
	2934);
INSERT INTO SM_AH
	VALUES (2935,
	2827);
INSERT INTO SM_ACT
	VALUES (2935,
	2827,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2936,
	2827,
	2935);
INSERT INTO ACT_ACT
	VALUES (2936,
	'transition',
	0,
	2937,
	0,
	0,
	'Display1: modeChange',
	0);
INSERT INTO ACT_BLK
	VALUES (2937,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2936,
	0);
INSERT INTO SM_TXN
	VALUES (2934,
	2827,
	2877,
	0);
INSERT INTO SM_NSTXN
	VALUES (2938,
	2827,
	2877,
	1523,
	0);
INSERT INTO SM_TAH
	VALUES (2939,
	2827,
	2938);
INSERT INTO SM_AH
	VALUES (2939,
	2827);
INSERT INTO SM_ACT
	VALUES (2939,
	2827,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2940,
	2827,
	2939);
INSERT INTO ACT_ACT
	VALUES (2940,
	'transition',
	0,
	2941,
	0,
	0,
	'Display1: modeChange',
	0);
INSERT INTO ACT_BLK
	VALUES (2941,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2940,
	0);
INSERT INTO SM_TXN
	VALUES (2938,
	2827,
	2895,
	0);
INSERT INTO SM_NSTXN
	VALUES (2942,
	2827,
	2895,
	1523,
	0);
INSERT INTO SM_TAH
	VALUES (2943,
	2827,
	2942);
INSERT INTO SM_AH
	VALUES (2943,
	2827);
INSERT INTO SM_ACT
	VALUES (2943,
	2827,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2944,
	2827,
	2943);
INSERT INTO ACT_ACT
	VALUES (2944,
	'transition',
	0,
	2945,
	0,
	0,
	'Display1: modeChange',
	0);
INSERT INTO ACT_BLK
	VALUES (2945,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2944,
	0);
INSERT INTO SM_TXN
	VALUES (2942,
	2827,
	2913,
	0);
INSERT INTO SM_NSTXN
	VALUES (2946,
	2827,
	2828,
	1600,
	0);
INSERT INTO SM_TAH
	VALUES (2947,
	2827,
	2946);
INSERT INTO SM_AH
	VALUES (2947,
	2827);
INSERT INTO SM_ACT
	VALUES (2947,
	2827,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2948,
	2827,
	2947);
INSERT INTO ACT_ACT
	VALUES (2948,
	'transition',
	0,
	2949,
	0,
	0,
	'Display2: refresh',
	0);
INSERT INTO ACT_BLK
	VALUES (2949,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2948,
	0);
INSERT INTO SM_TXN
	VALUES (2946,
	2827,
	2828,
	0);
INSERT INTO SM_NSTXN
	VALUES (2950,
	2827,
	2859,
	1600,
	0);
INSERT INTO SM_TAH
	VALUES (2951,
	2827,
	2950);
INSERT INTO SM_AH
	VALUES (2951,
	2827);
INSERT INTO SM_ACT
	VALUES (2951,
	2827,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2952,
	2827,
	2951);
INSERT INTO ACT_ACT
	VALUES (2952,
	'transition',
	0,
	2953,
	0,
	0,
	'Display2: refresh',
	0);
INSERT INTO ACT_BLK
	VALUES (2953,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2952,
	0);
INSERT INTO SM_TXN
	VALUES (2950,
	2827,
	2859,
	0);
INSERT INTO SM_NSTXN
	VALUES (2954,
	2827,
	2895,
	1600,
	0);
INSERT INTO SM_TAH
	VALUES (2955,
	2827,
	2954);
INSERT INTO SM_AH
	VALUES (2955,
	2827);
INSERT INTO SM_ACT
	VALUES (2955,
	2827,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2956,
	2827,
	2955);
INSERT INTO ACT_ACT
	VALUES (2956,
	'transition',
	0,
	2957,
	0,
	0,
	'Display2: refresh',
	0);
INSERT INTO ACT_BLK
	VALUES (2957,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2956,
	0);
INSERT INTO SM_TXN
	VALUES (2954,
	2827,
	2895,
	0);
INSERT INTO SM_NSTXN
	VALUES (2958,
	2827,
	2913,
	1600,
	0);
INSERT INTO SM_TAH
	VALUES (2959,
	2827,
	2958);
INSERT INTO SM_AH
	VALUES (2959,
	2827);
INSERT INTO SM_ACT
	VALUES (2959,
	2827,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2960,
	2827,
	2959);
INSERT INTO ACT_ACT
	VALUES (2960,
	'transition',
	0,
	2961,
	0,
	0,
	'Display2: refresh',
	0);
INSERT INTO ACT_BLK
	VALUES (2961,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2960,
	0);
INSERT INTO SM_TXN
	VALUES (2958,
	2827,
	2913,
	0);
INSERT INTO SM_NSTXN
	VALUES (2962,
	2827,
	2877,
	1600,
	0);
INSERT INTO SM_TAH
	VALUES (2963,
	2827,
	2962);
INSERT INTO SM_AH
	VALUES (2963,
	2827);
INSERT INTO SM_ACT
	VALUES (2963,
	2827,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2964,
	2827,
	2963);
INSERT INTO ACT_ACT
	VALUES (2964,
	'transition',
	0,
	2965,
	0,
	0,
	'Display2: refresh',
	0);
INSERT INTO ACT_BLK
	VALUES (2965,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2964,
	0);
INSERT INTO SM_TXN
	VALUES (2962,
	2827,
	2877,
	0);
INSERT INTO SM_NSTXN
	VALUES (2966,
	2827,
	2913,
	1523,
	0);
INSERT INTO SM_TAH
	VALUES (2967,
	2827,
	2966);
INSERT INTO SM_AH
	VALUES (2967,
	2827);
INSERT INTO SM_ACT
	VALUES (2967,
	2827,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (2968,
	2827,
	2967);
INSERT INTO ACT_ACT
	VALUES (2968,
	'transition',
	0,
	2969,
	0,
	0,
	'Display1: modeChange',
	0);
INSERT INTO ACT_BLK
	VALUES (2969,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	2968,
	0);
INSERT INTO SM_TXN
	VALUES (2966,
	2827,
	2828,
	0);
INSERT INTO PE_PE
	VALUES (1708,
	1,
	1574,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (1708,
	'Achievement',
	10,
	'Achievement',
	'Each instance represents one contiguous period of time during 
which a particular goal was being met (achieved).',
	0);
INSERT INTO O_TFR
	VALUES (2577,
	1708,
	'close',
	'',
	1192,
	1,
	'// Close this open achievement record by storing the end time, relating this
//   record as a recorded one and unrelating it as the open one.
select one goal related by self->Goal[R14.''is_open_for''];
select one workoutTimer related by goal->WorkoutSession[R11.''is_currently_executing_within'']->WorkoutTimer[R8.''is_timed_by''];
self.endTime = workoutTimer.time;
unrelate self from goal across R14.''is_open_for'';
relate self to goal across R12.''specifies_achievement_of'';


',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (2970,
	2577);
INSERT INTO ACT_ACT
	VALUES (2970,
	'operation',
	0,
	2971,
	0,
	0,
	'Achievement::close',
	0);
INSERT INTO ACT_BLK
	VALUES (2971,
	1,
	0,
	0,
	'specifies_achievement_of',
	'',
	'',
	7,
	1,
	4,
	95,
	0,
	0,
	7,
	28,
	7,
	32,
	0,
	0,
	0,
	2970,
	0);
INSERT INTO ACT_SMT
	VALUES (2972,
	2971,
	2973,
	3,
	1,
	'Achievement::close line: 3');
INSERT INTO ACT_SEL
	VALUES (2972,
	2974,
	1,
	'one',
	2975);
INSERT INTO ACT_SR
	VALUES (2972);
INSERT INTO ACT_LNK
	VALUES (2976,
	'is_open_for',
	2972,
	1707,
	0,
	2,
	1681,
	3,
	34,
	3,
	39,
	3,
	43);
INSERT INTO ACT_SMT
	VALUES (2973,
	2971,
	2977,
	4,
	1,
	'Achievement::close line: 4');
INSERT INTO ACT_SEL
	VALUES (2973,
	2978,
	1,
	'one',
	2979);
INSERT INTO ACT_SR
	VALUES (2973);
INSERT INTO ACT_LNK
	VALUES (2980,
	'is_currently_executing_within',
	2973,
	1680,
	2981,
	2,
	1470,
	4,
	42,
	4,
	57,
	4,
	61);
INSERT INTO ACT_LNK
	VALUES (2981,
	'is_timed_by',
	0,
	1583,
	0,
	2,
	1488,
	4,
	95,
	4,
	108,
	4,
	111);
INSERT INTO ACT_SMT
	VALUES (2977,
	2971,
	2982,
	5,
	1,
	'Achievement::close line: 5');
INSERT INTO ACT_AI
	VALUES (2977,
	2983,
	2984,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (2982,
	2971,
	2985,
	6,
	1,
	'Achievement::close line: 6');
INSERT INTO ACT_UNR
	VALUES (2982,
	2986,
	2974,
	'is_open_for',
	1707,
	6,
	32,
	6,
	36);
INSERT INTO ACT_SMT
	VALUES (2985,
	2971,
	0,
	7,
	1,
	'Achievement::close line: 7');
INSERT INTO ACT_REL
	VALUES (2985,
	2986,
	2974,
	'specifies_achievement_of',
	1722,
	7,
	28,
	7,
	32);
INSERT INTO V_VAL
	VALUES (2975,
	0,
	0,
	3,
	28,
	31,
	0,
	0,
	0,
	0,
	1309,
	2971);
INSERT INTO V_IRF
	VALUES (2975,
	2986);
INSERT INTO V_VAL
	VALUES (2979,
	0,
	0,
	4,
	36,
	39,
	0,
	0,
	0,
	0,
	1309,
	2971);
INSERT INTO V_IRF
	VALUES (2979,
	2974);
INSERT INTO V_VAL
	VALUES (2987,
	1,
	0,
	5,
	1,
	4,
	0,
	0,
	0,
	0,
	1309,
	2971);
INSERT INTO V_IRF
	VALUES (2987,
	2986);
INSERT INTO V_VAL
	VALUES (2984,
	1,
	0,
	5,
	6,
	12,
	0,
	0,
	0,
	0,
	160,
	2971);
INSERT INTO V_AVL
	VALUES (2984,
	2987,
	1708,
	2988);
INSERT INTO V_VAL
	VALUES (2989,
	0,
	0,
	5,
	16,
	27,
	0,
	0,
	0,
	0,
	1309,
	2971);
INSERT INTO V_IRF
	VALUES (2989,
	2978);
INSERT INTO V_VAL
	VALUES (2983,
	0,
	0,
	5,
	29,
	32,
	0,
	0,
	0,
	0,
	160,
	2971);
INSERT INTO V_AVL
	VALUES (2983,
	2989,
	1488,
	1604);
INSERT INTO V_VAR
	VALUES (2974,
	2971,
	'goal',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2974,
	0,
	1681);
INSERT INTO V_VAR
	VALUES (2986,
	2971,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2986,
	0,
	1708);
INSERT INTO V_VAR
	VALUES (2978,
	2971,
	'workoutTimer',
	1,
	1309);
INSERT INTO V_INT
	VALUES (2978,
	0,
	1488);
INSERT INTO O_NBATTR
	VALUES (2669,
	1708);
INSERT INTO O_BATTR
	VALUES (2669,
	1708);
INSERT INTO O_ATTR
	VALUES (2669,
	1708,
	2990,
	'startTime',
	'Starting time for this achievement, expressed as the number of seconds
since the beginning of the associated workout session.',
	'',
	'startTime',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (2988,
	1708);
INSERT INTO O_BATTR
	VALUES (2988,
	1708);
INSERT INTO O_ATTR
	VALUES (2988,
	1708,
	2669,
	'endTime',
	'Ending time for this achievement, expressed as the number of seconds
since the beginning of the associated workout session.',
	'',
	'endTime',
	0,
	160,
	'',
	'');
INSERT INTO O_REF
	VALUES (1708,
	1681,
	0,
	2612,
	1722,
	2991,
	2992,
	2993,
	2994,
	0,
	0,
	'',
	'Goal',
	'session_startTime',
	'R12.''specifies_achievement_of''');
INSERT INTO O_REF
	VALUES (1708,
	1681,
	0,
	2612,
	1707,
	2995,
	2996,
	2993,
	2997,
	2994,
	0,
	'',
	'Goal',
	'session_startTime',
	'R14.''is_open_for''');
INSERT INTO O_RATTR
	VALUES (2993,
	1708,
	1649,
	1470,
	1,
	'startTime');
INSERT INTO O_ATTR
	VALUES (2993,
	1708,
	0,
	'session_startTime',
	'

',
	'',
	'session_startTime',
	2,
	1308,
	'',
	'');
INSERT INTO O_REF
	VALUES (1708,
	1681,
	0,
	2363,
	1722,
	2991,
	2992,
	2990,
	2998,
	0,
	0,
	'',
	'Goal',
	'ID',
	'R12.''specifies_achievement_of''');
INSERT INTO O_REF
	VALUES (1708,
	1681,
	0,
	2363,
	1707,
	2995,
	2996,
	2990,
	2999,
	2998,
	0,
	'',
	'Goal',
	'ID',
	'R14.''is_open_for''');
INSERT INTO O_RATTR
	VALUES (2990,
	1708,
	2363,
	1681,
	1,
	'ID');
INSERT INTO O_ATTR
	VALUES (2990,
	1708,
	3000,
	'goal_ID',
	'

',
	'goal_',
	'ID',
	1,
	1308,
	'',
	'');
INSERT INTO O_REF
	VALUES (1708,
	1681,
	0,
	2608,
	1722,
	2991,
	2992,
	3000,
	3001,
	0,
	0,
	'',
	'Goal',
	'spec_sequenceNumber',
	'R12.''specifies_achievement_of''');
INSERT INTO O_REF
	VALUES (1708,
	1681,
	0,
	2608,
	1707,
	2995,
	2996,
	3000,
	3002,
	3001,
	0,
	'',
	'Goal',
	'spec_sequenceNumber',
	'R14.''is_open_for''');
INSERT INTO O_RATTR
	VALUES (3000,
	1708,
	1563,
	1542,
	1,
	'sequenceNumber');
INSERT INTO O_ATTR
	VALUES (3000,
	1708,
	2993,
	'spec_sequenceNumber',
	'

',
	'',
	'spec_sequenceNumber',
	2,
	1308,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	1708);
INSERT INTO O_OIDA
	VALUES (2993,
	1708,
	0,
	'session_startTime');
INSERT INTO O_OIDA
	VALUES (3000,
	1708,
	0,
	'spec_sequenceNumber');
INSERT INTO O_OIDA
	VALUES (2990,
	1708,
	0,
	'goal_ID');
INSERT INTO O_OIDA
	VALUES (2669,
	1708,
	0,
	'startTime');
INSERT INTO O_ID
	VALUES (1,
	1708);
INSERT INTO O_ID
	VALUES (2,
	1708);
INSERT INTO PE_PE
	VALUES (2118,
	1,
	1574,
	0,
	9);
INSERT INTO R_REL
	VALUES (2118,
	1,
	'Indicates the first track point for a track log.  In
other words, this is the first recorded location in 
a chronological series of track points that make up
a track log.
Established when the first track point is recorded and 
exists for the lifetime of the track log.',
	0);
INSERT INTO R_SIMP
	VALUES (2118);
INSERT INTO R_PART
	VALUES (1642,
	2118,
	2120,
	0,
	1,
	'is_start_of');
INSERT INTO O_RTIDA
	VALUES (2117,
	1642,
	0,
	2118,
	2120);
INSERT INTO R_RTO
	VALUES (1642,
	2118,
	2120,
	0);
INSERT INTO R_OIR
	VALUES (1642,
	2118,
	2120,
	0);
INSERT INTO R_FORM
	VALUES (1739,
	2118,
	2119,
	0,
	1,
	'has_first');
INSERT INTO R_RGO
	VALUES (1739,
	2118,
	2119);
INSERT INTO R_OIR
	VALUES (1739,
	2118,
	2119,
	0);
INSERT INTO PE_PE
	VALUES (1806,
	1,
	1574,
	0,
	9);
INSERT INTO R_REL
	VALUES (1806,
	2,
	'Chronologically sequences the track points in a track log.
Established each time a new track point is recorded and 
exists for the lifetime of the track log.',
	0);
INSERT INTO R_SIMP
	VALUES (1806);
INSERT INTO R_PART
	VALUES (1739,
	1806,
	2126,
	0,
	1,
	'preceeds');
INSERT INTO O_RTIDA
	VALUES (2116,
	1739,
	0,
	1806,
	2126);
INSERT INTO O_RTIDA
	VALUES (1787,
	1739,
	0,
	1806,
	2126);
INSERT INTO R_RTO
	VALUES (1739,
	1806,
	2126,
	0);
INSERT INTO R_OIR
	VALUES (1739,
	1806,
	2126,
	0);
INSERT INTO R_FORM
	VALUES (1739,
	1806,
	2125,
	0,
	1,
	'follows');
INSERT INTO R_RGO
	VALUES (1739,
	1806,
	2125);
INSERT INTO R_OIR
	VALUES (1739,
	1806,
	2125,
	0);
INSERT INTO PE_PE
	VALUES (1738,
	1,
	1574,
	0,
	9);
INSERT INTO R_REL
	VALUES (1738,
	3,
	'Represents the most recently recorded track point
in a track log.  
Established each time a new track point is recorded and
removed from the previously recorded track point at the same time.',
	0);
INSERT INTO R_SIMP
	VALUES (1738);
INSERT INTO R_FORM
	VALUES (1739,
	1738,
	2122,
	0,
	1,
	'has_last');
INSERT INTO R_RGO
	VALUES (1739,
	1738,
	2122);
INSERT INTO R_OIR
	VALUES (1739,
	1738,
	2122,
	0);
INSERT INTO R_PART
	VALUES (1642,
	1738,
	2123,
	0,
	1,
	'is_last_for');
INSERT INTO O_RTIDA
	VALUES (2117,
	1642,
	0,
	1738,
	2123);
INSERT INTO R_RTO
	VALUES (1642,
	1738,
	2123,
	0);
INSERT INTO R_OIR
	VALUES (1642,
	1738,
	2123,
	0);
INSERT INTO PE_PE
	VALUES (2278,
	1,
	1574,
	0,
	9);
INSERT INTO R_REL
	VALUES (2278,
	5,
	'Established when a lap marker is created and exists
for the lifetime of the track log.',
	0);
INSERT INTO R_SIMP
	VALUES (2278);
INSERT INTO R_FORM
	VALUES (2272,
	2278,
	2307,
	1,
	1,
	'has_laps_defined_by');
INSERT INTO R_RGO
	VALUES (2272,
	2278,
	2307);
INSERT INTO R_OIR
	VALUES (2272,
	2278,
	2307,
	0);
INSERT INTO R_PART
	VALUES (1642,
	2278,
	2308,
	0,
	0,
	'marks_end_of_lap_in');
INSERT INTO O_RTIDA
	VALUES (2117,
	1642,
	0,
	2278,
	2308);
INSERT INTO R_RTO
	VALUES (1642,
	2278,
	2308,
	0);
INSERT INTO R_OIR
	VALUES (1642,
	2278,
	2308,
	0);
INSERT INTO PE_PE
	VALUES (1521,
	1,
	1574,
	0,
	9);
INSERT INTO R_REL
	VALUES (1521,
	7,
	'Established when a workout session is created and 
exists for the duration of the session.',
	0);
INSERT INTO R_SIMP
	VALUES (1521);
INSERT INTO R_PART
	VALUES (1470,
	1521,
	2825,
	0,
	0,
	'indicates_current_status_of');
INSERT INTO O_RTIDA
	VALUES (1649,
	1470,
	0,
	1521,
	2825);
INSERT INTO R_RTO
	VALUES (1470,
	1521,
	2825,
	0);
INSERT INTO R_OIR
	VALUES (1470,
	1521,
	2825,
	0);
INSERT INTO R_FORM
	VALUES (1522,
	1521,
	2824,
	0,
	0,
	'current_status_indicated_on');
INSERT INTO R_RGO
	VALUES (1522,
	1521,
	2824);
INSERT INTO R_OIR
	VALUES (1522,
	1521,
	2824,
	0);
INSERT INTO PE_PE
	VALUES (1583,
	1,
	1574,
	0,
	9);
INSERT INTO R_REL
	VALUES (1583,
	8,
	'Established when a workout session is created and exists for the duration
of the session.',
	0);
INSERT INTO R_SIMP
	VALUES (1583);
INSERT INTO R_PART
	VALUES (1470,
	1583,
	2004,
	0,
	0,
	'acts_as_the_stopwatch_for');
INSERT INTO O_RTIDA
	VALUES (1649,
	1470,
	0,
	1583,
	2004);
INSERT INTO R_RTO
	VALUES (1470,
	1583,
	2004,
	0);
INSERT INTO R_OIR
	VALUES (1470,
	1583,
	2004,
	0);
INSERT INTO R_FORM
	VALUES (1488,
	1583,
	2003,
	0,
	0,
	'is_timed_by');
INSERT INTO R_RGO
	VALUES (1488,
	1583,
	2003);
INSERT INTO R_OIR
	VALUES (1488,
	1583,
	2003,
	0);
INSERT INTO PE_PE
	VALUES (1646,
	1,
	1574,
	0,
	9);
INSERT INTO R_REL
	VALUES (1646,
	4,
	'Established when a workout session is created and
exists for the duration of the session.',
	0);
INSERT INTO R_SIMP
	VALUES (1646);
INSERT INTO R_PART
	VALUES (1470,
	1646,
	2304,
	0,
	0,
	'represents_path_for');
INSERT INTO O_RTIDA
	VALUES (1649,
	1470,
	0,
	1646,
	2304);
INSERT INTO R_RTO
	VALUES (1470,
	1646,
	2304,
	0);
INSERT INTO R_OIR
	VALUES (1470,
	1646,
	2304,
	0);
INSERT INTO R_FORM
	VALUES (1642,
	1646,
	2303,
	0,
	0,
	'captures_path_in');
INSERT INTO R_RGO
	VALUES (1642,
	1646,
	2303);
INSERT INTO R_OIR
	VALUES (1642,
	1646,
	2303,
	0);
INSERT INTO PE_PE
	VALUES (1595,
	1,
	1574,
	0,
	9);
INSERT INTO R_REL
	VALUES (1595,
	6,
	'Established when a heart rate sample is created and exists for
the duration of the workout session.',
	0);
INSERT INTO R_SIMP
	VALUES (1595);
INSERT INTO R_FORM
	VALUES (1586,
	1595,
	2311,
	1,
	1,
	'tracks_heart_rate_over_time_as');
INSERT INTO R_RGO
	VALUES (1586,
	1595,
	2311);
INSERT INTO R_OIR
	VALUES (1586,
	1595,
	2311,
	0);
INSERT INTO R_PART
	VALUES (1470,
	1595,
	2312,
	0,
	0,
	'was_collected_during');
INSERT INTO O_RTIDA
	VALUES (1649,
	1470,
	0,
	1595,
	2312);
INSERT INTO R_RTO
	VALUES (1470,
	1595,
	2312,
	0);
INSERT INTO R_OIR
	VALUES (1470,
	1595,
	2312,
	0);
INSERT INTO PE_PE
	VALUES (2341,
	1,
	1574,
	0,
	9);
INSERT INTO R_REL
	VALUES (2341,
	9,
	'Established when goal execution begins and removed when it ends.',
	0);
INSERT INTO R_SIMP
	VALUES (2341);
INSERT INTO R_PART
	VALUES (1542,
	2341,
	2615,
	0,
	0,
	'specified_by');
INSERT INTO O_RTIDA
	VALUES (1563,
	1542,
	0,
	2341,
	2615);
INSERT INTO O_RTIDA
	VALUES (2314,
	1542,
	0,
	2341,
	2615);
INSERT INTO R_RTO
	VALUES (1542,
	2341,
	2615,
	0);
INSERT INTO R_OIR
	VALUES (1542,
	2341,
	2615,
	0);
INSERT INTO R_FORM
	VALUES (1681,
	2341,
	2614,
	1,
	1,
	'specifies');
INSERT INTO R_RGO
	VALUES (1681,
	2341,
	2614);
INSERT INTO R_OIR
	VALUES (1681,
	2341,
	2614,
	0);
INSERT INTO PE_PE
	VALUES (1561,
	1,
	1574,
	0,
	9);
INSERT INTO R_REL
	VALUES (1561,
	10,
	'Established when a goal specification is created and exists 
for the duration of a workout session.',
	0);
INSERT INTO R_SIMP
	VALUES (1561);
INSERT INTO R_PART
	VALUES (1470,
	1561,
	2316,
	0,
	0,
	'included_in');
INSERT INTO O_RTIDA
	VALUES (1649,
	1470,
	0,
	1561,
	2316);
INSERT INTO R_RTO
	VALUES (1470,
	1561,
	2316,
	0);
INSERT INTO R_OIR
	VALUES (1470,
	1561,
	2316,
	0);
INSERT INTO R_FORM
	VALUES (1542,
	1561,
	2315,
	1,
	1,
	'includes');
INSERT INTO R_RGO
	VALUES (1542,
	1561,
	2315);
INSERT INTO R_OIR
	VALUES (1542,
	1561,
	2315,
	0);
INSERT INTO PE_PE
	VALUES (1680,
	1,
	1574,
	0,
	9);
INSERT INTO R_REL
	VALUES (1680,
	11,
	'Established when a goal begins executing and removed when it ends.',
	0);
INSERT INTO R_SIMP
	VALUES (1680);
INSERT INTO R_PART
	VALUES (1470,
	1680,
	2618,
	0,
	1,
	'is_currently_executing_within');
INSERT INTO O_RTIDA
	VALUES (1649,
	1470,
	0,
	1680,
	2618);
INSERT INTO R_RTO
	VALUES (1470,
	1680,
	2618,
	0);
INSERT INTO R_OIR
	VALUES (1470,
	1680,
	2618,
	0);
INSERT INTO R_FORM
	VALUES (1681,
	1680,
	2617,
	0,
	1,
	'is_currently_executing');
INSERT INTO R_RGO
	VALUES (1681,
	1680,
	2617);
INSERT INTO R_OIR
	VALUES (1681,
	1680,
	2617,
	0);
INSERT INTO PE_PE
	VALUES (1722,
	1,
	1574,
	0,
	9);
INSERT INTO R_REL
	VALUES (1722,
	12,
	'Established when an achievement period begins and exists for 
the duration of the associated workout session.',
	0);
INSERT INTO R_SIMP
	VALUES (1722);
INSERT INTO R_PART
	VALUES (1681,
	1722,
	2992,
	0,
	0,
	'specifies_achievement_of');
INSERT INTO O_RTIDA
	VALUES (2612,
	1681,
	0,
	1722,
	2992);
INSERT INTO O_RTIDA
	VALUES (2363,
	1681,
	0,
	1722,
	2992);
INSERT INTO O_RTIDA
	VALUES (2608,
	1681,
	0,
	1722,
	2992);
INSERT INTO R_RTO
	VALUES (1681,
	1722,
	2992,
	0);
INSERT INTO R_OIR
	VALUES (1681,
	1722,
	2992,
	0);
INSERT INTO R_FORM
	VALUES (1708,
	1722,
	2991,
	1,
	1,
	'has_recorded');
INSERT INTO R_RGO
	VALUES (1708,
	1722,
	2991);
INSERT INTO R_OIR
	VALUES (1708,
	1722,
	2991,
	0);
INSERT INTO PE_PE
	VALUES (1689,
	1,
	1574,
	0,
	9);
INSERT INTO R_REL
	VALUES (1689,
	13,
	'Established when a goal completes execution and exists for the 
duration of the associated workout session.',
	0);
INSERT INTO R_SIMP
	VALUES (1689);
INSERT INTO R_FORM
	VALUES (1681,
	1689,
	2610,
	1,
	1,
	'has_executed');
INSERT INTO R_RGO
	VALUES (1681,
	1689,
	2610);
INSERT INTO R_OIR
	VALUES (1681,
	1689,
	2610,
	0);
INSERT INTO R_PART
	VALUES (1470,
	1689,
	2611,
	0,
	0,
	'was_executed_within');
INSERT INTO O_RTIDA
	VALUES (1649,
	1470,
	0,
	1689,
	2611);
INSERT INTO R_RTO
	VALUES (1470,
	1689,
	2611,
	0);
INSERT INTO R_OIR
	VALUES (1470,
	1689,
	2611,
	0);
INSERT INTO PE_PE
	VALUES (1707,
	1,
	1574,
	0,
	9);
INSERT INTO R_REL
	VALUES (1707,
	14,
	'Represents an open achievement record, one for which a start time has been recorded
but no end time has yet been recorded.  In other words, this association exists only
while the currently executing goal is being achieved.',
	0);
INSERT INTO R_SIMP
	VALUES (1707);
INSERT INTO R_PART
	VALUES (1681,
	1707,
	2996,
	0,
	1,
	'is_open_for');
INSERT INTO O_RTIDA
	VALUES (2612,
	1681,
	0,
	1707,
	2996);
INSERT INTO O_RTIDA
	VALUES (2363,
	1681,
	0,
	1707,
	2996);
INSERT INTO O_RTIDA
	VALUES (2608,
	1681,
	0,
	1707,
	2996);
INSERT INTO R_RTO
	VALUES (1681,
	1707,
	2996,
	0);
INSERT INTO R_OIR
	VALUES (1681,
	1707,
	2996,
	0);
INSERT INTO R_FORM
	VALUES (1708,
	1707,
	2995,
	0,
	1,
	'has_open');
INSERT INTO R_RGO
	VALUES (1708,
	1707,
	2995);
INSERT INTO R_OIR
	VALUES (1708,
	1707,
	2995,
	0);
INSERT INTO PE_PE
	VALUES (3003,
	1,
	0,
	459,
	7);
INSERT INTO EP_PKG
	VALUES (3003,
	0,
	1371,
	'ConstantSpecifications',
	'',
	0);
INSERT INTO PE_PE
	VALUES (2357,
	1,
	3003,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (2357,
	'GoalAchievement',
	3,
	'GoalAchievement',
	'evaluationPeriod is the period, expressed in microseconds, at which goal achievement is evaluated.',
	0);
INSERT INTO O_TFR
	VALUES (2354,
	2357,
	'initialize',
	'',
	1192,
	0,
	'select any goalachievement from instances of GoalAchievement;
if ( empty goalachievement )
  create object instance goalachievement of GoalAchievement; goalachievement.id = 1;
  goalachievement.evaluationPeriod = 3000000;
end if;',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (3004,
	2354);
INSERT INTO ACT_ACT
	VALUES (3004,
	'class operation',
	0,
	3005,
	0,
	0,
	'GoalAchievement::initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (3005,
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	46,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3004,
	0);
INSERT INTO ACT_SMT
	VALUES (3006,
	3005,
	3007,
	1,
	1,
	'GoalAchievement::initialize line: 1');
INSERT INTO ACT_FIO
	VALUES (3006,
	3008,
	1,
	'any',
	2357,
	1,
	46);
INSERT INTO ACT_SMT
	VALUES (3007,
	3005,
	0,
	2,
	1,
	'GoalAchievement::initialize line: 2');
INSERT INTO ACT_IF
	VALUES (3007,
	3009,
	3010,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3011,
	0,
	0,
	2,
	12,
	26,
	0,
	0,
	0,
	0,
	1309,
	3005);
INSERT INTO V_IRF
	VALUES (3011,
	3008);
INSERT INTO V_VAL
	VALUES (3010,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	3005);
INSERT INTO V_UNY
	VALUES (3010,
	3011,
	'empty');
INSERT INTO V_VAR
	VALUES (3008,
	3005,
	'goalachievement',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3008,
	0,
	2357);
INSERT INTO ACT_BLK
	VALUES (3009,
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	3,
	3,
	45,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3004,
	0);
INSERT INTO ACT_SMT
	VALUES (3012,
	3009,
	3013,
	3,
	3,
	'GoalAchievement::initialize line: 3');
INSERT INTO ACT_CR
	VALUES (3012,
	3008,
	0,
	2357,
	3,
	45);
INSERT INTO ACT_SMT
	VALUES (3013,
	3009,
	3014,
	3,
	62,
	'GoalAchievement::initialize line: 3');
INSERT INTO ACT_AI
	VALUES (3013,
	3015,
	3016,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3014,
	3009,
	0,
	4,
	3,
	'GoalAchievement::initialize line: 4');
INSERT INTO ACT_AI
	VALUES (3014,
	3017,
	3018,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3019,
	1,
	0,
	3,
	62,
	76,
	0,
	0,
	0,
	0,
	1309,
	3009);
INSERT INTO V_IRF
	VALUES (3019,
	3008);
INSERT INTO V_VAL
	VALUES (3016,
	1,
	0,
	3,
	78,
	79,
	0,
	0,
	0,
	0,
	160,
	3009);
INSERT INTO V_AVL
	VALUES (3016,
	3019,
	2357,
	3020);
INSERT INTO V_VAL
	VALUES (3015,
	0,
	0,
	3,
	83,
	83,
	0,
	0,
	0,
	0,
	160,
	3009);
INSERT INTO V_LIN
	VALUES (3015,
	'1');
INSERT INTO V_VAL
	VALUES (3021,
	1,
	0,
	4,
	3,
	17,
	0,
	0,
	0,
	0,
	1309,
	3009);
INSERT INTO V_IRF
	VALUES (3021,
	3008);
INSERT INTO V_VAL
	VALUES (3018,
	1,
	0,
	4,
	19,
	34,
	0,
	0,
	0,
	0,
	160,
	3009);
INSERT INTO V_AVL
	VALUES (3018,
	3021,
	2357,
	2378);
INSERT INTO V_VAL
	VALUES (3017,
	0,
	0,
	4,
	38,
	44,
	0,
	0,
	0,
	0,
	160,
	3009);
INSERT INTO V_LIN
	VALUES (3017,
	'3000000');
INSERT INTO O_NBATTR
	VALUES (3020,
	2357);
INSERT INTO O_BATTR
	VALUES (3020,
	2357);
INSERT INTO O_ATTR
	VALUES (3020,
	2357,
	0,
	'id',
	'',
	'',
	'id',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (2378,
	2357);
INSERT INTO O_BATTR
	VALUES (2378,
	2357);
INSERT INTO O_ATTR
	VALUES (2378,
	2357,
	3020,
	'evaluationPeriod',
	'',
	'',
	'evaluationPeriod',
	0,
	160,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	2357);
INSERT INTO O_OIDA
	VALUES (3020,
	2357,
	0,
	'id');
INSERT INTO O_ID
	VALUES (1,
	2357);
INSERT INTO O_ID
	VALUES (2,
	2357);
INSERT INTO PE_PE
	VALUES (2604,
	1,
	3003,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (2604,
	'GoalSpecConstants',
	4,
	'GoalSpecConstants',
	'GoalSpecOrigin indicates the sequence number of the first goal.',
	0);
INSERT INTO O_TFR
	VALUES (2601,
	2604,
	'initialize',
	'',
	1192,
	0,
	'select any gsc from instances of GoalSpecConstants;
if ( empty gsc )
  create object instance gsc of GoalSpecConstants; gsc.id = 1;
  gsc.GoalSpecOrigin = 1;
end if;',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (3022,
	2601);
INSERT INTO ACT_ACT
	VALUES (3022,
	'class operation',
	0,
	3023,
	0,
	0,
	'GoalSpecConstants::initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (3023,
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	34,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3022,
	0);
INSERT INTO ACT_SMT
	VALUES (3024,
	3023,
	3025,
	1,
	1,
	'GoalSpecConstants::initialize line: 1');
INSERT INTO ACT_FIO
	VALUES (3024,
	3026,
	1,
	'any',
	2604,
	1,
	34);
INSERT INTO ACT_SMT
	VALUES (3025,
	3023,
	0,
	2,
	1,
	'GoalSpecConstants::initialize line: 2');
INSERT INTO ACT_IF
	VALUES (3025,
	3027,
	3028,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3029,
	0,
	0,
	2,
	12,
	14,
	0,
	0,
	0,
	0,
	1309,
	3023);
INSERT INTO V_IRF
	VALUES (3029,
	3026);
INSERT INTO V_VAL
	VALUES (3028,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	3023);
INSERT INTO V_UNY
	VALUES (3028,
	3029,
	'empty');
INSERT INTO V_VAR
	VALUES (3026,
	3023,
	'gsc',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3026,
	0,
	2604);
INSERT INTO ACT_BLK
	VALUES (3027,
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	3,
	3,
	33,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3022,
	0);
INSERT INTO ACT_SMT
	VALUES (3030,
	3027,
	3031,
	3,
	3,
	'GoalSpecConstants::initialize line: 3');
INSERT INTO ACT_CR
	VALUES (3030,
	3026,
	0,
	2604,
	3,
	33);
INSERT INTO ACT_SMT
	VALUES (3031,
	3027,
	3032,
	3,
	52,
	'GoalSpecConstants::initialize line: 3');
INSERT INTO ACT_AI
	VALUES (3031,
	3033,
	3034,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3032,
	3027,
	0,
	4,
	3,
	'GoalSpecConstants::initialize line: 4');
INSERT INTO ACT_AI
	VALUES (3032,
	3035,
	3036,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3037,
	1,
	0,
	3,
	52,
	54,
	0,
	0,
	0,
	0,
	1309,
	3027);
INSERT INTO V_IRF
	VALUES (3037,
	3026);
INSERT INTO V_VAL
	VALUES (3034,
	1,
	0,
	3,
	56,
	57,
	0,
	0,
	0,
	0,
	160,
	3027);
INSERT INTO V_AVL
	VALUES (3034,
	3037,
	2604,
	3038);
INSERT INTO V_VAL
	VALUES (3033,
	0,
	0,
	3,
	61,
	61,
	0,
	0,
	0,
	0,
	160,
	3027);
INSERT INTO V_LIN
	VALUES (3033,
	'1');
INSERT INTO V_VAL
	VALUES (3039,
	1,
	0,
	4,
	3,
	5,
	0,
	0,
	0,
	0,
	1309,
	3027);
INSERT INTO V_IRF
	VALUES (3039,
	3026);
INSERT INTO V_VAL
	VALUES (3036,
	1,
	0,
	4,
	7,
	20,
	0,
	0,
	0,
	0,
	160,
	3027);
INSERT INTO V_AVL
	VALUES (3036,
	3039,
	2604,
	2607);
INSERT INTO V_VAL
	VALUES (3035,
	0,
	0,
	4,
	24,
	24,
	0,
	0,
	0,
	0,
	160,
	3027);
INSERT INTO V_LIN
	VALUES (3035,
	'1');
INSERT INTO O_NBATTR
	VALUES (3038,
	2604);
INSERT INTO O_BATTR
	VALUES (3038,
	2604);
INSERT INTO O_ATTR
	VALUES (3038,
	2604,
	0,
	'id',
	'',
	'',
	'id',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (2607,
	2604);
INSERT INTO O_BATTR
	VALUES (2607,
	2604);
INSERT INTO O_ATTR
	VALUES (2607,
	2604,
	3038,
	'GoalSpecOrigin',
	'',
	'',
	'GoalSpecOrigin',
	0,
	160,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	2604);
INSERT INTO O_OIDA
	VALUES (3038,
	2604,
	0,
	'id');
INSERT INTO O_ID
	VALUES (1,
	2604);
INSERT INTO O_ID
	VALUES (2,
	2604);
INSERT INTO PE_PE
	VALUES (1873,
	1,
	3003,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (1873,
	'HeartRateConstants',
	2,
	'HeartRateConstants',
	'SamplingPeriod is expressed in seconds and represents the period at which heart-rate samples are recorded.
AveragingWindow is expressed in samples and represents the number of samples used when calculating the current average.',
	0);
INSERT INTO O_TFR
	VALUES (1870,
	1873,
	'initialize',
	'',
	1192,
	0,
	'select any hrc from instances of HeartRateConstants;
if ( empty hrc )
  create object instance hrc of HeartRateConstants; hrc.id = 1;
  hrc.HeartRateAveragingWindow = 5;
  hrc.HeartRateSamplingPeriod = 3;
end if;',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (3040,
	1870);
INSERT INTO ACT_ACT
	VALUES (3040,
	'class operation',
	0,
	3041,
	0,
	0,
	'HeartRateConstants::initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (3041,
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	34,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3040,
	0);
INSERT INTO ACT_SMT
	VALUES (3042,
	3041,
	3043,
	1,
	1,
	'HeartRateConstants::initialize line: 1');
INSERT INTO ACT_FIO
	VALUES (3042,
	3044,
	1,
	'any',
	1873,
	1,
	34);
INSERT INTO ACT_SMT
	VALUES (3043,
	3041,
	0,
	2,
	1,
	'HeartRateConstants::initialize line: 2');
INSERT INTO ACT_IF
	VALUES (3043,
	3045,
	3046,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3047,
	0,
	0,
	2,
	12,
	14,
	0,
	0,
	0,
	0,
	1309,
	3041);
INSERT INTO V_IRF
	VALUES (3047,
	3044);
INSERT INTO V_VAL
	VALUES (3046,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	3041);
INSERT INTO V_UNY
	VALUES (3046,
	3047,
	'empty');
INSERT INTO V_VAR
	VALUES (3044,
	3041,
	'hrc',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3044,
	0,
	1873);
INSERT INTO ACT_BLK
	VALUES (3045,
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	3,
	3,
	33,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3040,
	0);
INSERT INTO ACT_SMT
	VALUES (3048,
	3045,
	3049,
	3,
	3,
	'HeartRateConstants::initialize line: 3');
INSERT INTO ACT_CR
	VALUES (3048,
	3044,
	0,
	1873,
	3,
	33);
INSERT INTO ACT_SMT
	VALUES (3049,
	3045,
	3050,
	3,
	53,
	'HeartRateConstants::initialize line: 3');
INSERT INTO ACT_AI
	VALUES (3049,
	3051,
	3052,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3050,
	3045,
	3053,
	4,
	3,
	'HeartRateConstants::initialize line: 4');
INSERT INTO ACT_AI
	VALUES (3050,
	3054,
	3055,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3053,
	3045,
	0,
	5,
	3,
	'HeartRateConstants::initialize line: 5');
INSERT INTO ACT_AI
	VALUES (3053,
	3056,
	3057,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3058,
	1,
	0,
	3,
	53,
	55,
	0,
	0,
	0,
	0,
	1309,
	3045);
INSERT INTO V_IRF
	VALUES (3058,
	3044);
INSERT INTO V_VAL
	VALUES (3052,
	1,
	0,
	3,
	57,
	58,
	0,
	0,
	0,
	0,
	160,
	3045);
INSERT INTO V_AVL
	VALUES (3052,
	3058,
	1873,
	3059);
INSERT INTO V_VAL
	VALUES (3051,
	0,
	0,
	3,
	62,
	62,
	0,
	0,
	0,
	0,
	160,
	3045);
INSERT INTO V_LIN
	VALUES (3051,
	'1');
INSERT INTO V_VAL
	VALUES (3060,
	1,
	0,
	4,
	3,
	5,
	0,
	0,
	0,
	0,
	1309,
	3045);
INSERT INTO V_IRF
	VALUES (3060,
	3044);
INSERT INTO V_VAL
	VALUES (3055,
	1,
	0,
	4,
	7,
	30,
	0,
	0,
	0,
	0,
	160,
	3045);
INSERT INTO V_AVL
	VALUES (3055,
	3060,
	1873,
	1911);
INSERT INTO V_VAL
	VALUES (3054,
	0,
	0,
	4,
	34,
	34,
	0,
	0,
	0,
	0,
	160,
	3045);
INSERT INTO V_LIN
	VALUES (3054,
	'5');
INSERT INTO V_VAL
	VALUES (3061,
	1,
	0,
	5,
	3,
	5,
	0,
	0,
	0,
	0,
	1309,
	3045);
INSERT INTO V_IRF
	VALUES (3061,
	3044);
INSERT INTO V_VAL
	VALUES (3057,
	1,
	0,
	5,
	7,
	29,
	0,
	0,
	0,
	0,
	160,
	3045);
INSERT INTO V_AVL
	VALUES (3057,
	3061,
	1873,
	1908);
INSERT INTO V_VAL
	VALUES (3056,
	0,
	0,
	5,
	33,
	33,
	0,
	0,
	0,
	0,
	160,
	3045);
INSERT INTO V_LIN
	VALUES (3056,
	'3');
INSERT INTO O_NBATTR
	VALUES (3059,
	1873);
INSERT INTO O_BATTR
	VALUES (3059,
	1873);
INSERT INTO O_ATTR
	VALUES (3059,
	1873,
	0,
	'id',
	'',
	'',
	'id',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1911,
	1873);
INSERT INTO O_BATTR
	VALUES (1911,
	1873);
INSERT INTO O_ATTR
	VALUES (1911,
	1873,
	3059,
	'HeartRateAveragingWindow',
	'',
	'',
	'HeartRateAveragingWindow',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1908,
	1873);
INSERT INTO O_BATTR
	VALUES (1908,
	1873);
INSERT INTO O_ATTR
	VALUES (1908,
	1873,
	1911,
	'HeartRateSamplingPeriod',
	'',
	'',
	'HeartRateSamplingPeriod',
	0,
	160,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	1873);
INSERT INTO O_OIDA
	VALUES (3059,
	1873,
	0,
	'id');
INSERT INTO O_ID
	VALUES (1,
	1873);
INSERT INTO O_ID
	VALUES (2,
	1873);
INSERT INTO PE_PE
	VALUES (1759,
	1,
	3003,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (1759,
	'Speed',
	1,
	'Speed',
	'SpeedAveragingWindow is the number of track points used to calculate the current average speed.
SecondsPerHour is the number of seconds in one hour.',
	0);
INSERT INTO O_TFR
	VALUES (1756,
	1759,
	'initialize',
	'',
	1192,
	0,
	'select any speed from instances of Speed;
if ( empty speed )
  create object instance speed of Speed; speed.id = 1;
  speed.SpeedAveragingWindow = 5;
  speed.SecondsPerHour = 3600;
end if;',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (3062,
	1756);
INSERT INTO ACT_ACT
	VALUES (3062,
	'class operation',
	0,
	3063,
	0,
	0,
	'Speed::initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (3063,
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	36,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3062,
	0);
INSERT INTO ACT_SMT
	VALUES (3064,
	3063,
	3065,
	1,
	1,
	'Speed::initialize line: 1');
INSERT INTO ACT_FIO
	VALUES (3064,
	3066,
	1,
	'any',
	1759,
	1,
	36);
INSERT INTO ACT_SMT
	VALUES (3065,
	3063,
	0,
	2,
	1,
	'Speed::initialize line: 2');
INSERT INTO ACT_IF
	VALUES (3065,
	3067,
	3068,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3069,
	0,
	0,
	2,
	12,
	16,
	0,
	0,
	0,
	0,
	1309,
	3063);
INSERT INTO V_IRF
	VALUES (3069,
	3066);
INSERT INTO V_VAL
	VALUES (3068,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	3063);
INSERT INTO V_UNY
	VALUES (3068,
	3069,
	'empty');
INSERT INTO V_VAR
	VALUES (3066,
	3063,
	'speed',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3066,
	0,
	1759);
INSERT INTO ACT_BLK
	VALUES (3067,
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	3,
	3,
	35,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3062,
	0);
INSERT INTO ACT_SMT
	VALUES (3070,
	3067,
	3071,
	3,
	3,
	'Speed::initialize line: 3');
INSERT INTO ACT_CR
	VALUES (3070,
	3066,
	0,
	1759,
	3,
	35);
INSERT INTO ACT_SMT
	VALUES (3071,
	3067,
	3072,
	3,
	42,
	'Speed::initialize line: 3');
INSERT INTO ACT_AI
	VALUES (3071,
	3073,
	3074,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3072,
	3067,
	3075,
	4,
	3,
	'Speed::initialize line: 4');
INSERT INTO ACT_AI
	VALUES (3072,
	3076,
	3077,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3075,
	3067,
	0,
	5,
	3,
	'Speed::initialize line: 5');
INSERT INTO ACT_AI
	VALUES (3075,
	3078,
	3079,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3080,
	1,
	0,
	3,
	42,
	46,
	0,
	0,
	0,
	0,
	1309,
	3067);
INSERT INTO V_IRF
	VALUES (3080,
	3066);
INSERT INTO V_VAL
	VALUES (3074,
	1,
	0,
	3,
	48,
	49,
	0,
	0,
	0,
	0,
	160,
	3067);
INSERT INTO V_AVL
	VALUES (3074,
	3080,
	1759,
	3081);
INSERT INTO V_VAL
	VALUES (3073,
	0,
	0,
	3,
	53,
	53,
	0,
	0,
	0,
	0,
	160,
	3067);
INSERT INTO V_LIN
	VALUES (3073,
	'1');
INSERT INTO V_VAL
	VALUES (3082,
	1,
	0,
	4,
	3,
	7,
	0,
	0,
	0,
	0,
	1309,
	3067);
INSERT INTO V_IRF
	VALUES (3082,
	3066);
INSERT INTO V_VAL
	VALUES (3077,
	1,
	0,
	4,
	9,
	28,
	0,
	0,
	0,
	0,
	160,
	3067);
INSERT INTO V_AVL
	VALUES (3077,
	3082,
	1759,
	1783);
INSERT INTO V_VAL
	VALUES (3076,
	0,
	0,
	4,
	32,
	32,
	0,
	0,
	0,
	0,
	160,
	3067);
INSERT INTO V_LIN
	VALUES (3076,
	'5');
INSERT INTO V_VAL
	VALUES (3083,
	1,
	0,
	5,
	3,
	7,
	0,
	0,
	0,
	0,
	1309,
	3067);
INSERT INTO V_IRF
	VALUES (3083,
	3066);
INSERT INTO V_VAL
	VALUES (3079,
	1,
	0,
	5,
	9,
	22,
	0,
	0,
	0,
	0,
	160,
	3067);
INSERT INTO V_AVL
	VALUES (3079,
	3083,
	1759,
	1800);
INSERT INTO V_VAL
	VALUES (3078,
	0,
	0,
	5,
	26,
	29,
	0,
	0,
	0,
	0,
	160,
	3067);
INSERT INTO V_LIN
	VALUES (3078,
	'3600');
INSERT INTO O_NBATTR
	VALUES (3081,
	1759);
INSERT INTO O_BATTR
	VALUES (3081,
	1759);
INSERT INTO O_ATTR
	VALUES (3081,
	1759,
	0,
	'id',
	'',
	'',
	'id',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1783,
	1759);
INSERT INTO O_BATTR
	VALUES (1783,
	1759);
INSERT INTO O_ATTR
	VALUES (1783,
	1759,
	3081,
	'SpeedAveragingWindow',
	'',
	'',
	'SpeedAveragingWindow',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1800,
	1759);
INSERT INTO O_BATTR
	VALUES (1800,
	1759);
INSERT INTO O_ATTR
	VALUES (1800,
	1759,
	1783,
	'SecondsPerHour',
	'',
	'',
	'SecondsPerHour',
	0,
	160,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	1759);
INSERT INTO O_OIDA
	VALUES (3081,
	1759,
	0,
	'id');
INSERT INTO O_ID
	VALUES (1,
	1759);
INSERT INTO O_ID
	VALUES (2,
	1759);
INSERT INTO PE_PE
	VALUES (1941,
	1,
	3003,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (1941,
	'WorkoutTimerConstants',
	5,
	'WorkoutTimerConstants',
	'timerPeriod specifies, in seconds, the period for the workout timer.',
	0);
INSERT INTO O_TFR
	VALUES (1938,
	1941,
	'initialize',
	'',
	1192,
	0,
	'select any wtc from instances of WorkoutTimerConstants;
if ( empty wtc )
  create object instance wtc of WorkoutTimerConstants; wtc.id = 1;
  wtc.timerPeriod = 1;
end if;',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (3084,
	1938);
INSERT INTO ACT_ACT
	VALUES (3084,
	'class operation',
	0,
	3085,
	0,
	0,
	'WorkoutTimerConstants::initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (3085,
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	34,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3084,
	0);
INSERT INTO ACT_SMT
	VALUES (3086,
	3085,
	3087,
	1,
	1,
	'WorkoutTimerConstants::initialize line: 1');
INSERT INTO ACT_FIO
	VALUES (3086,
	3088,
	1,
	'any',
	1941,
	1,
	34);
INSERT INTO ACT_SMT
	VALUES (3087,
	3085,
	0,
	2,
	1,
	'WorkoutTimerConstants::initialize line: 2');
INSERT INTO ACT_IF
	VALUES (3087,
	3089,
	3090,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3091,
	0,
	0,
	2,
	12,
	14,
	0,
	0,
	0,
	0,
	1309,
	3085);
INSERT INTO V_IRF
	VALUES (3091,
	3088);
INSERT INTO V_VAL
	VALUES (3090,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	3085);
INSERT INTO V_UNY
	VALUES (3090,
	3091,
	'empty');
INSERT INTO V_VAR
	VALUES (3088,
	3085,
	'wtc',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3088,
	0,
	1941);
INSERT INTO ACT_BLK
	VALUES (3089,
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	3,
	3,
	33,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3084,
	0);
INSERT INTO ACT_SMT
	VALUES (3092,
	3089,
	3093,
	3,
	3,
	'WorkoutTimerConstants::initialize line: 3');
INSERT INTO ACT_CR
	VALUES (3092,
	3088,
	0,
	1941,
	3,
	33);
INSERT INTO ACT_SMT
	VALUES (3093,
	3089,
	3094,
	3,
	56,
	'WorkoutTimerConstants::initialize line: 3');
INSERT INTO ACT_AI
	VALUES (3093,
	3095,
	3096,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3094,
	3089,
	0,
	4,
	3,
	'WorkoutTimerConstants::initialize line: 4');
INSERT INTO ACT_AI
	VALUES (3094,
	3097,
	3098,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3099,
	1,
	0,
	3,
	56,
	58,
	0,
	0,
	0,
	0,
	1309,
	3089);
INSERT INTO V_IRF
	VALUES (3099,
	3088);
INSERT INTO V_VAL
	VALUES (3096,
	1,
	0,
	3,
	60,
	61,
	0,
	0,
	0,
	0,
	160,
	3089);
INSERT INTO V_AVL
	VALUES (3096,
	3099,
	1941,
	3100);
INSERT INTO V_VAL
	VALUES (3095,
	0,
	0,
	3,
	65,
	65,
	0,
	0,
	0,
	0,
	160,
	3089);
INSERT INTO V_LIN
	VALUES (3095,
	'1');
INSERT INTO V_VAL
	VALUES (3101,
	1,
	0,
	4,
	3,
	5,
	0,
	0,
	0,
	0,
	1309,
	3089);
INSERT INTO V_IRF
	VALUES (3101,
	3088);
INSERT INTO V_VAL
	VALUES (3098,
	1,
	0,
	4,
	7,
	17,
	0,
	0,
	0,
	0,
	160,
	3089);
INSERT INTO V_AVL
	VALUES (3098,
	3101,
	1941,
	1964);
INSERT INTO V_VAL
	VALUES (3097,
	0,
	0,
	4,
	21,
	21,
	0,
	0,
	0,
	0,
	160,
	3089);
INSERT INTO V_LIN
	VALUES (3097,
	'1');
INSERT INTO O_NBATTR
	VALUES (3100,
	1941);
INSERT INTO O_BATTR
	VALUES (3100,
	1941);
INSERT INTO O_ATTR
	VALUES (3100,
	1941,
	0,
	'id',
	'',
	'',
	'id',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (1964,
	1941);
INSERT INTO O_BATTR
	VALUES (1964,
	1941);
INSERT INTO O_ATTR
	VALUES (1964,
	1941,
	3100,
	'timerPeriod',
	'',
	'',
	'timerPeriod',
	0,
	160,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	1941);
INSERT INTO O_OIDA
	VALUES (3100,
	1941,
	0,
	'id');
INSERT INTO O_ID
	VALUES (1,
	1941);
INSERT INTO O_ID
	VALUES (2,
	1941);
INSERT INTO PE_PE
	VALUES (3102,
	1,
	1344,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (3102,
	0,
	1371,
	'Shared',
	'',
	0);
INSERT INTO PE_PE
	VALUES (44,
	1,
	3102,
	0,
	6);
INSERT INTO C_I
	VALUES (44,
	0,
	'Tracking',
	'');
INSERT INTO C_EP
	VALUES (46,
	44,
	0,
	'heartRateChanged',
	'');
INSERT INTO C_IO
	VALUES (46,
	1192,
	'heartRateChanged',
	'',
	0,
	'',
	0);
INSERT INTO C_PP
	VALUES (1337,
	46,
	160,
	'heartRate',
	'',
	0,
	'',
	0);
INSERT INTO C_EP
	VALUES (50,
	44,
	0,
	'setTargetPressed',
	'');
INSERT INTO C_IO
	VALUES (50,
	1192,
	'setTargetPressed',
	'',
	0,
	'',
	46);
INSERT INTO C_EP
	VALUES (54,
	44,
	0,
	'startStopPressed',
	'');
INSERT INTO C_IO
	VALUES (54,
	1192,
	'startStopPressed',
	'',
	0,
	'',
	50);
INSERT INTO C_EP
	VALUES (58,
	44,
	0,
	'lapResetPressed',
	'');
INSERT INTO C_IO
	VALUES (58,
	1192,
	'lapResetPressed',
	'',
	0,
	'',
	54);
INSERT INTO C_EP
	VALUES (62,
	44,
	0,
	'lightPressed',
	'');
INSERT INTO C_IO
	VALUES (62,
	1192,
	'lightPressed',
	'',
	0,
	'',
	58);
INSERT INTO C_EP
	VALUES (66,
	44,
	0,
	'modePressed',
	'');
INSERT INTO C_IO
	VALUES (66,
	1192,
	'modePressed',
	'',
	0,
	'',
	62);
INSERT INTO C_EP
	VALUES (70,
	44,
	0,
	'newGoalSpec',
	'');
INSERT INTO C_IO
	VALUES (70,
	1192,
	'newGoalSpec',
	'',
	0,
	'',
	66);
INSERT INTO C_PP
	VALUES (1338,
	70,
	147,
	'spanType',
	'',
	0,
	'',
	0);
INSERT INTO C_PP
	VALUES (1339,
	70,
	150,
	'criteriaType',
	'',
	0,
	'',
	1338);
INSERT INTO C_PP
	VALUES (1340,
	70,
	153,
	'span',
	'',
	0,
	'',
	1339);
INSERT INTO C_PP
	VALUES (1341,
	70,
	153,
	'maximum',
	'',
	0,
	'',
	1340);
INSERT INTO C_PP
	VALUES (1342,
	70,
	153,
	'minimum',
	'',
	0,
	'',
	1341);
INSERT INTO C_PP
	VALUES (1343,
	70,
	160,
	'sequenceNumber',
	'',
	0,
	'',
	1342);
INSERT INTO PE_PE
	VALUES (436,
	1,
	3102,
	0,
	6);
INSERT INTO C_I
	VALUES (436,
	0,
	'Tracking_HeartRateMonitor',
	'');
INSERT INTO C_EP
	VALUES (438,
	436,
	0,
	'registerListener',
	'');
INSERT INTO C_IO
	VALUES (438,
	1192,
	'registerListener',
	'',
	0,
	'',
	0);
INSERT INTO C_EP
	VALUES (443,
	436,
	0,
	'unregisterListener',
	'');
INSERT INTO C_IO
	VALUES (443,
	1192,
	'unregisterListener',
	'',
	0,
	'',
	438);
INSERT INTO PE_PE
	VALUES (378,
	1,
	3102,
	0,
	6);
INSERT INTO C_I
	VALUES (378,
	0,
	'Tracking_Location',
	'');
INSERT INTO C_EP
	VALUES (380,
	378,
	0,
	'getDistance',
	'');
INSERT INTO C_IO
	VALUES (380,
	1192,
	'getDistance',
	'',
	0,
	'',
	0);
INSERT INTO C_PP
	VALUES (400,
	380,
	153,
	'toLong',
	'',
	0,
	'',
	391);
INSERT INTO C_PP
	VALUES (398,
	380,
	153,
	'toLat',
	'',
	0,
	'',
	400);
INSERT INTO C_PP
	VALUES (396,
	380,
	153,
	'fromLong',
	'',
	0,
	'',
	398);
INSERT INTO C_PP
	VALUES (394,
	380,
	153,
	'fromLat',
	'',
	0,
	'',
	396);
INSERT INTO C_PP
	VALUES (391,
	380,
	153,
	'result',
	'',
	1,
	'',
	0);
INSERT INTO C_EP
	VALUES (402,
	378,
	0,
	'getLocation',
	'');
INSERT INTO C_IO
	VALUES (402,
	1192,
	'getLocation',
	'',
	0,
	'',
	380);
INSERT INTO C_PP
	VALUES (421,
	402,
	153,
	'longitude',
	'',
	1,
	'',
	0);
INSERT INTO C_PP
	VALUES (419,
	402,
	153,
	'latitude',
	'',
	1,
	'',
	421);
INSERT INTO C_EP
	VALUES (425,
	378,
	0,
	'registerListener',
	'');
INSERT INTO C_IO
	VALUES (425,
	1192,
	'registerListener',
	'',
	0,
	'',
	402);
INSERT INTO C_EP
	VALUES (430,
	378,
	0,
	'unregisterListener',
	'');
INSERT INTO C_IO
	VALUES (430,
	1192,
	'unregisterListener',
	'',
	0,
	'',
	425);
INSERT INTO PE_PE
	VALUES (207,
	1,
	3102,
	0,
	6);
INSERT INTO C_I
	VALUES (207,
	0,
	'Tracking_UI',
	'');
INSERT INTO C_EP
	VALUES (209,
	207,
	0,
	'setData',
	'');
INSERT INTO C_IO
	VALUES (209,
	1192,
	'setData',
	'',
	0,
	'',
	0);
INSERT INTO C_PP
	VALUES (247,
	209,
	246,
	'unit',
	'',
	0,
	'',
	282);
INSERT INTO C_PP
	VALUES (282,
	209,
	153,
	'value',
	'',
	0,
	'',
	0);
INSERT INTO C_EP
	VALUES (327,
	207,
	0,
	'setIndicator',
	'');
INSERT INTO C_IO
	VALUES (327,
	1192,
	'setIndicator',
	'',
	0,
	'',
	209);
INSERT INTO C_PP
	VALUES (344,
	327,
	343,
	'indicator',
	'',
	0,
	'',
	0);
INSERT INTO C_EP
	VALUES (370,
	207,
	0,
	'setTime',
	'');
INSERT INTO C_IO
	VALUES (370,
	1192,
	'setTime',
	'',
	0,
	'',
	327);
INSERT INTO C_PP
	VALUES (375,
	370,
	160,
	'time',
	'',
	0,
	'',
	0);
INSERT INTO PE_PE
	VALUES (150,
	1,
	3102,
	0,
	3);
INSERT INTO S_DT
	VALUES (150,
	0,
	'GoalCriteria',
	'The criteria type for a particular workout goal.  ',
	'');
INSERT INTO S_EDT
	VALUES (150);
INSERT INTO S_ENUM
	VALUES (183,
	'Pace',
	'A pace criteria is specified as a range of paces between
miniumum and maximum values specified in minutes per kilometer.',
	150,
	151);
INSERT INTO S_ENUM
	VALUES (151,
	'HeartRate',
	'A heart-rate criteria is specified as a range of heart rates between
minimum and maximum values, in beats per minute.',
	150,
	0);
INSERT INTO PE_PE
	VALUES (2370,
	1,
	3102,
	0,
	3);
INSERT INTO S_DT
	VALUES (2370,
	0,
	'GoalDisposition',
	'Disposition of a currently executing goal.',
	'');
INSERT INTO S_EDT
	VALUES (2370);
INSERT INTO S_ENUM
	VALUES (2491,
	'Decrease',
	'The value associated with the goal is presently above the maximum 
specified in the criteria for the goal, so the user must decrease
that value to achieve the goal.',
	2370,
	2372);
INSERT INTO S_ENUM
	VALUES (2372,
	'Increase',
	'The value associated with the goal is presently below the minimum 
specified in the criteria for the goal, so the user must increase
that value to achieve the goal.',
	2370,
	2467);
INSERT INTO S_ENUM
	VALUES (2467,
	'Achieving',
	'The goal is currently being achieved.',
	2370,
	0);
INSERT INTO PE_PE
	VALUES (147,
	1,
	3102,
	0,
	3);
INSERT INTO S_DT
	VALUES (147,
	0,
	'GoalSpan',
	'',
	'');
INSERT INTO S_EDT
	VALUES (147);
INSERT INTO S_ENUM
	VALUES (164,
	'Time',
	'A time-based span is specified in seconds.',
	147,
	148);
INSERT INTO S_ENUM
	VALUES (148,
	'Distance',
	'A distance-based span is specified in meters.',
	147,
	0);
INSERT INTO PE_PE
	VALUES (343,
	1,
	3102,
	0,
	3);
INSERT INTO S_DT
	VALUES (343,
	0,
	'Indicator',
	'Graphical indicator.',
	'');
INSERT INTO S_EDT
	VALUES (343);
INSERT INTO S_ENUM
	VALUES (349,
	'Down',
	'A downward indicator:  perhaps an arrow pointing down.',
	343,
	346);
INSERT INTO S_ENUM
	VALUES (352,
	'Flat',
	'A neutral indicator:  perhaps a horizontal line or dash.',
	343,
	349);
INSERT INTO S_ENUM
	VALUES (355,
	'Up',
	'A downward indicator:  perhaps an arrow pointing up.',
	343,
	352);
INSERT INTO S_ENUM
	VALUES (346,
	'Blank',
	'No indicator at all.',
	343,
	0);
INSERT INTO PE_PE
	VALUES (246,
	1,
	3102,
	0,
	3);
INSERT INTO S_DT
	VALUES (246,
	0,
	'Unit',
	'',
	'');
INSERT INTO S_EDT
	VALUES (246);
INSERT INTO S_ENUM
	VALUES (255,
	'minPerKm',
	'',
	246,
	252);
INSERT INTO S_ENUM
	VALUES (249,
	'km',
	'',
	246,
	0);
INSERT INTO S_ENUM
	VALUES (252,
	'meters',
	'',
	246,
	249);
INSERT INTO S_ENUM
	VALUES (258,
	'kmPerHour',
	'',
	246,
	255);
INSERT INTO S_ENUM
	VALUES (261,
	'miles',
	'',
	246,
	258);
INSERT INTO S_ENUM
	VALUES (264,
	'yards',
	'',
	246,
	261);
INSERT INTO S_ENUM
	VALUES (267,
	'feet',
	'',
	246,
	264);
INSERT INTO S_ENUM
	VALUES (270,
	'minPerMile',
	'',
	246,
	267);
INSERT INTO S_ENUM
	VALUES (273,
	'mph',
	'',
	246,
	270);
INSERT INTO S_ENUM
	VALUES (276,
	'bpm',
	'',
	246,
	273);
INSERT INTO S_ENUM
	VALUES (279,
	'laps',
	'',
	246,
	276);
-- root-types-contained: SystemModel_c
-- BP 7.1 content: StreamData syschar: 3 persistence-version: 7.1.6

INSERT INTO S_SYS
	VALUES (3103,
	'UI',
	1);
INSERT INTO EP_PKG
	VALUES (1323,
	3103,
	3103,
	'UI',
	'',
	0);
INSERT INTO PE_PE
	VALUES (448,
	1,
	1323,
	0,
	2);
INSERT INTO C_C
	VALUES (448,
	0,
	0,
	'UI',
	'Simulates the user interface and has the ability to connect an external GUI
representing the physical watch.

Uses the BridgePoint Java API to connect to an animated version of the watch
while the models are executing in Verifier.

There is also hand-written C code that implments parts of this component to 
allow generated code to connect to the exact same animated watch.',
	0,
	0,
	0,
	'');
INSERT INTO C_PO
	VALUES (1314,
	448,
	'UI',
	0,
	0);
INSERT INTO C_IR
	VALUES (451,
	6,
	0,
	1314);
INSERT INTO C_P
	VALUES (451,
	'UI',
	'Unnamed Interface',
	'',
	'UI::UI::UI');
INSERT INTO SPR_PEP
	VALUES (1315,
	8,
	451);
INSERT INTO SPR_PO
	VALUES (1315,
	'setTime',
	'',
	'::setTime( time:param.time );',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (3104,
	1315);
INSERT INTO ACT_ACT
	VALUES (3104,
	'interface operation',
	0,
	3105,
	0,
	0,
	'UI::UI::setTime',
	0);
INSERT INTO ACT_BLK
	VALUES (3105,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3104,
	0);
INSERT INTO ACT_SMT
	VALUES (3106,
	3105,
	0,
	1,
	1,
	'UI::UI::setTime line: 1');
INSERT INTO ACT_FNC
	VALUES (3106,
	3107,
	1,
	3);
INSERT INTO V_VAL
	VALUES (3108,
	0,
	0,
	1,
	23,
	26,
	0,
	0,
	0,
	0,
	160,
	3105);
INSERT INTO V_PVL
	VALUES (3108,
	0,
	0,
	0,
	1319);
INSERT INTO V_PAR
	VALUES (3108,
	3106,
	0,
	'time',
	0,
	1,
	12);
INSERT INTO SPR_PEP
	VALUES (1316,
	12,
	451);
INSERT INTO SPR_PO
	VALUES (1316,
	'setData',
	'',
	'::setData( value:param.value, unit:param.unit );',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (3109,
	1316);
INSERT INTO ACT_ACT
	VALUES (3109,
	'interface operation',
	0,
	3110,
	0,
	0,
	'UI::UI::setData',
	0);
INSERT INTO ACT_BLK
	VALUES (3110,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3109,
	0);
INSERT INTO ACT_SMT
	VALUES (3111,
	3110,
	0,
	1,
	1,
	'UI::UI::setData line: 1');
INSERT INTO ACT_FNC
	VALUES (3111,
	3112,
	1,
	3);
INSERT INTO V_VAL
	VALUES (3113,
	0,
	0,
	1,
	24,
	28,
	0,
	0,
	0,
	0,
	153,
	3110);
INSERT INTO V_PVL
	VALUES (3113,
	0,
	0,
	0,
	1320);
INSERT INTO V_PAR
	VALUES (3113,
	3111,
	0,
	'value',
	3114,
	1,
	12);
INSERT INTO V_VAL
	VALUES (3114,
	0,
	0,
	1,
	42,
	45,
	0,
	0,
	0,
	0,
	284,
	3110);
INSERT INTO V_PVL
	VALUES (3114,
	0,
	0,
	0,
	1321);
INSERT INTO V_PAR
	VALUES (3114,
	3111,
	0,
	'unit',
	0,
	1,
	31);
INSERT INTO SPR_PEP
	VALUES (1317,
	16,
	451);
INSERT INTO SPR_PO
	VALUES (1317,
	'startTest',
	'',
	'::startTest();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (3115,
	1317);
INSERT INTO ACT_ACT
	VALUES (3115,
	'interface operation',
	0,
	3116,
	0,
	0,
	'UI::UI::startTest',
	0);
INSERT INTO ACT_BLK
	VALUES (3116,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3115,
	0);
INSERT INTO ACT_SMT
	VALUES (3117,
	3116,
	0,
	1,
	1,
	'UI::UI::startTest line: 1');
INSERT INTO ACT_FNC
	VALUES (3117,
	3118,
	1,
	3);
INSERT INTO SPR_PEP
	VALUES (1318,
	20,
	451);
INSERT INTO SPR_PO
	VALUES (1318,
	'setIndicator',
	'',
	'::setIndicator( indicator:param.indicator );',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (3119,
	1318);
INSERT INTO ACT_ACT
	VALUES (3119,
	'interface operation',
	0,
	3120,
	0,
	0,
	'UI::UI::setIndicator',
	0);
INSERT INTO ACT_BLK
	VALUES (3120,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3119,
	0);
INSERT INTO ACT_SMT
	VALUES (3121,
	3120,
	0,
	1,
	1,
	'UI::UI::setIndicator line: 1');
INSERT INTO ACT_FNC
	VALUES (3121,
	3122,
	1,
	3);
INSERT INTO V_VAL
	VALUES (3123,
	0,
	0,
	1,
	33,
	41,
	0,
	0,
	0,
	0,
	358,
	3120);
INSERT INTO V_PVL
	VALUES (3123,
	0,
	0,
	0,
	1322);
INSERT INTO V_PAR
	VALUES (3123,
	3121,
	0,
	'indicator',
	0,
	1,
	17);
INSERT INTO C_PO
	VALUES (453,
	448,
	'TRACK',
	0,
	0);
INSERT INTO C_IR
	VALUES (456,
	86,
	0,
	453);
INSERT INTO C_R
	VALUES (456,
	'UI_Tracking',
	'',
	'Unnamed Interface',
	'UI::TRACK::UI_Tracking');
INSERT INTO SPR_REP
	VALUES (1324,
	88,
	456);
INSERT INTO SPR_RO
	VALUES (1324,
	'setTargetPressed',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (3124,
	1324);
INSERT INTO ACT_ACT
	VALUES (3124,
	'interface operation',
	0,
	3125,
	0,
	0,
	'TRACK::UI_Tracking::setTargetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3125,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3124,
	0);
INSERT INTO SPR_REP
	VALUES (1325,
	93,
	456);
INSERT INTO SPR_RO
	VALUES (1325,
	'startStopPressed',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (3126,
	1325);
INSERT INTO ACT_ACT
	VALUES (3126,
	'interface operation',
	0,
	3127,
	0,
	0,
	'TRACK::UI_Tracking::startStopPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3127,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3126,
	0);
INSERT INTO SPR_REP
	VALUES (1326,
	98,
	456);
INSERT INTO SPR_RO
	VALUES (1326,
	'lapResetPressed',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (3128,
	1326);
INSERT INTO ACT_ACT
	VALUES (3128,
	'interface operation',
	0,
	3129,
	0,
	0,
	'TRACK::UI_Tracking::lapResetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3129,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3128,
	0);
INSERT INTO SPR_REP
	VALUES (1327,
	103,
	456);
INSERT INTO SPR_RO
	VALUES (1327,
	'lightPressed',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (3130,
	1327);
INSERT INTO ACT_ACT
	VALUES (3130,
	'interface operation',
	0,
	3131,
	0,
	0,
	'TRACK::UI_Tracking::lightPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3131,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3130,
	0);
INSERT INTO SPR_REP
	VALUES (1328,
	108,
	456);
INSERT INTO SPR_RO
	VALUES (1328,
	'modePressed',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (3132,
	1328);
INSERT INTO ACT_ACT
	VALUES (3132,
	'interface operation',
	0,
	3133,
	0,
	0,
	'TRACK::UI_Tracking::modePressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3133,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3132,
	0);
INSERT INTO SPR_REP
	VALUES (1329,
	113,
	456);
INSERT INTO SPR_RO
	VALUES (1329,
	'newGoalSpec',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (3134,
	1329);
INSERT INTO ACT_ACT
	VALUES (3134,
	'interface operation',
	0,
	3135,
	0,
	0,
	'TRACK::UI_Tracking::newGoalSpec',
	0);
INSERT INTO ACT_BLK
	VALUES (3135,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3134,
	0);
INSERT INTO PE_PE
	VALUES (3136,
	1,
	0,
	448,
	7);
INSERT INTO EP_PKG
	VALUES (3136,
	0,
	3103,
	'External_Entities',
	'',
	0);
INSERT INTO PE_PE
	VALUES (3137,
	1,
	3136,
	0,
	5);
INSERT INTO S_EE
	VALUES (3137,
	'Graphical_User_Interface',
	'',
	'GuiBridge',
	0,
	'',
	'Graphical_User_Interface',
	1);
INSERT INTO S_BRG
	VALUES (3138,
	3137,
	'setData',
	'',
	0,
	1192,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (3139,
	3138,
	'value',
	153,
	0,
	'',
	0,
	'');
INSERT INTO S_BPARM
	VALUES (3140,
	3138,
	'unit',
	160,
	0,
	'',
	3139,
	'');
INSERT INTO ACT_BRB
	VALUES (3141,
	3138);
INSERT INTO ACT_ACT
	VALUES (3141,
	'bridge',
	0,
	3142,
	0,
	0,
	'Graphical_User_Interface::setData',
	0);
INSERT INTO ACT_BLK
	VALUES (3142,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3141,
	0);
INSERT INTO S_BRG
	VALUES (3143,
	3137,
	'setTime',
	'',
	0,
	1192,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (3144,
	3143,
	'time',
	160,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (3145,
	3143);
INSERT INTO ACT_ACT
	VALUES (3145,
	'bridge',
	0,
	3146,
	0,
	0,
	'Graphical_User_Interface::setTime',
	0);
INSERT INTO ACT_BLK
	VALUES (3146,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3145,
	0);
INSERT INTO S_BRG
	VALUES (3147,
	3137,
	'connect',
	'',
	0,
	160,
	'',
	1,
	'',
	0);
INSERT INTO ACT_BRB
	VALUES (3148,
	3147);
INSERT INTO ACT_ACT
	VALUES (3148,
	'bridge',
	0,
	3149,
	0,
	0,
	'Graphical_User_Interface::connect',
	0);
INSERT INTO ACT_BLK
	VALUES (3149,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3148,
	0);
INSERT INTO S_BRG
	VALUES (3150,
	3137,
	'setIndicator',
	'',
	0,
	1192,
	'',
	1,
	'',
	0);
INSERT INTO S_BPARM
	VALUES (3151,
	3150,
	'value',
	160,
	0,
	'',
	0,
	'');
INSERT INTO ACT_BRB
	VALUES (3152,
	3150);
INSERT INTO ACT_ACT
	VALUES (3152,
	'bridge',
	0,
	3153,
	0,
	0,
	'Graphical_User_Interface::setIndicator',
	0);
INSERT INTO ACT_BLK
	VALUES (3153,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3152,
	0);
INSERT INTO S_BRG
	VALUES (3154,
	3137,
	'poll',
	'',
	0,
	160,
	'',
	1,
	'',
	0);
INSERT INTO ACT_BRB
	VALUES (3155,
	3154);
INSERT INTO ACT_ACT
	VALUES (3155,
	'bridge',
	0,
	3156,
	0,
	0,
	'Graphical_User_Interface::poll',
	0);
INSERT INTO ACT_BLK
	VALUES (3156,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3155,
	0);
INSERT INTO PE_PE
	VALUES (3157,
	1,
	0,
	448,
	7);
INSERT INTO EP_PKG
	VALUES (3157,
	0,
	3103,
	'PublicFunctions',
	'',
	0);
INSERT INTO PE_PE
	VALUES (3112,
	1,
	3157,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3112,
	0,
	'setData',
	'',
	'select any ui from instances of UI;
if ( not_empty ui )
  if (param.unit == UIUnit::km)
    ui.setData(value: param.value, unit: 0);
  elif (param.unit == UIUnit::meters)
    ui.setData(value: param.value, unit: 1);
  elif (param.unit == UIUnit::minPerKm)
    ui.setData(value: param.value, unit: 2);
  elif (param.unit == UIUnit::kmPerHour)
    ui.setData(value: param.value, unit: 3);
  elif (param.unit == UIUnit::miles)
    ui.setData(value: param.value, unit: 4);
  elif (param.unit == UIUnit::yards)
    ui.setData(value: param.value, unit: 5);
  elif (param.unit == UIUnit::feet)
    ui.setData(value: param.value, unit: 6);
  elif (param.unit == UIUnit::minPerMile)
    ui.setData(value: param.value, unit: 7);
  elif (param.unit == UIUnit::mph)
    ui.setData(value: param.value, unit: 8);
  elif (param.unit == UIUnit::bpm)
    ui.setData(value: param.value, unit: 9);
  elif (param.unit == UIUnit::laps)
    ui.setData(value: param.value, unit: 10);
  end if;
end if;',
	1192,
	1,
	'',
	0);
INSERT INTO S_SPARM
	VALUES (3158,
	3112,
	'value',
	153,
	0,
	'',
	0,
	'');
INSERT INTO S_SPARM
	VALUES (3159,
	3112,
	'unit',
	284,
	0,
	'',
	3158,
	'');
INSERT INTO ACT_FNB
	VALUES (3160,
	3112);
INSERT INTO ACT_ACT
	VALUES (3160,
	'function',
	0,
	3161,
	0,
	0,
	'setData',
	0);
INSERT INTO ACT_BLK
	VALUES (3161,
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	33,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3160,
	0);
INSERT INTO ACT_SMT
	VALUES (3162,
	3161,
	3163,
	1,
	1,
	'setData line: 1');
INSERT INTO ACT_FIO
	VALUES (3162,
	3164,
	1,
	'any',
	3165,
	1,
	33);
INSERT INTO ACT_SMT
	VALUES (3163,
	3161,
	0,
	2,
	1,
	'setData line: 2');
INSERT INTO ACT_IF
	VALUES (3163,
	3166,
	3167,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3168,
	0,
	0,
	2,
	16,
	17,
	0,
	0,
	0,
	0,
	1309,
	3161);
INSERT INTO V_IRF
	VALUES (3168,
	3164);
INSERT INTO V_VAL
	VALUES (3167,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	3161);
INSERT INTO V_UNY
	VALUES (3167,
	3168,
	'not_empty');
INSERT INTO V_VAR
	VALUES (3164,
	3161,
	'ui',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3164,
	0,
	3165);
INSERT INTO ACT_BLK
	VALUES (3166,
	0,
	0,
	0,
	'',
	'',
	'',
	23,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	23,
	23,
	0,
	3160,
	0);
INSERT INTO ACT_SMT
	VALUES (3169,
	3166,
	0,
	3,
	3,
	'setData line: 3');
INSERT INTO ACT_IF
	VALUES (3169,
	3170,
	3171,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3172,
	3166,
	0,
	5,
	3,
	'setData line: 5');
INSERT INTO ACT_EL
	VALUES (3172,
	3173,
	3174,
	3169);
INSERT INTO ACT_SMT
	VALUES (3175,
	3166,
	0,
	7,
	3,
	'setData line: 7');
INSERT INTO ACT_EL
	VALUES (3175,
	3176,
	3177,
	3169);
INSERT INTO ACT_SMT
	VALUES (3178,
	3166,
	0,
	9,
	3,
	'setData line: 9');
INSERT INTO ACT_EL
	VALUES (3178,
	3179,
	3180,
	3169);
INSERT INTO ACT_SMT
	VALUES (3181,
	3166,
	0,
	11,
	3,
	'setData line: 11');
INSERT INTO ACT_EL
	VALUES (3181,
	3182,
	3183,
	3169);
INSERT INTO ACT_SMT
	VALUES (3184,
	3166,
	0,
	13,
	3,
	'setData line: 13');
INSERT INTO ACT_EL
	VALUES (3184,
	3185,
	3186,
	3169);
INSERT INTO ACT_SMT
	VALUES (3187,
	3166,
	0,
	15,
	3,
	'setData line: 15');
INSERT INTO ACT_EL
	VALUES (3187,
	3188,
	3189,
	3169);
INSERT INTO ACT_SMT
	VALUES (3190,
	3166,
	0,
	17,
	3,
	'setData line: 17');
INSERT INTO ACT_EL
	VALUES (3190,
	3191,
	3192,
	3169);
INSERT INTO ACT_SMT
	VALUES (3193,
	3166,
	0,
	19,
	3,
	'setData line: 19');
INSERT INTO ACT_EL
	VALUES (3193,
	3194,
	3195,
	3169);
INSERT INTO ACT_SMT
	VALUES (3196,
	3166,
	0,
	21,
	3,
	'setData line: 21');
INSERT INTO ACT_EL
	VALUES (3196,
	3197,
	3198,
	3169);
INSERT INTO ACT_SMT
	VALUES (3199,
	3166,
	0,
	23,
	3,
	'setData line: 23');
INSERT INTO ACT_EL
	VALUES (3199,
	3200,
	3201,
	3169);
INSERT INTO V_VAL
	VALUES (3202,
	0,
	0,
	3,
	13,
	16,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_PVL
	VALUES (3202,
	0,
	3159,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3171,
	0,
	0,
	3,
	13,
	30,
	0,
	0,
	0,
	0,
	125,
	3166);
INSERT INTO V_BIN
	VALUES (3171,
	3203,
	3202,
	'==');
INSERT INTO V_VAL
	VALUES (3203,
	0,
	0,
	3,
	29,
	30,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_LEN
	VALUES (3203,
	285,
	3,
	21);
INSERT INTO V_VAL
	VALUES (3204,
	0,
	0,
	5,
	15,
	18,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_PVL
	VALUES (3204,
	0,
	3159,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3174,
	0,
	0,
	5,
	15,
	36,
	0,
	0,
	0,
	0,
	125,
	3166);
INSERT INTO V_BIN
	VALUES (3174,
	3205,
	3204,
	'==');
INSERT INTO V_VAL
	VALUES (3205,
	0,
	0,
	5,
	31,
	36,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_LEN
	VALUES (3205,
	289,
	5,
	23);
INSERT INTO V_VAL
	VALUES (3206,
	0,
	0,
	7,
	15,
	18,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_PVL
	VALUES (3206,
	0,
	3159,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3177,
	0,
	0,
	7,
	15,
	38,
	0,
	0,
	0,
	0,
	125,
	3166);
INSERT INTO V_BIN
	VALUES (3177,
	3207,
	3206,
	'==');
INSERT INTO V_VAL
	VALUES (3207,
	0,
	0,
	7,
	31,
	38,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_LEN
	VALUES (3207,
	293,
	7,
	23);
INSERT INTO V_VAL
	VALUES (3208,
	0,
	0,
	9,
	15,
	18,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_PVL
	VALUES (3208,
	0,
	3159,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3180,
	0,
	0,
	9,
	15,
	39,
	0,
	0,
	0,
	0,
	125,
	3166);
INSERT INTO V_BIN
	VALUES (3180,
	3209,
	3208,
	'==');
INSERT INTO V_VAL
	VALUES (3209,
	0,
	0,
	9,
	31,
	39,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_LEN
	VALUES (3209,
	297,
	9,
	23);
INSERT INTO V_VAL
	VALUES (3210,
	0,
	0,
	11,
	15,
	18,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_PVL
	VALUES (3210,
	0,
	3159,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3183,
	0,
	0,
	11,
	15,
	35,
	0,
	0,
	0,
	0,
	125,
	3166);
INSERT INTO V_BIN
	VALUES (3183,
	3211,
	3210,
	'==');
INSERT INTO V_VAL
	VALUES (3211,
	0,
	0,
	11,
	31,
	35,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_LEN
	VALUES (3211,
	301,
	11,
	23);
INSERT INTO V_VAL
	VALUES (3212,
	0,
	0,
	13,
	15,
	18,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_PVL
	VALUES (3212,
	0,
	3159,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3186,
	0,
	0,
	13,
	15,
	35,
	0,
	0,
	0,
	0,
	125,
	3166);
INSERT INTO V_BIN
	VALUES (3186,
	3213,
	3212,
	'==');
INSERT INTO V_VAL
	VALUES (3213,
	0,
	0,
	13,
	31,
	35,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_LEN
	VALUES (3213,
	305,
	13,
	23);
INSERT INTO V_VAL
	VALUES (3214,
	0,
	0,
	15,
	15,
	18,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_PVL
	VALUES (3214,
	0,
	3159,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3189,
	0,
	0,
	15,
	15,
	34,
	0,
	0,
	0,
	0,
	125,
	3166);
INSERT INTO V_BIN
	VALUES (3189,
	3215,
	3214,
	'==');
INSERT INTO V_VAL
	VALUES (3215,
	0,
	0,
	15,
	31,
	34,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_LEN
	VALUES (3215,
	309,
	15,
	23);
INSERT INTO V_VAL
	VALUES (3216,
	0,
	0,
	17,
	15,
	18,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_PVL
	VALUES (3216,
	0,
	3159,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3192,
	0,
	0,
	17,
	15,
	40,
	0,
	0,
	0,
	0,
	125,
	3166);
INSERT INTO V_BIN
	VALUES (3192,
	3217,
	3216,
	'==');
INSERT INTO V_VAL
	VALUES (3217,
	0,
	0,
	17,
	31,
	40,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_LEN
	VALUES (3217,
	313,
	17,
	23);
INSERT INTO V_VAL
	VALUES (3218,
	0,
	0,
	19,
	15,
	18,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_PVL
	VALUES (3218,
	0,
	3159,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3195,
	0,
	0,
	19,
	15,
	33,
	0,
	0,
	0,
	0,
	125,
	3166);
INSERT INTO V_BIN
	VALUES (3195,
	3219,
	3218,
	'==');
INSERT INTO V_VAL
	VALUES (3219,
	0,
	0,
	19,
	31,
	33,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_LEN
	VALUES (3219,
	317,
	19,
	23);
INSERT INTO V_VAL
	VALUES (3220,
	0,
	0,
	21,
	15,
	18,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_PVL
	VALUES (3220,
	0,
	3159,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3198,
	0,
	0,
	21,
	15,
	33,
	0,
	0,
	0,
	0,
	125,
	3166);
INSERT INTO V_BIN
	VALUES (3198,
	3221,
	3220,
	'==');
INSERT INTO V_VAL
	VALUES (3221,
	0,
	0,
	21,
	31,
	33,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_LEN
	VALUES (3221,
	321,
	21,
	23);
INSERT INTO V_VAL
	VALUES (3222,
	0,
	0,
	23,
	15,
	18,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_PVL
	VALUES (3222,
	0,
	3159,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3201,
	0,
	0,
	23,
	15,
	34,
	0,
	0,
	0,
	0,
	125,
	3166);
INSERT INTO V_BIN
	VALUES (3201,
	3223,
	3222,
	'==');
INSERT INTO V_VAL
	VALUES (3223,
	0,
	0,
	23,
	31,
	34,
	0,
	0,
	0,
	0,
	284,
	3166);
INSERT INTO V_LEN
	VALUES (3223,
	325,
	23,
	23);
INSERT INTO ACT_BLK
	VALUES (3170,
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3160,
	0);
INSERT INTO ACT_SMT
	VALUES (3224,
	3170,
	0,
	4,
	5,
	'setData line: 4');
INSERT INTO ACT_TFM
	VALUES (3224,
	3225,
	3164,
	4,
	8,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3226,
	0,
	0,
	4,
	29,
	33,
	0,
	0,
	0,
	0,
	153,
	3170);
INSERT INTO V_PVL
	VALUES (3226,
	0,
	3158,
	0,
	0);
INSERT INTO V_PAR
	VALUES (3226,
	3224,
	0,
	'value',
	3227,
	4,
	16);
INSERT INTO V_VAL
	VALUES (3227,
	0,
	0,
	4,
	42,
	42,
	0,
	0,
	0,
	0,
	160,
	3170);
INSERT INTO V_LIN
	VALUES (3227,
	'0');
INSERT INTO V_PAR
	VALUES (3227,
	3224,
	0,
	'unit',
	0,
	4,
	36);
INSERT INTO ACT_BLK
	VALUES (3173,
	0,
	0,
	0,
	'',
	'',
	'',
	6,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3160,
	0);
INSERT INTO ACT_SMT
	VALUES (3228,
	3173,
	0,
	6,
	5,
	'setData line: 6');
INSERT INTO ACT_TFM
	VALUES (3228,
	3225,
	3164,
	6,
	8,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3229,
	0,
	0,
	6,
	29,
	33,
	0,
	0,
	0,
	0,
	153,
	3173);
INSERT INTO V_PVL
	VALUES (3229,
	0,
	3158,
	0,
	0);
INSERT INTO V_PAR
	VALUES (3229,
	3228,
	0,
	'value',
	3230,
	6,
	16);
INSERT INTO V_VAL
	VALUES (3230,
	0,
	0,
	6,
	42,
	42,
	0,
	0,
	0,
	0,
	160,
	3173);
INSERT INTO V_LIN
	VALUES (3230,
	'1');
INSERT INTO V_PAR
	VALUES (3230,
	3228,
	0,
	'unit',
	0,
	6,
	36);
INSERT INTO ACT_BLK
	VALUES (3176,
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3160,
	0);
INSERT INTO ACT_SMT
	VALUES (3231,
	3176,
	0,
	8,
	5,
	'setData line: 8');
INSERT INTO ACT_TFM
	VALUES (3231,
	3225,
	3164,
	8,
	8,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3232,
	0,
	0,
	8,
	29,
	33,
	0,
	0,
	0,
	0,
	153,
	3176);
INSERT INTO V_PVL
	VALUES (3232,
	0,
	3158,
	0,
	0);
INSERT INTO V_PAR
	VALUES (3232,
	3231,
	0,
	'value',
	3233,
	8,
	16);
INSERT INTO V_VAL
	VALUES (3233,
	0,
	0,
	8,
	42,
	42,
	0,
	0,
	0,
	0,
	160,
	3176);
INSERT INTO V_LIN
	VALUES (3233,
	'2');
INSERT INTO V_PAR
	VALUES (3233,
	3231,
	0,
	'unit',
	0,
	8,
	36);
INSERT INTO ACT_BLK
	VALUES (3179,
	0,
	0,
	0,
	'',
	'',
	'',
	10,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3160,
	0);
INSERT INTO ACT_SMT
	VALUES (3234,
	3179,
	0,
	10,
	5,
	'setData line: 10');
INSERT INTO ACT_TFM
	VALUES (3234,
	3225,
	3164,
	10,
	8,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3235,
	0,
	0,
	10,
	29,
	33,
	0,
	0,
	0,
	0,
	153,
	3179);
INSERT INTO V_PVL
	VALUES (3235,
	0,
	3158,
	0,
	0);
INSERT INTO V_PAR
	VALUES (3235,
	3234,
	0,
	'value',
	3236,
	10,
	16);
INSERT INTO V_VAL
	VALUES (3236,
	0,
	0,
	10,
	42,
	42,
	0,
	0,
	0,
	0,
	160,
	3179);
INSERT INTO V_LIN
	VALUES (3236,
	'3');
INSERT INTO V_PAR
	VALUES (3236,
	3234,
	0,
	'unit',
	0,
	10,
	36);
INSERT INTO ACT_BLK
	VALUES (3182,
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3160,
	0);
INSERT INTO ACT_SMT
	VALUES (3237,
	3182,
	0,
	12,
	5,
	'setData line: 12');
INSERT INTO ACT_TFM
	VALUES (3237,
	3225,
	3164,
	12,
	8,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3238,
	0,
	0,
	12,
	29,
	33,
	0,
	0,
	0,
	0,
	153,
	3182);
INSERT INTO V_PVL
	VALUES (3238,
	0,
	3158,
	0,
	0);
INSERT INTO V_PAR
	VALUES (3238,
	3237,
	0,
	'value',
	3239,
	12,
	16);
INSERT INTO V_VAL
	VALUES (3239,
	0,
	0,
	12,
	42,
	42,
	0,
	0,
	0,
	0,
	160,
	3182);
INSERT INTO V_LIN
	VALUES (3239,
	'4');
INSERT INTO V_PAR
	VALUES (3239,
	3237,
	0,
	'unit',
	0,
	12,
	36);
INSERT INTO ACT_BLK
	VALUES (3185,
	0,
	0,
	0,
	'',
	'',
	'',
	14,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3160,
	0);
INSERT INTO ACT_SMT
	VALUES (3240,
	3185,
	0,
	14,
	5,
	'setData line: 14');
INSERT INTO ACT_TFM
	VALUES (3240,
	3225,
	3164,
	14,
	8,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3241,
	0,
	0,
	14,
	29,
	33,
	0,
	0,
	0,
	0,
	153,
	3185);
INSERT INTO V_PVL
	VALUES (3241,
	0,
	3158,
	0,
	0);
INSERT INTO V_PAR
	VALUES (3241,
	3240,
	0,
	'value',
	3242,
	14,
	16);
INSERT INTO V_VAL
	VALUES (3242,
	0,
	0,
	14,
	42,
	42,
	0,
	0,
	0,
	0,
	160,
	3185);
INSERT INTO V_LIN
	VALUES (3242,
	'5');
INSERT INTO V_PAR
	VALUES (3242,
	3240,
	0,
	'unit',
	0,
	14,
	36);
INSERT INTO ACT_BLK
	VALUES (3188,
	0,
	0,
	0,
	'',
	'',
	'',
	16,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3160,
	0);
INSERT INTO ACT_SMT
	VALUES (3243,
	3188,
	0,
	16,
	5,
	'setData line: 16');
INSERT INTO ACT_TFM
	VALUES (3243,
	3225,
	3164,
	16,
	8,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3244,
	0,
	0,
	16,
	29,
	33,
	0,
	0,
	0,
	0,
	153,
	3188);
INSERT INTO V_PVL
	VALUES (3244,
	0,
	3158,
	0,
	0);
INSERT INTO V_PAR
	VALUES (3244,
	3243,
	0,
	'value',
	3245,
	16,
	16);
INSERT INTO V_VAL
	VALUES (3245,
	0,
	0,
	16,
	42,
	42,
	0,
	0,
	0,
	0,
	160,
	3188);
INSERT INTO V_LIN
	VALUES (3245,
	'6');
INSERT INTO V_PAR
	VALUES (3245,
	3243,
	0,
	'unit',
	0,
	16,
	36);
INSERT INTO ACT_BLK
	VALUES (3191,
	0,
	0,
	0,
	'',
	'',
	'',
	18,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3160,
	0);
INSERT INTO ACT_SMT
	VALUES (3246,
	3191,
	0,
	18,
	5,
	'setData line: 18');
INSERT INTO ACT_TFM
	VALUES (3246,
	3225,
	3164,
	18,
	8,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3247,
	0,
	0,
	18,
	29,
	33,
	0,
	0,
	0,
	0,
	153,
	3191);
INSERT INTO V_PVL
	VALUES (3247,
	0,
	3158,
	0,
	0);
INSERT INTO V_PAR
	VALUES (3247,
	3246,
	0,
	'value',
	3248,
	18,
	16);
INSERT INTO V_VAL
	VALUES (3248,
	0,
	0,
	18,
	42,
	42,
	0,
	0,
	0,
	0,
	160,
	3191);
INSERT INTO V_LIN
	VALUES (3248,
	'7');
INSERT INTO V_PAR
	VALUES (3248,
	3246,
	0,
	'unit',
	0,
	18,
	36);
INSERT INTO ACT_BLK
	VALUES (3194,
	0,
	0,
	0,
	'',
	'',
	'',
	20,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3160,
	0);
INSERT INTO ACT_SMT
	VALUES (3249,
	3194,
	0,
	20,
	5,
	'setData line: 20');
INSERT INTO ACT_TFM
	VALUES (3249,
	3225,
	3164,
	20,
	8,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3250,
	0,
	0,
	20,
	29,
	33,
	0,
	0,
	0,
	0,
	153,
	3194);
INSERT INTO V_PVL
	VALUES (3250,
	0,
	3158,
	0,
	0);
INSERT INTO V_PAR
	VALUES (3250,
	3249,
	0,
	'value',
	3251,
	20,
	16);
INSERT INTO V_VAL
	VALUES (3251,
	0,
	0,
	20,
	42,
	42,
	0,
	0,
	0,
	0,
	160,
	3194);
INSERT INTO V_LIN
	VALUES (3251,
	'8');
INSERT INTO V_PAR
	VALUES (3251,
	3249,
	0,
	'unit',
	0,
	20,
	36);
INSERT INTO ACT_BLK
	VALUES (3197,
	0,
	0,
	0,
	'',
	'',
	'',
	22,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3160,
	0);
INSERT INTO ACT_SMT
	VALUES (3252,
	3197,
	0,
	22,
	5,
	'setData line: 22');
INSERT INTO ACT_TFM
	VALUES (3252,
	3225,
	3164,
	22,
	8,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3253,
	0,
	0,
	22,
	29,
	33,
	0,
	0,
	0,
	0,
	153,
	3197);
INSERT INTO V_PVL
	VALUES (3253,
	0,
	3158,
	0,
	0);
INSERT INTO V_PAR
	VALUES (3253,
	3252,
	0,
	'value',
	3254,
	22,
	16);
INSERT INTO V_VAL
	VALUES (3254,
	0,
	0,
	22,
	42,
	42,
	0,
	0,
	0,
	0,
	160,
	3197);
INSERT INTO V_LIN
	VALUES (3254,
	'9');
INSERT INTO V_PAR
	VALUES (3254,
	3252,
	0,
	'unit',
	0,
	22,
	36);
INSERT INTO ACT_BLK
	VALUES (3200,
	0,
	0,
	0,
	'',
	'',
	'',
	24,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3160,
	0);
INSERT INTO ACT_SMT
	VALUES (3255,
	3200,
	0,
	24,
	5,
	'setData line: 24');
INSERT INTO ACT_TFM
	VALUES (3255,
	3225,
	3164,
	24,
	8,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3256,
	0,
	0,
	24,
	29,
	33,
	0,
	0,
	0,
	0,
	153,
	3200);
INSERT INTO V_PVL
	VALUES (3256,
	0,
	3158,
	0,
	0);
INSERT INTO V_PAR
	VALUES (3256,
	3255,
	0,
	'value',
	3257,
	24,
	16);
INSERT INTO V_VAL
	VALUES (3257,
	0,
	0,
	24,
	42,
	43,
	0,
	0,
	0,
	0,
	160,
	3200);
INSERT INTO V_LIN
	VALUES (3257,
	'10');
INSERT INTO V_PAR
	VALUES (3257,
	3255,
	0,
	'unit',
	0,
	24,
	36);
INSERT INTO PE_PE
	VALUES (3122,
	1,
	3157,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3122,
	0,
	'setIndicator',
	'',
	'// Map values of UIDatatypes/UIIndicator to values defined in WatchGUI.java.
select any ui from instances of UI;
if ( not_empty ui )
  if ( param.indicator == UIIndicator::Blank  )
    ui.setIndicator( value: 0 );
  elif ( param.indicator == UIIndicator::Down )
    ui.setIndicator( value: 1 );
  elif ( param.indicator == UIIndicator::Flat )
    ui.setIndicator( value: 2 );
  elif ( param.indicator == UIIndicator::Up )
    ui.setIndicator( value: 3 );
  end if;
end if;',
	1192,
	1,
	'',
	0);
INSERT INTO S_SPARM
	VALUES (3258,
	3122,
	'indicator',
	358,
	0,
	'',
	0,
	'');
INSERT INTO ACT_FNB
	VALUES (3259,
	3122);
INSERT INTO ACT_ACT
	VALUES (3259,
	'function',
	0,
	3260,
	0,
	0,
	'setIndicator',
	0);
INSERT INTO ACT_BLK
	VALUES (3260,
	1,
	0,
	0,
	'',
	'',
	'',
	3,
	1,
	2,
	33,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3259,
	0);
INSERT INTO ACT_SMT
	VALUES (3261,
	3260,
	3262,
	2,
	1,
	'setIndicator line: 2');
INSERT INTO ACT_FIO
	VALUES (3261,
	3263,
	1,
	'any',
	3165,
	2,
	33);
INSERT INTO ACT_SMT
	VALUES (3262,
	3260,
	0,
	3,
	1,
	'setIndicator line: 3');
INSERT INTO ACT_IF
	VALUES (3262,
	3264,
	3265,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3266,
	0,
	0,
	3,
	16,
	17,
	0,
	0,
	0,
	0,
	1309,
	3260);
INSERT INTO V_IRF
	VALUES (3266,
	3263);
INSERT INTO V_VAL
	VALUES (3265,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	3260);
INSERT INTO V_UNY
	VALUES (3265,
	3266,
	'not_empty');
INSERT INTO V_VAR
	VALUES (3263,
	3260,
	'ui',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3263,
	0,
	3165);
INSERT INTO ACT_BLK
	VALUES (3264,
	0,
	0,
	0,
	'',
	'',
	'',
	10,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	10,
	29,
	0,
	3259,
	0);
INSERT INTO ACT_SMT
	VALUES (3267,
	3264,
	0,
	4,
	3,
	'setIndicator line: 4');
INSERT INTO ACT_IF
	VALUES (3267,
	3268,
	3269,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3270,
	3264,
	0,
	6,
	3,
	'setIndicator line: 6');
INSERT INTO ACT_EL
	VALUES (3270,
	3271,
	3272,
	3267);
INSERT INTO ACT_SMT
	VALUES (3273,
	3264,
	0,
	8,
	3,
	'setIndicator line: 8');
INSERT INTO ACT_EL
	VALUES (3273,
	3274,
	3275,
	3267);
INSERT INTO ACT_SMT
	VALUES (3276,
	3264,
	0,
	10,
	3,
	'setIndicator line: 10');
INSERT INTO ACT_EL
	VALUES (3276,
	3277,
	3278,
	3267);
INSERT INTO V_VAL
	VALUES (3279,
	0,
	0,
	4,
	14,
	22,
	0,
	0,
	0,
	0,
	358,
	3264);
INSERT INTO V_PVL
	VALUES (3279,
	0,
	3258,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3269,
	0,
	0,
	4,
	14,
	44,
	0,
	0,
	0,
	0,
	125,
	3264);
INSERT INTO V_BIN
	VALUES (3269,
	3280,
	3279,
	'==');
INSERT INTO V_VAL
	VALUES (3280,
	0,
	0,
	4,
	40,
	44,
	0,
	0,
	0,
	0,
	358,
	3264);
INSERT INTO V_LEN
	VALUES (3280,
	359,
	4,
	27);
INSERT INTO V_VAL
	VALUES (3281,
	0,
	0,
	6,
	16,
	24,
	0,
	0,
	0,
	0,
	358,
	3264);
INSERT INTO V_PVL
	VALUES (3281,
	0,
	3258,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3272,
	0,
	0,
	6,
	16,
	45,
	0,
	0,
	0,
	0,
	125,
	3264);
INSERT INTO V_BIN
	VALUES (3272,
	3282,
	3281,
	'==');
INSERT INTO V_VAL
	VALUES (3282,
	0,
	0,
	6,
	42,
	45,
	0,
	0,
	0,
	0,
	358,
	3264);
INSERT INTO V_LEN
	VALUES (3282,
	362,
	6,
	29);
INSERT INTO V_VAL
	VALUES (3283,
	0,
	0,
	8,
	16,
	24,
	0,
	0,
	0,
	0,
	358,
	3264);
INSERT INTO V_PVL
	VALUES (3283,
	0,
	3258,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3275,
	0,
	0,
	8,
	16,
	45,
	0,
	0,
	0,
	0,
	125,
	3264);
INSERT INTO V_BIN
	VALUES (3275,
	3284,
	3283,
	'==');
INSERT INTO V_VAL
	VALUES (3284,
	0,
	0,
	8,
	42,
	45,
	0,
	0,
	0,
	0,
	358,
	3264);
INSERT INTO V_LEN
	VALUES (3284,
	365,
	8,
	29);
INSERT INTO V_VAL
	VALUES (3285,
	0,
	0,
	10,
	16,
	24,
	0,
	0,
	0,
	0,
	358,
	3264);
INSERT INTO V_PVL
	VALUES (3285,
	0,
	3258,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3278,
	0,
	0,
	10,
	16,
	43,
	0,
	0,
	0,
	0,
	125,
	3264);
INSERT INTO V_BIN
	VALUES (3278,
	3286,
	3285,
	'==');
INSERT INTO V_VAL
	VALUES (3286,
	0,
	0,
	10,
	42,
	43,
	0,
	0,
	0,
	0,
	358,
	3264);
INSERT INTO V_LEN
	VALUES (3286,
	368,
	10,
	29);
INSERT INTO ACT_BLK
	VALUES (3268,
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3259,
	0);
INSERT INTO ACT_SMT
	VALUES (3287,
	3268,
	0,
	5,
	5,
	'setIndicator line: 5');
INSERT INTO ACT_TFM
	VALUES (3287,
	3288,
	3263,
	5,
	8,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3289,
	0,
	0,
	5,
	29,
	29,
	0,
	0,
	0,
	0,
	160,
	3268);
INSERT INTO V_LIN
	VALUES (3289,
	'0');
INSERT INTO V_PAR
	VALUES (3289,
	3287,
	0,
	'value',
	0,
	5,
	22);
INSERT INTO ACT_BLK
	VALUES (3271,
	0,
	0,
	0,
	'',
	'',
	'',
	7,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3259,
	0);
INSERT INTO ACT_SMT
	VALUES (3290,
	3271,
	0,
	7,
	5,
	'setIndicator line: 7');
INSERT INTO ACT_TFM
	VALUES (3290,
	3288,
	3263,
	7,
	8,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3291,
	0,
	0,
	7,
	29,
	29,
	0,
	0,
	0,
	0,
	160,
	3271);
INSERT INTO V_LIN
	VALUES (3291,
	'1');
INSERT INTO V_PAR
	VALUES (3291,
	3290,
	0,
	'value',
	0,
	7,
	22);
INSERT INTO ACT_BLK
	VALUES (3274,
	0,
	0,
	0,
	'',
	'',
	'',
	9,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3259,
	0);
INSERT INTO ACT_SMT
	VALUES (3292,
	3274,
	0,
	9,
	5,
	'setIndicator line: 9');
INSERT INTO ACT_TFM
	VALUES (3292,
	3288,
	3263,
	9,
	8,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3293,
	0,
	0,
	9,
	29,
	29,
	0,
	0,
	0,
	0,
	160,
	3274);
INSERT INTO V_LIN
	VALUES (3293,
	'2');
INSERT INTO V_PAR
	VALUES (3293,
	3292,
	0,
	'value',
	0,
	9,
	22);
INSERT INTO ACT_BLK
	VALUES (3277,
	0,
	0,
	0,
	'',
	'',
	'',
	11,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3259,
	0);
INSERT INTO ACT_SMT
	VALUES (3294,
	3277,
	0,
	11,
	5,
	'setIndicator line: 11');
INSERT INTO ACT_TFM
	VALUES (3294,
	3288,
	3263,
	11,
	8,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3295,
	0,
	0,
	11,
	29,
	29,
	0,
	0,
	0,
	0,
	160,
	3277);
INSERT INTO V_LIN
	VALUES (3295,
	'3');
INSERT INTO V_PAR
	VALUES (3295,
	3294,
	0,
	'value',
	0,
	11,
	22);
INSERT INTO PE_PE
	VALUES (3107,
	1,
	3157,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3107,
	0,
	'setTime',
	'',
	'select any ui from instances of UI;
if ( not_empty ui )
  ui.setTime(time: param.time);
end if;',
	1192,
	1,
	'',
	0);
INSERT INTO S_SPARM
	VALUES (3296,
	3107,
	'time',
	160,
	0,
	'',
	0,
	'');
INSERT INTO ACT_FNB
	VALUES (3297,
	3107);
INSERT INTO ACT_ACT
	VALUES (3297,
	'function',
	0,
	3298,
	0,
	0,
	'setTime',
	0);
INSERT INTO ACT_BLK
	VALUES (3298,
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	33,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3297,
	0);
INSERT INTO ACT_SMT
	VALUES (3299,
	3298,
	3300,
	1,
	1,
	'setTime line: 1');
INSERT INTO ACT_FIO
	VALUES (3299,
	3301,
	1,
	'any',
	3165,
	1,
	33);
INSERT INTO ACT_SMT
	VALUES (3300,
	3298,
	0,
	2,
	1,
	'setTime line: 2');
INSERT INTO ACT_IF
	VALUES (3300,
	3302,
	3303,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3304,
	0,
	0,
	2,
	16,
	17,
	0,
	0,
	0,
	0,
	1309,
	3298);
INSERT INTO V_IRF
	VALUES (3304,
	3301);
INSERT INTO V_VAL
	VALUES (3303,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	3298);
INSERT INTO V_UNY
	VALUES (3303,
	3304,
	'not_empty');
INSERT INTO V_VAR
	VALUES (3301,
	3298,
	'ui',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3301,
	0,
	3165);
INSERT INTO ACT_BLK
	VALUES (3302,
	0,
	0,
	0,
	'',
	'',
	'',
	3,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3297,
	0);
INSERT INTO ACT_SMT
	VALUES (3305,
	3302,
	0,
	3,
	3,
	'setTime line: 3');
INSERT INTO ACT_TFM
	VALUES (3305,
	3306,
	3301,
	3,
	6,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3307,
	0,
	0,
	3,
	26,
	29,
	0,
	0,
	0,
	0,
	160,
	3302);
INSERT INTO V_PVL
	VALUES (3307,
	0,
	3296,
	0,
	0);
INSERT INTO V_PAR
	VALUES (3307,
	3305,
	0,
	'time',
	0,
	3,
	14);
INSERT INTO PE_PE
	VALUES (3118,
	1,
	3157,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3118,
	0,
	'startTest',
	'',
	'create object instance tc of TestCase; tc.id = 1;
generate TestCase5:initialize( iterations: 2 ) to tc;',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (3308,
	3118);
INSERT INTO ACT_ACT
	VALUES (3308,
	'function',
	0,
	3309,
	0,
	0,
	'startTest',
	0);
INSERT INTO ACT_BLK
	VALUES (3309,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'iterations',
	'iterations',
	2,
	1,
	1,
	30,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3308,
	0);
INSERT INTO ACT_SMT
	VALUES (3310,
	3309,
	3311,
	1,
	1,
	'startTest line: 1');
INSERT INTO ACT_CR
	VALUES (3310,
	3312,
	1,
	3313,
	1,
	30);
INSERT INTO ACT_SMT
	VALUES (3311,
	3309,
	3314,
	1,
	40,
	'startTest line: 1');
INSERT INTO ACT_AI
	VALUES (3311,
	3315,
	3316,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3314,
	3309,
	0,
	2,
	1,
	'startTest line: 2');
INSERT INTO E_ESS
	VALUES (3314,
	1,
	0,
	2,
	10,
	2,
	20,
	1,
	30,
	2,
	32,
	0,
	0);
INSERT INTO V_PAR
	VALUES (3317,
	3314,
	0,
	'iterations',
	0,
	2,
	32);
INSERT INTO E_GES
	VALUES (3314);
INSERT INTO E_GSME
	VALUES (3314,
	3318);
INSERT INTO E_GEN
	VALUES (3314,
	3312);
INSERT INTO V_VAL
	VALUES (3319,
	1,
	0,
	1,
	40,
	41,
	0,
	0,
	0,
	0,
	1309,
	3309);
INSERT INTO V_IRF
	VALUES (3319,
	3312);
INSERT INTO V_VAL
	VALUES (3316,
	1,
	0,
	1,
	43,
	44,
	0,
	0,
	0,
	0,
	160,
	3309);
INSERT INTO V_AVL
	VALUES (3316,
	3319,
	3313,
	3320);
INSERT INTO V_VAL
	VALUES (3315,
	0,
	0,
	1,
	48,
	48,
	0,
	0,
	0,
	0,
	160,
	3309);
INSERT INTO V_LIN
	VALUES (3315,
	'1');
INSERT INTO V_VAL
	VALUES (3317,
	0,
	0,
	2,
	44,
	44,
	0,
	0,
	0,
	0,
	160,
	3309);
INSERT INTO V_LIN
	VALUES (3317,
	'2');
INSERT INTO V_VAR
	VALUES (3312,
	3309,
	'tc',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3312,
	0,
	3313);
INSERT INTO PE_PE
	VALUES (3321,
	1,
	0,
	448,
	7);
INSERT INTO EP_PKG
	VALUES (3321,
	0,
	3103,
	'TestCases',
	'',
	0);
INSERT INTO PE_PE
	VALUES (3322,
	1,
	3321,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3322,
	0,
	'RunTestCase',
	'',
	'TestCase::execute();',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (3323,
	3322);
INSERT INTO ACT_ACT
	VALUES (3323,
	'function',
	0,
	3324,
	0,
	0,
	'RunTestCase',
	0);
INSERT INTO ACT_BLK
	VALUES (3324,
	0,
	0,
	0,
	'TestCase',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3323,
	0);
INSERT INTO ACT_SMT
	VALUES (3325,
	3324,
	0,
	1,
	1,
	'RunTestCase line: 1');
INSERT INTO ACT_TFM
	VALUES (3325,
	3326,
	0,
	1,
	11,
	1,
	1);
INSERT INTO PE_PE
	VALUES (3327,
	1,
	3321,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3327,
	0,
	'createGoals_1',
	'',
	'// Create some goal specifications.
TRACK::newGoalSpec( 
  sequenceNumber: 1,
  minimum: 2.0,
  maximum: 8.0,
  span: 150.0,
  criteriaType: UIGoalCriteria::Pace,
  spanType: UIGoalSpan::Distance );
  
TRACK::newGoalSpec( 
  sequenceNumber: 2,
  minimum: 60.0,
  maximum: 80.0,
  span: 10,
  criteriaType: UIGoalCriteria::HeartRate,
  spanType: UIGoalSpan::Time );
  
TRACK::newGoalSpec( 
  sequenceNumber: 3,
  minimum: 5.0,
  maximum: 6.0,
  span: 15,
  criteriaType: UIGoalCriteria::Pace,
  spanType: UIGoalSpan::Time );
  
TRACK::newGoalSpec( 
  sequenceNumber: 4,
  minimum: 1.0,
  maximum: 2.0,
  span: 15,
  criteriaType: UIGoalCriteria::Pace,
  spanType: UIGoalSpan::Time );
  ',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (3328,
	3327);
INSERT INTO ACT_ACT
	VALUES (3328,
	'function',
	0,
	3329,
	0,
	0,
	'createGoals_1',
	0);
INSERT INTO ACT_BLK
	VALUES (3329,
	0,
	0,
	0,
	'TRACK',
	'',
	'',
	26,
	1,
	26,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	32,
	13,
	0,
	3328,
	0);
INSERT INTO ACT_SMT
	VALUES (3330,
	3329,
	3331,
	2,
	1,
	'createGoals_1 line: 2');
INSERT INTO ACT_IOP
	VALUES (3330,
	2,
	8,
	2,
	1,
	0,
	1329,
	0);
INSERT INTO ACT_SMT
	VALUES (3331,
	3329,
	3332,
	10,
	1,
	'createGoals_1 line: 10');
INSERT INTO ACT_IOP
	VALUES (3331,
	10,
	8,
	10,
	1,
	0,
	1329,
	0);
INSERT INTO ACT_SMT
	VALUES (3332,
	3329,
	3333,
	18,
	1,
	'createGoals_1 line: 18');
INSERT INTO ACT_IOP
	VALUES (3332,
	18,
	8,
	18,
	1,
	0,
	1329,
	0);
INSERT INTO ACT_SMT
	VALUES (3333,
	3329,
	0,
	26,
	1,
	'createGoals_1 line: 26');
INSERT INTO ACT_IOP
	VALUES (3333,
	26,
	8,
	26,
	1,
	0,
	1329,
	0);
INSERT INTO V_VAL
	VALUES (3334,
	0,
	0,
	3,
	19,
	19,
	0,
	0,
	0,
	0,
	160,
	3329);
INSERT INTO V_LIN
	VALUES (3334,
	'1');
INSERT INTO V_PAR
	VALUES (3334,
	3330,
	0,
	'sequenceNumber',
	3335,
	3,
	3);
INSERT INTO V_VAL
	VALUES (3335,
	0,
	0,
	4,
	12,
	14,
	0,
	0,
	0,
	0,
	153,
	3329);
INSERT INTO V_LRL
	VALUES (3335,
	'2.0');
INSERT INTO V_PAR
	VALUES (3335,
	3330,
	0,
	'minimum',
	3336,
	4,
	3);
INSERT INTO V_VAL
	VALUES (3336,
	0,
	0,
	5,
	12,
	14,
	0,
	0,
	0,
	0,
	153,
	3329);
INSERT INTO V_LRL
	VALUES (3336,
	'8.0');
INSERT INTO V_PAR
	VALUES (3336,
	3330,
	0,
	'maximum',
	3337,
	5,
	3);
INSERT INTO V_VAL
	VALUES (3337,
	0,
	0,
	6,
	9,
	13,
	0,
	0,
	0,
	0,
	153,
	3329);
INSERT INTO V_LRL
	VALUES (3337,
	'150.0');
INSERT INTO V_PAR
	VALUES (3337,
	3330,
	0,
	'span',
	3338,
	6,
	3);
INSERT INTO V_VAL
	VALUES (3338,
	0,
	0,
	7,
	33,
	36,
	0,
	0,
	0,
	0,
	123,
	3329);
INSERT INTO V_LEN
	VALUES (3338,
	130,
	7,
	17);
INSERT INTO V_PAR
	VALUES (3338,
	3330,
	0,
	'criteriaType',
	3339,
	7,
	3);
INSERT INTO V_VAL
	VALUES (3339,
	0,
	0,
	8,
	25,
	32,
	0,
	0,
	0,
	0,
	138,
	3329);
INSERT INTO V_LEN
	VALUES (3339,
	141,
	8,
	13);
INSERT INTO V_PAR
	VALUES (3339,
	3330,
	0,
	'spanType',
	0,
	8,
	3);
INSERT INTO V_VAL
	VALUES (3340,
	0,
	0,
	11,
	19,
	19,
	0,
	0,
	0,
	0,
	160,
	3329);
INSERT INTO V_LIN
	VALUES (3340,
	'2');
INSERT INTO V_PAR
	VALUES (3340,
	3331,
	0,
	'sequenceNumber',
	3341,
	11,
	3);
INSERT INTO V_VAL
	VALUES (3341,
	0,
	0,
	12,
	12,
	15,
	0,
	0,
	0,
	0,
	153,
	3329);
INSERT INTO V_LRL
	VALUES (3341,
	'60.0');
INSERT INTO V_PAR
	VALUES (3341,
	3331,
	0,
	'minimum',
	3342,
	12,
	3);
INSERT INTO V_VAL
	VALUES (3342,
	0,
	0,
	13,
	12,
	15,
	0,
	0,
	0,
	0,
	153,
	3329);
INSERT INTO V_LRL
	VALUES (3342,
	'80.0');
INSERT INTO V_PAR
	VALUES (3342,
	3331,
	0,
	'maximum',
	3343,
	13,
	3);
INSERT INTO V_VAL
	VALUES (3343,
	0,
	0,
	14,
	9,
	10,
	0,
	0,
	0,
	0,
	160,
	3329);
INSERT INTO V_LIN
	VALUES (3343,
	'10');
INSERT INTO V_PAR
	VALUES (3343,
	3331,
	0,
	'span',
	3344,
	14,
	3);
INSERT INTO V_VAL
	VALUES (3344,
	0,
	0,
	15,
	33,
	41,
	0,
	0,
	0,
	0,
	123,
	3329);
INSERT INTO V_LEN
	VALUES (3344,
	127,
	15,
	17);
INSERT INTO V_PAR
	VALUES (3344,
	3331,
	0,
	'criteriaType',
	3345,
	15,
	3);
INSERT INTO V_VAL
	VALUES (3345,
	0,
	0,
	16,
	25,
	28,
	0,
	0,
	0,
	0,
	138,
	3329);
INSERT INTO V_LEN
	VALUES (3345,
	144,
	16,
	13);
INSERT INTO V_PAR
	VALUES (3345,
	3331,
	0,
	'spanType',
	0,
	16,
	3);
INSERT INTO V_VAL
	VALUES (3346,
	0,
	0,
	19,
	19,
	19,
	0,
	0,
	0,
	0,
	160,
	3329);
INSERT INTO V_LIN
	VALUES (3346,
	'3');
INSERT INTO V_PAR
	VALUES (3346,
	3332,
	0,
	'sequenceNumber',
	3347,
	19,
	3);
INSERT INTO V_VAL
	VALUES (3347,
	0,
	0,
	20,
	12,
	14,
	0,
	0,
	0,
	0,
	153,
	3329);
INSERT INTO V_LRL
	VALUES (3347,
	'5.0');
INSERT INTO V_PAR
	VALUES (3347,
	3332,
	0,
	'minimum',
	3348,
	20,
	3);
INSERT INTO V_VAL
	VALUES (3348,
	0,
	0,
	21,
	12,
	14,
	0,
	0,
	0,
	0,
	153,
	3329);
INSERT INTO V_LRL
	VALUES (3348,
	'6.0');
INSERT INTO V_PAR
	VALUES (3348,
	3332,
	0,
	'maximum',
	3349,
	21,
	3);
INSERT INTO V_VAL
	VALUES (3349,
	0,
	0,
	22,
	9,
	10,
	0,
	0,
	0,
	0,
	160,
	3329);
INSERT INTO V_LIN
	VALUES (3349,
	'15');
INSERT INTO V_PAR
	VALUES (3349,
	3332,
	0,
	'span',
	3350,
	22,
	3);
INSERT INTO V_VAL
	VALUES (3350,
	0,
	0,
	23,
	33,
	36,
	0,
	0,
	0,
	0,
	123,
	3329);
INSERT INTO V_LEN
	VALUES (3350,
	130,
	23,
	17);
INSERT INTO V_PAR
	VALUES (3350,
	3332,
	0,
	'criteriaType',
	3351,
	23,
	3);
INSERT INTO V_VAL
	VALUES (3351,
	0,
	0,
	24,
	25,
	28,
	0,
	0,
	0,
	0,
	138,
	3329);
INSERT INTO V_LEN
	VALUES (3351,
	144,
	24,
	13);
INSERT INTO V_PAR
	VALUES (3351,
	3332,
	0,
	'spanType',
	0,
	24,
	3);
INSERT INTO V_VAL
	VALUES (3352,
	0,
	0,
	27,
	19,
	19,
	0,
	0,
	0,
	0,
	160,
	3329);
INSERT INTO V_LIN
	VALUES (3352,
	'4');
INSERT INTO V_PAR
	VALUES (3352,
	3333,
	0,
	'sequenceNumber',
	3353,
	27,
	3);
INSERT INTO V_VAL
	VALUES (3353,
	0,
	0,
	28,
	12,
	14,
	0,
	0,
	0,
	0,
	153,
	3329);
INSERT INTO V_LRL
	VALUES (3353,
	'1.0');
INSERT INTO V_PAR
	VALUES (3353,
	3333,
	0,
	'minimum',
	3354,
	28,
	3);
INSERT INTO V_VAL
	VALUES (3354,
	0,
	0,
	29,
	12,
	14,
	0,
	0,
	0,
	0,
	153,
	3329);
INSERT INTO V_LRL
	VALUES (3354,
	'2.0');
INSERT INTO V_PAR
	VALUES (3354,
	3333,
	0,
	'maximum',
	3355,
	29,
	3);
INSERT INTO V_VAL
	VALUES (3355,
	0,
	0,
	30,
	9,
	10,
	0,
	0,
	0,
	0,
	160,
	3329);
INSERT INTO V_LIN
	VALUES (3355,
	'15');
INSERT INTO V_PAR
	VALUES (3355,
	3333,
	0,
	'span',
	3356,
	30,
	3);
INSERT INTO V_VAL
	VALUES (3356,
	0,
	0,
	31,
	33,
	36,
	0,
	0,
	0,
	0,
	123,
	3329);
INSERT INTO V_LEN
	VALUES (3356,
	130,
	31,
	17);
INSERT INTO V_PAR
	VALUES (3356,
	3333,
	0,
	'criteriaType',
	3357,
	31,
	3);
INSERT INTO V_VAL
	VALUES (3357,
	0,
	0,
	32,
	25,
	28,
	0,
	0,
	0,
	0,
	138,
	3329);
INSERT INTO V_LEN
	VALUES (3357,
	144,
	32,
	13);
INSERT INTO V_PAR
	VALUES (3357,
	3333,
	0,
	'spanType',
	0,
	32,
	3);
INSERT INTO PE_PE
	VALUES (3358,
	1,
	3321,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3358,
	0,
	'init',
	'',
	'UI::connect();',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (3359,
	3358);
INSERT INTO ACT_ACT
	VALUES (3359,
	'function',
	0,
	3360,
	0,
	0,
	'init',
	0);
INSERT INTO ACT_BLK
	VALUES (3360,
	0,
	0,
	0,
	'UI',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3359,
	0);
INSERT INTO ACT_SMT
	VALUES (3361,
	3360,
	0,
	1,
	1,
	'init line: 1');
INSERT INTO ACT_TFM
	VALUES (3361,
	3362,
	0,
	1,
	5,
	1,
	1);
INSERT INTO PE_PE
	VALUES (3363,
	1,
	0,
	448,
	7);
INSERT INTO EP_PKG
	VALUES (3363,
	0,
	3103,
	'UI',
	'',
	0);
INSERT INTO PE_PE
	VALUES (3313,
	1,
	3363,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (3313,
	'TestCase',
	2,
	'TestCase',
	'Represents a very simple automated test case.',
	0);
INSERT INTO O_TFR
	VALUES (3326,
	3313,
	'execute',
	'',
	1192,
	0,
	'create object instance tc of TestCase; tc.id = 1;
generate TestCase5:initialize( iterations: 2 ) to tc;
',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (3364,
	3326);
INSERT INTO ACT_ACT
	VALUES (3364,
	'class operation',
	0,
	3365,
	0,
	0,
	'TestCase::execute',
	0);
INSERT INTO ACT_BLK
	VALUES (3365,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'iterations',
	'iterations',
	2,
	1,
	1,
	30,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3364,
	0);
INSERT INTO ACT_SMT
	VALUES (3366,
	3365,
	3367,
	1,
	1,
	'TestCase::execute line: 1');
INSERT INTO ACT_CR
	VALUES (3366,
	3368,
	1,
	3313,
	1,
	30);
INSERT INTO ACT_SMT
	VALUES (3367,
	3365,
	3369,
	1,
	40,
	'TestCase::execute line: 1');
INSERT INTO ACT_AI
	VALUES (3367,
	3370,
	3371,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3369,
	3365,
	0,
	2,
	1,
	'TestCase::execute line: 2');
INSERT INTO E_ESS
	VALUES (3369,
	1,
	0,
	2,
	10,
	2,
	20,
	1,
	30,
	2,
	32,
	0,
	0);
INSERT INTO V_PAR
	VALUES (3372,
	3369,
	0,
	'iterations',
	0,
	2,
	32);
INSERT INTO E_GES
	VALUES (3369);
INSERT INTO E_GSME
	VALUES (3369,
	3318);
INSERT INTO E_GEN
	VALUES (3369,
	3368);
INSERT INTO V_VAL
	VALUES (3373,
	1,
	0,
	1,
	40,
	41,
	0,
	0,
	0,
	0,
	1309,
	3365);
INSERT INTO V_IRF
	VALUES (3373,
	3368);
INSERT INTO V_VAL
	VALUES (3371,
	1,
	0,
	1,
	43,
	44,
	0,
	0,
	0,
	0,
	160,
	3365);
INSERT INTO V_AVL
	VALUES (3371,
	3373,
	3313,
	3320);
INSERT INTO V_VAL
	VALUES (3370,
	0,
	0,
	1,
	48,
	48,
	0,
	0,
	0,
	0,
	160,
	3365);
INSERT INTO V_LIN
	VALUES (3370,
	'1');
INSERT INTO V_VAL
	VALUES (3372,
	0,
	0,
	2,
	44,
	44,
	0,
	0,
	0,
	0,
	160,
	3365);
INSERT INTO V_LIN
	VALUES (3372,
	'2');
INSERT INTO V_VAR
	VALUES (3368,
	3365,
	'tc',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3368,
	0,
	3313);
INSERT INTO O_NBATTR
	VALUES (3374,
	3313);
INSERT INTO O_BATTR
	VALUES (3374,
	3313);
INSERT INTO O_ATTR
	VALUES (3374,
	3313,
	3320,
	'current_state',
	'',
	'',
	'current_state',
	0,
	1307,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3375,
	3313);
INSERT INTO O_BATTR
	VALUES (3375,
	3313);
INSERT INTO O_ATTR
	VALUES (3375,
	3313,
	3374,
	'iterations',
	'',
	'',
	'iterations',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3320,
	3313);
INSERT INTO O_BATTR
	VALUES (3320,
	3313);
INSERT INTO O_ATTR
	VALUES (3320,
	3313,
	0,
	'id',
	'',
	'',
	'id',
	0,
	160,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	3313);
INSERT INTO O_OIDA
	VALUES (3320,
	3313,
	0,
	'id');
INSERT INTO O_ID
	VALUES (1,
	3313);
INSERT INTO O_ID
	VALUES (2,
	3313);
INSERT INTO SM_ISM
	VALUES (3376,
	3313);
INSERT INTO SM_SM
	VALUES (3376,
	'',
	0);
INSERT INTO SM_MOORE
	VALUES (3376);
INSERT INTO SM_EVTDI
	VALUES (3377,
	3376,
	'iterations',
	'',
	160,
	'',
	3318,
	0);
INSERT INTO SM_LEVT
	VALUES (3378,
	3376,
	0);
INSERT INTO SM_SEVT
	VALUES (3378,
	3376,
	0);
INSERT INTO SM_EVT
	VALUES (3378,
	3376,
	0,
	1,
	'doDelay',
	0,
	'',
	'TestCase1',
	'');
INSERT INTO SM_LEVT
	VALUES (3379,
	3376,
	0);
INSERT INTO SM_SEVT
	VALUES (3379,
	3376,
	0);
INSERT INTO SM_EVT
	VALUES (3379,
	3376,
	0,
	3,
	'finish',
	0,
	'',
	'TestCase3',
	'');
INSERT INTO SM_LEVT
	VALUES (3380,
	3376,
	0);
INSERT INTO SM_SEVT
	VALUES (3380,
	3376,
	0);
INSERT INTO SM_EVT
	VALUES (3380,
	3376,
	0,
	4,
	'initializationComplete',
	0,
	'',
	'TestCase4',
	'');
INSERT INTO SM_LEVT
	VALUES (3318,
	3376,
	0);
INSERT INTO SM_SEVT
	VALUES (3318,
	3376,
	0);
INSERT INTO SM_EVT
	VALUES (3318,
	3376,
	0,
	5,
	'initialize',
	0,
	'',
	'TestCase5',
	'');
INSERT INTO SM_STATE
	VALUES (3381,
	3376,
	0,
	'pressStartStop',
	2,
	0);
INSERT INTO SM_SEME
	VALUES (3381,
	3378,
	3376,
	0);
INSERT INTO SM_SEME
	VALUES (3381,
	3379,
	3376,
	0);
INSERT INTO SM_CH
	VALUES (3381,
	3380,
	3376,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3381,
	3380,
	3376,
	0);
INSERT INTO SM_CH
	VALUES (3381,
	3318,
	3376,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3381,
	3318,
	3376,
	0);
INSERT INTO SM_MOAH
	VALUES (3382,
	3376,
	3381);
INSERT INTO SM_AH
	VALUES (3382,
	3376);
INSERT INTO SM_ACT
	VALUES (3382,
	3376,
	1,
	'if (self.iterations > 0)
  self.iterations = self.iterations - 1;
  create event instance evt of TestCase1 to self; handle = TIM::timer_start(event_inst: evt, microseconds: 4000000);
  TRACK::startStopPressed();
else
  generate TestCase3:finish to self;
  TRACK::lapResetPressed();
end if;',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (3383,
	3376,
	3382);
INSERT INTO ACT_ACT
	VALUES (3383,
	'state',
	0,
	3384,
	0,
	0,
	'TestCase::pressStartStop',
	0);
INSERT INTO ACT_BLK
	VALUES (3384,
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3383,
	0);
INSERT INTO ACT_SMT
	VALUES (3385,
	3384,
	0,
	1,
	1,
	'TestCase::pressStartStop line: 1');
INSERT INTO ACT_IF
	VALUES (3385,
	3386,
	3387,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3388,
	3384,
	0,
	5,
	1,
	'TestCase::pressStartStop line: 5');
INSERT INTO ACT_E
	VALUES (3388,
	3389,
	3385);
INSERT INTO V_VAL
	VALUES (3390,
	0,
	0,
	1,
	5,
	8,
	0,
	0,
	0,
	0,
	1309,
	3384);
INSERT INTO V_IRF
	VALUES (3390,
	3391);
INSERT INTO V_VAL
	VALUES (3392,
	0,
	0,
	1,
	10,
	19,
	0,
	0,
	0,
	0,
	160,
	3384);
INSERT INTO V_AVL
	VALUES (3392,
	3390,
	3313,
	3375);
INSERT INTO V_VAL
	VALUES (3387,
	0,
	0,
	1,
	10,
	23,
	0,
	0,
	0,
	0,
	125,
	3384);
INSERT INTO V_BIN
	VALUES (3387,
	3393,
	3392,
	'>');
INSERT INTO V_VAL
	VALUES (3393,
	0,
	0,
	1,
	23,
	23,
	0,
	0,
	0,
	0,
	160,
	3384);
INSERT INTO V_LIN
	VALUES (3393,
	'0');
INSERT INTO V_VAR
	VALUES (3391,
	3384,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3391,
	0,
	3313);
INSERT INTO ACT_BLK
	VALUES (3386,
	0,
	0,
	0,
	'TRACK',
	'',
	'',
	4,
	3,
	4,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3383,
	0);
INSERT INTO ACT_SMT
	VALUES (3394,
	3386,
	3395,
	2,
	3,
	'TestCase::pressStartStop line: 2');
INSERT INTO ACT_AI
	VALUES (3394,
	3396,
	3397,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3395,
	3386,
	3398,
	3,
	3,
	'TestCase::pressStartStop line: 3');
INSERT INTO E_ESS
	VALUES (3395,
	1,
	0,
	3,
	32,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (3395,
	1,
	3399);
INSERT INTO E_CSME
	VALUES (3395,
	3378);
INSERT INTO E_CEI
	VALUES (3395,
	3391);
INSERT INTO ACT_SMT
	VALUES (3398,
	3386,
	3400,
	3,
	51,
	'TestCase::pressStartStop line: 3');
INSERT INTO ACT_AI
	VALUES (3398,
	3401,
	3402,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3400,
	3386,
	0,
	4,
	3,
	'TestCase::pressStartStop line: 4');
INSERT INTO ACT_IOP
	VALUES (3400,
	4,
	10,
	4,
	3,
	0,
	1325,
	0);
INSERT INTO V_VAL
	VALUES (3403,
	1,
	0,
	2,
	3,
	6,
	0,
	0,
	0,
	0,
	1309,
	3386);
INSERT INTO V_IRF
	VALUES (3403,
	3391);
INSERT INTO V_VAL
	VALUES (3397,
	1,
	0,
	2,
	8,
	17,
	0,
	0,
	0,
	0,
	160,
	3386);
INSERT INTO V_AVL
	VALUES (3397,
	3403,
	3313,
	3375);
INSERT INTO V_VAL
	VALUES (3404,
	0,
	0,
	2,
	21,
	24,
	0,
	0,
	0,
	0,
	1309,
	3386);
INSERT INTO V_IRF
	VALUES (3404,
	3391);
INSERT INTO V_VAL
	VALUES (3405,
	0,
	0,
	2,
	26,
	35,
	0,
	0,
	0,
	0,
	160,
	3386);
INSERT INTO V_AVL
	VALUES (3405,
	3404,
	3313,
	3375);
INSERT INTO V_VAL
	VALUES (3396,
	0,
	0,
	2,
	26,
	39,
	0,
	0,
	0,
	0,
	160,
	3386);
INSERT INTO V_BIN
	VALUES (3396,
	3406,
	3405,
	'-');
INSERT INTO V_VAL
	VALUES (3406,
	0,
	0,
	2,
	39,
	39,
	0,
	0,
	0,
	0,
	160,
	3386);
INSERT INTO V_LIN
	VALUES (3406,
	'1');
INSERT INTO V_VAL
	VALUES (3402,
	1,
	1,
	3,
	51,
	56,
	0,
	0,
	0,
	0,
	1272,
	3386);
INSERT INTO V_TVL
	VALUES (3402,
	3407);
INSERT INTO V_VAL
	VALUES (3401,
	0,
	0,
	3,
	65,
	-1,
	3,
	77,
	3,
	94,
	1272,
	3386);
INSERT INTO V_BRV
	VALUES (3401,
	1271,
	1,
	3,
	60);
INSERT INTO V_VAL
	VALUES (3408,
	0,
	0,
	3,
	89,
	91,
	0,
	0,
	0,
	0,
	1275,
	3386);
INSERT INTO V_TVL
	VALUES (3408,
	3399);
INSERT INTO V_PAR
	VALUES (3408,
	0,
	3401,
	'event_inst',
	3409,
	3,
	77);
INSERT INTO V_VAL
	VALUES (3409,
	0,
	0,
	3,
	108,
	114,
	0,
	0,
	0,
	0,
	160,
	3386);
INSERT INTO V_LIN
	VALUES (3409,
	'4000000');
INSERT INTO V_PAR
	VALUES (3409,
	0,
	3401,
	'microseconds',
	0,
	3,
	94);
INSERT INTO V_VAR
	VALUES (3399,
	3386,
	'evt',
	1,
	1275);
INSERT INTO V_TRN
	VALUES (3399,
	0,
	'');
INSERT INTO V_VAR
	VALUES (3407,
	3386,
	'handle',
	1,
	1272);
INSERT INTO V_TRN
	VALUES (3407,
	0,
	'');
INSERT INTO ACT_BLK
	VALUES (3389,
	0,
	0,
	0,
	'TRACK',
	'',
	'',
	7,
	3,
	7,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3383,
	0);
INSERT INTO ACT_SMT
	VALUES (3410,
	3389,
	3411,
	6,
	3,
	'TestCase::pressStartStop line: 6');
INSERT INTO E_ESS
	VALUES (3410,
	1,
	0,
	6,
	12,
	6,
	22,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (3410);
INSERT INTO E_GSME
	VALUES (3410,
	3379);
INSERT INTO E_GEN
	VALUES (3410,
	3391);
INSERT INTO ACT_SMT
	VALUES (3411,
	3389,
	0,
	7,
	3,
	'TestCase::pressStartStop line: 7');
INSERT INTO ACT_IOP
	VALUES (3411,
	7,
	10,
	7,
	3,
	0,
	1326,
	0);
INSERT INTO SM_STATE
	VALUES (3412,
	3376,
	0,
	'testCaseFinished',
	3,
	1);
INSERT INTO SM_CH
	VALUES (3412,
	3378,
	3376,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3412,
	3378,
	3376,
	0);
INSERT INTO SM_CH
	VALUES (3412,
	3379,
	3376,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3412,
	3379,
	3376,
	0);
INSERT INTO SM_CH
	VALUES (3412,
	3380,
	3376,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3412,
	3380,
	3376,
	0);
INSERT INTO SM_CH
	VALUES (3412,
	3318,
	3376,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3412,
	3318,
	3376,
	0);
INSERT INTO SM_MOAH
	VALUES (3413,
	3376,
	3412);
INSERT INTO SM_AH
	VALUES (3413,
	3376);
INSERT INTO SM_ACT
	VALUES (3413,
	3376,
	1,
	'LOG::LogInfo(message: "End of test case"); ',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (3414,
	3376,
	3413);
INSERT INTO ACT_ACT
	VALUES (3414,
	'state',
	0,
	3415,
	0,
	0,
	'TestCase::testCaseFinished',
	0);
INSERT INTO ACT_BLK
	VALUES (3415,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3414,
	0);
INSERT INTO ACT_SMT
	VALUES (3416,
	3415,
	0,
	1,
	1,
	'TestCase::testCaseFinished line: 1');
INSERT INTO ACT_BRG
	VALUES (3416,
	1206,
	1,
	6,
	1,
	1);
INSERT INTO V_VAL
	VALUES (3417,
	0,
	0,
	1,
	23,
	39,
	0,
	0,
	0,
	0,
	1199,
	3415);
INSERT INTO V_LST
	VALUES (3417,
	'End of test case');
INSERT INTO V_PAR
	VALUES (3417,
	3416,
	0,
	'message',
	0,
	1,
	14);
INSERT INTO SM_STATE
	VALUES (3418,
	3376,
	0,
	'initialize',
	4,
	0);
INSERT INTO SM_CH
	VALUES (3418,
	3378,
	3376,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3418,
	3378,
	3376,
	0);
INSERT INTO SM_CH
	VALUES (3418,
	3379,
	3376,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3418,
	3379,
	3376,
	0);
INSERT INTO SM_SEME
	VALUES (3418,
	3380,
	3376,
	0);
INSERT INTO SM_CH
	VALUES (3418,
	3318,
	3376,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3418,
	3318,
	3376,
	0);
INSERT INTO SM_MOAH
	VALUES (3419,
	3376,
	3418);
INSERT INTO SM_AH
	VALUES (3419,
	3376);
INSERT INTO SM_ACT
	VALUES (3419,
	3376,
	1,
	'LOG::LogInfo(message: "Start of test case"); 
self.iterations = rcvd_evt.iterations * 2;
generate TestCase4:initializationComplete() to self; ',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (3420,
	3376,
	3419);
INSERT INTO ACT_ACT
	VALUES (3420,
	'state',
	0,
	3421,
	0,
	0,
	'TestCase::initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (3421,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	3,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3420,
	0);
INSERT INTO ACT_SMT
	VALUES (3422,
	3421,
	3423,
	1,
	1,
	'TestCase::initialize line: 1');
INSERT INTO ACT_BRG
	VALUES (3422,
	1206,
	1,
	6,
	1,
	1);
INSERT INTO ACT_SMT
	VALUES (3423,
	3421,
	3424,
	2,
	1,
	'TestCase::initialize line: 2');
INSERT INTO ACT_AI
	VALUES (3423,
	3425,
	3426,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3424,
	3421,
	0,
	3,
	1,
	'TestCase::initialize line: 3');
INSERT INTO E_ESS
	VALUES (3424,
	1,
	0,
	3,
	10,
	3,
	20,
	1,
	1,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (3424);
INSERT INTO E_GSME
	VALUES (3424,
	3380);
INSERT INTO E_GEN
	VALUES (3424,
	3427);
INSERT INTO V_VAL
	VALUES (3428,
	0,
	0,
	1,
	23,
	41,
	0,
	0,
	0,
	0,
	1199,
	3421);
INSERT INTO V_LST
	VALUES (3428,
	'Start of test case');
INSERT INTO V_PAR
	VALUES (3428,
	3422,
	0,
	'message',
	0,
	1,
	14);
INSERT INTO V_VAL
	VALUES (3429,
	1,
	0,
	2,
	1,
	4,
	0,
	0,
	0,
	0,
	1309,
	3421);
INSERT INTO V_IRF
	VALUES (3429,
	3427);
INSERT INTO V_VAL
	VALUES (3426,
	1,
	0,
	2,
	6,
	15,
	0,
	0,
	0,
	0,
	160,
	3421);
INSERT INTO V_AVL
	VALUES (3426,
	3429,
	3313,
	3375);
INSERT INTO V_VAL
	VALUES (3430,
	0,
	0,
	2,
	28,
	37,
	0,
	0,
	0,
	0,
	160,
	3421);
INSERT INTO V_EDV
	VALUES (3430);
INSERT INTO V_EPR
	VALUES (3430,
	3376,
	3377,
	0);
INSERT INTO V_VAL
	VALUES (3425,
	0,
	0,
	2,
	28,
	41,
	0,
	0,
	0,
	0,
	160,
	3421);
INSERT INTO V_BIN
	VALUES (3425,
	3431,
	3430,
	'*');
INSERT INTO V_VAL
	VALUES (3431,
	0,
	0,
	2,
	41,
	41,
	0,
	0,
	0,
	0,
	160,
	3421);
INSERT INTO V_LIN
	VALUES (3431,
	'2');
INSERT INTO V_VAR
	VALUES (3427,
	3421,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3427,
	0,
	3313);
INSERT INTO SM_STATE
	VALUES (3432,
	3376,
	0,
	'Idle',
	1,
	0);
INSERT INTO SM_CH
	VALUES (3432,
	3378,
	3376,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3432,
	3378,
	3376,
	0);
INSERT INTO SM_CH
	VALUES (3432,
	3379,
	3376,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3432,
	3379,
	3376,
	0);
INSERT INTO SM_CH
	VALUES (3432,
	3380,
	3376,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3432,
	3380,
	3376,
	0);
INSERT INTO SM_SEME
	VALUES (3432,
	3318,
	3376,
	0);
INSERT INTO SM_MOAH
	VALUES (3433,
	3376,
	3432);
INSERT INTO SM_AH
	VALUES (3433,
	3376);
INSERT INTO SM_ACT
	VALUES (3433,
	3376,
	1,
	'',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (3434,
	3376,
	3433);
INSERT INTO ACT_ACT
	VALUES (3434,
	'state',
	0,
	3435,
	0,
	0,
	'TestCase::Idle',
	0);
INSERT INTO ACT_BLK
	VALUES (3435,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3434,
	0);
INSERT INTO SM_NSTXN
	VALUES (3436,
	3376,
	3381,
	3378,
	0);
INSERT INTO SM_TAH
	VALUES (3437,
	3376,
	3436);
INSERT INTO SM_AH
	VALUES (3437,
	3376);
INSERT INTO SM_ACT
	VALUES (3437,
	3376,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3438,
	3376,
	3437);
INSERT INTO ACT_ACT
	VALUES (3438,
	'transition',
	0,
	3439,
	0,
	0,
	'TestCase1: doDelay',
	0);
INSERT INTO ACT_BLK
	VALUES (3439,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3438,
	0);
INSERT INTO SM_TXN
	VALUES (3436,
	3376,
	3381,
	0);
INSERT INTO SM_NSTXN
	VALUES (3440,
	3376,
	3381,
	3379,
	0);
INSERT INTO SM_TAH
	VALUES (3441,
	3376,
	3440);
INSERT INTO SM_AH
	VALUES (3441,
	3376);
INSERT INTO SM_ACT
	VALUES (3441,
	3376,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3442,
	3376,
	3441);
INSERT INTO ACT_ACT
	VALUES (3442,
	'transition',
	0,
	3443,
	0,
	0,
	'TestCase3: finish',
	0);
INSERT INTO ACT_BLK
	VALUES (3443,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3442,
	0);
INSERT INTO SM_TXN
	VALUES (3440,
	3376,
	3412,
	0);
INSERT INTO SM_NSTXN
	VALUES (3444,
	3376,
	3418,
	3380,
	0);
INSERT INTO SM_TAH
	VALUES (3445,
	3376,
	3444);
INSERT INTO SM_AH
	VALUES (3445,
	3376);
INSERT INTO SM_ACT
	VALUES (3445,
	3376,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3446,
	3376,
	3445);
INSERT INTO ACT_ACT
	VALUES (3446,
	'transition',
	0,
	3447,
	0,
	0,
	'TestCase4: initializationComplete',
	0);
INSERT INTO ACT_BLK
	VALUES (3447,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3446,
	0);
INSERT INTO SM_TXN
	VALUES (3444,
	3376,
	3381,
	0);
INSERT INTO SM_NSTXN
	VALUES (3448,
	3376,
	3432,
	3318,
	0);
INSERT INTO SM_TAH
	VALUES (3449,
	3376,
	3448);
INSERT INTO SM_AH
	VALUES (3449,
	3376);
INSERT INTO SM_ACT
	VALUES (3449,
	3376,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3450,
	3376,
	3449);
INSERT INTO ACT_ACT
	VALUES (3450,
	'transition',
	0,
	3451,
	0,
	0,
	'TestCase5: initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (3451,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3450,
	0);
INSERT INTO SM_TXN
	VALUES (3448,
	3376,
	3418,
	0);
INSERT INTO PE_PE
	VALUES (3165,
	1,
	3363,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (3165,
	'UI',
	1,
	'UI',
	'Provides an interface between Verifier and an external user interface representing 
the watch, in this case an animated rendition of the watch containing virtual
buttons that can be "pushed" by clicking on them with a mouse.

The system is first primed by creating, within the Verifier execution engine, an 
instance of each event that can be received by this class-based state machine.
This priming is done through execution of the feed*() bridge operations within 
the GuiBridge external entity.  Each of these operations is bound to a realized
Java function that queues the appropriate event within the Verifier execution 
engine.

Whenever a button on the animated watch is pushed, it causes the associated
event to be generated.  The activity on the transition then queues another instance
of the same event within the Verifier execution engine before sending the 
corresponding interface signal out through the UI port.  That interface signal 
can then be received by an application, such as the Tracking component, that is 
controlled by the animated watch.',
	0);
INSERT INTO O_TFR
	VALUES (3362,
	3165,
	'connect',
	'',
	1192,
	0,
	'// make sre the singleton exists
UIConstants::initialize();
select any uiconst from instances of UIConstants;
select any ui from instances of UI;
UI::initialize();
select any ui from instances of UI;

ui.socket_id = GuiBridge::connect();
if ( uiconst.SOCKET_ERROR != ui.socket_id )
  create event instance evt of UI9:tick() to ui; ui.timer = TIM::timer_start_recurring( event_inst: evt, microseconds: uiconst.tick_period );
end if;',
	1,
	'',
	3452,
	0);
INSERT INTO ACT_OPB
	VALUES (3453,
	3362);
INSERT INTO ACT_ACT
	VALUES (3453,
	'class operation',
	0,
	3454,
	0,
	0,
	'UI::connect',
	0);
INSERT INTO ACT_BLK
	VALUES (3454,
	1,
	0,
	0,
	'GuiBridge',
	'',
	'',
	9,
	1,
	8,
	16,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3453,
	0);
INSERT INTO ACT_SMT
	VALUES (3455,
	3454,
	3456,
	2,
	1,
	'UI::connect line: 2');
INSERT INTO ACT_TFM
	VALUES (3455,
	3457,
	0,
	2,
	14,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES (3456,
	3454,
	3458,
	3,
	1,
	'UI::connect line: 3');
INSERT INTO ACT_FIO
	VALUES (3456,
	3459,
	1,
	'any',
	3460,
	3,
	38);
INSERT INTO ACT_SMT
	VALUES (3458,
	3454,
	3461,
	4,
	1,
	'UI::connect line: 4');
INSERT INTO ACT_FIO
	VALUES (3458,
	3462,
	1,
	'any',
	3165,
	4,
	33);
INSERT INTO ACT_SMT
	VALUES (3461,
	3454,
	3463,
	5,
	1,
	'UI::connect line: 5');
INSERT INTO ACT_TFM
	VALUES (3461,
	3452,
	0,
	5,
	5,
	5,
	1);
INSERT INTO ACT_SMT
	VALUES (3463,
	3454,
	3464,
	6,
	1,
	'UI::connect line: 6');
INSERT INTO ACT_FIO
	VALUES (3463,
	3462,
	0,
	'any',
	3165,
	6,
	33);
INSERT INTO ACT_SMT
	VALUES (3464,
	3454,
	3465,
	8,
	1,
	'UI::connect line: 8');
INSERT INTO ACT_AI
	VALUES (3464,
	3466,
	3467,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3465,
	3454,
	0,
	9,
	1,
	'UI::connect line: 9');
INSERT INTO ACT_IF
	VALUES (3465,
	3468,
	3469,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3470,
	1,
	0,
	8,
	1,
	2,
	0,
	0,
	0,
	0,
	1309,
	3454);
INSERT INTO V_IRF
	VALUES (3470,
	3462);
INSERT INTO V_VAL
	VALUES (3467,
	1,
	0,
	8,
	4,
	12,
	0,
	0,
	0,
	0,
	160,
	3454);
INSERT INTO V_AVL
	VALUES (3467,
	3470,
	3165,
	3471);
INSERT INTO V_VAL
	VALUES (3466,
	0,
	0,
	8,
	27,
	-1,
	0,
	0,
	0,
	0,
	160,
	3454);
INSERT INTO V_BRV
	VALUES (3466,
	3147,
	1,
	8,
	16);
INSERT INTO V_VAL
	VALUES (3472,
	0,
	0,
	9,
	6,
	12,
	0,
	0,
	0,
	0,
	1309,
	3454);
INSERT INTO V_IRF
	VALUES (3472,
	3459);
INSERT INTO V_VAL
	VALUES (3473,
	0,
	0,
	9,
	14,
	25,
	0,
	0,
	0,
	0,
	160,
	3454);
INSERT INTO V_AVL
	VALUES (3473,
	3472,
	3460,
	3474);
INSERT INTO V_VAL
	VALUES (3469,
	0,
	0,
	9,
	14,
	41,
	0,
	0,
	0,
	0,
	125,
	3454);
INSERT INTO V_BIN
	VALUES (3469,
	3475,
	3473,
	'!=');
INSERT INTO V_VAL
	VALUES (3476,
	0,
	0,
	9,
	30,
	31,
	0,
	0,
	0,
	0,
	1309,
	3454);
INSERT INTO V_IRF
	VALUES (3476,
	3462);
INSERT INTO V_VAL
	VALUES (3475,
	0,
	0,
	9,
	33,
	41,
	0,
	0,
	0,
	0,
	160,
	3454);
INSERT INTO V_AVL
	VALUES (3475,
	3476,
	3165,
	3471);
INSERT INTO V_VAR
	VALUES (3459,
	3454,
	'uiconst',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3459,
	0,
	3460);
INSERT INTO V_VAR
	VALUES (3462,
	3454,
	'ui',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3462,
	0,
	3165);
INSERT INTO ACT_BLK
	VALUES (3468,
	0,
	0,
	0,
	'TIM',
	'',
	'',
	10,
	50,
	10,
	61,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3453,
	0);
INSERT INTO ACT_SMT
	VALUES (3477,
	3468,
	3478,
	10,
	3,
	'UI::connect line: 10');
INSERT INTO E_ESS
	VALUES (3477,
	1,
	0,
	10,
	32,
	10,
	36,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (3477,
	1,
	3479);
INSERT INTO E_CSME
	VALUES (3477,
	3480);
INSERT INTO E_CEI
	VALUES (3477,
	3462);
INSERT INTO ACT_SMT
	VALUES (3478,
	3468,
	0,
	10,
	50,
	'UI::connect line: 10');
INSERT INTO ACT_AI
	VALUES (3478,
	3481,
	3482,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3483,
	1,
	0,
	10,
	50,
	51,
	0,
	0,
	0,
	0,
	1309,
	3468);
INSERT INTO V_IRF
	VALUES (3483,
	3462);
INSERT INTO V_VAL
	VALUES (3482,
	1,
	0,
	10,
	53,
	57,
	0,
	0,
	0,
	0,
	1272,
	3468);
INSERT INTO V_AVL
	VALUES (3482,
	3483,
	3165,
	3484);
INSERT INTO V_VAL
	VALUES (3481,
	0,
	0,
	10,
	66,
	-1,
	10,
	89,
	10,
	106,
	1272,
	3468);
INSERT INTO V_BRV
	VALUES (3481,
	1278,
	1,
	10,
	61);
INSERT INTO V_VAL
	VALUES (3485,
	0,
	0,
	10,
	101,
	103,
	0,
	0,
	0,
	0,
	1275,
	3468);
INSERT INTO V_TVL
	VALUES (3485,
	3479);
INSERT INTO V_PAR
	VALUES (3485,
	0,
	3481,
	'event_inst',
	3486,
	10,
	89);
INSERT INTO V_VAL
	VALUES (3487,
	0,
	0,
	10,
	120,
	126,
	0,
	0,
	0,
	0,
	1309,
	3468);
INSERT INTO V_IRF
	VALUES (3487,
	3459);
INSERT INTO V_VAL
	VALUES (3486,
	0,
	0,
	10,
	128,
	138,
	0,
	0,
	0,
	0,
	160,
	3468);
INSERT INTO V_AVL
	VALUES (3486,
	3487,
	3460,
	3488);
INSERT INTO V_PAR
	VALUES (3486,
	0,
	3481,
	'microseconds',
	0,
	10,
	106);
INSERT INTO V_VAR
	VALUES (3479,
	3468,
	'evt',
	1,
	1275);
INSERT INTO V_TRN
	VALUES (3479,
	0,
	'');
INSERT INTO O_TFR
	VALUES (3489,
	3165,
	'poll',
	'',
	160,
	1,
	'return GuiBridge::poll();',
	1,
	'',
	3362,
	0);
INSERT INTO ACT_OPB
	VALUES (3490,
	3489);
INSERT INTO ACT_ACT
	VALUES (3490,
	'operation',
	0,
	3491,
	0,
	0,
	'UI::poll',
	0);
INSERT INTO ACT_BLK
	VALUES (3491,
	0,
	0,
	0,
	'GuiBridge',
	'',
	'',
	1,
	1,
	1,
	8,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3490,
	0);
INSERT INTO ACT_SMT
	VALUES (3492,
	3491,
	0,
	1,
	1,
	'UI::poll line: 1');
INSERT INTO ACT_RET
	VALUES (3492,
	3493);
INSERT INTO V_VAL
	VALUES (3493,
	0,
	0,
	1,
	19,
	-1,
	0,
	0,
	0,
	0,
	160,
	3491);
INSERT INTO V_BRV
	VALUES (3493,
	3154,
	1,
	1,
	8);
INSERT INTO O_TFR
	VALUES (3225,
	3165,
	'setData',
	'',
	1192,
	1,
	'GuiBridge::setData( value:param.value, unit:param.unit );',
	1,
	'',
	3489,
	0);
INSERT INTO O_TPARM
	VALUES (3494,
	3225,
	'value',
	153,
	0,
	'',
	0,
	'');
INSERT INTO O_TPARM
	VALUES (3495,
	3225,
	'unit',
	160,
	0,
	'',
	3494,
	'');
INSERT INTO ACT_OPB
	VALUES (3496,
	3225);
INSERT INTO ACT_ACT
	VALUES (3496,
	'operation',
	0,
	3497,
	0,
	0,
	'UI::setData',
	0);
INSERT INTO ACT_BLK
	VALUES (3497,
	0,
	0,
	0,
	'GuiBridge',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3496,
	0);
INSERT INTO ACT_SMT
	VALUES (3498,
	3497,
	0,
	1,
	1,
	'UI::setData line: 1');
INSERT INTO ACT_BRG
	VALUES (3498,
	3138,
	1,
	12,
	1,
	1);
INSERT INTO V_VAL
	VALUES (3499,
	0,
	0,
	1,
	33,
	37,
	0,
	0,
	0,
	0,
	153,
	3497);
INSERT INTO V_PVL
	VALUES (3499,
	0,
	0,
	3494,
	0);
INSERT INTO V_PAR
	VALUES (3499,
	3498,
	0,
	'value',
	3500,
	1,
	21);
INSERT INTO V_VAL
	VALUES (3500,
	0,
	0,
	1,
	51,
	54,
	0,
	0,
	0,
	0,
	160,
	3497);
INSERT INTO V_PVL
	VALUES (3500,
	0,
	0,
	3495,
	0);
INSERT INTO V_PAR
	VALUES (3500,
	3498,
	0,
	'unit',
	0,
	1,
	40);
INSERT INTO O_TFR
	VALUES (3288,
	3165,
	'setIndicator',
	'',
	1192,
	1,
	'GuiBridge::setIndicator( value:param.value );',
	1,
	'',
	3225,
	0);
INSERT INTO O_TPARM
	VALUES (3501,
	3288,
	'value',
	160,
	0,
	'',
	0,
	'');
INSERT INTO ACT_OPB
	VALUES (3502,
	3288);
INSERT INTO ACT_ACT
	VALUES (3502,
	'operation',
	0,
	3503,
	0,
	0,
	'UI::setIndicator',
	0);
INSERT INTO ACT_BLK
	VALUES (3503,
	0,
	0,
	0,
	'GuiBridge',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3502,
	0);
INSERT INTO ACT_SMT
	VALUES (3504,
	3503,
	0,
	1,
	1,
	'UI::setIndicator line: 1');
INSERT INTO ACT_BRG
	VALUES (3504,
	3150,
	1,
	12,
	1,
	1);
INSERT INTO V_VAL
	VALUES (3505,
	0,
	0,
	1,
	38,
	42,
	0,
	0,
	0,
	0,
	160,
	3503);
INSERT INTO V_PVL
	VALUES (3505,
	0,
	0,
	3501,
	0);
INSERT INTO V_PAR
	VALUES (3505,
	3504,
	0,
	'value',
	0,
	1,
	26);
INSERT INTO O_TFR
	VALUES (3306,
	3165,
	'setTime',
	'',
	1192,
	1,
	'GuiBridge::setTime( time:param.time );',
	1,
	'',
	3288,
	0);
INSERT INTO O_TPARM
	VALUES (3506,
	3306,
	'time',
	160,
	0,
	'',
	0,
	'');
INSERT INTO ACT_OPB
	VALUES (3507,
	3306);
INSERT INTO ACT_ACT
	VALUES (3507,
	'operation',
	0,
	3508,
	0,
	0,
	'UI::setTime',
	0);
INSERT INTO ACT_BLK
	VALUES (3508,
	0,
	0,
	0,
	'GuiBridge',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3507,
	0);
INSERT INTO ACT_SMT
	VALUES (3509,
	3508,
	0,
	1,
	1,
	'UI::setTime line: 1');
INSERT INTO ACT_BRG
	VALUES (3509,
	3143,
	1,
	12,
	1,
	1);
INSERT INTO V_VAL
	VALUES (3510,
	0,
	0,
	1,
	32,
	35,
	0,
	0,
	0,
	0,
	160,
	3508);
INSERT INTO V_PVL
	VALUES (3510,
	0,
	0,
	3506,
	0);
INSERT INTO V_PAR
	VALUES (3510,
	3509,
	0,
	'time',
	0,
	1,
	21);
INSERT INTO O_TFR
	VALUES (3452,
	3165,
	'initialize',
	'',
	1192,
	0,
	'// make sre the singleton exists
select any ui from instances of UI;
if (empty ui)
  UIConstants::initialize();
  select any uiconst from instances of UIConstants;
  create object instance ui of UI; 
  ui.id = 1;
  ui.socket_id = uiconst.SOCKET_ERROR;
end if;',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (3511,
	3452);
INSERT INTO ACT_ACT
	VALUES (3511,
	'class operation',
	0,
	3512,
	0,
	0,
	'UI::initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (3512,
	1,
	0,
	0,
	'',
	'',
	'',
	3,
	1,
	2,
	33,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3511,
	0);
INSERT INTO ACT_SMT
	VALUES (3513,
	3512,
	3514,
	2,
	1,
	'UI::initialize line: 2');
INSERT INTO ACT_FIO
	VALUES (3513,
	3515,
	1,
	'any',
	3165,
	2,
	33);
INSERT INTO ACT_SMT
	VALUES (3514,
	3512,
	0,
	3,
	1,
	'UI::initialize line: 3');
INSERT INTO ACT_IF
	VALUES (3514,
	3516,
	3517,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3518,
	0,
	0,
	3,
	11,
	12,
	0,
	0,
	0,
	0,
	1309,
	3512);
INSERT INTO V_IRF
	VALUES (3518,
	3515);
INSERT INTO V_VAL
	VALUES (3517,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	3512);
INSERT INTO V_UNY
	VALUES (3517,
	3518,
	'empty');
INSERT INTO V_VAR
	VALUES (3515,
	3512,
	'ui',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3515,
	0,
	3165);
INSERT INTO ACT_BLK
	VALUES (3516,
	1,
	0,
	0,
	'UIConstants',
	'',
	'',
	8,
	3,
	6,
	32,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3511,
	0);
INSERT INTO ACT_SMT
	VALUES (3519,
	3516,
	3520,
	4,
	3,
	'UI::initialize line: 4');
INSERT INTO ACT_TFM
	VALUES (3519,
	3457,
	0,
	4,
	16,
	4,
	3);
INSERT INTO ACT_SMT
	VALUES (3520,
	3516,
	3521,
	5,
	3,
	'UI::initialize line: 5');
INSERT INTO ACT_FIO
	VALUES (3520,
	3522,
	1,
	'any',
	3460,
	5,
	40);
INSERT INTO ACT_SMT
	VALUES (3521,
	3516,
	3523,
	6,
	3,
	'UI::initialize line: 6');
INSERT INTO ACT_CR
	VALUES (3521,
	3515,
	0,
	3165,
	6,
	32);
INSERT INTO ACT_SMT
	VALUES (3523,
	3516,
	3524,
	7,
	3,
	'UI::initialize line: 7');
INSERT INTO ACT_AI
	VALUES (3523,
	3525,
	3526,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3524,
	3516,
	0,
	8,
	3,
	'UI::initialize line: 8');
INSERT INTO ACT_AI
	VALUES (3524,
	3527,
	3528,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3529,
	1,
	0,
	7,
	3,
	4,
	0,
	0,
	0,
	0,
	1309,
	3516);
INSERT INTO V_IRF
	VALUES (3529,
	3515);
INSERT INTO V_VAL
	VALUES (3526,
	1,
	0,
	7,
	6,
	7,
	0,
	0,
	0,
	0,
	160,
	3516);
INSERT INTO V_AVL
	VALUES (3526,
	3529,
	3165,
	3530);
INSERT INTO V_VAL
	VALUES (3525,
	0,
	0,
	7,
	11,
	11,
	0,
	0,
	0,
	0,
	160,
	3516);
INSERT INTO V_LIN
	VALUES (3525,
	'1');
INSERT INTO V_VAL
	VALUES (3531,
	1,
	0,
	8,
	3,
	4,
	0,
	0,
	0,
	0,
	1309,
	3516);
INSERT INTO V_IRF
	VALUES (3531,
	3515);
INSERT INTO V_VAL
	VALUES (3528,
	1,
	0,
	8,
	6,
	14,
	0,
	0,
	0,
	0,
	160,
	3516);
INSERT INTO V_AVL
	VALUES (3528,
	3531,
	3165,
	3471);
INSERT INTO V_VAL
	VALUES (3532,
	0,
	0,
	8,
	18,
	24,
	0,
	0,
	0,
	0,
	1309,
	3516);
INSERT INTO V_IRF
	VALUES (3532,
	3522);
INSERT INTO V_VAL
	VALUES (3527,
	0,
	0,
	8,
	26,
	37,
	0,
	0,
	0,
	0,
	160,
	3516);
INSERT INTO V_AVL
	VALUES (3527,
	3532,
	3460,
	3474);
INSERT INTO V_VAR
	VALUES (3522,
	3516,
	'uiconst',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3522,
	0,
	3460);
INSERT INTO O_NBATTR
	VALUES (3533,
	3165);
INSERT INTO O_BATTR
	VALUES (3533,
	3165);
INSERT INTO O_ATTR
	VALUES (3533,
	3165,
	3530,
	'current_state',
	'',
	'',
	'current_state',
	0,
	1307,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3530,
	3165);
INSERT INTO O_BATTR
	VALUES (3530,
	3165);
INSERT INTO O_ATTR
	VALUES (3530,
	3165,
	0,
	'id',
	'',
	'',
	'id',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3471,
	3165);
INSERT INTO O_BATTR
	VALUES (3471,
	3165);
INSERT INTO O_ATTR
	VALUES (3471,
	3165,
	3533,
	'socket_id',
	'',
	'',
	'socket_id',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3484,
	3165);
INSERT INTO O_BATTR
	VALUES (3484,
	3165);
INSERT INTO O_ATTR
	VALUES (3484,
	3165,
	3471,
	'timer',
	'',
	'',
	'timer',
	0,
	1272,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	3165);
INSERT INTO O_OIDA
	VALUES (3530,
	3165,
	0,
	'id');
INSERT INTO O_ID
	VALUES (1,
	3165);
INSERT INTO O_ID
	VALUES (2,
	3165);
INSERT INTO SM_ISM
	VALUES (3534,
	3165);
INSERT INTO SM_SM
	VALUES (3534,
	'',
	0);
INSERT INTO SM_MOORE
	VALUES (3534);
INSERT INTO SM_LEVT
	VALUES (3535,
	3534,
	0);
INSERT INTO SM_SEVT
	VALUES (3535,
	3534,
	0);
INSERT INTO SM_EVT
	VALUES (3535,
	3534,
	0,
	3,
	'setTargetPressed',
	0,
	'',
	'UI3',
	'');
INSERT INTO SM_LEVT
	VALUES (3536,
	3534,
	0);
INSERT INTO SM_SEVT
	VALUES (3536,
	3534,
	0);
INSERT INTO SM_EVT
	VALUES (3536,
	3534,
	0,
	4,
	'startStopPressed',
	0,
	'',
	'UI4',
	'');
INSERT INTO SM_LEVT
	VALUES (3537,
	3534,
	0);
INSERT INTO SM_SEVT
	VALUES (3537,
	3534,
	0);
INSERT INTO SM_EVT
	VALUES (3537,
	3534,
	0,
	5,
	'lapResetPressed',
	0,
	'',
	'UI5',
	'');
INSERT INTO SM_LEVT
	VALUES (3538,
	3534,
	0);
INSERT INTO SM_SEVT
	VALUES (3538,
	3534,
	0);
INSERT INTO SM_EVT
	VALUES (3538,
	3534,
	0,
	6,
	'lightPressed',
	0,
	'',
	'UI6',
	'');
INSERT INTO SM_LEVT
	VALUES (3539,
	3534,
	0);
INSERT INTO SM_SEVT
	VALUES (3539,
	3534,
	0);
INSERT INTO SM_EVT
	VALUES (3539,
	3534,
	0,
	7,
	'modePressed',
	0,
	'',
	'UI7',
	'');
INSERT INTO SM_LEVT
	VALUES (3540,
	3534,
	0);
INSERT INTO SM_SEVT
	VALUES (3540,
	3534,
	0);
INSERT INTO SM_EVT
	VALUES (3540,
	3534,
	0,
	8,
	'running',
	0,
	'',
	'UI8',
	'');
INSERT INTO SM_LEVT
	VALUES (3480,
	3534,
	0);
INSERT INTO SM_SEVT
	VALUES (3480,
	3534,
	0);
INSERT INTO SM_EVT
	VALUES (3480,
	3534,
	0,
	9,
	'tick',
	0,
	'',
	'UI9',
	'');
INSERT INTO SM_STATE
	VALUES (3541,
	3534,
	0,
	'running',
	1,
	0);
INSERT INTO SM_SEME
	VALUES (3541,
	3535,
	3534,
	0);
INSERT INTO SM_SEME
	VALUES (3541,
	3536,
	3534,
	0);
INSERT INTO SM_SEME
	VALUES (3541,
	3537,
	3534,
	0);
INSERT INTO SM_SEME
	VALUES (3541,
	3538,
	3534,
	0);
INSERT INTO SM_SEME
	VALUES (3541,
	3539,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3541,
	3540,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3541,
	3540,
	3534,
	0);
INSERT INTO SM_SEME
	VALUES (3541,
	3480,
	3534,
	0);
INSERT INTO SM_MOAH
	VALUES (3542,
	3534,
	3541);
INSERT INTO SM_AH
	VALUES (3542,
	3534);
INSERT INTO SM_ACT
	VALUES (3542,
	3534,
	1,
	'UIConstants::initialize();
select any uiconst from instances of UIConstants;
signal_no = self.poll();
if ( uiconst.SOCKET_ERROR == signal_no )
  self.socket_id = uiconst.SOCKET_ERROR;
  res = TIM::timer_cancel( timer_inst_ref:self.timer );
elif ( uiconst.SIGNAL_NO_START_STOP_PRESSED == signal_no )
  generate UI4:startStopPressed() to self;
elif ( uiconst.SIGNAL_NO_TARGET_PRESSED == signal_no )	
  generate UI3:setTargetPressed() to self;
elif ( uiconst.SIGNAL_NO_LAP_RESET_PRESSED == signal_no )	
  generate UI5:lapResetPressed() to self;
elif ( uiconst.SIGNAL_NO_LIGHT_PRESSED == signal_no )	
  generate UI6:lightPressed() to self;
elif ( uiconst.SIGNAL_NO_MODE_PRESSED == signal_no )	
  generate UI7:modePressed() to self;
end if;',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (3543,
	3534,
	3542);
INSERT INTO ACT_ACT
	VALUES (3543,
	'state',
	0,
	3544,
	0,
	0,
	'UI::running',
	0);
INSERT INTO ACT_BLK
	VALUES (3544,
	1,
	0,
	0,
	'UIConstants',
	'',
	'',
	15,
	1,
	2,
	38,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3543,
	0);
INSERT INTO ACT_SMT
	VALUES (3545,
	3544,
	3546,
	1,
	1,
	'UI::running line: 1');
INSERT INTO ACT_TFM
	VALUES (3545,
	3457,
	0,
	1,
	14,
	1,
	1);
INSERT INTO ACT_SMT
	VALUES (3546,
	3544,
	3547,
	2,
	1,
	'UI::running line: 2');
INSERT INTO ACT_FIO
	VALUES (3546,
	3548,
	1,
	'any',
	3460,
	2,
	38);
INSERT INTO ACT_SMT
	VALUES (3547,
	3544,
	3549,
	3,
	1,
	'UI::running line: 3');
INSERT INTO ACT_AI
	VALUES (3547,
	3550,
	3551,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3549,
	3544,
	0,
	4,
	1,
	'UI::running line: 4');
INSERT INTO ACT_IF
	VALUES (3549,
	3552,
	3553,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3554,
	3544,
	0,
	7,
	1,
	'UI::running line: 7');
INSERT INTO ACT_EL
	VALUES (3554,
	3555,
	3556,
	3549);
INSERT INTO ACT_SMT
	VALUES (3557,
	3544,
	0,
	9,
	1,
	'UI::running line: 9');
INSERT INTO ACT_EL
	VALUES (3557,
	3558,
	3559,
	3549);
INSERT INTO ACT_SMT
	VALUES (3560,
	3544,
	0,
	11,
	1,
	'UI::running line: 11');
INSERT INTO ACT_EL
	VALUES (3560,
	3561,
	3562,
	3549);
INSERT INTO ACT_SMT
	VALUES (3563,
	3544,
	0,
	13,
	1,
	'UI::running line: 13');
INSERT INTO ACT_EL
	VALUES (3563,
	3564,
	3565,
	3549);
INSERT INTO ACT_SMT
	VALUES (3566,
	3544,
	0,
	15,
	1,
	'UI::running line: 15');
INSERT INTO ACT_EL
	VALUES (3566,
	3567,
	3568,
	3549);
INSERT INTO V_VAL
	VALUES (3551,
	1,
	1,
	3,
	1,
	9,
	0,
	0,
	0,
	0,
	160,
	3544);
INSERT INTO V_TVL
	VALUES (3551,
	3569);
INSERT INTO V_VAL
	VALUES (3550,
	0,
	0,
	3,
	18,
	-1,
	0,
	0,
	0,
	0,
	160,
	3544);
INSERT INTO V_TRV
	VALUES (3550,
	3489,
	3570,
	1,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3571,
	0,
	0,
	4,
	6,
	12,
	0,
	0,
	0,
	0,
	1309,
	3544);
INSERT INTO V_IRF
	VALUES (3571,
	3548);
INSERT INTO V_VAL
	VALUES (3572,
	0,
	0,
	4,
	14,
	25,
	0,
	0,
	0,
	0,
	160,
	3544);
INSERT INTO V_AVL
	VALUES (3572,
	3571,
	3460,
	3474);
INSERT INTO V_VAL
	VALUES (3553,
	0,
	0,
	4,
	14,
	38,
	0,
	0,
	0,
	0,
	125,
	3544);
INSERT INTO V_BIN
	VALUES (3553,
	3573,
	3572,
	'==');
INSERT INTO V_VAL
	VALUES (3573,
	0,
	0,
	4,
	30,
	38,
	0,
	0,
	0,
	0,
	160,
	3544);
INSERT INTO V_TVL
	VALUES (3573,
	3569);
INSERT INTO V_VAL
	VALUES (3574,
	0,
	0,
	7,
	8,
	14,
	0,
	0,
	0,
	0,
	1309,
	3544);
INSERT INTO V_IRF
	VALUES (3574,
	3548);
INSERT INTO V_VAL
	VALUES (3575,
	0,
	0,
	7,
	16,
	43,
	0,
	0,
	0,
	0,
	160,
	3544);
INSERT INTO V_AVL
	VALUES (3575,
	3574,
	3460,
	3576);
INSERT INTO V_VAL
	VALUES (3556,
	0,
	0,
	7,
	16,
	56,
	0,
	0,
	0,
	0,
	125,
	3544);
INSERT INTO V_BIN
	VALUES (3556,
	3577,
	3575,
	'==');
INSERT INTO V_VAL
	VALUES (3577,
	0,
	0,
	7,
	48,
	56,
	0,
	0,
	0,
	0,
	160,
	3544);
INSERT INTO V_TVL
	VALUES (3577,
	3569);
INSERT INTO V_VAL
	VALUES (3578,
	0,
	0,
	9,
	8,
	14,
	0,
	0,
	0,
	0,
	1309,
	3544);
INSERT INTO V_IRF
	VALUES (3578,
	3548);
INSERT INTO V_VAL
	VALUES (3579,
	0,
	0,
	9,
	16,
	39,
	0,
	0,
	0,
	0,
	160,
	3544);
INSERT INTO V_AVL
	VALUES (3579,
	3578,
	3460,
	3580);
INSERT INTO V_VAL
	VALUES (3559,
	0,
	0,
	9,
	16,
	52,
	0,
	0,
	0,
	0,
	125,
	3544);
INSERT INTO V_BIN
	VALUES (3559,
	3581,
	3579,
	'==');
INSERT INTO V_VAL
	VALUES (3581,
	0,
	0,
	9,
	44,
	52,
	0,
	0,
	0,
	0,
	160,
	3544);
INSERT INTO V_TVL
	VALUES (3581,
	3569);
INSERT INTO V_VAL
	VALUES (3582,
	0,
	0,
	11,
	8,
	14,
	0,
	0,
	0,
	0,
	1309,
	3544);
INSERT INTO V_IRF
	VALUES (3582,
	3548);
INSERT INTO V_VAL
	VALUES (3583,
	0,
	0,
	11,
	16,
	42,
	0,
	0,
	0,
	0,
	160,
	3544);
INSERT INTO V_AVL
	VALUES (3583,
	3582,
	3460,
	3584);
INSERT INTO V_VAL
	VALUES (3562,
	0,
	0,
	11,
	16,
	55,
	0,
	0,
	0,
	0,
	125,
	3544);
INSERT INTO V_BIN
	VALUES (3562,
	3585,
	3583,
	'==');
INSERT INTO V_VAL
	VALUES (3585,
	0,
	0,
	11,
	47,
	55,
	0,
	0,
	0,
	0,
	160,
	3544);
INSERT INTO V_TVL
	VALUES (3585,
	3569);
INSERT INTO V_VAL
	VALUES (3586,
	0,
	0,
	13,
	8,
	14,
	0,
	0,
	0,
	0,
	1309,
	3544);
INSERT INTO V_IRF
	VALUES (3586,
	3548);
INSERT INTO V_VAL
	VALUES (3587,
	0,
	0,
	13,
	16,
	38,
	0,
	0,
	0,
	0,
	160,
	3544);
INSERT INTO V_AVL
	VALUES (3587,
	3586,
	3460,
	3588);
INSERT INTO V_VAL
	VALUES (3565,
	0,
	0,
	13,
	16,
	51,
	0,
	0,
	0,
	0,
	125,
	3544);
INSERT INTO V_BIN
	VALUES (3565,
	3589,
	3587,
	'==');
INSERT INTO V_VAL
	VALUES (3589,
	0,
	0,
	13,
	43,
	51,
	0,
	0,
	0,
	0,
	160,
	3544);
INSERT INTO V_TVL
	VALUES (3589,
	3569);
INSERT INTO V_VAL
	VALUES (3590,
	0,
	0,
	15,
	8,
	14,
	0,
	0,
	0,
	0,
	1309,
	3544);
INSERT INTO V_IRF
	VALUES (3590,
	3548);
INSERT INTO V_VAL
	VALUES (3591,
	0,
	0,
	15,
	16,
	37,
	0,
	0,
	0,
	0,
	160,
	3544);
INSERT INTO V_AVL
	VALUES (3591,
	3590,
	3460,
	3592);
INSERT INTO V_VAL
	VALUES (3568,
	0,
	0,
	15,
	16,
	50,
	0,
	0,
	0,
	0,
	125,
	3544);
INSERT INTO V_BIN
	VALUES (3568,
	3593,
	3591,
	'==');
INSERT INTO V_VAL
	VALUES (3593,
	0,
	0,
	15,
	42,
	50,
	0,
	0,
	0,
	0,
	160,
	3544);
INSERT INTO V_TVL
	VALUES (3593,
	3569);
INSERT INTO V_VAR
	VALUES (3548,
	3544,
	'uiconst',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3548,
	0,
	3460);
INSERT INTO V_VAR
	VALUES (3569,
	3544,
	'signal_no',
	1,
	160);
INSERT INTO V_TRN
	VALUES (3569,
	0,
	'');
INSERT INTO V_VAR
	VALUES (3570,
	3544,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3570,
	0,
	3165);
INSERT INTO ACT_BLK
	VALUES (3552,
	0,
	0,
	0,
	'TIM',
	'',
	'',
	6,
	3,
	6,
	9,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3543,
	0);
INSERT INTO ACT_SMT
	VALUES (3594,
	3552,
	3595,
	5,
	3,
	'UI::running line: 5');
INSERT INTO ACT_AI
	VALUES (3594,
	3596,
	3597,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3595,
	3552,
	0,
	6,
	3,
	'UI::running line: 6');
INSERT INTO ACT_AI
	VALUES (3595,
	3598,
	3599,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3600,
	1,
	0,
	5,
	3,
	6,
	0,
	0,
	0,
	0,
	1309,
	3552);
INSERT INTO V_IRF
	VALUES (3600,
	3570);
INSERT INTO V_VAL
	VALUES (3597,
	1,
	0,
	5,
	8,
	16,
	0,
	0,
	0,
	0,
	160,
	3552);
INSERT INTO V_AVL
	VALUES (3597,
	3600,
	3165,
	3471);
INSERT INTO V_VAL
	VALUES (3601,
	0,
	0,
	5,
	20,
	26,
	0,
	0,
	0,
	0,
	1309,
	3552);
INSERT INTO V_IRF
	VALUES (3601,
	3548);
INSERT INTO V_VAL
	VALUES (3596,
	0,
	0,
	5,
	28,
	39,
	0,
	0,
	0,
	0,
	160,
	3552);
INSERT INTO V_AVL
	VALUES (3596,
	3601,
	3460,
	3474);
INSERT INTO V_VAL
	VALUES (3599,
	1,
	1,
	6,
	3,
	5,
	0,
	0,
	0,
	0,
	125,
	3552);
INSERT INTO V_TVL
	VALUES (3599,
	3602);
INSERT INTO V_VAL
	VALUES (3598,
	0,
	0,
	6,
	14,
	-1,
	6,
	28,
	0,
	0,
	125,
	3552);
INSERT INTO V_BRV
	VALUES (3598,
	1297,
	1,
	6,
	9);
INSERT INTO V_VAL
	VALUES (3603,
	0,
	0,
	6,
	43,
	46,
	0,
	0,
	0,
	0,
	1309,
	3552);
INSERT INTO V_IRF
	VALUES (3603,
	3570);
INSERT INTO V_VAL
	VALUES (3604,
	0,
	0,
	6,
	48,
	52,
	0,
	0,
	0,
	0,
	1272,
	3552);
INSERT INTO V_AVL
	VALUES (3604,
	3603,
	3165,
	3484);
INSERT INTO V_PAR
	VALUES (3604,
	0,
	3598,
	'timer_inst_ref',
	0,
	6,
	28);
INSERT INTO V_VAR
	VALUES (3602,
	3552,
	'res',
	1,
	125);
INSERT INTO V_TRN
	VALUES (3602,
	0,
	'');
INSERT INTO ACT_BLK
	VALUES (3555,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	8,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3543,
	0);
INSERT INTO ACT_SMT
	VALUES (3605,
	3555,
	0,
	8,
	3,
	'UI::running line: 8');
INSERT INTO E_ESS
	VALUES (3605,
	1,
	0,
	8,
	12,
	8,
	16,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (3605);
INSERT INTO E_GSME
	VALUES (3605,
	3536);
INSERT INTO E_GEN
	VALUES (3605,
	3570);
INSERT INTO ACT_BLK
	VALUES (3558,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	10,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3543,
	0);
INSERT INTO ACT_SMT
	VALUES (3606,
	3558,
	0,
	10,
	3,
	'UI::running line: 10');
INSERT INTO E_ESS
	VALUES (3606,
	1,
	0,
	10,
	12,
	10,
	16,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (3606);
INSERT INTO E_GSME
	VALUES (3606,
	3535);
INSERT INTO E_GEN
	VALUES (3606,
	3570);
INSERT INTO ACT_BLK
	VALUES (3561,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	12,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3543,
	0);
INSERT INTO ACT_SMT
	VALUES (3607,
	3561,
	0,
	12,
	3,
	'UI::running line: 12');
INSERT INTO E_ESS
	VALUES (3607,
	1,
	0,
	12,
	12,
	12,
	16,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (3607);
INSERT INTO E_GSME
	VALUES (3607,
	3537);
INSERT INTO E_GEN
	VALUES (3607,
	3570);
INSERT INTO ACT_BLK
	VALUES (3564,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	14,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3543,
	0);
INSERT INTO ACT_SMT
	VALUES (3608,
	3564,
	0,
	14,
	3,
	'UI::running line: 14');
INSERT INTO E_ESS
	VALUES (3608,
	1,
	0,
	14,
	12,
	14,
	16,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (3608);
INSERT INTO E_GSME
	VALUES (3608,
	3538);
INSERT INTO E_GEN
	VALUES (3608,
	3570);
INSERT INTO ACT_BLK
	VALUES (3567,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	16,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3543,
	0);
INSERT INTO ACT_SMT
	VALUES (3609,
	3567,
	0,
	16,
	3,
	'UI::running line: 16');
INSERT INTO E_ESS
	VALUES (3609,
	1,
	0,
	16,
	12,
	16,
	16,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (3609);
INSERT INTO E_GSME
	VALUES (3609,
	3539);
INSERT INTO E_GEN
	VALUES (3609,
	3570);
INSERT INTO SM_STATE
	VALUES (3610,
	3534,
	0,
	'setTargetPressed',
	2,
	0);
INSERT INTO SM_CH
	VALUES (3610,
	3535,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3610,
	3535,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3610,
	3536,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3610,
	3536,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3610,
	3537,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3610,
	3537,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3610,
	3538,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3610,
	3538,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3610,
	3539,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3610,
	3539,
	3534,
	0);
INSERT INTO SM_SEME
	VALUES (3610,
	3540,
	3534,
	0);
INSERT INTO SM_EIGN
	VALUES (3610,
	3480,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3610,
	3480,
	3534,
	0);
INSERT INTO SM_MOAH
	VALUES (3611,
	3534,
	3610);
INSERT INTO SM_AH
	VALUES (3611,
	3534);
INSERT INTO SM_ACT
	VALUES (3611,
	3534,
	1,
	'::sendTargetPressed();
generate UI8:running() to self;',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (3612,
	3534,
	3611);
INSERT INTO ACT_ACT
	VALUES (3612,
	'state',
	0,
	3613,
	0,
	0,
	'UI::setTargetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3613,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3612,
	0);
INSERT INTO ACT_SMT
	VALUES (3614,
	3613,
	3615,
	1,
	1,
	'UI::setTargetPressed line: 1');
INSERT INTO ACT_FNC
	VALUES (3614,
	3616,
	1,
	3);
INSERT INTO ACT_SMT
	VALUES (3615,
	3613,
	0,
	2,
	1,
	'UI::setTargetPressed line: 2');
INSERT INTO E_ESS
	VALUES (3615,
	1,
	0,
	2,
	10,
	2,
	14,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (3615);
INSERT INTO E_GSME
	VALUES (3615,
	3540);
INSERT INTO E_GEN
	VALUES (3615,
	3617);
INSERT INTO V_VAR
	VALUES (3617,
	3613,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3617,
	0,
	3165);
INSERT INTO SM_STATE
	VALUES (3618,
	3534,
	0,
	'startStopPresssed',
	3,
	0);
INSERT INTO SM_CH
	VALUES (3618,
	3535,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3618,
	3535,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3618,
	3536,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3618,
	3536,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3618,
	3537,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3618,
	3537,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3618,
	3538,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3618,
	3538,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3618,
	3539,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3618,
	3539,
	3534,
	0);
INSERT INTO SM_SEME
	VALUES (3618,
	3540,
	3534,
	0);
INSERT INTO SM_EIGN
	VALUES (3618,
	3480,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3618,
	3480,
	3534,
	0);
INSERT INTO SM_MOAH
	VALUES (3619,
	3534,
	3618);
INSERT INTO SM_AH
	VALUES (3619,
	3534);
INSERT INTO SM_ACT
	VALUES (3619,
	3534,
	1,
	'::sendStartStopPressed();
generate UI8:running() to self;',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (3620,
	3534,
	3619);
INSERT INTO ACT_ACT
	VALUES (3620,
	'state',
	0,
	3621,
	0,
	0,
	'UI::startStopPresssed',
	0);
INSERT INTO ACT_BLK
	VALUES (3621,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3620,
	0);
INSERT INTO ACT_SMT
	VALUES (3622,
	3621,
	3623,
	1,
	1,
	'UI::startStopPresssed line: 1');
INSERT INTO ACT_FNC
	VALUES (3622,
	3624,
	1,
	3);
INSERT INTO ACT_SMT
	VALUES (3623,
	3621,
	0,
	2,
	1,
	'UI::startStopPresssed line: 2');
INSERT INTO E_ESS
	VALUES (3623,
	1,
	0,
	2,
	10,
	2,
	14,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (3623);
INSERT INTO E_GSME
	VALUES (3623,
	3540);
INSERT INTO E_GEN
	VALUES (3623,
	3625);
INSERT INTO V_VAR
	VALUES (3625,
	3621,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3625,
	0,
	3165);
INSERT INTO SM_STATE
	VALUES (3626,
	3534,
	0,
	'lapResetPressed',
	4,
	0);
INSERT INTO SM_CH
	VALUES (3626,
	3535,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3626,
	3535,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3626,
	3536,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3626,
	3536,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3626,
	3537,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3626,
	3537,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3626,
	3538,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3626,
	3538,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3626,
	3539,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3626,
	3539,
	3534,
	0);
INSERT INTO SM_SEME
	VALUES (3626,
	3540,
	3534,
	0);
INSERT INTO SM_EIGN
	VALUES (3626,
	3480,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3626,
	3480,
	3534,
	0);
INSERT INTO SM_MOAH
	VALUES (3627,
	3534,
	3626);
INSERT INTO SM_AH
	VALUES (3627,
	3534);
INSERT INTO SM_ACT
	VALUES (3627,
	3534,
	1,
	'::sendLapResetPressed();
generate UI8:running() to self;',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (3628,
	3534,
	3627);
INSERT INTO ACT_ACT
	VALUES (3628,
	'state',
	0,
	3629,
	0,
	0,
	'UI::lapResetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3629,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3628,
	0);
INSERT INTO ACT_SMT
	VALUES (3630,
	3629,
	3631,
	1,
	1,
	'UI::lapResetPressed line: 1');
INSERT INTO ACT_FNC
	VALUES (3630,
	3632,
	1,
	3);
INSERT INTO ACT_SMT
	VALUES (3631,
	3629,
	0,
	2,
	1,
	'UI::lapResetPressed line: 2');
INSERT INTO E_ESS
	VALUES (3631,
	1,
	0,
	2,
	10,
	2,
	14,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (3631);
INSERT INTO E_GSME
	VALUES (3631,
	3540);
INSERT INTO E_GEN
	VALUES (3631,
	3633);
INSERT INTO V_VAR
	VALUES (3633,
	3629,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3633,
	0,
	3165);
INSERT INTO SM_STATE
	VALUES (3634,
	3534,
	0,
	'lightPressed',
	5,
	0);
INSERT INTO SM_CH
	VALUES (3634,
	3535,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3634,
	3535,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3634,
	3536,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3634,
	3536,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3634,
	3537,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3634,
	3537,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3634,
	3538,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3634,
	3538,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3634,
	3539,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3634,
	3539,
	3534,
	0);
INSERT INTO SM_SEME
	VALUES (3634,
	3540,
	3534,
	0);
INSERT INTO SM_EIGN
	VALUES (3634,
	3480,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3634,
	3480,
	3534,
	0);
INSERT INTO SM_MOAH
	VALUES (3635,
	3534,
	3634);
INSERT INTO SM_AH
	VALUES (3635,
	3534);
INSERT INTO SM_ACT
	VALUES (3635,
	3534,
	1,
	'::sendLightPressed();
generate UI8:running() to self;',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (3636,
	3534,
	3635);
INSERT INTO ACT_ACT
	VALUES (3636,
	'state',
	0,
	3637,
	0,
	0,
	'UI::lightPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3637,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3636,
	0);
INSERT INTO ACT_SMT
	VALUES (3638,
	3637,
	3639,
	1,
	1,
	'UI::lightPressed line: 1');
INSERT INTO ACT_FNC
	VALUES (3638,
	3640,
	1,
	3);
INSERT INTO ACT_SMT
	VALUES (3639,
	3637,
	0,
	2,
	1,
	'UI::lightPressed line: 2');
INSERT INTO E_ESS
	VALUES (3639,
	1,
	0,
	2,
	10,
	2,
	14,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (3639);
INSERT INTO E_GSME
	VALUES (3639,
	3540);
INSERT INTO E_GEN
	VALUES (3639,
	3641);
INSERT INTO V_VAR
	VALUES (3641,
	3637,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3641,
	0,
	3165);
INSERT INTO SM_STATE
	VALUES (3642,
	3534,
	0,
	'modePressed',
	6,
	0);
INSERT INTO SM_CH
	VALUES (3642,
	3535,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3642,
	3535,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3642,
	3536,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3642,
	3536,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3642,
	3537,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3642,
	3537,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3642,
	3538,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3642,
	3538,
	3534,
	0);
INSERT INTO SM_CH
	VALUES (3642,
	3539,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3642,
	3539,
	3534,
	0);
INSERT INTO SM_SEME
	VALUES (3642,
	3540,
	3534,
	0);
INSERT INTO SM_EIGN
	VALUES (3642,
	3480,
	3534,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3642,
	3480,
	3534,
	0);
INSERT INTO SM_MOAH
	VALUES (3643,
	3534,
	3642);
INSERT INTO SM_AH
	VALUES (3643,
	3534);
INSERT INTO SM_ACT
	VALUES (3643,
	3534,
	1,
	'::sendModePressed();
generate UI8:running() to self;',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (3644,
	3534,
	3643);
INSERT INTO ACT_ACT
	VALUES (3644,
	'state',
	0,
	3645,
	0,
	0,
	'UI::modePressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3645,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	2,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3644,
	0);
INSERT INTO ACT_SMT
	VALUES (3646,
	3645,
	3647,
	1,
	1,
	'UI::modePressed line: 1');
INSERT INTO ACT_FNC
	VALUES (3646,
	3648,
	1,
	3);
INSERT INTO ACT_SMT
	VALUES (3647,
	3645,
	0,
	2,
	1,
	'UI::modePressed line: 2');
INSERT INTO E_ESS
	VALUES (3647,
	1,
	0,
	2,
	10,
	2,
	14,
	0,
	0,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (3647);
INSERT INTO E_GSME
	VALUES (3647,
	3540);
INSERT INTO E_GEN
	VALUES (3647,
	3649);
INSERT INTO V_VAR
	VALUES (3649,
	3645,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3649,
	0,
	3165);
INSERT INTO SM_NSTXN
	VALUES (3650,
	3534,
	3541,
	3536,
	0);
INSERT INTO SM_TAH
	VALUES (3651,
	3534,
	3650);
INSERT INTO SM_AH
	VALUES (3651,
	3534);
INSERT INTO SM_ACT
	VALUES (3651,
	3534,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3652,
	3534,
	3651);
INSERT INTO ACT_ACT
	VALUES (3652,
	'transition',
	0,
	3653,
	0,
	0,
	'UI4: startStopPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3653,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3652,
	0);
INSERT INTO SM_TXN
	VALUES (3650,
	3534,
	3618,
	0);
INSERT INTO SM_NSTXN
	VALUES (3654,
	3534,
	3618,
	3540,
	0);
INSERT INTO SM_TAH
	VALUES (3655,
	3534,
	3654);
INSERT INTO SM_AH
	VALUES (3655,
	3534);
INSERT INTO SM_ACT
	VALUES (3655,
	3534,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3656,
	3534,
	3655);
INSERT INTO ACT_ACT
	VALUES (3656,
	'transition',
	0,
	3657,
	0,
	0,
	'UI8: running',
	0);
INSERT INTO ACT_BLK
	VALUES (3657,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3656,
	0);
INSERT INTO SM_TXN
	VALUES (3654,
	3534,
	3541,
	0);
INSERT INTO SM_NSTXN
	VALUES (3658,
	3534,
	3541,
	3538,
	0);
INSERT INTO SM_TAH
	VALUES (3659,
	3534,
	3658);
INSERT INTO SM_AH
	VALUES (3659,
	3534);
INSERT INTO SM_ACT
	VALUES (3659,
	3534,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3660,
	3534,
	3659);
INSERT INTO ACT_ACT
	VALUES (3660,
	'transition',
	0,
	3661,
	0,
	0,
	'UI6: lightPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3661,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3660,
	0);
INSERT INTO SM_TXN
	VALUES (3658,
	3534,
	3634,
	0);
INSERT INTO SM_NSTXN
	VALUES (3662,
	3534,
	3634,
	3540,
	0);
INSERT INTO SM_TAH
	VALUES (3663,
	3534,
	3662);
INSERT INTO SM_AH
	VALUES (3663,
	3534);
INSERT INTO SM_ACT
	VALUES (3663,
	3534,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3664,
	3534,
	3663);
INSERT INTO ACT_ACT
	VALUES (3664,
	'transition',
	0,
	3665,
	0,
	0,
	'UI8: running',
	0);
INSERT INTO ACT_BLK
	VALUES (3665,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3664,
	0);
INSERT INTO SM_TXN
	VALUES (3662,
	3534,
	3541,
	0);
INSERT INTO SM_NSTXN
	VALUES (3666,
	3534,
	3541,
	3535,
	0);
INSERT INTO SM_TAH
	VALUES (3667,
	3534,
	3666);
INSERT INTO SM_AH
	VALUES (3667,
	3534);
INSERT INTO SM_ACT
	VALUES (3667,
	3534,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3668,
	3534,
	3667);
INSERT INTO ACT_ACT
	VALUES (3668,
	'transition',
	0,
	3669,
	0,
	0,
	'UI3: setTargetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3669,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3668,
	0);
INSERT INTO SM_TXN
	VALUES (3666,
	3534,
	3610,
	0);
INSERT INTO SM_NSTXN
	VALUES (3670,
	3534,
	3610,
	3540,
	0);
INSERT INTO SM_TAH
	VALUES (3671,
	3534,
	3670);
INSERT INTO SM_AH
	VALUES (3671,
	3534);
INSERT INTO SM_ACT
	VALUES (3671,
	3534,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3672,
	3534,
	3671);
INSERT INTO ACT_ACT
	VALUES (3672,
	'transition',
	0,
	3673,
	0,
	0,
	'UI8: running',
	0);
INSERT INTO ACT_BLK
	VALUES (3673,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3672,
	0);
INSERT INTO SM_TXN
	VALUES (3670,
	3534,
	3541,
	0);
INSERT INTO SM_NSTXN
	VALUES (3674,
	3534,
	3541,
	3537,
	0);
INSERT INTO SM_TAH
	VALUES (3675,
	3534,
	3674);
INSERT INTO SM_AH
	VALUES (3675,
	3534);
INSERT INTO SM_ACT
	VALUES (3675,
	3534,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3676,
	3534,
	3675);
INSERT INTO ACT_ACT
	VALUES (3676,
	'transition',
	0,
	3677,
	0,
	0,
	'UI5: lapResetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3677,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3676,
	0);
INSERT INTO SM_TXN
	VALUES (3674,
	3534,
	3626,
	0);
INSERT INTO SM_NSTXN
	VALUES (3678,
	3534,
	3626,
	3540,
	0);
INSERT INTO SM_TAH
	VALUES (3679,
	3534,
	3678);
INSERT INTO SM_AH
	VALUES (3679,
	3534);
INSERT INTO SM_ACT
	VALUES (3679,
	3534,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3680,
	3534,
	3679);
INSERT INTO ACT_ACT
	VALUES (3680,
	'transition',
	0,
	3681,
	0,
	0,
	'UI8: running',
	0);
INSERT INTO ACT_BLK
	VALUES (3681,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3680,
	0);
INSERT INTO SM_TXN
	VALUES (3678,
	3534,
	3541,
	0);
INSERT INTO SM_NSTXN
	VALUES (3682,
	3534,
	3541,
	3539,
	0);
INSERT INTO SM_TAH
	VALUES (3683,
	3534,
	3682);
INSERT INTO SM_AH
	VALUES (3683,
	3534);
INSERT INTO SM_ACT
	VALUES (3683,
	3534,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3684,
	3534,
	3683);
INSERT INTO ACT_ACT
	VALUES (3684,
	'transition',
	0,
	3685,
	0,
	0,
	'UI7: modePressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3685,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3684,
	0);
INSERT INTO SM_TXN
	VALUES (3682,
	3534,
	3642,
	0);
INSERT INTO SM_NSTXN
	VALUES (3686,
	3534,
	3642,
	3540,
	0);
INSERT INTO SM_TAH
	VALUES (3687,
	3534,
	3686);
INSERT INTO SM_AH
	VALUES (3687,
	3534);
INSERT INTO SM_ACT
	VALUES (3687,
	3534,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3688,
	3534,
	3687);
INSERT INTO ACT_ACT
	VALUES (3688,
	'transition',
	0,
	3689,
	0,
	0,
	'UI8: running',
	0);
INSERT INTO ACT_BLK
	VALUES (3689,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3688,
	0);
INSERT INTO SM_TXN
	VALUES (3686,
	3534,
	3541,
	0);
INSERT INTO SM_NSTXN
	VALUES (3690,
	3534,
	3541,
	3480,
	0);
INSERT INTO SM_TAH
	VALUES (3691,
	3534,
	3690);
INSERT INTO SM_AH
	VALUES (3691,
	3534);
INSERT INTO SM_ACT
	VALUES (3691,
	3534,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3692,
	3534,
	3691);
INSERT INTO ACT_ACT
	VALUES (3692,
	'transition',
	0,
	3693,
	0,
	0,
	'UI9: tick',
	0);
INSERT INTO ACT_BLK
	VALUES (3693,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3692,
	0);
INSERT INTO SM_TXN
	VALUES (3690,
	3534,
	3541,
	0);
INSERT INTO PE_PE
	VALUES (3460,
	1,
	3363,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (3460,
	'UIConstants',
	3,
	'UIConstants',
	'',
	0);
INSERT INTO O_TFR
	VALUES (3457,
	3460,
	'initialize',
	'',
	1192,
	0,
	'select any uiconst from instances of UIConstants;
if ( empty uiconst )
  create object instance uiconst of UIConstants; uiconst.id = 1;
  uiconst.SIGNAL_NO_NULL_SIGNAL = 0;
  uiconst.SIGNAL_NO_START_STOP_PRESSED = 1;
  uiconst.SIGNAL_NO_TARGET_PRESSED = 2;
  uiconst.SIGNAL_NO_LAP_RESET_PRESSED = 3;
  uiconst.SIGNAL_NO_LIGHT_PRESSED = 4;
  uiconst.SIGNAL_NO_MODE_PRESSED = 5;
  uiconst.SOCKET_ERROR = -1;
  uiconst.tick_period = 100000; // in microseconds
end if;',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (3694,
	3457);
INSERT INTO ACT_ACT
	VALUES (3694,
	'class operation',
	0,
	3695,
	0,
	0,
	'UIConstants::initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (3695,
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	38,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3694,
	0);
INSERT INTO ACT_SMT
	VALUES (3696,
	3695,
	3697,
	1,
	1,
	'UIConstants::initialize line: 1');
INSERT INTO ACT_FIO
	VALUES (3696,
	3698,
	1,
	'any',
	3460,
	1,
	38);
INSERT INTO ACT_SMT
	VALUES (3697,
	3695,
	0,
	2,
	1,
	'UIConstants::initialize line: 2');
INSERT INTO ACT_IF
	VALUES (3697,
	3699,
	3700,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3701,
	0,
	0,
	2,
	12,
	18,
	0,
	0,
	0,
	0,
	1309,
	3695);
INSERT INTO V_IRF
	VALUES (3701,
	3698);
INSERT INTO V_VAL
	VALUES (3700,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	3695);
INSERT INTO V_UNY
	VALUES (3700,
	3701,
	'empty');
INSERT INTO V_VAR
	VALUES (3698,
	3695,
	'uiconst',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3698,
	0,
	3460);
INSERT INTO ACT_BLK
	VALUES (3699,
	0,
	0,
	0,
	'',
	'',
	'',
	11,
	3,
	3,
	37,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3694,
	0);
INSERT INTO ACT_SMT
	VALUES (3702,
	3699,
	3703,
	3,
	3,
	'UIConstants::initialize line: 3');
INSERT INTO ACT_CR
	VALUES (3702,
	3698,
	0,
	3460,
	3,
	37);
INSERT INTO ACT_SMT
	VALUES (3703,
	3699,
	3704,
	3,
	50,
	'UIConstants::initialize line: 3');
INSERT INTO ACT_AI
	VALUES (3703,
	3705,
	3706,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3704,
	3699,
	3707,
	4,
	3,
	'UIConstants::initialize line: 4');
INSERT INTO ACT_AI
	VALUES (3704,
	3708,
	3709,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3707,
	3699,
	3710,
	5,
	3,
	'UIConstants::initialize line: 5');
INSERT INTO ACT_AI
	VALUES (3707,
	3711,
	3712,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3710,
	3699,
	3713,
	6,
	3,
	'UIConstants::initialize line: 6');
INSERT INTO ACT_AI
	VALUES (3710,
	3714,
	3715,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3713,
	3699,
	3716,
	7,
	3,
	'UIConstants::initialize line: 7');
INSERT INTO ACT_AI
	VALUES (3713,
	3717,
	3718,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3716,
	3699,
	3719,
	8,
	3,
	'UIConstants::initialize line: 8');
INSERT INTO ACT_AI
	VALUES (3716,
	3720,
	3721,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3719,
	3699,
	3722,
	9,
	3,
	'UIConstants::initialize line: 9');
INSERT INTO ACT_AI
	VALUES (3719,
	3723,
	3724,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3722,
	3699,
	3725,
	10,
	3,
	'UIConstants::initialize line: 10');
INSERT INTO ACT_AI
	VALUES (3722,
	3726,
	3727,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3725,
	3699,
	0,
	11,
	3,
	'UIConstants::initialize line: 11');
INSERT INTO ACT_AI
	VALUES (3725,
	3728,
	3729,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3730,
	1,
	0,
	3,
	50,
	56,
	0,
	0,
	0,
	0,
	1309,
	3699);
INSERT INTO V_IRF
	VALUES (3730,
	3698);
INSERT INTO V_VAL
	VALUES (3706,
	1,
	0,
	3,
	58,
	59,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_AVL
	VALUES (3706,
	3730,
	3460,
	3731);
INSERT INTO V_VAL
	VALUES (3705,
	0,
	0,
	3,
	63,
	63,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_LIN
	VALUES (3705,
	'1');
INSERT INTO V_VAL
	VALUES (3732,
	1,
	0,
	4,
	3,
	9,
	0,
	0,
	0,
	0,
	1309,
	3699);
INSERT INTO V_IRF
	VALUES (3732,
	3698);
INSERT INTO V_VAL
	VALUES (3709,
	1,
	0,
	4,
	11,
	31,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_AVL
	VALUES (3709,
	3732,
	3460,
	3733);
INSERT INTO V_VAL
	VALUES (3708,
	0,
	0,
	4,
	35,
	35,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_LIN
	VALUES (3708,
	'0');
INSERT INTO V_VAL
	VALUES (3734,
	1,
	0,
	5,
	3,
	9,
	0,
	0,
	0,
	0,
	1309,
	3699);
INSERT INTO V_IRF
	VALUES (3734,
	3698);
INSERT INTO V_VAL
	VALUES (3712,
	1,
	0,
	5,
	11,
	38,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_AVL
	VALUES (3712,
	3734,
	3460,
	3576);
INSERT INTO V_VAL
	VALUES (3711,
	0,
	0,
	5,
	42,
	42,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_LIN
	VALUES (3711,
	'1');
INSERT INTO V_VAL
	VALUES (3735,
	1,
	0,
	6,
	3,
	9,
	0,
	0,
	0,
	0,
	1309,
	3699);
INSERT INTO V_IRF
	VALUES (3735,
	3698);
INSERT INTO V_VAL
	VALUES (3715,
	1,
	0,
	6,
	11,
	34,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_AVL
	VALUES (3715,
	3735,
	3460,
	3580);
INSERT INTO V_VAL
	VALUES (3714,
	0,
	0,
	6,
	38,
	38,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_LIN
	VALUES (3714,
	'2');
INSERT INTO V_VAL
	VALUES (3736,
	1,
	0,
	7,
	3,
	9,
	0,
	0,
	0,
	0,
	1309,
	3699);
INSERT INTO V_IRF
	VALUES (3736,
	3698);
INSERT INTO V_VAL
	VALUES (3718,
	1,
	0,
	7,
	11,
	37,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_AVL
	VALUES (3718,
	3736,
	3460,
	3584);
INSERT INTO V_VAL
	VALUES (3717,
	0,
	0,
	7,
	41,
	41,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_LIN
	VALUES (3717,
	'3');
INSERT INTO V_VAL
	VALUES (3737,
	1,
	0,
	8,
	3,
	9,
	0,
	0,
	0,
	0,
	1309,
	3699);
INSERT INTO V_IRF
	VALUES (3737,
	3698);
INSERT INTO V_VAL
	VALUES (3721,
	1,
	0,
	8,
	11,
	33,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_AVL
	VALUES (3721,
	3737,
	3460,
	3588);
INSERT INTO V_VAL
	VALUES (3720,
	0,
	0,
	8,
	37,
	37,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_LIN
	VALUES (3720,
	'4');
INSERT INTO V_VAL
	VALUES (3738,
	1,
	0,
	9,
	3,
	9,
	0,
	0,
	0,
	0,
	1309,
	3699);
INSERT INTO V_IRF
	VALUES (3738,
	3698);
INSERT INTO V_VAL
	VALUES (3724,
	1,
	0,
	9,
	11,
	32,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_AVL
	VALUES (3724,
	3738,
	3460,
	3592);
INSERT INTO V_VAL
	VALUES (3723,
	0,
	0,
	9,
	36,
	36,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_LIN
	VALUES (3723,
	'5');
INSERT INTO V_VAL
	VALUES (3739,
	1,
	0,
	10,
	3,
	9,
	0,
	0,
	0,
	0,
	1309,
	3699);
INSERT INTO V_IRF
	VALUES (3739,
	3698);
INSERT INTO V_VAL
	VALUES (3727,
	1,
	0,
	10,
	11,
	22,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_AVL
	VALUES (3727,
	3739,
	3460,
	3474);
INSERT INTO V_VAL
	VALUES (3726,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_UNY
	VALUES (3726,
	3740,
	'-');
INSERT INTO V_VAL
	VALUES (3740,
	0,
	0,
	10,
	27,
	27,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_LIN
	VALUES (3740,
	'1');
INSERT INTO V_VAL
	VALUES (3741,
	1,
	0,
	11,
	3,
	9,
	0,
	0,
	0,
	0,
	1309,
	3699);
INSERT INTO V_IRF
	VALUES (3741,
	3698);
INSERT INTO V_VAL
	VALUES (3729,
	1,
	0,
	11,
	11,
	21,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_AVL
	VALUES (3729,
	3741,
	3460,
	3488);
INSERT INTO V_VAL
	VALUES (3728,
	0,
	0,
	11,
	25,
	30,
	0,
	0,
	0,
	0,
	160,
	3699);
INSERT INTO V_LIN
	VALUES (3728,
	'100000');
INSERT INTO O_NBATTR
	VALUES (3731,
	3460);
INSERT INTO O_BATTR
	VALUES (3731,
	3460);
INSERT INTO O_ATTR
	VALUES (3731,
	3460,
	0,
	'id',
	'',
	'',
	'id',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3733,
	3460);
INSERT INTO O_BATTR
	VALUES (3733,
	3460);
INSERT INTO O_ATTR
	VALUES (3733,
	3460,
	3731,
	'SIGNAL_NO_NULL_SIGNAL',
	'',
	'',
	'SIGNAL_NO_NULL_SIGNAL',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3576,
	3460);
INSERT INTO O_BATTR
	VALUES (3576,
	3460);
INSERT INTO O_ATTR
	VALUES (3576,
	3460,
	3733,
	'SIGNAL_NO_START_STOP_PRESSED',
	'',
	'',
	'SIGNAL_NO_START_STOP_PRESSED',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3580,
	3460);
INSERT INTO O_BATTR
	VALUES (3580,
	3460);
INSERT INTO O_ATTR
	VALUES (3580,
	3460,
	3576,
	'SIGNAL_NO_TARGET_PRESSED',
	'',
	'',
	'SIGNAL_NO_TARGET_PRESSED',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3584,
	3460);
INSERT INTO O_BATTR
	VALUES (3584,
	3460);
INSERT INTO O_ATTR
	VALUES (3584,
	3460,
	3580,
	'SIGNAL_NO_LAP_RESET_PRESSED',
	'',
	'',
	'SIGNAL_NO_LAP_RESET_PRESSED',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3588,
	3460);
INSERT INTO O_BATTR
	VALUES (3588,
	3460);
INSERT INTO O_ATTR
	VALUES (3588,
	3460,
	3584,
	'SIGNAL_NO_LIGHT_PRESSED',
	'',
	'',
	'SIGNAL_NO_LIGHT_PRESSED',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3592,
	3460);
INSERT INTO O_BATTR
	VALUES (3592,
	3460);
INSERT INTO O_ATTR
	VALUES (3592,
	3460,
	3588,
	'SIGNAL_NO_MODE_PRESSED',
	'',
	'',
	'SIGNAL_NO_MODE_PRESSED',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3474,
	3460);
INSERT INTO O_BATTR
	VALUES (3474,
	3460);
INSERT INTO O_ATTR
	VALUES (3474,
	3460,
	3592,
	'SOCKET_ERROR',
	'',
	'',
	'SOCKET_ERROR',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3488,
	3460);
INSERT INTO O_BATTR
	VALUES (3488,
	3460);
INSERT INTO O_ATTR
	VALUES (3488,
	3460,
	3474,
	'tick_period',
	'',
	'',
	'tick_period',
	0,
	160,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	3460);
INSERT INTO O_OIDA
	VALUES (3731,
	3460,
	0,
	'id');
INSERT INTO O_ID
	VALUES (1,
	3460);
INSERT INTO O_ID
	VALUES (2,
	3460);
INSERT INTO PE_PE
	VALUES (3742,
	1,
	0,
	448,
	7);
INSERT INTO EP_PKG
	VALUES (3742,
	0,
	3103,
	'ButtonFunctions',
	'Each function within this package represents one of the buttons
on the watch.  When a function is executed, it sends the 
corresponding interface signal out through the UI port.
This allows a user executing models in Verifier to simulate
the use of the watch by invoking these functions to 
represent button pushes.',
	0);
INSERT INTO PE_PE
	VALUES (3632,
	1,
	3742,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3632,
	0,
	'sendLapResetPressed',
	'',
	'TRACK::lapResetPressed();',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (3743,
	3632);
INSERT INTO ACT_ACT
	VALUES (3743,
	'function',
	0,
	3744,
	0,
	0,
	'sendLapResetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3744,
	0,
	0,
	0,
	'TRACK',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3743,
	0);
INSERT INTO ACT_SMT
	VALUES (3745,
	3744,
	0,
	1,
	1,
	'sendLapResetPressed line: 1');
INSERT INTO ACT_IOP
	VALUES (3745,
	1,
	8,
	1,
	1,
	0,
	1326,
	0);
INSERT INTO PE_PE
	VALUES (3640,
	1,
	3742,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3640,
	0,
	'sendLightPressed',
	'',
	'TRACK::lightPressed();',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (3746,
	3640);
INSERT INTO ACT_ACT
	VALUES (3746,
	'function',
	0,
	3747,
	0,
	0,
	'sendLightPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3747,
	0,
	0,
	0,
	'TRACK',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3746,
	0);
INSERT INTO ACT_SMT
	VALUES (3748,
	3747,
	0,
	1,
	1,
	'sendLightPressed line: 1');
INSERT INTO ACT_IOP
	VALUES (3748,
	1,
	8,
	1,
	1,
	0,
	1327,
	0);
INSERT INTO PE_PE
	VALUES (3648,
	1,
	3742,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3648,
	0,
	'sendModePressed',
	'',
	'TRACK::modePressed();',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (3749,
	3648);
INSERT INTO ACT_ACT
	VALUES (3749,
	'function',
	0,
	3750,
	0,
	0,
	'sendModePressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3750,
	0,
	0,
	0,
	'TRACK',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3749,
	0);
INSERT INTO ACT_SMT
	VALUES (3751,
	3750,
	0,
	1,
	1,
	'sendModePressed line: 1');
INSERT INTO ACT_IOP
	VALUES (3751,
	1,
	8,
	1,
	1,
	0,
	1328,
	0);
INSERT INTO PE_PE
	VALUES (3624,
	1,
	3742,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3624,
	0,
	'sendStartStopPressed',
	'',
	'TRACK::startStopPressed();',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (3752,
	3624);
INSERT INTO ACT_ACT
	VALUES (3752,
	'function',
	0,
	3753,
	0,
	0,
	'sendStartStopPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3753,
	0,
	0,
	0,
	'TRACK',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3752,
	0);
INSERT INTO ACT_SMT
	VALUES (3754,
	3753,
	0,
	1,
	1,
	'sendStartStopPressed line: 1');
INSERT INTO ACT_IOP
	VALUES (3754,
	1,
	8,
	1,
	1,
	0,
	1325,
	0);
INSERT INTO PE_PE
	VALUES (3616,
	1,
	3742,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3616,
	0,
	'sendTargetPressed',
	'',
	'TRACK::setTargetPressed();',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (3755,
	3616);
INSERT INTO ACT_ACT
	VALUES (3755,
	'function',
	0,
	3756,
	0,
	0,
	'sendTargetPressed',
	0);
INSERT INTO ACT_BLK
	VALUES (3756,
	0,
	0,
	0,
	'TRACK',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3755,
	0);
INSERT INTO ACT_SMT
	VALUES (3757,
	3756,
	0,
	1,
	1,
	'sendTargetPressed line: 1');
INSERT INTO ACT_IOP
	VALUES (3757,
	1,
	8,
	1,
	1,
	0,
	1324,
	0);
INSERT INTO PE_PE
	VALUES (3758,
	1,
	1323,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (3758,
	0,
	3103,
	'Shared',
	'',
	0);
INSERT INTO PE_PE
	VALUES (6,
	1,
	3758,
	0,
	6);
INSERT INTO C_I
	VALUES (6,
	0,
	'UI',
	'');
INSERT INTO C_EP
	VALUES (8,
	6,
	-1,
	'setTime',
	'');
INSERT INTO C_IO
	VALUES (8,
	1192,
	'setTime',
	'',
	0,
	'',
	0);
INSERT INTO C_PP
	VALUES (1319,
	8,
	160,
	'time',
	'',
	0,
	'',
	0);
INSERT INTO C_EP
	VALUES (12,
	6,
	-1,
	'setData',
	'');
INSERT INTO C_IO
	VALUES (12,
	1192,
	'setData',
	'',
	0,
	'',
	8);
INSERT INTO C_PP
	VALUES (1320,
	12,
	153,
	'value',
	'',
	0,
	'',
	0);
INSERT INTO C_PP
	VALUES (1321,
	12,
	284,
	'unit',
	'',
	0,
	'',
	1320);
INSERT INTO C_EP
	VALUES (16,
	6,
	-1,
	'startTest',
	'');
INSERT INTO C_IO
	VALUES (16,
	1192,
	'startTest',
	'',
	0,
	'',
	12);
INSERT INTO C_EP
	VALUES (20,
	6,
	-1,
	'setIndicator',
	'');
INSERT INTO C_IO
	VALUES (20,
	1192,
	'setIndicator',
	'',
	0,
	'',
	16);
INSERT INTO C_PP
	VALUES (1322,
	20,
	358,
	'indicator',
	'',
	0,
	'',
	0);
INSERT INTO PE_PE
	VALUES (86,
	1,
	3758,
	0,
	6);
INSERT INTO C_I
	VALUES (86,
	0,
	'UI_Tracking',
	'');
INSERT INTO C_EP
	VALUES (88,
	86,
	0,
	'setTargetPressed',
	'');
INSERT INTO C_IO
	VALUES (88,
	1192,
	'setTargetPressed',
	'',
	0,
	'',
	0);
INSERT INTO C_EP
	VALUES (93,
	86,
	0,
	'startStopPressed',
	'');
INSERT INTO C_IO
	VALUES (93,
	1192,
	'startStopPressed',
	'',
	0,
	'',
	88);
INSERT INTO C_EP
	VALUES (98,
	86,
	0,
	'lapResetPressed',
	'');
INSERT INTO C_IO
	VALUES (98,
	1192,
	'lapResetPressed',
	'',
	0,
	'',
	93);
INSERT INTO C_EP
	VALUES (103,
	86,
	0,
	'lightPressed',
	'');
INSERT INTO C_IO
	VALUES (103,
	1192,
	'lightPressed',
	'',
	0,
	'',
	98);
INSERT INTO C_EP
	VALUES (108,
	86,
	0,
	'modePressed',
	'');
INSERT INTO C_IO
	VALUES (108,
	1192,
	'modePressed',
	'',
	0,
	'',
	103);
INSERT INTO C_EP
	VALUES (113,
	86,
	0,
	'newGoalSpec',
	'');
INSERT INTO C_IO
	VALUES (113,
	1192,
	'newGoalSpec',
	'',
	0,
	'',
	108);
INSERT INTO C_PP
	VALUES (139,
	113,
	138,
	'spanType',
	'',
	0,
	'',
	0);
INSERT INTO C_PP
	VALUES (124,
	113,
	123,
	'criteriaType',
	'',
	0,
	'',
	139);
INSERT INTO C_PP
	VALUES (154,
	113,
	153,
	'span',
	'',
	0,
	'',
	124);
INSERT INTO C_PP
	VALUES (156,
	113,
	153,
	'maximum',
	'',
	0,
	'',
	154);
INSERT INTO C_PP
	VALUES (158,
	113,
	153,
	'minimum',
	'',
	0,
	'',
	156);
INSERT INTO C_PP
	VALUES (161,
	113,
	160,
	'sequenceNumber',
	'',
	0,
	'',
	158);
INSERT INTO PE_PE
	VALUES (123,
	1,
	3758,
	0,
	3);
INSERT INTO S_DT
	VALUES (123,
	0,
	'UIGoalCriteria',
	'',
	'');
INSERT INTO S_EDT
	VALUES (123);
INSERT INTO S_ENUM
	VALUES (127,
	'HeartRate',
	'A heart-rate criteria is specified as a range of heart rates between
minimum and maximum values, in beats per minute.',
	123,
	0);
INSERT INTO S_ENUM
	VALUES (130,
	'Pace',
	'A pace criteria is specified as a range of paces between
miniumum and maximum values specified in minutes per kilometer.',
	123,
	127);
INSERT INTO PE_PE
	VALUES (138,
	1,
	3758,
	0,
	3);
INSERT INTO S_DT
	VALUES (138,
	0,
	'UIGoalSpan',
	'',
	'');
INSERT INTO S_EDT
	VALUES (138);
INSERT INTO S_ENUM
	VALUES (141,
	'Distance',
	'A distance-based span is specified in meters.',
	138,
	0);
INSERT INTO S_ENUM
	VALUES (144,
	'Time',
	'A time-based span is specified in seconds.',
	138,
	141);
INSERT INTO PE_PE
	VALUES (358,
	1,
	3758,
	0,
	3);
INSERT INTO S_DT
	VALUES (358,
	0,
	'UIIndicator',
	'',
	'');
INSERT INTO S_EDT
	VALUES (358);
INSERT INTO S_ENUM
	VALUES (359,
	'Blank',
	'No indicator at all.',
	358,
	0);
INSERT INTO S_ENUM
	VALUES (362,
	'Down',
	'A downward indicator:  perhaps an arrow pointing down.',
	358,
	359);
INSERT INTO S_ENUM
	VALUES (365,
	'Flat',
	'A neutral indicator:  perhaps a horizontal line or dash.',
	358,
	362);
INSERT INTO S_ENUM
	VALUES (368,
	'Up',
	'A downward indicator:  perhaps an arrow pointing up.',
	358,
	365);
INSERT INTO PE_PE
	VALUES (284,
	1,
	3758,
	0,
	3);
INSERT INTO S_DT
	VALUES (284,
	0,
	'UIUnit',
	'',
	'');
INSERT INTO S_EDT
	VALUES (284);
INSERT INTO S_ENUM
	VALUES (285,
	'km',
	'',
	284,
	0);
INSERT INTO S_ENUM
	VALUES (289,
	'meters',
	'',
	284,
	285);
INSERT INTO S_ENUM
	VALUES (293,
	'minPerKm',
	'',
	284,
	289);
INSERT INTO S_ENUM
	VALUES (297,
	'kmPerHour',
	'',
	284,
	293);
INSERT INTO S_ENUM
	VALUES (301,
	'miles',
	'',
	284,
	297);
INSERT INTO S_ENUM
	VALUES (305,
	'yards',
	'',
	284,
	301);
INSERT INTO S_ENUM
	VALUES (309,
	'feet',
	'',
	284,
	305);
INSERT INTO S_ENUM
	VALUES (313,
	'minPerMile',
	'',
	284,
	309);
INSERT INTO S_ENUM
	VALUES (317,
	'mph',
	'',
	284,
	313);
INSERT INTO S_ENUM
	VALUES (321,
	'bpm',
	'',
	284,
	317);
INSERT INTO S_ENUM
	VALUES (325,
	'laps',
	'',
	284,
	321);
-- root-types-contained: SystemModel_c
-- BP 7.1 content: StreamData syschar: 3 persistence-version: 7.1.6

INSERT INTO S_SYS
	VALUES (3759,
	'HeartRateMonitor',
	1);
INSERT INTO EP_PKG
	VALUES (1357,
	3759,
	3759,
	'HeartRateMonitor',
	'',
	0);
INSERT INTO PE_PE
	VALUES (3760,
	1,
	1357,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (3760,
	0,
	3759,
	'Shared',
	'',
	0);
INSERT INTO PE_PE
	VALUES (197,
	1,
	3760,
	0,
	6);
INSERT INTO C_I
	VALUES (197,
	0,
	'HRChange',
	'');
INSERT INTO C_EP
	VALUES (199,
	197,
	0,
	'heartRateChanged',
	'');
INSERT INTO C_IO
	VALUES (199,
	1192,
	'heartRateChanged',
	'',
	0,
	'',
	0);
INSERT INTO C_PP
	VALUES (204,
	199,
	160,
	'heartRate',
	'',
	0,
	'',
	0);
INSERT INTO PE_PE
	VALUES (75,
	1,
	3760,
	0,
	6);
INSERT INTO C_I
	VALUES (75,
	0,
	'HeartRateProvider',
	'');
INSERT INTO C_EP
	VALUES (77,
	75,
	-1,
	'registerListener',
	'');
INSERT INTO C_IO
	VALUES (77,
	1192,
	'registerListener',
	'',
	0,
	'',
	0);
INSERT INTO C_EP
	VALUES (81,
	75,
	-1,
	'unregisterListener',
	'');
INSERT INTO C_IO
	VALUES (81,
	1192,
	'unregisterListener',
	'',
	0,
	'',
	77);
INSERT INTO PE_PE
	VALUES (481,
	1,
	1357,
	0,
	2);
INSERT INTO C_C
	VALUES (481,
	0,
	0,
	'HeartRateMonitor',
	'Simulates a pulse monitor hardware/firmware. This component is only behavioral and included for testing purposes.',
	0,
	0,
	0,
	'');
INSERT INTO C_PO
	VALUES (1354,
	481,
	'HeartRateMonitor',
	0,
	0);
INSERT INTO C_IR
	VALUES (484,
	75,
	0,
	1354);
INSERT INTO C_P
	VALUES (484,
	'HeartRateProvider',
	'Unnamed Interface',
	'',
	'HeartRateMonitor::HeartRateMonitor::HeartRateProvider');
INSERT INTO SPR_PEP
	VALUES (1355,
	77,
	484);
INSERT INTO SPR_PO
	VALUES (1355,
	'registerListener',
	'',
	'::registerListener();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (3761,
	1355);
INSERT INTO ACT_ACT
	VALUES (3761,
	'interface operation',
	0,
	3762,
	0,
	0,
	'HeartRateMonitor::HeartRateProvider::registerListener',
	0);
INSERT INTO ACT_BLK
	VALUES (3762,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3761,
	0);
INSERT INTO ACT_SMT
	VALUES (3763,
	3762,
	0,
	1,
	1,
	'HeartRateMonitor::HeartRateProvider::registerListener line: 1');
INSERT INTO ACT_FNC
	VALUES (3763,
	3764,
	1,
	3);
INSERT INTO SPR_PEP
	VALUES (1356,
	81,
	484);
INSERT INTO SPR_PO
	VALUES (1356,
	'unregisterListener',
	'',
	'::unregisterListener();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (3765,
	1356);
INSERT INTO ACT_ACT
	VALUES (3765,
	'interface operation',
	0,
	3766,
	0,
	0,
	'HeartRateMonitor::HeartRateProvider::unregisterListener',
	0);
INSERT INTO ACT_BLK
	VALUES (3766,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3765,
	0);
INSERT INTO ACT_SMT
	VALUES (3767,
	3766,
	0,
	1,
	1,
	'HeartRateMonitor::HeartRateProvider::unregisterListener line: 1');
INSERT INTO ACT_FNC
	VALUES (3767,
	3768,
	1,
	3);
INSERT INTO C_PO
	VALUES (486,
	481,
	'HRChange',
	0,
	0);
INSERT INTO C_IR
	VALUES (489,
	197,
	0,
	486);
INSERT INTO C_R
	VALUES (489,
	'HRChange',
	'',
	'Unnamed Interface',
	'HeartRateMonitor::HRChange::HRChange');
INSERT INTO SPR_REP
	VALUES (1358,
	199,
	489);
INSERT INTO SPR_RO
	VALUES (1358,
	'heartRateChanged',
	'',
	'',
	1,
	0);
INSERT INTO ACT_ROB
	VALUES (3769,
	1358);
INSERT INTO ACT_ACT
	VALUES (3769,
	'interface operation',
	0,
	3770,
	0,
	0,
	'HRChange::HRChange::heartRateChanged',
	0);
INSERT INTO ACT_BLK
	VALUES (3770,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3769,
	0);
INSERT INTO PE_PE
	VALUES (3771,
	1,
	0,
	481,
	7);
INSERT INTO EP_PKG
	VALUES (3771,
	0,
	3759,
	'functions',
	'',
	0);
INSERT INTO PE_PE
	VALUES (3764,
	1,
	3771,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3764,
	0,
	'registerListener',
	'',
	'HeartRateMonitor::initialize();
select any hr from instances of HeartRateMonitor;
generate HeartRateMonitor8:registerListener() to hr;',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (3772,
	3764);
INSERT INTO ACT_ACT
	VALUES (3772,
	'function',
	0,
	3773,
	0,
	0,
	'registerListener',
	0);
INSERT INTO ACT_BLK
	VALUES (3773,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	3,
	1,
	2,
	33,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3772,
	0);
INSERT INTO ACT_SMT
	VALUES (3774,
	3773,
	3775,
	1,
	1,
	'registerListener line: 1');
INSERT INTO ACT_TFM
	VALUES (3774,
	3776,
	0,
	1,
	19,
	1,
	1);
INSERT INTO ACT_SMT
	VALUES (3775,
	3773,
	3777,
	2,
	1,
	'registerListener line: 2');
INSERT INTO ACT_FIO
	VALUES (3775,
	3778,
	1,
	'any',
	3779,
	2,
	33);
INSERT INTO ACT_SMT
	VALUES (3777,
	3773,
	0,
	3,
	1,
	'registerListener line: 3');
INSERT INTO E_ESS
	VALUES (3777,
	1,
	0,
	3,
	10,
	3,
	28,
	2,
	33,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (3777);
INSERT INTO E_GSME
	VALUES (3777,
	3780);
INSERT INTO E_GEN
	VALUES (3777,
	3778);
INSERT INTO V_VAR
	VALUES (3778,
	3773,
	'hr',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3778,
	0,
	3779);
INSERT INTO PE_PE
	VALUES (3768,
	1,
	3771,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3768,
	0,
	'unregisterListener',
	'',
	'HeartRateMonitor::initialize();
select any hr from instances of HeartRateMonitor;
generate HeartRateMonitor9:unregisterListener() to hr; ',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (3781,
	3768);
INSERT INTO ACT_ACT
	VALUES (3781,
	'function',
	0,
	3782,
	0,
	0,
	'unregisterListener',
	0);
INSERT INTO ACT_BLK
	VALUES (3782,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	3,
	1,
	2,
	33,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3781,
	0);
INSERT INTO ACT_SMT
	VALUES (3783,
	3782,
	3784,
	1,
	1,
	'unregisterListener line: 1');
INSERT INTO ACT_TFM
	VALUES (3783,
	3776,
	0,
	1,
	19,
	1,
	1);
INSERT INTO ACT_SMT
	VALUES (3784,
	3782,
	3785,
	2,
	1,
	'unregisterListener line: 2');
INSERT INTO ACT_FIO
	VALUES (3784,
	3786,
	1,
	'any',
	3779,
	2,
	33);
INSERT INTO ACT_SMT
	VALUES (3785,
	3782,
	0,
	3,
	1,
	'unregisterListener line: 3');
INSERT INTO E_ESS
	VALUES (3785,
	1,
	0,
	3,
	10,
	3,
	28,
	2,
	33,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (3785);
INSERT INTO E_GSME
	VALUES (3785,
	3787);
INSERT INTO E_GEN
	VALUES (3785,
	3786);
INSERT INTO V_VAR
	VALUES (3786,
	3782,
	'hr',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3786,
	0,
	3779);
INSERT INTO PE_PE
	VALUES (3788,
	1,
	0,
	481,
	7);
INSERT INTO EP_PKG
	VALUES (3788,
	0,
	3759,
	'HeartRateMonitor',
	'',
	0);
INSERT INTO PE_PE
	VALUES (3789,
	1,
	3788,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (3789,
	'HeartRateConstants',
	2,
	'HeartRateConstants',
	'SamplingPeriod is expressed in seconds and represents the period at which heart-rate samples are recorded.
AveragingWindow is expressed in samples and represents the number of samples used when calculating the current average.',
	0);
INSERT INTO O_TFR
	VALUES (3790,
	3789,
	'initialize',
	'',
	1192,
	0,
	'select any hrc from instances of HeartRateConstants;
if ( empty hrc )
  create object instance hrc of HeartRateConstants; hrc.id = 1;
  hrc.HeartRateAveragingWindow = 5;
  hrc.HeartRateSamplingPeriod = 3;
end if;',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (3791,
	3790);
INSERT INTO ACT_ACT
	VALUES (3791,
	'class operation',
	0,
	3792,
	0,
	0,
	'HeartRateConstants::initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (3792,
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	34,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3791,
	0);
INSERT INTO ACT_SMT
	VALUES (3793,
	3792,
	3794,
	1,
	1,
	'HeartRateConstants::initialize line: 1');
INSERT INTO ACT_FIO
	VALUES (3793,
	3795,
	1,
	'any',
	3789,
	1,
	34);
INSERT INTO ACT_SMT
	VALUES (3794,
	3792,
	0,
	2,
	1,
	'HeartRateConstants::initialize line: 2');
INSERT INTO ACT_IF
	VALUES (3794,
	3796,
	3797,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3798,
	0,
	0,
	2,
	12,
	14,
	0,
	0,
	0,
	0,
	1309,
	3792);
INSERT INTO V_IRF
	VALUES (3798,
	3795);
INSERT INTO V_VAL
	VALUES (3797,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	3792);
INSERT INTO V_UNY
	VALUES (3797,
	3798,
	'empty');
INSERT INTO V_VAR
	VALUES (3795,
	3792,
	'hrc',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3795,
	0,
	3789);
INSERT INTO ACT_BLK
	VALUES (3796,
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	3,
	3,
	33,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3791,
	0);
INSERT INTO ACT_SMT
	VALUES (3799,
	3796,
	3800,
	3,
	3,
	'HeartRateConstants::initialize line: 3');
INSERT INTO ACT_CR
	VALUES (3799,
	3795,
	0,
	3789,
	3,
	33);
INSERT INTO ACT_SMT
	VALUES (3800,
	3796,
	3801,
	3,
	53,
	'HeartRateConstants::initialize line: 3');
INSERT INTO ACT_AI
	VALUES (3800,
	3802,
	3803,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3801,
	3796,
	3804,
	4,
	3,
	'HeartRateConstants::initialize line: 4');
INSERT INTO ACT_AI
	VALUES (3801,
	3805,
	3806,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3804,
	3796,
	0,
	5,
	3,
	'HeartRateConstants::initialize line: 5');
INSERT INTO ACT_AI
	VALUES (3804,
	3807,
	3808,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3809,
	1,
	0,
	3,
	53,
	55,
	0,
	0,
	0,
	0,
	1309,
	3796);
INSERT INTO V_IRF
	VALUES (3809,
	3795);
INSERT INTO V_VAL
	VALUES (3803,
	1,
	0,
	3,
	57,
	58,
	0,
	0,
	0,
	0,
	160,
	3796);
INSERT INTO V_AVL
	VALUES (3803,
	3809,
	3789,
	3810);
INSERT INTO V_VAL
	VALUES (3802,
	0,
	0,
	3,
	62,
	62,
	0,
	0,
	0,
	0,
	160,
	3796);
INSERT INTO V_LIN
	VALUES (3802,
	'1');
INSERT INTO V_VAL
	VALUES (3811,
	1,
	0,
	4,
	3,
	5,
	0,
	0,
	0,
	0,
	1309,
	3796);
INSERT INTO V_IRF
	VALUES (3811,
	3795);
INSERT INTO V_VAL
	VALUES (3806,
	1,
	0,
	4,
	7,
	30,
	0,
	0,
	0,
	0,
	160,
	3796);
INSERT INTO V_AVL
	VALUES (3806,
	3811,
	3789,
	3812);
INSERT INTO V_VAL
	VALUES (3805,
	0,
	0,
	4,
	34,
	34,
	0,
	0,
	0,
	0,
	160,
	3796);
INSERT INTO V_LIN
	VALUES (3805,
	'5');
INSERT INTO V_VAL
	VALUES (3813,
	1,
	0,
	5,
	3,
	5,
	0,
	0,
	0,
	0,
	1309,
	3796);
INSERT INTO V_IRF
	VALUES (3813,
	3795);
INSERT INTO V_VAL
	VALUES (3808,
	1,
	0,
	5,
	7,
	29,
	0,
	0,
	0,
	0,
	160,
	3796);
INSERT INTO V_AVL
	VALUES (3808,
	3813,
	3789,
	3814);
INSERT INTO V_VAL
	VALUES (3807,
	0,
	0,
	5,
	33,
	33,
	0,
	0,
	0,
	0,
	160,
	3796);
INSERT INTO V_LIN
	VALUES (3807,
	'3');
INSERT INTO O_NBATTR
	VALUES (3810,
	3789);
INSERT INTO O_BATTR
	VALUES (3810,
	3789);
INSERT INTO O_ATTR
	VALUES (3810,
	3789,
	0,
	'id',
	'',
	'',
	'id',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3812,
	3789);
INSERT INTO O_BATTR
	VALUES (3812,
	3789);
INSERT INTO O_ATTR
	VALUES (3812,
	3789,
	3810,
	'HeartRateAveragingWindow',
	'',
	'',
	'HeartRateAveragingWindow',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3814,
	3789);
INSERT INTO O_BATTR
	VALUES (3814,
	3789);
INSERT INTO O_ATTR
	VALUES (3814,
	3789,
	3812,
	'HeartRateSamplingPeriod',
	'',
	'',
	'HeartRateSamplingPeriod',
	0,
	160,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	3789);
INSERT INTO O_OIDA
	VALUES (3810,
	3789,
	0,
	'id');
INSERT INTO O_ID
	VALUES (1,
	3789);
INSERT INTO O_ID
	VALUES (2,
	3789);
INSERT INTO PE_PE
	VALUES (3779,
	1,
	3788,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (3779,
	'HeartRateMonitor',
	1,
	'HeartRateMonitor',
	'Represents the heart-rate monitoring facility.',
	0);
INSERT INTO O_TFR
	VALUES (3776,
	3779,
	'initialize',
	'',
	1192,
	0,
	'
select any monitor from instances of HeartRateMonitor;
if (empty monitor)
  create object instance monitor of HeartRateMonitor; 
  monitor.id = 1;
end if;',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (3815,
	3776);
INSERT INTO ACT_ACT
	VALUES (3815,
	'class operation',
	0,
	3816,
	0,
	0,
	'HeartRateMonitor::initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (3816,
	1,
	0,
	0,
	'',
	'',
	'',
	3,
	1,
	2,
	38,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3815,
	0);
INSERT INTO ACT_SMT
	VALUES (3817,
	3816,
	3818,
	2,
	1,
	'HeartRateMonitor::initialize line: 2');
INSERT INTO ACT_FIO
	VALUES (3817,
	3819,
	1,
	'any',
	3779,
	2,
	38);
INSERT INTO ACT_SMT
	VALUES (3818,
	3816,
	0,
	3,
	1,
	'HeartRateMonitor::initialize line: 3');
INSERT INTO ACT_IF
	VALUES (3818,
	3820,
	3821,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3822,
	0,
	0,
	3,
	11,
	17,
	0,
	0,
	0,
	0,
	1309,
	3816);
INSERT INTO V_IRF
	VALUES (3822,
	3819);
INSERT INTO V_VAL
	VALUES (3821,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	3816);
INSERT INTO V_UNY
	VALUES (3821,
	3822,
	'empty');
INSERT INTO V_VAR
	VALUES (3819,
	3816,
	'monitor',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3819,
	0,
	3779);
INSERT INTO ACT_BLK
	VALUES (3820,
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	3,
	4,
	37,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3815,
	0);
INSERT INTO ACT_SMT
	VALUES (3823,
	3820,
	3824,
	4,
	3,
	'HeartRateMonitor::initialize line: 4');
INSERT INTO ACT_CR
	VALUES (3823,
	3819,
	0,
	3779,
	4,
	37);
INSERT INTO ACT_SMT
	VALUES (3824,
	3820,
	0,
	5,
	3,
	'HeartRateMonitor::initialize line: 5');
INSERT INTO ACT_AI
	VALUES (3824,
	3825,
	3826,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3827,
	1,
	0,
	5,
	3,
	9,
	0,
	0,
	0,
	0,
	1309,
	3820);
INSERT INTO V_IRF
	VALUES (3827,
	3819);
INSERT INTO V_VAL
	VALUES (3826,
	1,
	0,
	5,
	11,
	12,
	0,
	0,
	0,
	0,
	160,
	3820);
INSERT INTO V_AVL
	VALUES (3826,
	3827,
	3779,
	3828);
INSERT INTO V_VAL
	VALUES (3825,
	0,
	0,
	5,
	16,
	16,
	0,
	0,
	0,
	0,
	160,
	3820);
INSERT INTO V_LIN
	VALUES (3825,
	'1');
INSERT INTO O_NBATTR
	VALUES (3829,
	3779);
INSERT INTO O_BATTR
	VALUES (3829,
	3779);
INSERT INTO O_ATTR
	VALUES (3829,
	3779,
	3828,
	'recentHeartRate',
	'Most recent heart-rate sample, expressed in beats per minute.',
	'',
	'recentHeartRate',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3830,
	3779);
INSERT INTO O_BATTR
	VALUES (3830,
	3779);
INSERT INTO O_ATTR
	VALUES (3830,
	3779,
	3829,
	'timer',
	'Handle for underlying timer mechanism enabling the 
generation of delayed events that drive the model
of the heart-rate monitor.',
	'',
	'timer',
	0,
	1272,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3831,
	3779);
INSERT INTO O_BATTR
	VALUES (3831,
	3779);
INSERT INTO O_ATTR
	VALUES (3831,
	3779,
	3830,
	'current_state',
	'',
	'',
	'current_state',
	0,
	1307,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3828,
	3779);
INSERT INTO O_BATTR
	VALUES (3828,
	3779);
INSERT INTO O_ATTR
	VALUES (3828,
	3779,
	0,
	'id',
	'',
	'',
	'id',
	0,
	160,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	3779);
INSERT INTO O_OIDA
	VALUES (3828,
	3779,
	0,
	'id');
INSERT INTO O_ID
	VALUES (1,
	3779);
INSERT INTO O_ID
	VALUES (2,
	3779);
INSERT INTO SM_ISM
	VALUES (3832,
	3779);
INSERT INTO SM_SM
	VALUES (3832,
	'',
	0);
INSERT INTO SM_MOORE
	VALUES (3832);
INSERT INTO SM_LEVT
	VALUES (3833,
	3832,
	0);
INSERT INTO SM_SEVT
	VALUES (3833,
	3832,
	0);
INSERT INTO SM_EVT
	VALUES (3833,
	3832,
	0,
	3,
	'timeout',
	0,
	'',
	'HeartRateMonitor3',
	'');
INSERT INTO SM_LEVT
	VALUES (3834,
	3832,
	0);
INSERT INTO SM_SEVT
	VALUES (3834,
	3832,
	0);
INSERT INTO SM_EVT
	VALUES (3834,
	3832,
	0,
	5,
	'registerComplete',
	0,
	'',
	'HeartRateMonitor5',
	'');
INSERT INTO SM_LEVT
	VALUES (3835,
	3832,
	0);
INSERT INTO SM_SEVT
	VALUES (3835,
	3832,
	0);
INSERT INTO SM_EVT
	VALUES (3835,
	3832,
	0,
	7,
	'unregisterComplete',
	0,
	'',
	'HeartRateMonitor7',
	'');
INSERT INTO SM_LEVT
	VALUES (3780,
	3832,
	0);
INSERT INTO SM_SEVT
	VALUES (3780,
	3832,
	0);
INSERT INTO SM_EVT
	VALUES (3780,
	3832,
	0,
	8,
	'registerListener',
	0,
	'',
	'HeartRateMonitor8',
	'');
INSERT INTO SM_LEVT
	VALUES (3787,
	3832,
	0);
INSERT INTO SM_SEVT
	VALUES (3787,
	3832,
	0);
INSERT INTO SM_EVT
	VALUES (3787,
	3832,
	0,
	9,
	'unregisterListener',
	0,
	'',
	'HeartRateMonitor9',
	'');
INSERT INTO SM_STATE
	VALUES (3836,
	3832,
	0,
	'idle',
	1,
	0);
INSERT INTO SM_CH
	VALUES (3836,
	3833,
	3832,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3836,
	3833,
	3832,
	0);
INSERT INTO SM_CH
	VALUES (3836,
	3834,
	3832,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3836,
	3834,
	3832,
	0);
INSERT INTO SM_CH
	VALUES (3836,
	3835,
	3832,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3836,
	3835,
	3832,
	0);
INSERT INTO SM_SEME
	VALUES (3836,
	3780,
	3832,
	0);
INSERT INTO SM_CH
	VALUES (3836,
	3787,
	3832,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3836,
	3787,
	3832,
	0);
INSERT INTO SM_MOAH
	VALUES (3837,
	3832,
	3836);
INSERT INTO SM_AH
	VALUES (3837,
	3832);
INSERT INTO SM_ACT
	VALUES (3837,
	3832,
	1,
	'',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (3838,
	3832,
	3837);
INSERT INTO ACT_ACT
	VALUES (3838,
	'state',
	0,
	3839,
	0,
	0,
	'HeartRateMonitor::idle',
	0);
INSERT INTO ACT_BLK
	VALUES (3839,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3838,
	0);
INSERT INTO SM_STATE
	VALUES (3840,
	3832,
	0,
	'monitoring',
	2,
	0);
INSERT INTO SM_SEME
	VALUES (3840,
	3833,
	3832,
	0);
INSERT INTO SM_CH
	VALUES (3840,
	3834,
	3832,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3840,
	3834,
	3832,
	0);
INSERT INTO SM_CH
	VALUES (3840,
	3835,
	3832,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3840,
	3835,
	3832,
	0);
INSERT INTO SM_CH
	VALUES (3840,
	3780,
	3832,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3840,
	3780,
	3832,
	0);
INSERT INTO SM_SEME
	VALUES (3840,
	3787,
	3832,
	0);
INSERT INTO SM_MOAH
	VALUES (3841,
	3832,
	3840);
INSERT INTO SM_AH
	VALUES (3841,
	3832);
INSERT INTO SM_ACT
	VALUES (3841,
	3832,
	1,
	'send HRChange::heartRateChanged(heartRate: self.recentHeartRate);
self.recentHeartRate = self.recentHeartRate + 1;',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (3842,
	3832,
	3841);
INSERT INTO ACT_ACT
	VALUES (3842,
	'state',
	0,
	3843,
	0,
	0,
	'HeartRateMonitor::monitoring',
	0);
INSERT INTO ACT_BLK
	VALUES (3843,
	0,
	0,
	0,
	'HRChange',
	'',
	'',
	2,
	1,
	1,
	6,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3842,
	0);
INSERT INTO ACT_SMT
	VALUES (3844,
	3843,
	3845,
	1,
	1,
	'HeartRateMonitor::monitoring line: 1');
INSERT INTO ACT_IOP
	VALUES (3844,
	1,
	16,
	1,
	6,
	0,
	1358,
	0);
INSERT INTO ACT_SMT
	VALUES (3845,
	3843,
	0,
	2,
	1,
	'HeartRateMonitor::monitoring line: 2');
INSERT INTO ACT_AI
	VALUES (3845,
	3846,
	3847,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3848,
	0,
	0,
	1,
	44,
	47,
	0,
	0,
	0,
	0,
	1309,
	3843);
INSERT INTO V_IRF
	VALUES (3848,
	3849);
INSERT INTO V_VAL
	VALUES (3850,
	0,
	0,
	1,
	49,
	63,
	0,
	0,
	0,
	0,
	160,
	3843);
INSERT INTO V_AVL
	VALUES (3850,
	3848,
	3779,
	3829);
INSERT INTO V_PAR
	VALUES (3850,
	3844,
	0,
	'heartRate',
	0,
	1,
	33);
INSERT INTO V_VAL
	VALUES (3851,
	1,
	0,
	2,
	1,
	4,
	0,
	0,
	0,
	0,
	1309,
	3843);
INSERT INTO V_IRF
	VALUES (3851,
	3849);
INSERT INTO V_VAL
	VALUES (3847,
	1,
	0,
	2,
	6,
	20,
	0,
	0,
	0,
	0,
	160,
	3843);
INSERT INTO V_AVL
	VALUES (3847,
	3851,
	3779,
	3829);
INSERT INTO V_VAL
	VALUES (3852,
	0,
	0,
	2,
	24,
	27,
	0,
	0,
	0,
	0,
	1309,
	3843);
INSERT INTO V_IRF
	VALUES (3852,
	3849);
INSERT INTO V_VAL
	VALUES (3853,
	0,
	0,
	2,
	29,
	43,
	0,
	0,
	0,
	0,
	160,
	3843);
INSERT INTO V_AVL
	VALUES (3853,
	3852,
	3779,
	3829);
INSERT INTO V_VAL
	VALUES (3846,
	0,
	0,
	2,
	29,
	47,
	0,
	0,
	0,
	0,
	160,
	3843);
INSERT INTO V_BIN
	VALUES (3846,
	3854,
	3853,
	'+');
INSERT INTO V_VAL
	VALUES (3854,
	0,
	0,
	2,
	47,
	47,
	0,
	0,
	0,
	0,
	160,
	3843);
INSERT INTO V_LIN
	VALUES (3854,
	'1');
INSERT INTO V_VAR
	VALUES (3849,
	3843,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3849,
	0,
	3779);
INSERT INTO SM_STATE
	VALUES (3855,
	3832,
	0,
	'Registering',
	3,
	0);
INSERT INTO SM_CH
	VALUES (3855,
	3833,
	3832,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3855,
	3833,
	3832,
	0);
INSERT INTO SM_SEME
	VALUES (3855,
	3834,
	3832,
	0);
INSERT INTO SM_CH
	VALUES (3855,
	3835,
	3832,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3855,
	3835,
	3832,
	0);
INSERT INTO SM_CH
	VALUES (3855,
	3780,
	3832,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3855,
	3780,
	3832,
	0);
INSERT INTO SM_CH
	VALUES (3855,
	3787,
	3832,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3855,
	3787,
	3832,
	0);
INSERT INTO SM_MOAH
	VALUES (3856,
	3832,
	3855);
INSERT INTO SM_AH
	VALUES (3856,
	3832);
INSERT INTO SM_ACT
	VALUES (3856,
	3832,
	1,
	'
self.recentHeartRate = 50;

LOG::LogInfo(message: "listener registered");

// start timer
HeartRateConstants::initialize();
select any hrc from instances of HeartRateConstants;
create event instance timeout of HeartRateMonitor3:timeout() to self; 
self.timer = TIM::timer_start_recurring( event_inst: timeout, microseconds: (hrc.HeartRateSamplingPeriod * 1000000) ); 

generate HeartRateMonitor5:registerComplete() to self;',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (3857,
	3832,
	3856);
INSERT INTO ACT_ACT
	VALUES (3857,
	'state',
	0,
	3858,
	0,
	0,
	'HeartRateMonitor::Registering',
	0);
INSERT INTO ACT_BLK
	VALUES (3858,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	12,
	1,
	10,
	14,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3857,
	0);
INSERT INTO ACT_SMT
	VALUES (3859,
	3858,
	3860,
	2,
	1,
	'HeartRateMonitor::Registering line: 2');
INSERT INTO ACT_AI
	VALUES (3859,
	3861,
	3862,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3860,
	3858,
	3863,
	4,
	1,
	'HeartRateMonitor::Registering line: 4');
INSERT INTO ACT_BRG
	VALUES (3860,
	1206,
	4,
	6,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES (3863,
	3858,
	3864,
	7,
	1,
	'HeartRateMonitor::Registering line: 7');
INSERT INTO ACT_TFM
	VALUES (3863,
	3790,
	0,
	7,
	21,
	7,
	1);
INSERT INTO ACT_SMT
	VALUES (3864,
	3858,
	3865,
	8,
	1,
	'HeartRateMonitor::Registering line: 8');
INSERT INTO ACT_FIO
	VALUES (3864,
	3866,
	1,
	'any',
	3789,
	8,
	34);
INSERT INTO ACT_SMT
	VALUES (3865,
	3858,
	3867,
	9,
	1,
	'HeartRateMonitor::Registering line: 9');
INSERT INTO E_ESS
	VALUES (3865,
	1,
	0,
	9,
	34,
	9,
	52,
	8,
	34,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (3865,
	1,
	3868);
INSERT INTO E_CSME
	VALUES (3865,
	3833);
INSERT INTO E_CEI
	VALUES (3865,
	3869);
INSERT INTO ACT_SMT
	VALUES (3867,
	3858,
	3870,
	10,
	1,
	'HeartRateMonitor::Registering line: 10');
INSERT INTO ACT_AI
	VALUES (3867,
	3871,
	3872,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3870,
	3858,
	0,
	12,
	1,
	'HeartRateMonitor::Registering line: 12');
INSERT INTO E_ESS
	VALUES (3870,
	1,
	0,
	12,
	10,
	12,
	28,
	10,
	14,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (3870);
INSERT INTO E_GSME
	VALUES (3870,
	3834);
INSERT INTO E_GEN
	VALUES (3870,
	3869);
INSERT INTO V_VAL
	VALUES (3873,
	1,
	0,
	2,
	1,
	4,
	0,
	0,
	0,
	0,
	1309,
	3858);
INSERT INTO V_IRF
	VALUES (3873,
	3869);
INSERT INTO V_VAL
	VALUES (3862,
	1,
	0,
	2,
	6,
	20,
	0,
	0,
	0,
	0,
	160,
	3858);
INSERT INTO V_AVL
	VALUES (3862,
	3873,
	3779,
	3829);
INSERT INTO V_VAL
	VALUES (3861,
	0,
	0,
	2,
	24,
	25,
	0,
	0,
	0,
	0,
	160,
	3858);
INSERT INTO V_LIN
	VALUES (3861,
	'50');
INSERT INTO V_VAL
	VALUES (3874,
	0,
	0,
	4,
	23,
	42,
	0,
	0,
	0,
	0,
	1199,
	3858);
INSERT INTO V_LST
	VALUES (3874,
	'listener registered');
INSERT INTO V_PAR
	VALUES (3874,
	3860,
	0,
	'message',
	0,
	4,
	14);
INSERT INTO V_VAL
	VALUES (3875,
	1,
	0,
	10,
	1,
	4,
	0,
	0,
	0,
	0,
	1309,
	3858);
INSERT INTO V_IRF
	VALUES (3875,
	3869);
INSERT INTO V_VAL
	VALUES (3872,
	1,
	0,
	10,
	6,
	10,
	0,
	0,
	0,
	0,
	1272,
	3858);
INSERT INTO V_AVL
	VALUES (3872,
	3875,
	3779,
	3830);
INSERT INTO V_VAL
	VALUES (3871,
	0,
	0,
	10,
	19,
	-1,
	10,
	42,
	10,
	63,
	1272,
	3858);
INSERT INTO V_BRV
	VALUES (3871,
	1278,
	1,
	10,
	14);
INSERT INTO V_VAL
	VALUES (3876,
	0,
	0,
	10,
	54,
	60,
	0,
	0,
	0,
	0,
	1275,
	3858);
INSERT INTO V_TVL
	VALUES (3876,
	3868);
INSERT INTO V_PAR
	VALUES (3876,
	0,
	3871,
	'event_inst',
	3877,
	10,
	42);
INSERT INTO V_VAL
	VALUES (3878,
	0,
	0,
	10,
	78,
	80,
	0,
	0,
	0,
	0,
	1309,
	3858);
INSERT INTO V_IRF
	VALUES (3878,
	3866);
INSERT INTO V_VAL
	VALUES (3879,
	0,
	0,
	10,
	82,
	104,
	0,
	0,
	0,
	0,
	160,
	3858);
INSERT INTO V_AVL
	VALUES (3879,
	3878,
	3789,
	3814);
INSERT INTO V_VAL
	VALUES (3877,
	0,
	0,
	10,
	82,
	114,
	0,
	0,
	0,
	0,
	160,
	3858);
INSERT INTO V_BIN
	VALUES (3877,
	3880,
	3879,
	'*');
INSERT INTO V_PAR
	VALUES (3877,
	0,
	3871,
	'microseconds',
	0,
	10,
	63);
INSERT INTO V_VAL
	VALUES (3880,
	0,
	0,
	10,
	108,
	114,
	0,
	0,
	0,
	0,
	160,
	3858);
INSERT INTO V_LIN
	VALUES (3880,
	'1000000');
INSERT INTO V_VAR
	VALUES (3869,
	3858,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3869,
	0,
	3779);
INSERT INTO V_VAR
	VALUES (3866,
	3858,
	'hrc',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3866,
	0,
	3789);
INSERT INTO V_VAR
	VALUES (3868,
	3858,
	'timeout',
	1,
	1275);
INSERT INTO V_TRN
	VALUES (3868,
	0,
	'');
INSERT INTO SM_STATE
	VALUES (3881,
	3832,
	0,
	'Unregistering',
	4,
	0);
INSERT INTO SM_CH
	VALUES (3881,
	3833,
	3832,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3881,
	3833,
	3832,
	0);
INSERT INTO SM_CH
	VALUES (3881,
	3834,
	3832,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3881,
	3834,
	3832,
	0);
INSERT INTO SM_SEME
	VALUES (3881,
	3835,
	3832,
	0);
INSERT INTO SM_CH
	VALUES (3881,
	3780,
	3832,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3881,
	3780,
	3832,
	0);
INSERT INTO SM_CH
	VALUES (3881,
	3787,
	3832,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (3881,
	3787,
	3832,
	0);
INSERT INTO SM_MOAH
	VALUES (3882,
	3832,
	3881);
INSERT INTO SM_AH
	VALUES (3882,
	3832);
INSERT INTO SM_ACT
	VALUES (3882,
	3832,
	1,
	'res = TIM::timer_cancel(timer_inst_ref: self.timer);
if ( res )
  LOG::LogSuccess( message: "Heart Rate Monitor: timer_cancel() succeeded." );
else
  LOG::LogFailure( message: "Heart Rate Monitor: timer_cancel() failed." );
end if;

generate HeartRateMonitor7:unregisterComplete() to self;
',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (3883,
	3832,
	3882);
INSERT INTO ACT_ACT
	VALUES (3883,
	'state',
	0,
	3884,
	0,
	0,
	'HeartRateMonitor::Unregistering',
	0);
INSERT INTO ACT_BLK
	VALUES (3884,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	8,
	1,
	1,
	7,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3883,
	0);
INSERT INTO ACT_SMT
	VALUES (3885,
	3884,
	3886,
	1,
	1,
	'HeartRateMonitor::Unregistering line: 1');
INSERT INTO ACT_AI
	VALUES (3885,
	3887,
	3888,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3886,
	3884,
	3889,
	2,
	1,
	'HeartRateMonitor::Unregistering line: 2');
INSERT INTO ACT_IF
	VALUES (3886,
	3890,
	3891,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3892,
	3884,
	0,
	4,
	1,
	'HeartRateMonitor::Unregistering line: 4');
INSERT INTO ACT_E
	VALUES (3892,
	3893,
	3886);
INSERT INTO ACT_SMT
	VALUES (3889,
	3884,
	0,
	8,
	1,
	'HeartRateMonitor::Unregistering line: 8');
INSERT INTO E_ESS
	VALUES (3889,
	1,
	0,
	8,
	10,
	8,
	28,
	1,
	7,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (3889);
INSERT INTO E_GSME
	VALUES (3889,
	3835);
INSERT INTO E_GEN
	VALUES (3889,
	3894);
INSERT INTO V_VAL
	VALUES (3888,
	1,
	1,
	1,
	1,
	3,
	0,
	0,
	0,
	0,
	125,
	3884);
INSERT INTO V_TVL
	VALUES (3888,
	3895);
INSERT INTO V_VAL
	VALUES (3887,
	0,
	0,
	1,
	12,
	-1,
	1,
	25,
	0,
	0,
	125,
	3884);
INSERT INTO V_BRV
	VALUES (3887,
	1297,
	1,
	1,
	7);
INSERT INTO V_VAL
	VALUES (3896,
	0,
	0,
	1,
	41,
	44,
	0,
	0,
	0,
	0,
	1309,
	3884);
INSERT INTO V_IRF
	VALUES (3896,
	3894);
INSERT INTO V_VAL
	VALUES (3897,
	0,
	0,
	1,
	46,
	50,
	0,
	0,
	0,
	0,
	1272,
	3884);
INSERT INTO V_AVL
	VALUES (3897,
	3896,
	3779,
	3830);
INSERT INTO V_PAR
	VALUES (3897,
	0,
	3887,
	'timer_inst_ref',
	0,
	1,
	25);
INSERT INTO V_VAL
	VALUES (3891,
	0,
	0,
	2,
	6,
	8,
	0,
	0,
	0,
	0,
	125,
	3884);
INSERT INTO V_TVL
	VALUES (3891,
	3895);
INSERT INTO V_VAR
	VALUES (3895,
	3884,
	'res',
	1,
	125);
INSERT INTO V_TRN
	VALUES (3895,
	0,
	'');
INSERT INTO V_VAR
	VALUES (3894,
	3884,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3894,
	0,
	3779);
INSERT INTO ACT_BLK
	VALUES (3890,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	3,
	3,
	3,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3883,
	0);
INSERT INTO ACT_SMT
	VALUES (3898,
	3890,
	0,
	3,
	3,
	'HeartRateMonitor::Unregistering line: 3');
INSERT INTO ACT_BRG
	VALUES (3898,
	1197,
	3,
	8,
	3,
	3);
INSERT INTO V_VAL
	VALUES (3899,
	0,
	0,
	3,
	29,
	74,
	0,
	0,
	0,
	0,
	1199,
	3890);
INSERT INTO V_LST
	VALUES (3899,
	'Heart Rate Monitor: timer_cancel() succeeded.');
INSERT INTO V_PAR
	VALUES (3899,
	3898,
	0,
	'message',
	0,
	3,
	20);
INSERT INTO ACT_BLK
	VALUES (3893,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	5,
	3,
	5,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3883,
	0);
INSERT INTO ACT_SMT
	VALUES (3900,
	3893,
	0,
	5,
	3,
	'HeartRateMonitor::Unregistering line: 5');
INSERT INTO ACT_BRG
	VALUES (3900,
	1202,
	5,
	8,
	5,
	3);
INSERT INTO V_VAL
	VALUES (3901,
	0,
	0,
	5,
	29,
	71,
	0,
	0,
	0,
	0,
	1199,
	3893);
INSERT INTO V_LST
	VALUES (3901,
	'Heart Rate Monitor: timer_cancel() failed.');
INSERT INTO V_PAR
	VALUES (3901,
	3900,
	0,
	'message',
	0,
	5,
	20);
INSERT INTO SM_NSTXN
	VALUES (3902,
	3832,
	3840,
	3833,
	0);
INSERT INTO SM_TAH
	VALUES (3903,
	3832,
	3902);
INSERT INTO SM_AH
	VALUES (3903,
	3832);
INSERT INTO SM_ACT
	VALUES (3903,
	3832,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3904,
	3832,
	3903);
INSERT INTO ACT_ACT
	VALUES (3904,
	'transition',
	0,
	3905,
	0,
	0,
	'HeartRateMonitor3: timeout',
	0);
INSERT INTO ACT_BLK
	VALUES (3905,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3904,
	0);
INSERT INTO SM_TXN
	VALUES (3902,
	3832,
	3840,
	0);
INSERT INTO SM_NSTXN
	VALUES (3906,
	3832,
	3836,
	3780,
	0);
INSERT INTO SM_TAH
	VALUES (3907,
	3832,
	3906);
INSERT INTO SM_AH
	VALUES (3907,
	3832);
INSERT INTO SM_ACT
	VALUES (3907,
	3832,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3908,
	3832,
	3907);
INSERT INTO ACT_ACT
	VALUES (3908,
	'transition',
	0,
	3909,
	0,
	0,
	'HeartRateMonitor8: registerListener',
	0);
INSERT INTO ACT_BLK
	VALUES (3909,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3908,
	0);
INSERT INTO SM_TXN
	VALUES (3906,
	3832,
	3855,
	0);
INSERT INTO SM_NSTXN
	VALUES (3910,
	3832,
	3855,
	3834,
	0);
INSERT INTO SM_TAH
	VALUES (3911,
	3832,
	3910);
INSERT INTO SM_AH
	VALUES (3911,
	3832);
INSERT INTO SM_ACT
	VALUES (3911,
	3832,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3912,
	3832,
	3911);
INSERT INTO ACT_ACT
	VALUES (3912,
	'transition',
	0,
	3913,
	0,
	0,
	'HeartRateMonitor5: registerComplete',
	0);
INSERT INTO ACT_BLK
	VALUES (3913,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3912,
	0);
INSERT INTO SM_TXN
	VALUES (3910,
	3832,
	3840,
	0);
INSERT INTO SM_NSTXN
	VALUES (3914,
	3832,
	3840,
	3787,
	0);
INSERT INTO SM_TAH
	VALUES (3915,
	3832,
	3914);
INSERT INTO SM_AH
	VALUES (3915,
	3832);
INSERT INTO SM_ACT
	VALUES (3915,
	3832,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3916,
	3832,
	3915);
INSERT INTO ACT_ACT
	VALUES (3916,
	'transition',
	0,
	3917,
	0,
	0,
	'HeartRateMonitor9: unregisterListener',
	0);
INSERT INTO ACT_BLK
	VALUES (3917,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3916,
	0);
INSERT INTO SM_TXN
	VALUES (3914,
	3832,
	3881,
	0);
INSERT INTO SM_NSTXN
	VALUES (3918,
	3832,
	3881,
	3835,
	0);
INSERT INTO SM_TAH
	VALUES (3919,
	3832,
	3918);
INSERT INTO SM_AH
	VALUES (3919,
	3832);
INSERT INTO SM_ACT
	VALUES (3919,
	3832,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (3920,
	3832,
	3919);
INSERT INTO ACT_ACT
	VALUES (3920,
	'transition',
	0,
	3921,
	0,
	0,
	'HeartRateMonitor7: unregisterComplete',
	0);
INSERT INTO ACT_BLK
	VALUES (3921,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3920,
	0);
INSERT INTO SM_TXN
	VALUES (3918,
	3832,
	3836,
	0);
-- root-types-contained: SystemModel_c
-- BP 7.1 content: StreamData syschar: 3 persistence-version: 7.1.6

INSERT INTO S_SYS
	VALUES (3922,
	'Location',
	1);
INSERT INTO EP_PKG
	VALUES (1370,
	3922,
	3922,
	'Location',
	'',
	0);
INSERT INTO PE_PE
	VALUES (3923,
	1,
	1370,
	0,
	7);
INSERT INTO EP_PKG
	VALUES (3923,
	0,
	3922,
	'Shared',
	'',
	0);
INSERT INTO PE_PE
	VALUES (25,
	1,
	3923,
	0,
	6);
INSERT INTO C_I
	VALUES (25,
	0,
	'LocationProvider',
	'');
INSERT INTO C_EP
	VALUES (27,
	25,
	-1,
	'getLocation',
	'');
INSERT INTO C_IO
	VALUES (27,
	1192,
	'getLocation',
	'',
	0,
	'',
	0);
INSERT INTO C_PP
	VALUES (1363,
	27,
	153,
	'latitude',
	'Latitude, expressed in decimal degrees, of the current position.',
	1,
	'',
	0);
INSERT INTO C_PP
	VALUES (1364,
	27,
	153,
	'longitude',
	'Longitude, expressed in decimal degrees, of the current position.',
	1,
	'',
	1363);
INSERT INTO C_EP
	VALUES (31,
	25,
	-1,
	'registerListener',
	'');
INSERT INTO C_IO
	VALUES (31,
	1192,
	'registerListener',
	'',
	0,
	'',
	27);
INSERT INTO C_EP
	VALUES (35,
	25,
	-1,
	'unregisterListener',
	'');
INSERT INTO C_IO
	VALUES (35,
	1192,
	'unregisterListener',
	'',
	0,
	'',
	31);
INSERT INTO C_EP
	VALUES (39,
	25,
	-1,
	'getDistance',
	'');
INSERT INTO C_IO
	VALUES (39,
	1192,
	'getDistance',
	'',
	0,
	'',
	35);
INSERT INTO C_PP
	VALUES (1365,
	39,
	153,
	'fromLat',
	'',
	0,
	'',
	1366);
INSERT INTO C_PP
	VALUES (1367,
	39,
	153,
	'fromLong',
	'',
	0,
	'',
	1365);
INSERT INTO C_PP
	VALUES (1368,
	39,
	153,
	'toLat',
	'',
	0,
	'',
	1367);
INSERT INTO C_PP
	VALUES (1369,
	39,
	153,
	'toLong',
	'',
	0,
	'',
	1368);
INSERT INTO C_PP
	VALUES (1366,
	39,
	153,
	'result',
	'',
	1,
	'',
	0);
INSERT INTO PE_PE
	VALUES (492,
	1,
	1370,
	0,
	2);
INSERT INTO C_C
	VALUES (492,
	0,
	0,
	'Location',
	'Simulates a the GPS hardware/firmware. This component is only behavioral and included for testing purposes.',
	0,
	0,
	0,
	'');
INSERT INTO C_PO
	VALUES (493,
	492,
	'LOC',
	0,
	0);
INSERT INTO C_IR
	VALUES (496,
	25,
	0,
	493);
INSERT INTO C_P
	VALUES (496,
	'LocationProvider',
	'Unnamed Interface',
	'',
	'Location::LOC::LocationProvider');
INSERT INTO SPR_PEP
	VALUES (1359,
	27,
	496);
INSERT INTO SPR_PO
	VALUES (1359,
	'getLocation',
	'',
	'lat = param.latitude;
longi = param.longitude;
::getLocation( latitude:lat, longitude: longi);
param.latitude = lat;
param.longitude = longi;
',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (3924,
	1359);
INSERT INTO ACT_ACT
	VALUES (3924,
	'interface operation',
	0,
	3925,
	0,
	0,
	'LOC::LocationProvider::getLocation',
	0);
INSERT INTO ACT_BLK
	VALUES (3925,
	0,
	0,
	0,
	'',
	'',
	'',
	5,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3924,
	0);
INSERT INTO ACT_SMT
	VALUES (3926,
	3925,
	3927,
	1,
	1,
	'LOC::LocationProvider::getLocation line: 1');
INSERT INTO ACT_AI
	VALUES (3926,
	3928,
	3929,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3927,
	3925,
	3930,
	2,
	1,
	'LOC::LocationProvider::getLocation line: 2');
INSERT INTO ACT_AI
	VALUES (3927,
	3931,
	3932,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3930,
	3925,
	3933,
	3,
	1,
	'LOC::LocationProvider::getLocation line: 3');
INSERT INTO ACT_FNC
	VALUES (3930,
	3934,
	3,
	3);
INSERT INTO ACT_SMT
	VALUES (3933,
	3925,
	3935,
	4,
	1,
	'LOC::LocationProvider::getLocation line: 4');
INSERT INTO ACT_AI
	VALUES (3933,
	3936,
	3937,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3935,
	3925,
	0,
	5,
	1,
	'LOC::LocationProvider::getLocation line: 5');
INSERT INTO ACT_AI
	VALUES (3935,
	3938,
	3939,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3929,
	1,
	1,
	1,
	1,
	3,
	0,
	0,
	0,
	0,
	153,
	3925);
INSERT INTO V_TVL
	VALUES (3929,
	3940);
INSERT INTO V_VAL
	VALUES (3928,
	0,
	0,
	1,
	13,
	20,
	0,
	0,
	0,
	0,
	153,
	3925);
INSERT INTO V_PVL
	VALUES (3928,
	0,
	0,
	0,
	1363);
INSERT INTO V_VAL
	VALUES (3932,
	1,
	1,
	2,
	1,
	5,
	0,
	0,
	0,
	0,
	153,
	3925);
INSERT INTO V_TVL
	VALUES (3932,
	3941);
INSERT INTO V_VAL
	VALUES (3931,
	0,
	0,
	2,
	15,
	23,
	0,
	0,
	0,
	0,
	153,
	3925);
INSERT INTO V_PVL
	VALUES (3931,
	0,
	0,
	0,
	1364);
INSERT INTO V_VAL
	VALUES (3942,
	0,
	0,
	3,
	25,
	27,
	0,
	0,
	0,
	0,
	153,
	3925);
INSERT INTO V_TVL
	VALUES (3942,
	3940);
INSERT INTO V_PAR
	VALUES (3942,
	3930,
	0,
	'latitude',
	3943,
	3,
	16);
INSERT INTO V_VAL
	VALUES (3943,
	0,
	0,
	3,
	41,
	45,
	0,
	0,
	0,
	0,
	153,
	3925);
INSERT INTO V_TVL
	VALUES (3943,
	3941);
INSERT INTO V_PAR
	VALUES (3943,
	3930,
	0,
	'longitude',
	0,
	3,
	30);
INSERT INTO V_VAL
	VALUES (3937,
	1,
	0,
	4,
	7,
	14,
	0,
	0,
	0,
	0,
	153,
	3925);
INSERT INTO V_PVL
	VALUES (3937,
	0,
	0,
	0,
	1363);
INSERT INTO V_VAL
	VALUES (3936,
	0,
	0,
	4,
	18,
	20,
	0,
	0,
	0,
	0,
	153,
	3925);
INSERT INTO V_TVL
	VALUES (3936,
	3940);
INSERT INTO V_VAL
	VALUES (3939,
	1,
	0,
	5,
	7,
	15,
	0,
	0,
	0,
	0,
	153,
	3925);
INSERT INTO V_PVL
	VALUES (3939,
	0,
	0,
	0,
	1364);
INSERT INTO V_VAL
	VALUES (3938,
	0,
	0,
	5,
	19,
	23,
	0,
	0,
	0,
	0,
	153,
	3925);
INSERT INTO V_TVL
	VALUES (3938,
	3941);
INSERT INTO V_VAR
	VALUES (3940,
	3925,
	'lat',
	1,
	153);
INSERT INTO V_TRN
	VALUES (3940,
	0,
	'');
INSERT INTO V_VAR
	VALUES (3941,
	3925,
	'longi',
	1,
	153);
INSERT INTO V_TRN
	VALUES (3941,
	0,
	'');
INSERT INTO SPR_PEP
	VALUES (1360,
	31,
	496);
INSERT INTO SPR_PO
	VALUES (1360,
	'registerListener',
	'',
	'::registerListener();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (3944,
	1360);
INSERT INTO ACT_ACT
	VALUES (3944,
	'interface operation',
	0,
	3945,
	0,
	0,
	'LOC::LocationProvider::registerListener',
	0);
INSERT INTO ACT_BLK
	VALUES (3945,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3944,
	0);
INSERT INTO ACT_SMT
	VALUES (3946,
	3945,
	0,
	1,
	1,
	'LOC::LocationProvider::registerListener line: 1');
INSERT INTO ACT_FNC
	VALUES (3946,
	3947,
	1,
	3);
INSERT INTO SPR_PEP
	VALUES (1361,
	35,
	496);
INSERT INTO SPR_PO
	VALUES (1361,
	'unregisterListener',
	'',
	'::unregisterListener();',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (3948,
	1361);
INSERT INTO ACT_ACT
	VALUES (3948,
	'interface operation',
	0,
	3949,
	0,
	0,
	'LOC::LocationProvider::unregisterListener',
	0);
INSERT INTO ACT_BLK
	VALUES (3949,
	0,
	0,
	0,
	'',
	'',
	'',
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3948,
	0);
INSERT INTO ACT_SMT
	VALUES (3950,
	3949,
	0,
	1,
	1,
	'LOC::LocationProvider::unregisterListener line: 1');
INSERT INTO ACT_FNC
	VALUES (3950,
	3951,
	1,
	3);
INSERT INTO SPR_PEP
	VALUES (1362,
	39,
	496);
INSERT INTO SPR_PO
	VALUES (1362,
	'getDistance',
	'',
	'distance = param.result;
::getDistance( result:distance, fromLat:param.fromLat, fromLong:param.fromLong, toLat:param.toLat, toLong: param.toLong);
param.result = distance;',
	1,
	0);
INSERT INTO ACT_POB
	VALUES (3952,
	1362);
INSERT INTO ACT_ACT
	VALUES (3952,
	'interface operation',
	0,
	3953,
	0,
	0,
	'LOC::LocationProvider::getDistance',
	0);
INSERT INTO ACT_BLK
	VALUES (3953,
	0,
	0,
	0,
	'',
	'',
	'',
	3,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3952,
	0);
INSERT INTO ACT_SMT
	VALUES (3954,
	3953,
	3955,
	1,
	1,
	'LOC::LocationProvider::getDistance line: 1');
INSERT INTO ACT_AI
	VALUES (3954,
	3956,
	3957,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3955,
	3953,
	3958,
	2,
	1,
	'LOC::LocationProvider::getDistance line: 2');
INSERT INTO ACT_FNC
	VALUES (3955,
	3959,
	2,
	3);
INSERT INTO ACT_SMT
	VALUES (3958,
	3953,
	0,
	3,
	1,
	'LOC::LocationProvider::getDistance line: 3');
INSERT INTO ACT_AI
	VALUES (3958,
	3960,
	3961,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3957,
	1,
	1,
	1,
	1,
	8,
	0,
	0,
	0,
	0,
	153,
	3953);
INSERT INTO V_TVL
	VALUES (3957,
	3962);
INSERT INTO V_VAL
	VALUES (3956,
	0,
	0,
	1,
	18,
	23,
	0,
	0,
	0,
	0,
	153,
	3953);
INSERT INTO V_PVL
	VALUES (3956,
	0,
	0,
	0,
	1366);
INSERT INTO V_VAL
	VALUES (3963,
	0,
	0,
	2,
	23,
	30,
	0,
	0,
	0,
	0,
	153,
	3953);
INSERT INTO V_TVL
	VALUES (3963,
	3962);
INSERT INTO V_PAR
	VALUES (3963,
	3955,
	0,
	'result',
	3964,
	2,
	16);
INSERT INTO V_VAL
	VALUES (3964,
	0,
	0,
	2,
	47,
	53,
	0,
	0,
	0,
	0,
	153,
	3953);
INSERT INTO V_PVL
	VALUES (3964,
	0,
	0,
	0,
	1365);
INSERT INTO V_PAR
	VALUES (3964,
	3955,
	0,
	'fromLat',
	3965,
	2,
	33);
INSERT INTO V_VAL
	VALUES (3965,
	0,
	0,
	2,
	71,
	78,
	0,
	0,
	0,
	0,
	153,
	3953);
INSERT INTO V_PVL
	VALUES (3965,
	0,
	0,
	0,
	1367);
INSERT INTO V_PAR
	VALUES (3965,
	3955,
	0,
	'fromLong',
	3966,
	2,
	56);
INSERT INTO V_VAL
	VALUES (3966,
	0,
	0,
	2,
	93,
	97,
	0,
	0,
	0,
	0,
	153,
	3953);
INSERT INTO V_PVL
	VALUES (3966,
	0,
	0,
	0,
	1368);
INSERT INTO V_PAR
	VALUES (3966,
	3955,
	0,
	'toLat',
	3967,
	2,
	81);
INSERT INTO V_VAL
	VALUES (3967,
	0,
	0,
	2,
	114,
	119,
	0,
	0,
	0,
	0,
	153,
	3953);
INSERT INTO V_PVL
	VALUES (3967,
	0,
	0,
	0,
	1369);
INSERT INTO V_PAR
	VALUES (3967,
	3955,
	0,
	'toLong',
	0,
	2,
	100);
INSERT INTO V_VAL
	VALUES (3961,
	1,
	0,
	3,
	7,
	12,
	0,
	0,
	0,
	0,
	153,
	3953);
INSERT INTO V_PVL
	VALUES (3961,
	0,
	0,
	0,
	1366);
INSERT INTO V_VAL
	VALUES (3960,
	0,
	0,
	3,
	16,
	23,
	0,
	0,
	0,
	0,
	153,
	3953);
INSERT INTO V_TVL
	VALUES (3960,
	3962);
INSERT INTO V_VAR
	VALUES (3962,
	3953,
	'distance',
	1,
	153);
INSERT INTO V_TRN
	VALUES (3962,
	0,
	'');
INSERT INTO PE_PE
	VALUES (3968,
	1,
	0,
	492,
	7);
INSERT INTO EP_PKG
	VALUES (3968,
	0,
	3922,
	'functions',
	'',
	0);
INSERT INTO PE_PE
	VALUES (3934,
	1,
	3968,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3934,
	0,
	'getLocation',
	'',
	'// Return, via reference arguments, the current position of the singleton 
// instance of the simulated GPS.

GPS::initialize();
select any gps from instances of GPS;
param.latitude = gps.currentLatitude;
param.longitude = gps.currentLongitude; ',
	1192,
	1,
	'',
	0);
INSERT INTO S_SPARM
	VALUES (3969,
	3934,
	'latitude',
	153,
	1,
	'',
	0,
	'');
INSERT INTO S_SPARM
	VALUES (3970,
	3934,
	'longitude',
	153,
	1,
	'',
	3969,
	'');
INSERT INTO ACT_FNB
	VALUES (3971,
	3934);
INSERT INTO ACT_ACT
	VALUES (3971,
	'function',
	0,
	3972,
	0,
	0,
	'getLocation',
	0);
INSERT INTO ACT_BLK
	VALUES (3972,
	1,
	0,
	0,
	'GPS',
	'',
	'',
	7,
	1,
	5,
	34,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3971,
	0);
INSERT INTO ACT_SMT
	VALUES (3973,
	3972,
	3974,
	4,
	1,
	'getLocation line: 4');
INSERT INTO ACT_TFM
	VALUES (3973,
	3975,
	0,
	4,
	6,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES (3974,
	3972,
	3976,
	5,
	1,
	'getLocation line: 5');
INSERT INTO ACT_FIO
	VALUES (3974,
	3977,
	1,
	'any',
	3978,
	5,
	34);
INSERT INTO ACT_SMT
	VALUES (3976,
	3972,
	3979,
	6,
	1,
	'getLocation line: 6');
INSERT INTO ACT_AI
	VALUES (3976,
	3980,
	3981,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (3979,
	3972,
	0,
	7,
	1,
	'getLocation line: 7');
INSERT INTO ACT_AI
	VALUES (3979,
	3982,
	3983,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3981,
	1,
	0,
	6,
	7,
	14,
	0,
	0,
	0,
	0,
	153,
	3972);
INSERT INTO V_PVL
	VALUES (3981,
	0,
	3969,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3984,
	0,
	0,
	6,
	18,
	20,
	0,
	0,
	0,
	0,
	1309,
	3972);
INSERT INTO V_IRF
	VALUES (3984,
	3977);
INSERT INTO V_VAL
	VALUES (3980,
	0,
	0,
	6,
	22,
	36,
	0,
	0,
	0,
	0,
	153,
	3972);
INSERT INTO V_AVL
	VALUES (3980,
	3984,
	3978,
	3985);
INSERT INTO V_VAL
	VALUES (3983,
	1,
	0,
	7,
	7,
	15,
	0,
	0,
	0,
	0,
	153,
	3972);
INSERT INTO V_PVL
	VALUES (3983,
	0,
	3970,
	0,
	0);
INSERT INTO V_VAL
	VALUES (3986,
	0,
	0,
	7,
	19,
	21,
	0,
	0,
	0,
	0,
	1309,
	3972);
INSERT INTO V_IRF
	VALUES (3986,
	3977);
INSERT INTO V_VAL
	VALUES (3982,
	0,
	0,
	7,
	23,
	38,
	0,
	0,
	0,
	0,
	153,
	3972);
INSERT INTO V_AVL
	VALUES (3982,
	3986,
	3978,
	3987);
INSERT INTO V_VAR
	VALUES (3977,
	3972,
	'gps',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3977,
	0,
	3978);
INSERT INTO PE_PE
	VALUES (3959,
	1,
	3968,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3959,
	0,
	'getDistance',
	'',
	'// Return the straight-line distance, expressed in meters, between the 
// two points passed as parameters, expressed in decimal degrees.

Distance::initialize();
select any distance from instances of Distance;
deltaLat = param.toLat - param.fromLat;
deltaLong = param.toLong - param.fromLong;
sumSquares = (deltaLat * deltaLat) + (deltaLong * deltaLong);
sqrtSum = ::sqrt( x:sumSquares );
result = (sqrtSum * distance.kmPerDegree * 1000 );
param.result = result;

',
	1192,
	1,
	'',
	0);
INSERT INTO S_SPARM
	VALUES (3988,
	3959,
	'fromLat',
	153,
	0,
	'',
	3989,
	'');
INSERT INTO S_SPARM
	VALUES (3990,
	3959,
	'fromLong',
	153,
	0,
	'',
	3988,
	'');
INSERT INTO S_SPARM
	VALUES (3991,
	3959,
	'toLat',
	153,
	0,
	'',
	3990,
	'');
INSERT INTO S_SPARM
	VALUES (3992,
	3959,
	'toLong',
	153,
	0,
	'',
	3991,
	'');
INSERT INTO S_SPARM
	VALUES (3989,
	3959,
	'result',
	153,
	1,
	'',
	0,
	'');
INSERT INTO ACT_FNB
	VALUES (3993,
	3959);
INSERT INTO ACT_ACT
	VALUES (3993,
	'function',
	0,
	3994,
	0,
	0,
	'getDistance',
	0);
INSERT INTO ACT_BLK
	VALUES (3994,
	1,
	0,
	0,
	'Distance',
	'',
	'',
	11,
	1,
	5,
	39,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	3993,
	0);
INSERT INTO ACT_SMT
	VALUES (3995,
	3994,
	3996,
	4,
	1,
	'getDistance line: 4');
INSERT INTO ACT_TFM
	VALUES (3995,
	3997,
	0,
	4,
	11,
	4,
	1);
INSERT INTO ACT_SMT
	VALUES (3996,
	3994,
	3998,
	5,
	1,
	'getDistance line: 5');
INSERT INTO ACT_FIO
	VALUES (3996,
	3999,
	1,
	'any',
	4000,
	5,
	39);
INSERT INTO ACT_SMT
	VALUES (3998,
	3994,
	4001,
	6,
	1,
	'getDistance line: 6');
INSERT INTO ACT_AI
	VALUES (3998,
	4002,
	4003,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4001,
	3994,
	4004,
	7,
	1,
	'getDistance line: 7');
INSERT INTO ACT_AI
	VALUES (4001,
	4005,
	4006,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4004,
	3994,
	4007,
	8,
	1,
	'getDistance line: 8');
INSERT INTO ACT_AI
	VALUES (4004,
	4008,
	4009,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4007,
	3994,
	4010,
	9,
	1,
	'getDistance line: 9');
INSERT INTO ACT_AI
	VALUES (4007,
	4011,
	4012,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4010,
	3994,
	4013,
	10,
	1,
	'getDistance line: 10');
INSERT INTO ACT_AI
	VALUES (4010,
	4014,
	4015,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4013,
	3994,
	0,
	11,
	1,
	'getDistance line: 11');
INSERT INTO ACT_AI
	VALUES (4013,
	4016,
	4017,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4003,
	1,
	1,
	6,
	1,
	8,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_TVL
	VALUES (4003,
	4018);
INSERT INTO V_VAL
	VALUES (4019,
	0,
	0,
	6,
	18,
	22,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_PVL
	VALUES (4019,
	0,
	3991,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4002,
	0,
	0,
	6,
	18,
	38,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_BIN
	VALUES (4002,
	4020,
	4019,
	'-');
INSERT INTO V_VAL
	VALUES (4020,
	0,
	0,
	6,
	32,
	38,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_PVL
	VALUES (4020,
	0,
	3988,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4006,
	1,
	1,
	7,
	1,
	9,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_TVL
	VALUES (4006,
	4021);
INSERT INTO V_VAL
	VALUES (4022,
	0,
	0,
	7,
	19,
	24,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_PVL
	VALUES (4022,
	0,
	3992,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4005,
	0,
	0,
	7,
	19,
	41,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_BIN
	VALUES (4005,
	4023,
	4022,
	'-');
INSERT INTO V_VAL
	VALUES (4023,
	0,
	0,
	7,
	34,
	41,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_PVL
	VALUES (4023,
	0,
	3990,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4009,
	1,
	1,
	8,
	1,
	10,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_TVL
	VALUES (4009,
	4024);
INSERT INTO V_VAL
	VALUES (4025,
	0,
	0,
	8,
	15,
	22,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_TVL
	VALUES (4025,
	4018);
INSERT INTO V_VAL
	VALUES (4026,
	0,
	0,
	8,
	15,
	33,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_BIN
	VALUES (4026,
	4027,
	4025,
	'*');
INSERT INTO V_VAL
	VALUES (4027,
	0,
	0,
	8,
	26,
	33,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_TVL
	VALUES (4027,
	4018);
INSERT INTO V_VAL
	VALUES (4008,
	0,
	0,
	8,
	15,
	59,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_BIN
	VALUES (4008,
	4028,
	4026,
	'+');
INSERT INTO V_VAL
	VALUES (4029,
	0,
	0,
	8,
	39,
	47,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_TVL
	VALUES (4029,
	4021);
INSERT INTO V_VAL
	VALUES (4028,
	0,
	0,
	8,
	39,
	59,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_BIN
	VALUES (4028,
	4030,
	4029,
	'*');
INSERT INTO V_VAL
	VALUES (4030,
	0,
	0,
	8,
	51,
	59,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_TVL
	VALUES (4030,
	4021);
INSERT INTO V_VAL
	VALUES (4012,
	1,
	1,
	9,
	1,
	7,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_TVL
	VALUES (4012,
	4031);
INSERT INTO V_VAL
	VALUES (4011,
	0,
	0,
	9,
	13,
	-1,
	9,
	19,
	0,
	0,
	153,
	3994);
INSERT INTO V_FNV
	VALUES (4011,
	4032,
	1);
INSERT INTO V_VAL
	VALUES (4033,
	0,
	0,
	9,
	21,
	30,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_TVL
	VALUES (4033,
	4024);
INSERT INTO V_PAR
	VALUES (4033,
	0,
	4011,
	'x',
	0,
	9,
	19);
INSERT INTO V_VAL
	VALUES (4015,
	1,
	1,
	10,
	1,
	6,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_TVL
	VALUES (4015,
	4034);
INSERT INTO V_VAL
	VALUES (4035,
	0,
	0,
	10,
	11,
	17,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_TVL
	VALUES (4035,
	4031);
INSERT INTO V_VAL
	VALUES (4036,
	0,
	0,
	10,
	11,
	40,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_BIN
	VALUES (4036,
	4037,
	4035,
	'*');
INSERT INTO V_VAL
	VALUES (4038,
	0,
	0,
	10,
	21,
	28,
	0,
	0,
	0,
	0,
	1309,
	3994);
INSERT INTO V_IRF
	VALUES (4038,
	3999);
INSERT INTO V_VAL
	VALUES (4037,
	0,
	0,
	10,
	30,
	40,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_AVL
	VALUES (4037,
	4038,
	4000,
	4039);
INSERT INTO V_VAL
	VALUES (4014,
	0,
	0,
	10,
	11,
	47,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_BIN
	VALUES (4014,
	4040,
	4036,
	'*');
INSERT INTO V_VAL
	VALUES (4040,
	0,
	0,
	10,
	44,
	47,
	0,
	0,
	0,
	0,
	160,
	3994);
INSERT INTO V_LIN
	VALUES (4040,
	'1000');
INSERT INTO V_VAL
	VALUES (4017,
	1,
	0,
	11,
	7,
	12,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_PVL
	VALUES (4017,
	0,
	3989,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4016,
	0,
	0,
	11,
	16,
	21,
	0,
	0,
	0,
	0,
	153,
	3994);
INSERT INTO V_TVL
	VALUES (4016,
	4034);
INSERT INTO V_VAR
	VALUES (3999,
	3994,
	'distance',
	1,
	1309);
INSERT INTO V_INT
	VALUES (3999,
	0,
	4000);
INSERT INTO V_VAR
	VALUES (4018,
	3994,
	'deltaLat',
	1,
	153);
INSERT INTO V_TRN
	VALUES (4018,
	0,
	'');
INSERT INTO V_VAR
	VALUES (4021,
	3994,
	'deltaLong',
	1,
	153);
INSERT INTO V_TRN
	VALUES (4021,
	0,
	'');
INSERT INTO V_VAR
	VALUES (4024,
	3994,
	'sumSquares',
	1,
	153);
INSERT INTO V_TRN
	VALUES (4024,
	0,
	'');
INSERT INTO V_VAR
	VALUES (4031,
	3994,
	'sqrtSum',
	1,
	153);
INSERT INTO V_TRN
	VALUES (4031,
	0,
	'');
INSERT INTO V_VAR
	VALUES (4034,
	3994,
	'result',
	1,
	153);
INSERT INTO V_TRN
	VALUES (4034,
	0,
	'');
INSERT INTO PE_PE
	VALUES (3947,
	1,
	3968,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3947,
	0,
	'registerListener',
	'',
	'GPS::initialize();
select any gps from instances of GPS;
generate GPS10:registerListener() to gps;
',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (4041,
	3947);
INSERT INTO ACT_ACT
	VALUES (4041,
	'function',
	0,
	4042,
	0,
	0,
	'registerListener',
	0);
INSERT INTO ACT_BLK
	VALUES (4042,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	3,
	1,
	2,
	34,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4041,
	0);
INSERT INTO ACT_SMT
	VALUES (4043,
	4042,
	4044,
	1,
	1,
	'registerListener line: 1');
INSERT INTO ACT_TFM
	VALUES (4043,
	3975,
	0,
	1,
	6,
	1,
	1);
INSERT INTO ACT_SMT
	VALUES (4044,
	4042,
	4045,
	2,
	1,
	'registerListener line: 2');
INSERT INTO ACT_FIO
	VALUES (4044,
	4046,
	1,
	'any',
	3978,
	2,
	34);
INSERT INTO ACT_SMT
	VALUES (4045,
	4042,
	0,
	3,
	1,
	'registerListener line: 3');
INSERT INTO E_ESS
	VALUES (4045,
	1,
	0,
	3,
	10,
	3,
	16,
	2,
	34,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (4045);
INSERT INTO E_GSME
	VALUES (4045,
	4047);
INSERT INTO E_GEN
	VALUES (4045,
	4046);
INSERT INTO V_VAR
	VALUES (4046,
	4042,
	'gps',
	1,
	1309);
INSERT INTO V_INT
	VALUES (4046,
	0,
	3978);
INSERT INTO PE_PE
	VALUES (3951,
	1,
	3968,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (3951,
	0,
	'unregisterListener',
	'',
	'GPS::initialize();
select any gps from instances of GPS;
generate GPS11:unregisterListener() to gps; 
',
	1192,
	1,
	'',
	0);
INSERT INTO ACT_FNB
	VALUES (4048,
	3951);
INSERT INTO ACT_ACT
	VALUES (4048,
	'function',
	0,
	4049,
	0,
	0,
	'unregisterListener',
	0);
INSERT INTO ACT_BLK
	VALUES (4049,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	3,
	1,
	2,
	34,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4048,
	0);
INSERT INTO ACT_SMT
	VALUES (4050,
	4049,
	4051,
	1,
	1,
	'unregisterListener line: 1');
INSERT INTO ACT_TFM
	VALUES (4050,
	3975,
	0,
	1,
	6,
	1,
	1);
INSERT INTO ACT_SMT
	VALUES (4051,
	4049,
	4052,
	2,
	1,
	'unregisterListener line: 2');
INSERT INTO ACT_FIO
	VALUES (4051,
	4053,
	1,
	'any',
	3978,
	2,
	34);
INSERT INTO ACT_SMT
	VALUES (4052,
	4049,
	0,
	3,
	1,
	'unregisterListener line: 3');
INSERT INTO E_ESS
	VALUES (4052,
	1,
	0,
	3,
	10,
	3,
	16,
	2,
	34,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (4052);
INSERT INTO E_GSME
	VALUES (4052,
	4054);
INSERT INTO E_GEN
	VALUES (4052,
	4053);
INSERT INTO V_VAR
	VALUES (4053,
	4049,
	'gps',
	1,
	1309);
INSERT INTO V_INT
	VALUES (4053,
	0,
	3978);
INSERT INTO PE_PE
	VALUES (4032,
	1,
	3968,
	0,
	1);
INSERT INTO S_SYNC
	VALUES (4032,
	0,
	'sqrt',
	'',
	'// TODO:FIXME There is a bug in verifier in handling of realized external entities in 
//      a multi-domain project. I am working around this by getting a sqrt approximation.
//sqrtSum = MATH::sqrt( x: sumSquares );
//      So, this is introduced as a workaround to give an approximation of sqrt.
result = 0.0;

inputValue = param.x;

// If a negative is passed-in take the abs value
if inputValue < 0
  inputValue = -param.x;
end if;

if (param.x > 0) 

	guess = param.x;
	MAX_ITERATIONS = 24;
	i = 0;
	prev_value = -1.0;
	while (i < MAX_ITERATIONS and prev_value != guess)
      prev_value = guess;
      guess = guess - (((guess*guess)-inputValue)/(2*guess));
	  i = i + 1;
	end while;
    result = guess;
end if;

return result;
',
	153,
	1,
	'',
	0);
INSERT INTO S_SPARM
	VALUES (4055,
	4032,
	'x',
	153,
	0,
	'',
	0,
	'');
INSERT INTO ACT_FNB
	VALUES (4056,
	4032);
INSERT INTO ACT_ACT
	VALUES (4056,
	'function',
	0,
	4057,
	0,
	0,
	'sqrt',
	0);
INSERT INTO ACT_BLK
	VALUES (4057,
	0,
	0,
	0,
	'',
	'',
	'',
	28,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4056,
	0);
INSERT INTO ACT_SMT
	VALUES (4058,
	4057,
	4059,
	5,
	1,
	'sqrt line: 5');
INSERT INTO ACT_AI
	VALUES (4058,
	4060,
	4061,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4059,
	4057,
	4062,
	7,
	1,
	'sqrt line: 7');
INSERT INTO ACT_AI
	VALUES (4059,
	4063,
	4064,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4062,
	4057,
	4065,
	10,
	1,
	'sqrt line: 10');
INSERT INTO ACT_IF
	VALUES (4062,
	4066,
	4067,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4065,
	4057,
	4068,
	14,
	1,
	'sqrt line: 14');
INSERT INTO ACT_IF
	VALUES (4065,
	4069,
	4070,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4068,
	4057,
	0,
	28,
	1,
	'sqrt line: 28');
INSERT INTO ACT_RET
	VALUES (4068,
	4071);
INSERT INTO V_VAL
	VALUES (4061,
	1,
	1,
	5,
	1,
	6,
	0,
	0,
	0,
	0,
	153,
	4057);
INSERT INTO V_TVL
	VALUES (4061,
	4072);
INSERT INTO V_VAL
	VALUES (4060,
	0,
	0,
	5,
	10,
	12,
	0,
	0,
	0,
	0,
	153,
	4057);
INSERT INTO V_LRL
	VALUES (4060,
	'0.0');
INSERT INTO V_VAL
	VALUES (4064,
	1,
	1,
	7,
	1,
	10,
	0,
	0,
	0,
	0,
	153,
	4057);
INSERT INTO V_TVL
	VALUES (4064,
	4073);
INSERT INTO V_VAL
	VALUES (4063,
	0,
	0,
	7,
	20,
	20,
	0,
	0,
	0,
	0,
	153,
	4057);
INSERT INTO V_PVL
	VALUES (4063,
	0,
	4055,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4074,
	0,
	0,
	10,
	4,
	13,
	0,
	0,
	0,
	0,
	153,
	4057);
INSERT INTO V_TVL
	VALUES (4074,
	4073);
INSERT INTO V_VAL
	VALUES (4067,
	0,
	0,
	10,
	4,
	17,
	0,
	0,
	0,
	0,
	125,
	4057);
INSERT INTO V_BIN
	VALUES (4067,
	4075,
	4074,
	'<');
INSERT INTO V_VAL
	VALUES (4075,
	0,
	0,
	10,
	17,
	17,
	0,
	0,
	0,
	0,
	160,
	4057);
INSERT INTO V_LIN
	VALUES (4075,
	'0');
INSERT INTO V_VAL
	VALUES (4076,
	0,
	0,
	14,
	11,
	11,
	0,
	0,
	0,
	0,
	153,
	4057);
INSERT INTO V_PVL
	VALUES (4076,
	0,
	4055,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4070,
	0,
	0,
	14,
	11,
	15,
	0,
	0,
	0,
	0,
	125,
	4057);
INSERT INTO V_BIN
	VALUES (4070,
	4077,
	4076,
	'>');
INSERT INTO V_VAL
	VALUES (4077,
	0,
	0,
	14,
	15,
	15,
	0,
	0,
	0,
	0,
	160,
	4057);
INSERT INTO V_LIN
	VALUES (4077,
	'0');
INSERT INTO V_VAL
	VALUES (4071,
	0,
	0,
	28,
	8,
	13,
	0,
	0,
	0,
	0,
	153,
	4057);
INSERT INTO V_TVL
	VALUES (4071,
	4072);
INSERT INTO V_VAR
	VALUES (4072,
	4057,
	'result',
	1,
	153);
INSERT INTO V_TRN
	VALUES (4072,
	0,
	'');
INSERT INTO V_VAR
	VALUES (4073,
	4057,
	'inputValue',
	1,
	153);
INSERT INTO V_TRN
	VALUES (4073,
	0,
	'');
INSERT INTO ACT_BLK
	VALUES (4066,
	0,
	0,
	0,
	'',
	'',
	'',
	11,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4056,
	0);
INSERT INTO ACT_SMT
	VALUES (4078,
	4066,
	0,
	11,
	3,
	'sqrt line: 11');
INSERT INTO ACT_AI
	VALUES (4078,
	4079,
	4080,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4080,
	1,
	0,
	11,
	3,
	12,
	0,
	0,
	0,
	0,
	153,
	4066);
INSERT INTO V_TVL
	VALUES (4080,
	4073);
INSERT INTO V_VAL
	VALUES (4079,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	153,
	4066);
INSERT INTO V_UNY
	VALUES (4079,
	4081,
	'-');
INSERT INTO V_VAL
	VALUES (4081,
	0,
	0,
	11,
	23,
	23,
	0,
	0,
	0,
	0,
	153,
	4066);
INSERT INTO V_PVL
	VALUES (4081,
	0,
	4055,
	0,
	0);
INSERT INTO ACT_BLK
	VALUES (4069,
	0,
	0,
	0,
	'',
	'',
	'',
	25,
	5,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4056,
	0);
INSERT INTO ACT_SMT
	VALUES (4082,
	4069,
	4083,
	16,
	2,
	'sqrt line: 16');
INSERT INTO ACT_AI
	VALUES (4082,
	4084,
	4085,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4083,
	4069,
	4086,
	17,
	2,
	'sqrt line: 17');
INSERT INTO ACT_AI
	VALUES (4083,
	4087,
	4088,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4086,
	4069,
	4089,
	18,
	2,
	'sqrt line: 18');
INSERT INTO ACT_AI
	VALUES (4086,
	4090,
	4091,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4089,
	4069,
	4092,
	19,
	2,
	'sqrt line: 19');
INSERT INTO ACT_AI
	VALUES (4089,
	4093,
	4094,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4092,
	4069,
	4095,
	20,
	2,
	'sqrt line: 20');
INSERT INTO ACT_WHL
	VALUES (4092,
	4096,
	4097);
INSERT INTO ACT_SMT
	VALUES (4095,
	4069,
	0,
	25,
	5,
	'sqrt line: 25');
INSERT INTO ACT_AI
	VALUES (4095,
	4098,
	4099,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4085,
	1,
	1,
	16,
	2,
	6,
	0,
	0,
	0,
	0,
	153,
	4069);
INSERT INTO V_TVL
	VALUES (4085,
	4100);
INSERT INTO V_VAL
	VALUES (4084,
	0,
	0,
	16,
	16,
	16,
	0,
	0,
	0,
	0,
	153,
	4069);
INSERT INTO V_PVL
	VALUES (4084,
	0,
	4055,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4088,
	1,
	1,
	17,
	2,
	15,
	0,
	0,
	0,
	0,
	160,
	4069);
INSERT INTO V_TVL
	VALUES (4088,
	4101);
INSERT INTO V_VAL
	VALUES (4087,
	0,
	0,
	17,
	19,
	20,
	0,
	0,
	0,
	0,
	160,
	4069);
INSERT INTO V_LIN
	VALUES (4087,
	'24');
INSERT INTO V_VAL
	VALUES (4091,
	1,
	1,
	18,
	2,
	2,
	0,
	0,
	0,
	0,
	160,
	4069);
INSERT INTO V_TVL
	VALUES (4091,
	4102);
INSERT INTO V_VAL
	VALUES (4090,
	0,
	0,
	18,
	6,
	6,
	0,
	0,
	0,
	0,
	160,
	4069);
INSERT INTO V_LIN
	VALUES (4090,
	'0');
INSERT INTO V_VAL
	VALUES (4094,
	1,
	1,
	19,
	2,
	11,
	0,
	0,
	0,
	0,
	153,
	4069);
INSERT INTO V_TVL
	VALUES (4094,
	4103);
INSERT INTO V_VAL
	VALUES (4093,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	153,
	4069);
INSERT INTO V_UNY
	VALUES (4093,
	4104,
	'-');
INSERT INTO V_VAL
	VALUES (4104,
	0,
	0,
	19,
	16,
	18,
	0,
	0,
	0,
	0,
	153,
	4069);
INSERT INTO V_LRL
	VALUES (4104,
	'1.0');
INSERT INTO V_VAL
	VALUES (4105,
	0,
	0,
	20,
	9,
	9,
	0,
	0,
	0,
	0,
	160,
	4069);
INSERT INTO V_TVL
	VALUES (4105,
	4102);
INSERT INTO V_VAL
	VALUES (4106,
	0,
	0,
	20,
	9,
	26,
	0,
	0,
	0,
	0,
	125,
	4069);
INSERT INTO V_BIN
	VALUES (4106,
	4107,
	4105,
	'<');
INSERT INTO V_VAL
	VALUES (4107,
	0,
	0,
	20,
	13,
	26,
	0,
	0,
	0,
	0,
	160,
	4069);
INSERT INTO V_TVL
	VALUES (4107,
	4101);
INSERT INTO V_VAL
	VALUES (4108,
	0,
	0,
	20,
	32,
	41,
	0,
	0,
	0,
	0,
	153,
	4069);
INSERT INTO V_TVL
	VALUES (4108,
	4103);
INSERT INTO V_VAL
	VALUES (4109,
	0,
	0,
	20,
	32,
	50,
	0,
	0,
	0,
	0,
	125,
	4069);
INSERT INTO V_BIN
	VALUES (4109,
	4110,
	4108,
	'!=');
INSERT INTO V_VAL
	VALUES (4110,
	0,
	0,
	20,
	46,
	50,
	0,
	0,
	0,
	0,
	153,
	4069);
INSERT INTO V_TVL
	VALUES (4110,
	4100);
INSERT INTO V_VAL
	VALUES (4096,
	0,
	0,
	20,
	9,
	50,
	0,
	0,
	0,
	0,
	125,
	4069);
INSERT INTO V_BIN
	VALUES (4096,
	4109,
	4106,
	'and');
INSERT INTO V_VAL
	VALUES (4099,
	1,
	0,
	25,
	5,
	10,
	0,
	0,
	0,
	0,
	153,
	4069);
INSERT INTO V_TVL
	VALUES (4099,
	4072);
INSERT INTO V_VAL
	VALUES (4098,
	0,
	0,
	25,
	14,
	18,
	0,
	0,
	0,
	0,
	153,
	4069);
INSERT INTO V_TVL
	VALUES (4098,
	4100);
INSERT INTO V_VAR
	VALUES (4100,
	4069,
	'guess',
	1,
	153);
INSERT INTO V_TRN
	VALUES (4100,
	0,
	'');
INSERT INTO V_VAR
	VALUES (4101,
	4069,
	'MAX_ITERATIONS',
	1,
	160);
INSERT INTO V_TRN
	VALUES (4101,
	0,
	'');
INSERT INTO V_VAR
	VALUES (4102,
	4069,
	'i',
	1,
	160);
INSERT INTO V_TRN
	VALUES (4102,
	0,
	'');
INSERT INTO V_VAR
	VALUES (4103,
	4069,
	'prev_value',
	1,
	153);
INSERT INTO V_TRN
	VALUES (4103,
	0,
	'');
INSERT INTO ACT_BLK
	VALUES (4097,
	0,
	0,
	0,
	'',
	'',
	'',
	23,
	4,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4056,
	0);
INSERT INTO ACT_SMT
	VALUES (4111,
	4097,
	4112,
	21,
	7,
	'sqrt line: 21');
INSERT INTO ACT_AI
	VALUES (4111,
	4113,
	4114,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4112,
	4097,
	4115,
	22,
	7,
	'sqrt line: 22');
INSERT INTO ACT_AI
	VALUES (4112,
	4116,
	4117,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4115,
	4097,
	0,
	23,
	4,
	'sqrt line: 23');
INSERT INTO ACT_AI
	VALUES (4115,
	4118,
	4119,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4114,
	1,
	0,
	21,
	7,
	16,
	0,
	0,
	0,
	0,
	153,
	4097);
INSERT INTO V_TVL
	VALUES (4114,
	4103);
INSERT INTO V_VAL
	VALUES (4113,
	0,
	0,
	21,
	20,
	24,
	0,
	0,
	0,
	0,
	153,
	4097);
INSERT INTO V_TVL
	VALUES (4113,
	4100);
INSERT INTO V_VAL
	VALUES (4117,
	1,
	0,
	22,
	7,
	11,
	0,
	0,
	0,
	0,
	153,
	4097);
INSERT INTO V_TVL
	VALUES (4117,
	4100);
INSERT INTO V_VAL
	VALUES (4120,
	0,
	0,
	22,
	15,
	19,
	0,
	0,
	0,
	0,
	153,
	4097);
INSERT INTO V_TVL
	VALUES (4120,
	4100);
INSERT INTO V_VAL
	VALUES (4116,
	0,
	0,
	22,
	15,
	58,
	0,
	0,
	0,
	0,
	153,
	4097);
INSERT INTO V_BIN
	VALUES (4116,
	4121,
	4120,
	'-');
INSERT INTO V_VAL
	VALUES (4122,
	0,
	0,
	22,
	26,
	30,
	0,
	0,
	0,
	0,
	153,
	4097);
INSERT INTO V_TVL
	VALUES (4122,
	4100);
INSERT INTO V_VAL
	VALUES (4123,
	0,
	0,
	22,
	26,
	36,
	0,
	0,
	0,
	0,
	153,
	4097);
INSERT INTO V_BIN
	VALUES (4123,
	4124,
	4122,
	'*');
INSERT INTO V_VAL
	VALUES (4124,
	0,
	0,
	22,
	32,
	36,
	0,
	0,
	0,
	0,
	153,
	4097);
INSERT INTO V_TVL
	VALUES (4124,
	4100);
INSERT INTO V_VAL
	VALUES (4125,
	0,
	0,
	22,
	26,
	48,
	0,
	0,
	0,
	0,
	153,
	4097);
INSERT INTO V_BIN
	VALUES (4125,
	4126,
	4123,
	'-');
INSERT INTO V_VAL
	VALUES (4126,
	0,
	0,
	22,
	39,
	48,
	0,
	0,
	0,
	0,
	153,
	4097);
INSERT INTO V_TVL
	VALUES (4126,
	4073);
INSERT INTO V_VAL
	VALUES (4121,
	0,
	0,
	22,
	26,
	58,
	0,
	0,
	0,
	0,
	153,
	4097);
INSERT INTO V_BIN
	VALUES (4121,
	4127,
	4125,
	'/');
INSERT INTO V_VAL
	VALUES (4128,
	0,
	0,
	22,
	52,
	52,
	0,
	0,
	0,
	0,
	160,
	4097);
INSERT INTO V_LIN
	VALUES (4128,
	'2');
INSERT INTO V_VAL
	VALUES (4127,
	0,
	0,
	22,
	52,
	58,
	0,
	0,
	0,
	0,
	153,
	4097);
INSERT INTO V_BIN
	VALUES (4127,
	4129,
	4128,
	'*');
INSERT INTO V_VAL
	VALUES (4129,
	0,
	0,
	22,
	54,
	58,
	0,
	0,
	0,
	0,
	153,
	4097);
INSERT INTO V_TVL
	VALUES (4129,
	4100);
INSERT INTO V_VAL
	VALUES (4119,
	1,
	0,
	23,
	4,
	4,
	0,
	0,
	0,
	0,
	160,
	4097);
INSERT INTO V_TVL
	VALUES (4119,
	4102);
INSERT INTO V_VAL
	VALUES (4130,
	0,
	0,
	23,
	8,
	8,
	0,
	0,
	0,
	0,
	160,
	4097);
INSERT INTO V_TVL
	VALUES (4130,
	4102);
INSERT INTO V_VAL
	VALUES (4118,
	0,
	0,
	23,
	8,
	12,
	0,
	0,
	0,
	0,
	160,
	4097);
INSERT INTO V_BIN
	VALUES (4118,
	4131,
	4130,
	'+');
INSERT INTO V_VAL
	VALUES (4131,
	0,
	0,
	23,
	12,
	12,
	0,
	0,
	0,
	0,
	160,
	4097);
INSERT INTO V_LIN
	VALUES (4131,
	'1');
INSERT INTO PE_PE
	VALUES (4132,
	1,
	0,
	492,
	7);
INSERT INTO EP_PKG
	VALUES (4132,
	0,
	3922,
	'Location',
	'',
	0);
INSERT INTO PE_PE
	VALUES (4000,
	1,
	4132,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (4000,
	'Distance',
	3,
	'Distance',
	'kmPerDegree is a rough conversion figure valid for most latitude figures (except where 
the irregular shape of the earth perturbs the value) and for longitude figures
away from the poles (where the distance between longitude lines decreases to zero).

latitudeIncrement and longitudeIncrement specify the distance traveled by the simulated
GPS during each interval.',
	0);
INSERT INTO O_TFR
	VALUES (3997,
	4000,
	'initialize',
	'',
	1192,
	0,
	'select any distance from instances of Distance;
if ( empty distance )
  create object instance distance of Distance; distance.id = 1;
  distance.kmPerDegree = 111.32;
end if;',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (4133,
	3997);
INSERT INTO ACT_ACT
	VALUES (4133,
	'class operation',
	0,
	4134,
	0,
	0,
	'Distance::initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (4134,
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	39,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4133,
	0);
INSERT INTO ACT_SMT
	VALUES (4135,
	4134,
	4136,
	1,
	1,
	'Distance::initialize line: 1');
INSERT INTO ACT_FIO
	VALUES (4135,
	4137,
	1,
	'any',
	4000,
	1,
	39);
INSERT INTO ACT_SMT
	VALUES (4136,
	4134,
	0,
	2,
	1,
	'Distance::initialize line: 2');
INSERT INTO ACT_IF
	VALUES (4136,
	4138,
	4139,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4140,
	0,
	0,
	2,
	12,
	19,
	0,
	0,
	0,
	0,
	1309,
	4134);
INSERT INTO V_IRF
	VALUES (4140,
	4137);
INSERT INTO V_VAL
	VALUES (4139,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	4134);
INSERT INTO V_UNY
	VALUES (4139,
	4140,
	'empty');
INSERT INTO V_VAR
	VALUES (4137,
	4134,
	'distance',
	1,
	1309);
INSERT INTO V_INT
	VALUES (4137,
	0,
	4000);
INSERT INTO ACT_BLK
	VALUES (4138,
	0,
	0,
	0,
	'',
	'',
	'',
	4,
	3,
	3,
	38,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4133,
	0);
INSERT INTO ACT_SMT
	VALUES (4141,
	4138,
	4142,
	3,
	3,
	'Distance::initialize line: 3');
INSERT INTO ACT_CR
	VALUES (4141,
	4137,
	0,
	4000,
	3,
	38);
INSERT INTO ACT_SMT
	VALUES (4142,
	4138,
	4143,
	3,
	48,
	'Distance::initialize line: 3');
INSERT INTO ACT_AI
	VALUES (4142,
	4144,
	4145,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4143,
	4138,
	0,
	4,
	3,
	'Distance::initialize line: 4');
INSERT INTO ACT_AI
	VALUES (4143,
	4146,
	4147,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4148,
	1,
	0,
	3,
	48,
	55,
	0,
	0,
	0,
	0,
	1309,
	4138);
INSERT INTO V_IRF
	VALUES (4148,
	4137);
INSERT INTO V_VAL
	VALUES (4145,
	1,
	0,
	3,
	57,
	58,
	0,
	0,
	0,
	0,
	160,
	4138);
INSERT INTO V_AVL
	VALUES (4145,
	4148,
	4000,
	4149);
INSERT INTO V_VAL
	VALUES (4144,
	0,
	0,
	3,
	62,
	62,
	0,
	0,
	0,
	0,
	160,
	4138);
INSERT INTO V_LIN
	VALUES (4144,
	'1');
INSERT INTO V_VAL
	VALUES (4150,
	1,
	0,
	4,
	3,
	10,
	0,
	0,
	0,
	0,
	1309,
	4138);
INSERT INTO V_IRF
	VALUES (4150,
	4137);
INSERT INTO V_VAL
	VALUES (4147,
	1,
	0,
	4,
	12,
	22,
	0,
	0,
	0,
	0,
	153,
	4138);
INSERT INTO V_AVL
	VALUES (4147,
	4150,
	4000,
	4039);
INSERT INTO V_VAL
	VALUES (4146,
	0,
	0,
	4,
	26,
	31,
	0,
	0,
	0,
	0,
	153,
	4138);
INSERT INTO V_LRL
	VALUES (4146,
	'111.32');
INSERT INTO O_NBATTR
	VALUES (4149,
	4000);
INSERT INTO O_BATTR
	VALUES (4149,
	4000);
INSERT INTO O_ATTR
	VALUES (4149,
	4000,
	0,
	'id',
	'',
	'',
	'id',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (4039,
	4000);
INSERT INTO O_BATTR
	VALUES (4039,
	4000);
INSERT INTO O_ATTR
	VALUES (4039,
	4000,
	4149,
	'kmPerDegree',
	'',
	'',
	'kmPerDegree',
	0,
	153,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	4000);
INSERT INTO O_OIDA
	VALUES (4149,
	4000,
	0,
	'id');
INSERT INTO O_ID
	VALUES (1,
	4000);
INSERT INTO O_ID
	VALUES (2,
	4000);
INSERT INTO PE_PE
	VALUES (3978,
	1,
	4132,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (3978,
	'GPS',
	1,
	'GPS',
	'Simulates a GPS.',
	0);
INSERT INTO O_TFR
	VALUES (3975,
	3978,
	'initialize',
	'',
	1192,
	0,
	'// The GPS is a singleton instance, so create it if it does not exist.

select any gps from instances of GPS;
if ( empty gps )
  // Create and initialize the singleton instance of the GPS.
  create object instance gps of GPS; gps.id = 1;
  gps.motionSegments = 0;
  
  simulatedGPS::initialize();
  select any simgps from instances of simulatedGPS;
  gps.currentLatitude  = simgps.initialLatitude;
  gps.currentLongitude = simgps.initialLongitude;
end if;
',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (4151,
	3975);
INSERT INTO ACT_ACT
	VALUES (4151,
	'class operation',
	0,
	4152,
	0,
	0,
	'GPS::initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (4152,
	1,
	0,
	0,
	'',
	'',
	'',
	4,
	1,
	3,
	34,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4151,
	0);
INSERT INTO ACT_SMT
	VALUES (4153,
	4152,
	4154,
	3,
	1,
	'GPS::initialize line: 3');
INSERT INTO ACT_FIO
	VALUES (4153,
	4155,
	1,
	'any',
	3978,
	3,
	34);
INSERT INTO ACT_SMT
	VALUES (4154,
	4152,
	0,
	4,
	1,
	'GPS::initialize line: 4');
INSERT INTO ACT_IF
	VALUES (4154,
	4156,
	4157,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4158,
	0,
	0,
	4,
	12,
	14,
	0,
	0,
	0,
	0,
	1309,
	4152);
INSERT INTO V_IRF
	VALUES (4158,
	4155);
INSERT INTO V_VAL
	VALUES (4157,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	4152);
INSERT INTO V_UNY
	VALUES (4157,
	4158,
	'empty');
INSERT INTO V_VAR
	VALUES (4155,
	4152,
	'gps',
	1,
	1309);
INSERT INTO V_INT
	VALUES (4155,
	0,
	3978);
INSERT INTO ACT_BLK
	VALUES (4156,
	1,
	0,
	0,
	'simulatedGPS',
	'',
	'',
	12,
	3,
	10,
	39,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4151,
	0);
INSERT INTO ACT_SMT
	VALUES (4159,
	4156,
	4160,
	6,
	3,
	'GPS::initialize line: 6');
INSERT INTO ACT_CR
	VALUES (4159,
	4155,
	0,
	3978,
	6,
	33);
INSERT INTO ACT_SMT
	VALUES (4160,
	4156,
	4161,
	6,
	38,
	'GPS::initialize line: 6');
INSERT INTO ACT_AI
	VALUES (4160,
	4162,
	4163,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4161,
	4156,
	4164,
	7,
	3,
	'GPS::initialize line: 7');
INSERT INTO ACT_AI
	VALUES (4161,
	4165,
	4166,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4164,
	4156,
	4167,
	9,
	3,
	'GPS::initialize line: 9');
INSERT INTO ACT_TFM
	VALUES (4164,
	4168,
	0,
	9,
	17,
	9,
	3);
INSERT INTO ACT_SMT
	VALUES (4167,
	4156,
	4169,
	10,
	3,
	'GPS::initialize line: 10');
INSERT INTO ACT_FIO
	VALUES (4167,
	4170,
	1,
	'any',
	4171,
	10,
	39);
INSERT INTO ACT_SMT
	VALUES (4169,
	4156,
	4172,
	11,
	3,
	'GPS::initialize line: 11');
INSERT INTO ACT_AI
	VALUES (4169,
	4173,
	4174,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4172,
	4156,
	0,
	12,
	3,
	'GPS::initialize line: 12');
INSERT INTO ACT_AI
	VALUES (4172,
	4175,
	4176,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4177,
	1,
	0,
	6,
	38,
	40,
	0,
	0,
	0,
	0,
	1309,
	4156);
INSERT INTO V_IRF
	VALUES (4177,
	4155);
INSERT INTO V_VAL
	VALUES (4163,
	1,
	0,
	6,
	42,
	43,
	0,
	0,
	0,
	0,
	160,
	4156);
INSERT INTO V_AVL
	VALUES (4163,
	4177,
	3978,
	4178);
INSERT INTO V_VAL
	VALUES (4162,
	0,
	0,
	6,
	47,
	47,
	0,
	0,
	0,
	0,
	160,
	4156);
INSERT INTO V_LIN
	VALUES (4162,
	'1');
INSERT INTO V_VAL
	VALUES (4179,
	1,
	0,
	7,
	3,
	5,
	0,
	0,
	0,
	0,
	1309,
	4156);
INSERT INTO V_IRF
	VALUES (4179,
	4155);
INSERT INTO V_VAL
	VALUES (4166,
	1,
	0,
	7,
	7,
	20,
	0,
	0,
	0,
	0,
	160,
	4156);
INSERT INTO V_AVL
	VALUES (4166,
	4179,
	3978,
	4180);
INSERT INTO V_VAL
	VALUES (4165,
	0,
	0,
	7,
	24,
	24,
	0,
	0,
	0,
	0,
	160,
	4156);
INSERT INTO V_LIN
	VALUES (4165,
	'0');
INSERT INTO V_VAL
	VALUES (4181,
	1,
	0,
	11,
	3,
	5,
	0,
	0,
	0,
	0,
	1309,
	4156);
INSERT INTO V_IRF
	VALUES (4181,
	4155);
INSERT INTO V_VAL
	VALUES (4174,
	1,
	0,
	11,
	7,
	21,
	0,
	0,
	0,
	0,
	153,
	4156);
INSERT INTO V_AVL
	VALUES (4174,
	4181,
	3978,
	3985);
INSERT INTO V_VAL
	VALUES (4182,
	0,
	0,
	11,
	26,
	31,
	0,
	0,
	0,
	0,
	1309,
	4156);
INSERT INTO V_IRF
	VALUES (4182,
	4170);
INSERT INTO V_VAL
	VALUES (4173,
	0,
	0,
	11,
	33,
	47,
	0,
	0,
	0,
	0,
	153,
	4156);
INSERT INTO V_AVL
	VALUES (4173,
	4182,
	4171,
	4183);
INSERT INTO V_VAL
	VALUES (4184,
	1,
	0,
	12,
	3,
	5,
	0,
	0,
	0,
	0,
	1309,
	4156);
INSERT INTO V_IRF
	VALUES (4184,
	4155);
INSERT INTO V_VAL
	VALUES (4176,
	1,
	0,
	12,
	7,
	22,
	0,
	0,
	0,
	0,
	153,
	4156);
INSERT INTO V_AVL
	VALUES (4176,
	4184,
	3978,
	3987);
INSERT INTO V_VAL
	VALUES (4185,
	0,
	0,
	12,
	26,
	31,
	0,
	0,
	0,
	0,
	1309,
	4156);
INSERT INTO V_IRF
	VALUES (4185,
	4170);
INSERT INTO V_VAL
	VALUES (4175,
	0,
	0,
	12,
	33,
	48,
	0,
	0,
	0,
	0,
	153,
	4156);
INSERT INTO V_AVL
	VALUES (4175,
	4185,
	4171,
	4186);
INSERT INTO V_VAR
	VALUES (4170,
	4156,
	'simgps',
	1,
	1309);
INSERT INTO V_INT
	VALUES (4170,
	0,
	4171);
INSERT INTO O_NBATTR
	VALUES (4187,
	3978);
INSERT INTO O_BATTR
	VALUES (4187,
	3978);
INSERT INTO O_ATTR
	VALUES (4187,
	3978,
	4180,
	'timer',
	'Handle for underlying timer mechanism enabling the generation 
of delayed events that drive the GPS simulator.',
	'',
	'timer',
	0,
	1272,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3985,
	3978);
INSERT INTO O_BATTR
	VALUES (3985,
	3978);
INSERT INTO O_ATTR
	VALUES (3985,
	3978,
	4178,
	'currentLatitude',
	'Current latitude, expressed in decimal degrees, of the simulated GPS.',
	'',
	'currentLatitude',
	0,
	153,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (3987,
	3978);
INSERT INTO O_BATTR
	VALUES (3987,
	3978);
INSERT INTO O_ATTR
	VALUES (3987,
	3978,
	3985,
	'currentLongitude',
	'Current longitude, expressed in decimal degrees, of the simulated GPS.',
	'',
	'currentLongitude',
	0,
	153,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (4180,
	3978);
INSERT INTO O_BATTR
	VALUES (4180,
	3978);
INSERT INTO O_ATTR
	VALUES (4180,
	3978,
	3987,
	'motionSegments',
	'The number of motion segments simulated by the GPS.',
	'',
	'motionSegments',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (4188,
	3978);
INSERT INTO O_BATTR
	VALUES (4188,
	3978);
INSERT INTO O_ATTR
	VALUES (4188,
	3978,
	4187,
	'current_state',
	'',
	'',
	'current_state',
	0,
	1307,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (4178,
	3978);
INSERT INTO O_BATTR
	VALUES (4178,
	3978);
INSERT INTO O_ATTR
	VALUES (4178,
	3978,
	0,
	'id',
	'',
	'',
	'id',
	0,
	160,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	3978);
INSERT INTO O_OIDA
	VALUES (4178,
	3978,
	0,
	'id');
INSERT INTO O_ID
	VALUES (1,
	3978);
INSERT INTO O_ID
	VALUES (2,
	3978);
INSERT INTO SM_ISM
	VALUES (4189,
	3978);
INSERT INTO SM_SM
	VALUES (4189,
	'',
	0);
INSERT INTO SM_MOORE
	VALUES (4189);
INSERT INTO SM_LEVT
	VALUES (4190,
	4189,
	0);
INSERT INTO SM_SEVT
	VALUES (4190,
	4189,
	0);
INSERT INTO SM_EVT
	VALUES (4190,
	4189,
	0,
	1,
	'tick',
	0,
	'',
	'GPS1',
	'');
INSERT INTO SM_LEVT
	VALUES (4191,
	4189,
	0);
INSERT INTO SM_SEVT
	VALUES (4191,
	4189,
	0);
INSERT INTO SM_EVT
	VALUES (4191,
	4189,
	0,
	4,
	'registeringComplete',
	0,
	'',
	'GPS4',
	'');
INSERT INTO SM_LEVT
	VALUES (4047,
	4189,
	0);
INSERT INTO SM_SEVT
	VALUES (4047,
	4189,
	0);
INSERT INTO SM_EVT
	VALUES (4047,
	4189,
	0,
	10,
	'registerListener',
	0,
	'',
	'GPS10',
	'');
INSERT INTO SM_LEVT
	VALUES (4054,
	4189,
	0);
INSERT INTO SM_SEVT
	VALUES (4054,
	4189,
	0);
INSERT INTO SM_EVT
	VALUES (4054,
	4189,
	0,
	11,
	'unregisterListener',
	0,
	'',
	'GPS11',
	'');
INSERT INTO SM_LEVT
	VALUES (4192,
	4189,
	0);
INSERT INTO SM_SEVT
	VALUES (4192,
	4189,
	0);
INSERT INTO SM_EVT
	VALUES (4192,
	4189,
	0,
	12,
	'unregisterComplete',
	0,
	'',
	'GPS12',
	'');
INSERT INTO SM_STATE
	VALUES (4193,
	4189,
	0,
	'idle',
	1,
	0);
INSERT INTO SM_CH
	VALUES (4193,
	4190,
	4189,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (4193,
	4190,
	4189,
	0);
INSERT INTO SM_CH
	VALUES (4193,
	4191,
	4189,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (4193,
	4191,
	4189,
	0);
INSERT INTO SM_SEME
	VALUES (4193,
	4047,
	4189,
	0);
INSERT INTO SM_CH
	VALUES (4193,
	4054,
	4189,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (4193,
	4054,
	4189,
	0);
INSERT INTO SM_CH
	VALUES (4193,
	4192,
	4189,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (4193,
	4192,
	4189,
	0);
INSERT INTO SM_MOAH
	VALUES (4194,
	4189,
	4193);
INSERT INTO SM_AH
	VALUES (4194,
	4189);
INSERT INTO SM_ACT
	VALUES (4194,
	4189,
	1,
	'LOG::LogInfo( message:"Locating::GPS::Idle" );',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (4195,
	4189,
	4194);
INSERT INTO ACT_ACT
	VALUES (4195,
	'state',
	0,
	4196,
	0,
	0,
	'GPS::idle',
	0);
INSERT INTO ACT_BLK
	VALUES (4196,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	1,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4195,
	0);
INSERT INTO ACT_SMT
	VALUES (4197,
	4196,
	0,
	1,
	1,
	'GPS::idle line: 1');
INSERT INTO ACT_BRG
	VALUES (4197,
	1206,
	1,
	6,
	1,
	1);
INSERT INTO V_VAL
	VALUES (4198,
	0,
	0,
	1,
	23,
	42,
	0,
	0,
	0,
	0,
	1199,
	4196);
INSERT INTO V_LST
	VALUES (4198,
	'Locating::GPS::Idle');
INSERT INTO V_PAR
	VALUES (4198,
	4197,
	0,
	'message',
	0,
	1,
	15);
INSERT INTO SM_STATE
	VALUES (4199,
	4189,
	0,
	'locating',
	2,
	0);
INSERT INTO SM_SEME
	VALUES (4199,
	4190,
	4189,
	0);
INSERT INTO SM_CH
	VALUES (4199,
	4191,
	4189,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (4199,
	4191,
	4189,
	0);
INSERT INTO SM_CH
	VALUES (4199,
	4047,
	4189,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (4199,
	4047,
	4189,
	0);
INSERT INTO SM_SEME
	VALUES (4199,
	4054,
	4189,
	0);
INSERT INTO SM_CH
	VALUES (4199,
	4192,
	4189,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (4199,
	4192,
	4189,
	0);
INSERT INTO SM_MOAH
	VALUES (4200,
	4189,
	4199);
INSERT INTO SM_AH
	VALUES (4200,
	4189);
INSERT INTO SM_ACT
	VALUES (4200,
	4189,
	1,
	'// Simulate movement.
simulatedGPS::initialize();
select any simgps from instances of simulatedGPS;
if ( (self.motionSegments % 3) == 0 )
  self.currentLongitude = self.currentLongitude + (simgps.longitudeIncrement * 2);
  self.currentLatitude = self.currentLatitude + simgps.latitudeIncrement;
elif ( (self.motionSegments %5) == 0 )
  self.currentLongitude = self.currentLongitude + simgps.longitudeIncrement;
  self.currentLatitude = self.currentLatitude + (simgps.latitudeIncrement * 3);
else
  self.currentLongitude = self.currentLongitude + simgps.longitudeIncrement;
  self.currentLatitude = self.currentLatitude + simgps.latitudeIncrement;
end if;
// Increment simulated motion segment count.
self.motionSegments = self.motionSegments + 1;
',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (4201,
	4189,
	4200);
INSERT INTO ACT_ACT
	VALUES (4201,
	'state',
	0,
	4202,
	0,
	0,
	'GPS::locating',
	0);
INSERT INTO ACT_BLK
	VALUES (4202,
	1,
	0,
	0,
	'simulatedGPS',
	'',
	'',
	15,
	1,
	3,
	37,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4201,
	0);
INSERT INTO ACT_SMT
	VALUES (4203,
	4202,
	4204,
	2,
	1,
	'GPS::locating line: 2');
INSERT INTO ACT_TFM
	VALUES (4203,
	4168,
	0,
	2,
	15,
	2,
	1);
INSERT INTO ACT_SMT
	VALUES (4204,
	4202,
	4205,
	3,
	1,
	'GPS::locating line: 3');
INSERT INTO ACT_FIO
	VALUES (4204,
	4206,
	1,
	'any',
	4171,
	3,
	37);
INSERT INTO ACT_SMT
	VALUES (4205,
	4202,
	4207,
	4,
	1,
	'GPS::locating line: 4');
INSERT INTO ACT_IF
	VALUES (4205,
	4208,
	4209,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4210,
	4202,
	0,
	7,
	1,
	'GPS::locating line: 7');
INSERT INTO ACT_EL
	VALUES (4210,
	4211,
	4212,
	4205);
INSERT INTO ACT_SMT
	VALUES (4213,
	4202,
	0,
	10,
	1,
	'GPS::locating line: 10');
INSERT INTO ACT_E
	VALUES (4213,
	4214,
	4205);
INSERT INTO ACT_SMT
	VALUES (4207,
	4202,
	0,
	15,
	1,
	'GPS::locating line: 15');
INSERT INTO ACT_AI
	VALUES (4207,
	4215,
	4216,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4217,
	0,
	0,
	4,
	7,
	10,
	0,
	0,
	0,
	0,
	1309,
	4202);
INSERT INTO V_IRF
	VALUES (4217,
	4218);
INSERT INTO V_VAL
	VALUES (4219,
	0,
	0,
	4,
	12,
	25,
	0,
	0,
	0,
	0,
	160,
	4202);
INSERT INTO V_AVL
	VALUES (4219,
	4217,
	3978,
	4180);
INSERT INTO V_VAL
	VALUES (4220,
	0,
	0,
	4,
	12,
	29,
	0,
	0,
	0,
	0,
	160,
	4202);
INSERT INTO V_BIN
	VALUES (4220,
	4221,
	4219,
	'%');
INSERT INTO V_VAL
	VALUES (4221,
	0,
	0,
	4,
	29,
	29,
	0,
	0,
	0,
	0,
	160,
	4202);
INSERT INTO V_LIN
	VALUES (4221,
	'3');
INSERT INTO V_VAL
	VALUES (4209,
	0,
	0,
	4,
	12,
	35,
	0,
	0,
	0,
	0,
	125,
	4202);
INSERT INTO V_BIN
	VALUES (4209,
	4222,
	4220,
	'==');
INSERT INTO V_VAL
	VALUES (4222,
	0,
	0,
	4,
	35,
	35,
	0,
	0,
	0,
	0,
	160,
	4202);
INSERT INTO V_LIN
	VALUES (4222,
	'0');
INSERT INTO V_VAL
	VALUES (4223,
	0,
	0,
	7,
	9,
	12,
	0,
	0,
	0,
	0,
	1309,
	4202);
INSERT INTO V_IRF
	VALUES (4223,
	4218);
INSERT INTO V_VAL
	VALUES (4224,
	0,
	0,
	7,
	14,
	27,
	0,
	0,
	0,
	0,
	160,
	4202);
INSERT INTO V_AVL
	VALUES (4224,
	4223,
	3978,
	4180);
INSERT INTO V_VAL
	VALUES (4225,
	0,
	0,
	7,
	14,
	30,
	0,
	0,
	0,
	0,
	160,
	4202);
INSERT INTO V_BIN
	VALUES (4225,
	4226,
	4224,
	'%');
INSERT INTO V_VAL
	VALUES (4226,
	0,
	0,
	7,
	30,
	30,
	0,
	0,
	0,
	0,
	160,
	4202);
INSERT INTO V_LIN
	VALUES (4226,
	'5');
INSERT INTO V_VAL
	VALUES (4212,
	0,
	0,
	7,
	14,
	36,
	0,
	0,
	0,
	0,
	125,
	4202);
INSERT INTO V_BIN
	VALUES (4212,
	4227,
	4225,
	'==');
INSERT INTO V_VAL
	VALUES (4227,
	0,
	0,
	7,
	36,
	36,
	0,
	0,
	0,
	0,
	160,
	4202);
INSERT INTO V_LIN
	VALUES (4227,
	'0');
INSERT INTO V_VAL
	VALUES (4228,
	1,
	0,
	15,
	1,
	4,
	0,
	0,
	0,
	0,
	1309,
	4202);
INSERT INTO V_IRF
	VALUES (4228,
	4218);
INSERT INTO V_VAL
	VALUES (4216,
	1,
	0,
	15,
	6,
	19,
	0,
	0,
	0,
	0,
	160,
	4202);
INSERT INTO V_AVL
	VALUES (4216,
	4228,
	3978,
	4180);
INSERT INTO V_VAL
	VALUES (4229,
	0,
	0,
	15,
	23,
	26,
	0,
	0,
	0,
	0,
	1309,
	4202);
INSERT INTO V_IRF
	VALUES (4229,
	4218);
INSERT INTO V_VAL
	VALUES (4230,
	0,
	0,
	15,
	28,
	41,
	0,
	0,
	0,
	0,
	160,
	4202);
INSERT INTO V_AVL
	VALUES (4230,
	4229,
	3978,
	4180);
INSERT INTO V_VAL
	VALUES (4215,
	0,
	0,
	15,
	28,
	45,
	0,
	0,
	0,
	0,
	160,
	4202);
INSERT INTO V_BIN
	VALUES (4215,
	4231,
	4230,
	'+');
INSERT INTO V_VAL
	VALUES (4231,
	0,
	0,
	15,
	45,
	45,
	0,
	0,
	0,
	0,
	160,
	4202);
INSERT INTO V_LIN
	VALUES (4231,
	'1');
INSERT INTO V_VAR
	VALUES (4206,
	4202,
	'simgps',
	1,
	1309);
INSERT INTO V_INT
	VALUES (4206,
	0,
	4171);
INSERT INTO V_VAR
	VALUES (4218,
	4202,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (4218,
	0,
	3978);
INSERT INTO ACT_BLK
	VALUES (4208,
	0,
	0,
	0,
	'',
	'',
	'',
	6,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4201,
	0);
INSERT INTO ACT_SMT
	VALUES (4232,
	4208,
	4233,
	5,
	3,
	'GPS::locating line: 5');
INSERT INTO ACT_AI
	VALUES (4232,
	4234,
	4235,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4233,
	4208,
	0,
	6,
	3,
	'GPS::locating line: 6');
INSERT INTO ACT_AI
	VALUES (4233,
	4236,
	4237,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4238,
	1,
	0,
	5,
	3,
	6,
	0,
	0,
	0,
	0,
	1309,
	4208);
INSERT INTO V_IRF
	VALUES (4238,
	4218);
INSERT INTO V_VAL
	VALUES (4235,
	1,
	0,
	5,
	8,
	23,
	0,
	0,
	0,
	0,
	153,
	4208);
INSERT INTO V_AVL
	VALUES (4235,
	4238,
	3978,
	3987);
INSERT INTO V_VAL
	VALUES (4239,
	0,
	0,
	5,
	27,
	30,
	0,
	0,
	0,
	0,
	1309,
	4208);
INSERT INTO V_IRF
	VALUES (4239,
	4218);
INSERT INTO V_VAL
	VALUES (4240,
	0,
	0,
	5,
	32,
	47,
	0,
	0,
	0,
	0,
	153,
	4208);
INSERT INTO V_AVL
	VALUES (4240,
	4239,
	3978,
	3987);
INSERT INTO V_VAL
	VALUES (4234,
	0,
	0,
	5,
	32,
	80,
	0,
	0,
	0,
	0,
	153,
	4208);
INSERT INTO V_BIN
	VALUES (4234,
	4241,
	4240,
	'+');
INSERT INTO V_VAL
	VALUES (4242,
	0,
	0,
	5,
	52,
	57,
	0,
	0,
	0,
	0,
	1309,
	4208);
INSERT INTO V_IRF
	VALUES (4242,
	4206);
INSERT INTO V_VAL
	VALUES (4243,
	0,
	0,
	5,
	59,
	76,
	0,
	0,
	0,
	0,
	153,
	4208);
INSERT INTO V_AVL
	VALUES (4243,
	4242,
	4171,
	4244);
INSERT INTO V_VAL
	VALUES (4241,
	0,
	0,
	5,
	59,
	80,
	0,
	0,
	0,
	0,
	153,
	4208);
INSERT INTO V_BIN
	VALUES (4241,
	4245,
	4243,
	'*');
INSERT INTO V_VAL
	VALUES (4245,
	0,
	0,
	5,
	80,
	80,
	0,
	0,
	0,
	0,
	160,
	4208);
INSERT INTO V_LIN
	VALUES (4245,
	'2');
INSERT INTO V_VAL
	VALUES (4246,
	1,
	0,
	6,
	3,
	6,
	0,
	0,
	0,
	0,
	1309,
	4208);
INSERT INTO V_IRF
	VALUES (4246,
	4218);
INSERT INTO V_VAL
	VALUES (4237,
	1,
	0,
	6,
	8,
	22,
	0,
	0,
	0,
	0,
	153,
	4208);
INSERT INTO V_AVL
	VALUES (4237,
	4246,
	3978,
	3985);
INSERT INTO V_VAL
	VALUES (4247,
	0,
	0,
	6,
	26,
	29,
	0,
	0,
	0,
	0,
	1309,
	4208);
INSERT INTO V_IRF
	VALUES (4247,
	4218);
INSERT INTO V_VAL
	VALUES (4248,
	0,
	0,
	6,
	31,
	45,
	0,
	0,
	0,
	0,
	153,
	4208);
INSERT INTO V_AVL
	VALUES (4248,
	4247,
	3978,
	3985);
INSERT INTO V_VAL
	VALUES (4236,
	0,
	0,
	6,
	31,
	72,
	0,
	0,
	0,
	0,
	153,
	4208);
INSERT INTO V_BIN
	VALUES (4236,
	4249,
	4248,
	'+');
INSERT INTO V_VAL
	VALUES (4250,
	0,
	0,
	6,
	49,
	54,
	0,
	0,
	0,
	0,
	1309,
	4208);
INSERT INTO V_IRF
	VALUES (4250,
	4206);
INSERT INTO V_VAL
	VALUES (4249,
	0,
	0,
	6,
	56,
	72,
	0,
	0,
	0,
	0,
	153,
	4208);
INSERT INTO V_AVL
	VALUES (4249,
	4250,
	4171,
	4251);
INSERT INTO ACT_BLK
	VALUES (4211,
	0,
	0,
	0,
	'',
	'',
	'',
	9,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4201,
	0);
INSERT INTO ACT_SMT
	VALUES (4252,
	4211,
	4253,
	8,
	3,
	'GPS::locating line: 8');
INSERT INTO ACT_AI
	VALUES (4252,
	4254,
	4255,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4253,
	4211,
	0,
	9,
	3,
	'GPS::locating line: 9');
INSERT INTO ACT_AI
	VALUES (4253,
	4256,
	4257,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4258,
	1,
	0,
	8,
	3,
	6,
	0,
	0,
	0,
	0,
	1309,
	4211);
INSERT INTO V_IRF
	VALUES (4258,
	4218);
INSERT INTO V_VAL
	VALUES (4255,
	1,
	0,
	8,
	8,
	23,
	0,
	0,
	0,
	0,
	153,
	4211);
INSERT INTO V_AVL
	VALUES (4255,
	4258,
	3978,
	3987);
INSERT INTO V_VAL
	VALUES (4259,
	0,
	0,
	8,
	27,
	30,
	0,
	0,
	0,
	0,
	1309,
	4211);
INSERT INTO V_IRF
	VALUES (4259,
	4218);
INSERT INTO V_VAL
	VALUES (4260,
	0,
	0,
	8,
	32,
	47,
	0,
	0,
	0,
	0,
	153,
	4211);
INSERT INTO V_AVL
	VALUES (4260,
	4259,
	3978,
	3987);
INSERT INTO V_VAL
	VALUES (4254,
	0,
	0,
	8,
	32,
	75,
	0,
	0,
	0,
	0,
	153,
	4211);
INSERT INTO V_BIN
	VALUES (4254,
	4261,
	4260,
	'+');
INSERT INTO V_VAL
	VALUES (4262,
	0,
	0,
	8,
	51,
	56,
	0,
	0,
	0,
	0,
	1309,
	4211);
INSERT INTO V_IRF
	VALUES (4262,
	4206);
INSERT INTO V_VAL
	VALUES (4261,
	0,
	0,
	8,
	58,
	75,
	0,
	0,
	0,
	0,
	153,
	4211);
INSERT INTO V_AVL
	VALUES (4261,
	4262,
	4171,
	4244);
INSERT INTO V_VAL
	VALUES (4263,
	1,
	0,
	9,
	3,
	6,
	0,
	0,
	0,
	0,
	1309,
	4211);
INSERT INTO V_IRF
	VALUES (4263,
	4218);
INSERT INTO V_VAL
	VALUES (4257,
	1,
	0,
	9,
	8,
	22,
	0,
	0,
	0,
	0,
	153,
	4211);
INSERT INTO V_AVL
	VALUES (4257,
	4263,
	3978,
	3985);
INSERT INTO V_VAL
	VALUES (4264,
	0,
	0,
	9,
	26,
	29,
	0,
	0,
	0,
	0,
	1309,
	4211);
INSERT INTO V_IRF
	VALUES (4264,
	4218);
INSERT INTO V_VAL
	VALUES (4265,
	0,
	0,
	9,
	31,
	45,
	0,
	0,
	0,
	0,
	153,
	4211);
INSERT INTO V_AVL
	VALUES (4265,
	4264,
	3978,
	3985);
INSERT INTO V_VAL
	VALUES (4256,
	0,
	0,
	9,
	31,
	77,
	0,
	0,
	0,
	0,
	153,
	4211);
INSERT INTO V_BIN
	VALUES (4256,
	4266,
	4265,
	'+');
INSERT INTO V_VAL
	VALUES (4267,
	0,
	0,
	9,
	50,
	55,
	0,
	0,
	0,
	0,
	1309,
	4211);
INSERT INTO V_IRF
	VALUES (4267,
	4206);
INSERT INTO V_VAL
	VALUES (4268,
	0,
	0,
	9,
	57,
	73,
	0,
	0,
	0,
	0,
	153,
	4211);
INSERT INTO V_AVL
	VALUES (4268,
	4267,
	4171,
	4251);
INSERT INTO V_VAL
	VALUES (4266,
	0,
	0,
	9,
	57,
	77,
	0,
	0,
	0,
	0,
	153,
	4211);
INSERT INTO V_BIN
	VALUES (4266,
	4269,
	4268,
	'*');
INSERT INTO V_VAL
	VALUES (4269,
	0,
	0,
	9,
	77,
	77,
	0,
	0,
	0,
	0,
	160,
	4211);
INSERT INTO V_LIN
	VALUES (4269,
	'3');
INSERT INTO ACT_BLK
	VALUES (4214,
	0,
	0,
	0,
	'',
	'',
	'',
	12,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4201,
	0);
INSERT INTO ACT_SMT
	VALUES (4270,
	4214,
	4271,
	11,
	3,
	'GPS::locating line: 11');
INSERT INTO ACT_AI
	VALUES (4270,
	4272,
	4273,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4271,
	4214,
	0,
	12,
	3,
	'GPS::locating line: 12');
INSERT INTO ACT_AI
	VALUES (4271,
	4274,
	4275,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4276,
	1,
	0,
	11,
	3,
	6,
	0,
	0,
	0,
	0,
	1309,
	4214);
INSERT INTO V_IRF
	VALUES (4276,
	4218);
INSERT INTO V_VAL
	VALUES (4273,
	1,
	0,
	11,
	8,
	23,
	0,
	0,
	0,
	0,
	153,
	4214);
INSERT INTO V_AVL
	VALUES (4273,
	4276,
	3978,
	3987);
INSERT INTO V_VAL
	VALUES (4277,
	0,
	0,
	11,
	27,
	30,
	0,
	0,
	0,
	0,
	1309,
	4214);
INSERT INTO V_IRF
	VALUES (4277,
	4218);
INSERT INTO V_VAL
	VALUES (4278,
	0,
	0,
	11,
	32,
	47,
	0,
	0,
	0,
	0,
	153,
	4214);
INSERT INTO V_AVL
	VALUES (4278,
	4277,
	3978,
	3987);
INSERT INTO V_VAL
	VALUES (4272,
	0,
	0,
	11,
	32,
	75,
	0,
	0,
	0,
	0,
	153,
	4214);
INSERT INTO V_BIN
	VALUES (4272,
	4279,
	4278,
	'+');
INSERT INTO V_VAL
	VALUES (4280,
	0,
	0,
	11,
	51,
	56,
	0,
	0,
	0,
	0,
	1309,
	4214);
INSERT INTO V_IRF
	VALUES (4280,
	4206);
INSERT INTO V_VAL
	VALUES (4279,
	0,
	0,
	11,
	58,
	75,
	0,
	0,
	0,
	0,
	153,
	4214);
INSERT INTO V_AVL
	VALUES (4279,
	4280,
	4171,
	4244);
INSERT INTO V_VAL
	VALUES (4281,
	1,
	0,
	12,
	3,
	6,
	0,
	0,
	0,
	0,
	1309,
	4214);
INSERT INTO V_IRF
	VALUES (4281,
	4218);
INSERT INTO V_VAL
	VALUES (4275,
	1,
	0,
	12,
	8,
	22,
	0,
	0,
	0,
	0,
	153,
	4214);
INSERT INTO V_AVL
	VALUES (4275,
	4281,
	3978,
	3985);
INSERT INTO V_VAL
	VALUES (4282,
	0,
	0,
	12,
	26,
	29,
	0,
	0,
	0,
	0,
	1309,
	4214);
INSERT INTO V_IRF
	VALUES (4282,
	4218);
INSERT INTO V_VAL
	VALUES (4283,
	0,
	0,
	12,
	31,
	45,
	0,
	0,
	0,
	0,
	153,
	4214);
INSERT INTO V_AVL
	VALUES (4283,
	4282,
	3978,
	3985);
INSERT INTO V_VAL
	VALUES (4274,
	0,
	0,
	12,
	31,
	72,
	0,
	0,
	0,
	0,
	153,
	4214);
INSERT INTO V_BIN
	VALUES (4274,
	4284,
	4283,
	'+');
INSERT INTO V_VAL
	VALUES (4285,
	0,
	0,
	12,
	49,
	54,
	0,
	0,
	0,
	0,
	1309,
	4214);
INSERT INTO V_IRF
	VALUES (4285,
	4206);
INSERT INTO V_VAL
	VALUES (4284,
	0,
	0,
	12,
	56,
	72,
	0,
	0,
	0,
	0,
	153,
	4214);
INSERT INTO V_AVL
	VALUES (4284,
	4285,
	4171,
	4251);
INSERT INTO SM_STATE
	VALUES (4286,
	4189,
	0,
	'registeringListener',
	3,
	0);
INSERT INTO SM_CH
	VALUES (4286,
	4190,
	4189,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (4286,
	4190,
	4189,
	0);
INSERT INTO SM_SEME
	VALUES (4286,
	4191,
	4189,
	0);
INSERT INTO SM_CH
	VALUES (4286,
	4047,
	4189,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (4286,
	4047,
	4189,
	0);
INSERT INTO SM_CH
	VALUES (4286,
	4054,
	4189,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (4286,
	4054,
	4189,
	0);
INSERT INTO SM_CH
	VALUES (4286,
	4192,
	4189,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (4286,
	4192,
	4189,
	0);
INSERT INTO SM_MOAH
	VALUES (4287,
	4189,
	4286);
INSERT INTO SM_AH
	VALUES (4287,
	4189);
INSERT INTO SM_ACT
	VALUES (4287,
	4189,
	1,
	'// Activate the simulated GPS (this creates the GPS instance, if needed).
// Establish recurring timer for periodic position updates.
simulatedGPS::initialize();
select any simgps from instances of simulatedGPS;
create event instance tick of GPS1:tick() to self;
self.timer = TIM::timer_start_recurring( event_inst: tick, microseconds: simgps.updatePeriod );
LOG::LogInfo(message: "Location listener registered.");  

generate GPS4:registeringComplete() to self;',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (4288,
	4189,
	4287);
INSERT INTO ACT_ACT
	VALUES (4288,
	'state',
	0,
	4289,
	0,
	0,
	'GPS::registeringListener',
	0);
INSERT INTO ACT_BLK
	VALUES (4289,
	1,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	9,
	1,
	7,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4288,
	0);
INSERT INTO ACT_SMT
	VALUES (4290,
	4289,
	4291,
	3,
	1,
	'GPS::registeringListener line: 3');
INSERT INTO ACT_TFM
	VALUES (4290,
	4168,
	0,
	3,
	15,
	3,
	1);
INSERT INTO ACT_SMT
	VALUES (4291,
	4289,
	4292,
	4,
	1,
	'GPS::registeringListener line: 4');
INSERT INTO ACT_FIO
	VALUES (4291,
	4293,
	1,
	'any',
	4171,
	4,
	37);
INSERT INTO ACT_SMT
	VALUES (4292,
	4289,
	4294,
	5,
	1,
	'GPS::registeringListener line: 5');
INSERT INTO E_ESS
	VALUES (4292,
	1,
	0,
	5,
	31,
	5,
	36,
	4,
	37,
	0,
	0,
	0,
	0);
INSERT INTO E_CES
	VALUES (4292,
	1,
	4295);
INSERT INTO E_CSME
	VALUES (4292,
	4190);
INSERT INTO E_CEI
	VALUES (4292,
	4296);
INSERT INTO ACT_SMT
	VALUES (4294,
	4289,
	4297,
	6,
	1,
	'GPS::registeringListener line: 6');
INSERT INTO ACT_AI
	VALUES (4294,
	4298,
	4299,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4297,
	4289,
	4300,
	7,
	1,
	'GPS::registeringListener line: 7');
INSERT INTO ACT_BRG
	VALUES (4297,
	1206,
	7,
	6,
	7,
	1);
INSERT INTO ACT_SMT
	VALUES (4300,
	4289,
	0,
	9,
	1,
	'GPS::registeringListener line: 9');
INSERT INTO E_ESS
	VALUES (4300,
	1,
	0,
	9,
	10,
	9,
	15,
	7,
	1,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (4300);
INSERT INTO E_GSME
	VALUES (4300,
	4191);
INSERT INTO E_GEN
	VALUES (4300,
	4296);
INSERT INTO V_VAL
	VALUES (4301,
	1,
	0,
	6,
	1,
	4,
	0,
	0,
	0,
	0,
	1309,
	4289);
INSERT INTO V_IRF
	VALUES (4301,
	4296);
INSERT INTO V_VAL
	VALUES (4299,
	1,
	0,
	6,
	6,
	10,
	0,
	0,
	0,
	0,
	1272,
	4289);
INSERT INTO V_AVL
	VALUES (4299,
	4301,
	3978,
	4187);
INSERT INTO V_VAL
	VALUES (4298,
	0,
	0,
	6,
	19,
	-1,
	6,
	42,
	6,
	60,
	1272,
	4289);
INSERT INTO V_BRV
	VALUES (4298,
	1278,
	1,
	6,
	14);
INSERT INTO V_VAL
	VALUES (4302,
	0,
	0,
	6,
	54,
	57,
	0,
	0,
	0,
	0,
	1275,
	4289);
INSERT INTO V_TVL
	VALUES (4302,
	4295);
INSERT INTO V_PAR
	VALUES (4302,
	0,
	4298,
	'event_inst',
	4303,
	6,
	42);
INSERT INTO V_VAL
	VALUES (4304,
	0,
	0,
	6,
	74,
	79,
	0,
	0,
	0,
	0,
	1309,
	4289);
INSERT INTO V_IRF
	VALUES (4304,
	4293);
INSERT INTO V_VAL
	VALUES (4303,
	0,
	0,
	6,
	81,
	92,
	0,
	0,
	0,
	0,
	160,
	4289);
INSERT INTO V_AVL
	VALUES (4303,
	4304,
	4171,
	4305);
INSERT INTO V_PAR
	VALUES (4303,
	0,
	4298,
	'microseconds',
	0,
	6,
	60);
INSERT INTO V_VAL
	VALUES (4306,
	0,
	0,
	7,
	23,
	52,
	0,
	0,
	0,
	0,
	1199,
	4289);
INSERT INTO V_LST
	VALUES (4306,
	'Location listener registered.');
INSERT INTO V_PAR
	VALUES (4306,
	4297,
	0,
	'message',
	0,
	7,
	14);
INSERT INTO V_VAR
	VALUES (4293,
	4289,
	'simgps',
	1,
	1309);
INSERT INTO V_INT
	VALUES (4293,
	0,
	4171);
INSERT INTO V_VAR
	VALUES (4295,
	4289,
	'tick',
	1,
	1275);
INSERT INTO V_TRN
	VALUES (4295,
	0,
	'');
INSERT INTO V_VAR
	VALUES (4296,
	4289,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (4296,
	0,
	3978);
INSERT INTO SM_STATE
	VALUES (4307,
	4189,
	0,
	'unregistering',
	5,
	0);
INSERT INTO SM_CH
	VALUES (4307,
	4190,
	4189,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (4307,
	4190,
	4189,
	0);
INSERT INTO SM_CH
	VALUES (4307,
	4191,
	4189,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (4307,
	4191,
	4189,
	0);
INSERT INTO SM_CH
	VALUES (4307,
	4047,
	4189,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (4307,
	4047,
	4189,
	0);
INSERT INTO SM_CH
	VALUES (4307,
	4054,
	4189,
	0,
	'');
INSERT INTO SM_SEME
	VALUES (4307,
	4054,
	4189,
	0);
INSERT INTO SM_SEME
	VALUES (4307,
	4192,
	4189,
	0);
INSERT INTO SM_MOAH
	VALUES (4308,
	4189,
	4307);
INSERT INTO SM_AH
	VALUES (4308,
	4189);
INSERT INTO SM_ACT
	VALUES (4308,
	4189,
	1,
	'// Deactivate the timer.
res = TIM::timer_cancel(timer_inst_ref: self.timer);
LOG::LogInfo(message: "Location listener unregistered.");

if ( not res )
  LOG::LogFailure( message: "Location listener: timer_cancel() failed." );
end if;
generate GPS12:unregisterComplete() to self;',
	'',
	0);
INSERT INTO ACT_SAB
	VALUES (4309,
	4189,
	4308);
INSERT INTO ACT_ACT
	VALUES (4309,
	'state',
	0,
	4310,
	0,
	0,
	'GPS::unregistering',
	0);
INSERT INTO ACT_BLK
	VALUES (4310,
	0,
	0,
	0,
	'V_VAR.Var_ID',
	'',
	'',
	8,
	1,
	3,
	1,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4309,
	0);
INSERT INTO ACT_SMT
	VALUES (4311,
	4310,
	4312,
	2,
	1,
	'GPS::unregistering line: 2');
INSERT INTO ACT_AI
	VALUES (4311,
	4313,
	4314,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4312,
	4310,
	4315,
	3,
	1,
	'GPS::unregistering line: 3');
INSERT INTO ACT_BRG
	VALUES (4312,
	1206,
	3,
	6,
	3,
	1);
INSERT INTO ACT_SMT
	VALUES (4315,
	4310,
	4316,
	5,
	1,
	'GPS::unregistering line: 5');
INSERT INTO ACT_IF
	VALUES (4315,
	4317,
	4318,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4316,
	4310,
	0,
	8,
	1,
	'GPS::unregistering line: 8');
INSERT INTO E_ESS
	VALUES (4316,
	1,
	0,
	8,
	10,
	8,
	16,
	3,
	1,
	0,
	0,
	0,
	0);
INSERT INTO E_GES
	VALUES (4316);
INSERT INTO E_GSME
	VALUES (4316,
	4192);
INSERT INTO E_GEN
	VALUES (4316,
	4319);
INSERT INTO V_VAL
	VALUES (4314,
	1,
	1,
	2,
	1,
	3,
	0,
	0,
	0,
	0,
	125,
	4310);
INSERT INTO V_TVL
	VALUES (4314,
	4320);
INSERT INTO V_VAL
	VALUES (4313,
	0,
	0,
	2,
	12,
	-1,
	2,
	25,
	0,
	0,
	125,
	4310);
INSERT INTO V_BRV
	VALUES (4313,
	1297,
	1,
	2,
	7);
INSERT INTO V_VAL
	VALUES (4321,
	0,
	0,
	2,
	41,
	44,
	0,
	0,
	0,
	0,
	1309,
	4310);
INSERT INTO V_IRF
	VALUES (4321,
	4319);
INSERT INTO V_VAL
	VALUES (4322,
	0,
	0,
	2,
	46,
	50,
	0,
	0,
	0,
	0,
	1272,
	4310);
INSERT INTO V_AVL
	VALUES (4322,
	4321,
	3978,
	4187);
INSERT INTO V_PAR
	VALUES (4322,
	0,
	4313,
	'timer_inst_ref',
	0,
	2,
	25);
INSERT INTO V_VAL
	VALUES (4323,
	0,
	0,
	3,
	23,
	54,
	0,
	0,
	0,
	0,
	1199,
	4310);
INSERT INTO V_LST
	VALUES (4323,
	'Location listener unregistered.');
INSERT INTO V_PAR
	VALUES (4323,
	4312,
	0,
	'message',
	0,
	3,
	14);
INSERT INTO V_VAL
	VALUES (4324,
	0,
	0,
	5,
	10,
	12,
	0,
	0,
	0,
	0,
	125,
	4310);
INSERT INTO V_TVL
	VALUES (4324,
	4320);
INSERT INTO V_VAL
	VALUES (4318,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	4310);
INSERT INTO V_UNY
	VALUES (4318,
	4324,
	'not');
INSERT INTO V_VAR
	VALUES (4320,
	4310,
	'res',
	1,
	125);
INSERT INTO V_TRN
	VALUES (4320,
	0,
	'');
INSERT INTO V_VAR
	VALUES (4319,
	4310,
	'self',
	1,
	1309);
INSERT INTO V_INT
	VALUES (4319,
	0,
	3978);
INSERT INTO ACT_BLK
	VALUES (4317,
	0,
	0,
	0,
	'LOG',
	'',
	'',
	6,
	3,
	6,
	3,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4309,
	0);
INSERT INTO ACT_SMT
	VALUES (4325,
	4317,
	0,
	6,
	3,
	'GPS::unregistering line: 6');
INSERT INTO ACT_BRG
	VALUES (4325,
	1202,
	6,
	8,
	6,
	3);
INSERT INTO V_VAL
	VALUES (4326,
	0,
	0,
	6,
	29,
	70,
	0,
	0,
	0,
	0,
	1199,
	4317);
INSERT INTO V_LST
	VALUES (4326,
	'Location listener: timer_cancel() failed.');
INSERT INTO V_PAR
	VALUES (4326,
	4325,
	0,
	'message',
	0,
	6,
	20);
INSERT INTO SM_NSTXN
	VALUES (4327,
	4189,
	4286,
	4191,
	0);
INSERT INTO SM_TAH
	VALUES (4328,
	4189,
	4327);
INSERT INTO SM_AH
	VALUES (4328,
	4189);
INSERT INTO SM_ACT
	VALUES (4328,
	4189,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (4329,
	4189,
	4328);
INSERT INTO ACT_ACT
	VALUES (4329,
	'transition',
	0,
	4330,
	0,
	0,
	'GPS4: registeringComplete',
	0);
INSERT INTO ACT_BLK
	VALUES (4330,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4329,
	0);
INSERT INTO SM_TXN
	VALUES (4327,
	4189,
	4199,
	0);
INSERT INTO SM_NSTXN
	VALUES (4331,
	4189,
	4193,
	4047,
	0);
INSERT INTO SM_TAH
	VALUES (4332,
	4189,
	4331);
INSERT INTO SM_AH
	VALUES (4332,
	4189);
INSERT INTO SM_ACT
	VALUES (4332,
	4189,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (4333,
	4189,
	4332);
INSERT INTO ACT_ACT
	VALUES (4333,
	'transition',
	0,
	4334,
	0,
	0,
	'GPS10: registerListener',
	0);
INSERT INTO ACT_BLK
	VALUES (4334,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4333,
	0);
INSERT INTO SM_TXN
	VALUES (4331,
	4189,
	4286,
	0);
INSERT INTO SM_NSTXN
	VALUES (4335,
	4189,
	4199,
	4054,
	0);
INSERT INTO SM_TAH
	VALUES (4336,
	4189,
	4335);
INSERT INTO SM_AH
	VALUES (4336,
	4189);
INSERT INTO SM_ACT
	VALUES (4336,
	4189,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (4337,
	4189,
	4336);
INSERT INTO ACT_ACT
	VALUES (4337,
	'transition',
	0,
	4338,
	0,
	0,
	'GPS11: unregisterListener',
	0);
INSERT INTO ACT_BLK
	VALUES (4338,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4337,
	0);
INSERT INTO SM_TXN
	VALUES (4335,
	4189,
	4307,
	0);
INSERT INTO SM_NSTXN
	VALUES (4339,
	4189,
	4307,
	4192,
	0);
INSERT INTO SM_TAH
	VALUES (4340,
	4189,
	4339);
INSERT INTO SM_AH
	VALUES (4340,
	4189);
INSERT INTO SM_ACT
	VALUES (4340,
	4189,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (4341,
	4189,
	4340);
INSERT INTO ACT_ACT
	VALUES (4341,
	'transition',
	0,
	4342,
	0,
	0,
	'GPS12: unregisterComplete',
	0);
INSERT INTO ACT_BLK
	VALUES (4342,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4341,
	0);
INSERT INTO SM_TXN
	VALUES (4339,
	4189,
	4193,
	0);
INSERT INTO SM_NSTXN
	VALUES (4343,
	4189,
	4199,
	4190,
	0);
INSERT INTO SM_TAH
	VALUES (4344,
	4189,
	4343);
INSERT INTO SM_AH
	VALUES (4344,
	4189);
INSERT INTO SM_ACT
	VALUES (4344,
	4189,
	1,
	'',
	'',
	0);
INSERT INTO ACT_TAB
	VALUES (4345,
	4189,
	4344);
INSERT INTO ACT_ACT
	VALUES (4345,
	'transition',
	0,
	4346,
	0,
	0,
	'GPS1: tick',
	0);
INSERT INTO ACT_BLK
	VALUES (4346,
	0,
	0,
	0,
	'',
	'',
	'',
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4345,
	0);
INSERT INTO SM_TXN
	VALUES (4343,
	4189,
	4199,
	0);
INSERT INTO PE_PE
	VALUES (4171,
	1,
	4132,
	0,
	4);
INSERT INTO O_OBJ
	VALUES (4171,
	'simulatedGPS',
	2,
	'simulatedGPS',
	'Constants specifying the behavior of the simulated GPS.

initialLatitude and initialLongitude specify, as decimal degrees,
the initial location of the simulated GPS.

latitudeIncrement and longitudeIncrement specify, as decimal degrees,
the distance the simulated GPS moves during each update period.

updatePeriod specifies, in microseconds, the update period for the
simulated GPS.  In other words, the simulated GPS updates its location
once per updatePeriod.',
	0);
INSERT INTO O_TFR
	VALUES (4168,
	4171,
	'initialize',
	'',
	1192,
	0,
	'select any simgps from instances of simulatedGPS;
if ( empty simgps )
  create object instance simgps of simulatedGPS; simgps.id = 1;
  simgps.initialLatitude = 32.432237;
  simgps.initialLongitude = -110.812283;
  simgps.latitudeIncrement = 0.00001;
  simgps.longitudeIncrement = 0.00002;
  simgps.updatePeriod = 1000000;
end if;',
	1,
	'',
	0,
	0);
INSERT INTO ACT_OPB
	VALUES (4347,
	4168);
INSERT INTO ACT_ACT
	VALUES (4347,
	'class operation',
	0,
	4348,
	0,
	0,
	'simulatedGPS::initialize',
	0);
INSERT INTO ACT_BLK
	VALUES (4348,
	1,
	0,
	0,
	'',
	'',
	'',
	2,
	1,
	1,
	37,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4347,
	0);
INSERT INTO ACT_SMT
	VALUES (4349,
	4348,
	4350,
	1,
	1,
	'simulatedGPS::initialize line: 1');
INSERT INTO ACT_FIO
	VALUES (4349,
	4351,
	1,
	'any',
	4171,
	1,
	37);
INSERT INTO ACT_SMT
	VALUES (4350,
	4348,
	0,
	2,
	1,
	'simulatedGPS::initialize line: 2');
INSERT INTO ACT_IF
	VALUES (4350,
	4352,
	4353,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4354,
	0,
	0,
	2,
	12,
	17,
	0,
	0,
	0,
	0,
	1309,
	4348);
INSERT INTO V_IRF
	VALUES (4354,
	4351);
INSERT INTO V_VAL
	VALUES (4353,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	125,
	4348);
INSERT INTO V_UNY
	VALUES (4353,
	4354,
	'empty');
INSERT INTO V_VAR
	VALUES (4351,
	4348,
	'simgps',
	1,
	1309);
INSERT INTO V_INT
	VALUES (4351,
	0,
	4171);
INSERT INTO ACT_BLK
	VALUES (4352,
	0,
	0,
	0,
	'',
	'',
	'',
	8,
	3,
	3,
	36,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	4347,
	0);
INSERT INTO ACT_SMT
	VALUES (4355,
	4352,
	4356,
	3,
	3,
	'simulatedGPS::initialize line: 3');
INSERT INTO ACT_CR
	VALUES (4355,
	4351,
	0,
	4171,
	3,
	36);
INSERT INTO ACT_SMT
	VALUES (4356,
	4352,
	4357,
	3,
	50,
	'simulatedGPS::initialize line: 3');
INSERT INTO ACT_AI
	VALUES (4356,
	4358,
	4359,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4357,
	4352,
	4360,
	4,
	3,
	'simulatedGPS::initialize line: 4');
INSERT INTO ACT_AI
	VALUES (4357,
	4361,
	4362,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4360,
	4352,
	4363,
	5,
	3,
	'simulatedGPS::initialize line: 5');
INSERT INTO ACT_AI
	VALUES (4360,
	4364,
	4365,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4363,
	4352,
	4366,
	6,
	3,
	'simulatedGPS::initialize line: 6');
INSERT INTO ACT_AI
	VALUES (4363,
	4367,
	4368,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4366,
	4352,
	4369,
	7,
	3,
	'simulatedGPS::initialize line: 7');
INSERT INTO ACT_AI
	VALUES (4366,
	4370,
	4371,
	0,
	0);
INSERT INTO ACT_SMT
	VALUES (4369,
	4352,
	0,
	8,
	3,
	'simulatedGPS::initialize line: 8');
INSERT INTO ACT_AI
	VALUES (4369,
	4372,
	4373,
	0,
	0);
INSERT INTO V_VAL
	VALUES (4374,
	1,
	0,
	3,
	50,
	55,
	0,
	0,
	0,
	0,
	1309,
	4352);
INSERT INTO V_IRF
	VALUES (4374,
	4351);
INSERT INTO V_VAL
	VALUES (4359,
	1,
	0,
	3,
	57,
	58,
	0,
	0,
	0,
	0,
	160,
	4352);
INSERT INTO V_AVL
	VALUES (4359,
	4374,
	4171,
	4375);
INSERT INTO V_VAL
	VALUES (4358,
	0,
	0,
	3,
	62,
	62,
	0,
	0,
	0,
	0,
	160,
	4352);
INSERT INTO V_LIN
	VALUES (4358,
	'1');
INSERT INTO V_VAL
	VALUES (4376,
	1,
	0,
	4,
	3,
	8,
	0,
	0,
	0,
	0,
	1309,
	4352);
INSERT INTO V_IRF
	VALUES (4376,
	4351);
INSERT INTO V_VAL
	VALUES (4362,
	1,
	0,
	4,
	10,
	24,
	0,
	0,
	0,
	0,
	153,
	4352);
INSERT INTO V_AVL
	VALUES (4362,
	4376,
	4171,
	4183);
INSERT INTO V_VAL
	VALUES (4361,
	0,
	0,
	4,
	28,
	36,
	0,
	0,
	0,
	0,
	153,
	4352);
INSERT INTO V_LRL
	VALUES (4361,
	'32.432237');
INSERT INTO V_VAL
	VALUES (4377,
	1,
	0,
	5,
	3,
	8,
	0,
	0,
	0,
	0,
	1309,
	4352);
INSERT INTO V_IRF
	VALUES (4377,
	4351);
INSERT INTO V_VAL
	VALUES (4365,
	1,
	0,
	5,
	10,
	25,
	0,
	0,
	0,
	0,
	153,
	4352);
INSERT INTO V_AVL
	VALUES (4365,
	4377,
	4171,
	4186);
INSERT INTO V_VAL
	VALUES (4364,
	0,
	0,
	-1,
	-1,
	-1,
	0,
	0,
	0,
	0,
	153,
	4352);
INSERT INTO V_UNY
	VALUES (4364,
	4378,
	'-');
INSERT INTO V_VAL
	VALUES (4378,
	0,
	0,
	5,
	30,
	39,
	0,
	0,
	0,
	0,
	153,
	4352);
INSERT INTO V_LRL
	VALUES (4378,
	'110.812283');
INSERT INTO V_VAL
	VALUES (4379,
	1,
	0,
	6,
	3,
	8,
	0,
	0,
	0,
	0,
	1309,
	4352);
INSERT INTO V_IRF
	VALUES (4379,
	4351);
INSERT INTO V_VAL
	VALUES (4368,
	1,
	0,
	6,
	10,
	26,
	0,
	0,
	0,
	0,
	153,
	4352);
INSERT INTO V_AVL
	VALUES (4368,
	4379,
	4171,
	4251);
INSERT INTO V_VAL
	VALUES (4367,
	0,
	0,
	6,
	30,
	36,
	0,
	0,
	0,
	0,
	153,
	4352);
INSERT INTO V_LRL
	VALUES (4367,
	'0.00001');
INSERT INTO V_VAL
	VALUES (4380,
	1,
	0,
	7,
	3,
	8,
	0,
	0,
	0,
	0,
	1309,
	4352);
INSERT INTO V_IRF
	VALUES (4380,
	4351);
INSERT INTO V_VAL
	VALUES (4371,
	1,
	0,
	7,
	10,
	27,
	0,
	0,
	0,
	0,
	153,
	4352);
INSERT INTO V_AVL
	VALUES (4371,
	4380,
	4171,
	4244);
INSERT INTO V_VAL
	VALUES (4370,
	0,
	0,
	7,
	31,
	37,
	0,
	0,
	0,
	0,
	153,
	4352);
INSERT INTO V_LRL
	VALUES (4370,
	'0.00002');
INSERT INTO V_VAL
	VALUES (4381,
	1,
	0,
	8,
	3,
	8,
	0,
	0,
	0,
	0,
	1309,
	4352);
INSERT INTO V_IRF
	VALUES (4381,
	4351);
INSERT INTO V_VAL
	VALUES (4373,
	1,
	0,
	8,
	10,
	21,
	0,
	0,
	0,
	0,
	160,
	4352);
INSERT INTO V_AVL
	VALUES (4373,
	4381,
	4171,
	4305);
INSERT INTO V_VAL
	VALUES (4372,
	0,
	0,
	8,
	25,
	31,
	0,
	0,
	0,
	0,
	160,
	4352);
INSERT INTO V_LIN
	VALUES (4372,
	'1000000');
INSERT INTO O_NBATTR
	VALUES (4375,
	4171);
INSERT INTO O_BATTR
	VALUES (4375,
	4171);
INSERT INTO O_ATTR
	VALUES (4375,
	4171,
	0,
	'id',
	'',
	'',
	'id',
	0,
	160,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (4183,
	4171);
INSERT INTO O_BATTR
	VALUES (4183,
	4171);
INSERT INTO O_ATTR
	VALUES (4183,
	4171,
	4375,
	'initialLatitude',
	'',
	'',
	'initialLatitude',
	0,
	153,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (4186,
	4171);
INSERT INTO O_BATTR
	VALUES (4186,
	4171);
INSERT INTO O_ATTR
	VALUES (4186,
	4171,
	4183,
	'initialLongitude',
	'',
	'',
	'initialLongitude',
	0,
	153,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (4251,
	4171);
INSERT INTO O_BATTR
	VALUES (4251,
	4171);
INSERT INTO O_ATTR
	VALUES (4251,
	4171,
	4186,
	'latitudeIncrement',
	'',
	'',
	'latitudeIncrement',
	0,
	153,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (4244,
	4171);
INSERT INTO O_BATTR
	VALUES (4244,
	4171);
INSERT INTO O_ATTR
	VALUES (4244,
	4171,
	4251,
	'longitudeIncrement',
	'',
	'',
	'longitudeIncrement',
	0,
	153,
	'',
	'');
INSERT INTO O_NBATTR
	VALUES (4305,
	4171);
INSERT INTO O_BATTR
	VALUES (4305,
	4171);
INSERT INTO O_ATTR
	VALUES (4305,
	4171,
	4244,
	'updatePeriod',
	'',
	'',
	'updatePeriod',
	0,
	160,
	'',
	'');
INSERT INTO O_ID
	VALUES (0,
	4171);
INSERT INTO O_OIDA
	VALUES (4375,
	4171,
	0,
	'id');
INSERT INTO O_ID
	VALUES (1,
	4171);
INSERT INTO O_ID
	VALUES (2,
	4171);
