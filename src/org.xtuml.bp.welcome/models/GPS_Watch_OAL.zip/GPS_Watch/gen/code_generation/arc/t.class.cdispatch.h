extern void ${te_class.CBdispatcher}( ${te_eq.base_event_type} * );
