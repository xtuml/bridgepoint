/*
 * ${te_dt.Name}:
 */
typedef struct {
${members}\
} ${te_dt.ExtName};
