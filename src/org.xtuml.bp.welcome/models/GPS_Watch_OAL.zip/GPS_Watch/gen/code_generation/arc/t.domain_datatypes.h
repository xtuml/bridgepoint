/*
 * Internal enumerated and structured data types for component:  ${te_c.Name}
 */
${enumeration_info}
${structured_data_types}
