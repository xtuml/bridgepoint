${ws}${te_set.init}( ${te_select_related.result_var} );
