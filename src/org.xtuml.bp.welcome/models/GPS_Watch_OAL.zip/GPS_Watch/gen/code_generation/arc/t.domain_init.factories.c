.//
    for ( int cn=0; cn < ${te_dci.max}; ++cn ) {
      ${te_instance.factory_init}( 0, cn );
    }
.//
