#ifndef SYS_XTUMLLOAD_H
#define SYS_XTUMLLOAD_H
${te_target.c2cplusplus_linkage_begin}

int Escher_xtUML_load( int, char * [] );

${te_target.c2cplusplus_linkage_end}
#endif   /* SYS_XTUMLLOAD_H */
.//
