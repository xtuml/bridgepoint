//
// File: Inspector__HeartRateMonitor__HeartRateConstants.hh
//
#ifndef Inspector_Heart_Rate_Monitor_Heart_Rate_Constants_hh
#define Inspector_Heart_Rate_Monitor_Heart_Rate_Constants_hh

#include "__HeartRateMonitor__HeartRateConstants.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_HeartRateMonitor
  {
    namespace maslo_HeartRateConstants
    {
      class maslo_HeartRateConstantsHandler
        : public ObjectHandler< ::masld_HeartRateMonitor::maslo_HeartRateConstants>
      {

        // Constructors
        public:
          maslo_HeartRateConstantsHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateConstants> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                                                 channel,
                                       ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateConstants> instance,
                                       int                                                                   relId ) const;


      };
    }
  }
}
#endif // Inspector_Heart_Rate_Monitor_Heart_Rate_Constants_hh
