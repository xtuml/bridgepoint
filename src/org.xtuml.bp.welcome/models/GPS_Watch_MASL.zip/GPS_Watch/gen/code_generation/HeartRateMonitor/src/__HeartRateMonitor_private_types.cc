//
// File: __HeartRateMonitor_private_types.cc
//
