//
// File: Sqlite__HeartRateMonitor__HeartRateMonitorPopulation.hh
//
#ifndef Sqlite_Heart_Rate_Monitor_Heart_Rate_Monitor_Population_hh
#define Sqlite_Heart_Rate_Monitor_Heart_Rate_Monitor_Population_hh

#include "Sqlite__HeartRateMonitor__HeartRateMonitor.hh"
#include "Sqlite__HeartRateMonitor__HeartRateMonitorMapper.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "__HeartRateMonitor__HeartRateMonitorPopulation.hh"
#include "boost/signals2.hpp"
#include "sql/Population.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_HeartRateMonitor
  {
    class maslo_HeartRateMonitorPopulation
      : public ::SQL::SqlPopulation< ::masld_HeartRateMonitor::maslo_HeartRateMonitor,maslo_HeartRateMonitor,maslo_HeartRateMonitorMapper,::masld_HeartRateMonitor::maslo_HeartRateMonitorPopulation>
    {

      // Constructors and Destructors
      private:
        maslo_HeartRateMonitorPopulation ( );
        ~maslo_HeartRateMonitorPopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> createInstance ( int32_t                                                masla_recentHeartRate,
                                                                                                     const ::SWA::EventTimers::TimerIdType&                 masla_timer,
                                                                                                     int32_t                                                masla_id,
                                                                                                     ::masld_HeartRateMonitor::maslo_HeartRateMonitor::Type currentState );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> instance );


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Singleton Registration
      public:
        static maslo_HeartRateMonitorPopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;


    };
  }
}
#endif // Sqlite_Heart_Rate_Monitor_Heart_Rate_Monitor_Population_hh
