//
// File: Inspector_types__HeartRateMonitor.cc
//
