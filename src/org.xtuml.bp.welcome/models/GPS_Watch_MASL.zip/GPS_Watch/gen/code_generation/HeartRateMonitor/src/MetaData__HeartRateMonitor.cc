//
// File: MetaData__HeartRateMonitor.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_terminators.hh"
#include "__HeartRateMonitor__HeartRateConstants.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "metadata/MetaData.hh"
#include "swa/Domain.hh"
#include <vector>

namespace 
{
  namespace init_masld_HeartRateMonitor
  {
    ::SWA::ServiceMetaData get_masls_registerListener_MetaData ( );
    ::SWA::ServiceMetaData get_masls_unregisterListener_MetaData ( );
    namespace maslb_HRChange
    {
      ::SWA::TerminatorMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_heartRateChanged_MetaData ( );
    }
    namespace maslo_HeartRateConstants
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( );
    }
    namespace maslo_HeartRateMonitor
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( );
      ::SWA::StateMetaData get_maslst_idle_MetaData ( );
      ::SWA::StateMetaData get_maslst_monitoring_MetaData ( );
      ::SWA::StateMetaData get_maslst_Registering_MetaData ( );
      ::SWA::StateMetaData get_maslst_Unregistering_MetaData ( );
      ::SWA::EventMetaData get_maslev_timeout_MetaData ( );
      ::SWA::EventMetaData get_maslev_registerComplete_MetaData ( );
      ::SWA::EventMetaData get_maslev_unregisterComplete_MetaData ( );
      ::SWA::EventMetaData get_maslev_registerListener_MetaData ( );
      ::SWA::EventMetaData get_maslev_unregisterListener_MetaData ( );
    }
    ::SWA::DomainMetaData initDomainMetaData ( )
    {
      ::SWA::DomainMetaData domain(::masld_HeartRateMonitor::getDomain().getId(), "HeartRateMonitor", false);
      domain.addService( get_masls_registerListener_MetaData() );
      domain.addService( get_masls_unregisterListener_MetaData() );
      domain.addTerminator( maslb_HRChange::getMetaData() );
      domain.addObject( maslo_HeartRateConstants::getMetaData() );
      domain.addObject( maslo_HeartRateMonitor::getMetaData() );
      return domain;
    }

    ::SWA::DomainMetaData& getDomainMetaData ( )
    {
      static ::SWA::DomainMetaData domain = initDomainMetaData();
      return domain;
    }

    bool registered = ::SWA::ProcessMetaData::getProcess().addDomain( ::masld_HeartRateMonitor::getDomain().getId(), &getDomainMetaData );

    ::SWA::ServiceMetaData get_masls_registerListener_MetaData ( )
    {
      int lines[] = { 3,
     4,
     5,
     6};
      ::SWA::ServiceMetaData service(::masld_HeartRateMonitor::serviceId_masls_registerListener, ::SWA::ServiceMetaData::Domain, "registerListener", ::std::vector<int>( lines, lines + 4 ), "registerListener.svc", "e2e3f517bae41ccaccbddb522bdba191");
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "hr", "instance of HeartRateMonitor", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_HeartRateMonitor::getDomain().getId(), ::masld_HeartRateMonitor::objectId_maslo_HeartRateMonitor ) ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_unregisterListener_MetaData ( )
    {
      int lines[] = { 3,
     4,
     5,
     6};
      ::SWA::ServiceMetaData service(::masld_HeartRateMonitor::serviceId_masls_unregisterListener, ::SWA::ServiceMetaData::Domain, "unregisterListener", ::std::vector<int>( lines, lines + 4 ), "unregisterListener.svc", "fc6c47b17847dc0c5a9c7c63586d269a");
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "hr", "instance of HeartRateMonitor", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_HeartRateMonitor::getDomain().getId(), ::masld_HeartRateMonitor::objectId_maslo_HeartRateMonitor ) ) );
      return service;
    }

    namespace maslb_HRChange
    {
      ::SWA::TerminatorMetaData getMetaData ( )
      {
        ::SWA::TerminatorMetaData terminator(::masld_HeartRateMonitor::terminatorId_maslb_HRChange, "HRChange", "HRChange");
        terminator.addService( get_masls_heartRateChanged_MetaData() );
        return terminator;
      }

      ::SWA::ServiceMetaData get_masls_heartRateChanged_MetaData ( )
      {
        int lines[] = { 2,
     3};
        ::SWA::ServiceMetaData service(::masld_HeartRateMonitor::maslb_HRChange::serviceId_masls_heartRateChanged, ::SWA::ServiceMetaData::Terminator, "heartRateChanged", ::std::vector<int>( lines, lines + 2 ), "HRChange_heartRateChanged.tr", "3cf9e79b0b7e12c58f2c5c0f91b491a6");
        service.addParameter( ::SWA::ParameterMetaData( "heartRate", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
        return service;
      }

    }
    namespace maslo_HeartRateConstants
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_HeartRateMonitor::objectId_maslo_HeartRateConstants, "HeartRateConstants", "HeartRateConstants");
        object.addAttribute( ::SWA::AttributeMetaData( "id", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "HeartRateAveragingWindow", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "HeartRateSamplingPeriod", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addService( get_masls_initialize_MetaData() );
        return object;
      }

      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( )
      {
        int lines[] = { 3,
     4,
     5,
     6,
     7,
     8};
        ::SWA::ServiceMetaData service(::masld_HeartRateMonitor::maslo_HeartRateConstants::serviceId_masls_initialize, ::SWA::ServiceMetaData::Object, "initialize", ::std::vector<int>( lines, lines + 6 ), "HeartRateConstants_initialize.svc", "6c1f9c2475e8b973f050fc7cf756a686");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "hrc", "instance of HeartRateConstants", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_HeartRateMonitor::getDomain().getId(), ::masld_HeartRateMonitor::objectId_maslo_HeartRateConstants ) ) );
        return service;
      }

    }
    namespace maslo_HeartRateMonitor
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_HeartRateMonitor::objectId_maslo_HeartRateMonitor, "HeartRateMonitor", "HeartRateMonitor");
        object.addAttribute( ::SWA::AttributeMetaData( "recentHeartRate", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "timer", false, "timer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "id", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addService( get_masls_initialize_MetaData() );
        object.addState( get_maslst_idle_MetaData() );
        object.addState( get_maslst_monitoring_MetaData() );
        object.addState( get_maslst_Registering_MetaData() );
        object.addState( get_maslst_Unregistering_MetaData() );
        object.addEvent( get_maslev_timeout_MetaData() );
        object.addEvent( get_maslev_registerComplete_MetaData() );
        object.addEvent( get_maslev_unregisterComplete_MetaData() );
        object.addEvent( get_maslev_registerListener_MetaData() );
        object.addEvent( get_maslev_unregisterListener_MetaData() );
        return object;
      }

      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( )
      {
        int lines[] = { 3,
     4,
     5,
     6};
        ::SWA::ServiceMetaData service(::masld_HeartRateMonitor::maslo_HeartRateMonitor::serviceId_masls_initialize, ::SWA::ServiceMetaData::Object, "initialize", ::std::vector<int>( lines, lines + 4 ), "HeartRateMonitor_initialize.svc", "9d3c29bc46febe23cbc8b0cc23208843");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "monitor", "instance of HeartRateMonitor", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_HeartRateMonitor::getDomain().getId(), ::masld_HeartRateMonitor::objectId_maslo_HeartRateMonitor ) ) );
        return service;
      }

      ::SWA::StateMetaData get_maslst_idle_MetaData ( )
      {
        int lines[] = { 2};
        ::SWA::StateMetaData state(::masld_HeartRateMonitor::maslo_HeartRateMonitor::stateId_maslst_idle, ::SWA::StateMetaData::Normal, "idle", ::std::vector<int>( lines, lines + 1 ), "HeartRateMonitor_idle.al", "9856552533bd33ddd038407dd5e29a3b");
        return state;
      }

      ::SWA::StateMetaData get_maslst_monitoring_MetaData ( )
      {
        int lines[] = { 2,
     3,
     4};
        ::SWA::StateMetaData state(::masld_HeartRateMonitor::maslo_HeartRateMonitor::stateId_maslst_monitoring, ::SWA::StateMetaData::Normal, "monitoring", ::std::vector<int>( lines, lines + 3 ), "HeartRateMonitor_monitoring.al", "3f54bc983eb3bfcf9c8e7df563da22dc");
        return state;
      }

      ::SWA::StateMetaData get_maslst_Registering_MetaData ( )
      {
        int lines[] = { 3,
     4,
     6,
     9,
     10,
     11,
     13};
        ::SWA::StateMetaData state(::masld_HeartRateMonitor::maslo_HeartRateMonitor::stateId_maslst_Registering, ::SWA::StateMetaData::Normal, "Registering", ::std::vector<int>( lines, lines + 7 ), "HeartRateMonitor_Registering.al", "c8a1658fab0a98fedc48bedb8975cea6");
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "hrc", "instance of HeartRateConstants", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_HeartRateMonitor::getDomain().getId(), ::masld_HeartRateMonitor::objectId_maslo_HeartRateConstants ) ) );
        return state;
      }

      ::SWA::StateMetaData get_maslst_Unregistering_MetaData ( )
      {
        int lines[] = { 2,
     3,
     10};
        ::SWA::StateMetaData state(::masld_HeartRateMonitor::maslo_HeartRateMonitor::stateId_maslst_Unregistering, ::SWA::StateMetaData::Normal, "Unregistering", ::std::vector<int>( lines, lines + 3 ), "HeartRateMonitor_Unregistering.al", "14c00dd0d5e3dac44e4a385ce1aff149");
        return state;
      }

      ::SWA::EventMetaData get_maslev_timeout_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_HeartRateMonitor::maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_timeout, ::masld_HeartRateMonitor::objectId_maslo_HeartRateMonitor, ::SWA::EventMetaData::Normal, "timeout");
        return event;
      }

      ::SWA::EventMetaData get_maslev_registerComplete_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_HeartRateMonitor::maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_registerComplete, ::masld_HeartRateMonitor::objectId_maslo_HeartRateMonitor, ::SWA::EventMetaData::Normal, "registerComplete");
        return event;
      }

      ::SWA::EventMetaData get_maslev_unregisterComplete_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_HeartRateMonitor::maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_unregisterComplete, ::masld_HeartRateMonitor::objectId_maslo_HeartRateMonitor, ::SWA::EventMetaData::Normal, "unregisterComplete");
        return event;
      }

      ::SWA::EventMetaData get_maslev_registerListener_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_HeartRateMonitor::maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_registerListener, ::masld_HeartRateMonitor::objectId_maslo_HeartRateMonitor, ::SWA::EventMetaData::Normal, "registerListener");
        return event;
      }

      ::SWA::EventMetaData get_maslev_unregisterListener_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_HeartRateMonitor::maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_unregisterListener, ::masld_HeartRateMonitor::objectId_maslo_HeartRateMonitor, ::SWA::EventMetaData::Normal, "unregisterListener");
        return event;
      }

    }
  }
}
