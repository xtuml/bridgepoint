//
// File: Inspector__HeartRateMonitor__HeartRateMonitor.hh
//
#ifndef Inspector_Heart_Rate_Monitor_Heart_Rate_Monitor_hh
#define Inspector_Heart_Rate_Monitor_Heart_Rate_Monitor_hh

#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_HeartRateMonitor
  {
    namespace maslo_HeartRateMonitor
    {
      class maslo_HeartRateMonitorHandler
        : public ObjectHandler< ::masld_HeartRateMonitor::maslo_HeartRateMonitor>
      {

        // Constructors
        public:
          maslo_HeartRateMonitorHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                                               channel,
                                       ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> instance,
                                       int                                                                 relId ) const;


      };
    }
  }
}
#endif // Inspector_Heart_Rate_Monitor_Heart_Rate_Monitor_hh
