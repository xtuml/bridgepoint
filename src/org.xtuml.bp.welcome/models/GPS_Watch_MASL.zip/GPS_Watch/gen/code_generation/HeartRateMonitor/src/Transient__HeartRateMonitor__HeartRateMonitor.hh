//
// File: Transient__HeartRateMonitor__HeartRateMonitor.hh
//
#ifndef Transient_Heart_Rate_Monitor_Heart_Rate_Monitor_hh
#define Transient_Heart_Rate_Monitor_Heart_Rate_Monitor_hh

#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/types.hh"

namespace transient
{
  namespace masld_HeartRateMonitor
  {
    class maslo_HeartRateMonitor
      : public ::masld_HeartRateMonitor::maslo_HeartRateMonitor
    {

      // Constructors and Destructors
      public:
        maslo_HeartRateMonitor ( int32_t                                                masla_recentHeartRate,
                                 const ::SWA::EventTimers::TimerIdType&                 masla_timer,
                                 int32_t                                                masla_id,
                                 ::masld_HeartRateMonitor::maslo_HeartRateMonitor::Type currentState );


      // Setters for each object attribute
      public:
        virtual void set_masla_recentHeartRate ( int32_t value ) { this->masla_recentHeartRate = value; }
        virtual void set_masla_timer ( const ::SWA::EventTimers::TimerIdType& value ) { this->masla_timer = value; }
        virtual void setCurrentState ( ::masld_HeartRateMonitor::maslo_HeartRateMonitor::Type newState ) { currentState = newState; }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_recentHeartRate ( ) const { return masla_recentHeartRate; }
        virtual ::SWA::EventTimers::TimerIdType get_masla_timer ( ) const { return masla_timer; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual ::masld_HeartRateMonitor::maslo_HeartRateMonitor::Type getCurrentState ( ) const { return currentState; }


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_recentHeartRate;
        ::SWA::EventTimers::TimerIdType masla_timer;
        int32_t masla_id;
        ::masld_HeartRateMonitor::maslo_HeartRateMonitor::Type currentState;


    };
  }
}
#endif // Transient_Heart_Rate_Monitor_Heart_Rate_Monitor_hh
