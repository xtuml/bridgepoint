//
// File: __HeartRateMonitor__registerListener.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_services.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "boost/shared_ptr.hpp"
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace masld_HeartRateMonitor
{
  void masls_registerListener ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_registerListener);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // hr : instance of HeartRateMonitor;
        ::SWA::ObjectPtr<maslo_HeartRateMonitor> maslv_hr;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_hr(0, maslv_hr);

        // HeartRateMonitor.initialize()
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslo_HeartRateMonitor::masls_initialize();
        }

        // hr := find_one HeartRateMonitor ();
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          maslv_hr = maslo_HeartRateMonitor::findOne();
        }

        // generate HeartRateMonitor.registerListener () to hr;
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          ::SWA::Process::getInstance().getEventQueue().addEvent( maslv_hr->create_maslo_HeartRateMonitor_maslev_registerListener() );
        }
      }
    }
  }

  const bool localServiceRegistration_masls_registerListener = interceptor_masls_registerListener::instance().registerLocal( &masls_registerListener );

}
