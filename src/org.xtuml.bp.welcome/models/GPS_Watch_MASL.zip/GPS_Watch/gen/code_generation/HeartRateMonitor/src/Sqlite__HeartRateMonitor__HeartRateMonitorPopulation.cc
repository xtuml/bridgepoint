//
// File: Sqlite__HeartRateMonitor__HeartRateMonitorPopulation.cc
//
#include "Sqlite__HeartRateMonitor__HeartRateMonitorPopulation.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "boost/bind.hpp"
#include "boost/signals2.hpp"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_HeartRateMonitor
  {
    maslo_HeartRateMonitorPopulation::maslo_HeartRateMonitorPopulation ( )
    {
    }

    maslo_HeartRateMonitorPopulation::~maslo_HeartRateMonitorPopulation ( )
    {
    }

    void maslo_HeartRateMonitorPopulation::initialise ( )
    {
      mapper->initialise();
    }

    maslo_HeartRateMonitorPopulation& maslo_HeartRateMonitorPopulation::getPopulation ( )
    {
      static maslo_HeartRateMonitorPopulation population;
      return population;
    }

    bool maslo_HeartRateMonitorPopulation::registered = maslo_HeartRateMonitorPopulation::registerSingleton( &maslo_HeartRateMonitorPopulation::getPopulation );

    ::boost::signals2::connection maslo_HeartRateMonitorPopulation::initialised = ::SWA::Process::getInstance().registerInitialisingListener( ::boost::bind( &maslo_HeartRateMonitorPopulation::initialise, ::boost::bind( &maslo_HeartRateMonitorPopulation::getPopulation ) ) );

    ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> maslo_HeartRateMonitorPopulation::findObject ( const ::SWA::IdType& obj )
    {
      return mapper->find( obj );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> > maslo_HeartRateMonitorPopulation::findObject ( const MapperType::PsObjectIdSet& obj )
    {
      MapperType::PsObjectPtrSet objectSet = mapper->find( obj );
      return ::SWA::Set< ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> >( objectSet.begin(), objectSet.end(), true );
    }

    ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> maslo_HeartRateMonitorPopulation::createInstance ( int32_t                                                masla_recentHeartRate,
                                                                                                                           const ::SWA::EventTimers::TimerIdType&                 masla_timer,
                                                                                                                           int32_t                                                masla_id,
                                                                                                                           ::masld_HeartRateMonitor::maslo_HeartRateMonitor::Type currentState )
    {
      return mapper->createInstance( masla_recentHeartRate, masla_timer, masla_id, currentState );
    }

    void maslo_HeartRateMonitorPopulation::deleteInstance ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> instance )
    {
      {
      }
      mapper->deleteInstance( instance );
    }

  }
}
