//
// File: Transient__HeartRateMonitor__HeartRateMonitorPopulation.hh
//
#ifndef Transient_Heart_Rate_Monitor_Heart_Rate_Monitor_Population_hh
#define Transient_Heart_Rate_Monitor_Heart_Rate_Monitor_Population_hh

#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "__HeartRateMonitor__HeartRateMonitorPopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace transient
{
  namespace masld_HeartRateMonitor
  {
    class maslo_HeartRateMonitorPopulation
      : public TransientPopulation< ::masld_HeartRateMonitor::maslo_HeartRateMonitor,::masld_HeartRateMonitor::maslo_HeartRateMonitorPopulation>
    {

      // Instance Creation
      private:
        maslo_HeartRateMonitorPopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> createInstance ( int32_t                                                masla_recentHeartRate,
                                                                                                     const ::SWA::EventTimers::TimerIdType&                 masla_timer,
                                                                                                     int32_t                                                masla_id,
                                                                                                     ::masld_HeartRateMonitor::maslo_HeartRateMonitor::Type currentState );


      // Singleton Registration
      public:
        static maslo_HeartRateMonitorPopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> > masla_id_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> instance );
      protected:
        bool exists_masla_id ( int32_t masla_id ) const;


    };
  }
}
#endif // Transient_Heart_Rate_Monitor_Heart_Rate_Monitor_Population_hh
