//
// File: __HeartRateMonitor__HeartRateConstants__initialize.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "__HeartRateMonitor__HeartRateConstants.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_HeartRateMonitor
{
  void maslo_HeartRateConstants::masls_initialize ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_HeartRateConstants, serviceId_masls_initialize);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // hrc : instance of HeartRateConstants;
        ::SWA::ObjectPtr<maslo_HeartRateConstants> maslv_hrc;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_hrc(0, maslv_hrc);

        // hrc := find_one HeartRateConstants ();
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslv_hrc = findOne();
        }

        // if (null = hrc) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          if ( ::SWA::Null == maslv_hrc )
          {

            // hrc := create HeartRateConstants (
            //            id => 1 );
            {
              ::SWA::Stack::ExecutingStatement statement(6);
              maslv_hrc = createInstance( 1ll, int32_t(), int32_t() );
            }

            // hrc.HeartRateAveragingWindow := 5;
            {
              ::SWA::Stack::ExecutingStatement statement(7);
              maslv_hrc->set_masla_HeartRateAveragingWindow( 5ll );
            }

            // hrc.HeartRateSamplingPeriod := 3;
            {
              ::SWA::Stack::ExecutingStatement statement(8);
              maslv_hrc->set_masla_HeartRateSamplingPeriod( 3ll );
            }
          }
        }
      }
    }
  }

}
