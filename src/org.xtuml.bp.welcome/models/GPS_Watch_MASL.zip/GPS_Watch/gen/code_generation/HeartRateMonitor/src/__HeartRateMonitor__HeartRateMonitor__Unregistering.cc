//
// File: __HeartRateMonitor__HeartRateMonitor__Unregistering.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "boost/shared_ptr.hpp"
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace masld_HeartRateMonitor
{
  void maslo_HeartRateMonitor::state_maslst_Unregistering ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_HeartRateMonitor, stateId_maslst_Unregistering);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // cancel this.timer;
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          ::SWA::EventTimers::getInstance().cancelTimer( ::SWA::ObjectPtr<maslo_HeartRateMonitor>( this )->get_masla_timer() );
        }

        // generate HeartRateMonitor.unregisterComplete () to this;
        {
          ::SWA::Stack::ExecutingStatement statement(10);
          ::SWA::Process::getInstance().getEventQueue().addEvent( ::SWA::ObjectPtr<maslo_HeartRateMonitor>( this )->create_maslo_HeartRateMonitor_maslev_unregisterComplete( objectId_maslo_HeartRateMonitor, getArchitectureId() ) );
        }
      }
    }
  }

}
