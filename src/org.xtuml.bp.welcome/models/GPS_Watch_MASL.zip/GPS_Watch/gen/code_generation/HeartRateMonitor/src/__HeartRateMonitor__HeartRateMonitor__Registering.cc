//
// File: __HeartRateMonitor__HeartRateMonitor__Registering.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "LOG_OOA/__LOG_services.hh"
#include "__HeartRateMonitor__HeartRateConstants.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "boost/shared_ptr.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Duration.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_HeartRateMonitor
{
  void maslo_HeartRateMonitor::state_maslst_Registering ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_HeartRateMonitor, stateId_maslst_Registering);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // hrc : instance of HeartRateConstants;
        ::SWA::ObjectPtr<maslo_HeartRateConstants> maslv_hrc;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_hrc(0, maslv_hrc);

        // this.recentHeartRate := 50;
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          ::SWA::ObjectPtr<maslo_HeartRateMonitor>( this )->set_masla_recentHeartRate( 50ll );
        }

        // LOG::LogInfo("listener registered")
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          ::masld_LOG::interceptor_masls_LogInfo::instance().callService()( ::SWA::String( "listener registered" ) );
        }

        // HeartRateConstants.initialize()
        {
          ::SWA::Stack::ExecutingStatement statement(9);
          maslo_HeartRateConstants::masls_initialize();
        }

        // hrc := find_one HeartRateConstants ();
        {
          ::SWA::Stack::ExecutingStatement statement(10);
          maslv_hrc = maslo_HeartRateConstants::findOne();
        }

        // schedule this.timer generate HeartRateMonitor.timeout () to this delay (@PT1S@ * hrc.HeartRateSamplingPeriod) delta (@PT1S@ * hrc.HeartRateSamplingPeriod);
        {
          ::SWA::Stack::ExecutingStatement statement(11);
          ::SWA::EventTimers::getInstance().scheduleTimer( ::SWA::ObjectPtr<maslo_HeartRateMonitor>( this )->get_masla_timer(), ::SWA::Duration::fromNanos( 1000000000ll ) * maslv_hrc->get_masla_HeartRateSamplingPeriod() + ::SWA::Timestamp::now(), ::SWA::Duration::fromNanos( 1000000000ll ) * maslv_hrc->get_masla_HeartRateSamplingPeriod(), ::SWA::ObjectPtr<maslo_HeartRateMonitor>( this )->create_maslo_HeartRateMonitor_maslev_timeout( objectId_maslo_HeartRateMonitor, getArchitectureId() ) );
        }

        // generate HeartRateMonitor.registerComplete () to this;
        {
          ::SWA::Stack::ExecutingStatement statement(13);
          ::SWA::Process::getInstance().getEventQueue().addEvent( ::SWA::ObjectPtr<maslo_HeartRateMonitor>( this )->create_maslo_HeartRateMonitor_maslev_registerComplete( objectId_maslo_HeartRateMonitor, getArchitectureId() ) );
        }
      }
    }
  }

}
