//
// File: __HeartRateMonitor__HRChange__heartRateChanged.cc
//
#include "Format_OOA/__Format_services.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_terminators.hh"
#include "LOG_OOA/__LOG_services.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"

namespace masld_HeartRateMonitor
{
  void maslb_HRChange::masls_heartRateChanged ( int32_t maslp_heartRate )
  {
    getInstance().override_masls_heartRateChanged.getFunction()( maslp_heartRate );
  }

  bool maslb_HRChange::register_masls_heartRateChanged ( ::SWA::FunctionOverrider<void (int32_t)>::FunctionPtr override )
  {
    getInstance().override_masls_heartRateChanged.override( override );
    return true;
  }

  bool maslb_HRChange::overriden_masls_heartRateChanged ( )
  {
    return getInstance().override_masls_heartRateChanged.isOverridden();
  }

  void maslb_HRChange::domain_masls_heartRateChanged ( int32_t maslp_heartRate )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringTerminatorService enteringActionMarker(getDomain().getId(), terminatorId_maslb_HRChange, serviceId_masls_heartRateChanged);
      ::SWA::Stack::DeclareParameter pm_maslp_heartRate(maslp_heartRate);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // LOG::LogInfo(("Sending message 'heartRateChanged' on terminator HRChange. heartRate: " & Format::format_integer(heartRate, false)))
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          ::masld_LOG::interceptor_masls_LogInfo::instance().callService()( ::SWA::String( ::SWA::String( "Sending message 'heartRateChanged' on terminator HRChange. heartRate: " ) ) + ::masld_Format::masls_format_integer( maslp_heartRate, false ) );
        }
      }
    }
  }

}
