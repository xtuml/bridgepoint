//
// File: Sqlite__HeartRateMonitor__HeartRateMonitorMapper.cc
//
#include "Sqlite__HeartRateMonitor__HeartRateMonitor.hh"
#include "Sqlite__HeartRateMonitor__HeartRateMonitorMapper.hh"
#include "Sqlite__HeartRateMonitor__HeartRateMonitorMapperSql.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_HeartRateMonitor
  {
    maslo_HeartRateMonitorMapper::maslo_HeartRateMonitorMapper ( )
      : ::SQL::ObjectMapper< ::masld_HeartRateMonitor::maslo_HeartRateMonitor,maslo_HeartRateMonitor>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_HeartRateMonitor::maslo_HeartRateMonitor,maslo_HeartRateMonitor> >( new maslo_HeartRateMonitorSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_HeartRateMonitorMapper::~maslo_HeartRateMonitorMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> maslo_HeartRateMonitorMapper::createInstance ( int32_t                                                masla_recentHeartRate,
                                                                                                                       const ::SWA::EventTimers::TimerIdType&                 masla_timer,
                                                                                                                       int32_t                                                masla_id,
                                                                                                                       ::masld_HeartRateMonitor::maslo_HeartRateMonitor::Type currentState )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_HeartRateMonitor::PrimaryKeyType>::value_type( masla_id ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_HeartRateMonitor> instance(new maslo_HeartRateMonitor(  uniqueId,
                             masla_recentHeartRate,
                             masla_timer,
                             masla_id,
                             currentState ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_HeartRateMonitorMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> instance )
    {
      ::SQL::ObjectMapper< ::masld_HeartRateMonitor::maslo_HeartRateMonitor,maslo_HeartRateMonitor>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_HeartRateMonitor>()->getPrimaryKey() );
    }

    bool maslo_HeartRateMonitorMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
