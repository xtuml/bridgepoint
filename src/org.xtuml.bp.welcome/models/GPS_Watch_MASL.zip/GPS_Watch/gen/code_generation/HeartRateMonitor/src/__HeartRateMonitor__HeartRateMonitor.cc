//
// File: __HeartRateMonitor__HeartRateMonitor.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "__HeartRateMonitor__HeartRateMonitorEvents.hh"
#include "__HeartRateMonitor__HeartRateMonitorPopulation.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include <cstddef>
#include <iostream>
#include <stdexcept>
#include <stdint.h>
#include <string>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/NameFormatter.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProcessMonitor.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_HeartRateMonitor
{
  ::SWA::ObjectPtr<maslo_HeartRateMonitor> maslo_HeartRateMonitor::getInstance ( ::SWA::IdType id )
  {
    return maslo_HeartRateMonitorPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_HeartRateMonitor::getNextArchId ( )
  {
    return maslo_HeartRateMonitorPopulation::getSingleton().getNextArchId();
  }

  void maslo_HeartRateMonitor::process_maslo_HeartRateMonitor_maslev_timeout ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_monitoring:
      {
        state_maslst_monitoring();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_HeartRateMonitor, getArchitectureId(), getCurrentState(), maslst_monitoring );
        setCurrentState( maslst_monitoring );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_HeartRateMonitor, eventId_maslo_HeartRateMonitor_maslev_timeout ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_HeartRateMonitor ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_HeartRateMonitor, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_HeartRateMonitor::create_maslo_HeartRateMonitor_maslev_timeout ( int           sourceObj,
                                                                                                            ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_HeartRateMonitor_maslev_timeout());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_HeartRateMonitor::consume_maslo_HeartRateMonitor_maslev_timeout ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_HeartRateMonitor> instance = getInstance( id );
    if ( instance ) instance->process_maslo_HeartRateMonitor_maslev_timeout();
  }

  int Event_maslo_HeartRateMonitor_maslev_timeout::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_HeartRateMonitor_maslev_timeout::getObjectId ( ) const
  {
    return objectId_maslo_HeartRateMonitor;
  }

  int Event_maslo_HeartRateMonitor_maslev_timeout::getEventId ( ) const
  {
    return maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_timeout;
  }

  Event_maslo_HeartRateMonitor_maslev_timeout::Event_maslo_HeartRateMonitor_maslev_timeout ( )
  {
  }

  void Event_maslo_HeartRateMonitor_maslev_timeout::invoke ( ) const
  {
    maslo_HeartRateMonitor::consume_maslo_HeartRateMonitor_maslev_timeout( getDestInstanceId() );
  }

  void maslo_HeartRateMonitor::process_maslo_HeartRateMonitor_maslev_registerComplete ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_Registering:
      {
        state_maslst_monitoring();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_HeartRateMonitor, getArchitectureId(), getCurrentState(), maslst_monitoring );
        setCurrentState( maslst_monitoring );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_HeartRateMonitor, eventId_maslo_HeartRateMonitor_maslev_registerComplete ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_HeartRateMonitor ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_HeartRateMonitor, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_HeartRateMonitor::create_maslo_HeartRateMonitor_maslev_registerComplete ( int           sourceObj,
                                                                                                                     ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_HeartRateMonitor_maslev_registerComplete());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_HeartRateMonitor::consume_maslo_HeartRateMonitor_maslev_registerComplete ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_HeartRateMonitor> instance = getInstance( id );
    if ( instance ) instance->process_maslo_HeartRateMonitor_maslev_registerComplete();
  }

  int Event_maslo_HeartRateMonitor_maslev_registerComplete::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_HeartRateMonitor_maslev_registerComplete::getObjectId ( ) const
  {
    return objectId_maslo_HeartRateMonitor;
  }

  int Event_maslo_HeartRateMonitor_maslev_registerComplete::getEventId ( ) const
  {
    return maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_registerComplete;
  }

  Event_maslo_HeartRateMonitor_maslev_registerComplete::Event_maslo_HeartRateMonitor_maslev_registerComplete ( )
  {
  }

  void Event_maslo_HeartRateMonitor_maslev_registerComplete::invoke ( ) const
  {
    maslo_HeartRateMonitor::consume_maslo_HeartRateMonitor_maslev_registerComplete( getDestInstanceId() );
  }

  void maslo_HeartRateMonitor::process_maslo_HeartRateMonitor_maslev_unregisterComplete ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_Unregistering:
      {
        state_maslst_idle();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_HeartRateMonitor, getArchitectureId(), getCurrentState(), maslst_idle );
        setCurrentState( maslst_idle );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_HeartRateMonitor, eventId_maslo_HeartRateMonitor_maslev_unregisterComplete ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_HeartRateMonitor ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_HeartRateMonitor, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_HeartRateMonitor::create_maslo_HeartRateMonitor_maslev_unregisterComplete ( int           sourceObj,
                                                                                                                       ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_HeartRateMonitor_maslev_unregisterComplete());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_HeartRateMonitor::consume_maslo_HeartRateMonitor_maslev_unregisterComplete ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_HeartRateMonitor> instance = getInstance( id );
    if ( instance ) instance->process_maslo_HeartRateMonitor_maslev_unregisterComplete();
  }

  int Event_maslo_HeartRateMonitor_maslev_unregisterComplete::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_HeartRateMonitor_maslev_unregisterComplete::getObjectId ( ) const
  {
    return objectId_maslo_HeartRateMonitor;
  }

  int Event_maslo_HeartRateMonitor_maslev_unregisterComplete::getEventId ( ) const
  {
    return maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_unregisterComplete;
  }

  Event_maslo_HeartRateMonitor_maslev_unregisterComplete::Event_maslo_HeartRateMonitor_maslev_unregisterComplete ( )
  {
  }

  void Event_maslo_HeartRateMonitor_maslev_unregisterComplete::invoke ( ) const
  {
    maslo_HeartRateMonitor::consume_maslo_HeartRateMonitor_maslev_unregisterComplete( getDestInstanceId() );
  }

  void maslo_HeartRateMonitor::process_maslo_HeartRateMonitor_maslev_registerListener ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_idle:
      {
        state_maslst_Registering();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_HeartRateMonitor, getArchitectureId(), getCurrentState(), maslst_Registering );
        setCurrentState( maslst_Registering );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_HeartRateMonitor, eventId_maslo_HeartRateMonitor_maslev_registerListener ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_HeartRateMonitor ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_HeartRateMonitor, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_HeartRateMonitor::create_maslo_HeartRateMonitor_maslev_registerListener ( int           sourceObj,
                                                                                                                     ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_HeartRateMonitor_maslev_registerListener());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_HeartRateMonitor::consume_maslo_HeartRateMonitor_maslev_registerListener ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_HeartRateMonitor> instance = getInstance( id );
    if ( instance ) instance->process_maslo_HeartRateMonitor_maslev_registerListener();
  }

  int Event_maslo_HeartRateMonitor_maslev_registerListener::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_HeartRateMonitor_maslev_registerListener::getObjectId ( ) const
  {
    return objectId_maslo_HeartRateMonitor;
  }

  int Event_maslo_HeartRateMonitor_maslev_registerListener::getEventId ( ) const
  {
    return maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_registerListener;
  }

  Event_maslo_HeartRateMonitor_maslev_registerListener::Event_maslo_HeartRateMonitor_maslev_registerListener ( )
  {
  }

  void Event_maslo_HeartRateMonitor_maslev_registerListener::invoke ( ) const
  {
    maslo_HeartRateMonitor::consume_maslo_HeartRateMonitor_maslev_registerListener( getDestInstanceId() );
  }

  void maslo_HeartRateMonitor::process_maslo_HeartRateMonitor_maslev_unregisterListener ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_monitoring:
      {
        state_maslst_Unregistering();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_HeartRateMonitor, getArchitectureId(), getCurrentState(), maslst_Unregistering );
        setCurrentState( maslst_Unregistering );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_HeartRateMonitor, eventId_maslo_HeartRateMonitor_maslev_unregisterListener ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_HeartRateMonitor ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_id() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_HeartRateMonitor, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_HeartRateMonitor::create_maslo_HeartRateMonitor_maslev_unregisterListener ( int           sourceObj,
                                                                                                                       ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_HeartRateMonitor_maslev_unregisterListener());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_HeartRateMonitor::consume_maslo_HeartRateMonitor_maslev_unregisterListener ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_HeartRateMonitor> instance = getInstance( id );
    if ( instance ) instance->process_maslo_HeartRateMonitor_maslev_unregisterListener();
  }

  int Event_maslo_HeartRateMonitor_maslev_unregisterListener::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_HeartRateMonitor_maslev_unregisterListener::getObjectId ( ) const
  {
    return objectId_maslo_HeartRateMonitor;
  }

  int Event_maslo_HeartRateMonitor_maslev_unregisterListener::getEventId ( ) const
  {
    return maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_unregisterListener;
  }

  Event_maslo_HeartRateMonitor_maslev_unregisterListener::Event_maslo_HeartRateMonitor_maslev_unregisterListener ( )
  {
  }

  void Event_maslo_HeartRateMonitor_maslev_unregisterListener::invoke ( ) const
  {
    maslo_HeartRateMonitor::consume_maslo_HeartRateMonitor_maslev_unregisterListener( getDestInstanceId() );
  }

  maslo_HeartRateMonitor::maslo_HeartRateMonitor ( )
    : isDeletedFlag()
  {
  }

  maslo_HeartRateMonitor::~maslo_HeartRateMonitor ( )
  {
  }

  ::SWA::ObjectPtr<maslo_HeartRateMonitor> maslo_HeartRateMonitor::createInstance ( int32_t                                masla_recentHeartRate,
                                                                                    const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                                    int32_t                                masla_id,
                                                                                    Type                                   currentState )
  {
    return maslo_HeartRateMonitorPopulation::getSingleton().createInstance( masla_recentHeartRate, masla_timer, masla_id, currentState );
  }

  void maslo_HeartRateMonitor::deleteInstance ( )
  {
    maslo_HeartRateMonitorPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_HeartRateMonitor>( this ) );
    ::SWA::EventTimers::getInstance().deleteTimer( get_masla_timer() );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_HeartRateMonitor::getPopulationSize ( )
  {
    return maslo_HeartRateMonitorPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_HeartRateMonitor> > maslo_HeartRateMonitor::findAll ( )
  {
    return maslo_HeartRateMonitorPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_HeartRateMonitor> maslo_HeartRateMonitor::findOne ( )
  {
    return maslo_HeartRateMonitorPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_HeartRateMonitor> maslo_HeartRateMonitor::findOnly ( )
  {
    return maslo_HeartRateMonitorPopulation::getSingleton().findOnly();
  }

  ::std::ostream& operator<< ( ::std::ostream&               stream,
                               const maslo_HeartRateMonitor& obj )
  {
    stream << "(";
    stream << obj.get_masla_recentHeartRate();
    stream << ",";
    stream << obj.get_masla_timer();
    stream << ",";
    stream << obj.get_masla_id();
    stream << ")";
    return stream;
  }

}
