//
// File: MetaData__HeartRateMonitor.hh
//
#ifndef Heart_Rate_Monitor_OOA_Meta_Data_Heart_Rate_Monitor_hh
#define Heart_Rate_Monitor_OOA_Meta_Data_Heart_Rate_Monitor_hh

namespace masld_HeartRateMonitor
{
  enum TypeIds {};
}
#endif // Heart_Rate_Monitor_OOA_Meta_Data_Heart_Rate_Monitor_hh
