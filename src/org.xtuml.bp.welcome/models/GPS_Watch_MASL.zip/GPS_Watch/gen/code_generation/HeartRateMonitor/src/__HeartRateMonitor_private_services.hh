//
// File: __HeartRateMonitor_private_services.hh
//
#ifndef _Heart_Rate_Monitor_private_services_hh
#define _Heart_Rate_Monitor_private_services_hh

#endif // _Heart_Rate_Monitor_private_services_hh
