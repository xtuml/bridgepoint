//
// File: __HeartRateMonitor__HeartRateMonitorPopulation.hh
//
#ifndef _Heart_Rate_Monitor_Heart_Rate_Monitor_Population_hh
#define _Heart_Rate_Monitor_Heart_Rate_Monitor_Population_hh

#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/DynamicSingleton.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_HeartRateMonitor
{
  class maslo_HeartRateMonitorPopulation
    : public ::SWA::DynamicSingleton<maslo_HeartRateMonitorPopulation>
  {

    // Instance Creation
    public:
      virtual ::SWA::IdType getNextArchId ( ) = 0;
      virtual ::SWA::ObjectPtr<maslo_HeartRateMonitor> createInstance ( int32_t                                masla_recentHeartRate,
                                                                        const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                        int32_t                                masla_id,
                                                                        maslo_HeartRateMonitor::Type           currentState ) = 0;
      virtual void deleteInstance ( ::SWA::ObjectPtr<maslo_HeartRateMonitor> instance ) = 0;
      virtual ::std::size_t size ( ) const = 0;


    // Instance Retrieval
    public:
      virtual ::SWA::ObjectPtr<maslo_HeartRateMonitor> getInstance ( ::SWA::IdType id ) const = 0;
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_HeartRateMonitor> > findAll ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_HeartRateMonitor> findOne ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_HeartRateMonitor> findOnly ( ) const = 0;


    // Constructors and Destructors
    protected:
      maslo_HeartRateMonitorPopulation ( );
      virtual ~maslo_HeartRateMonitorPopulation ( );


    // Prevent copy
    private:
      maslo_HeartRateMonitorPopulation ( const maslo_HeartRateMonitorPopulation& rhs );
      maslo_HeartRateMonitorPopulation& operator= ( const maslo_HeartRateMonitorPopulation& rhs );


  };
}
#endif // _Heart_Rate_Monitor_Heart_Rate_Monitor_Population_hh
