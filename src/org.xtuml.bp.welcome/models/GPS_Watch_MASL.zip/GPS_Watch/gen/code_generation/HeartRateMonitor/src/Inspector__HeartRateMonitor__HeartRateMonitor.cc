//
// File: Inspector__HeartRateMonitor__HeartRateMonitor.cc
//
#include "Inspector__HeartRateMonitor__HeartRateMonitor.hh"
#include "__HeartRateMonitor__HeartRateConstants.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "__HeartRateMonitor__HeartRateMonitorEvents.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/EventHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include <string>
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_HeartRateMonitor
  {
    namespace maslo_HeartRateMonitor
    {
      class masls_initializeHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_initializeInvoker
      {

        public:
          masls_initializeInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_HeartRateMonitor::maslo_HeartRateMonitor::masls_initialize(); }


      };
      class maslst_idleHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_monitoringHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_RegisteringHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_UnregisteringHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslo_HeartRateMonitor_maslev_timeoutHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_HeartRateMonitor_maslev_registerCompleteHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_HeartRateMonitor_maslev_unregisterCompleteHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_HeartRateMonitor_maslev_registerListenerHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_HeartRateMonitor_maslev_unregisterListenerHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      Callable masls_initializeHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_initializeInvoker( channel );
      }

      void masls_initializeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write monitor
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> >();
              break;

          }

        }
      }

      void maslst_idleHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor>( frame.getThis< ::masld_HeartRateMonitor::maslo_HeartRateMonitor>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      void maslst_monitoringHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                      const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor>( frame.getThis< ::masld_HeartRateMonitor::maslo_HeartRateMonitor>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      void maslst_RegisteringHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                       const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor>( frame.getThis< ::masld_HeartRateMonitor::maslo_HeartRateMonitor>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write hrc
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateConstants> >();
              break;

          }

        }
      }

      void maslst_UnregisteringHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                         const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor>( frame.getThis< ::masld_HeartRateMonitor::maslo_HeartRateMonitor>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_HeartRateMonitor_maslev_timeoutHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_HeartRateMonitor_maslev_timeout( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_HeartRateMonitor_maslev_timeoutHandler::writeParameters ( const ::SWA::Event&   event,
                                                                           BufferedOutputStream& stream ) const
      {
        const ::masld_HeartRateMonitor::Event_maslo_HeartRateMonitor_maslev_timeout& typedEvent = dynamic_cast<const ::masld_HeartRateMonitor::Event_maslo_HeartRateMonitor_maslev_timeout&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_HeartRateMonitor_maslev_registerCompleteHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_HeartRateMonitor_maslev_registerComplete( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_HeartRateMonitor_maslev_registerCompleteHandler::writeParameters ( const ::SWA::Event&   event,
                                                                                    BufferedOutputStream& stream ) const
      {
        const ::masld_HeartRateMonitor::Event_maslo_HeartRateMonitor_maslev_registerComplete& typedEvent = dynamic_cast<const ::masld_HeartRateMonitor::Event_maslo_HeartRateMonitor_maslev_registerComplete&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_HeartRateMonitor_maslev_unregisterCompleteHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_HeartRateMonitor_maslev_unregisterComplete( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_HeartRateMonitor_maslev_unregisterCompleteHandler::writeParameters ( const ::SWA::Event&   event,
                                                                                      BufferedOutputStream& stream ) const
      {
        const ::masld_HeartRateMonitor::Event_maslo_HeartRateMonitor_maslev_unregisterComplete& typedEvent = dynamic_cast<const ::masld_HeartRateMonitor::Event_maslo_HeartRateMonitor_maslev_unregisterComplete&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_HeartRateMonitor_maslev_registerListenerHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_HeartRateMonitor_maslev_registerListener( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_HeartRateMonitor_maslev_registerListenerHandler::writeParameters ( const ::SWA::Event&   event,
                                                                                    BufferedOutputStream& stream ) const
      {
        const ::masld_HeartRateMonitor::Event_maslo_HeartRateMonitor_maslev_registerListener& typedEvent = dynamic_cast<const ::masld_HeartRateMonitor::Event_maslo_HeartRateMonitor_maslev_registerListener&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_HeartRateMonitor_maslev_unregisterListenerHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_HeartRateMonitor_maslev_unregisterListener( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_HeartRateMonitor_maslev_unregisterListenerHandler::writeParameters ( const ::SWA::Event&   event,
                                                                                      BufferedOutputStream& stream ) const
      {
        const ::masld_HeartRateMonitor::Event_maslo_HeartRateMonitor_maslev_unregisterListener& typedEvent = dynamic_cast<const ::masld_HeartRateMonitor::Event_maslo_HeartRateMonitor_maslev_unregisterListener&>( event );
      }

      maslo_HeartRateMonitorHandler::maslo_HeartRateMonitorHandler ( )
      {
        registerServiceHandler( ::masld_HeartRateMonitor::maslo_HeartRateMonitor::serviceId_masls_initialize, ::boost::shared_ptr<ActionHandler>( new masls_initializeHandler() ) );
        registerStateHandler( ::masld_HeartRateMonitor::maslo_HeartRateMonitor::stateId_maslst_idle, ::boost::shared_ptr<ActionHandler>( new maslst_idleHandler() ) );
        registerStateHandler( ::masld_HeartRateMonitor::maslo_HeartRateMonitor::stateId_maslst_monitoring, ::boost::shared_ptr<ActionHandler>( new maslst_monitoringHandler() ) );
        registerStateHandler( ::masld_HeartRateMonitor::maslo_HeartRateMonitor::stateId_maslst_Registering, ::boost::shared_ptr<ActionHandler>( new maslst_RegisteringHandler() ) );
        registerStateHandler( ::masld_HeartRateMonitor::maslo_HeartRateMonitor::stateId_maslst_Unregistering, ::boost::shared_ptr<ActionHandler>( new maslst_UnregisteringHandler() ) );
        registerEventHandler( ::masld_HeartRateMonitor::maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_timeout, ::boost::shared_ptr<EventHandler>( new maslo_HeartRateMonitor_maslev_timeoutHandler() ) );
        registerEventHandler( ::masld_HeartRateMonitor::maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_registerComplete, ::boost::shared_ptr<EventHandler>( new maslo_HeartRateMonitor_maslev_registerCompleteHandler() ) );
        registerEventHandler( ::masld_HeartRateMonitor::maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_unregisterComplete, ::boost::shared_ptr<EventHandler>( new maslo_HeartRateMonitor_maslev_unregisterCompleteHandler() ) );
        registerEventHandler( ::masld_HeartRateMonitor::maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_registerListener, ::boost::shared_ptr<EventHandler>( new maslo_HeartRateMonitor_maslev_registerListenerHandler() ) );
        registerEventHandler( ::masld_HeartRateMonitor::maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_unregisterListener, ::boost::shared_ptr<EventHandler>( new maslo_HeartRateMonitor_maslev_unregisterListenerHandler() ) );
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> ( const ::masld_HeartRateMonitor::maslo_HeartRateMonitor& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_recentHeartRate() );
    write( ::SWA::EventTimers::getInstance().getTimer( instance.get_masla_timer() ) );
    write( instance.get_masla_id() );
    write( static_cast<int>( instance.getCurrentState() ) );
  }

  namespace masld_HeartRateMonitor
  {
    namespace maslo_HeartRateMonitor
    {
      void maslo_HeartRateMonitorHandler::createInstance ( CommunicationChannel& channel ) const
      {
        int32_t masla_recentHeartRate;
        int32_t masla_id;
        int currentState;
        channel >> masla_recentHeartRate >> masla_id >> currentState;
        ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> instance = ::masld_HeartRateMonitor::maslo_HeartRateMonitor::createInstance( masla_recentHeartRate, ::SWA::EventTimers::getInstance().createTimer(), masla_id, ::masld_HeartRateMonitor::maslo_HeartRateMonitor::Type( currentState ) );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_HeartRateMonitorHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_id() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> > ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_HeartRateMonitor::maslo_HeartRateMonitor::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_HeartRateMonitor
  {
    namespace maslo_HeartRateMonitor
    {
      void maslo_HeartRateMonitorHandler::writeRelatedInstances ( CommunicationChannel&                                               channel,
                                                                  ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> instance,
                                                                  int                                                                 relId ) const
      {
        switch ( relId )
        {
        }

      }

    }
  }
}
