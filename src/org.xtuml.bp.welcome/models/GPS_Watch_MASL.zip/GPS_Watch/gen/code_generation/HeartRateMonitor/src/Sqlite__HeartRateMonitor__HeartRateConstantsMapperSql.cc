//
// File: Sqlite__HeartRateMonitor__HeartRateConstantsMapperSql.cc
//
#include "Sqlite__HeartRateMonitor__HeartRateConstants.hh"
#include "Sqlite__HeartRateMonitor__HeartRateConstantsMapperSql.hh"
#include "__HeartRateMonitor__HeartRateConstants.hh"
#include "boost/shared_ptr.hpp"
#include "boost/tuple/tuple_comparison.hpp"
#include <map>
#include "sql/Criteria.hh"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/Schema.hh"
#include "sql/Util.hh"
#include "sqlite/Database.hh"
#include "sqlite/Exception.hh"
#include "sqlite/Resultset.hh"
#include "sqlite/SqlMonitor.hh"
#include "sqlite3.h"
#include <stdint.h>
#include <string>
#include "swa/types.hh"

namespace 
{
  const ::std::string createTableStatment ( )
  {
    return "CREATE TABLE S_HeartRateMonitor_HEARTRATECONSTANTS(   architecture_id  INTEGER ,   masla_id INTEGER,   masla_HeartRateAveragingWindow INTEGER,   masla_HeartRateSamplingPeriod INTEGER, PRIMARY KEY (architecture_id));\n";
  }

  bool registerSchema = ::SQL::Schema::singleton().registerTable( "S_HeartRateMonitor_HEARTRATECONSTANTS", createTableStatment() );

}
namespace SQLITE
{
  namespace masld_HeartRateMonitor
  {
    maslo_HeartRateConstantsSqlGenerator::maslo_HeartRateConstantsSqlGenerator ( )
      : tableName("S_HeartRateMonitor_HEARTRATECONSTANTS"),
        objectName("HeartRateConstants"),
        insertStatement("INSERT INTO S_HeartRateMonitor_HEARTRATECONSTANTS VALUES(:1,:2,:3,:4);"),
        updateStatement("UPDATE S_HeartRateMonitor_HEARTRATECONSTANTS SET masla_id = :2  , masla_HeartRateAveragingWindow = :3  , masla_HeartRateSamplingPeriod = :4  WHERE architecture_id = :1;"),
        deleteStatement("DELETE  FROM S_HeartRateMonitor_HEARTRATECONSTANTS WHERE architecture_id = :1;"),
        columnNameMapper()
    {
    }

    maslo_HeartRateConstantsSqlGenerator::~maslo_HeartRateConstantsSqlGenerator ( )
    {
    }

    void maslo_HeartRateConstantsSqlGenerator::initialise ( )
    {
      columnNameMapper["architecture_id"] = ::std::string( "architecture_id" );
      columnNameMapper["id"] = ::std::string( "masla_id" );
      columnNameMapper["HeartRateAveragingWindow"] = ::std::string( "masla_HeartRateAveragingWindow" );
      columnNameMapper["HeartRateSamplingPeriod"] = ::std::string( "masla_HeartRateSamplingPeriod" );
      insertStatement.prepare();
      updateStatement.prepare();
      deleteStatement.prepare();
    }

    const ::std::string maslo_HeartRateConstantsSqlGenerator::getDomainName ( ) const
    {
      return "HeartRateMonitor";
    }

    const ::std::string& maslo_HeartRateConstantsSqlGenerator::getTableName ( ) const
    {
      return tableName;
    }

    const ::std::string& maslo_HeartRateConstantsSqlGenerator::getObjectName ( ) const
    {
      return objectName;
    }

    const ::std::string maslo_HeartRateConstantsSqlGenerator::getColumnName ( const ::std::string& attribute ) const
    {
      ::std::map< ::std::string,::std::string>::const_iterator requiredNameItr = columnNameMapper.find( attribute );
      if ( requiredNameItr == columnNameMapper.end() )
      {
        throw SqliteException( "maslo_HeartRateConstantsSqlGenerator::getColumnName - failed to find attribute name " );
      }
      return requiredNameItr->second;
    }

    void maslo_HeartRateConstantsSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                          int32_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_HeartRateMonitor_HEARTRATECONSTANTS;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_HeartRateConstantsSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_HeartRateConstantsSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    void maslo_HeartRateConstantsSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                          int64_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_HeartRateMonitor_HEARTRATECONSTANTS;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_HeartRateConstantsSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int64_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_HeartRateConstantsSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    ::SWA::IdType maslo_HeartRateConstantsSqlGenerator::executeGetRowCount ( ) const
    {
      int32_t rowCount = 0;
      ::std::string valueSelect("SELECT count(*) FROM S_HeartRateMonitor_HEARTRATECONSTANTS;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_HeartRateConstantsSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          rowCount = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_HeartRateConstantsSqlGenerator::executeGetRowCount - query failed" );
      }
      return rowCount;
    }

    ::SWA::IdType maslo_HeartRateConstantsSqlGenerator::executeGetMaxIdentifier ( ) const
    {
      ::SWA::IdType maxIdValue = 0;
      executeGetMaxColumnValue( "architecture_id", maxIdValue );
      return maxIdValue;
    }

    void maslo_HeartRateConstantsSqlGenerator::executeUpdate ( const PsObjectPtr& object ) const
    {
      updateStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_id(), object.getChecked()->get_masla_HeartRateAveragingWindow(), object.getChecked()->get_masla_HeartRateSamplingPeriod() ) );
    }

    void maslo_HeartRateConstantsSqlGenerator::executeInsert ( const PsObjectPtr& object ) const
    {
      insertStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_id(), object.getChecked()->get_masla_HeartRateAveragingWindow(), object.getChecked()->get_masla_HeartRateSamplingPeriod() ) );
    }

    void maslo_HeartRateConstantsSqlGenerator::executeRemove ( const PsObjectPtr& object ) const
    {
      deleteStatement.execute( object.getChecked()->getArchitectureId() );
    }

    void maslo_HeartRateConstantsSqlGenerator::executeRemoveId ( const ::SWA::IdType object ) const
    {
      deleteStatement.execute( object );
    }

    void maslo_HeartRateConstantsSqlGenerator::executeSelect ( CacheType&             cache,
                                                               const ::SQL::Criteria& criteria,
                                                               PsBaseObjectPtrSwaSet& result ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("HeartRateConstants::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "HeartRateConstants::executeSelect", compile_result, query );
        database.checkColumnCount( "HeartRateConstants::executeSelect", sqlite3_column_count( ppStmt ), 4, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr != cache.end() )
          {
            PsBaseObjectPtr currentObject(objectItr->second.get());
            result += currentObject;
          }
          else
          {
            PsObjectPtr currentObject(new maslo_HeartRateConstants(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );
            result += currentObject;

            int32_t id = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_id( id );

            int32_t HeartRateAveragingWindow = sqlite3_column_int( ppStmt, 2 );
            currentObject->set_masla_HeartRateAveragingWindow( HeartRateAveragingWindow );

            int32_t HeartRateSamplingPeriod = sqlite3_column_int( ppStmt, 3 );
            currentObject->set_masla_HeartRateSamplingPeriod( HeartRateSamplingPeriod );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

    void maslo_HeartRateConstantsSqlGenerator::executeSelect ( CacheType&             cache,
                                                               const ::SQL::Criteria& criteria ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("HeartRateConstants::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "HeartRateConstants::executeSelect", compile_result, query );
        database.checkColumnCount( "HeartRateConstants::executeSelect", sqlite3_column_count( ppStmt ), 4, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr == cache.end() )
          {
            PsObjectPtr currentObject(new maslo_HeartRateConstants(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );

            int32_t id = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_id( id );

            int32_t HeartRateAveragingWindow = sqlite3_column_int( ppStmt, 2 );
            currentObject->set_masla_HeartRateAveragingWindow( HeartRateAveragingWindow );

            int32_t HeartRateSamplingPeriod = sqlite3_column_int( ppStmt, 3 );
            currentObject->set_masla_HeartRateSamplingPeriod( HeartRateSamplingPeriod );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

  }
}
