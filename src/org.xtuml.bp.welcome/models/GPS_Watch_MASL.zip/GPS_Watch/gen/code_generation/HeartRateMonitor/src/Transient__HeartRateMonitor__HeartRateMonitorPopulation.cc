//
// File: Transient__HeartRateMonitor__HeartRateMonitorPopulation.cc
//
#include "Transient__HeartRateMonitor__HeartRateMonitor.hh"
#include "Transient__HeartRateMonitor__HeartRateMonitorPopulation.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"

namespace transient
{
  namespace masld_HeartRateMonitor
  {
    maslo_HeartRateMonitorPopulation::maslo_HeartRateMonitorPopulation ( )
      : masla_id_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> maslo_HeartRateMonitorPopulation::createInstance ( int32_t                                                masla_recentHeartRate,
                                                                                                                           const ::SWA::EventTimers::TimerIdType&                 masla_timer,
                                                                                                                           int32_t                                                masla_id,
                                                                                                                           ::masld_HeartRateMonitor::maslo_HeartRateMonitor::Type currentState )
    {
      if ( exists_masla_id( masla_id ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> instance(new maslo_HeartRateMonitor(  masla_recentHeartRate,
                             masla_timer,
                             masla_id,
                             currentState ));
      addInstance( instance );
      return instance;
    }

    void maslo_HeartRateMonitorPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> instance )
    {
      masla_id_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> >::value_type( ::boost::make_tuple( instance->get_masla_id() ), instance ) );
    }

    void maslo_HeartRateMonitorPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> instance )
    {
      masla_id_Lookup.erase( ::boost::make_tuple( instance->get_masla_id() ) );
    }

    bool maslo_HeartRateMonitorPopulation::exists_masla_id ( int32_t masla_id ) const
    {
      return masla_id_Lookup.find( ::boost::make_tuple( masla_id ) ) != masla_id_Lookup.end();
    }

    maslo_HeartRateMonitorPopulation& maslo_HeartRateMonitorPopulation::getPopulation ( )
    {
      static maslo_HeartRateMonitorPopulation population;
      return population;
    }

    bool maslo_HeartRateMonitorPopulation::registered = maslo_HeartRateMonitorPopulation::registerSingleton( &maslo_HeartRateMonitorPopulation::getPopulation );

  }
}
