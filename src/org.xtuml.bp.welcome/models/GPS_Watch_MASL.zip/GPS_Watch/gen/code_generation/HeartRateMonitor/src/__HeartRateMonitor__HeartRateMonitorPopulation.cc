//
// File: __HeartRateMonitor__HeartRateMonitorPopulation.cc
//
#include "__HeartRateMonitor__HeartRateMonitorPopulation.hh"

namespace masld_HeartRateMonitor
{
  maslo_HeartRateMonitorPopulation::maslo_HeartRateMonitorPopulation ( )
  {
  }

  maslo_HeartRateMonitorPopulation::~maslo_HeartRateMonitorPopulation ( )
  {
  }

}
