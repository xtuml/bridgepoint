//
// File: Sqlite__HeartRateMonitor__HeartRateConstantsMapper.hh
//
#ifndef Sqlite_Heart_Rate_Monitor_Heart_Rate_Constants_Mapper_hh
#define Sqlite_Heart_Rate_Monitor_Heart_Rate_Constants_Mapper_hh

#include "Sqlite__HeartRateMonitor__HeartRateConstants.hh"
#include "__HeartRateMonitor__HeartRateConstants.hh"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"

namespace SQLITE
{
  namespace masld_HeartRateMonitor
  {
    class maslo_HeartRateConstantsMapper
      : public ::SQL::ObjectMapper< ::masld_HeartRateMonitor::maslo_HeartRateConstants,maslo_HeartRateConstants>
    {

      // Instance creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateConstants> createInstance ( int32_t masla_id,
                                                                                                       int32_t masla_HeartRateAveragingWindow,
                                                                                                       int32_t masla_HeartRateSamplingPeriod );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateConstants> instance );
      protected:
        virtual bool doPostInit ( );


      // Constructors and Destructors
      public:
        maslo_HeartRateConstantsMapper ( );
        virtual ~maslo_HeartRateConstantsMapper ( );


      // Attributes
      private:
        ::boost::unordered_set<maslo_HeartRateConstants::PrimaryKeyType> primarykey_cache;


    };
  }
}
#endif // Sqlite_Heart_Rate_Monitor_Heart_Rate_Constants_Mapper_hh
