//
// File: __HeartRateMonitor.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "swa/Domain.hh"

namespace masld_HeartRateMonitor
{
  bool initialiseDomain ( )
  {
    getDomain().setInterface( false );
    return true;
  }

  const bool domainInitialised = initialiseDomain();

}
