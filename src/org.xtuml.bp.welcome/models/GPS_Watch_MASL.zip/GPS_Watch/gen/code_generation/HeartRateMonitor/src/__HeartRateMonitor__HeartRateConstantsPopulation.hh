//
// File: __HeartRateMonitor__HeartRateConstantsPopulation.hh
//
#ifndef _Heart_Rate_Monitor_Heart_Rate_Constants_Population_hh
#define _Heart_Rate_Monitor_Heart_Rate_Constants_Population_hh

#include <cstddef>
#include <stdint.h>
#include "swa/DynamicSingleton.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_HeartRateMonitor
{
  class maslo_HeartRateConstants;
  class maslo_HeartRateConstantsPopulation
    : public ::SWA::DynamicSingleton<maslo_HeartRateConstantsPopulation>
  {

    // Instance Creation
    public:
      virtual ::SWA::IdType getNextArchId ( ) = 0;
      virtual ::SWA::ObjectPtr<maslo_HeartRateConstants> createInstance ( int32_t masla_id,
                                                                          int32_t masla_HeartRateAveragingWindow,
                                                                          int32_t masla_HeartRateSamplingPeriod ) = 0;
      virtual void deleteInstance ( ::SWA::ObjectPtr<maslo_HeartRateConstants> instance ) = 0;
      virtual ::std::size_t size ( ) const = 0;


    // Instance Retrieval
    public:
      virtual ::SWA::ObjectPtr<maslo_HeartRateConstants> getInstance ( ::SWA::IdType id ) const = 0;
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_HeartRateConstants> > findAll ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_HeartRateConstants> findOne ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_HeartRateConstants> findOnly ( ) const = 0;


    // Constructors and Destructors
    protected:
      maslo_HeartRateConstantsPopulation ( );
      virtual ~maslo_HeartRateConstantsPopulation ( );


    // Prevent copy
    private:
      maslo_HeartRateConstantsPopulation ( const maslo_HeartRateConstantsPopulation& rhs );
      maslo_HeartRateConstantsPopulation& operator= ( const maslo_HeartRateConstantsPopulation& rhs );


  };
}
#endif // _Heart_Rate_Monitor_Heart_Rate_Constants_Population_hh
