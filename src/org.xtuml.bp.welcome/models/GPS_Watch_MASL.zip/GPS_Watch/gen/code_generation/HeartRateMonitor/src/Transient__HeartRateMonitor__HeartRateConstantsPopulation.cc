//
// File: Transient__HeartRateMonitor__HeartRateConstantsPopulation.cc
//
#include "Transient__HeartRateMonitor__HeartRateConstants.hh"
#include "Transient__HeartRateMonitor__HeartRateConstantsPopulation.hh"
#include "__HeartRateMonitor__HeartRateConstants.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"

namespace transient
{
  namespace masld_HeartRateMonitor
  {
    maslo_HeartRateConstantsPopulation::maslo_HeartRateConstantsPopulation ( )
      : masla_id_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateConstants> maslo_HeartRateConstantsPopulation::createInstance ( int32_t masla_id,
                                                                                                                               int32_t masla_HeartRateAveragingWindow,
                                                                                                                               int32_t masla_HeartRateSamplingPeriod )
    {
      if ( exists_masla_id( masla_id ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateConstants> instance(new maslo_HeartRateConstants(  masla_id,
                               masla_HeartRateAveragingWindow,
                               masla_HeartRateSamplingPeriod ));
      addInstance( instance );
      return instance;
    }

    void maslo_HeartRateConstantsPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateConstants> instance )
    {
      masla_id_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateConstants> >::value_type( ::boost::make_tuple( instance->get_masla_id() ), instance ) );
    }

    void maslo_HeartRateConstantsPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateConstants> instance )
    {
      masla_id_Lookup.erase( ::boost::make_tuple( instance->get_masla_id() ) );
    }

    bool maslo_HeartRateConstantsPopulation::exists_masla_id ( int32_t masla_id ) const
    {
      return masla_id_Lookup.find( ::boost::make_tuple( masla_id ) ) != masla_id_Lookup.end();
    }

    maslo_HeartRateConstantsPopulation& maslo_HeartRateConstantsPopulation::getPopulation ( )
    {
      static maslo_HeartRateConstantsPopulation population;
      return population;
    }

    bool maslo_HeartRateConstantsPopulation::registered = maslo_HeartRateConstantsPopulation::registerSingleton( &maslo_HeartRateConstantsPopulation::getPopulation );

  }
}
