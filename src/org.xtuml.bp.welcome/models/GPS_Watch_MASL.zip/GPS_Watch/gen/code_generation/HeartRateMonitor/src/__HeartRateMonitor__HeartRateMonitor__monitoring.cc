//
// File: __HeartRateMonitor__HeartRateMonitor__monitoring.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_terminators.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_HeartRateMonitor
{
  void maslo_HeartRateMonitor::state_maslst_monitoring ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_HeartRateMonitor, stateId_maslst_monitoring);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // HRChange~>heartRateChanged(this.recentHeartRate)
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          maslb_HRChange::masls_heartRateChanged( ::SWA::ObjectPtr<maslo_HeartRateMonitor>( this )->get_masla_recentHeartRate() );
        }

        // this.recentHeartRate := (this.recentHeartRate + 1);
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          ::SWA::ObjectPtr<maslo_HeartRateMonitor>( this )->set_masla_recentHeartRate( ::SWA::ObjectPtr<maslo_HeartRateMonitor>( this )->get_masla_recentHeartRate() + 1ll );
        }
      }
    }
  }

}
