//
// File: Inspector_private_types__HeartRateMonitor.cc
//
