//
// File: Transient__Tracking__GoalPopulation.cc
//
#include "Tracking_OOA/__Tracking_types.hh"
#include "Transient__Tracking__Goal.hh"
#include "Transient__Tracking__GoalPopulation.hh"
#include "__Tracking__Goal.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Timestamp.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_GoalPopulation::maslo_GoalPopulation ( )
      : masla_IDmasla_session_startTimemasla_spec_sequenceNumber_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> maslo_GoalPopulation::createInstance ( const ::masld_Tracking::maslt_GoalDisposition& masla_disposition,
                                                                                           double                                         masla_startingPoint,
                                                                                           int32_t                                        masla_ID,
                                                                                           const ::SWA::EventTimers::TimerIdType&         masla_evaluationTimer,
                                                                                           const ::SWA::Timestamp&                        masla_session_startTime,
                                                                                           int32_t                                        masla_spec_sequenceNumber,
                                                                                           ::masld_Tracking::maslo_Goal::Type             currentState )
    {
      if ( exists_masla_IDmasla_session_startTimemasla_spec_sequenceNumber( masla_ID, masla_session_startTime, masla_spec_sequenceNumber ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> instance(new maslo_Goal(  masla_disposition,
                 masla_startingPoint,
                 masla_ID,
                 masla_evaluationTimer,
                 masla_session_startTime,
                 masla_spec_sequenceNumber,
                 currentState ));
      addInstance( instance );
      return instance;
    }

    void maslo_GoalPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> instance )
    {
      masla_IDmasla_session_startTimemasla_spec_sequenceNumber_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t,::SWA::Timestamp,int32_t>,::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> >::value_type( ::boost::make_tuple( instance->get_masla_ID(), instance->get_masla_session_startTime(), instance->get_masla_spec_sequenceNumber() ), instance ) );
    }

    void maslo_GoalPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> instance )
    {
      masla_IDmasla_session_startTimemasla_spec_sequenceNumber_Lookup.erase( ::boost::make_tuple( instance->get_masla_ID(), instance->get_masla_session_startTime(), instance->get_masla_spec_sequenceNumber() ) );
    }

    bool maslo_GoalPopulation::exists_masla_IDmasla_session_startTimemasla_spec_sequenceNumber ( int32_t                 masla_ID,
                                                                                                 const ::SWA::Timestamp& masla_session_startTime,
                                                                                                 int32_t                 masla_spec_sequenceNumber ) const
    {
      return masla_IDmasla_session_startTimemasla_spec_sequenceNumber_Lookup.find( ::boost::make_tuple( masla_ID, masla_session_startTime, masla_spec_sequenceNumber ) ) != masla_IDmasla_session_startTimemasla_spec_sequenceNumber_Lookup.end();
    }

    maslo_GoalPopulation& maslo_GoalPopulation::getPopulation ( )
    {
      static maslo_GoalPopulation population;
      return population;
    }

    bool maslo_GoalPopulation::registered = maslo_GoalPopulation::registerSingleton( &maslo_GoalPopulation::getPopulation );

  }
}
