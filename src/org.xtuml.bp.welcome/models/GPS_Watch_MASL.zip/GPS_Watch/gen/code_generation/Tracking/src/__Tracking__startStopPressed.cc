//
// File: __Tracking__startStopPressed.cc
//
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_services.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/shared_ptr.hpp"
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  void masls_startStopPressed ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_startStopPressed);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // workoutTimer : instance of WorkoutTimer;
        ::SWA::ObjectPtr<maslo_WorkoutTimer> maslv_workoutTimer;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_workoutTimer(0, maslv_workoutTimer);

        // WorkoutSession.initialize()
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          maslo_WorkoutSession::masls_initialize();
        }

        // workoutTimer := find_one WorkoutTimer ();
        {
          ::SWA::Stack::ExecutingStatement statement(10);
          maslv_workoutTimer = maslo_WorkoutTimer::findOne();
        }

        // generate WorkoutTimer.startStopPressed () to workoutTimer;
        {
          ::SWA::Stack::ExecutingStatement statement(11);
          ::SWA::Process::getInstance().getEventQueue().addEvent( maslv_workoutTimer->create_maslo_WorkoutTimer_maslev_startStopPressed() );
        }
      }
    }
  }

  const bool localServiceRegistration_masls_startStopPressed = interceptor_masls_startStopPressed::instance().registerLocal( &masls_startStopPressed );

}
