//
// File: Transient__Tracking__TrackPoint.cc
//
#include "Transient__Tracking__TrackLog.hh"
#include "Transient__Tracking__TrackPoint.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__TrackPoint.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "transient/ToOneRelationship.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_TrackPoint::maslo_TrackPoint ( int32_t                 masla_time,
                                         double                  masla_longitude,
                                         double                  masla_latitude,
                                         const ::SWA::Timestamp& masla_session_startTime )
      : architectureId(getNextArchId()),
        masla_time(masla_time),
        masla_longitude(masla_longitude),
        masla_latitude(masla_latitude),
        masla_session_startTime(masla_session_startTime),
        R1_is_start_of_TrackLog(),
        R2_follows_TrackPoint(),
        R2_preceeds_TrackPoint(),
        R3_is_last_for_TrackLog()
    {
    }

    ToOneRelationship<maslo_TrackLog>& maslo_TrackPoint::get_R1_is_start_of_TrackLog ( )
    {
      return R1_is_start_of_TrackLog;
    }

    const ToOneRelationship<maslo_TrackLog>& maslo_TrackPoint::get_R1_is_start_of_TrackLog ( ) const
    {
      return R1_is_start_of_TrackLog;
    }

    ToOneRelationship<maslo_TrackPoint>& maslo_TrackPoint::get_R2_follows_TrackPoint ( )
    {
      return R2_follows_TrackPoint;
    }

    const ToOneRelationship<maslo_TrackPoint>& maslo_TrackPoint::get_R2_follows_TrackPoint ( ) const
    {
      return R2_follows_TrackPoint;
    }

    ToOneRelationship<maslo_TrackPoint>& maslo_TrackPoint::get_R2_preceeds_TrackPoint ( )
    {
      return R2_preceeds_TrackPoint;
    }

    const ToOneRelationship<maslo_TrackPoint>& maslo_TrackPoint::get_R2_preceeds_TrackPoint ( ) const
    {
      return R2_preceeds_TrackPoint;
    }

    ToOneRelationship<maslo_TrackLog>& maslo_TrackPoint::get_R3_is_last_for_TrackLog ( )
    {
      return R3_is_last_for_TrackLog;
    }

    const ToOneRelationship<maslo_TrackLog>& maslo_TrackPoint::get_R3_is_last_for_TrackLog ( ) const
    {
      return R3_is_last_for_TrackLog;
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> maslo_TrackPoint::navigate_R1_is_start_of_TrackLog ( ) const
    {
      return get_R1_is_start_of_TrackLog().navigate();
    }

    ::std::size_t maslo_TrackPoint::count_R1_is_start_of_TrackLog ( ) const
    {
      return get_R1_is_start_of_TrackLog().count();
    }

    void maslo_TrackPoint::link_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackLog> rhs2 = rhs.downcast<maslo_TrackLog>();
      this->get_R1_is_start_of_TrackLog().link( rhs2 );
      try
      {
        rhs2->get_R1_has_first_TrackPoint().link( ::SWA::ObjectPtr<maslo_TrackPoint>( this ) );
      }
      catch ( ... )
      {
        this->get_R1_is_start_of_TrackLog().unlink( rhs2 );
        throw;
      }
    }

    void maslo_TrackPoint::unlink_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackLog> rhs2 = rhs.downcast<maslo_TrackLog>();
      this->get_R1_is_start_of_TrackLog().unlink( rhs2 );
      try
      {
        rhs2->get_R1_has_first_TrackPoint().unlink( ::SWA::ObjectPtr<maslo_TrackPoint>( this ) );
      }
      catch ( ... )
      {
        this->get_R1_is_start_of_TrackLog().link( rhs2 );
        throw;
      }
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> maslo_TrackPoint::navigate_R2_follows_TrackPoint ( ) const
    {
      return get_R2_follows_TrackPoint().navigate();
    }

    ::std::size_t maslo_TrackPoint::count_R2_follows_TrackPoint ( ) const
    {
      return get_R2_follows_TrackPoint().count();
    }

    void maslo_TrackPoint::link_R2_follows_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> rhs2 = rhs.downcast<maslo_TrackPoint>();
      this->get_R2_follows_TrackPoint().link( rhs2 );
      try
      {
        rhs2->get_R2_preceeds_TrackPoint().link( ::SWA::ObjectPtr<maslo_TrackPoint>( this ) );
      }
      catch ( ... )
      {
        this->get_R2_follows_TrackPoint().unlink( rhs2 );
        throw;
      }
    }

    void maslo_TrackPoint::unlink_R2_follows_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> rhs2 = rhs.downcast<maslo_TrackPoint>();
      this->get_R2_follows_TrackPoint().unlink( rhs2 );
      try
      {
        rhs2->get_R2_preceeds_TrackPoint().unlink( ::SWA::ObjectPtr<maslo_TrackPoint>( this ) );
      }
      catch ( ... )
      {
        this->get_R2_follows_TrackPoint().link( rhs2 );
        throw;
      }
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> maslo_TrackPoint::navigate_R2_preceeds_TrackPoint ( ) const
    {
      return get_R2_preceeds_TrackPoint().navigate();
    }

    ::std::size_t maslo_TrackPoint::count_R2_preceeds_TrackPoint ( ) const
    {
      return get_R2_preceeds_TrackPoint().count();
    }

    void maslo_TrackPoint::link_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> rhs2 = rhs.downcast<maslo_TrackPoint>();
      this->get_R2_preceeds_TrackPoint().link( rhs2 );
      try
      {
        rhs2->get_R2_follows_TrackPoint().link( ::SWA::ObjectPtr<maslo_TrackPoint>( this ) );
      }
      catch ( ... )
      {
        this->get_R2_preceeds_TrackPoint().unlink( rhs2 );
        throw;
      }
    }

    void maslo_TrackPoint::unlink_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> rhs2 = rhs.downcast<maslo_TrackPoint>();
      this->get_R2_preceeds_TrackPoint().unlink( rhs2 );
      try
      {
        rhs2->get_R2_follows_TrackPoint().unlink( ::SWA::ObjectPtr<maslo_TrackPoint>( this ) );
      }
      catch ( ... )
      {
        this->get_R2_preceeds_TrackPoint().link( rhs2 );
        throw;
      }
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> maslo_TrackPoint::navigate_R3_is_last_for_TrackLog ( ) const
    {
      return get_R3_is_last_for_TrackLog().navigate();
    }

    ::std::size_t maslo_TrackPoint::count_R3_is_last_for_TrackLog ( ) const
    {
      return get_R3_is_last_for_TrackLog().count();
    }

    void maslo_TrackPoint::link_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackLog> rhs2 = rhs.downcast<maslo_TrackLog>();
      this->get_R3_is_last_for_TrackLog().link( rhs2 );
      try
      {
        rhs2->get_R3_has_last_TrackPoint().link( ::SWA::ObjectPtr<maslo_TrackPoint>( this ) );
      }
      catch ( ... )
      {
        this->get_R3_is_last_for_TrackLog().unlink( rhs2 );
        throw;
      }
    }

    void maslo_TrackPoint::unlink_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackLog> rhs2 = rhs.downcast<maslo_TrackLog>();
      this->get_R3_is_last_for_TrackLog().unlink( rhs2 );
      try
      {
        rhs2->get_R3_has_last_TrackPoint().unlink( ::SWA::ObjectPtr<maslo_TrackPoint>( this ) );
      }
      catch ( ... )
      {
        this->get_R3_is_last_for_TrackLog().link( rhs2 );
        throw;
      }
    }

  }
}
