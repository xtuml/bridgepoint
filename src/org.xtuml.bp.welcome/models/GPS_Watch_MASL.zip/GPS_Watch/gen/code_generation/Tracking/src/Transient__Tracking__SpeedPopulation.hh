//
// File: Transient__Tracking__SpeedPopulation.hh
//
#ifndef Transient_Tracking_Speed_Population_hh
#define Transient_Tracking_Speed_Population_hh

#include "__Tracking__Speed.hh"
#include "__Tracking__SpeedPopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace transient
{
  namespace masld_Tracking
  {
    class maslo_SpeedPopulation
      : public TransientPopulation< ::masld_Tracking::maslo_Speed,::masld_Tracking::maslo_SpeedPopulation>
    {

      // Instance Creation
      private:
        maslo_SpeedPopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> createInstance ( int32_t masla_id,
                                                                                  int32_t masla_SpeedAveragingWindow,
                                                                                  int32_t masla_SecondsPerHour );


      // Singleton Registration
      public:
        static maslo_SpeedPopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> > masla_id_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> instance );
      protected:
        bool exists_masla_id ( int32_t masla_id ) const;


    };
  }
}
#endif // Transient_Tracking_Speed_Population_hh
