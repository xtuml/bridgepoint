//
// File: Inspector__Tracking__Speed.cc
//
#include "Inspector__Tracking__Speed.hh"
#include "__Tracking__Speed.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include <string>
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_Speed
    {
      class masls_initializeHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_initializeInvoker
      {

        public:
          masls_initializeInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_Tracking::maslo_Speed::masls_initialize(); }


      };
      Callable masls_initializeHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_initializeInvoker( channel );
      }

      void masls_initializeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write speed
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> >();
              break;

          }

        }
      }

      maslo_SpeedHandler::maslo_SpeedHandler ( )
      {
        registerServiceHandler( ::masld_Tracking::maslo_Speed::serviceId_masls_initialize, ::boost::shared_ptr<ActionHandler>( new masls_initializeHandler() ) );
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslo_Speed> ( const ::masld_Tracking::maslo_Speed& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_id() );
    write( instance.get_masla_SpeedAveragingWindow() );
    write( instance.get_masla_SecondsPerHour() );
  }

  namespace masld_Tracking
  {
    namespace maslo_Speed
    {
      void maslo_SpeedHandler::createInstance ( CommunicationChannel& channel ) const
      {
        int32_t masla_id;
        int32_t masla_SpeedAveragingWindow;
        int32_t masla_SecondsPerHour;
        channel >> masla_id >> masla_SpeedAveragingWindow >> masla_SecondsPerHour;
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> instance = ::masld_Tracking::maslo_Speed::createInstance( masla_id, masla_SpeedAveragingWindow, masla_SecondsPerHour );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_SpeedHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_id() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> > ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_Tracking::maslo_Speed::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_Tracking
  {
    namespace maslo_Speed
    {
      void maslo_SpeedHandler::writeRelatedInstances ( CommunicationChannel&                            channel,
                                                       ::SWA::ObjectPtr< ::masld_Tracking::maslo_Speed> instance,
                                                       int                                              relId ) const
      {
        switch ( relId )
        {
        }

      }

    }
  }
}
