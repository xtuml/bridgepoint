//
// File: __Tracking__Display.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__DisplayEvents.hh"
#include "__Tracking__DisplayPopulation.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include <cstddef>
#include <iostream>
#include <stdexcept>
#include <string>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/NameFormatter.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProcessMonitor.hh"
#include "swa/ProgramError.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  ::SWA::ObjectPtr<maslo_Display> maslo_Display::getInstance ( ::SWA::IdType id )
  {
    return maslo_DisplayPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_Display::getNextArchId ( )
  {
    return maslo_DisplayPopulation::getSingleton().getNextArchId();
  }

  void maslo_Display::process_maslo_Display_maslev_modeChange ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_displayDistance:
      {
        state_maslst_displaySpeed();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_Display, getArchitectureId(), getCurrentState(), maslst_displaySpeed );
        setCurrentState( maslst_displaySpeed );
        break;
      }
      case maslst_displaySpeed:
      {
        state_maslst_displayPace();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_Display, getArchitectureId(), getCurrentState(), maslst_displayPace );
        setCurrentState( maslst_displayPace );
        break;
      }
      case maslst_displayPace:
      {
        state_maslst_displayHeartRate();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_Display, getArchitectureId(), getCurrentState(), maslst_displayHeartRate );
        setCurrentState( maslst_displayHeartRate );
        break;
      }
      case maslst_displayHeartRate:
      {
        state_maslst_displayLapCount();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_Display, getArchitectureId(), getCurrentState(), maslst_displayLapCount );
        setCurrentState( maslst_displayLapCount );
        break;
      }
      case maslst_displayLapCount:
      {
        state_maslst_displayDistance();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_Display, getArchitectureId(), getCurrentState(), maslst_displayDistance );
        setCurrentState( maslst_displayDistance );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_Display, eventId_maslo_Display_maslev_modeChange ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_Display ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_session_startTime() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_Display, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_Display::create_maslo_Display_maslev_modeChange ( int           sourceObj,
                                                                                             ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_Display_maslev_modeChange());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_Display::consume_maslo_Display_maslev_modeChange ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_Display> instance = getInstance( id );
    if ( instance ) instance->process_maslo_Display_maslev_modeChange();
  }

  int Event_maslo_Display_maslev_modeChange::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_Display_maslev_modeChange::getObjectId ( ) const
  {
    return objectId_maslo_Display;
  }

  int Event_maslo_Display_maslev_modeChange::getEventId ( ) const
  {
    return maslo_Display::eventId_maslo_Display_maslev_modeChange;
  }

  Event_maslo_Display_maslev_modeChange::Event_maslo_Display_maslev_modeChange ( )
  {
  }

  void Event_maslo_Display_maslev_modeChange::invoke ( ) const
  {
    maslo_Display::consume_maslo_Display_maslev_modeChange( getDestInstanceId() );
  }

  void maslo_Display::process_maslo_Display_maslev_refresh ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_displayDistance:
      {
        state_maslst_displayDistance();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_Display, getArchitectureId(), getCurrentState(), maslst_displayDistance );
        setCurrentState( maslst_displayDistance );
        break;
      }
      case maslst_displaySpeed:
      {
        state_maslst_displaySpeed();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_Display, getArchitectureId(), getCurrentState(), maslst_displaySpeed );
        setCurrentState( maslst_displaySpeed );
        break;
      }
      case maslst_displayPace:
      {
        state_maslst_displayPace();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_Display, getArchitectureId(), getCurrentState(), maslst_displayPace );
        setCurrentState( maslst_displayPace );
        break;
      }
      case maslst_displayHeartRate:
      {
        state_maslst_displayHeartRate();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_Display, getArchitectureId(), getCurrentState(), maslst_displayHeartRate );
        setCurrentState( maslst_displayHeartRate );
        break;
      }
      case maslst_displayLapCount:
      {
        state_maslst_displayLapCount();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_Display, getArchitectureId(), getCurrentState(), maslst_displayLapCount );
        setCurrentState( maslst_displayLapCount );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_Display, eventId_maslo_Display_maslev_refresh ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_Display ) + "(" + ::boost::lexical_cast< ::std::string>( get_masla_session_startTime() ) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_Display, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_Display::create_maslo_Display_maslev_refresh ( int           sourceObj,
                                                                                          ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_Display_maslev_refresh());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_Display::consume_maslo_Display_maslev_refresh ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_Display> instance = getInstance( id );
    if ( instance ) instance->process_maslo_Display_maslev_refresh();
  }

  int Event_maslo_Display_maslev_refresh::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_Display_maslev_refresh::getObjectId ( ) const
  {
    return objectId_maslo_Display;
  }

  int Event_maslo_Display_maslev_refresh::getEventId ( ) const
  {
    return maslo_Display::eventId_maslo_Display_maslev_refresh;
  }

  Event_maslo_Display_maslev_refresh::Event_maslo_Display_maslev_refresh ( )
  {
  }

  void Event_maslo_Display_maslev_refresh::invoke ( ) const
  {
    maslo_Display::consume_maslo_Display_maslev_refresh( getDestInstanceId() );
  }

  maslo_Display::maslo_Display ( )
    : isDeletedFlag()
  {
  }

  maslo_Display::~maslo_Display ( )
  {
  }

  ::SWA::ObjectPtr<maslo_Display> maslo_Display::createInstance ( const ::SWA::Timestamp& masla_session_startTime,
                                                                  Type                    currentState )
  {
    return maslo_DisplayPopulation::getSingleton().createInstance( masla_session_startTime, currentState );
  }

  void maslo_Display::deleteInstance ( )
  {
    if ( count_R7_indicates_current_status_of_WorkoutSession() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R7 still linked" );
    maslo_DisplayPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_Display>( this ) );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_Display::getPopulationSize ( )
  {
    return maslo_DisplayPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_Display> > maslo_Display::findAll ( )
  {
    return maslo_DisplayPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_Display> maslo_Display::findOne ( )
  {
    return maslo_DisplayPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_Display> maslo_Display::findOnly ( )
  {
    return maslo_DisplayPopulation::getSingleton().findOnly();
  }

  ::std::size_t maslo_Display::count_R7_indicates_current_status_of_WorkoutSession ( ) const
  {
    return navigate_R7_indicates_current_status_of_WorkoutSession() == ::SWA::Null ? 0
                                                                                   : 1;
  }

  void maslo_Display::checked_link_R7_indicates_current_status_of_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs )
  {
    if ( get_masla_session_startTime() != rhs->get_masla_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R7_indicates_current_status_of_WorkoutSession( rhs );
  }

  void maslo_Display::unlink_R7_indicates_current_status_of_WorkoutSession ( )
  {
    const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs = navigate_R7_indicates_current_status_of_WorkoutSession();
    if ( rhs ) unlink_R7_indicates_current_status_of_WorkoutSession( rhs );
  }

  ::std::ostream& operator<< ( ::std::ostream&      stream,
                               const maslo_Display& obj )
  {
    stream << "(";
    stream << obj.get_masla_session_startTime();
    stream << ")";
    return stream;
  }

}
