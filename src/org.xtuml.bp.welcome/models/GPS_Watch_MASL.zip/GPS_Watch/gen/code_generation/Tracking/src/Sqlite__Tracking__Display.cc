//
// File: Sqlite__Tracking__Display.cc
//
#include "Sqlite__Tracking__Display.hh"
#include "Sqlite__Tracking__DisplayPopulation.hh"
#include "Sqlite__Tracking__WorkoutSession.hh"
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__DisplayEvents.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/shared_ptr.hpp"
#include <cstddef>
#include "sqlite/BlobData.hh"
#include "sqlite/EventParameterCodecs.hh"
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_Display::maslo_Display ( ::SWA::IdType                         architectureId,
                                   const ::SWA::Timestamp&               masla_session_startTime,
                                   ::masld_Tracking::maslo_Display::Type currentState )
      : architectureId(architectureId),
        masla_session_startTime(masla_session_startTime),
        currentState(currentState),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_Display::maslo_Display ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_session_startTime(),
        currentState(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_Display::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_Display::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_DisplayPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_Display::PrimaryKeyType maslo_Display::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_session_startTime );
    }

    const maslo_Display::IndexKeyType_1 maslo_Display::get_index_1 ( )
    {
      return IndexKeyType_1( masla_session_startTime );
    }

    void maslo_Display::link_R7_indicates_current_status_of_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> derivedrhs(rhs.downcast<maslo_WorkoutSession>());
      maslo_DisplayPopulation::getPopulation().link_R7_indicates_current_status_of_WorkoutSession( ::SWA::ObjectPtr<maslo_Display>( this ), derivedrhs );
    }

    void maslo_Display::unlink_R7_indicates_current_status_of_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> derivedrhs(rhs.downcast<maslo_WorkoutSession>());
      maslo_DisplayPopulation::getPopulation().unlink_R7_indicates_current_status_of_WorkoutSession( ::SWA::ObjectPtr<maslo_Display>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_Display::navigate_R7_indicates_current_status_of_WorkoutSession ( ) const
    {
      ::SWA::ObjectPtr<maslo_Display> self(const_cast<maslo_Display*>( this ));
      return maslo_DisplayPopulation::getPopulation().navigate_R7_indicates_current_status_of_WorkoutSession( self );
    }

    ::std::size_t maslo_Display::count_R7_indicates_current_status_of_WorkoutSession ( ) const
    {
      ::SWA::ObjectPtr<maslo_Display> self(const_cast<maslo_Display*>( this ));
      return maslo_DisplayPopulation::getPopulation().count_R7_indicates_current_status_of_WorkoutSession( self );
    }

    void encode_maslo_Display_maslev_modeChange ( ::boost::shared_ptr< ::SWA::Event> event,
                                                  BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_Display_maslev_modeChange ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Tracking::Event_maslo_Display_maslev_modeChange() );
    }

    bool registermaslo_Display_maslev_modeChange = EventParameterCodecs::getInstance().registerCodec( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Display, ::masld_Tracking::maslo_Display::eventId_maslo_Display_maslev_modeChange, &encode_maslo_Display_maslev_modeChange, &decode_maslo_Display_maslev_modeChange );

    void encode_maslo_Display_maslev_refresh ( ::boost::shared_ptr< ::SWA::Event> event,
                                               BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_Display_maslev_refresh ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Tracking::Event_maslo_Display_maslev_refresh() );
    }

    bool registermaslo_Display_maslev_refresh = EventParameterCodecs::getInstance().registerCodec( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Display, ::masld_Tracking::maslo_Display::eventId_maslo_Display_maslev_refresh, &encode_maslo_Display_maslev_refresh, &decode_maslo_Display_maslev_refresh );

  }
}
