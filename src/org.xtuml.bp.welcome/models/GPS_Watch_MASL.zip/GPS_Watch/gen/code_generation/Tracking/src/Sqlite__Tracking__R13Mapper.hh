//
// File: Sqlite__Tracking__R13Mapper.hh
//
#ifndef Sqlite_Tracking_R_13_Mapper_hh
#define Sqlite_Tracking_R_13_Mapper_hh

#include "Sqlite__Tracking__Goal.hh"
#include "Sqlite__Tracking__WorkoutSession.hh"
#include "sql/RelationshipBinaryDefinitions.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    typedef ::SQL::OneToManyRelationship<13,maslo_WorkoutSession,maslo_Goal,false,true>::mapper_type RelationshipR13Mapper;
  }
}
#endif // Sqlite_Tracking_R_13_Mapper_hh
