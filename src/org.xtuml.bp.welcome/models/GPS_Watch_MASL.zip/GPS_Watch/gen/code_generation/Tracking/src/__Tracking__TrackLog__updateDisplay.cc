//
// File: __Tracking__TrackLog__updateDisplay.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/bind.hpp"
#include "boost/shared_ptr.hpp"
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/navigate.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  void maslo_TrackLog::masls_updateDisplay ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_TrackLog, serviceId_masls_updateDisplay);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // display : instance of Display;
        ::SWA::ObjectPtr<maslo_Display> maslv_display;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_display(0, maslv_display);

        // display := this -> R4.represents_path_for.WorkoutSession -> R7.current_status_indicated_on.Display;
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          maslv_display = ::SWA::navigate_one<maslo_Display>( ::SWA::navigate_one<maslo_WorkoutSession>( ::SWA::ObjectPtr<maslo_TrackLog>( this ), ::boost::bind( &maslo_TrackLog::navigate_R4_represents_path_for_WorkoutSession, _1 ) ), ::boost::bind( &maslo_WorkoutSession::navigate_R7_current_status_indicated_on_Display, _1 ) );
        }

        // generate Display.refresh () to display;
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          ::SWA::Process::getInstance().getEventQueue().addEvent( maslv_display->create_maslo_Display_maslev_refresh( objectId_maslo_TrackLog, getArchitectureId() ) );
        }
      }
    }
  }

}
