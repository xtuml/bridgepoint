//
// File: __Tracking__Goal__Executing.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Achievement.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/bind.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/Timestamp.hh"
#include "swa/navigate.hh"

namespace masld_Tracking
{
  void maslo_Goal::state_maslst_Executing ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_Goal, stateId_maslst_Executing);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(5);
      {

        // disposition : Tracking::GoalDisposition;
        maslt_GoalDisposition maslv_disposition;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_disposition(0, maslv_disposition);

        // workoutTimer : instance of WorkoutTimer;
        ::SWA::ObjectPtr<maslo_WorkoutTimer> maslv_workoutTimer;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_workoutTimer(1, maslv_workoutTimer);

        // achievement : instance of Achievement;
        ::SWA::ObjectPtr<maslo_Achievement> maslv_achievement;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_achievement(2, maslv_achievement);

        // disposition := this.evaluateAchievement();
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          maslv_disposition = ::SWA::ObjectPtr<maslo_Goal>( this )->masls_evaluateAchievement();
        }

        // if ((this.disposition /= Tracking::GoalDisposition.Achieving) and (disposition = Tracking::GoalDisposition.Achieving)) then ...
        // elsif ((this.disposition = Tracking::GoalDisposition.Achieving) and (disposition /= Tracking::GoalDisposition.Achieving)) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(17);
          if ( ::SWA::ObjectPtr<maslo_Goal>( this )->get_masla_disposition() != maslt_GoalDisposition::masle_Achieving && maslv_disposition == maslt_GoalDisposition::masle_Achieving )
          {

            // workoutTimer := this -> R11.is_currently_executing_within.WorkoutSession -> R8.is_timed_by.WorkoutTimer;
            {
              ::SWA::Stack::ExecutingStatement statement(19);
              maslv_workoutTimer = ::SWA::navigate_one<maslo_WorkoutTimer>( ::SWA::navigate_one<maslo_WorkoutSession>( ::SWA::ObjectPtr<maslo_Goal>( this ), ::boost::bind( &maslo_Goal::navigate_R11_is_currently_executing_within_WorkoutSession, _1 ) ), ::boost::bind( &maslo_WorkoutSession::navigate_R8_is_timed_by_WorkoutTimer, _1 ) );
            }

            // achievement := create Achievement (
            //            session_startTime   => this.session_startTime,
            //            spec_sequenceNumber => this.spec_sequenceNumber,
            //            goal_ID             => this.ID,
            //            startTime           => workoutTimer.time );
            {
              ::SWA::Stack::ExecutingStatement statement(20);
              maslv_achievement = maslo_Achievement::createInstance( maslv_workoutTimer->get_masla_time(), int32_t(), ::SWA::ObjectPtr<maslo_Goal>( this )->get_masla_session_startTime(), ::SWA::ObjectPtr<maslo_Goal>( this )->get_masla_ID(), ::SWA::ObjectPtr<maslo_Goal>( this )->get_masla_spec_sequenceNumber() );
            }

            // link this R14.has_open.Achievement  achievement;
            {
              ::SWA::Stack::ExecutingStatement statement(21);
              ::SWA::ObjectPtr<maslo_Goal>( this )->checked_link_R14_has_open_Achievement( maslv_achievement );
            }
          }
          else if ( ::SWA::ObjectPtr<maslo_Goal>( this )->get_masla_disposition() == maslt_GoalDisposition::masle_Achieving && maslv_disposition != maslt_GoalDisposition::masle_Achieving )
          {

            // achievement := this -> R14.has_open.Achievement;
            {
              ::SWA::Stack::ExecutingStatement statement(24);
              maslv_achievement = ::SWA::navigate_one<maslo_Achievement>( ::SWA::ObjectPtr<maslo_Goal>( this ), ::boost::bind( &maslo_Goal::navigate_R14_has_open_Achievement, _1 ) );
            }

            // achievement.close()
            {
              ::SWA::Stack::ExecutingStatement statement(25);
              maslv_achievement->masls_close();
            }
          }
        }

        // this.disposition := disposition;
        {
          ::SWA::Stack::ExecutingStatement statement(29);
          ::SWA::ObjectPtr<maslo_Goal>( this )->set_masla_disposition( maslv_disposition );
        }

        // this.evaluateCompletion()
        {
          ::SWA::Stack::ExecutingStatement statement(33);
          ::SWA::ObjectPtr<maslo_Goal>( this )->masls_evaluateCompletion();
        }
      }
    }
  }

}
