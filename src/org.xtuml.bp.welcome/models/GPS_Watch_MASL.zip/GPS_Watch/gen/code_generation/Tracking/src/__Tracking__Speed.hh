//
// File: __Tracking__Speed.hh
//
#ifndef _Tracking_Speed_hh
#define _Tracking_Speed_hh

#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_Speed;
  class maslo_Speed
  {

    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_Speed> createInstance ( int32_t masla_id,
                                                            int32_t masla_SpeedAveragingWindow,
                                                            int32_t masla_SecondsPerHour );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_Speed> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_SpeedAveragingWindow ( int32_t value ) = 0;
      virtual void set_masla_SecondsPerHour ( int32_t value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual int32_t get_masla_id ( ) const = 0;
      virtual int32_t get_masla_SpeedAveragingWindow ( ) const = 0;
      virtual int32_t get_masla_SecondsPerHour ( ) const = 0;


    // Object Services
    public:
      static void masls_initialize ( );


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_Speed> > findAll ( );
      static ::SWA::ObjectPtr<maslo_Speed> findOne ( );
      static ::SWA::ObjectPtr<maslo_Speed> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_Speed ( );
      virtual ~maslo_Speed ( );


    // Prevent copy
    private:
      maslo_Speed ( const maslo_Speed& rhs );
      maslo_Speed& operator= ( const maslo_Speed& rhs );


    // Id Enumerations
    public:
      enum StateIds {};
      enum EventIds {};
      enum ServiceIds {  serviceId_masls_initialize };


  };
  ::std::ostream& operator<< ( ::std::ostream&    stream,
                               const maslo_Speed& obj );
}
#endif // _Tracking_Speed_hh
