//
// File: Sqlite__Tracking__WorkoutTimerConstants.hh
//
#ifndef Sqlite_Tracking_Workout_Timer_Constants_hh
#define Sqlite_Tracking_Workout_Timer_Constants_hh

#include "__Tracking__WorkoutTimerConstants.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <stdint.h>
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_WorkoutTimerConstants
      : public ::masld_Tracking::maslo_WorkoutTimerConstants
    {

      // Type definitions
      public:
        typedef ::boost::tuple<int32_t> PrimaryKeyType;
        typedef ::boost::tuple<int32_t> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_WorkoutTimerConstants ( ::SWA::IdType architectureId );
        maslo_WorkoutTimerConstants ( ::SWA::IdType architectureId,
                                      int32_t       masla_id,
                                      int32_t       masla_timerPeriod );


      // Setters for each object attribute
      public:
        void set_masla_id ( int32_t value )
        {
          this->masla_id = value;
          markAsModified();
        }
        virtual void set_masla_timerPeriod ( int32_t value )
        {
          this->masla_timerPeriod = value;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual int32_t get_masla_timerPeriod ( ) const { return masla_timerPeriod; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_id;
        int32_t masla_timerPeriod;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_Tracking_Workout_Timer_Constants_hh
