//
// File: __Tracking__WorkoutSessionPopulation.hh
//
#ifndef _Tracking_Workout_Session_Population_hh
#define _Tracking_Workout_Session_Population_hh

#include <cstddef>
#include "swa/DynamicSingleton.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_WorkoutSession;
  class maslo_WorkoutSessionPopulation
    : public ::SWA::DynamicSingleton<maslo_WorkoutSessionPopulation>
  {

    // Instance Creation
    public:
      virtual ::SWA::IdType getNextArchId ( ) = 0;
      virtual ::SWA::ObjectPtr<maslo_WorkoutSession> createInstance ( const ::SWA::Timestamp& masla_startTime,
                                                                      double                  masla_accumulatedDistance ) = 0;
      virtual void deleteInstance ( ::SWA::ObjectPtr<maslo_WorkoutSession> instance ) = 0;
      virtual ::std::size_t size ( ) const = 0;


    // Instance Retrieval
    public:
      virtual ::SWA::ObjectPtr<maslo_WorkoutSession> getInstance ( ::SWA::IdType id ) const = 0;
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_WorkoutSession> > findAll ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_WorkoutSession> findOne ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_WorkoutSession> findOnly ( ) const = 0;


    // Constructors and Destructors
    protected:
      maslo_WorkoutSessionPopulation ( );
      virtual ~maslo_WorkoutSessionPopulation ( );


    // Prevent copy
    private:
      maslo_WorkoutSessionPopulation ( const maslo_WorkoutSessionPopulation& rhs );
      maslo_WorkoutSessionPopulation& operator= ( const maslo_WorkoutSessionPopulation& rhs );


  };
}
#endif // _Tracking_Workout_Session_Population_hh
