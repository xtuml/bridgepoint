//
// File: __Tracking__GoalAchievementPopulation.hh
//
#ifndef _Tracking_Goal_Achievement_Population_hh
#define _Tracking_Goal_Achievement_Population_hh

#include <cstddef>
#include <stdint.h>
#include "swa/DynamicSingleton.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_GoalAchievement;
  class maslo_GoalAchievementPopulation
    : public ::SWA::DynamicSingleton<maslo_GoalAchievementPopulation>
  {

    // Instance Creation
    public:
      virtual ::SWA::IdType getNextArchId ( ) = 0;
      virtual ::SWA::ObjectPtr<maslo_GoalAchievement> createInstance ( int32_t masla_id,
                                                                       int32_t masla_evaluationPeriod ) = 0;
      virtual void deleteInstance ( ::SWA::ObjectPtr<maslo_GoalAchievement> instance ) = 0;
      virtual ::std::size_t size ( ) const = 0;


    // Instance Retrieval
    public:
      virtual ::SWA::ObjectPtr<maslo_GoalAchievement> getInstance ( ::SWA::IdType id ) const = 0;
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_GoalAchievement> > findAll ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_GoalAchievement> findOne ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_GoalAchievement> findOnly ( ) const = 0;


    // Constructors and Destructors
    protected:
      maslo_GoalAchievementPopulation ( );
      virtual ~maslo_GoalAchievementPopulation ( );


    // Prevent copy
    private:
      maslo_GoalAchievementPopulation ( const maslo_GoalAchievementPopulation& rhs );
      maslo_GoalAchievementPopulation& operator= ( const maslo_GoalAchievementPopulation& rhs );


  };
}
#endif // _Tracking_Goal_Achievement_Population_hh
