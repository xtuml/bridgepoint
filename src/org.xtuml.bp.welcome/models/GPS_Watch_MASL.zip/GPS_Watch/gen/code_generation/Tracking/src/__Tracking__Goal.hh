//
// File: __Tracking__Goal.hh
//
#ifndef _Tracking_Goal_hh
#define _Tracking_Goal_hh

#include "boost/shared_ptr.hpp"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/Bag.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslt_GoalDisposition;
  class maslo_GoalSpec;
  class maslo_WorkoutSession;
  class maslo_Achievement;
  class maslo_Goal;
  class maslo_Goal
  {

    public:
      enum Type {  maslst_Executing,
                   maslst_Completed,
                   maslst_Paused,
                   maslst_Evaluating };


    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_Goal> createInstance ( const maslt_GoalDisposition&           masla_disposition,
                                                           double                                 masla_startingPoint,
                                                           int32_t                                masla_ID,
                                                           const ::SWA::EventTimers::TimerIdType& masla_evaluationTimer,
                                                           const ::SWA::Timestamp&                masla_session_startTime,
                                                           int32_t                                masla_spec_sequenceNumber,
                                                           Type                                   currentState );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_Goal> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_disposition ( const maslt_GoalDisposition& value ) = 0;
      virtual void set_masla_startingPoint ( double value ) = 0;
      virtual void set_masla_evaluationTimer ( const ::SWA::EventTimers::TimerIdType& value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual maslt_GoalDisposition get_masla_disposition ( ) const = 0;
      virtual double get_masla_startingPoint ( ) const = 0;
      virtual int32_t get_masla_ID ( ) const = 0;
      virtual ::SWA::EventTimers::TimerIdType get_masla_evaluationTimer ( ) const = 0;
      virtual ::SWA::Timestamp get_masla_session_startTime ( ) const = 0;
      virtual int32_t get_masla_spec_sequenceNumber ( ) const = 0;


    // Object Services
    public:
      static void masls_initialize ( int32_t maslp_sequenceNumber );
      static void masls_nextGoal ( );


    // Instance Services
    public:
      void masls_calculateStart ( );
      maslt_GoalDisposition masls_evaluateAchievement ( );
      void masls_evaluateCompletion ( );


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_Goal> > findAll ( );
      static ::SWA::ObjectPtr<maslo_Goal> findOne ( );
      static ::SWA::ObjectPtr<maslo_Goal> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_Goal ( );
      virtual ~maslo_Goal ( );


    // Prevent copy
    private:
      maslo_Goal ( const maslo_Goal& rhs );
      maslo_Goal& operator= ( const maslo_Goal& rhs );


    // State Machine
    public:
      virtual Type getCurrentState ( ) const = 0;
      virtual void setCurrentState ( Type newState ) = 0;


    // State Actions
    private:
      void state_maslst_Executing ( );
      void state_maslst_Completed ( );
      void state_maslst_Paused ( );
      void state_maslst_Evaluating ( );


    // Generate Events
    public:
      ::boost::shared_ptr< ::SWA::Event> create_maslo_Goal_maslev_Completed ( int           sourceObj = -1,
                                                                              ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_Goal_maslev_Evaluate ( int           sourceObj = -1,
                                                                             ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_Goal_maslev_Pause ( int           sourceObj = -1,
                                                                          ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_Goal_maslev_evaluationComplete ( int           sourceObj = -1,
                                                                                       ::SWA::IdType sourceInstance = 0 );


    // Consume Events
    public:
      static void consume_maslo_Goal_maslev_Completed ( ::SWA::IdType id );
      static void consume_maslo_Goal_maslev_Evaluate ( ::SWA::IdType id );
      static void consume_maslo_Goal_maslev_Pause ( ::SWA::IdType id );
      static void consume_maslo_Goal_maslev_evaluationComplete ( ::SWA::IdType id );


    // Process Events
    public:
      void process_maslo_Goal_maslev_Completed ( );
      void process_maslo_Goal_maslev_Evaluate ( );
      void process_maslo_Goal_maslev_Pause ( );
      void process_maslo_Goal_maslev_evaluationComplete ( );


    // Id Enumerations
    public:
      enum StateIds {  stateId_maslst_Executing,
                       stateId_maslst_Completed,
                       stateId_maslst_Paused,
                       stateId_maslst_Evaluating };
      enum EventIds {  eventId_maslo_Goal_maslev_Completed,
                       eventId_maslo_Goal_maslev_Evaluate,
                       eventId_maslo_Goal_maslev_Pause,
                       eventId_maslo_Goal_maslev_evaluationComplete };
      enum ServiceIds {  serviceId_masls_initialize,
                         serviceId_masls_calculateStart,
                         serviceId_masls_evaluateAchievement,
                         serviceId_masls_evaluateCompletion,
                         serviceId_masls_nextGoal };


    // Relationship R9.specified_by.GoalSpec
    public:
      virtual ::SWA::ObjectPtr<maslo_GoalSpec> navigate_R9_specified_by_GoalSpec ( ) const = 0;
      virtual ::std::size_t count_R9_specified_by_GoalSpec ( ) const;
      virtual void link_R9_specified_by_GoalSpec ( const ::SWA::ObjectPtr<maslo_GoalSpec>& rhs ) = 0;
      void checked_link_R9_specified_by_GoalSpec ( const ::SWA::ObjectPtr<maslo_GoalSpec>& rhs );
      virtual void unlink_R9_specified_by_GoalSpec ( const ::SWA::ObjectPtr<maslo_GoalSpec>& rhs ) = 0;
      virtual void unlink_R9_specified_by_GoalSpec ( );


    // Relationship R11.is_currently_executing_within.WorkoutSession
    public:
      virtual ::SWA::ObjectPtr<maslo_WorkoutSession> navigate_R11_is_currently_executing_within_WorkoutSession ( ) const = 0;
      virtual ::std::size_t count_R11_is_currently_executing_within_WorkoutSession ( ) const;
      virtual void link_R11_is_currently_executing_within_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs ) = 0;
      void checked_link_R11_is_currently_executing_within_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs );
      virtual void unlink_R11_is_currently_executing_within_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs ) = 0;
      virtual void unlink_R11_is_currently_executing_within_WorkoutSession ( );


    // Relationship R12.has_recorded.Achievement
    public:
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_Achievement> > navigate_R12_has_recorded_Achievement ( ) const = 0;
      virtual ::std::size_t count_R12_has_recorded_Achievement ( ) const;
      virtual void link_R12_has_recorded_Achievement ( const ::SWA::ObjectPtr<maslo_Achievement>& rhs ) = 0;
      virtual void link_R12_has_recorded_Achievement ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Achievement> >& rhs );
      void checked_link_R12_has_recorded_Achievement ( const ::SWA::ObjectPtr<maslo_Achievement>& rhs );
      void checked_link_R12_has_recorded_Achievement ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Achievement> >& rhs );
      virtual void unlink_R12_has_recorded_Achievement ( const ::SWA::ObjectPtr<maslo_Achievement>& rhs ) = 0;
      virtual void unlink_R12_has_recorded_Achievement ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Achievement> >& rhs );
      virtual void unlink_R12_has_recorded_Achievement ( );


    // Relationship R13.was_executed_within.WorkoutSession
    public:
      virtual ::SWA::ObjectPtr<maslo_WorkoutSession> navigate_R13_was_executed_within_WorkoutSession ( ) const = 0;
      virtual ::std::size_t count_R13_was_executed_within_WorkoutSession ( ) const;
      virtual void link_R13_was_executed_within_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs ) = 0;
      void checked_link_R13_was_executed_within_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs );
      virtual void unlink_R13_was_executed_within_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs ) = 0;
      virtual void unlink_R13_was_executed_within_WorkoutSession ( );


    // Relationship R14.has_open.Achievement
    public:
      virtual ::SWA::ObjectPtr<maslo_Achievement> navigate_R14_has_open_Achievement ( ) const = 0;
      virtual ::std::size_t count_R14_has_open_Achievement ( ) const;
      virtual void link_R14_has_open_Achievement ( const ::SWA::ObjectPtr<maslo_Achievement>& rhs ) = 0;
      void checked_link_R14_has_open_Achievement ( const ::SWA::ObjectPtr<maslo_Achievement>& rhs );
      virtual void unlink_R14_has_open_Achievement ( const ::SWA::ObjectPtr<maslo_Achievement>& rhs ) = 0;
      virtual void unlink_R14_has_open_Achievement ( );


  };
  ::std::ostream& operator<< ( ::std::ostream&   stream,
                               const maslo_Goal& obj );
}
#endif // _Tracking_Goal_hh
