//
// File: Inspector__Tracking.cc
//
#include "Inspector__Tracking__Achievement.hh"
#include "Inspector__Tracking__Display.hh"
#include "Inspector__Tracking__Goal.hh"
#include "Inspector__Tracking__GoalAchievement.hh"
#include "Inspector__Tracking__GoalSpec.hh"
#include "Inspector__Tracking__GoalSpecConstants.hh"
#include "Inspector__Tracking__HR.hh"
#include "Inspector__Tracking__HeartRateConstants.hh"
#include "Inspector__Tracking__HeartRateSample.hh"
#include "Inspector__Tracking__LOC.hh"
#include "Inspector__Tracking__LapMarker.hh"
#include "Inspector__Tracking__Speed.hh"
#include "Inspector__Tracking__TrackLog.hh"
#include "Inspector__Tracking__TrackPoint.hh"
#include "Inspector__Tracking__UI.hh"
#include "Inspector__Tracking__WorkoutSession.hh"
#include "Inspector__Tracking__WorkoutTimer.hh"
#include "Inspector__Tracking__WorkoutTimerConstants.hh"
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_services.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Achievement.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__HeartRateSample.hh"
#include "__Tracking__LapMarker.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__TrackPoint.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "__Tracking_private_services.hh"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/GenericObjectHandler.hh"
#include "inspector/ProcessHandler.hh"
#include "inspector/TerminatorHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    class masls_InitializeHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_InitializeInvoker
    {

      public:
        masls_InitializeInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_Tracking::interceptor_masls_Initialize::instance().callService()(); }


    };
    class masls_GoalTest_1Handler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_GoalTest_1Invoker
    {

      public:
        masls_GoalTest_1Invoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_Tracking::interceptor_masls_GoalTest_1::instance().callService()(); }


    };
    class masls_heartRateChangedHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_heartRateChangedInvoker
    {

      public:
        masls_heartRateChangedInvoker ( CommunicationChannel& channel )
          : maslp_heartRate()
 { channel >> maslp_heartRate; }
        void operator() ( ) { ::masld_Tracking::interceptor_masls_heartRateChanged::instance().callService()( maslp_heartRate ); }


      private:
        int32_t maslp_heartRate;


    };
    class masls_setTargetPressedHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_setTargetPressedInvoker
    {

      public:
        masls_setTargetPressedInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_Tracking::interceptor_masls_setTargetPressed::instance().callService()(); }


    };
    class masls_startStopPressedHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_startStopPressedInvoker
    {

      public:
        masls_startStopPressedInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_Tracking::interceptor_masls_startStopPressed::instance().callService()(); }


    };
    class masls_lapResetPressedHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_lapResetPressedInvoker
    {

      public:
        masls_lapResetPressedInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_Tracking::interceptor_masls_lapResetPressed::instance().callService()(); }


    };
    class masls_lightPressedHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_lightPressedInvoker
    {

      public:
        masls_lightPressedInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_Tracking::interceptor_masls_lightPressed::instance().callService()(); }


    };
    class masls_modePressedHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_modePressedInvoker
    {

      public:
        masls_modePressedInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_Tracking::interceptor_masls_modePressed::instance().callService()(); }


    };
    class masls_newGoalSpecHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_newGoalSpecInvoker
    {

      public:
        masls_newGoalSpecInvoker ( CommunicationChannel& channel )
          : maslp_spanType(),
            maslp_criteriaType(),
            maslp_span(),
            maslp_maximum(),
            maslp_minimum(),
            maslp_sequenceNumber()

        {
          channel >> maslp_spanType;
          channel >> maslp_criteriaType;
          channel >> maslp_span;
          channel >> maslp_maximum;
          channel >> maslp_minimum;
          channel >> maslp_sequenceNumber;
        }
        void operator() ( ) { ::masld_Tracking::interceptor_masls_newGoalSpec::instance().callService()( maslp_spanType, maslp_criteriaType, maslp_span, maslp_maximum, maslp_minimum, maslp_sequenceNumber ); }


      private:
        ::masld_Tracking::maslt_GoalSpan maslp_spanType;
        ::masld_Tracking::maslt_GoalCriteria maslp_criteriaType;
        double maslp_span;
        double maslp_maximum;
        double maslp_minimum;
        int32_t maslp_sequenceNumber;


    };
    class masld_TrackingHandler
      : public DomainHandler
    {

      public:
        masld_TrackingHandler ( );
        void createRelationship ( CommunicationChannel& channel,
                                  int                   relId );


    };
    Callable masls_InitializeHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_InitializeInvoker( channel );
    }

    void masls_InitializeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                   const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_GoalTest_1Handler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_GoalTest_1Invoker( channel );
    }

    void masls_GoalTest_1Handler::writeLocalVars ( CommunicationChannel&    channel,
                                                   const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_heartRateChangedHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_heartRateChangedInvoker( channel );
    }

    void masls_heartRateChangedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                         const ::SWA::StackFrame& frame ) const
    {

      // Write heartRate
      channel << frame.getParameters()[0].getValue<int32_t>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
      for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
      {
        channel << frame.getLocalVars()[i].getId();
        switch ( frame.getLocalVars()[i].getId() )
        {
          case 0:

            // Write session
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
            break;

        }

      }
    }

    Callable masls_setTargetPressedHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_setTargetPressedInvoker( channel );
    }

    void masls_setTargetPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                         const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_startStopPressedHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_startStopPressedInvoker( channel );
    }

    void masls_startStopPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                         const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
      for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
      {
        channel << frame.getLocalVars()[i].getId();
        switch ( frame.getLocalVars()[i].getId() )
        {
          case 0:

            // Write workoutTimer
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> >();
            break;

        }

      }
    }

    Callable masls_lapResetPressedHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_lapResetPressedInvoker( channel );
    }

    void masls_lapResetPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                        const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
      for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
      {
        channel << frame.getLocalVars()[i].getId();
        switch ( frame.getLocalVars()[i].getId() )
        {
          case 0:

            // Write workoutTimer
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> >();
            break;

        }

      }
    }

    Callable masls_lightPressedHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_lightPressedInvoker( channel );
    }

    void masls_lightPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_modePressedHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_modePressedInvoker( channel );
    }

    void masls_modePressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                    const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
      for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
      {
        channel << frame.getLocalVars()[i].getId();
        switch ( frame.getLocalVars()[i].getId() )
        {
          case 0:

            // Write session
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
            break;

          case 1:

            // Write display
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> >();
            break;

        }

      }
    }

    Callable masls_newGoalSpecHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_newGoalSpecInvoker( channel );
    }

    void masls_newGoalSpecHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                    const ::SWA::StackFrame& frame ) const
    {

      // Write spanType
      channel << frame.getParameters()[0].getValue< ::masld_Tracking::maslt_GoalSpan>();

      // Write criteriaType
      channel << frame.getParameters()[1].getValue< ::masld_Tracking::maslt_GoalCriteria>();

      // Write span
      channel << frame.getParameters()[2].getValue<double>();

      // Write maximum
      channel << frame.getParameters()[3].getValue<double>();

      // Write minimum
      channel << frame.getParameters()[4].getValue<double>();

      // Write sequenceNumber
      channel << frame.getParameters()[5].getValue<int32_t>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
      for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
      {
        channel << frame.getLocalVars()[i].getId();
        switch ( frame.getLocalVars()[i].getId() )
        {
          case 0:

            // Write session
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
            break;

          case 1:

            // Write goalSpec
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> >();
            break;

        }

      }
    }

    masld_TrackingHandler::masld_TrackingHandler ( )
    {
      registerObjectHandler( ::masld_Tracking::objectId_maslo_WorkoutSession, ::boost::shared_ptr<GenericObjectHandler>( new maslo_WorkoutSession::maslo_WorkoutSessionHandler() ) );
      registerObjectHandler( ::masld_Tracking::objectId_maslo_WorkoutTimer, ::boost::shared_ptr<GenericObjectHandler>( new maslo_WorkoutTimer::maslo_WorkoutTimerHandler() ) );
      registerObjectHandler( ::masld_Tracking::objectId_maslo_TrackPoint, ::boost::shared_ptr<GenericObjectHandler>( new maslo_TrackPoint::maslo_TrackPointHandler() ) );
      registerObjectHandler( ::masld_Tracking::objectId_maslo_TrackLog, ::boost::shared_ptr<GenericObjectHandler>( new maslo_TrackLog::maslo_TrackLogHandler() ) );
      registerObjectHandler( ::masld_Tracking::objectId_maslo_LapMarker, ::boost::shared_ptr<GenericObjectHandler>( new maslo_LapMarker::maslo_LapMarkerHandler() ) );
      registerObjectHandler( ::masld_Tracking::objectId_maslo_HeartRateSample, ::boost::shared_ptr<GenericObjectHandler>( new maslo_HeartRateSample::maslo_HeartRateSampleHandler() ) );
      registerObjectHandler( ::masld_Tracking::objectId_maslo_GoalSpec, ::boost::shared_ptr<GenericObjectHandler>( new maslo_GoalSpec::maslo_GoalSpecHandler() ) );
      registerObjectHandler( ::masld_Tracking::objectId_maslo_Goal, ::boost::shared_ptr<GenericObjectHandler>( new maslo_Goal::maslo_GoalHandler() ) );
      registerObjectHandler( ::masld_Tracking::objectId_maslo_Display, ::boost::shared_ptr<GenericObjectHandler>( new maslo_Display::maslo_DisplayHandler() ) );
      registerObjectHandler( ::masld_Tracking::objectId_maslo_Achievement, ::boost::shared_ptr<GenericObjectHandler>( new maslo_Achievement::maslo_AchievementHandler() ) );
      registerObjectHandler( ::masld_Tracking::objectId_maslo_GoalAchievement, ::boost::shared_ptr<GenericObjectHandler>( new maslo_GoalAchievement::maslo_GoalAchievementHandler() ) );
      registerObjectHandler( ::masld_Tracking::objectId_maslo_GoalSpecConstants, ::boost::shared_ptr<GenericObjectHandler>( new maslo_GoalSpecConstants::maslo_GoalSpecConstantsHandler() ) );
      registerObjectHandler( ::masld_Tracking::objectId_maslo_HeartRateConstants, ::boost::shared_ptr<GenericObjectHandler>( new maslo_HeartRateConstants::maslo_HeartRateConstantsHandler() ) );
      registerObjectHandler( ::masld_Tracking::objectId_maslo_Speed, ::boost::shared_ptr<GenericObjectHandler>( new maslo_Speed::maslo_SpeedHandler() ) );
      registerObjectHandler( ::masld_Tracking::objectId_maslo_WorkoutTimerConstants, ::boost::shared_ptr<GenericObjectHandler>( new maslo_WorkoutTimerConstants::maslo_WorkoutTimerConstantsHandler() ) );
      registerTerminatorHandler( ::masld_Tracking::terminatorId_maslb_HR, ::boost::shared_ptr<TerminatorHandler>( new maslb_HR::maslb_HRHandler() ) );
      registerTerminatorHandler( ::masld_Tracking::terminatorId_maslb_LOC, ::boost::shared_ptr<TerminatorHandler>( new maslb_LOC::maslb_LOCHandler() ) );
      registerTerminatorHandler( ::masld_Tracking::terminatorId_maslb_UI, ::boost::shared_ptr<TerminatorHandler>( new maslb_UI::maslb_UIHandler() ) );
      registerServiceHandler( ::masld_Tracking::serviceId_masls_Initialize, ::boost::shared_ptr<ActionHandler>( new masls_InitializeHandler() ) );
      registerServiceHandler( ::masld_Tracking::serviceId_masls_GoalTest_1, ::boost::shared_ptr<ActionHandler>( new masls_GoalTest_1Handler() ) );
      registerServiceHandler( ::masld_Tracking::serviceId_masls_heartRateChanged, ::boost::shared_ptr<ActionHandler>( new masls_heartRateChangedHandler() ) );
      registerServiceHandler( ::masld_Tracking::serviceId_masls_setTargetPressed, ::boost::shared_ptr<ActionHandler>( new masls_setTargetPressedHandler() ) );
      registerServiceHandler( ::masld_Tracking::serviceId_masls_startStopPressed, ::boost::shared_ptr<ActionHandler>( new masls_startStopPressedHandler() ) );
      registerServiceHandler( ::masld_Tracking::serviceId_masls_lapResetPressed, ::boost::shared_ptr<ActionHandler>( new masls_lapResetPressedHandler() ) );
      registerServiceHandler( ::masld_Tracking::serviceId_masls_lightPressed, ::boost::shared_ptr<ActionHandler>( new masls_lightPressedHandler() ) );
      registerServiceHandler( ::masld_Tracking::serviceId_masls_modePressed, ::boost::shared_ptr<ActionHandler>( new masls_modePressedHandler() ) );
      registerServiceHandler( ::masld_Tracking::serviceId_masls_newGoalSpec, ::boost::shared_ptr<ActionHandler>( new masls_newGoalSpecHandler() ) );
    }

    void masld_TrackingHandler::createRelationship ( CommunicationChannel& channel,
                                                     int                   relId )
    {
      switch ( relId )
      {
        case ::masld_Tracking::relationshipId_R1:
        {
          ::SWA::IdType lhsId;
          ::SWA::IdType rhsId;
          channel >> lhsId >> rhsId;
          ::masld_Tracking::maslo_TrackLog::getInstance( lhsId )->checked_link_R1_has_first_TrackPoint( ::masld_Tracking::maslo_TrackPoint::getInstance( rhsId ) );
          break;
        }
        case ::masld_Tracking::relationshipId_R2:
        {
          ::SWA::IdType lhsId;
          ::SWA::IdType rhsId;
          channel >> lhsId >> rhsId;
          ::masld_Tracking::maslo_TrackPoint::getInstance( lhsId )->checked_link_R2_follows_TrackPoint( ::masld_Tracking::maslo_TrackPoint::getInstance( rhsId ) );
          break;
        }
        case ::masld_Tracking::relationshipId_R3:
        {
          ::SWA::IdType lhsId;
          ::SWA::IdType rhsId;
          channel >> lhsId >> rhsId;
          ::masld_Tracking::maslo_TrackLog::getInstance( lhsId )->checked_link_R3_has_last_TrackPoint( ::masld_Tracking::maslo_TrackPoint::getInstance( rhsId ) );
          break;
        }
        case ::masld_Tracking::relationshipId_R5:
        {
          ::SWA::IdType lhsId;
          ::SWA::IdType rhsId;
          channel >> lhsId >> rhsId;
          ::masld_Tracking::maslo_TrackLog::getInstance( lhsId )->checked_link_R5_has_laps_defined_by_LapMarker( ::masld_Tracking::maslo_LapMarker::getInstance( rhsId ) );
          break;
        }
        case ::masld_Tracking::relationshipId_R7:
        {
          ::SWA::IdType lhsId;
          ::SWA::IdType rhsId;
          channel >> lhsId >> rhsId;
          ::masld_Tracking::maslo_WorkoutSession::getInstance( lhsId )->checked_link_R7_current_status_indicated_on_Display( ::masld_Tracking::maslo_Display::getInstance( rhsId ) );
          break;
        }
        case ::masld_Tracking::relationshipId_R8:
        {
          ::SWA::IdType lhsId;
          ::SWA::IdType rhsId;
          channel >> lhsId >> rhsId;
          ::masld_Tracking::maslo_WorkoutSession::getInstance( lhsId )->checked_link_R8_is_timed_by_WorkoutTimer( ::masld_Tracking::maslo_WorkoutTimer::getInstance( rhsId ) );
          break;
        }
        case ::masld_Tracking::relationshipId_R4:
        {
          ::SWA::IdType lhsId;
          ::SWA::IdType rhsId;
          channel >> lhsId >> rhsId;
          ::masld_Tracking::maslo_WorkoutSession::getInstance( lhsId )->checked_link_R4_captures_path_in_TrackLog( ::masld_Tracking::maslo_TrackLog::getInstance( rhsId ) );
          break;
        }
        case ::masld_Tracking::relationshipId_R6:
        {
          ::SWA::IdType lhsId;
          ::SWA::IdType rhsId;
          channel >> lhsId >> rhsId;
          ::masld_Tracking::maslo_WorkoutSession::getInstance( lhsId )->checked_link_R6_tracks_heart_rate_over_time_as_HeartRateSample( ::masld_Tracking::maslo_HeartRateSample::getInstance( rhsId ) );
          break;
        }
        case ::masld_Tracking::relationshipId_R9:
        {
          ::SWA::IdType lhsId;
          ::SWA::IdType rhsId;
          channel >> lhsId >> rhsId;
          ::masld_Tracking::maslo_GoalSpec::getInstance( lhsId )->checked_link_R9_specifies_Goal( ::masld_Tracking::maslo_Goal::getInstance( rhsId ) );
          break;
        }
        case ::masld_Tracking::relationshipId_R10:
        {
          ::SWA::IdType lhsId;
          ::SWA::IdType rhsId;
          channel >> lhsId >> rhsId;
          ::masld_Tracking::maslo_WorkoutSession::getInstance( lhsId )->checked_link_R10_includes_GoalSpec( ::masld_Tracking::maslo_GoalSpec::getInstance( rhsId ) );
          break;
        }
        case ::masld_Tracking::relationshipId_R11:
        {
          ::SWA::IdType lhsId;
          ::SWA::IdType rhsId;
          channel >> lhsId >> rhsId;
          ::masld_Tracking::maslo_WorkoutSession::getInstance( lhsId )->checked_link_R11_is_currently_executing_Goal( ::masld_Tracking::maslo_Goal::getInstance( rhsId ) );
          break;
        }
        case ::masld_Tracking::relationshipId_R12:
        {
          ::SWA::IdType lhsId;
          ::SWA::IdType rhsId;
          channel >> lhsId >> rhsId;
          ::masld_Tracking::maslo_Goal::getInstance( lhsId )->checked_link_R12_has_recorded_Achievement( ::masld_Tracking::maslo_Achievement::getInstance( rhsId ) );
          break;
        }
        case ::masld_Tracking::relationshipId_R13:
        {
          ::SWA::IdType lhsId;
          ::SWA::IdType rhsId;
          channel >> lhsId >> rhsId;
          ::masld_Tracking::maslo_WorkoutSession::getInstance( lhsId )->checked_link_R13_has_executed_Goal( ::masld_Tracking::maslo_Goal::getInstance( rhsId ) );
          break;
        }
        case ::masld_Tracking::relationshipId_R14:
        {
          ::SWA::IdType lhsId;
          ::SWA::IdType rhsId;
          channel >> lhsId >> rhsId;
          ::masld_Tracking::maslo_Goal::getInstance( lhsId )->checked_link_R14_has_open_Achievement( ::masld_Tracking::maslo_Achievement::getInstance( rhsId ) );
          break;
        }
      }

    }

  }
}
namespace 
{
  bool masld_Tracking_registered = ::Inspector::ProcessHandler::getInstance().registerDomainHandler( ::SWA::Process::getInstance().getDomain( "Tracking" ).getId(), ::boost::shared_ptr< ::Inspector::DomainHandler>( new ::Inspector::masld_Tracking::masld_TrackingHandler() ) );

}
