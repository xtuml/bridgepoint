//
// File: Transient__Tracking__GoalAchievement.cc
//
#include "Transient__Tracking__GoalAchievement.hh"
#include <stdint.h>

namespace transient
{
  namespace masld_Tracking
  {
    maslo_GoalAchievement::maslo_GoalAchievement ( int32_t masla_id,
                                                   int32_t masla_evaluationPeriod )
      : architectureId(getNextArchId()),
        masla_id(masla_id),
        masla_evaluationPeriod(masla_evaluationPeriod)
    {
    }

  }
}
