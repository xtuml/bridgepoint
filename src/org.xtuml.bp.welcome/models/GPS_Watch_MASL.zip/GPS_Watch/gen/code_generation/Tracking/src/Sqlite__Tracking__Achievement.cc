//
// File: Sqlite__Tracking__Achievement.cc
//
#include "Sqlite__Tracking__Achievement.hh"
#include "Sqlite__Tracking__AchievementPopulation.hh"
#include "Sqlite__Tracking__Goal.hh"
#include "__Tracking__Goal.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_Achievement::maslo_Achievement ( ::SWA::IdType           architectureId,
                                           int32_t                 masla_startTime,
                                           int32_t                 masla_endTime,
                                           const ::SWA::Timestamp& masla_session_startTime,
                                           int32_t                 masla_goal_ID,
                                           int32_t                 masla_spec_sequenceNumber )
      : architectureId(architectureId),
        masla_startTime(masla_startTime),
        masla_endTime(masla_endTime),
        masla_session_startTime(masla_session_startTime),
        masla_goal_ID(masla_goal_ID),
        masla_spec_sequenceNumber(masla_spec_sequenceNumber),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_Achievement::maslo_Achievement ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_startTime(),
        masla_endTime(),
        masla_session_startTime(),
        masla_goal_ID(),
        masla_spec_sequenceNumber(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_Achievement::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_Achievement::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_AchievementPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_Achievement::PrimaryKeyType maslo_Achievement::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_startTime, masla_session_startTime, masla_goal_ID, masla_spec_sequenceNumber );
    }

    const maslo_Achievement::IndexKeyType_1 maslo_Achievement::get_index_1 ( )
    {
      return IndexKeyType_1( masla_startTime, masla_session_startTime, masla_goal_ID, masla_spec_sequenceNumber );
    }

    void maslo_Achievement::link_R12_specifies_achievement_of_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> derivedrhs(rhs.downcast<maslo_Goal>());
      maslo_AchievementPopulation::getPopulation().link_R12_specifies_achievement_of_Goal( ::SWA::ObjectPtr<maslo_Achievement>( this ), derivedrhs );
    }

    void maslo_Achievement::unlink_R12_specifies_achievement_of_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> derivedrhs(rhs.downcast<maslo_Goal>());
      maslo_AchievementPopulation::getPopulation().unlink_R12_specifies_achievement_of_Goal( ::SWA::ObjectPtr<maslo_Achievement>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> maslo_Achievement::navigate_R12_specifies_achievement_of_Goal ( ) const
    {
      ::SWA::ObjectPtr<maslo_Achievement> self(const_cast<maslo_Achievement*>( this ));
      return maslo_AchievementPopulation::getPopulation().navigate_R12_specifies_achievement_of_Goal( self );
    }

    ::std::size_t maslo_Achievement::count_R12_specifies_achievement_of_Goal ( ) const
    {
      ::SWA::ObjectPtr<maslo_Achievement> self(const_cast<maslo_Achievement*>( this ));
      return maslo_AchievementPopulation::getPopulation().count_R12_specifies_achievement_of_Goal( self );
    }

    void maslo_Achievement::link_R14_is_open_for_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> derivedrhs(rhs.downcast<maslo_Goal>());
      maslo_AchievementPopulation::getPopulation().link_R14_is_open_for_Goal( ::SWA::ObjectPtr<maslo_Achievement>( this ), derivedrhs );
    }

    void maslo_Achievement::unlink_R14_is_open_for_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> derivedrhs(rhs.downcast<maslo_Goal>());
      maslo_AchievementPopulation::getPopulation().unlink_R14_is_open_for_Goal( ::SWA::ObjectPtr<maslo_Achievement>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> maslo_Achievement::navigate_R14_is_open_for_Goal ( ) const
    {
      ::SWA::ObjectPtr<maslo_Achievement> self(const_cast<maslo_Achievement*>( this ));
      return maslo_AchievementPopulation::getPopulation().navigate_R14_is_open_for_Goal( self );
    }

    ::std::size_t maslo_Achievement::count_R14_is_open_for_Goal ( ) const
    {
      ::SWA::ObjectPtr<maslo_Achievement> self(const_cast<maslo_Achievement*>( this ));
      return maslo_AchievementPopulation::getPopulation().count_R14_is_open_for_Goal( self );
    }

  }
}
