//
// File: Sqlite__Tracking__TrackPointMapper.cc
//
#include "Sqlite__Tracking__TrackPoint.hh"
#include "Sqlite__Tracking__TrackPointMapper.hh"
#include "Sqlite__Tracking__TrackPointMapperSql.hh"
#include "__Tracking__TrackPoint.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_TrackPointMapper::maslo_TrackPointMapper ( )
      : ::SQL::ObjectMapper< ::masld_Tracking::maslo_TrackPoint,maslo_TrackPoint>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_Tracking::maslo_TrackPoint,maslo_TrackPoint> >( new maslo_TrackPointSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_TrackPointMapper::~maslo_TrackPointMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> maslo_TrackPointMapper::createInstance ( int32_t                 masla_time,
                                                                                                   double                  masla_longitude,
                                                                                                   double                  masla_latitude,
                                                                                                   const ::SWA::Timestamp& masla_session_startTime )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_TrackPoint::PrimaryKeyType>::value_type( masla_time, masla_session_startTime ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_TrackPoint> instance(new maslo_TrackPoint(  uniqueId,
                       masla_time,
                       masla_longitude,
                       masla_latitude,
                       masla_session_startTime ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_TrackPointMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> instance )
    {
      ::SQL::ObjectMapper< ::masld_Tracking::maslo_TrackPoint,maslo_TrackPoint>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_TrackPoint>()->getPrimaryKey() );
    }

    bool maslo_TrackPointMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
