//
// File: __Tracking_interface.cc
//
#include "Tracking_OOA/__Tracking_interface.hh"
#include "swa/Domain.hh"
#include "swa/Process.hh"

namespace masld_Tracking
{
  ::SWA::Domain& getDomain ( )
  {
    static ::SWA::Domain& domain = ::SWA::Process::getInstance().registerDomain( "Tracking" );
    return domain;
  }

  bool initialiseInterface ( )
  {
    getDomain();
  }

  const bool interfaceInitialised = initialiseInterface();

}
