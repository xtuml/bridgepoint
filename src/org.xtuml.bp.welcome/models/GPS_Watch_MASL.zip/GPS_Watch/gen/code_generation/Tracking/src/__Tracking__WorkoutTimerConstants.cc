//
// File: __Tracking__WorkoutTimerConstants.cc
//
#include "__Tracking__WorkoutTimerConstants.hh"
#include "__Tracking__WorkoutTimerConstantsPopulation.hh"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  ::SWA::ObjectPtr<maslo_WorkoutTimerConstants> maslo_WorkoutTimerConstants::getInstance ( ::SWA::IdType id )
  {
    return maslo_WorkoutTimerConstantsPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_WorkoutTimerConstants::getNextArchId ( )
  {
    return maslo_WorkoutTimerConstantsPopulation::getSingleton().getNextArchId();
  }

  maslo_WorkoutTimerConstants::maslo_WorkoutTimerConstants ( )
    : isDeletedFlag()
  {
  }

  maslo_WorkoutTimerConstants::~maslo_WorkoutTimerConstants ( )
  {
  }

  ::SWA::ObjectPtr<maslo_WorkoutTimerConstants> maslo_WorkoutTimerConstants::createInstance ( int32_t masla_id,
                                                                                              int32_t masla_timerPeriod )
  {
    return maslo_WorkoutTimerConstantsPopulation::getSingleton().createInstance( masla_id, masla_timerPeriod );
  }

  void maslo_WorkoutTimerConstants::deleteInstance ( )
  {
    maslo_WorkoutTimerConstantsPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_WorkoutTimerConstants>( this ) );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_WorkoutTimerConstants::getPopulationSize ( )
  {
    return maslo_WorkoutTimerConstantsPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_WorkoutTimerConstants> > maslo_WorkoutTimerConstants::findAll ( )
  {
    return maslo_WorkoutTimerConstantsPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_WorkoutTimerConstants> maslo_WorkoutTimerConstants::findOne ( )
  {
    return maslo_WorkoutTimerConstantsPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_WorkoutTimerConstants> maslo_WorkoutTimerConstants::findOnly ( )
  {
    return maslo_WorkoutTimerConstantsPopulation::getSingleton().findOnly();
  }

  ::std::ostream& operator<< ( ::std::ostream&                    stream,
                               const maslo_WorkoutTimerConstants& obj )
  {
    stream << "(";
    stream << obj.get_masla_id();
    stream << ",";
    stream << obj.get_masla_timerPeriod();
    stream << ")";
    return stream;
  }

}
