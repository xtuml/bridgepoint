//
// File: __Tracking__GoalSpecConstantsPopulation.cc
//
#include "__Tracking__GoalSpecConstantsPopulation.hh"

namespace masld_Tracking
{
  maslo_GoalSpecConstantsPopulation::maslo_GoalSpecConstantsPopulation ( )
  {
  }

  maslo_GoalSpecConstantsPopulation::~maslo_GoalSpecConstantsPopulation ( )
  {
  }

}
