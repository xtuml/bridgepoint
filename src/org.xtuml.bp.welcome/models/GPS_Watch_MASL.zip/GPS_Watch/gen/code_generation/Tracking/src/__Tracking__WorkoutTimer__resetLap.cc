//
// File: __Tracking__WorkoutTimer__resetLap.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/shared_ptr.hpp"
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  void maslo_WorkoutTimer::state_maslst_resetLap ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_WorkoutTimer, stateId_maslst_resetLap);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // trackLog : instance of TrackLog;
        ::SWA::ObjectPtr<maslo_TrackLog> maslv_trackLog;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_trackLog(0, maslv_trackLog);

        // trackLog := find_one TrackLog ();
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslv_trackLog = maslo_TrackLog::findOne();
        }

        // if (null /= trackLog) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          if ( ::SWA::Null != maslv_trackLog )
          {

            // trackLog.addLapMarker()
            {
              ::SWA::Stack::ExecutingStatement statement(6);
              maslv_trackLog->masls_addLapMarker();
            }
          }
        }

        // generate WorkoutTimer.lapResetComplete () to this;
        {
          ::SWA::Stack::ExecutingStatement statement(8);
          ::SWA::Process::getInstance().getEventQueue().addEvent( ::SWA::ObjectPtr<maslo_WorkoutTimer>( this )->create_maslo_WorkoutTimer_maslev_lapResetComplete( objectId_maslo_WorkoutTimer, getArchitectureId() ) );
        }
      }
    }
  }

}
