//
// File: __Tracking__Goal.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Achievement.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalEvents.hh"
#include "__Tracking__GoalPopulation.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include <cstddef>
#include <iostream>
#include <stdexcept>
#include <stdint.h>
#include <string>
#include "swa/Bag.hh"
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/NameFormatter.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProcessMonitor.hh"
#include "swa/ProgramError.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  ::SWA::ObjectPtr<maslo_Goal> maslo_Goal::getInstance ( ::SWA::IdType id )
  {
    return maslo_GoalPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_Goal::getNextArchId ( )
  {
    return maslo_GoalPopulation::getSingleton().getNextArchId();
  }

  void maslo_Goal::process_maslo_Goal_maslev_Completed ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_Executing:
      {
        state_maslst_Completed();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_Goal, getArchitectureId(), getCurrentState(), maslst_Completed );
        setCurrentState( maslst_Completed );
        break;
      }
      case maslst_Completed:
        /* Ignore */
        break;

      case maslst_Paused:
      {
        state_maslst_Completed();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_Goal, getArchitectureId(), getCurrentState(), maslst_Completed );
        setCurrentState( maslst_Completed );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_Goal, eventId_maslo_Goal_maslev_Completed ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_Goal ) + "(" + (::boost::lexical_cast< ::std::string>( get_masla_ID() ) + "," + ::boost::lexical_cast< ::std::string>( get_masla_session_startTime() ) + "," + ::boost::lexical_cast< ::std::string>( get_masla_spec_sequenceNumber() )) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_Goal, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_Goal::create_maslo_Goal_maslev_Completed ( int           sourceObj,
                                                                                      ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_Goal_maslev_Completed());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_Goal::consume_maslo_Goal_maslev_Completed ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_Goal> instance = getInstance( id );
    if ( instance ) instance->process_maslo_Goal_maslev_Completed();
  }

  int Event_maslo_Goal_maslev_Completed::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_Goal_maslev_Completed::getObjectId ( ) const
  {
    return objectId_maslo_Goal;
  }

  int Event_maslo_Goal_maslev_Completed::getEventId ( ) const
  {
    return maslo_Goal::eventId_maslo_Goal_maslev_Completed;
  }

  Event_maslo_Goal_maslev_Completed::Event_maslo_Goal_maslev_Completed ( )
  {
  }

  void Event_maslo_Goal_maslev_Completed::invoke ( ) const
  {
    maslo_Goal::consume_maslo_Goal_maslev_Completed( getDestInstanceId() );
  }

  void maslo_Goal::process_maslo_Goal_maslev_Evaluate ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_Executing:
      {
        state_maslst_Executing();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_Goal, getArchitectureId(), getCurrentState(), maslst_Executing );
        setCurrentState( maslst_Executing );
        break;
      }
      case maslst_Completed:
        /* Ignore */
        break;

      case maslst_Paused:
      {
        state_maslst_Evaluating();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_Goal, getArchitectureId(), getCurrentState(), maslst_Evaluating );
        setCurrentState( maslst_Evaluating );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_Goal, eventId_maslo_Goal_maslev_Evaluate ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_Goal ) + "(" + (::boost::lexical_cast< ::std::string>( get_masla_ID() ) + "," + ::boost::lexical_cast< ::std::string>( get_masla_session_startTime() ) + "," + ::boost::lexical_cast< ::std::string>( get_masla_spec_sequenceNumber() )) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_Goal, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_Goal::create_maslo_Goal_maslev_Evaluate ( int           sourceObj,
                                                                                     ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_Goal_maslev_Evaluate());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_Goal::consume_maslo_Goal_maslev_Evaluate ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_Goal> instance = getInstance( id );
    if ( instance ) instance->process_maslo_Goal_maslev_Evaluate();
  }

  int Event_maslo_Goal_maslev_Evaluate::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_Goal_maslev_Evaluate::getObjectId ( ) const
  {
    return objectId_maslo_Goal;
  }

  int Event_maslo_Goal_maslev_Evaluate::getEventId ( ) const
  {
    return maslo_Goal::eventId_maslo_Goal_maslev_Evaluate;
  }

  Event_maslo_Goal_maslev_Evaluate::Event_maslo_Goal_maslev_Evaluate ( )
  {
  }

  void Event_maslo_Goal_maslev_Evaluate::invoke ( ) const
  {
    maslo_Goal::consume_maslo_Goal_maslev_Evaluate( getDestInstanceId() );
  }

  void maslo_Goal::process_maslo_Goal_maslev_Pause ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_Executing:
      {
        state_maslst_Paused();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_Goal, getArchitectureId(), getCurrentState(), maslst_Paused );
        setCurrentState( maslst_Paused );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_Goal, eventId_maslo_Goal_maslev_Pause ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_Goal ) + "(" + (::boost::lexical_cast< ::std::string>( get_masla_ID() ) + "," + ::boost::lexical_cast< ::std::string>( get_masla_session_startTime() ) + "," + ::boost::lexical_cast< ::std::string>( get_masla_spec_sequenceNumber() )) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_Goal, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_Goal::create_maslo_Goal_maslev_Pause ( int           sourceObj,
                                                                                  ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_Goal_maslev_Pause());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_Goal::consume_maslo_Goal_maslev_Pause ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_Goal> instance = getInstance( id );
    if ( instance ) instance->process_maslo_Goal_maslev_Pause();
  }

  int Event_maslo_Goal_maslev_Pause::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_Goal_maslev_Pause::getObjectId ( ) const
  {
    return objectId_maslo_Goal;
  }

  int Event_maslo_Goal_maslev_Pause::getEventId ( ) const
  {
    return maslo_Goal::eventId_maslo_Goal_maslev_Pause;
  }

  Event_maslo_Goal_maslev_Pause::Event_maslo_Goal_maslev_Pause ( )
  {
  }

  void Event_maslo_Goal_maslev_Pause::invoke ( ) const
  {
    maslo_Goal::consume_maslo_Goal_maslev_Pause( getDestInstanceId() );
  }

  void maslo_Goal::process_maslo_Goal_maslev_evaluationComplete ( )
  {
    switch ( getCurrentState() )
    {
      case maslst_Evaluating:
      {
        state_maslst_Executing();
        ::SWA::ProcessMonitor::getInstance().transitioningState( getDomain().getId(), objectId_maslo_Goal, getArchitectureId(), getCurrentState(), maslst_Executing );
        setCurrentState( maslst_Executing );
        break;
      }
      default: throw ::std::out_of_range( "Event " + ::SWA::NameFormatter::formatEventName( getDomain().getId(), objectId_maslo_Goal, eventId_maslo_Goal_maslev_evaluationComplete ) + " sent to " + ::SWA::NameFormatter::formatObjectName( getDomain().getId(), objectId_maslo_Goal ) + "(" + (::boost::lexical_cast< ::std::string>( get_masla_ID() ) + "," + ::boost::lexical_cast< ::std::string>( get_masla_session_startTime() ) + "," + ::boost::lexical_cast< ::std::string>( get_masla_spec_sequenceNumber() )) + ")" + " cannot happen in state " + ::SWA::NameFormatter::formatStateName( getDomain().getId(), objectId_maslo_Goal, getCurrentState() ) );
    }

  }

  ::boost::shared_ptr< ::SWA::Event> maslo_Goal::create_maslo_Goal_maslev_evaluationComplete ( int           sourceObj,
                                                                                               ::SWA::IdType sourceInstance )
  {
    ::boost::shared_ptr< ::SWA::Event> event(new Event_maslo_Goal_maslev_evaluationComplete());
    event->setDest( getArchitectureId() );
    if ( sourceObj != -1 ) event->setSource( sourceObj, sourceInstance );
    return event;
  }

  void maslo_Goal::consume_maslo_Goal_maslev_evaluationComplete ( ::SWA::IdType id )
  {
    ::SWA::ObjectPtr<maslo_Goal> instance = getInstance( id );
    if ( instance ) instance->process_maslo_Goal_maslev_evaluationComplete();
  }

  int Event_maslo_Goal_maslev_evaluationComplete::getDomainId ( ) const
  {
    return getDomain().getId();
  }

  int Event_maslo_Goal_maslev_evaluationComplete::getObjectId ( ) const
  {
    return objectId_maslo_Goal;
  }

  int Event_maslo_Goal_maslev_evaluationComplete::getEventId ( ) const
  {
    return maslo_Goal::eventId_maslo_Goal_maslev_evaluationComplete;
  }

  Event_maslo_Goal_maslev_evaluationComplete::Event_maslo_Goal_maslev_evaluationComplete ( )
  {
  }

  void Event_maslo_Goal_maslev_evaluationComplete::invoke ( ) const
  {
    maslo_Goal::consume_maslo_Goal_maslev_evaluationComplete( getDestInstanceId() );
  }

  maslo_Goal::maslo_Goal ( )
    : isDeletedFlag()
  {
  }

  maslo_Goal::~maslo_Goal ( )
  {
  }

  ::SWA::ObjectPtr<maslo_Goal> maslo_Goal::createInstance ( const maslt_GoalDisposition&           masla_disposition,
                                                            double                                 masla_startingPoint,
                                                            int32_t                                masla_ID,
                                                            const ::SWA::EventTimers::TimerIdType& masla_evaluationTimer,
                                                            const ::SWA::Timestamp&                masla_session_startTime,
                                                            int32_t                                masla_spec_sequenceNumber,
                                                            Type                                   currentState )
  {
    return maslo_GoalPopulation::getSingleton().createInstance( masla_disposition, masla_startingPoint, masla_ID, masla_evaluationTimer, masla_session_startTime, masla_spec_sequenceNumber, currentState );
  }

  void maslo_Goal::deleteInstance ( )
  {
    if ( count_R9_specified_by_GoalSpec() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R9 still linked" );
    if ( count_R11_is_currently_executing_within_WorkoutSession() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R11 still linked" );
    if ( count_R12_has_recorded_Achievement() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R12 still linked" );
    if ( count_R13_was_executed_within_WorkoutSession() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R13 still linked" );
    if ( count_R14_has_open_Achievement() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R14 still linked" );
    maslo_GoalPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_Goal>( this ) );
    ::SWA::EventTimers::getInstance().deleteTimer( get_masla_evaluationTimer() );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_Goal::getPopulationSize ( )
  {
    return maslo_GoalPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_Goal> > maslo_Goal::findAll ( )
  {
    return maslo_GoalPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_Goal> maslo_Goal::findOne ( )
  {
    return maslo_GoalPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_Goal> maslo_Goal::findOnly ( )
  {
    return maslo_GoalPopulation::getSingleton().findOnly();
  }

  ::std::size_t maslo_Goal::count_R9_specified_by_GoalSpec ( ) const
  {
    return navigate_R9_specified_by_GoalSpec() == ::SWA::Null ? 0
                                                              : 1;
  }

  void maslo_Goal::checked_link_R9_specified_by_GoalSpec ( const ::SWA::ObjectPtr<maslo_GoalSpec>& rhs )
  {
    if ( get_masla_session_startTime() != rhs->get_masla_session_startTime() || get_masla_spec_sequenceNumber() != rhs->get_masla_sequenceNumber() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R9_specified_by_GoalSpec( rhs );
  }

  void maslo_Goal::unlink_R9_specified_by_GoalSpec ( )
  {
    const ::SWA::ObjectPtr<maslo_GoalSpec>& rhs = navigate_R9_specified_by_GoalSpec();
    if ( rhs ) unlink_R9_specified_by_GoalSpec( rhs );
  }

  ::std::size_t maslo_Goal::count_R11_is_currently_executing_within_WorkoutSession ( ) const
  {
    return navigate_R11_is_currently_executing_within_WorkoutSession() == ::SWA::Null ? 0
                                                                                      : 1;
  }

  void maslo_Goal::checked_link_R11_is_currently_executing_within_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs )
  {
    if ( get_masla_session_startTime() != rhs->get_masla_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R11_is_currently_executing_within_WorkoutSession( rhs );
  }

  void maslo_Goal::unlink_R11_is_currently_executing_within_WorkoutSession ( )
  {
    const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs = navigate_R11_is_currently_executing_within_WorkoutSession();
    if ( rhs ) unlink_R11_is_currently_executing_within_WorkoutSession( rhs );
  }

  ::std::size_t maslo_Goal::count_R12_has_recorded_Achievement ( ) const
  {
    return navigate_R12_has_recorded_Achievement().size();
  }

  void maslo_Goal::checked_link_R12_has_recorded_Achievement ( const ::SWA::ObjectPtr<maslo_Achievement>& rhs )
  {
    if ( rhs->get_masla_session_startTime() != get_masla_session_startTime() || rhs->get_masla_goal_ID() != get_masla_ID() || rhs->get_masla_spec_sequenceNumber() != get_masla_spec_sequenceNumber() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R12_has_recorded_Achievement( rhs );
  }

  void maslo_Goal::checked_link_R12_has_recorded_Achievement ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Achievement> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_Achievement> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it )
    {
      if ( (*it)->get_masla_session_startTime() != get_masla_session_startTime() || (*it)->get_masla_goal_ID() != get_masla_ID() || (*it)->get_masla_spec_sequenceNumber() != get_masla_spec_sequenceNumber() )
      {
        throw ::SWA::ProgramError( "referential integrity failure" );
      }
    }
    link_R12_has_recorded_Achievement( rhs );
  }

  void maslo_Goal::link_R12_has_recorded_Achievement ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Achievement> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_Achievement> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it ) link_R12_has_recorded_Achievement( *it );
  }

  void maslo_Goal::unlink_R12_has_recorded_Achievement ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Achievement> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_Achievement> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it ) unlink_R12_has_recorded_Achievement( *it );
  }

  void maslo_Goal::unlink_R12_has_recorded_Achievement ( )
  {
    unlink_R12_has_recorded_Achievement( navigate_R12_has_recorded_Achievement() );
  }

  ::std::size_t maslo_Goal::count_R13_was_executed_within_WorkoutSession ( ) const
  {
    return navigate_R13_was_executed_within_WorkoutSession() == ::SWA::Null ? 0
                                                                            : 1;
  }

  void maslo_Goal::checked_link_R13_was_executed_within_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs )
  {
    if ( get_masla_session_startTime() != rhs->get_masla_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R13_was_executed_within_WorkoutSession( rhs );
  }

  void maslo_Goal::unlink_R13_was_executed_within_WorkoutSession ( )
  {
    const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs = navigate_R13_was_executed_within_WorkoutSession();
    if ( rhs ) unlink_R13_was_executed_within_WorkoutSession( rhs );
  }

  ::std::size_t maslo_Goal::count_R14_has_open_Achievement ( ) const
  {
    return navigate_R14_has_open_Achievement() == ::SWA::Null ? 0
                                                              : 1;
  }

  void maslo_Goal::checked_link_R14_has_open_Achievement ( const ::SWA::ObjectPtr<maslo_Achievement>& rhs )
  {
    if ( rhs->get_masla_session_startTime() != get_masla_session_startTime() || rhs->get_masla_goal_ID() != get_masla_ID() || rhs->get_masla_spec_sequenceNumber() != get_masla_spec_sequenceNumber() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R14_has_open_Achievement( rhs );
  }

  void maslo_Goal::unlink_R14_has_open_Achievement ( )
  {
    const ::SWA::ObjectPtr<maslo_Achievement>& rhs = navigate_R14_has_open_Achievement();
    if ( rhs ) unlink_R14_has_open_Achievement( rhs );
  }

  ::std::ostream& operator<< ( ::std::ostream&   stream,
                               const maslo_Goal& obj )
  {
    stream << "(";
    stream << obj.get_masla_disposition();
    stream << ",";
    stream << obj.get_masla_startingPoint();
    stream << ",";
    stream << obj.get_masla_ID();
    stream << ",";
    stream << obj.get_masla_evaluationTimer();
    stream << ",";
    stream << obj.get_masla_session_startTime();
    stream << ",";
    stream << obj.get_masla_spec_sequenceNumber();
    stream << ")";
    return stream;
  }

}
