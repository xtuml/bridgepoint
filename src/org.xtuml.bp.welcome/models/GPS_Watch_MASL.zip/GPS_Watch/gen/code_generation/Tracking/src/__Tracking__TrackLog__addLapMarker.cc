//
// File: __Tracking__TrackLog__addLapMarker.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__LapMarker.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/bind.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/Timestamp.hh"
#include "swa/navigate.hh"

namespace masld_Tracking
{
  void maslo_TrackLog::masls_addLapMarker ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_TrackLog, serviceId_masls_addLapMarker);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(4);
      {

        // timer : instance of WorkoutTimer;
        ::SWA::ObjectPtr<maslo_WorkoutTimer> maslv_timer;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_timer(0, maslv_timer);

        // lapMarker : instance of LapMarker;
        ::SWA::ObjectPtr<maslo_LapMarker> maslv_lapMarker;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_lapMarker(1, maslv_lapMarker);

        // timer := this -> R4.represents_path_for.WorkoutSession -> R8.is_timed_by.WorkoutTimer;
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          maslv_timer = ::SWA::navigate_one<maslo_WorkoutTimer>( ::SWA::navigate_one<maslo_WorkoutSession>( ::SWA::ObjectPtr<maslo_TrackLog>( this ), ::boost::bind( &maslo_TrackLog::navigate_R4_represents_path_for_WorkoutSession, _1 ) ), ::boost::bind( &maslo_WorkoutSession::navigate_R8_is_timed_by_WorkoutTimer, _1 ) );
        }

        // lapMarker := create LapMarker (
        //            session_startTime => this.session_startTime,
        //            lapTime           => timer.time );
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          maslv_lapMarker = maslo_LapMarker::createInstance( maslv_timer->get_masla_time(), ::SWA::ObjectPtr<maslo_TrackLog>( this )->get_masla_session_startTime() );
        }

        // link this R5.has_laps_defined_by.LapMarker  lapMarker;
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          ::SWA::ObjectPtr<maslo_TrackLog>( this )->checked_link_R5_has_laps_defined_by_LapMarker( maslv_lapMarker );
        }

        // this.updateDisplay()
        {
          ::SWA::Stack::ExecutingStatement statement(10);
          ::SWA::ObjectPtr<maslo_TrackLog>( this )->masls_updateDisplay();
        }
      }
    }
  }

}
