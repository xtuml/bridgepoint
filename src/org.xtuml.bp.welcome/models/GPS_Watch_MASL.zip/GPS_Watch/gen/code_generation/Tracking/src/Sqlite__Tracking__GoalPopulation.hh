//
// File: Sqlite__Tracking__GoalPopulation.hh
//
#ifndef Sqlite_Tracking_Goal_Population_hh
#define Sqlite_Tracking_Goal_Population_hh

#include "Sqlite__Tracking__Goal.hh"
#include "Sqlite__Tracking__GoalMapper.hh"
#include "Sqlite__Tracking__R11Mapper.hh"
#include "Sqlite__Tracking__R12Mapper.hh"
#include "Sqlite__Tracking__R13Mapper.hh"
#include "Sqlite__Tracking__R14Mapper.hh"
#include "Sqlite__Tracking__R9Mapper.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalPopulation.hh"
#include "boost/signals2.hpp"
#include <cstddef>
#include "sql/Population.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslt_GoalDisposition;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_GoalSpec;
  }
  namespace masld_Tracking
  {
    class maslo_WorkoutSession;
  }
  namespace masld_Tracking
  {
    class maslo_Achievement;
  }
}
namespace masld_Tracking
{
  class maslo_GoalSpec;
  class maslo_WorkoutSession;
  class maslo_Achievement;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_GoalPopulation
      : public ::SQL::SqlPopulation< ::masld_Tracking::maslo_Goal,maslo_Goal,maslo_GoalMapper,::masld_Tracking::maslo_GoalPopulation>
    {

      // Constructors and Destructors
      private:
        maslo_GoalPopulation ( );
        ~maslo_GoalPopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> createInstance ( const ::masld_Tracking::maslt_GoalDisposition& masla_disposition,
                                                                                 double                                         masla_startingPoint,
                                                                                 int32_t                                        masla_ID,
                                                                                 const ::SWA::EventTimers::TimerIdType&         masla_evaluationTimer,
                                                                                 const ::SWA::Timestamp&                        masla_session_startTime,
                                                                                 int32_t                                        masla_spec_sequenceNumber,
                                                                                 ::masld_Tracking::maslo_Goal::Type             currentState );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> instance );


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Relationship Counts
      public:
        ::std::size_t count_R9_specified_by_GoalSpec ( const ::SWA::ObjectPtr<maslo_Goal>& lhs );
        ::std::size_t count_R11_is_currently_executing_within_WorkoutSession ( const ::SWA::ObjectPtr<maslo_Goal>& lhs );
        ::std::size_t count_R12_has_recorded_Achievement ( const ::SWA::ObjectPtr<maslo_Goal>& lhs );
        ::std::size_t count_R13_was_executed_within_WorkoutSession ( const ::SWA::ObjectPtr<maslo_Goal>& lhs );
        ::std::size_t count_R14_has_open_Achievement ( const ::SWA::ObjectPtr<maslo_Goal>& lhs );


      // Relationship Links
      public:
        void link_R9_specified_by_GoalSpec ( const ::SWA::ObjectPtr<maslo_Goal>&     lhs,
                                             const ::SWA::ObjectPtr<maslo_GoalSpec>& rhs );
        void unlink_R9_specified_by_GoalSpec ( const ::SWA::ObjectPtr<maslo_Goal>&     lhs,
                                               const ::SWA::ObjectPtr<maslo_GoalSpec>& rhs );
        void link_R11_is_currently_executing_within_WorkoutSession ( const ::SWA::ObjectPtr<maslo_Goal>&           lhs,
                                                                     const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs );
        void unlink_R11_is_currently_executing_within_WorkoutSession ( const ::SWA::ObjectPtr<maslo_Goal>&           lhs,
                                                                       const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs );
        void link_R12_has_recorded_Achievement ( const ::SWA::ObjectPtr<maslo_Goal>&        lhs,
                                                 const ::SWA::ObjectPtr<maslo_Achievement>& rhs );
        void unlink_R12_has_recorded_Achievement ( const ::SWA::ObjectPtr<maslo_Goal>&        lhs,
                                                   const ::SWA::ObjectPtr<maslo_Achievement>& rhs );
        void link_R13_was_executed_within_WorkoutSession ( const ::SWA::ObjectPtr<maslo_Goal>&           lhs,
                                                           const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs );
        void unlink_R13_was_executed_within_WorkoutSession ( const ::SWA::ObjectPtr<maslo_Goal>&           lhs,
                                                             const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs );
        void link_R14_has_open_Achievement ( const ::SWA::ObjectPtr<maslo_Goal>&        lhs,
                                             const ::SWA::ObjectPtr<maslo_Achievement>& rhs );
        void unlink_R14_has_open_Achievement ( const ::SWA::ObjectPtr<maslo_Goal>&        lhs,
                                               const ::SWA::ObjectPtr<maslo_Achievement>& rhs );


      // Relationship Navigations
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> navigate_R9_specified_by_GoalSpec ( const ::SWA::ObjectPtr<maslo_Goal>& lhs );
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> navigate_R11_is_currently_executing_within_WorkoutSession ( const ::SWA::ObjectPtr<maslo_Goal>& lhs );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> > navigate_R12_has_recorded_Achievement ( const ::SWA::ObjectPtr<maslo_Goal>& lhs );
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> navigate_R13_was_executed_within_WorkoutSession ( const ::SWA::ObjectPtr<maslo_Goal>& lhs );
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> navigate_R14_has_open_Achievement ( const ::SWA::ObjectPtr<maslo_Goal>& lhs );


      // Singleton Registration
      public:
        static maslo_GoalPopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;
        RelationshipR9Mapper& R9Mapper;
        RelationshipR11Mapper& R11Mapper;
        RelationshipR12Mapper& R12Mapper;
        RelationshipR13Mapper& R13Mapper;
        RelationshipR14Mapper& R14Mapper;


    };
  }
}
#endif // Sqlite_Tracking_Goal_Population_hh
