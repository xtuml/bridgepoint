//
// File: __Tracking__GoalTest_1.cc
//
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_services.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking_private_services.hh"
#include "swa/Domain.hh"
#include "swa/Stack.hh"

namespace masld_Tracking
{
  void masls_GoalTest_1 ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_GoalTest_1);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // Tracking::Initialize()
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          interceptor_masls_Initialize::instance().callService()();
        }

        // Tracking::newGoalSpec(Tracking::GoalSpan.Distance, Tracking::GoalCriteria.Pace, 150.0, 8.0, 2.0, 1)
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          interceptor_masls_newGoalSpec::instance().callService()( maslt_GoalSpan::masle_Distance, maslt_GoalCriteria::masle_Pace, 150.0, 8.0, 2.0, 1ll );
        }

        // Tracking::newGoalSpec(Tracking::GoalSpan.Time, Tracking::GoalCriteria.HeartRate, 10, 80.0, 60.0, 2)
        {
          ::SWA::Stack::ExecutingStatement statement(9);
          interceptor_masls_newGoalSpec::instance().callService()( maslt_GoalSpan::masle_Time, maslt_GoalCriteria::masle_HeartRate, 10ll, 80.0, 60.0, 2ll );
        }

        // Tracking::newGoalSpec(Tracking::GoalSpan.Time, Tracking::GoalCriteria.Pace, 15, 6.0, 5.0, 3)
        {
          ::SWA::Stack::ExecutingStatement statement(11);
          interceptor_masls_newGoalSpec::instance().callService()( maslt_GoalSpan::masle_Time, maslt_GoalCriteria::masle_Pace, 15ll, 6.0, 5.0, 3ll );
        }

        // Tracking::newGoalSpec(Tracking::GoalSpan.Time, Tracking::GoalCriteria.Pace, 15, 2.0, 1.0, 4)
        {
          ::SWA::Stack::ExecutingStatement statement(13);
          interceptor_masls_newGoalSpec::instance().callService()( maslt_GoalSpan::masle_Time, maslt_GoalCriteria::masle_Pace, 15ll, 2.0, 1.0, 4ll );
        }
      }
    }
  }

  const bool localServiceRegistration_masls_GoalTest_1 = interceptor_masls_GoalTest_1::instance().registerLocal( &masls_GoalTest_1 );

}
