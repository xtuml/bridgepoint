//
// File: __Tracking__AchievementPopulation.cc
//
#include "__Tracking__AchievementPopulation.hh"

namespace masld_Tracking
{
  maslo_AchievementPopulation::maslo_AchievementPopulation ( )
  {
  }

  maslo_AchievementPopulation::~maslo_AchievementPopulation ( )
  {
  }

}
