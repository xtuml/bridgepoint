//
// File: __Tracking__UI__setTime.cc
//
#include "LOG_OOA/__LOG_services.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"

namespace masld_Tracking
{
  void maslb_UI::masls_setTime ( int32_t maslp_time )
  {
    getInstance().override_masls_setTime.getFunction()( maslp_time );
  }

  bool maslb_UI::register_masls_setTime ( ::SWA::FunctionOverrider<void (int32_t)>::FunctionPtr override )
  {
    getInstance().override_masls_setTime.override( override );
    return true;
  }

  bool maslb_UI::overriden_masls_setTime ( )
  {
    return getInstance().override_masls_setTime.isOverridden();
  }

  void maslb_UI::domain_masls_setTime ( int32_t maslp_time )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringTerminatorService enteringActionMarker(getDomain().getId(), terminatorId_maslb_UI, serviceId_masls_setTime);
      ::SWA::Stack::DeclareParameter pm_maslp_time(maslp_time);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // LOG::LogInfo("Sending message 'setTime' on terminator UI")
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          ::masld_LOG::interceptor_masls_LogInfo::instance().callService()( ::SWA::String( "Sending message 'setTime' on terminator UI" ) );
        }
      }
    }
  }

}
