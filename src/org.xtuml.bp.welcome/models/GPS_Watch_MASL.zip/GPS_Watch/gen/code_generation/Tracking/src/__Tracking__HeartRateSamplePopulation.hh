//
// File: __Tracking__HeartRateSamplePopulation.hh
//
#ifndef _Tracking_Heart_Rate_Sample_Population_hh
#define _Tracking_Heart_Rate_Sample_Population_hh

#include <cstddef>
#include <stdint.h>
#include "swa/DynamicSingleton.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_HeartRateSample;
  class maslo_HeartRateSamplePopulation
    : public ::SWA::DynamicSingleton<maslo_HeartRateSamplePopulation>
  {

    // Instance Creation
    public:
      virtual ::SWA::IdType getNextArchId ( ) = 0;
      virtual ::SWA::ObjectPtr<maslo_HeartRateSample> createInstance ( int32_t                 masla_heartRate,
                                                                       int32_t                 masla_time,
                                                                       const ::SWA::Timestamp& masla_session_startTime ) = 0;
      virtual void deleteInstance ( ::SWA::ObjectPtr<maslo_HeartRateSample> instance ) = 0;
      virtual ::std::size_t size ( ) const = 0;


    // Instance Retrieval
    public:
      virtual ::SWA::ObjectPtr<maslo_HeartRateSample> getInstance ( ::SWA::IdType id ) const = 0;
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_HeartRateSample> > findAll ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_HeartRateSample> findOne ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_HeartRateSample> findOnly ( ) const = 0;


    // Constructors and Destructors
    protected:
      maslo_HeartRateSamplePopulation ( );
      virtual ~maslo_HeartRateSamplePopulation ( );


    // Prevent copy
    private:
      maslo_HeartRateSamplePopulation ( const maslo_HeartRateSamplePopulation& rhs );
      maslo_HeartRateSamplePopulation& operator= ( const maslo_HeartRateSamplePopulation& rhs );


  };
}
#endif // _Tracking_Heart_Rate_Sample_Population_hh
