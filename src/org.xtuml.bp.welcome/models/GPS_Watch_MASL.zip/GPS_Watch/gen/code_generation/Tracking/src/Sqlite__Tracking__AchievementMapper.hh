//
// File: Sqlite__Tracking__AchievementMapper.hh
//
#ifndef Sqlite_Tracking_Achievement_Mapper_hh
#define Sqlite_Tracking_Achievement_Mapper_hh

#include "Sqlite__Tracking__Achievement.hh"
#include "__Tracking__Achievement.hh"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_AchievementMapper
      : public ::SQL::ObjectMapper< ::masld_Tracking::maslo_Achievement,maslo_Achievement>
    {

      // Instance creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> createInstance ( int32_t                 masla_startTime,
                                                                                        int32_t                 masla_endTime,
                                                                                        const ::SWA::Timestamp& masla_session_startTime,
                                                                                        int32_t                 masla_goal_ID,
                                                                                        int32_t                 masla_spec_sequenceNumber );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> instance );
      protected:
        virtual bool doPostInit ( );


      // Constructors and Destructors
      public:
        maslo_AchievementMapper ( );
        virtual ~maslo_AchievementMapper ( );


      // Attributes
      private:
        ::boost::unordered_set<maslo_Achievement::PrimaryKeyType> primarykey_cache;


    };
  }
}
#endif // Sqlite_Tracking_Achievement_Mapper_hh
