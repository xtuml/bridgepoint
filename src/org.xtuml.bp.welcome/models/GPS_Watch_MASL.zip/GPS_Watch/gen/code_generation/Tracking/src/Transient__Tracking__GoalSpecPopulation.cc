//
// File: Transient__Tracking__GoalSpecPopulation.cc
//
#include "Tracking_OOA/__Tracking_types.hh"
#include "Transient__Tracking__GoalSpec.hh"
#include "Transient__Tracking__GoalSpecPopulation.hh"
#include "__Tracking__GoalSpec.hh"
#include "boost/bind.hpp"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Timestamp.hh"
#include "swa/collection.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_GoalSpecPopulation::maslo_GoalSpecPopulation ( )
      : masla_sequenceNumbermasla_session_startTime_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> maslo_GoalSpecPopulation::createInstance ( double                                      masla_minimum,
                                                                                                   double                                      masla_maximum,
                                                                                                   double                                      masla_span,
                                                                                                   const ::masld_Tracking::maslt_GoalCriteria& masla_criteriaType,
                                                                                                   const ::masld_Tracking::maslt_GoalSpan&     masla_spanType,
                                                                                                   int32_t                                     masla_sequenceNumber,
                                                                                                   const ::SWA::Timestamp&                     masla_session_startTime,
                                                                                                   int32_t                                     masla_last_goal_ID )
    {
      if ( exists_masla_sequenceNumbermasla_session_startTime( masla_sequenceNumber, masla_session_startTime ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> instance(new maslo_GoalSpec(  masla_minimum,
                     masla_maximum,
                     masla_span,
                     masla_criteriaType,
                     masla_spanType,
                     masla_sequenceNumber,
                     masla_session_startTime,
                     masla_last_goal_ID ));
      addInstance( instance );
      return instance;
    }

    void maslo_GoalSpecPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> instance )
    {
      masla_sequenceNumbermasla_session_startTime_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t,::SWA::Timestamp>,::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> >::value_type( ::boost::make_tuple( instance->get_masla_sequenceNumber(), instance->get_masla_session_startTime() ), instance ) );
    }

    void maslo_GoalSpecPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> instance )
    {
      masla_sequenceNumbermasla_session_startTime_Lookup.erase( ::boost::make_tuple( instance->get_masla_sequenceNumber(), instance->get_masla_session_startTime() ) );
    }

    bool maslo_GoalSpecPopulation::exists_masla_sequenceNumbermasla_session_startTime ( int32_t                 masla_sequenceNumber,
                                                                                        const ::SWA::Timestamp& masla_session_startTime ) const
    {
      return masla_sequenceNumbermasla_session_startTime_Lookup.find( ::boost::make_tuple( masla_sequenceNumber, masla_session_startTime ) ) != masla_sequenceNumbermasla_session_startTime_Lookup.end();
    }

    maslo_GoalSpecPopulation& maslo_GoalSpecPopulation::getPopulation ( )
    {
      static maslo_GoalSpecPopulation population;
      return population;
    }

    bool maslo_GoalSpecPopulation::registered = maslo_GoalSpecPopulation::registerSingleton( &maslo_GoalSpecPopulation::getPopulation );

    // MASL find: (sequenceNumber = p1)
    ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> maslo_GoalSpecPopulation::findOne_OPmasl_sequenceNumber_maslEQp1CP ( int32_t p1 ) const
    {
      return ::SWA::find_one( begin(), end(), ::boost::bind( &::masld_Tracking::maslo_GoalSpec::findPredicate_OPmasl_sequenceNumber_maslEQp1CP, ::boost::bind( &::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>::deref, _1 ), p1 ) );
    }

  }
}
