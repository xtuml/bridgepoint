//
// File: Transient__Tracking__LapMarker.cc
//
#include "Transient__Tracking__LapMarker.hh"
#include "Transient__Tracking__TrackLog.hh"
#include "__Tracking__TrackLog.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "transient/ToManyRelationship.hh"
#include "transient/ToOneRelationship.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_LapMarker::maslo_LapMarker ( int32_t                 masla_lapTime,
                                       const ::SWA::Timestamp& masla_session_startTime )
      : architectureId(getNextArchId()),
        masla_lapTime(masla_lapTime),
        masla_session_startTime(masla_session_startTime),
        R5_marks_end_of_lap_in_TrackLog()
    {
    }

    ToOneRelationship<maslo_TrackLog>& maslo_LapMarker::get_R5_marks_end_of_lap_in_TrackLog ( )
    {
      return R5_marks_end_of_lap_in_TrackLog;
    }

    const ToOneRelationship<maslo_TrackLog>& maslo_LapMarker::get_R5_marks_end_of_lap_in_TrackLog ( ) const
    {
      return R5_marks_end_of_lap_in_TrackLog;
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> maslo_LapMarker::navigate_R5_marks_end_of_lap_in_TrackLog ( ) const
    {
      return get_R5_marks_end_of_lap_in_TrackLog().navigate();
    }

    ::std::size_t maslo_LapMarker::count_R5_marks_end_of_lap_in_TrackLog ( ) const
    {
      return get_R5_marks_end_of_lap_in_TrackLog().count();
    }

    void maslo_LapMarker::link_R5_marks_end_of_lap_in_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackLog> rhs2 = rhs.downcast<maslo_TrackLog>();
      this->get_R5_marks_end_of_lap_in_TrackLog().link( rhs2 );
      try
      {
        rhs2->get_R5_has_laps_defined_by_LapMarker().link( ::SWA::ObjectPtr<maslo_LapMarker>( this ) );
      }
      catch ( ... )
      {
        this->get_R5_marks_end_of_lap_in_TrackLog().unlink( rhs2 );
        throw;
      }
    }

    void maslo_LapMarker::unlink_R5_marks_end_of_lap_in_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackLog> rhs2 = rhs.downcast<maslo_TrackLog>();
      this->get_R5_marks_end_of_lap_in_TrackLog().unlink( rhs2 );
      try
      {
        rhs2->get_R5_has_laps_defined_by_LapMarker().unlink( ::SWA::ObjectPtr<maslo_LapMarker>( this ) );
      }
      catch ( ... )
      {
        this->get_R5_marks_end_of_lap_in_TrackLog().link( rhs2 );
        throw;
      }
    }

  }
}
