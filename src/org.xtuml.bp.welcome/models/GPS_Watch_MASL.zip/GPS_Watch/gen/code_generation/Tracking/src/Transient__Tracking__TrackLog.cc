//
// File: Transient__Tracking__TrackLog.cc
//
#include "Transient__Tracking__LapMarker.hh"
#include "Transient__Tracking__TrackLog.hh"
#include "Transient__Tracking__TrackPoint.hh"
#include "Transient__Tracking__WorkoutSession.hh"
#include "__Tracking__LapMarker.hh"
#include "__Tracking__TrackPoint.hh"
#include "__Tracking__WorkoutSession.hh"
#include <cstddef>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "transient/ToManyRelationship.hh"
#include "transient/ToOneRelationship.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_TrackLog::maslo_TrackLog ( const ::SWA::Timestamp& masla_session_startTime )
      : architectureId(getNextArchId()),
        masla_session_startTime(masla_session_startTime),
        R1_has_first_TrackPoint(),
        R3_has_last_TrackPoint(),
        R5_has_laps_defined_by_LapMarker(),
        R4_represents_path_for_WorkoutSession()
    {
    }

    ToOneRelationship<maslo_TrackPoint>& maslo_TrackLog::get_R1_has_first_TrackPoint ( )
    {
      return R1_has_first_TrackPoint;
    }

    const ToOneRelationship<maslo_TrackPoint>& maslo_TrackLog::get_R1_has_first_TrackPoint ( ) const
    {
      return R1_has_first_TrackPoint;
    }

    ToOneRelationship<maslo_TrackPoint>& maslo_TrackLog::get_R3_has_last_TrackPoint ( )
    {
      return R3_has_last_TrackPoint;
    }

    const ToOneRelationship<maslo_TrackPoint>& maslo_TrackLog::get_R3_has_last_TrackPoint ( ) const
    {
      return R3_has_last_TrackPoint;
    }

    ToManyRelationship<maslo_LapMarker>& maslo_TrackLog::get_R5_has_laps_defined_by_LapMarker ( )
    {
      return R5_has_laps_defined_by_LapMarker;
    }

    const ToManyRelationship<maslo_LapMarker>& maslo_TrackLog::get_R5_has_laps_defined_by_LapMarker ( ) const
    {
      return R5_has_laps_defined_by_LapMarker;
    }

    ToOneRelationship<maslo_WorkoutSession>& maslo_TrackLog::get_R4_represents_path_for_WorkoutSession ( )
    {
      return R4_represents_path_for_WorkoutSession;
    }

    const ToOneRelationship<maslo_WorkoutSession>& maslo_TrackLog::get_R4_represents_path_for_WorkoutSession ( ) const
    {
      return R4_represents_path_for_WorkoutSession;
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> maslo_TrackLog::navigate_R1_has_first_TrackPoint ( ) const
    {
      return get_R1_has_first_TrackPoint().navigate();
    }

    ::std::size_t maslo_TrackLog::count_R1_has_first_TrackPoint ( ) const
    {
      return get_R1_has_first_TrackPoint().count();
    }

    void maslo_TrackLog::link_R1_has_first_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> rhs2 = rhs.downcast<maslo_TrackPoint>();
      this->get_R1_has_first_TrackPoint().link( rhs2 );
      try
      {
        rhs2->get_R1_is_start_of_TrackLog().link( ::SWA::ObjectPtr<maslo_TrackLog>( this ) );
      }
      catch ( ... )
      {
        this->get_R1_has_first_TrackPoint().unlink( rhs2 );
        throw;
      }
    }

    void maslo_TrackLog::unlink_R1_has_first_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> rhs2 = rhs.downcast<maslo_TrackPoint>();
      this->get_R1_has_first_TrackPoint().unlink( rhs2 );
      try
      {
        rhs2->get_R1_is_start_of_TrackLog().unlink( ::SWA::ObjectPtr<maslo_TrackLog>( this ) );
      }
      catch ( ... )
      {
        this->get_R1_has_first_TrackPoint().link( rhs2 );
        throw;
      }
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> maslo_TrackLog::navigate_R3_has_last_TrackPoint ( ) const
    {
      return get_R3_has_last_TrackPoint().navigate();
    }

    ::std::size_t maslo_TrackLog::count_R3_has_last_TrackPoint ( ) const
    {
      return get_R3_has_last_TrackPoint().count();
    }

    void maslo_TrackLog::link_R3_has_last_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> rhs2 = rhs.downcast<maslo_TrackPoint>();
      this->get_R3_has_last_TrackPoint().link( rhs2 );
      try
      {
        rhs2->get_R3_is_last_for_TrackLog().link( ::SWA::ObjectPtr<maslo_TrackLog>( this ) );
      }
      catch ( ... )
      {
        this->get_R3_has_last_TrackPoint().unlink( rhs2 );
        throw;
      }
    }

    void maslo_TrackLog::unlink_R3_has_last_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> rhs2 = rhs.downcast<maslo_TrackPoint>();
      this->get_R3_has_last_TrackPoint().unlink( rhs2 );
      try
      {
        rhs2->get_R3_is_last_for_TrackLog().unlink( ::SWA::ObjectPtr<maslo_TrackLog>( this ) );
      }
      catch ( ... )
      {
        this->get_R3_has_last_TrackPoint().link( rhs2 );
        throw;
      }
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> > maslo_TrackLog::navigate_R5_has_laps_defined_by_LapMarker ( ) const
    {
      return get_R5_has_laps_defined_by_LapMarker().navigate();
    }

    ::std::size_t maslo_TrackLog::count_R5_has_laps_defined_by_LapMarker ( ) const
    {
      return get_R5_has_laps_defined_by_LapMarker().count();
    }

    void maslo_TrackLog::link_R5_has_laps_defined_by_LapMarker ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker>& rhs )
    {
      ::SWA::ObjectPtr<maslo_LapMarker> rhs2 = rhs.downcast<maslo_LapMarker>();
      this->get_R5_has_laps_defined_by_LapMarker().link( rhs2 );
      try
      {
        rhs2->get_R5_marks_end_of_lap_in_TrackLog().link( ::SWA::ObjectPtr<maslo_TrackLog>( this ) );
      }
      catch ( ... )
      {
        this->get_R5_has_laps_defined_by_LapMarker().unlink( rhs2 );
        throw;
      }
    }

    void maslo_TrackLog::unlink_R5_has_laps_defined_by_LapMarker ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker>& rhs )
    {
      ::SWA::ObjectPtr<maslo_LapMarker> rhs2 = rhs.downcast<maslo_LapMarker>();
      this->get_R5_has_laps_defined_by_LapMarker().unlink( rhs2 );
      try
      {
        rhs2->get_R5_marks_end_of_lap_in_TrackLog().unlink( ::SWA::ObjectPtr<maslo_TrackLog>( this ) );
      }
      catch ( ... )
      {
        this->get_R5_has_laps_defined_by_LapMarker().link( rhs2 );
        throw;
      }
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_TrackLog::navigate_R4_represents_path_for_WorkoutSession ( ) const
    {
      return get_R4_represents_path_for_WorkoutSession().navigate();
    }

    ::std::size_t maslo_TrackLog::count_R4_represents_path_for_WorkoutSession ( ) const
    {
      return get_R4_represents_path_for_WorkoutSession().count();
    }

    void maslo_TrackLog::link_R4_represents_path_for_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> rhs2 = rhs.downcast<maslo_WorkoutSession>();
      this->get_R4_represents_path_for_WorkoutSession().link( rhs2 );
      try
      {
        rhs2->get_R4_captures_path_in_TrackLog().link( ::SWA::ObjectPtr<maslo_TrackLog>( this ) );
      }
      catch ( ... )
      {
        this->get_R4_represents_path_for_WorkoutSession().unlink( rhs2 );
        throw;
      }
    }

    void maslo_TrackLog::unlink_R4_represents_path_for_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> rhs2 = rhs.downcast<maslo_WorkoutSession>();
      this->get_R4_represents_path_for_WorkoutSession().unlink( rhs2 );
      try
      {
        rhs2->get_R4_captures_path_in_TrackLog().unlink( ::SWA::ObjectPtr<maslo_TrackLog>( this ) );
      }
      catch ( ... )
      {
        this->get_R4_represents_path_for_WorkoutSession().link( rhs2 );
        throw;
      }
    }

  }
}
