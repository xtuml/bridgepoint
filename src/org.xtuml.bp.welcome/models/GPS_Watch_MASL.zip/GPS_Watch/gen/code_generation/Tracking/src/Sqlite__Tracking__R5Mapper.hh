//
// File: Sqlite__Tracking__R5Mapper.hh
//
#ifndef Sqlite_Tracking_R_5_Mapper_hh
#define Sqlite_Tracking_R_5_Mapper_hh

#include "Sqlite__Tracking__LapMarker.hh"
#include "Sqlite__Tracking__TrackLog.hh"
#include "sql/RelationshipBinaryDefinitions.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    typedef ::SQL::OneToManyRelationship<5,maslo_TrackLog,maslo_LapMarker,false,true>::mapper_type RelationshipR5Mapper;
  }
}
#endif // Sqlite_Tracking_R_5_Mapper_hh
