//
// File: MetaData__Tracking.cc
//
#include "Tracking_OOA/MetaData__Tracking.hh"
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Achievement.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalAchievement.hh"
#include "__Tracking__GoalSpecConstants.hh"
#include "__Tracking__HeartRateConstants.hh"
#include "__Tracking__Speed.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "__Tracking__WorkoutTimerConstants.hh"
#include "metadata/MetaData.hh"
#include "swa/Domain.hh"
#include <vector>

namespace 
{
  namespace init_masld_Tracking
  {
    ::SWA::EnumerateMetaData get_maslt_GoalCriteria_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_GoalDisposition_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_GoalSpan_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_Indicator_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_Unit_MetaData ( );
    ::SWA::ServiceMetaData get_masls_Initialize_MetaData ( );
    ::SWA::ServiceMetaData get_masls_GoalTest_1_MetaData ( );
    ::SWA::ServiceMetaData get_masls_heartRateChanged_MetaData ( );
    ::SWA::ServiceMetaData get_masls_setTargetPressed_MetaData ( );
    ::SWA::ServiceMetaData get_masls_startStopPressed_MetaData ( );
    ::SWA::ServiceMetaData get_masls_lapResetPressed_MetaData ( );
    ::SWA::ServiceMetaData get_masls_lightPressed_MetaData ( );
    ::SWA::ServiceMetaData get_masls_modePressed_MetaData ( );
    ::SWA::ServiceMetaData get_masls_newGoalSpec_MetaData ( );
    namespace maslb_HR
    {
      ::SWA::TerminatorMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_registerListener_MetaData ( );
      ::SWA::ServiceMetaData get_masls_unregisterListener_MetaData ( );
    }
    namespace maslb_LOC
    {
      ::SWA::TerminatorMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_getDistance_MetaData ( );
      ::SWA::ServiceMetaData get_masls_getLocation_MetaData ( );
      ::SWA::ServiceMetaData get_masls_registerListener_MetaData ( );
      ::SWA::ServiceMetaData get_masls_unregisterListener_MetaData ( );
    }
    namespace maslb_UI
    {
      ::SWA::TerminatorMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_setData_MetaData ( );
      ::SWA::ServiceMetaData get_masls_setIndicator_MetaData ( );
      ::SWA::ServiceMetaData get_masls_setTime_MetaData ( );
    }
    namespace maslo_WorkoutSession
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_addHeartRateSample_MetaData ( );
      ::SWA::ServiceMetaData get_masls_clearHeartRateSamples_MetaData ( );
      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( );
      ::SWA::ServiceMetaData get_masls_reset_MetaData ( );
      ::SWA::ServiceMetaData get_masls_getCurrentSpeed_MetaData ( );
      ::SWA::ServiceMetaData get_masls_getCurrentPace_MetaData ( );
      ::SWA::ServiceMetaData get_masls_getCurrentHeartRate_MetaData ( );
    }
    namespace maslo_WorkoutTimer
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( );
      ::SWA::ServiceMetaData get_masls_activate_MetaData ( );
      ::SWA::ServiceMetaData get_masls_deactivate_MetaData ( );
      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( );
      ::SWA::StateMetaData get_maslst_stopped_MetaData ( );
      ::SWA::StateMetaData get_maslst_running_MetaData ( );
      ::SWA::StateMetaData get_maslst_paused_MetaData ( );
      ::SWA::StateMetaData get_maslst_processingStart_MetaData ( );
      ::SWA::StateMetaData get_maslst_resetLap_MetaData ( );
      ::SWA::EventMetaData get_maslev_startStopPressed_MetaData ( );
      ::SWA::EventMetaData get_maslev_lapResetPressed_MetaData ( );
      ::SWA::EventMetaData get_maslev_tick_MetaData ( );
      ::SWA::EventMetaData get_maslev_pause_MetaData ( );
      ::SWA::EventMetaData get_maslev_resume_MetaData ( );
      ::SWA::EventMetaData get_maslev_startTimer_MetaData ( );
      ::SWA::EventMetaData get_maslev_lapResetComplete_MetaData ( );
    }
    namespace maslo_TrackPoint
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( );
      ::SWA::AttributeMetaData getmasla_next_timeMetaData ( );
    }
    namespace maslo_TrackLog
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( );
      ::SWA::ServiceMetaData get_masls_addTrackPoint_MetaData ( );
      ::SWA::ServiceMetaData get_masls_clearTrackPoints_MetaData ( );
      ::SWA::ServiceMetaData get_masls_addLapMarker_MetaData ( );
      ::SWA::ServiceMetaData get_masls_clearLapMarkers_MetaData ( );
      ::SWA::ServiceMetaData get_masls_updateDisplay_MetaData ( );
    }
    namespace maslo_LapMarker
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( );
    }
    namespace maslo_HeartRateSample
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( );
    }
    namespace maslo_GoalSpec
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( );
    }
    namespace maslo_Goal
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( );
      ::SWA::AttributeMetaData getmasla_spec_sequenceNumberMetaData ( );
      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( );
      ::SWA::ServiceMetaData get_masls_calculateStart_MetaData ( );
      ::SWA::ServiceMetaData get_masls_evaluateAchievement_MetaData ( );
      ::SWA::ServiceMetaData get_masls_evaluateCompletion_MetaData ( );
      ::SWA::ServiceMetaData get_masls_nextGoal_MetaData ( );
      ::SWA::StateMetaData get_maslst_Executing_MetaData ( );
      ::SWA::StateMetaData get_maslst_Completed_MetaData ( );
      ::SWA::StateMetaData get_maslst_Paused_MetaData ( );
      ::SWA::StateMetaData get_maslst_Evaluating_MetaData ( );
      ::SWA::EventMetaData get_maslev_Completed_MetaData ( );
      ::SWA::EventMetaData get_maslev_Evaluate_MetaData ( );
      ::SWA::EventMetaData get_maslev_Pause_MetaData ( );
      ::SWA::EventMetaData get_maslev_evaluationComplete_MetaData ( );
    }
    namespace maslo_Display
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( );
      ::SWA::ServiceMetaData get_masls_goalDispositionIndicator_MetaData ( );
      ::SWA::StateMetaData get_maslst_displayDistance_MetaData ( );
      ::SWA::StateMetaData get_maslst_displaySpeed_MetaData ( );
      ::SWA::StateMetaData get_maslst_displayPace_MetaData ( );
      ::SWA::StateMetaData get_maslst_displayHeartRate_MetaData ( );
      ::SWA::StateMetaData get_maslst_displayLapCount_MetaData ( );
      ::SWA::EventMetaData get_maslev_modeChange_MetaData ( );
      ::SWA::EventMetaData get_maslev_refresh_MetaData ( );
    }
    namespace maslo_Achievement
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( );
      ::SWA::AttributeMetaData getmasla_goal_IDMetaData ( );
      ::SWA::AttributeMetaData getmasla_spec_sequenceNumberMetaData ( );
      ::SWA::ServiceMetaData get_masls_close_MetaData ( );
    }
    namespace maslo_GoalAchievement
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( );
    }
    namespace maslo_GoalSpecConstants
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( );
    }
    namespace maslo_HeartRateConstants
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( );
    }
    namespace maslo_Speed
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( );
    }
    namespace maslo_WorkoutTimerConstants
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( );
    }
    ::SWA::DomainMetaData initDomainMetaData ( )
    {
      ::SWA::DomainMetaData domain(::masld_Tracking::getDomain().getId(), "Tracking", false);
      domain.addEnumerate( get_maslt_GoalCriteria_MetaData() );
      domain.addEnumerate( get_maslt_GoalDisposition_MetaData() );
      domain.addEnumerate( get_maslt_GoalSpan_MetaData() );
      domain.addEnumerate( get_maslt_Indicator_MetaData() );
      domain.addEnumerate( get_maslt_Unit_MetaData() );
      domain.addService( get_masls_Initialize_MetaData() );
      domain.addService( get_masls_GoalTest_1_MetaData() );
      domain.addService( get_masls_heartRateChanged_MetaData() );
      domain.addService( get_masls_setTargetPressed_MetaData() );
      domain.addService( get_masls_startStopPressed_MetaData() );
      domain.addService( get_masls_lapResetPressed_MetaData() );
      domain.addService( get_masls_lightPressed_MetaData() );
      domain.addService( get_masls_modePressed_MetaData() );
      domain.addService( get_masls_newGoalSpec_MetaData() );
      domain.addRelationship( ::SWA::RelationshipMetaData( ::masld_Tracking::relationshipId_R1, "R1", ::masld_Tracking::objectId_maslo_TrackLog, "has_first", false, true, ::masld_Tracking::objectId_maslo_TrackPoint, "is_start_of", false, true ) );
      domain.addRelationship( ::SWA::RelationshipMetaData( ::masld_Tracking::relationshipId_R2, "R2", ::masld_Tracking::objectId_maslo_TrackPoint, "follows", false, true, ::masld_Tracking::objectId_maslo_TrackPoint, "preceeds", false, true ) );
      domain.addRelationship( ::SWA::RelationshipMetaData( ::masld_Tracking::relationshipId_R3, "R3", ::masld_Tracking::objectId_maslo_TrackLog, "has_last", false, true, ::masld_Tracking::objectId_maslo_TrackPoint, "is_last_for", false, true ) );
      domain.addRelationship( ::SWA::RelationshipMetaData( ::masld_Tracking::relationshipId_R5, "R5", ::masld_Tracking::objectId_maslo_TrackLog, "has_laps_defined_by", true, true, ::masld_Tracking::objectId_maslo_LapMarker, "marks_end_of_lap_in", false, false ) );
      domain.addRelationship( ::SWA::RelationshipMetaData( ::masld_Tracking::relationshipId_R7, "R7", ::masld_Tracking::objectId_maslo_WorkoutSession, "current_status_indicated_on", false, false, ::masld_Tracking::objectId_maslo_Display, "indicates_current_status_of", false, false ) );
      domain.addRelationship( ::SWA::RelationshipMetaData( ::masld_Tracking::relationshipId_R8, "R8", ::masld_Tracking::objectId_maslo_WorkoutSession, "is_timed_by", false, false, ::masld_Tracking::objectId_maslo_WorkoutTimer, "acts_as_the_stopwatch_for", false, false ) );
      domain.addRelationship( ::SWA::RelationshipMetaData( ::masld_Tracking::relationshipId_R4, "R4", ::masld_Tracking::objectId_maslo_WorkoutSession, "captures_path_in", false, false, ::masld_Tracking::objectId_maslo_TrackLog, "represents_path_for", false, false ) );
      domain.addRelationship( ::SWA::RelationshipMetaData( ::masld_Tracking::relationshipId_R6, "R6", ::masld_Tracking::objectId_maslo_WorkoutSession, "tracks_heart_rate_over_time_as", true, true, ::masld_Tracking::objectId_maslo_HeartRateSample, "was_collected_during", false, false ) );
      domain.addRelationship( ::SWA::RelationshipMetaData( ::masld_Tracking::relationshipId_R9, "R9", ::masld_Tracking::objectId_maslo_GoalSpec, "specifies", true, true, ::masld_Tracking::objectId_maslo_Goal, "specified_by", false, false ) );
      domain.addRelationship( ::SWA::RelationshipMetaData( ::masld_Tracking::relationshipId_R10, "R10", ::masld_Tracking::objectId_maslo_WorkoutSession, "includes", true, true, ::masld_Tracking::objectId_maslo_GoalSpec, "included_in", false, false ) );
      domain.addRelationship( ::SWA::RelationshipMetaData( ::masld_Tracking::relationshipId_R11, "R11", ::masld_Tracking::objectId_maslo_WorkoutSession, "is_currently_executing", false, true, ::masld_Tracking::objectId_maslo_Goal, "is_currently_executing_within", false, true ) );
      domain.addRelationship( ::SWA::RelationshipMetaData( ::masld_Tracking::relationshipId_R12, "R12", ::masld_Tracking::objectId_maslo_Goal, "has_recorded", true, true, ::masld_Tracking::objectId_maslo_Achievement, "specifies_achievement_of", false, false ) );
      domain.addRelationship( ::SWA::RelationshipMetaData( ::masld_Tracking::relationshipId_R13, "R13", ::masld_Tracking::objectId_maslo_WorkoutSession, "has_executed", true, true, ::masld_Tracking::objectId_maslo_Goal, "was_executed_within", false, false ) );
      domain.addRelationship( ::SWA::RelationshipMetaData( ::masld_Tracking::relationshipId_R14, "R14", ::masld_Tracking::objectId_maslo_Goal, "has_open", false, true, ::masld_Tracking::objectId_maslo_Achievement, "is_open_for", false, true ) );
      domain.addTerminator( maslb_HR::getMetaData() );
      domain.addTerminator( maslb_LOC::getMetaData() );
      domain.addTerminator( maslb_UI::getMetaData() );
      domain.addObject( maslo_WorkoutSession::getMetaData() );
      domain.addObject( maslo_WorkoutTimer::getMetaData() );
      domain.addObject( maslo_TrackPoint::getMetaData() );
      domain.addObject( maslo_TrackLog::getMetaData() );
      domain.addObject( maslo_LapMarker::getMetaData() );
      domain.addObject( maslo_HeartRateSample::getMetaData() );
      domain.addObject( maslo_GoalSpec::getMetaData() );
      domain.addObject( maslo_Goal::getMetaData() );
      domain.addObject( maslo_Display::getMetaData() );
      domain.addObject( maslo_Achievement::getMetaData() );
      domain.addObject( maslo_GoalAchievement::getMetaData() );
      domain.addObject( maslo_GoalSpecConstants::getMetaData() );
      domain.addObject( maslo_HeartRateConstants::getMetaData() );
      domain.addObject( maslo_Speed::getMetaData() );
      domain.addObject( maslo_WorkoutTimerConstants::getMetaData() );
      return domain;
    }

    ::SWA::DomainMetaData& getDomainMetaData ( )
    {
      static ::SWA::DomainMetaData domain = initDomainMetaData();
      return domain;
    }

    bool registered = ::SWA::ProcessMetaData::getProcess().addDomain( ::masld_Tracking::getDomain().getId(), &getDomainMetaData );

    ::SWA::EnumerateMetaData get_maslt_GoalCriteria_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Tracking::typeId_maslt_GoalCriteria, "GoalCriteria");
      enumeration.addValue( ::masld_Tracking::maslt_GoalCriteria::masle_HeartRate.getValue(), "HeartRate" );
      enumeration.addValue( ::masld_Tracking::maslt_GoalCriteria::masle_Pace.getValue(), "Pace" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_GoalDisposition_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Tracking::typeId_maslt_GoalDisposition, "GoalDisposition");
      enumeration.addValue( ::masld_Tracking::maslt_GoalDisposition::masle_Achieving.getValue(), "Achieving" );
      enumeration.addValue( ::masld_Tracking::maslt_GoalDisposition::masle_Increase.getValue(), "Increase" );
      enumeration.addValue( ::masld_Tracking::maslt_GoalDisposition::masle_Decrease.getValue(), "Decrease" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_GoalSpan_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Tracking::typeId_maslt_GoalSpan, "GoalSpan");
      enumeration.addValue( ::masld_Tracking::maslt_GoalSpan::masle_Distance.getValue(), "Distance" );
      enumeration.addValue( ::masld_Tracking::maslt_GoalSpan::masle_Time.getValue(), "Time" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_Indicator_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Tracking::typeId_maslt_Indicator, "Indicator");
      enumeration.addValue( ::masld_Tracking::maslt_Indicator::masle_Blank.getValue(), "Blank" );
      enumeration.addValue( ::masld_Tracking::maslt_Indicator::masle_Down.getValue(), "Down" );
      enumeration.addValue( ::masld_Tracking::maslt_Indicator::masle_Flat.getValue(), "Flat" );
      enumeration.addValue( ::masld_Tracking::maslt_Indicator::masle_Up.getValue(), "Up" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_Unit_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Tracking::typeId_maslt_Unit, "Unit");
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_km.getValue(), "km" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_meters.getValue(), "meters" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_minPerKm.getValue(), "minPerKm" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_kmPerHour.getValue(), "kmPerHour" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_miles.getValue(), "miles" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_yards.getValue(), "yards" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_feet.getValue(), "feet" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_minPerMile.getValue(), "minPerMile" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_mph.getValue(), "mph" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_bpm.getValue(), "bpm" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_laps.getValue(), "laps" );
      return enumeration;
    }

    ::SWA::ServiceMetaData get_masls_Initialize_MetaData ( )
    {
      int lines[] = { 2,
     4};
      ::SWA::ServiceMetaData service(::masld_Tracking::serviceId_masls_Initialize, ::SWA::ServiceMetaData::Domain, "Initialize", ::std::vector<int>( lines, lines + 2 ), "Initialize.svc", "91c98a1e95ea82cf812ebafdb842a701");
      return service;
    }

    ::SWA::ServiceMetaData get_masls_GoalTest_1_MetaData ( )
    {
      int lines[] = { 2,
     4,
     7,
     9,
     11,
     13};
      ::SWA::ServiceMetaData service(::masld_Tracking::serviceId_masls_GoalTest_1, ::SWA::ServiceMetaData::Domain, "GoalTest_1", ::std::vector<int>( lines, lines + 6 ), "GoalTest_1.svc", "1eb0e61a1717afe365ca6c45c7141720");
      return service;
    }

    ::SWA::ServiceMetaData get_masls_heartRateChanged_MetaData ( )
    {
      int lines[] = { 3,
     9,
     10,
     11};
      ::SWA::ServiceMetaData service(::masld_Tracking::serviceId_masls_heartRateChanged, ::SWA::ServiceMetaData::Domain, "heartRateChanged", ::std::vector<int>( lines, lines + 4 ), "heartRateChanged.svc", "61912cec140bd79a2ffef12b252c46dd");
      service.addParameter( ::SWA::ParameterMetaData( "heartRate", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_setTargetPressed_MetaData ( )
    {
      int lines[] = { 2,
     5};
      ::SWA::ServiceMetaData service(::masld_Tracking::serviceId_masls_setTargetPressed, ::SWA::ServiceMetaData::Domain, "setTargetPressed", ::std::vector<int>( lines, lines + 2 ), "setTargetPressed.svc", "a192c0b81d3061539e3aa05f0269f4e6");
      return service;
    }

    ::SWA::ServiceMetaData get_masls_startStopPressed_MetaData ( )
    {
      int lines[] = { 3,
     7,
     10,
     11};
      ::SWA::ServiceMetaData service(::masld_Tracking::serviceId_masls_startStopPressed, ::SWA::ServiceMetaData::Domain, "startStopPressed", ::std::vector<int>( lines, lines + 4 ), "startStopPressed.svc", "fe40820e6656e764179cb8af9f8749a1");
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "workoutTimer", "instance of WorkoutTimer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer ) ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_lapResetPressed_MetaData ( )
    {
      int lines[] = { 3,
     7,
     8,
     9,
     11};
      ::SWA::ServiceMetaData service(::masld_Tracking::serviceId_masls_lapResetPressed, ::SWA::ServiceMetaData::Domain, "lapResetPressed", ::std::vector<int>( lines, lines + 5 ), "lapResetPressed.svc", "1fc9e9b240e29da7fb44ade2666cab06");
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "workoutTimer", "instance of WorkoutTimer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer ) ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_lightPressed_MetaData ( )
    {
      int lines[] = { 2};
      ::SWA::ServiceMetaData service(::masld_Tracking::serviceId_masls_lightPressed, ::SWA::ServiceMetaData::Domain, "lightPressed", ::std::vector<int>( lines, lines + 1 ), "lightPressed.svc", "c860ecc661db22026eaba11b8ecd0566");
      return service;
    }

    ::SWA::ServiceMetaData get_masls_modePressed_MetaData ( )
    {
      int lines[] = { 4,
     9,
     10,
     11,
     12};
      ::SWA::ServiceMetaData service(::masld_Tracking::serviceId_masls_modePressed, ::SWA::ServiceMetaData::Domain, "modePressed", ::std::vector<int>( lines, lines + 5 ), "modePressed.svc", "71a1b7fbcbcb61c03943140732c20ee4");
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "display", "instance of Display", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Display ) ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_newGoalSpec_MetaData ( )
    {
      int lines[] = { 9,
     12,
     13,
     14,
     15,
     16,
     17,
     18,
     19,
     20,
     21};
      ::SWA::ServiceMetaData service(::masld_Tracking::serviceId_masls_newGoalSpec, ::SWA::ServiceMetaData::Domain, "newGoalSpec", ::std::vector<int>( lines, lines + 11 ), "newGoalSpec.svc", "bb2219c55864db993884066ebf5db246");
      service.addParameter( ::SWA::ParameterMetaData( "spanType", "Tracking::GoalSpan", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::typeId_maslt_GoalSpan ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "criteriaType", "Tracking::GoalCriteria", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::typeId_maslt_GoalCriteria ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "span", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "maximum", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "minimum", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "sequenceNumber", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "goalSpec", "instance of GoalSpec", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_GoalSpec ) ) );
      return service;
    }

    namespace maslb_HR
    {
      ::SWA::TerminatorMetaData getMetaData ( )
      {
        ::SWA::TerminatorMetaData terminator(::masld_Tracking::terminatorId_maslb_HR, "HR", "HR");
        terminator.addService( get_masls_registerListener_MetaData() );
        terminator.addService( get_masls_unregisterListener_MetaData() );
        return terminator;
      }

      ::SWA::ServiceMetaData get_masls_registerListener_MetaData ( )
      {
        int lines[] = { 2,
     3};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslb_HR::serviceId_masls_registerListener, ::SWA::ServiceMetaData::Terminator, "registerListener", ::std::vector<int>( lines, lines + 2 ), "HR_registerListener.tr", "5a1589aa8020dcb1f1bc3c8a74baf679");
        return service;
      }

      ::SWA::ServiceMetaData get_masls_unregisterListener_MetaData ( )
      {
        int lines[] = { 2,
     3};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslb_HR::serviceId_masls_unregisterListener, ::SWA::ServiceMetaData::Terminator, "unregisterListener", ::std::vector<int>( lines, lines + 2 ), "HR_unregisterListener.tr", "b6f7def5a9ad42d8b243b259a8b74055");
        return service;
      }

    }
    namespace maslb_LOC
    {
      ::SWA::TerminatorMetaData getMetaData ( )
      {
        ::SWA::TerminatorMetaData terminator(::masld_Tracking::terminatorId_maslb_LOC, "LOC", "LOC");
        terminator.addService( get_masls_getDistance_MetaData() );
        terminator.addService( get_masls_getLocation_MetaData() );
        terminator.addService( get_masls_registerListener_MetaData() );
        terminator.addService( get_masls_unregisterListener_MetaData() );
        return terminator;
      }

      ::SWA::ServiceMetaData get_masls_getDistance_MetaData ( )
      {
        int lines[] = { 6,
     7};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslb_LOC::serviceId_masls_getDistance, ::SWA::ServiceMetaData::Terminator, "getDistance", ::std::vector<int>( lines, lines + 2 ), "LOC_getDistance.tr", "b4577927a0ef5688c42b8596317925b4");
        service.addParameter( ::SWA::ParameterMetaData( "result", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), true ) );
        service.addParameter( ::SWA::ParameterMetaData( "toLong", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
        service.addParameter( ::SWA::ParameterMetaData( "toLat", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
        service.addParameter( ::SWA::ParameterMetaData( "fromLong", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
        service.addParameter( ::SWA::ParameterMetaData( "fromLat", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_getLocation_MetaData ( )
      {
        int lines[] = { 3,
     4};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslb_LOC::serviceId_masls_getLocation, ::SWA::ServiceMetaData::Terminator, "getLocation", ::std::vector<int>( lines, lines + 2 ), "LOC_getLocation.tr", "b426a4464597a72d9f5944e0f194d426");
        service.addParameter( ::SWA::ParameterMetaData( "longitude", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), true ) );
        service.addParameter( ::SWA::ParameterMetaData( "latitude", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), true ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_registerListener_MetaData ( )
      {
        int lines[] = { 2,
     3};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslb_LOC::serviceId_masls_registerListener, ::SWA::ServiceMetaData::Terminator, "registerListener", ::std::vector<int>( lines, lines + 2 ), "LOC_registerListener.tr", "709275e35b341f0a65d3ae954a0f1b1b");
        return service;
      }

      ::SWA::ServiceMetaData get_masls_unregisterListener_MetaData ( )
      {
        int lines[] = { 2,
     3};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslb_LOC::serviceId_masls_unregisterListener, ::SWA::ServiceMetaData::Terminator, "unregisterListener", ::std::vector<int>( lines, lines + 2 ), "LOC_unregisterListener.tr", "2748a8ba88c9e3d19f1cd264827e3d16");
        return service;
      }

    }
    namespace maslb_UI
    {
      ::SWA::TerminatorMetaData getMetaData ( )
      {
        ::SWA::TerminatorMetaData terminator(::masld_Tracking::terminatorId_maslb_UI, "UI", "UI");
        terminator.addService( get_masls_setData_MetaData() );
        terminator.addService( get_masls_setIndicator_MetaData() );
        terminator.addService( get_masls_setTime_MetaData() );
        return terminator;
      }

      ::SWA::ServiceMetaData get_masls_setData_MetaData ( )
      {
        int lines[] = { 3,
     4};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslb_UI::serviceId_masls_setData, ::SWA::ServiceMetaData::Terminator, "setData", ::std::vector<int>( lines, lines + 2 ), "UI_setData.tr", "a2292914da91ccac6445ef2925e137c5");
        service.addParameter( ::SWA::ParameterMetaData( "value", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
        service.addParameter( ::SWA::ParameterMetaData( "unit", "Tracking::Unit", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::typeId_maslt_Unit ), false ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_setIndicator_MetaData ( )
      {
        int lines[] = { 2,
     3};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslb_UI::serviceId_masls_setIndicator, ::SWA::ServiceMetaData::Terminator, "setIndicator", ::std::vector<int>( lines, lines + 2 ), "UI_setIndicator.tr", "d88a127f11537d4c1a979b229c728633");
        service.addParameter( ::SWA::ParameterMetaData( "indicator", "Tracking::Indicator", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::typeId_maslt_Indicator ), false ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_setTime_MetaData ( )
      {
        int lines[] = { 2,
     3};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslb_UI::serviceId_masls_setTime, ::SWA::ServiceMetaData::Terminator, "setTime", ::std::vector<int>( lines, lines + 2 ), "UI_setTime.tr", "26738497bab343378510c9d07c52b760");
        service.addParameter( ::SWA::ParameterMetaData( "time", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
        return service;
      }

    }
    namespace maslo_WorkoutSession
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Tracking::objectId_maslo_WorkoutSession, "WorkoutSession", "WorkoutSession");
        object.addAttribute( ::SWA::AttributeMetaData( "startTime", true, "timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "accumulatedDistance", false, "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R7", "current_status_indicated_on", false, false, ::masld_Tracking::objectId_maslo_Display ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R8", "is_timed_by", false, false, ::masld_Tracking::objectId_maslo_WorkoutTimer ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R4", "captures_path_in", false, false, ::masld_Tracking::objectId_maslo_TrackLog ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R6", "tracks_heart_rate_over_time_as", true, true, ::masld_Tracking::objectId_maslo_HeartRateSample ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R10", "includes", true, true, ::masld_Tracking::objectId_maslo_GoalSpec ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R11", "is_currently_executing", false, true, ::masld_Tracking::objectId_maslo_Goal ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R13", "has_executed", true, true, ::masld_Tracking::objectId_maslo_Goal ) );
        object.addService( get_masls_addHeartRateSample_MetaData() );
        object.addService( get_masls_clearHeartRateSamples_MetaData() );
        object.addService( get_masls_initialize_MetaData() );
        object.addService( get_masls_reset_MetaData() );
        object.addService( get_masls_getCurrentSpeed_MetaData() );
        object.addService( get_masls_getCurrentPace_MetaData() );
        object.addService( get_masls_getCurrentHeartRate_MetaData() );
        return object;
      }

      ::SWA::ServiceMetaData get_masls_addHeartRateSample_MetaData ( )
      {
        int lines[] = { 5,
     8,
     11,
     12,
     13,
     16,
     17};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_WorkoutSession::serviceId_masls_addHeartRateSample, ::SWA::ServiceMetaData::Instance, "addHeartRateSample", ::std::vector<int>( lines, lines + 7 ), "WorkoutSession_addHeartRateSample.svc", "ce2de5f40ce64fb0e0cf21ba631eb221");
        service.addParameter( ::SWA::ParameterMetaData( "heartRate", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "workoutTimer", "instance of WorkoutTimer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "sample", "instance of HeartRateSample", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_HeartRateSample ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "display", "instance of Display", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Display ) ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_clearHeartRateSamples_MetaData ( )
      {
        int lines[] = { 3,
     4,
     5,
     6,
     7};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_WorkoutSession::serviceId_masls_clearHeartRateSamples, ::SWA::ServiceMetaData::Instance, "clearHeartRateSamples", ::std::vector<int>( lines, lines + 5 ), "WorkoutSession_clearHeartRateSamples.svc", "5f36fd66105046e105de5a7a320ad27d");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "samples", "set of instance of HeartRateSample", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_HeartRateSample, 1 ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "sample", "instance of HeartRateSample", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_HeartRateSample ) ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( )
      {
        int lines[] = { 6,
     10,
     12,
     15,
     17,
     20,
     21,
     24,
     27,
     30,
     31,
     32};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_WorkoutSession::serviceId_masls_initialize, ::SWA::ServiceMetaData::Object, "initialize", ::std::vector<int>( lines, lines + 12 ), "WorkoutSession_initialize.svc", "d8a7d7000ae9b8de31db11dbe357035a");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "workoutTimer", "instance of WorkoutTimer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "trackLog", "instance of TrackLog", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_TrackLog ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "display", "instance of Display", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Display ) ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_reset_MetaData ( )
      {
        int lines[] = { 9,
     14,
     15,
     18,
     19,
     20,
     23,
     24,
     25,
     26,
     30,
     31,
     32,
     33,
     34,
     35,
     37,
     38,
     42,
     43,
     44,
     45,
     46,
     47,
     49,
     50,
     54,
     55};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_WorkoutSession::serviceId_masls_reset, ::SWA::ServiceMetaData::Instance, "reset", ::std::vector<int>( lines, lines + 28 ), "WorkoutSession_reset.svc", "0240cb1693d176a2b0ade25ddd1ee462");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "workoutTimer", "instance of WorkoutTimer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "trackLog", "instance of TrackLog", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_TrackLog ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "goalSpecs", "set of instance of GoalSpec", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_GoalSpec, 1 ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "executingGoal", "instance of Goal", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Goal ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "openAchievement", "instance of Achievement", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Achievement ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "goals", "set of instance of Goal", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Goal, 1 ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "achievements", "set of instance of Achievement", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Achievement, 1 ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "goalSpec", "instance of GoalSpec", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_GoalSpec ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "goal", "instance of Goal", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Goal ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "achievement", "instance of Achievement", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Achievement ) ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_getCurrentSpeed_MetaData ( )
      {
        int lines[] = { 11,
     17,
     18,
     19,
     20,
     21,
     22,
     23,
     24,
     25,
     26,
     27,
     28,
     29,
     31,
     32,
     33,
     34,
     36,
     37,
     40};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_WorkoutSession::serviceId_masls_getCurrentSpeed, ::SWA::ServiceMetaData::Instance, "getCurrentSpeed", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), ::std::vector<int>( lines, lines + 21 ), "WorkoutSession_getCurrentSpeed.svc", "3e01062a8b0b02d0bf92371d09c819ce");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "lastPoint", "instance of TrackPoint", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_TrackPoint ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "speed", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "cursor", "instance of TrackPoint", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_TrackPoint ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "spd", "instance of Speed", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Speed ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "index", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "totalDistance", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "elapsedTime", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "previousPoint", "instance of TrackPoint", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_TrackPoint ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "distance", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_getCurrentPace_MetaData ( )
      {
        int lines[] = { 3,
     5,
     6,
     7,
     9,
     12};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_WorkoutSession::serviceId_masls_getCurrentPace, ::SWA::ServiceMetaData::Instance, "getCurrentPace", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), ::std::vector<int>( lines, lines + 6 ), "WorkoutSession_getCurrentPace.svc", "aae4346b694e8524a7d00b9c3e99c3fc");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "result", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_getCurrentHeartRate_MetaData ( )
      {
        int lines[] = { 9,
     11,
     12,
     13,
     14,
     15,
     16,
     17,
     18,
     19,
     20,
     22,
     23,
     26};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_WorkoutSession::serviceId_masls_getCurrentHeartRate, ::SWA::ServiceMetaData::Instance, "getCurrentHeartRate", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), ::std::vector<int>( lines, lines + 14 ), "WorkoutSession_getCurrentHeartRate.svc", "3ca323a4659146e543cab22327b6df55");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "hrc", "instance of HeartRateConstants", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_HeartRateConstants ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "workoutTimer", "instance of WorkoutTimer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "samples", "set of instance of HeartRateSample", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_HeartRateSample, 1 ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "sample", "instance of HeartRateSample", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_HeartRateSample ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "numberOfSamples", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "sum", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "result", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "sample", "instance of HeartRateSample", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_HeartRateSample ) ) );
        return service;
      }

    }
    namespace maslo_WorkoutTimer
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Tracking::objectId_maslo_WorkoutTimer, "WorkoutTimer", "WorkoutTimer");
        object.addAttribute( ::SWA::AttributeMetaData( "time", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "timer", false, "timer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timer ) ) );
        object.addAttribute( getmasla_session_startTimeMetaData() );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R8", "acts_as_the_stopwatch_for", false, false, ::masld_Tracking::objectId_maslo_WorkoutSession ) );
        object.addService( get_masls_activate_MetaData() );
        object.addService( get_masls_deactivate_MetaData() );
        object.addService( get_masls_initialize_MetaData() );
        object.addState( get_maslst_stopped_MetaData() );
        object.addState( get_maslst_running_MetaData() );
        object.addState( get_maslst_paused_MetaData() );
        object.addState( get_maslst_processingStart_MetaData() );
        object.addState( get_maslst_resetLap_MetaData() );
        object.addEvent( get_maslev_startStopPressed_MetaData() );
        object.addEvent( get_maslev_lapResetPressed_MetaData() );
        object.addEvent( get_maslev_tick_MetaData() );
        object.addEvent( get_maslev_pause_MetaData() );
        object.addEvent( get_maslev_resume_MetaData() );
        object.addEvent( get_maslev_startTimer_MetaData() );
        object.addEvent( get_maslev_lapResetComplete_MetaData() );
        return object;
      }

      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( )
      {
        ::SWA::AttributeMetaData attribute("session_startTime", true, "timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), ::masld_Tracking::relationshipId_R8);
        attribute.addReferential( ::masld_Tracking::relationshipId_R8 );
        return attribute;
      }

      ::SWA::ServiceMetaData get_masls_activate_MetaData ( )
      {
        int lines[] = { 4,
     6,
     7,
     8,
     11,
     12,
     13,
     17,
     18};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_WorkoutTimer::serviceId_masls_activate, ::SWA::ServiceMetaData::Instance, "activate", ::std::vector<int>( lines, lines + 9 ), "WorkoutTimer_activate.svc", "e6a11704561d913fdde917495458fde5");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "wtc", "instance of WorkoutTimerConstants", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimerConstants ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "executingGoal", "instance of Goal", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Goal ) ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_deactivate_MetaData ( )
      {
        int lines[] = { 3,
     5,
     8,
     9,
     10,
     14,
     15};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_WorkoutTimer::serviceId_masls_deactivate, ::SWA::ServiceMetaData::Instance, "deactivate", ::std::vector<int>( lines, lines + 7 ), "WorkoutTimer_deactivate.svc", "639eb0ce299b5aba74054c9f654eef6a");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "executingGoal", "instance of Goal", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Goal ) ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( )
      {
        int lines[] = { 2,
     5};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_WorkoutTimer::serviceId_masls_initialize, ::SWA::ServiceMetaData::Instance, "initialize", ::std::vector<int>( lines, lines + 2 ), "WorkoutTimer_initialize.svc", "884c5a0dd9f1520899c95be994ae5c57");
        return service;
      }

      ::SWA::StateMetaData get_maslst_stopped_MetaData ( )
      {
        int lines[] = { 4,
     6,
     7,
     10,
     11,
     12};
        ::SWA::StateMetaData state(::masld_Tracking::maslo_WorkoutTimer::stateId_maslst_stopped, ::SWA::StateMetaData::Normal, "stopped", ::std::vector<int>( lines, lines + 6 ), "WorkoutTimer_stopped.al", "2f8f0a06fd31bfd35477517d655f0933");
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "display", "instance of Display", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Display ) ) );
        return state;
      }

      ::SWA::StateMetaData get_maslst_running_MetaData ( )
      {
        int lines[] = { 4,
     6,
     7,
     8,
     11,
     12,
     15};
        ::SWA::StateMetaData state(::masld_Tracking::maslo_WorkoutTimer::stateId_maslst_running, ::SWA::StateMetaData::Normal, "running", ::std::vector<int>( lines, lines + 7 ), "WorkoutTimer_running.al", "563d2651b4bb67a55200547a4ff3ebf6");
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "wtc", "instance of WorkoutTimerConstants", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimerConstants ) ) );
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "trackLog", "instance of TrackLog", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_TrackLog ) ) );
        return state;
      }

      ::SWA::StateMetaData get_maslst_paused_MetaData ( )
      {
        int lines[] = { 2,
     3};
        ::SWA::StateMetaData state(::masld_Tracking::maslo_WorkoutTimer::stateId_maslst_paused, ::SWA::StateMetaData::Normal, "paused", ::std::vector<int>( lines, lines + 2 ), "WorkoutTimer_paused.al", "a1fe915e4b9db167041c75e2237a709d");
        return state;
      }

      ::SWA::StateMetaData get_maslst_processingStart_MetaData ( )
      {
        int lines[] = { 2,
     4,
     5};
        ::SWA::StateMetaData state(::masld_Tracking::maslo_WorkoutTimer::stateId_maslst_processingStart, ::SWA::StateMetaData::Normal, "processingStart", ::std::vector<int>( lines, lines + 3 ), "WorkoutTimer_processingStart.al", "a800d07e6e0521b8a024455556b67af1");
        return state;
      }

      ::SWA::StateMetaData get_maslst_resetLap_MetaData ( )
      {
        int lines[] = { 3,
     4,
     5,
     6,
     8};
        ::SWA::StateMetaData state(::masld_Tracking::maslo_WorkoutTimer::stateId_maslst_resetLap, ::SWA::StateMetaData::Normal, "resetLap", ::std::vector<int>( lines, lines + 5 ), "WorkoutTimer_resetLap.al", "0b7d341cfafece5dc4821b6f4de6cea6");
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "trackLog", "instance of TrackLog", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_TrackLog ) ) );
        return state;
      }

      ::SWA::EventMetaData get_maslev_startStopPressed_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_startStopPressed, ::masld_Tracking::objectId_maslo_WorkoutTimer, ::SWA::EventMetaData::Normal, "startStopPressed");
        return event;
      }

      ::SWA::EventMetaData get_maslev_lapResetPressed_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_lapResetPressed, ::masld_Tracking::objectId_maslo_WorkoutTimer, ::SWA::EventMetaData::Normal, "lapResetPressed");
        return event;
      }

      ::SWA::EventMetaData get_maslev_tick_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_tick, ::masld_Tracking::objectId_maslo_WorkoutTimer, ::SWA::EventMetaData::Normal, "tick");
        return event;
      }

      ::SWA::EventMetaData get_maslev_pause_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_pause, ::masld_Tracking::objectId_maslo_WorkoutTimer, ::SWA::EventMetaData::Normal, "pause");
        return event;
      }

      ::SWA::EventMetaData get_maslev_resume_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_resume, ::masld_Tracking::objectId_maslo_WorkoutTimer, ::SWA::EventMetaData::Normal, "resume");
        return event;
      }

      ::SWA::EventMetaData get_maslev_startTimer_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_startTimer, ::masld_Tracking::objectId_maslo_WorkoutTimer, ::SWA::EventMetaData::Normal, "startTimer");
        return event;
      }

      ::SWA::EventMetaData get_maslev_lapResetComplete_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_lapResetComplete, ::masld_Tracking::objectId_maslo_WorkoutTimer, ::SWA::EventMetaData::Normal, "lapResetComplete");
        return event;
      }

    }
    namespace maslo_TrackPoint
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Tracking::objectId_maslo_TrackPoint, "TrackPoint", "TrackPoint");
        object.addAttribute( ::SWA::AttributeMetaData( "time", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "longitude", false, "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "latitude", false, "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        object.addAttribute( getmasla_session_startTimeMetaData() );
        object.addAttribute( getmasla_next_timeMetaData() );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R1", "is_start_of", false, true, ::masld_Tracking::objectId_maslo_TrackLog ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R2", "follows", false, true, ::masld_Tracking::objectId_maslo_TrackPoint ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R2", "preceeds", false, true, ::masld_Tracking::objectId_maslo_TrackPoint ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R3", "is_last_for", false, true, ::masld_Tracking::objectId_maslo_TrackLog ) );
        return object;
      }

      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( )
      {
        ::SWA::AttributeMetaData attribute("session_startTime", true, "timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), ::masld_Tracking::relationshipId_R1);
        attribute.addReferential( ::masld_Tracking::relationshipId_R1 );
        attribute.addReferential( ::masld_Tracking::relationshipId_R3 );
        attribute.addReferential( ::masld_Tracking::relationshipId_R2 );
        return attribute;
      }

      ::SWA::AttributeMetaData getmasla_next_timeMetaData ( )
      {
        ::SWA::AttributeMetaData attribute("next_time", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), ::masld_Tracking::relationshipId_R2);
        attribute.addReferential( ::masld_Tracking::relationshipId_R2 );
        return attribute;
      }

    }
    namespace maslo_TrackLog
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Tracking::objectId_maslo_TrackLog, "TrackLog", "TrackLog");
        object.addAttribute( getmasla_session_startTimeMetaData() );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R1", "has_first", false, true, ::masld_Tracking::objectId_maslo_TrackPoint ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R3", "has_last", false, true, ::masld_Tracking::objectId_maslo_TrackPoint ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R5", "has_laps_defined_by", true, true, ::masld_Tracking::objectId_maslo_LapMarker ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R4", "represents_path_for", false, false, ::masld_Tracking::objectId_maslo_WorkoutSession ) );
        object.addService( get_masls_addTrackPoint_MetaData() );
        object.addService( get_masls_clearTrackPoints_MetaData() );
        object.addService( get_masls_addLapMarker_MetaData() );
        object.addService( get_masls_clearLapMarkers_MetaData() );
        object.addService( get_masls_updateDisplay_MetaData() );
        return object;
      }

      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( )
      {
        ::SWA::AttributeMetaData attribute("session_startTime", true, "timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), ::masld_Tracking::relationshipId_R4);
        attribute.addReferential( ::masld_Tracking::relationshipId_R4 );
        return attribute;
      }

      ::SWA::ServiceMetaData get_masls_addTrackPoint_MetaData ( )
      {
        int lines[] = { 11,
     16,
     17,
     18,
     21,
     22,
     25,
     26,
     27,
     28,
     29,
     30,
     31,
     34,
     35,
     36,
     37,
     38,
     42,
     43,
     44,
     47,
     48,
     51};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_TrackLog::serviceId_masls_addTrackPoint, ::SWA::ServiceMetaData::Instance, "addTrackPoint", ::std::vector<int>( lines, lines + 24 ), "TrackLog_addTrackPoint.svc", "8b61fa4cc51480b650f072d4e47c9fa4");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "workoutTimer", "instance of WorkoutTimer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "trackPoint", "instance of TrackPoint", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_TrackPoint ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "firstPoint", "instance of TrackPoint", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_TrackPoint ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "lastPoint", "instance of TrackPoint", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_TrackPoint ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "isFirstTrackPoint", "boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "lastLatitude", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "lastLongitude", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "distance", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_clearTrackPoints_MetaData ( )
      {
        int lines[] = { 5,
     6,
     7,
     9,
     10,
     13,
     14,
     17,
     18,
     19,
     20,
     21,
     23};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_TrackLog::serviceId_masls_clearTrackPoints, ::SWA::ServiceMetaData::Instance, "clearTrackPoints", ::std::vector<int>( lines, lines + 13 ), "TrackLog_clearTrackPoints.svc", "61b7bd6251e2fe007e30706ece418322");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "nextPoint", "instance of TrackPoint", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_TrackPoint ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "lastPoint", "instance of TrackPoint", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_TrackPoint ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "prevPoint", "instance of TrackPoint", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_TrackPoint ) ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_addLapMarker_MetaData ( )
      {
        int lines[] = { 4,
     5,
     6,
     7,
     10};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_TrackLog::serviceId_masls_addLapMarker, ::SWA::ServiceMetaData::Instance, "addLapMarker", ::std::vector<int>( lines, lines + 5 ), "TrackLog_addLapMarker.svc", "da59da9e939cd81dded9e41f9ce93ee9");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "timer", "instance of WorkoutTimer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "lapMarker", "instance of LapMarker", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_LapMarker ) ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_clearLapMarkers_MetaData ( )
      {
        int lines[] = { 3,
     4,
     5,
     6,
     7};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_TrackLog::serviceId_masls_clearLapMarkers, ::SWA::ServiceMetaData::Instance, "clearLapMarkers", ::std::vector<int>( lines, lines + 5 ), "TrackLog_clearLapMarkers.svc", "993e9f067a10f2b163bfe364cf72cc55");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "lapMarkers", "set of instance of LapMarker", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_LapMarker, 1 ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "lapMarker", "instance of LapMarker", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_LapMarker ) ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_updateDisplay_MetaData ( )
      {
        int lines[] = { 3,
     5,
     6};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_TrackLog::serviceId_masls_updateDisplay, ::SWA::ServiceMetaData::Instance, "updateDisplay", ::std::vector<int>( lines, lines + 3 ), "TrackLog_updateDisplay.svc", "9255357df390c746b4fa2bdb3955b0dc");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "display", "instance of Display", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Display ) ) );
        return service;
      }

    }
    namespace maslo_LapMarker
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Tracking::objectId_maslo_LapMarker, "LapMarker", "LapMarker");
        object.addAttribute( ::SWA::AttributeMetaData( "lapTime", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( getmasla_session_startTimeMetaData() );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R5", "marks_end_of_lap_in", false, false, ::masld_Tracking::objectId_maslo_TrackLog ) );
        return object;
      }

      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( )
      {
        ::SWA::AttributeMetaData attribute("session_startTime", true, "timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), ::masld_Tracking::relationshipId_R5);
        attribute.addReferential( ::masld_Tracking::relationshipId_R5 );
        return attribute;
      }

    }
    namespace maslo_HeartRateSample
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Tracking::objectId_maslo_HeartRateSample, "HeartRateSample", "HeartRateSample");
        object.addAttribute( ::SWA::AttributeMetaData( "heartRate", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "time", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( getmasla_session_startTimeMetaData() );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R6", "was_collected_during", false, false, ::masld_Tracking::objectId_maslo_WorkoutSession ) );
        return object;
      }

      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( )
      {
        ::SWA::AttributeMetaData attribute("session_startTime", true, "timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), ::masld_Tracking::relationshipId_R6);
        attribute.addReferential( ::masld_Tracking::relationshipId_R6 );
        return attribute;
      }

    }
    namespace maslo_GoalSpec
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Tracking::objectId_maslo_GoalSpec, "GoalSpec", "GoalSpec");
        object.addAttribute( ::SWA::AttributeMetaData( "minimum", false, "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "maximum", false, "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "span", false, "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "criteriaType", false, "Tracking::GoalCriteria", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::typeId_maslt_GoalCriteria ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "spanType", false, "Tracking::GoalSpan", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::typeId_maslt_GoalSpan ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "sequenceNumber", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( getmasla_session_startTimeMetaData() );
        object.addAttribute( ::SWA::AttributeMetaData( "last_goal_ID", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R9", "specifies", true, true, ::masld_Tracking::objectId_maslo_Goal ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R10", "included_in", false, false, ::masld_Tracking::objectId_maslo_WorkoutSession ) );
        return object;
      }

      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( )
      {
        ::SWA::AttributeMetaData attribute("session_startTime", true, "timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), ::masld_Tracking::relationshipId_R10);
        attribute.addReferential( ::masld_Tracking::relationshipId_R10 );
        return attribute;
      }

    }
    namespace maslo_Goal
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Tracking::objectId_maslo_Goal, "Goal", "Goal");
        object.addAttribute( ::SWA::AttributeMetaData( "disposition", false, "Tracking::GoalDisposition", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::typeId_maslt_GoalDisposition ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "startingPoint", false, "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "ID", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "evaluationTimer", false, "timer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timer ) ) );
        object.addAttribute( getmasla_session_startTimeMetaData() );
        object.addAttribute( getmasla_spec_sequenceNumberMetaData() );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R9", "specified_by", false, false, ::masld_Tracking::objectId_maslo_GoalSpec ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R11", "is_currently_executing_within", false, true, ::masld_Tracking::objectId_maslo_WorkoutSession ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R12", "has_recorded", true, true, ::masld_Tracking::objectId_maslo_Achievement ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R13", "was_executed_within", false, false, ::masld_Tracking::objectId_maslo_WorkoutSession ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R14", "has_open", false, true, ::masld_Tracking::objectId_maslo_Achievement ) );
        object.addService( get_masls_initialize_MetaData() );
        object.addService( get_masls_calculateStart_MetaData() );
        object.addService( get_masls_evaluateAchievement_MetaData() );
        object.addService( get_masls_evaluateCompletion_MetaData() );
        object.addService( get_masls_nextGoal_MetaData() );
        object.addState( get_maslst_Executing_MetaData() );
        object.addState( get_maslst_Completed_MetaData() );
        object.addState( get_maslst_Paused_MetaData() );
        object.addState( get_maslst_Evaluating_MetaData() );
        object.addEvent( get_maslev_Completed_MetaData() );
        object.addEvent( get_maslev_Evaluate_MetaData() );
        object.addEvent( get_maslev_Pause_MetaData() );
        object.addEvent( get_maslev_evaluationComplete_MetaData() );
        return object;
      }

      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( )
      {
        ::SWA::AttributeMetaData attribute("session_startTime", true, "timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), ::masld_Tracking::relationshipId_R13);
        attribute.addReferential( ::masld_Tracking::relationshipId_R13 );
        attribute.addReferential( ::masld_Tracking::relationshipId_R9 );
        attribute.addReferential( ::masld_Tracking::relationshipId_R11 );
        return attribute;
      }

      ::SWA::AttributeMetaData getmasla_spec_sequenceNumberMetaData ( )
      {
        ::SWA::AttributeMetaData attribute("spec_sequenceNumber", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), ::masld_Tracking::relationshipId_R9);
        attribute.addReferential( ::masld_Tracking::relationshipId_R9 );
        return attribute;
      }

      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( )
      {
        int lines[] = { 6,
     14,
     15,
     16,
     17,
     18,
     19,
     20,
     23,
     24,
     27,
     28,
     29};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_Goal::serviceId_masls_initialize, ::SWA::ServiceMetaData::Object, "initialize", ::std::vector<int>( lines, lines + 13 ), "Goal_initialize.svc", "6c062aaebff1f9b2d99149332f1df549");
        service.addParameter( ::SWA::ParameterMetaData( "sequenceNumber", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "goalSpec", "instance of GoalSpec", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_GoalSpec ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "goal", "instance of Goal", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Goal ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "goalachievement", "instance of GoalAchievement", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_GoalAchievement ) ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_calculateStart_MetaData ( )
      {
        int lines[] = { 5,
     8,
     9,
     10,
     11,
     13,
     14,
     16};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_Goal::serviceId_masls_calculateStart, ::SWA::ServiceMetaData::Instance, "calculateStart", ::std::vector<int>( lines, lines + 8 ), "Goal_calculateStart.svc", "9b1d9d5d81d60d6479d888ddb5f69b5a");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "goalSpec", "instance of GoalSpec", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_GoalSpec ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "workoutTimer", "instance of WorkoutTimer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_evaluateAchievement_MetaData ( )
      {
        int lines[] = { 6,
     12,
     13,
     17,
     18,
     19,
     21,
     23,
     27,
     28,
     29,
     31,
     36,
     37,
     38,
     40,
     44};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_Goal::serviceId_masls_evaluateAchievement, ::SWA::ServiceMetaData::Instance, "evaluateAchievement", "Tracking::GoalDisposition", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::typeId_maslt_GoalDisposition ), ::std::vector<int>( lines, lines + 17 ), "Goal_evaluateAchievement.svc", "302e0587f537988dbf691773c0b42924");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "goalSpec", "instance of GoalSpec", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_GoalSpec ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "currentValue", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "goalDisposition", "Tracking::GoalDisposition", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::typeId_maslt_GoalDisposition ) ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_evaluateCompletion_MetaData ( )
      {
        int lines[] = { 7,
     13,
     17,
     18,
     19,
     20,
     22,
     23,
     25,
     30,
     31,
     32,
     33,
     35};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_Goal::serviceId_masls_evaluateCompletion, ::SWA::ServiceMetaData::Instance, "evaluateCompletion", ::std::vector<int>( lines, lines + 14 ), "Goal_evaluateCompletion.svc", "0628746a32bf8494909a279b3277761f");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "goalSpec", "instance of GoalSpec", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_GoalSpec ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "elapsedSpan", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "workoutTimer", "instance of WorkoutTimer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "openAchievement", "instance of Achievement", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Achievement ) ) );
        return service;
      }

      ::SWA::ServiceMetaData get_masls_nextGoal_MetaData ( )
      {
        int lines[] = { 5,
     13,
     14,
     15,
     16,
     17,
     19,
     20,
     21};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_Goal::serviceId_masls_nextGoal, ::SWA::ServiceMetaData::Object, "nextGoal", ::std::vector<int>( lines, lines + 9 ), "Goal_nextGoal.svc", "67d50cbcf81c171744874f405fef52d5");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "goal", "instance of Goal", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Goal ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "gsc", "instance of GoalSpecConstants", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_GoalSpecConstants ) ) );
        return service;
      }

      ::SWA::StateMetaData get_maslst_Executing_MetaData ( )
      {
        int lines[] = { 5,
     7,
     17,
     19,
     20,
     21,
     24,
     25,
     29,
     33};
        ::SWA::StateMetaData state(::masld_Tracking::maslo_Goal::stateId_maslst_Executing, ::SWA::StateMetaData::Normal, "Executing", ::std::vector<int>( lines, lines + 10 ), "Goal_Executing.al", "660df6a66009bc780164050007e15362");
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "disposition", "Tracking::GoalDisposition", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::typeId_maslt_GoalDisposition ) ) );
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "workoutTimer", "instance of WorkoutTimer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer ) ) );
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "achievement", "instance of Achievement", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Achievement ) ) );
        return state;
      }

      ::SWA::StateMetaData get_maslst_Completed_MetaData ( )
      {
        int lines[] = { 6,
     11,
     14,
     15,
     16,
     20,
     21,
     24,
     27,
     29,
     31,
     32};
        ::SWA::StateMetaData state(::masld_Tracking::maslo_Goal::stateId_maslst_Completed, ::SWA::StateMetaData::Normal, "Completed", ::std::vector<int>( lines, lines + 12 ), "Goal_Completed.al", "1219cb259e840f98e9dc9a152524f5ce");
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "openAchievement", "instance of Achievement", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Achievement ) ) );
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "currentGoalSpec", "instance of GoalSpec", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_GoalSpec ) ) );
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "nextGoalSpec", "instance of GoalSpec", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_GoalSpec ) ) );
        return state;
      }

      ::SWA::StateMetaData get_maslst_Paused_MetaData ( )
      {
        int lines[] = { 2,
     5};
        ::SWA::StateMetaData state(::masld_Tracking::maslo_Goal::stateId_maslst_Paused, ::SWA::StateMetaData::Normal, "Paused", ::std::vector<int>( lines, lines + 2 ), "Goal_Paused.al", "9c54580f6522b65dede8db92fc907e44");
        return state;
      }

      ::SWA::StateMetaData get_maslst_Evaluating_MetaData ( )
      {
        int lines[] = { 3,
     5,
     6,
     7,
     9};
        ::SWA::StateMetaData state(::masld_Tracking::maslo_Goal::stateId_maslst_Evaluating, ::SWA::StateMetaData::Normal, "Evaluating", ::std::vector<int>( lines, lines + 5 ), "Goal_Evaluating.al", "888fa7454a96e5081e76f0fee48cf9cd");
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "goalachievement", "instance of GoalAchievement", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_GoalAchievement ) ) );
        return state;
      }

      ::SWA::EventMetaData get_maslev_Completed_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Tracking::maslo_Goal::eventId_maslo_Goal_maslev_Completed, ::masld_Tracking::objectId_maslo_Goal, ::SWA::EventMetaData::Normal, "Completed");
        return event;
      }

      ::SWA::EventMetaData get_maslev_Evaluate_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Tracking::maslo_Goal::eventId_maslo_Goal_maslev_Evaluate, ::masld_Tracking::objectId_maslo_Goal, ::SWA::EventMetaData::Normal, "Evaluate");
        return event;
      }

      ::SWA::EventMetaData get_maslev_Pause_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Tracking::maslo_Goal::eventId_maslo_Goal_maslev_Pause, ::masld_Tracking::objectId_maslo_Goal, ::SWA::EventMetaData::Normal, "Pause");
        return event;
      }

      ::SWA::EventMetaData get_maslev_evaluationComplete_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Tracking::maslo_Goal::eventId_maslo_Goal_maslev_evaluationComplete, ::masld_Tracking::objectId_maslo_Goal, ::SWA::EventMetaData::Normal, "evaluationComplete");
        return event;
      }

    }
    namespace maslo_Display
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Tracking::objectId_maslo_Display, "Display", "Display");
        object.addAttribute( getmasla_session_startTimeMetaData() );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R7", "indicates_current_status_of", false, false, ::masld_Tracking::objectId_maslo_WorkoutSession ) );
        object.addService( get_masls_goalDispositionIndicator_MetaData() );
        object.addState( get_maslst_displayDistance_MetaData() );
        object.addState( get_maslst_displaySpeed_MetaData() );
        object.addState( get_maslst_displayPace_MetaData() );
        object.addState( get_maslst_displayHeartRate_MetaData() );
        object.addState( get_maslst_displayLapCount_MetaData() );
        object.addEvent( get_maslev_modeChange_MetaData() );
        object.addEvent( get_maslev_refresh_MetaData() );
        return object;
      }

      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( )
      {
        ::SWA::AttributeMetaData attribute("session_startTime", true, "timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), ::masld_Tracking::relationshipId_R7);
        attribute.addReferential( ::masld_Tracking::relationshipId_R7 );
        return attribute;
      }

      ::SWA::ServiceMetaData get_masls_goalDispositionIndicator_MetaData ( )
      {
        int lines[] = { 5,
     12,
     13,
     17,
     18,
     19,
     20,
     22,
     24,
     28};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_Display::serviceId_masls_goalDispositionIndicator, ::SWA::ServiceMetaData::Object, "goalDispositionIndicator", "Tracking::Indicator", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::typeId_maslt_Indicator ), ::std::vector<int>( lines, lines + 10 ), "Display_goalDispositionIndicator.svc", "4cef402040efbadc2f50156c3cb152e3");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "goal", "instance of Goal", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Goal ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "indicator", "Tracking::Indicator", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::typeId_maslt_Indicator ) ) );
        return service;
      }

      ::SWA::StateMetaData get_maslst_displayDistance_MetaData ( )
      {
        int lines[] = { 4,
     5,
     6,
     7,
     8,
     10,
     12};
        ::SWA::StateMetaData state(::masld_Tracking::maslo_Display::stateId_maslst_displayDistance, ::SWA::StateMetaData::Normal, "displayDistance", ::std::vector<int>( lines, lines + 7 ), "Display_displayDistance.al", "a2faaab704509dc1fa8dec5c544341d7");
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "distance", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        return state;
      }

      ::SWA::StateMetaData get_maslst_displaySpeed_MetaData ( )
      {
        int lines[] = { 4,
     5,
     6,
     7,
     8};
        ::SWA::StateMetaData state(::masld_Tracking::maslo_Display::stateId_maslst_displaySpeed, ::SWA::StateMetaData::Normal, "displaySpeed", ::std::vector<int>( lines, lines + 5 ), "Display_displaySpeed.al", "cebe534f3cfe979766e997b0b73aea91");
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "speed", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        return state;
      }

      ::SWA::StateMetaData get_maslst_displayPace_MetaData ( )
      {
        int lines[] = { 4,
     5,
     6,
     7,
     8};
        ::SWA::StateMetaData state(::masld_Tracking::maslo_Display::stateId_maslst_displayPace, ::SWA::StateMetaData::Normal, "displayPace", ::std::vector<int>( lines, lines + 5 ), "Display_displayPace.al", "b9d186e9d884d037f2929b7ebc99ddc4");
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "pace", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        return state;
      }

      ::SWA::StateMetaData get_maslst_displayHeartRate_MetaData ( )
      {
        int lines[] = { 4,
     5,
     6,
     7,
     8};
        ::SWA::StateMetaData state(::masld_Tracking::maslo_Display::stateId_maslst_displayHeartRate, ::SWA::StateMetaData::Normal, "displayHeartRate", ::std::vector<int>( lines, lines + 5 ), "Display_displayHeartRate.al", "8ad9824f062d1b37caa5febd487cb7be");
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "session", "instance of WorkoutSession", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutSession ) ) );
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "heartRate", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        return state;
      }

      ::SWA::StateMetaData get_maslst_displayLapCount_MetaData ( )
      {
        int lines[] = { 3,
     4,
     5,
     6};
        ::SWA::StateMetaData state(::masld_Tracking::maslo_Display::stateId_maslst_displayLapCount, ::SWA::StateMetaData::Normal, "displayLapCount", ::std::vector<int>( lines, lines + 4 ), "Display_displayLapCount.al", "4a6e10ac4fd570bcaccca59144254c62");
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "lapMarkers", "set of instance of LapMarker", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_LapMarker, 1 ) ) );
        return state;
      }

      ::SWA::EventMetaData get_maslev_modeChange_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Tracking::maslo_Display::eventId_maslo_Display_maslev_modeChange, ::masld_Tracking::objectId_maslo_Display, ::SWA::EventMetaData::Normal, "modeChange");
        return event;
      }

      ::SWA::EventMetaData get_maslev_refresh_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Tracking::maslo_Display::eventId_maslo_Display_maslev_refresh, ::masld_Tracking::objectId_maslo_Display, ::SWA::EventMetaData::Normal, "refresh");
        return event;
      }

    }
    namespace maslo_Achievement
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Tracking::objectId_maslo_Achievement, "Achievement", "Achievement");
        object.addAttribute( ::SWA::AttributeMetaData( "startTime", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "endTime", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( getmasla_session_startTimeMetaData() );
        object.addAttribute( getmasla_goal_IDMetaData() );
        object.addAttribute( getmasla_spec_sequenceNumberMetaData() );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R12", "specifies_achievement_of", false, false, ::masld_Tracking::objectId_maslo_Goal ) );
        object.addRelationship( ::SWA::ObjectRelMetaData( "R14", "is_open_for", false, true, ::masld_Tracking::objectId_maslo_Goal ) );
        object.addService( get_masls_close_MetaData() );
        return object;
      }

      ::SWA::AttributeMetaData getmasla_session_startTimeMetaData ( )
      {
        ::SWA::AttributeMetaData attribute("session_startTime", true, "timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), ::masld_Tracking::relationshipId_R12);
        attribute.addReferential( ::masld_Tracking::relationshipId_R12 );
        attribute.addReferential( ::masld_Tracking::relationshipId_R14 );
        return attribute;
      }

      ::SWA::AttributeMetaData getmasla_goal_IDMetaData ( )
      {
        ::SWA::AttributeMetaData attribute("goal_ID", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), ::masld_Tracking::relationshipId_R12);
        attribute.addReferential( ::masld_Tracking::relationshipId_R12 );
        attribute.addReferential( ::masld_Tracking::relationshipId_R14 );
        return attribute;
      }

      ::SWA::AttributeMetaData getmasla_spec_sequenceNumberMetaData ( )
      {
        ::SWA::AttributeMetaData attribute("spec_sequenceNumber", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), ::masld_Tracking::relationshipId_R12);
        attribute.addReferential( ::masld_Tracking::relationshipId_R12 );
        attribute.addReferential( ::masld_Tracking::relationshipId_R14 );
        return attribute;
      }

      ::SWA::ServiceMetaData get_masls_close_MetaData ( )
      {
        int lines[] = { 4,
     7,
     8,
     9,
     10,
     11};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_Achievement::serviceId_masls_close, ::SWA::ServiceMetaData::Instance, "close", ::std::vector<int>( lines, lines + 6 ), "Achievement_close.svc", "de2b3f5213e62f7664c24e0ac94a6330");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "goal", "instance of Goal", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Goal ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "workoutTimer", "instance of WorkoutTimer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer ) ) );
        return service;
      }

    }
    namespace maslo_GoalAchievement
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Tracking::objectId_maslo_GoalAchievement, "GoalAchievement", "GoalAchievement");
        object.addAttribute( ::SWA::AttributeMetaData( "id", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "evaluationPeriod", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addService( get_masls_initialize_MetaData() );
        return object;
      }

      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( )
      {
        int lines[] = { 3,
     4,
     5,
     6,
     7};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_GoalAchievement::serviceId_masls_initialize, ::SWA::ServiceMetaData::Object, "initialize", ::std::vector<int>( lines, lines + 5 ), "GoalAchievement_initialize.svc", "4011fe5db2c87a1c87a04068bcf5c9e0");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "goalachievement", "instance of GoalAchievement", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_GoalAchievement ) ) );
        return service;
      }

    }
    namespace maslo_GoalSpecConstants
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Tracking::objectId_maslo_GoalSpecConstants, "GoalSpecConstants", "GoalSpecConstants");
        object.addAttribute( ::SWA::AttributeMetaData( "id", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "GoalSpecOrigin", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addService( get_masls_initialize_MetaData() );
        return object;
      }

      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( )
      {
        int lines[] = { 3,
     4,
     5,
     6,
     7};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_GoalSpecConstants::serviceId_masls_initialize, ::SWA::ServiceMetaData::Object, "initialize", ::std::vector<int>( lines, lines + 5 ), "GoalSpecConstants_initialize.svc", "98e14622a634378e706f82bda60ee4d3");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "gsc", "instance of GoalSpecConstants", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_GoalSpecConstants ) ) );
        return service;
      }

    }
    namespace maslo_HeartRateConstants
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Tracking::objectId_maslo_HeartRateConstants, "HeartRateConstants", "HeartRateConstants");
        object.addAttribute( ::SWA::AttributeMetaData( "id", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "HeartRateAveragingWindow", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "HeartRateSamplingPeriod", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addService( get_masls_initialize_MetaData() );
        return object;
      }

      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( )
      {
        int lines[] = { 3,
     4,
     5,
     6,
     7,
     8};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_HeartRateConstants::serviceId_masls_initialize, ::SWA::ServiceMetaData::Object, "initialize", ::std::vector<int>( lines, lines + 6 ), "HeartRateConstants_initialize.svc", "8709eb92a7ccacd3b4dca29efce14148");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "hrc", "instance of HeartRateConstants", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_HeartRateConstants ) ) );
        return service;
      }

    }
    namespace maslo_Speed
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Tracking::objectId_maslo_Speed, "Speed", "Speed");
        object.addAttribute( ::SWA::AttributeMetaData( "id", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "SpeedAveragingWindow", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "SecondsPerHour", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addService( get_masls_initialize_MetaData() );
        return object;
      }

      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( )
      {
        int lines[] = { 3,
     4,
     5,
     6,
     7,
     8};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_Speed::serviceId_masls_initialize, ::SWA::ServiceMetaData::Object, "initialize", ::std::vector<int>( lines, lines + 6 ), "Speed_initialize.svc", "2018127eae1a1f447f8e858d32859226");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "speed", "instance of Speed", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_Speed ) ) );
        return service;
      }

    }
    namespace maslo_WorkoutTimerConstants
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Tracking::objectId_maslo_WorkoutTimerConstants, "WorkoutTimerConstants", "WorkoutTimerConstants");
        object.addAttribute( ::SWA::AttributeMetaData( "id", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "timerPeriod", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addService( get_masls_initialize_MetaData() );
        return object;
      }

      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( )
      {
        int lines[] = { 3,
     4,
     5,
     6,
     7};
        ::SWA::ServiceMetaData service(::masld_Tracking::maslo_WorkoutTimerConstants::serviceId_masls_initialize, ::SWA::ServiceMetaData::Object, "initialize", ::std::vector<int>( lines, lines + 5 ), "WorkoutTimerConstants_initialize.svc", "3b1f69b92119ac94cfc2c772d9f2b335");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "wtc", "instance of WorkoutTimerConstants", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimerConstants ) ) );
        return service;
      }

    }
  }
}
