//
// File: Inspector__Tracking__GoalSpec.hh
//
#ifndef Inspector_Tracking_Goal_Spec_hh
#define Inspector_Tracking_Goal_Spec_hh

#include "__Tracking__GoalSpec.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_GoalSpec
    {
      class maslo_GoalSpecHandler
        : public ObjectHandler< ::masld_Tracking::maslo_GoalSpec>
      {

        // Constructors
        public:
          maslo_GoalSpecHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                               channel,
                                       ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> instance,
                                       int                                                 relId ) const;


      };
    }
  }
}
#endif // Inspector_Tracking_Goal_Spec_hh
