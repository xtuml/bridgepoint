//
// File: __Tracking__DisplayPopulation.cc
//
#include "__Tracking__DisplayPopulation.hh"

namespace masld_Tracking
{
  maslo_DisplayPopulation::maslo_DisplayPopulation ( )
  {
  }

  maslo_DisplayPopulation::~maslo_DisplayPopulation ( )
  {
  }

}
