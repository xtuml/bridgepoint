//
// File: Transient__Tracking__Goal.cc
//
#include "Tracking_OOA/__Tracking_types.hh"
#include "Transient__Tracking__Achievement.hh"
#include "Transient__Tracking__Goal.hh"
#include "Transient__Tracking__GoalSpec.hh"
#include "Transient__Tracking__WorkoutSession.hh"
#include "__Tracking__Achievement.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__WorkoutSession.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "transient/ToManyRelationship.hh"
#include "transient/ToOneRelationship.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_Goal::maslo_Goal ( const ::masld_Tracking::maslt_GoalDisposition& masla_disposition,
                             double                                         masla_startingPoint,
                             int32_t                                        masla_ID,
                             const ::SWA::EventTimers::TimerIdType&         masla_evaluationTimer,
                             const ::SWA::Timestamp&                        masla_session_startTime,
                             int32_t                                        masla_spec_sequenceNumber,
                             ::masld_Tracking::maslo_Goal::Type             currentState )
      : architectureId(getNextArchId()),
        masla_disposition(masla_disposition),
        masla_startingPoint(masla_startingPoint),
        masla_ID(masla_ID),
        masla_evaluationTimer(masla_evaluationTimer),
        masla_session_startTime(masla_session_startTime),
        masla_spec_sequenceNumber(masla_spec_sequenceNumber),
        currentState(currentState),
        R9_specified_by_GoalSpec(),
        R11_is_currently_executing_within_WorkoutSession(),
        R12_has_recorded_Achievement(),
        R13_was_executed_within_WorkoutSession(),
        R14_has_open_Achievement()
    {
    }

    ToOneRelationship<maslo_GoalSpec>& maslo_Goal::get_R9_specified_by_GoalSpec ( )
    {
      return R9_specified_by_GoalSpec;
    }

    const ToOneRelationship<maslo_GoalSpec>& maslo_Goal::get_R9_specified_by_GoalSpec ( ) const
    {
      return R9_specified_by_GoalSpec;
    }

    ToOneRelationship<maslo_WorkoutSession>& maslo_Goal::get_R11_is_currently_executing_within_WorkoutSession ( )
    {
      return R11_is_currently_executing_within_WorkoutSession;
    }

    const ToOneRelationship<maslo_WorkoutSession>& maslo_Goal::get_R11_is_currently_executing_within_WorkoutSession ( ) const
    {
      return R11_is_currently_executing_within_WorkoutSession;
    }

    ToManyRelationship<maslo_Achievement>& maslo_Goal::get_R12_has_recorded_Achievement ( )
    {
      return R12_has_recorded_Achievement;
    }

    const ToManyRelationship<maslo_Achievement>& maslo_Goal::get_R12_has_recorded_Achievement ( ) const
    {
      return R12_has_recorded_Achievement;
    }

    ToOneRelationship<maslo_WorkoutSession>& maslo_Goal::get_R13_was_executed_within_WorkoutSession ( )
    {
      return R13_was_executed_within_WorkoutSession;
    }

    const ToOneRelationship<maslo_WorkoutSession>& maslo_Goal::get_R13_was_executed_within_WorkoutSession ( ) const
    {
      return R13_was_executed_within_WorkoutSession;
    }

    ToOneRelationship<maslo_Achievement>& maslo_Goal::get_R14_has_open_Achievement ( )
    {
      return R14_has_open_Achievement;
    }

    const ToOneRelationship<maslo_Achievement>& maslo_Goal::get_R14_has_open_Achievement ( ) const
    {
      return R14_has_open_Achievement;
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> maslo_Goal::navigate_R9_specified_by_GoalSpec ( ) const
    {
      return get_R9_specified_by_GoalSpec().navigate();
    }

    ::std::size_t maslo_Goal::count_R9_specified_by_GoalSpec ( ) const
    {
      return get_R9_specified_by_GoalSpec().count();
    }

    void maslo_Goal::link_R9_specified_by_GoalSpec ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& rhs )
    {
      ::SWA::ObjectPtr<maslo_GoalSpec> rhs2 = rhs.downcast<maslo_GoalSpec>();
      this->get_R9_specified_by_GoalSpec().link( rhs2 );
      try
      {
        rhs2->get_R9_specifies_Goal().link( ::SWA::ObjectPtr<maslo_Goal>( this ) );
      }
      catch ( ... )
      {
        this->get_R9_specified_by_GoalSpec().unlink( rhs2 );
        throw;
      }
    }

    void maslo_Goal::unlink_R9_specified_by_GoalSpec ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& rhs )
    {
      ::SWA::ObjectPtr<maslo_GoalSpec> rhs2 = rhs.downcast<maslo_GoalSpec>();
      this->get_R9_specified_by_GoalSpec().unlink( rhs2 );
      try
      {
        rhs2->get_R9_specifies_Goal().unlink( ::SWA::ObjectPtr<maslo_Goal>( this ) );
      }
      catch ( ... )
      {
        this->get_R9_specified_by_GoalSpec().link( rhs2 );
        throw;
      }
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_Goal::navigate_R11_is_currently_executing_within_WorkoutSession ( ) const
    {
      return get_R11_is_currently_executing_within_WorkoutSession().navigate();
    }

    ::std::size_t maslo_Goal::count_R11_is_currently_executing_within_WorkoutSession ( ) const
    {
      return get_R11_is_currently_executing_within_WorkoutSession().count();
    }

    void maslo_Goal::link_R11_is_currently_executing_within_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> rhs2 = rhs.downcast<maslo_WorkoutSession>();
      this->get_R11_is_currently_executing_within_WorkoutSession().link( rhs2 );
      try
      {
        rhs2->get_R11_is_currently_executing_Goal().link( ::SWA::ObjectPtr<maslo_Goal>( this ) );
      }
      catch ( ... )
      {
        this->get_R11_is_currently_executing_within_WorkoutSession().unlink( rhs2 );
        throw;
      }
    }

    void maslo_Goal::unlink_R11_is_currently_executing_within_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> rhs2 = rhs.downcast<maslo_WorkoutSession>();
      this->get_R11_is_currently_executing_within_WorkoutSession().unlink( rhs2 );
      try
      {
        rhs2->get_R11_is_currently_executing_Goal().unlink( ::SWA::ObjectPtr<maslo_Goal>( this ) );
      }
      catch ( ... )
      {
        this->get_R11_is_currently_executing_within_WorkoutSession().link( rhs2 );
        throw;
      }
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> > maslo_Goal::navigate_R12_has_recorded_Achievement ( ) const
    {
      return get_R12_has_recorded_Achievement().navigate();
    }

    ::std::size_t maslo_Goal::count_R12_has_recorded_Achievement ( ) const
    {
      return get_R12_has_recorded_Achievement().count();
    }

    void maslo_Goal::link_R12_has_recorded_Achievement ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Achievement> rhs2 = rhs.downcast<maslo_Achievement>();
      this->get_R12_has_recorded_Achievement().link( rhs2 );
      try
      {
        rhs2->get_R12_specifies_achievement_of_Goal().link( ::SWA::ObjectPtr<maslo_Goal>( this ) );
      }
      catch ( ... )
      {
        this->get_R12_has_recorded_Achievement().unlink( rhs2 );
        throw;
      }
    }

    void maslo_Goal::unlink_R12_has_recorded_Achievement ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Achievement> rhs2 = rhs.downcast<maslo_Achievement>();
      this->get_R12_has_recorded_Achievement().unlink( rhs2 );
      try
      {
        rhs2->get_R12_specifies_achievement_of_Goal().unlink( ::SWA::ObjectPtr<maslo_Goal>( this ) );
      }
      catch ( ... )
      {
        this->get_R12_has_recorded_Achievement().link( rhs2 );
        throw;
      }
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_Goal::navigate_R13_was_executed_within_WorkoutSession ( ) const
    {
      return get_R13_was_executed_within_WorkoutSession().navigate();
    }

    ::std::size_t maslo_Goal::count_R13_was_executed_within_WorkoutSession ( ) const
    {
      return get_R13_was_executed_within_WorkoutSession().count();
    }

    void maslo_Goal::link_R13_was_executed_within_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> rhs2 = rhs.downcast<maslo_WorkoutSession>();
      this->get_R13_was_executed_within_WorkoutSession().link( rhs2 );
      try
      {
        rhs2->get_R13_has_executed_Goal().link( ::SWA::ObjectPtr<maslo_Goal>( this ) );
      }
      catch ( ... )
      {
        this->get_R13_was_executed_within_WorkoutSession().unlink( rhs2 );
        throw;
      }
    }

    void maslo_Goal::unlink_R13_was_executed_within_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> rhs2 = rhs.downcast<maslo_WorkoutSession>();
      this->get_R13_was_executed_within_WorkoutSession().unlink( rhs2 );
      try
      {
        rhs2->get_R13_has_executed_Goal().unlink( ::SWA::ObjectPtr<maslo_Goal>( this ) );
      }
      catch ( ... )
      {
        this->get_R13_was_executed_within_WorkoutSession().link( rhs2 );
        throw;
      }
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> maslo_Goal::navigate_R14_has_open_Achievement ( ) const
    {
      return get_R14_has_open_Achievement().navigate();
    }

    ::std::size_t maslo_Goal::count_R14_has_open_Achievement ( ) const
    {
      return get_R14_has_open_Achievement().count();
    }

    void maslo_Goal::link_R14_has_open_Achievement ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Achievement> rhs2 = rhs.downcast<maslo_Achievement>();
      this->get_R14_has_open_Achievement().link( rhs2 );
      try
      {
        rhs2->get_R14_is_open_for_Goal().link( ::SWA::ObjectPtr<maslo_Goal>( this ) );
      }
      catch ( ... )
      {
        this->get_R14_has_open_Achievement().unlink( rhs2 );
        throw;
      }
    }

    void maslo_Goal::unlink_R14_has_open_Achievement ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Achievement> rhs2 = rhs.downcast<maslo_Achievement>();
      this->get_R14_has_open_Achievement().unlink( rhs2 );
      try
      {
        rhs2->get_R14_is_open_for_Goal().unlink( ::SWA::ObjectPtr<maslo_Goal>( this ) );
      }
      catch ( ... )
      {
        this->get_R14_has_open_Achievement().link( rhs2 );
        throw;
      }
    }

  }
}
