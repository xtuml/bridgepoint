//
// File: __Tracking__WorkoutTimer__paused.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_Tracking
{
  void maslo_WorkoutTimer::state_maslst_paused ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_WorkoutTimer, stateId_maslst_paused);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // this.deactivate()
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          ::SWA::ObjectPtr<maslo_WorkoutTimer>( this )->masls_deactivate();
        }
      }
    }
  }

}
