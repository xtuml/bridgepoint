//
// File: Transient__Tracking__GoalAchievementPopulation.cc
//
#include "Transient__Tracking__GoalAchievement.hh"
#include "Transient__Tracking__GoalAchievementPopulation.hh"
#include "__Tracking__GoalAchievement.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_GoalAchievementPopulation::maslo_GoalAchievementPopulation ( )
      : masla_id_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> maslo_GoalAchievementPopulation::createInstance ( int32_t masla_id,
                                                                                                                 int32_t masla_evaluationPeriod )
    {
      if ( exists_masla_id( masla_id ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> instance(new maslo_GoalAchievement(  masla_id,
                            masla_evaluationPeriod ));
      addInstance( instance );
      return instance;
    }

    void maslo_GoalAchievementPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> instance )
    {
      masla_id_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> >::value_type( ::boost::make_tuple( instance->get_masla_id() ), instance ) );
    }

    void maslo_GoalAchievementPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> instance )
    {
      masla_id_Lookup.erase( ::boost::make_tuple( instance->get_masla_id() ) );
    }

    bool maslo_GoalAchievementPopulation::exists_masla_id ( int32_t masla_id ) const
    {
      return masla_id_Lookup.find( ::boost::make_tuple( masla_id ) ) != masla_id_Lookup.end();
    }

    maslo_GoalAchievementPopulation& maslo_GoalAchievementPopulation::getPopulation ( )
    {
      static maslo_GoalAchievementPopulation population;
      return population;
    }

    bool maslo_GoalAchievementPopulation::registered = maslo_GoalAchievementPopulation::registerSingleton( &maslo_GoalAchievementPopulation::getPopulation );

  }
}
