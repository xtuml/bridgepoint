//
// File: Sqlite__Tracking__WorkoutSessionPopulation.cc
//
#include "Sqlite__Tracking__Display.hh"
#include "Sqlite__Tracking__DisplayPopulation.hh"
#include "Sqlite__Tracking__Goal.hh"
#include "Sqlite__Tracking__GoalPopulation.hh"
#include "Sqlite__Tracking__GoalSpec.hh"
#include "Sqlite__Tracking__GoalSpecPopulation.hh"
#include "Sqlite__Tracking__HeartRateSample.hh"
#include "Sqlite__Tracking__HeartRateSamplePopulation.hh"
#include "Sqlite__Tracking__R10Mapper.hh"
#include "Sqlite__Tracking__R10MapperSql.hh"
#include "Sqlite__Tracking__R11Mapper.hh"
#include "Sqlite__Tracking__R11MapperSql.hh"
#include "Sqlite__Tracking__R13Mapper.hh"
#include "Sqlite__Tracking__R13MapperSql.hh"
#include "Sqlite__Tracking__R4Mapper.hh"
#include "Sqlite__Tracking__R4MapperSql.hh"
#include "Sqlite__Tracking__R6Mapper.hh"
#include "Sqlite__Tracking__R6MapperSql.hh"
#include "Sqlite__Tracking__R7Mapper.hh"
#include "Sqlite__Tracking__R7MapperSql.hh"
#include "Sqlite__Tracking__R8Mapper.hh"
#include "Sqlite__Tracking__R8MapperSql.hh"
#include "Sqlite__Tracking__TrackLog.hh"
#include "Sqlite__Tracking__TrackLogPopulation.hh"
#include "Sqlite__Tracking__WorkoutSession.hh"
#include "Sqlite__Tracking__WorkoutSessionPopulation.hh"
#include "Sqlite__Tracking__WorkoutTimer.hh"
#include "Sqlite__Tracking__WorkoutTimerPopulation.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__HeartRateSample.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/bind.hpp"
#include "boost/shared_ptr.hpp"
#include "boost/signals2.hpp"
#include <cstddef>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_WorkoutSessionPopulation::maslo_WorkoutSessionPopulation ( )
      : R7Mapper(RelationshipR7Mapper::singleton()),
        R8Mapper(RelationshipR8Mapper::singleton()),
        R4Mapper(RelationshipR4Mapper::singleton()),
        R6Mapper(RelationshipR6Mapper::singleton()),
        R10Mapper(RelationshipR10Mapper::singleton()),
        R11Mapper(RelationshipR11Mapper::singleton()),
        R13Mapper(RelationshipR13Mapper::singleton())
    {
    }

    maslo_WorkoutSessionPopulation::~maslo_WorkoutSessionPopulation ( )
    {
    }

    void maslo_WorkoutSessionPopulation::initialise ( )
    {
      mapper->initialise();
      if ( R7Mapper.isInitialised() == false )
      {
        R7Mapper.initialise( ::boost::shared_ptr<RelationshipR7Mapper::RelSqlGeneratorType>( new RelationshipR7SqlGenerator() ) );
      }

      if ( R8Mapper.isInitialised() == false )
      {
        R8Mapper.initialise( ::boost::shared_ptr<RelationshipR8Mapper::RelSqlGeneratorType>( new RelationshipR8SqlGenerator() ) );
      }

      if ( R4Mapper.isInitialised() == false )
      {
        R4Mapper.initialise( ::boost::shared_ptr<RelationshipR4Mapper::RelSqlGeneratorType>( new RelationshipR4SqlGenerator() ) );
      }

      if ( R6Mapper.isInitialised() == false )
      {
        R6Mapper.initialise( ::boost::shared_ptr<RelationshipR6Mapper::RelSqlGeneratorType>( new RelationshipR6SqlGenerator() ) );
      }

      if ( R10Mapper.isInitialised() == false )
      {
        R10Mapper.initialise( ::boost::shared_ptr<RelationshipR10Mapper::RelSqlGeneratorType>( new RelationshipR10SqlGenerator() ) );
      }

      if ( R11Mapper.isInitialised() == false )
      {
        R11Mapper.initialise( ::boost::shared_ptr<RelationshipR11Mapper::RelSqlGeneratorType>( new RelationshipR11SqlGenerator() ) );
      }

      if ( R13Mapper.isInitialised() == false )
      {
        R13Mapper.initialise( ::boost::shared_ptr<RelationshipR13Mapper::RelSqlGeneratorType>( new RelationshipR13SqlGenerator() ) );
      }

    }

    maslo_WorkoutSessionPopulation& maslo_WorkoutSessionPopulation::getPopulation ( )
    {
      static maslo_WorkoutSessionPopulation population;
      return population;
    }

    bool maslo_WorkoutSessionPopulation::registered = maslo_WorkoutSessionPopulation::registerSingleton( &maslo_WorkoutSessionPopulation::getPopulation );

    ::boost::signals2::connection maslo_WorkoutSessionPopulation::initialised = ::SWA::Process::getInstance().registerInitialisingListener( ::boost::bind( &maslo_WorkoutSessionPopulation::initialise, ::boost::bind( &maslo_WorkoutSessionPopulation::getPopulation ) ) );

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_WorkoutSessionPopulation::findObject ( const ::SWA::IdType& obj )
    {
      return mapper->find( obj );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> > maslo_WorkoutSessionPopulation::findObject ( const MapperType::PsObjectIdSet& obj )
    {
      MapperType::PsObjectPtrSet objectSet = mapper->find( obj );
      return ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >( objectSet.begin(), objectSet.end(), true );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_WorkoutSessionPopulation::createInstance ( const ::SWA::Timestamp& masla_startTime,
                                                                                                               double                  masla_accumulatedDistance )
    {
      return mapper->createInstance( masla_startTime, masla_accumulatedDistance );
    }

    void maslo_WorkoutSessionPopulation::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> instance )
    {
      {
        R7Mapper.objectDeletedLhs( instance.downcast<maslo_WorkoutSession>() );
        R8Mapper.objectDeletedLhs( instance.downcast<maslo_WorkoutSession>() );
        R4Mapper.objectDeletedLhs( instance.downcast<maslo_WorkoutSession>() );
        R6Mapper.objectDeletedLhs( instance.downcast<maslo_WorkoutSession>() );
        R10Mapper.objectDeletedLhs( instance.downcast<maslo_WorkoutSession>() );
        R11Mapper.objectDeletedLhs( instance.downcast<maslo_WorkoutSession>() );
        R13Mapper.objectDeletedLhs( instance.downcast<maslo_WorkoutSession>() );
      }
      mapper->deleteInstance( instance );
    }

    void maslo_WorkoutSessionPopulation::link_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                                                       const ::SWA::ObjectPtr<maslo_Display>&        rhs )
    {
      R7Mapper.linkFromLhsToRhs( lhs, rhs );
    }

    void maslo_WorkoutSessionPopulation::unlink_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                                                         const ::SWA::ObjectPtr<maslo_Display>&        rhs )
    {
      R7Mapper.unlinkFromLhsToRhs( lhs, rhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> maslo_WorkoutSessionPopulation::navigate_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs )
    {
      const RelationshipR7Mapper::NavigatedRhsType& navigated(R7Mapper.navigateFromLhsToRhs( lhs ));
      return maslo_DisplayPopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_WorkoutSessionPopulation::count_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs )
    {
      return R7Mapper.countFromLhsToRhs( lhs );
    }

    void maslo_WorkoutSessionPopulation::link_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                                            const ::SWA::ObjectPtr<maslo_WorkoutTimer>&   rhs )
    {
      R8Mapper.linkFromLhsToRhs( lhs, rhs );
    }

    void maslo_WorkoutSessionPopulation::unlink_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                                              const ::SWA::ObjectPtr<maslo_WorkoutTimer>&   rhs )
    {
      R8Mapper.unlinkFromLhsToRhs( lhs, rhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> maslo_WorkoutSessionPopulation::navigate_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs )
    {
      const RelationshipR8Mapper::NavigatedRhsType& navigated(R8Mapper.navigateFromLhsToRhs( lhs ));
      return maslo_WorkoutTimerPopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_WorkoutSessionPopulation::count_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs )
    {
      return R8Mapper.countFromLhsToRhs( lhs );
    }

    void maslo_WorkoutSessionPopulation::link_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                                             const ::SWA::ObjectPtr<maslo_TrackLog>&       rhs )
    {
      R4Mapper.linkFromLhsToRhs( lhs, rhs );
    }

    void maslo_WorkoutSessionPopulation::unlink_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                                               const ::SWA::ObjectPtr<maslo_TrackLog>&       rhs )
    {
      R4Mapper.unlinkFromLhsToRhs( lhs, rhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> maslo_WorkoutSessionPopulation::navigate_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs )
    {
      const RelationshipR4Mapper::NavigatedRhsType& navigated(R4Mapper.navigateFromLhsToRhs( lhs ));
      return maslo_TrackLogPopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_WorkoutSessionPopulation::count_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs )
    {
      return R4Mapper.countFromLhsToRhs( lhs );
    }

    void maslo_WorkoutSessionPopulation::link_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr<maslo_WorkoutSession>&  lhs,
                                                                                                  const ::SWA::ObjectPtr<maslo_HeartRateSample>& rhs )
    {
      R6Mapper.linkFromLhsToRhs( lhs, rhs );
    }

    void maslo_WorkoutSessionPopulation::unlink_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr<maslo_WorkoutSession>&  lhs,
                                                                                                    const ::SWA::ObjectPtr<maslo_HeartRateSample>& rhs )
    {
      R6Mapper.unlinkFromLhsToRhs( lhs, rhs );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> > maslo_WorkoutSessionPopulation::navigate_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs )
    {
      const RelationshipR6Mapper::NavigatedRhsType& navigated(R6Mapper.navigateFromLhsToRhs( lhs ));
      return maslo_HeartRateSamplePopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_WorkoutSessionPopulation::count_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs )
    {
      return R6Mapper.countFromLhsToRhs( lhs );
    }

    void maslo_WorkoutSessionPopulation::link_R10_includes_GoalSpec ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                                      const ::SWA::ObjectPtr<maslo_GoalSpec>&       rhs )
    {
      R10Mapper.linkFromLhsToRhs( lhs, rhs );
    }

    void maslo_WorkoutSessionPopulation::unlink_R10_includes_GoalSpec ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                                        const ::SWA::ObjectPtr<maslo_GoalSpec>&       rhs )
    {
      R10Mapper.unlinkFromLhsToRhs( lhs, rhs );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> > maslo_WorkoutSessionPopulation::navigate_R10_includes_GoalSpec ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs )
    {
      const RelationshipR10Mapper::NavigatedRhsType& navigated(R10Mapper.navigateFromLhsToRhs( lhs ));
      return maslo_GoalSpecPopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_WorkoutSessionPopulation::count_R10_includes_GoalSpec ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs )
    {
      return R10Mapper.countFromLhsToRhs( lhs );
    }

    void maslo_WorkoutSessionPopulation::link_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                                                const ::SWA::ObjectPtr<maslo_Goal>&           rhs )
    {
      R11Mapper.linkFromLhsToRhs( lhs, rhs );
    }

    void maslo_WorkoutSessionPopulation::unlink_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                                                  const ::SWA::ObjectPtr<maslo_Goal>&           rhs )
    {
      R11Mapper.unlinkFromLhsToRhs( lhs, rhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> maslo_WorkoutSessionPopulation::navigate_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs )
    {
      const RelationshipR11Mapper::NavigatedRhsType& navigated(R11Mapper.navigateFromLhsToRhs( lhs ));
      return maslo_GoalPopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_WorkoutSessionPopulation::count_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs )
    {
      return R11Mapper.countFromLhsToRhs( lhs );
    }

    void maslo_WorkoutSessionPopulation::link_R13_has_executed_Goal ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                                      const ::SWA::ObjectPtr<maslo_Goal>&           rhs )
    {
      R13Mapper.linkFromLhsToRhs( lhs, rhs );
    }

    void maslo_WorkoutSessionPopulation::unlink_R13_has_executed_Goal ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs,
                                                                        const ::SWA::ObjectPtr<maslo_Goal>&           rhs )
    {
      R13Mapper.unlinkFromLhsToRhs( lhs, rhs );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> > maslo_WorkoutSessionPopulation::navigate_R13_has_executed_Goal ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs )
    {
      const RelationshipR13Mapper::NavigatedRhsType& navigated(R13Mapper.navigateFromLhsToRhs( lhs ));
      return maslo_GoalPopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_WorkoutSessionPopulation::count_R13_has_executed_Goal ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& lhs )
    {
      return R13Mapper.countFromLhsToRhs( lhs );
    }

  }
}
