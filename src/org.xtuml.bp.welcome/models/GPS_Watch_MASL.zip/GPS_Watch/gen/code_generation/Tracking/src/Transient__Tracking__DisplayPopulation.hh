//
// File: Transient__Tracking__DisplayPopulation.hh
//
#ifndef Transient_Tracking_Display_Population_hh
#define Transient_Tracking_Display_Population_hh

#include "__Tracking__Display.hh"
#include "__Tracking__DisplayPopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace transient
{
  namespace masld_Tracking
  {
    class maslo_DisplayPopulation
      : public TransientPopulation< ::masld_Tracking::maslo_Display,::masld_Tracking::maslo_DisplayPopulation>
    {

      // Instance Creation
      private:
        maslo_DisplayPopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> createInstance ( const ::SWA::Timestamp&               masla_session_startTime,
                                                                                    ::masld_Tracking::maslo_Display::Type currentState );


      // Singleton Registration
      public:
        static maslo_DisplayPopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple< ::SWA::Timestamp>,::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> > masla_session_startTime_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> instance );
      protected:
        bool exists_masla_session_startTime ( const ::SWA::Timestamp& masla_session_startTime ) const;


    };
  }
}
#endif // Transient_Tracking_Display_Population_hh
