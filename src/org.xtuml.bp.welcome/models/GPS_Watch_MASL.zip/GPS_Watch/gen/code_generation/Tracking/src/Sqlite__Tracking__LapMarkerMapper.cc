//
// File: Sqlite__Tracking__LapMarkerMapper.cc
//
#include "Sqlite__Tracking__LapMarker.hh"
#include "Sqlite__Tracking__LapMarkerMapper.hh"
#include "Sqlite__Tracking__LapMarkerMapperSql.hh"
#include "__Tracking__LapMarker.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_LapMarkerMapper::maslo_LapMarkerMapper ( )
      : ::SQL::ObjectMapper< ::masld_Tracking::maslo_LapMarker,maslo_LapMarker>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_Tracking::maslo_LapMarker,maslo_LapMarker> >( new maslo_LapMarkerSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_LapMarkerMapper::~maslo_LapMarkerMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> maslo_LapMarkerMapper::createInstance ( int32_t                 masla_lapTime,
                                                                                                 const ::SWA::Timestamp& masla_session_startTime )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_LapMarker::PrimaryKeyType>::value_type( masla_lapTime, masla_session_startTime ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_LapMarker> instance(new maslo_LapMarker(  uniqueId,
                      masla_lapTime,
                      masla_session_startTime ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_LapMarkerMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> instance )
    {
      ::SQL::ObjectMapper< ::masld_Tracking::maslo_LapMarker,maslo_LapMarker>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_LapMarker>()->getPrimaryKey() );
    }

    bool maslo_LapMarkerMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
