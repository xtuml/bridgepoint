//
// File: Inspector__Tracking__LOC.cc
//
#include "Inspector__Tracking__LOC.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include "swa/Stack.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslb_LOC
    {
      class masls_getDistanceHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_getDistanceInvoker
      {

        public:
          masls_getDistanceInvoker ( CommunicationChannel& channel )
            : maslp_result(),
              maslp_toLong(),
              maslp_toLat(),
              maslp_fromLong(),
              maslp_fromLat()

          {
            channel >> maslp_result;
            channel >> maslp_toLong;
            channel >> maslp_toLat;
            channel >> maslp_fromLong;
            channel >> maslp_fromLat;
          }
          void operator() ( ) { ::masld_Tracking::maslb_LOC::masls_getDistance( maslp_result, maslp_toLong, maslp_toLat, maslp_fromLong, maslp_fromLat ); }


        private:
          double maslp_result;
          double maslp_toLong;
          double maslp_toLat;
          double maslp_fromLong;
          double maslp_fromLat;


      };
      class masls_getLocationHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_getLocationInvoker
      {

        public:
          masls_getLocationInvoker ( CommunicationChannel& channel )
            : maslp_longitude(),
              maslp_latitude()

          {
            channel >> maslp_longitude;
            channel >> maslp_latitude;
          }
          void operator() ( ) { ::masld_Tracking::maslb_LOC::masls_getLocation( maslp_longitude, maslp_latitude ); }


        private:
          double maslp_longitude;
          double maslp_latitude;


      };
      class masls_registerListenerHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_registerListenerInvoker
      {

        public:
          masls_registerListenerInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_Tracking::maslb_LOC::masls_registerListener(); }


      };
      class masls_unregisterListenerHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_unregisterListenerInvoker
      {

        public:
          masls_unregisterListenerInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_Tracking::maslb_LOC::masls_unregisterListener(); }


      };
      Callable masls_getDistanceHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_getDistanceInvoker( channel );
      }

      void masls_getDistanceHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                      const ::SWA::StackFrame& frame ) const
      {

        // Write result
        channel << frame.getParameters()[0].getValue<double>();

        // Write toLong
        channel << frame.getParameters()[1].getValue<double>();

        // Write toLat
        channel << frame.getParameters()[2].getValue<double>();

        // Write fromLong
        channel << frame.getParameters()[3].getValue<double>();

        // Write fromLat
        channel << frame.getParameters()[4].getValue<double>();

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      Callable masls_getLocationHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_getLocationInvoker( channel );
      }

      void masls_getLocationHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                      const ::SWA::StackFrame& frame ) const
      {

        // Write longitude
        channel << frame.getParameters()[0].getValue<double>();

        // Write latitude
        channel << frame.getParameters()[1].getValue<double>();

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      Callable masls_registerListenerHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_registerListenerInvoker( channel );
      }

      void masls_registerListenerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                           const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      Callable masls_unregisterListenerHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_unregisterListenerInvoker( channel );
      }

      void masls_unregisterListenerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                             const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      maslb_LOCHandler::maslb_LOCHandler ( )
      {
        registerServiceHandler( ::masld_Tracking::maslb_LOC::serviceId_masls_getDistance, ::boost::shared_ptr<ActionHandler>( new masls_getDistanceHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslb_LOC::serviceId_masls_getLocation, ::boost::shared_ptr<ActionHandler>( new masls_getLocationHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslb_LOC::serviceId_masls_registerListener, ::boost::shared_ptr<ActionHandler>( new masls_registerListenerHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslb_LOC::serviceId_masls_unregisterListener, ::boost::shared_ptr<ActionHandler>( new masls_unregisterListenerHandler() ) );
      }

    }
  }
}
