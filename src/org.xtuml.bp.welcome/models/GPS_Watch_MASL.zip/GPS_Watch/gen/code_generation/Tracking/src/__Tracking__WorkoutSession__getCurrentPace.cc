//
// File: __Tracking__WorkoutSession__getCurrentPace.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__WorkoutSession.hh"
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_Tracking
{
  double maslo_WorkoutSession::masls_getCurrentPace ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_WorkoutSession, serviceId_masls_getCurrentPace);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // result : real;
        double maslv_result = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_result(0, maslv_result);

        // result := 0.0;
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          maslv_result = 0.0;
        }

        // if (this.getCurrentSpeed() /= 0.0) then ...
        // else ...
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          if ( ::SWA::ObjectPtr<maslo_WorkoutSession>( this )->masls_getCurrentSpeed() != 0.0 )
          {

            // result := (60.0 / this.getCurrentSpeed());
            {
              ::SWA::Stack::ExecutingStatement statement(7);
              maslv_result = 60.0 / ::SWA::ObjectPtr<maslo_WorkoutSession>( this )->masls_getCurrentSpeed();
            }
          }
          else
          {

            // result := 0.0;
            {
              ::SWA::Stack::ExecutingStatement statement(9);
              maslv_result = 0.0;
            }
          }
        }

        // return result;
        {
          ::SWA::Stack::ExecutingStatement statement(12);
          return maslv_result;
        }
      }
    }
  }

}
