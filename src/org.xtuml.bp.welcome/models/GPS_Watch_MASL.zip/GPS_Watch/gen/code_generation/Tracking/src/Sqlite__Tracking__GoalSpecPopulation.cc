//
// File: Sqlite__Tracking__GoalSpecPopulation.cc
//
#include "Sqlite__Tracking__Goal.hh"
#include "Sqlite__Tracking__GoalPopulation.hh"
#include "Sqlite__Tracking__GoalSpec.hh"
#include "Sqlite__Tracking__GoalSpecPopulation.hh"
#include "Sqlite__Tracking__R10Mapper.hh"
#include "Sqlite__Tracking__R10MapperSql.hh"
#include "Sqlite__Tracking__R9Mapper.hh"
#include "Sqlite__Tracking__R9MapperSql.hh"
#include "Sqlite__Tracking__WorkoutSession.hh"
#include "Sqlite__Tracking__WorkoutSessionPopulation.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/bind.hpp"
#include "boost/shared_ptr.hpp"
#include "boost/signals2.hpp"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_GoalSpecPopulation::maslo_GoalSpecPopulation ( )
      : R9Mapper(RelationshipR9Mapper::singleton()),
        R10Mapper(RelationshipR10Mapper::singleton())
    {
    }

    maslo_GoalSpecPopulation::~maslo_GoalSpecPopulation ( )
    {
    }

    void maslo_GoalSpecPopulation::initialise ( )
    {
      mapper->initialise();
      if ( R9Mapper.isInitialised() == false )
      {
        R9Mapper.initialise( ::boost::shared_ptr<RelationshipR9Mapper::RelSqlGeneratorType>( new RelationshipR9SqlGenerator() ) );
      }

      if ( R10Mapper.isInitialised() == false )
      {
        R10Mapper.initialise( ::boost::shared_ptr<RelationshipR10Mapper::RelSqlGeneratorType>( new RelationshipR10SqlGenerator() ) );
      }

    }

    maslo_GoalSpecPopulation& maslo_GoalSpecPopulation::getPopulation ( )
    {
      static maslo_GoalSpecPopulation population;
      return population;
    }

    bool maslo_GoalSpecPopulation::registered = maslo_GoalSpecPopulation::registerSingleton( &maslo_GoalSpecPopulation::getPopulation );

    ::boost::signals2::connection maslo_GoalSpecPopulation::initialised = ::SWA::Process::getInstance().registerInitialisingListener( ::boost::bind( &maslo_GoalSpecPopulation::initialise, ::boost::bind( &maslo_GoalSpecPopulation::getPopulation ) ) );

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> maslo_GoalSpecPopulation::findObject ( const ::SWA::IdType& obj )
    {
      return mapper->find( obj );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> > maslo_GoalSpecPopulation::findObject ( const MapperType::PsObjectIdSet& obj )
    {
      MapperType::PsObjectPtrSet objectSet = mapper->find( obj );
      return ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> >( objectSet.begin(), objectSet.end(), true );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> maslo_GoalSpecPopulation::createInstance ( double                                      masla_minimum,
                                                                                                   double                                      masla_maximum,
                                                                                                   double                                      masla_span,
                                                                                                   const ::masld_Tracking::maslt_GoalCriteria& masla_criteriaType,
                                                                                                   const ::masld_Tracking::maslt_GoalSpan&     masla_spanType,
                                                                                                   int32_t                                     masla_sequenceNumber,
                                                                                                   const ::SWA::Timestamp&                     masla_session_startTime,
                                                                                                   int32_t                                     masla_last_goal_ID )
    {
      return mapper->createInstance( masla_minimum, masla_maximum, masla_span, masla_criteriaType, masla_spanType, masla_sequenceNumber, masla_session_startTime, masla_last_goal_ID );
    }

    void maslo_GoalSpecPopulation::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> instance )
    {
      {
        R9Mapper.objectDeletedLhs( instance.downcast<maslo_GoalSpec>() );
        R10Mapper.objectDeletedRhs( instance.downcast<maslo_GoalSpec>() );
      }
      mapper->deleteInstance( instance );
    }

    void maslo_GoalSpecPopulation::link_R9_specifies_Goal ( const ::SWA::ObjectPtr<maslo_GoalSpec>& lhs,
                                                            const ::SWA::ObjectPtr<maslo_Goal>&     rhs )
    {
      R9Mapper.linkFromLhsToRhs( lhs, rhs );
    }

    void maslo_GoalSpecPopulation::unlink_R9_specifies_Goal ( const ::SWA::ObjectPtr<maslo_GoalSpec>& lhs,
                                                              const ::SWA::ObjectPtr<maslo_Goal>&     rhs )
    {
      R9Mapper.unlinkFromLhsToRhs( lhs, rhs );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> > maslo_GoalSpecPopulation::navigate_R9_specifies_Goal ( const ::SWA::ObjectPtr<maslo_GoalSpec>& lhs )
    {
      const RelationshipR9Mapper::NavigatedRhsType& navigated(R9Mapper.navigateFromLhsToRhs( lhs ));
      return maslo_GoalPopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_GoalSpecPopulation::count_R9_specifies_Goal ( const ::SWA::ObjectPtr<maslo_GoalSpec>& lhs )
    {
      return R9Mapper.countFromLhsToRhs( lhs );
    }

    void maslo_GoalSpecPopulation::link_R10_included_in_WorkoutSession ( const ::SWA::ObjectPtr<maslo_GoalSpec>&       lhs,
                                                                         const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs )
    {
      R10Mapper.linkFromRhsToLhs( lhs, rhs );
    }

    void maslo_GoalSpecPopulation::unlink_R10_included_in_WorkoutSession ( const ::SWA::ObjectPtr<maslo_GoalSpec>&       lhs,
                                                                           const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs )
    {
      R10Mapper.unlinkFromRhsToLhs( lhs, rhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_GoalSpecPopulation::navigate_R10_included_in_WorkoutSession ( const ::SWA::ObjectPtr<maslo_GoalSpec>& lhs )
    {
      const RelationshipR10Mapper::NavigatedLhsType& navigated(R10Mapper.navigateFromRhsToLhs( lhs ));
      return maslo_WorkoutSessionPopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_GoalSpecPopulation::count_R10_included_in_WorkoutSession ( const ::SWA::ObjectPtr<maslo_GoalSpec>& lhs )
    {
      return R10Mapper.countFromRhsToLhs( lhs );
    }

    // MASL find: (sequenceNumber = p1)
    ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> maslo_GoalSpecPopulation::findOne_OPmasl_sequenceNumber_maslEQp1CP ( int32_t p1 ) const
    {
      return mapper->findOne_OPmasl_sequenceNumber_maslEQp1CP( p1 );
    }

  }
}
