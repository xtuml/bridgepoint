//
// File: __Tracking__TrackPoint.hh
//
#ifndef _Tracking_Track_Point_hh
#define _Tracking_Track_Point_hh

#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_TrackLog;
  class maslo_TrackPoint;
  class maslo_TrackPoint
  {

    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_TrackPoint> createInstance ( int32_t                 masla_time,
                                                                 double                  masla_longitude,
                                                                 double                  masla_latitude,
                                                                 const ::SWA::Timestamp& masla_session_startTime );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_TrackPoint> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_longitude ( double value ) = 0;
      virtual void set_masla_latitude ( double value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual int32_t get_masla_time ( ) const = 0;
      virtual double get_masla_longitude ( ) const = 0;
      virtual double get_masla_latitude ( ) const = 0;
      virtual ::SWA::Timestamp get_masla_session_startTime ( ) const = 0;
      virtual int32_t get_masla_next_time ( ) const;


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_TrackPoint> > findAll ( );
      static ::SWA::ObjectPtr<maslo_TrackPoint> findOne ( );
      static ::SWA::ObjectPtr<maslo_TrackPoint> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_TrackPoint ( );
      virtual ~maslo_TrackPoint ( );


    // Prevent copy
    private:
      maslo_TrackPoint ( const maslo_TrackPoint& rhs );
      maslo_TrackPoint& operator= ( const maslo_TrackPoint& rhs );


    // Id Enumerations
    public:
      enum StateIds {};
      enum EventIds {};
      enum ServiceIds {};


    // Relationship R1.is_start_of.TrackLog
    public:
      virtual ::SWA::ObjectPtr<maslo_TrackLog> navigate_R1_is_start_of_TrackLog ( ) const = 0;
      virtual ::std::size_t count_R1_is_start_of_TrackLog ( ) const;
      virtual void link_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackLog>& rhs ) = 0;
      void checked_link_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackLog>& rhs );
      virtual void unlink_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackLog>& rhs ) = 0;
      virtual void unlink_R1_is_start_of_TrackLog ( );


    // Relationship R2.follows.TrackPoint
    public:
      virtual ::SWA::ObjectPtr<maslo_TrackPoint> navigate_R2_follows_TrackPoint ( ) const = 0;
      virtual ::std::size_t count_R2_follows_TrackPoint ( ) const;
      virtual void link_R2_follows_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs ) = 0;
      void checked_link_R2_follows_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs );
      virtual void unlink_R2_follows_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs ) = 0;
      virtual void unlink_R2_follows_TrackPoint ( );


    // Relationship R2.preceeds.TrackPoint
    public:
      virtual ::SWA::ObjectPtr<maslo_TrackPoint> navigate_R2_preceeds_TrackPoint ( ) const = 0;
      virtual ::std::size_t count_R2_preceeds_TrackPoint ( ) const;
      virtual void link_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs ) = 0;
      void checked_link_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs );
      virtual void unlink_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs ) = 0;
      virtual void unlink_R2_preceeds_TrackPoint ( );


    // Relationship R3.is_last_for.TrackLog
    public:
      virtual ::SWA::ObjectPtr<maslo_TrackLog> navigate_R3_is_last_for_TrackLog ( ) const = 0;
      virtual ::std::size_t count_R3_is_last_for_TrackLog ( ) const;
      virtual void link_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackLog>& rhs ) = 0;
      void checked_link_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackLog>& rhs );
      virtual void unlink_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackLog>& rhs ) = 0;
      virtual void unlink_R3_is_last_for_TrackLog ( );


  };
  ::std::ostream& operator<< ( ::std::ostream&         stream,
                               const maslo_TrackPoint& obj );
}
#endif // _Tracking_Track_Point_hh
