//
// File: Sqlite__Tracking__GoalSpecConstants.cc
//
#include "Sqlite__Tracking__GoalSpecConstants.hh"
#include "Sqlite__Tracking__GoalSpecConstantsPopulation.hh"
#include <stdint.h>
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_GoalSpecConstants::maslo_GoalSpecConstants ( ::SWA::IdType architectureId,
                                                       int32_t       masla_id,
                                                       int32_t       masla_GoalSpecOrigin )
      : architectureId(architectureId),
        masla_id(masla_id),
        masla_GoalSpecOrigin(masla_GoalSpecOrigin),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_GoalSpecConstants::maslo_GoalSpecConstants ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_id(),
        masla_GoalSpecOrigin(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_GoalSpecConstants::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_GoalSpecConstants::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_GoalSpecConstantsPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_GoalSpecConstants::PrimaryKeyType maslo_GoalSpecConstants::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_id );
    }

    const maslo_GoalSpecConstants::IndexKeyType_1 maslo_GoalSpecConstants::get_index_1 ( )
    {
      return IndexKeyType_1( masla_id );
    }

  }
}
