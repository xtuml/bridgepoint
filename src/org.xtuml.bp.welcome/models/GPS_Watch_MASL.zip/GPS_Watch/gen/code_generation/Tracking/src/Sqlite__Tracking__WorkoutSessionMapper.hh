//
// File: Sqlite__Tracking__WorkoutSessionMapper.hh
//
#ifndef Sqlite_Tracking_Workout_Session_Mapper_hh
#define Sqlite_Tracking_Workout_Session_Mapper_hh

#include "Sqlite__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_WorkoutSessionMapper
      : public ::SQL::ObjectMapper< ::masld_Tracking::maslo_WorkoutSession,maslo_WorkoutSession>
    {

      // Instance creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> createInstance ( const ::SWA::Timestamp& masla_startTime,
                                                                                           double                  masla_accumulatedDistance );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> instance );
      protected:
        virtual bool doPostInit ( );


      // Constructors and Destructors
      public:
        maslo_WorkoutSessionMapper ( );
        virtual ~maslo_WorkoutSessionMapper ( );


      // Attributes
      private:
        ::boost::unordered_set<maslo_WorkoutSession::PrimaryKeyType> primarykey_cache;


    };
  }
}
#endif // Sqlite_Tracking_Workout_Session_Mapper_hh
