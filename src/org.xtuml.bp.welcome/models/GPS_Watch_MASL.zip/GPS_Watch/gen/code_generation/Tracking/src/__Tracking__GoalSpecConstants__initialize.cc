//
// File: __Tracking__GoalSpecConstants__initialize.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__GoalSpecConstants.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_Tracking
{
  void maslo_GoalSpecConstants::masls_initialize ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_GoalSpecConstants, serviceId_masls_initialize);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // gsc : instance of GoalSpecConstants;
        ::SWA::ObjectPtr<maslo_GoalSpecConstants> maslv_gsc;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_gsc(0, maslv_gsc);

        // gsc := find_one GoalSpecConstants ();
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslv_gsc = findOne();
        }

        // if (null = gsc) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          if ( ::SWA::Null == maslv_gsc )
          {

            // gsc := create GoalSpecConstants (
            //            id => 1 );
            {
              ::SWA::Stack::ExecutingStatement statement(6);
              maslv_gsc = createInstance( 1ll, int32_t() );
            }

            // gsc.GoalSpecOrigin := 1;
            {
              ::SWA::Stack::ExecutingStatement statement(7);
              maslv_gsc->set_masla_GoalSpecOrigin( 1ll );
            }
          }
        }
      }
    }
  }

}
