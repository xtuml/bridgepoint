//
// File: Sqlite__Tracking__R12Mapper.hh
//
#ifndef Sqlite_Tracking_R_12_Mapper_hh
#define Sqlite_Tracking_R_12_Mapper_hh

#include "Sqlite__Tracking__Achievement.hh"
#include "Sqlite__Tracking__Goal.hh"
#include "sql/RelationshipBinaryDefinitions.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    typedef ::SQL::OneToManyRelationship<12,maslo_Goal,maslo_Achievement,false,true>::mapper_type RelationshipR12Mapper;
  }
}
#endif // Sqlite_Tracking_R_12_Mapper_hh
