//
// File: Inspector__Tracking__UI.hh
//
#ifndef Inspector_Tracking_UI_hh
#define Inspector_Tracking_UI_hh

#include "inspector/TerminatorHandler.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslb_UI
    {
      class maslb_UIHandler
        : public TerminatorHandler
      {

        // Constructors
        public:
          maslb_UIHandler ( );


      };
    }
  }
}
#endif // Inspector_Tracking_UI_hh
