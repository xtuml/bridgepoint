//
// File: Sqlite__Tracking__TrackLogMapper.cc
//
#include "Sqlite__Tracking__TrackLog.hh"
#include "Sqlite__Tracking__TrackLogMapper.hh"
#include "Sqlite__Tracking__TrackLogMapperSql.hh"
#include "__Tracking__TrackLog.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_TrackLogMapper::maslo_TrackLogMapper ( )
      : ::SQL::ObjectMapper< ::masld_Tracking::maslo_TrackLog,maslo_TrackLog>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_Tracking::maslo_TrackLog,maslo_TrackLog> >( new maslo_TrackLogSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_TrackLogMapper::~maslo_TrackLogMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> maslo_TrackLogMapper::createInstance ( const ::SWA::Timestamp& masla_session_startTime )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_TrackLog::PrimaryKeyType>::value_type( masla_session_startTime ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_TrackLog> instance(new maslo_TrackLog(  uniqueId,
                     masla_session_startTime ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_TrackLogMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> instance )
    {
      ::SQL::ObjectMapper< ::masld_Tracking::maslo_TrackLog,maslo_TrackLog>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_TrackLog>()->getPrimaryKey() );
    }

    bool maslo_TrackLogMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
