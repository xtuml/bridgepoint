//
// File: __Tracking__newGoalSpec.cc
//
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_services.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__WorkoutSession.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/Timestamp.hh"

namespace masld_Tracking
{
  void masls_newGoalSpec ( const maslt_GoalSpan&     maslp_spanType,
                           const maslt_GoalCriteria& maslp_criteriaType,
                           double                    maslp_span,
                           double                    maslp_maximum,
                           double                    maslp_minimum,
                           int32_t                   maslp_sequenceNumber )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_newGoalSpec);
      ::SWA::Stack::DeclareParameter pm_maslp_spanType(maslp_spanType);
      ::SWA::Stack::DeclareParameter pm_maslp_criteriaType(maslp_criteriaType);
      ::SWA::Stack::DeclareParameter pm_maslp_span(maslp_span);
      ::SWA::Stack::DeclareParameter pm_maslp_maximum(maslp_maximum);
      ::SWA::Stack::DeclareParameter pm_maslp_minimum(maslp_minimum);
      ::SWA::Stack::DeclareParameter pm_maslp_sequenceNumber(maslp_sequenceNumber);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(9);
      {

        // session : instance of WorkoutSession;
        ::SWA::ObjectPtr<maslo_WorkoutSession> maslv_session;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_session(0, maslv_session);

        // goalSpec : instance of GoalSpec;
        ::SWA::ObjectPtr<maslo_GoalSpec> maslv_goalSpec;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_goalSpec(1, maslv_goalSpec);

        // session := find_one WorkoutSession ();
        {
          ::SWA::Stack::ExecutingStatement statement(12);
          maslv_session = maslo_WorkoutSession::findOne();
        }

        // if (null /= session) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(13);
          if ( ::SWA::Null != maslv_session )
          {

            // goalSpec := create GoalSpec (
            //            session_startTime => session.startTime,
            //            sequenceNumber    => sequenceNumber );
            {
              ::SWA::Stack::ExecutingStatement statement(14);
              maslv_goalSpec = maslo_GoalSpec::createInstance( double(), double(), double(), maslt_GoalCriteria(), maslt_GoalSpan(), maslp_sequenceNumber, maslv_session->get_masla_startTime(), int32_t() );
            }

            // goalSpec.minimum := minimum;
            {
              ::SWA::Stack::ExecutingStatement statement(15);
              maslv_goalSpec->set_masla_minimum( maslp_minimum );
            }

            // goalSpec.maximum := maximum;
            {
              ::SWA::Stack::ExecutingStatement statement(16);
              maslv_goalSpec->set_masla_maximum( maslp_maximum );
            }

            // goalSpec.span := span;
            {
              ::SWA::Stack::ExecutingStatement statement(17);
              maslv_goalSpec->set_masla_span( maslp_span );
            }

            // goalSpec.criteriaType := criteriaType;
            {
              ::SWA::Stack::ExecutingStatement statement(18);
              maslv_goalSpec->set_masla_criteriaType( maslp_criteriaType );
            }

            // goalSpec.spanType := spanType;
            {
              ::SWA::Stack::ExecutingStatement statement(19);
              maslv_goalSpec->set_masla_spanType( maslp_spanType );
            }

            // goalSpec.last_goal_ID := 0;
            {
              ::SWA::Stack::ExecutingStatement statement(20);
              maslv_goalSpec->set_masla_last_goal_ID( 0ll );
            }

            // link goalSpec R10.included_in.WorkoutSession  session;
            {
              ::SWA::Stack::ExecutingStatement statement(21);
              maslv_goalSpec->checked_link_R10_included_in_WorkoutSession( maslv_session );
            }
          }
        }
      }
    }
  }

  const bool localServiceRegistration_masls_newGoalSpec = interceptor_masls_newGoalSpec::instance().registerLocal( &masls_newGoalSpec );

}
