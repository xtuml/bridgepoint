//
// File: __Tracking__TrackLogPopulation.hh
//
#ifndef _Tracking_Track_Log_Population_hh
#define _Tracking_Track_Log_Population_hh

#include <cstddef>
#include "swa/DynamicSingleton.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_TrackLog;
  class maslo_TrackLogPopulation
    : public ::SWA::DynamicSingleton<maslo_TrackLogPopulation>
  {

    // Instance Creation
    public:
      virtual ::SWA::IdType getNextArchId ( ) = 0;
      virtual ::SWA::ObjectPtr<maslo_TrackLog> createInstance ( const ::SWA::Timestamp& masla_session_startTime ) = 0;
      virtual void deleteInstance ( ::SWA::ObjectPtr<maslo_TrackLog> instance ) = 0;
      virtual ::std::size_t size ( ) const = 0;


    // Instance Retrieval
    public:
      virtual ::SWA::ObjectPtr<maslo_TrackLog> getInstance ( ::SWA::IdType id ) const = 0;
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_TrackLog> > findAll ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_TrackLog> findOne ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_TrackLog> findOnly ( ) const = 0;


    // Constructors and Destructors
    protected:
      maslo_TrackLogPopulation ( );
      virtual ~maslo_TrackLogPopulation ( );


    // Prevent copy
    private:
      maslo_TrackLogPopulation ( const maslo_TrackLogPopulation& rhs );
      maslo_TrackLogPopulation& operator= ( const maslo_TrackLogPopulation& rhs );


  };
}
#endif // _Tracking_Track_Log_Population_hh
