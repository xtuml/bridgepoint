//
// File: __Tracking__WorkoutSession__clearHeartRateSamples.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__HeartRateSample.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/bind.hpp"
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Stack.hh"
#include "swa/navigate.hh"

namespace masld_Tracking
{
  void maslo_WorkoutSession::masls_clearHeartRateSamples ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_WorkoutSession, serviceId_masls_clearHeartRateSamples);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // samples : set of instance of HeartRateSample;
        ::SWA::Set< ::SWA::ObjectPtr<maslo_HeartRateSample> > maslv_samples;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_samples(0, maslv_samples);

        // samples := this -> R6.tracks_heart_rate_over_time_as.HeartRateSample;
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslv_samples = ::SWA::navigate_many<maslo_HeartRateSample>( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), ::boost::bind( &maslo_WorkoutSession::navigate_R6_tracks_heart_rate_over_time_as_HeartRateSample, _1 ) );
        }

        // for sample in samples'elements loop ...
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          ::SWA::Set< ::SWA::ObjectPtr<maslo_HeartRateSample> > collection = maslv_samples;
          for ( ::SWA::Set< ::SWA::ObjectPtr<maslo_HeartRateSample> >::const_iterator i = collection.begin(); i != collection.end(); ++i )
          {
            const ::SWA::ObjectPtr<maslo_HeartRateSample>& maslv_sample = *i;
            ::SWA::Stack::DeclareLocalVariable pm_maslv_sample(1, maslv_sample);

            // unlink this R6.tracks_heart_rate_over_time_as.HeartRateSample  sample;
            {
              ::SWA::Stack::ExecutingStatement statement(6);
              ::SWA::ObjectPtr<maslo_WorkoutSession>( this )->unlink_R6_tracks_heart_rate_over_time_as_HeartRateSample( maslv_sample );
            }

            // delete sample;
            {
              ::SWA::Stack::ExecutingStatement statement(7);
              maslv_sample.deleteInstance();
            }
          }
        }
      }
    }
  }

}
