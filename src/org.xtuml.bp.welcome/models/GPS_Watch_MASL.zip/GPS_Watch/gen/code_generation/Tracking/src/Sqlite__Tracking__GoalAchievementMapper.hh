//
// File: Sqlite__Tracking__GoalAchievementMapper.hh
//
#ifndef Sqlite_Tracking_Goal_Achievement_Mapper_hh
#define Sqlite_Tracking_Goal_Achievement_Mapper_hh

#include "Sqlite__Tracking__GoalAchievement.hh"
#include "__Tracking__GoalAchievement.hh"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_GoalAchievementMapper
      : public ::SQL::ObjectMapper< ::masld_Tracking::maslo_GoalAchievement,maslo_GoalAchievement>
    {

      // Instance creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> createInstance ( int32_t masla_id,
                                                                                            int32_t masla_evaluationPeriod );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> instance );
      protected:
        virtual bool doPostInit ( );


      // Constructors and Destructors
      public:
        maslo_GoalAchievementMapper ( );
        virtual ~maslo_GoalAchievementMapper ( );


      // Attributes
      private:
        ::boost::unordered_set<maslo_GoalAchievement::PrimaryKeyType> primarykey_cache;


    };
  }
}
#endif // Sqlite_Tracking_Goal_Achievement_Mapper_hh
