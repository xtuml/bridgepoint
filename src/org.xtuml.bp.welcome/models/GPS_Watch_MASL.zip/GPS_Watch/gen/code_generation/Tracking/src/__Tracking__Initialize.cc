//
// File: __Tracking__Initialize.cc
//
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking_private_services.hh"
#include "swa/Domain.hh"
#include "swa/Stack.hh"

namespace masld_Tracking
{
  void masls_Initialize ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_Initialize);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // WorkoutSession.initialize()
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslo_WorkoutSession::masls_initialize();
        }
      }
    }
  }

  const bool localServiceRegistration_masls_Initialize = interceptor_masls_Initialize::instance().registerLocal( &masls_Initialize );

}
