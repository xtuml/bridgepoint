//
// File: Inspector__Tracking__GoalSpec.cc
//
#include "Inspector__Tracking__GoalSpec.hh"
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/lexical_cast.hpp"
#include <cstddef>
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/ObjectHandler.hh"
#include "inspector/ProcessHandler.hh"
#include <stdint.h>
#include <string>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_GoalSpec
    {
      maslo_GoalSpecHandler::maslo_GoalSpecHandler ( )
      {
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslo_GoalSpec> ( const ::masld_Tracking::maslo_GoalSpec& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_minimum() );
    write( instance.get_masla_maximum() );
    write( instance.get_masla_span() );
    write( instance.get_masla_criteriaType() );
    write( instance.get_masla_spanType() );
    write( instance.get_masla_sequenceNumber() );
    write( instance.get_masla_session_startTime() );
    write( instance.get_masla_last_goal_ID() );
    write<int>( instance.count_R9_specifies_Goal() );
    write( instance.navigate_R10_included_in_WorkoutSession() );
  }

  namespace masld_Tracking
  {
    namespace maslo_GoalSpec
    {
      void maslo_GoalSpecHandler::createInstance ( CommunicationChannel& channel ) const
      {
        double masla_minimum;
        double masla_maximum;
        double masla_span;
        ::masld_Tracking::maslt_GoalCriteria masla_criteriaType;
        ::masld_Tracking::maslt_GoalSpan masla_spanType;
        int32_t masla_sequenceNumber;
        ::SWA::Timestamp masla_session_startTime;
        int32_t masla_last_goal_ID;
        channel >> masla_minimum >> masla_maximum >> masla_span >> masla_criteriaType >> masla_spanType >> masla_sequenceNumber >> masla_session_startTime >> masla_last_goal_ID;
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> instance = ::masld_Tracking::maslo_GoalSpec::createInstance( masla_minimum, masla_maximum, masla_span, masla_criteriaType, masla_spanType, masla_sequenceNumber, masla_session_startTime, masla_last_goal_ID );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_GoalSpecHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_sequenceNumber() ) + "," + ::boost::lexical_cast< ::std::string>( instance->get_masla_session_startTime() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> > ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_Tracking::maslo_GoalSpec::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_Tracking
  {
    namespace maslo_GoalSpec
    {
      void maslo_GoalSpecHandler::writeRelatedInstances ( CommunicationChannel&                               channel,
                                                          ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> instance,
                                                          int                                                 relId ) const
      {
        switch ( relId )
        {
          case 0:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_Goal>( ::masld_Tracking::objectId_maslo_Goal ).writeInstances( channel, instance ? instance->navigate_R9_specifies_Goal()
                                                                                                                                                                                                                               : ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> >() );
            break;

          case 1:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_WorkoutSession>( ::masld_Tracking::objectId_maslo_WorkoutSession ).writeInstances( channel, instance ? instance->navigate_R10_included_in_WorkoutSession()
                                                                                                                                                                                                                                                   : ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>() );
            break;

        }

      }

    }
  }
}
