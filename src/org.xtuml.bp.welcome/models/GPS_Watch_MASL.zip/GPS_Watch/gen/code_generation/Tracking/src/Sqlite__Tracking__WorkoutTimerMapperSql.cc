//
// File: Sqlite__Tracking__WorkoutTimerMapperSql.cc
//
#include "Sqlite__Tracking__WorkoutTimer.hh"
#include "Sqlite__Tracking__WorkoutTimerMapperSql.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/shared_ptr.hpp"
#include "boost/tuple/tuple_comparison.hpp"
#include <map>
#include "sql/Criteria.hh"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/Schema.hh"
#include "sql/Util.hh"
#include "sqlite/Database.hh"
#include "sqlite/Exception.hh"
#include "sqlite/Resultset.hh"
#include "sqlite/SqlMonitor.hh"
#include "sqlite3.h"
#include <stdint.h>
#include <string>
#include "swa/EventTimers.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace 
{
  const ::std::string createTableStatment ( )
  {
    return "CREATE TABLE S_Tracking_WORKOUTTIMER(   architecture_id  INTEGER ,   masla_time INTEGER,   masla_timer INTEGER,   masla_session_startTime INTEGER,   CurrentState INTEGER, PRIMARY KEY (architecture_id));\n";
  }

  bool registerSchema = ::SQL::Schema::singleton().registerTable( "S_Tracking_WORKOUTTIMER", createTableStatment() );

}
namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_WorkoutTimerSqlGenerator::maslo_WorkoutTimerSqlGenerator ( )
      : tableName("S_Tracking_WORKOUTTIMER"),
        objectName("WorkoutTimer"),
        insertStatement("INSERT INTO S_Tracking_WORKOUTTIMER VALUES(:1,:2,:3,:4,:5);"),
        updateStatement("UPDATE S_Tracking_WORKOUTTIMER SET masla_time = :2  , masla_timer = :3  , masla_session_startTime = :4  , CurrentState = :5  WHERE architecture_id = :1;"),
        deleteStatement("DELETE  FROM S_Tracking_WORKOUTTIMER WHERE architecture_id = :1;"),
        columnNameMapper()
    {
    }

    maslo_WorkoutTimerSqlGenerator::~maslo_WorkoutTimerSqlGenerator ( )
    {
    }

    void maslo_WorkoutTimerSqlGenerator::initialise ( )
    {
      columnNameMapper["architecture_id"] = ::std::string( "architecture_id" );
      columnNameMapper["time"] = ::std::string( "masla_time" );
      columnNameMapper["timer"] = ::std::string( "masla_timer" );
      columnNameMapper["session_startTime"] = ::std::string( "masla_session_startTime" );
      columnNameMapper["CurrentState"] = ::std::string( "CurrentState" );
      insertStatement.prepare();
      updateStatement.prepare();
      deleteStatement.prepare();
    }

    const ::std::string maslo_WorkoutTimerSqlGenerator::getDomainName ( ) const
    {
      return "Tracking";
    }

    const ::std::string& maslo_WorkoutTimerSqlGenerator::getTableName ( ) const
    {
      return tableName;
    }

    const ::std::string& maslo_WorkoutTimerSqlGenerator::getObjectName ( ) const
    {
      return objectName;
    }

    const ::std::string maslo_WorkoutTimerSqlGenerator::getColumnName ( const ::std::string& attribute ) const
    {
      ::std::map< ::std::string,::std::string>::const_iterator requiredNameItr = columnNameMapper.find( attribute );
      if ( requiredNameItr == columnNameMapper.end() )
      {
        throw SqliteException( "maslo_WorkoutTimerSqlGenerator::getColumnName - failed to find attribute name " );
      }
      return requiredNameItr->second;
    }

    void maslo_WorkoutTimerSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                    int32_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_Tracking_WORKOUTTIMER;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_WorkoutTimerSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_WorkoutTimerSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    void maslo_WorkoutTimerSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                    int64_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_Tracking_WORKOUTTIMER;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_WorkoutTimerSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int64_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_WorkoutTimerSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    ::SWA::IdType maslo_WorkoutTimerSqlGenerator::executeGetRowCount ( ) const
    {
      int32_t rowCount = 0;
      ::std::string valueSelect("SELECT count(*) FROM S_Tracking_WORKOUTTIMER;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_WorkoutTimerSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          rowCount = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_WorkoutTimerSqlGenerator::executeGetRowCount - query failed" );
      }
      return rowCount;
    }

    ::SWA::IdType maslo_WorkoutTimerSqlGenerator::executeGetMaxIdentifier ( ) const
    {
      ::SWA::IdType maxIdValue = 0;
      executeGetMaxColumnValue( "architecture_id", maxIdValue );
      return maxIdValue;
    }

    void maslo_WorkoutTimerSqlGenerator::executeUpdate ( const PsObjectPtr& object ) const
    {
      updateStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_time(), object.getChecked()->get_masla_timer(), object.getChecked()->get_masla_session_startTime(), object->getCurrentState() ) );
    }

    void maslo_WorkoutTimerSqlGenerator::executeInsert ( const PsObjectPtr& object ) const
    {
      insertStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_time(), object.getChecked()->get_masla_timer(), object.getChecked()->get_masla_session_startTime(), object->getCurrentState() ) );
    }

    void maslo_WorkoutTimerSqlGenerator::executeRemove ( const PsObjectPtr& object ) const
    {
      deleteStatement.execute( object.getChecked()->getArchitectureId() );
    }

    void maslo_WorkoutTimerSqlGenerator::executeRemoveId ( const ::SWA::IdType object ) const
    {
      deleteStatement.execute( object );
    }

    void maslo_WorkoutTimerSqlGenerator::executeSelect ( CacheType&             cache,
                                                         const ::SQL::Criteria& criteria,
                                                         PsBaseObjectPtrSwaSet& result ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("WorkoutTimer::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "WorkoutTimer::executeSelect", compile_result, query );
        database.checkColumnCount( "WorkoutTimer::executeSelect", sqlite3_column_count( ppStmt ), 5, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr != cache.end() )
          {
            PsBaseObjectPtr currentObject(objectItr->second.get());
            result += currentObject;
          }
          else
          {
            PsObjectPtr currentObject(new maslo_WorkoutTimer(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );
            result += currentObject;

            int32_t time = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_time( time );

            int32_t timer = sqlite3_column_int( ppStmt, 2 );
            currentObject->set_masla_timer( timer );

            ::SWA::Timestamp session_startTime = ::SWA::Timestamp::fromNanosSinceEpoch( sqlite3_column_int64( ppStmt, 3 ) );
            currentObject->set_masla_session_startTime( session_startTime );

            int32_t currentState = sqlite3_column_int( ppStmt, 4 );
            currentObject->setCurrentState( static_cast< ::masld_Tracking::maslo_WorkoutTimer::Type>( currentState ) );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

    void maslo_WorkoutTimerSqlGenerator::executeSelect ( CacheType&             cache,
                                                         const ::SQL::Criteria& criteria ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("WorkoutTimer::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "WorkoutTimer::executeSelect", compile_result, query );
        database.checkColumnCount( "WorkoutTimer::executeSelect", sqlite3_column_count( ppStmt ), 5, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr == cache.end() )
          {
            PsObjectPtr currentObject(new maslo_WorkoutTimer(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );

            int32_t time = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_time( time );

            int32_t timer = sqlite3_column_int( ppStmt, 2 );
            currentObject->set_masla_timer( timer );

            ::SWA::Timestamp session_startTime = ::SWA::Timestamp::fromNanosSinceEpoch( sqlite3_column_int64( ppStmt, 3 ) );
            currentObject->set_masla_session_startTime( session_startTime );

            int32_t currentState = sqlite3_column_int( ppStmt, 4 );
            currentObject->setCurrentState( static_cast< ::masld_Tracking::maslo_WorkoutTimer::Type>( currentState ) );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

  }
}
