//
// File: Transient__Tracking__WorkoutSessionPopulation.hh
//
#ifndef Transient_Tracking_Workout_Session_Population_hh
#define Transient_Tracking_Workout_Session_Population_hh

#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutSessionPopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace transient
{
  namespace masld_Tracking
  {
    class maslo_WorkoutSessionPopulation
      : public TransientPopulation< ::masld_Tracking::maslo_WorkoutSession,::masld_Tracking::maslo_WorkoutSessionPopulation>
    {

      // Instance Creation
      private:
        maslo_WorkoutSessionPopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> createInstance ( const ::SWA::Timestamp& masla_startTime,
                                                                                           double                  masla_accumulatedDistance );


      // Singleton Registration
      public:
        static maslo_WorkoutSessionPopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple< ::SWA::Timestamp>,::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> > masla_startTime_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> instance );
      protected:
        bool exists_masla_startTime ( const ::SWA::Timestamp& masla_startTime ) const;


    };
  }
}
#endif // Transient_Tracking_Workout_Session_Population_hh
