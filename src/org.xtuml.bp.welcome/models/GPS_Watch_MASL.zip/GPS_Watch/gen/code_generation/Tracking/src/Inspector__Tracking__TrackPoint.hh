//
// File: Inspector__Tracking__TrackPoint.hh
//
#ifndef Inspector_Tracking_Track_Point_hh
#define Inspector_Tracking_Track_Point_hh

#include "__Tracking__TrackPoint.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_TrackPoint
    {
      class maslo_TrackPointHandler
        : public ObjectHandler< ::masld_Tracking::maslo_TrackPoint>
      {

        // Constructors
        public:
          maslo_TrackPointHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                                 channel,
                                       ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> instance,
                                       int                                                   relId ) const;


      };
    }
  }
}
#endif // Inspector_Tracking_Track_Point_hh
