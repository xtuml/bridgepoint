//
// File: __Tracking__TrackPointPopulation.hh
//
#ifndef _Tracking_Track_Point_Population_hh
#define _Tracking_Track_Point_Population_hh

#include <cstddef>
#include <stdint.h>
#include "swa/DynamicSingleton.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_TrackPoint;
  class maslo_TrackPointPopulation
    : public ::SWA::DynamicSingleton<maslo_TrackPointPopulation>
  {

    // Instance Creation
    public:
      virtual ::SWA::IdType getNextArchId ( ) = 0;
      virtual ::SWA::ObjectPtr<maslo_TrackPoint> createInstance ( int32_t                 masla_time,
                                                                  double                  masla_longitude,
                                                                  double                  masla_latitude,
                                                                  const ::SWA::Timestamp& masla_session_startTime ) = 0;
      virtual void deleteInstance ( ::SWA::ObjectPtr<maslo_TrackPoint> instance ) = 0;
      virtual ::std::size_t size ( ) const = 0;


    // Instance Retrieval
    public:
      virtual ::SWA::ObjectPtr<maslo_TrackPoint> getInstance ( ::SWA::IdType id ) const = 0;
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_TrackPoint> > findAll ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_TrackPoint> findOne ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_TrackPoint> findOnly ( ) const = 0;


    // Constructors and Destructors
    protected:
      maslo_TrackPointPopulation ( );
      virtual ~maslo_TrackPointPopulation ( );


    // Prevent copy
    private:
      maslo_TrackPointPopulation ( const maslo_TrackPointPopulation& rhs );
      maslo_TrackPointPopulation& operator= ( const maslo_TrackPointPopulation& rhs );


  };
}
#endif // _Tracking_Track_Point_Population_hh
