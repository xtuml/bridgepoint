//
// File: Sqlite__Tracking__TrackPointPopulation.hh
//
#ifndef Sqlite_Tracking_Track_Point_Population_hh
#define Sqlite_Tracking_Track_Point_Population_hh

#include "Sqlite__Tracking__R1Mapper.hh"
#include "Sqlite__Tracking__R2Mapper.hh"
#include "Sqlite__Tracking__R3Mapper.hh"
#include "Sqlite__Tracking__TrackPoint.hh"
#include "Sqlite__Tracking__TrackPointMapper.hh"
#include "__Tracking__TrackPoint.hh"
#include "__Tracking__TrackPointPopulation.hh"
#include "boost/signals2.hpp"
#include <cstddef>
#include "sql/Population.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_TrackLog;
  }
}
namespace masld_Tracking
{
  class maslo_TrackLog;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_TrackPointPopulation
      : public ::SQL::SqlPopulation< ::masld_Tracking::maslo_TrackPoint,maslo_TrackPoint,maslo_TrackPointMapper,::masld_Tracking::maslo_TrackPointPopulation>
    {

      // Constructors and Destructors
      private:
        maslo_TrackPointPopulation ( );
        ~maslo_TrackPointPopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> createInstance ( int32_t                 masla_time,
                                                                                       double                  masla_longitude,
                                                                                       double                  masla_latitude,
                                                                                       const ::SWA::Timestamp& masla_session_startTime );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> instance );


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Relationship Counts
      public:
        ::std::size_t count_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs );
        ::std::size_t count_R2_follows_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs );
        ::std::size_t count_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs );
        ::std::size_t count_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs );


      // Relationship Links
      public:
        void link_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs,
                                            const ::SWA::ObjectPtr<maslo_TrackLog>&   rhs );
        void unlink_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs,
                                              const ::SWA::ObjectPtr<maslo_TrackLog>&   rhs );
        void link_R2_follows_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs,
                                          const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs );
        void unlink_R2_follows_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs,
                                            const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs );
        void link_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs,
                                           const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs );
        void unlink_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs,
                                             const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs );
        void link_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs,
                                            const ::SWA::ObjectPtr<maslo_TrackLog>&   rhs );
        void unlink_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs,
                                              const ::SWA::ObjectPtr<maslo_TrackLog>&   rhs );


      // Relationship Navigations
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> navigate_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs );
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> navigate_R2_follows_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs );
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> navigate_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs );
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> navigate_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackPoint>& lhs );


      // Singleton Registration
      public:
        static maslo_TrackPointPopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;
        RelationshipR1Mapper& R1Mapper;
        RelationshipR2Mapper& R2Mapper;
        RelationshipR3Mapper& R3Mapper;


    };
  }
}
#endif // Sqlite_Tracking_Track_Point_Population_hh
