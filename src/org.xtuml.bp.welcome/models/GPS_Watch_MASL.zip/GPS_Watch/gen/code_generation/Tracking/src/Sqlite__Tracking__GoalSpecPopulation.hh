//
// File: Sqlite__Tracking__GoalSpecPopulation.hh
//
#ifndef Sqlite_Tracking_Goal_Spec_Population_hh
#define Sqlite_Tracking_Goal_Spec_Population_hh

#include "Sqlite__Tracking__GoalSpec.hh"
#include "Sqlite__Tracking__GoalSpecMapper.hh"
#include "Sqlite__Tracking__R10Mapper.hh"
#include "Sqlite__Tracking__R9Mapper.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__GoalSpecPopulation.hh"
#include "boost/signals2.hpp"
#include <cstddef>
#include "sql/Population.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslt_GoalCriteria;
  class maslt_GoalSpan;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_Goal;
  }
  namespace masld_Tracking
  {
    class maslo_WorkoutSession;
  }
}
namespace masld_Tracking
{
  class maslo_Goal;
  class maslo_WorkoutSession;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_GoalSpecPopulation
      : public ::SQL::SqlPopulation< ::masld_Tracking::maslo_GoalSpec,maslo_GoalSpec,maslo_GoalSpecMapper,::masld_Tracking::maslo_GoalSpecPopulation>
    {

      // Constructors and Destructors
      private:
        maslo_GoalSpecPopulation ( );
        ~maslo_GoalSpecPopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> createInstance ( double                                      masla_minimum,
                                                                                     double                                      masla_maximum,
                                                                                     double                                      masla_span,
                                                                                     const ::masld_Tracking::maslt_GoalCriteria& masla_criteriaType,
                                                                                     const ::masld_Tracking::maslt_GoalSpan&     masla_spanType,
                                                                                     int32_t                                     masla_sequenceNumber,
                                                                                     const ::SWA::Timestamp&                     masla_session_startTime,
                                                                                     int32_t                                     masla_last_goal_ID );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> instance );


      // Find Routines
      public:
        // MASL find: (sequenceNumber = p1)
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> findOne_OPmasl_sequenceNumber_maslEQp1CP ( int32_t p1 ) const;


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Relationship Counts
      public:
        ::std::size_t count_R9_specifies_Goal ( const ::SWA::ObjectPtr<maslo_GoalSpec>& lhs );
        ::std::size_t count_R10_included_in_WorkoutSession ( const ::SWA::ObjectPtr<maslo_GoalSpec>& lhs );


      // Relationship Links
      public:
        void link_R9_specifies_Goal ( const ::SWA::ObjectPtr<maslo_GoalSpec>& lhs,
                                      const ::SWA::ObjectPtr<maslo_Goal>&     rhs );
        void unlink_R9_specifies_Goal ( const ::SWA::ObjectPtr<maslo_GoalSpec>& lhs,
                                        const ::SWA::ObjectPtr<maslo_Goal>&     rhs );
        void link_R10_included_in_WorkoutSession ( const ::SWA::ObjectPtr<maslo_GoalSpec>&       lhs,
                                                   const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs );
        void unlink_R10_included_in_WorkoutSession ( const ::SWA::ObjectPtr<maslo_GoalSpec>&       lhs,
                                                     const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs );


      // Relationship Navigations
      public:
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> > navigate_R9_specifies_Goal ( const ::SWA::ObjectPtr<maslo_GoalSpec>& lhs );
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> navigate_R10_included_in_WorkoutSession ( const ::SWA::ObjectPtr<maslo_GoalSpec>& lhs );


      // Singleton Registration
      public:
        static maslo_GoalSpecPopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;
        RelationshipR9Mapper& R9Mapper;
        RelationshipR10Mapper& R10Mapper;


    };
  }
}
#endif // Sqlite_Tracking_Goal_Spec_Population_hh
