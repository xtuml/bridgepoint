//
// File: __Tracking__setTargetPressed.cc
//
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_services.hh"
#include "__Tracking__Goal.hh"
#include "swa/Domain.hh"
#include "swa/Stack.hh"

namespace masld_Tracking
{
  void masls_setTargetPressed ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_setTargetPressed);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // Goal.nextGoal()
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          maslo_Goal::masls_nextGoal();
        }
      }
    }
  }

  const bool localServiceRegistration_masls_setTargetPressed = interceptor_masls_setTargetPressed::instance().registerLocal( &masls_setTargetPressed );

}
