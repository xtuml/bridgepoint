//
// File: Transient__Tracking__WorkoutTimerConstants.cc
//
#include "Transient__Tracking__WorkoutTimerConstants.hh"
#include <stdint.h>

namespace transient
{
  namespace masld_Tracking
  {
    maslo_WorkoutTimerConstants::maslo_WorkoutTimerConstants ( int32_t masla_id,
                                                               int32_t masla_timerPeriod )
      : architectureId(getNextArchId()),
        masla_id(masla_id),
        masla_timerPeriod(masla_timerPeriod)
    {
    }

  }
}
