//
// File: Sqlite__Tracking__WorkoutSession.hh
//
#ifndef Sqlite_Tracking_Workout_Session_hh
#define Sqlite_Tracking_Workout_Session_hh

#include "__Tracking__WorkoutSession.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <cstddef>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_Display;
  class maslo_WorkoutTimer;
  class maslo_TrackLog;
  class maslo_HeartRateSample;
  class maslo_GoalSpec;
  class maslo_Goal;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_WorkoutSession
      : public ::masld_Tracking::maslo_WorkoutSession
    {

      // Type definitions
      public:
        typedef ::boost::tuple< ::SWA::Timestamp> PrimaryKeyType;
        typedef ::boost::tuple< ::SWA::Timestamp> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_WorkoutSession ( ::SWA::IdType architectureId );
        maslo_WorkoutSession ( ::SWA::IdType           architectureId,
                               const ::SWA::Timestamp& masla_startTime,
                               double                  masla_accumulatedDistance );


      // Setters for each object attribute
      public:
        void set_masla_startTime ( const ::SWA::Timestamp& value )
        {
          this->masla_startTime = value;
          markAsModified();
        }
        virtual void set_masla_accumulatedDistance ( double value )
        {
          this->masla_accumulatedDistance = value;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual ::SWA::Timestamp get_masla_startTime ( ) const { return masla_startTime; }
        virtual double get_masla_accumulatedDistance ( ) const { return masla_accumulatedDistance; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Relationship Navigators
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> navigate_R7_current_status_indicated_on_Display ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> navigate_R8_is_timed_by_WorkoutTimer ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> navigate_R4_captures_path_in_TrackLog ( ) const;
        virtual ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> > navigate_R6_tracks_heart_rate_over_time_as_HeartRateSample ( ) const;
        virtual ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> > navigate_R10_includes_GoalSpec ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> navigate_R11_is_currently_executing_Goal ( ) const;
        virtual ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> > navigate_R13_has_executed_Goal ( ) const;


      // Relationship Counts
      public:
        virtual ::std::size_t count_R7_current_status_indicated_on_Display ( ) const;
        virtual ::std::size_t count_R8_is_timed_by_WorkoutTimer ( ) const;
        virtual ::std::size_t count_R4_captures_path_in_TrackLog ( ) const;
        virtual ::std::size_t count_R6_tracks_heart_rate_over_time_as_HeartRateSample ( ) const;
        virtual ::std::size_t count_R10_includes_GoalSpec ( ) const;
        virtual ::std::size_t count_R11_is_currently_executing_Goal ( ) const;
        virtual ::std::size_t count_R13_has_executed_Goal ( ) const;


      // Relationship Linkers
      public:
        virtual void link_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display>& rhs );
        virtual void unlink_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display>& rhs );
        virtual void link_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>& rhs );
        virtual void unlink_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>& rhs );
        virtual void link_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs );
        virtual void unlink_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs );
        virtual void link_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample>& rhs );
        virtual void unlink_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample>& rhs );
        virtual void link_R10_includes_GoalSpec ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& rhs );
        virtual void unlink_R10_includes_GoalSpec ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& rhs );
        virtual void link_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs );
        virtual void unlink_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs );
        virtual void link_R13_has_executed_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs );
        virtual void unlink_R13_has_executed_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        ::SWA::Timestamp masla_startTime;
        double masla_accumulatedDistance;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_Tracking_Workout_Session_hh
