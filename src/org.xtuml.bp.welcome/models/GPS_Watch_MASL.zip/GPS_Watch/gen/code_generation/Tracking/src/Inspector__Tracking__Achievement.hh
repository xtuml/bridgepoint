//
// File: Inspector__Tracking__Achievement.hh
//
#ifndef Inspector_Tracking_Achievement_hh
#define Inspector_Tracking_Achievement_hh

#include "__Tracking__Achievement.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_Achievement
    {
      class maslo_AchievementHandler
        : public ObjectHandler< ::masld_Tracking::maslo_Achievement>
      {

        // Constructors
        public:
          maslo_AchievementHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                                  channel,
                                       ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> instance,
                                       int                                                    relId ) const;


      };
    }
  }
}
#endif // Inspector_Tracking_Achievement_hh
