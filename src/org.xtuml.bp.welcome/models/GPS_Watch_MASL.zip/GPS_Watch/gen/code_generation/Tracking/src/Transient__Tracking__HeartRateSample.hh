//
// File: Transient__Tracking__HeartRateSample.hh
//
#ifndef Transient_Tracking_Heart_Rate_Sample_hh
#define Transient_Tracking_Heart_Rate_Sample_hh

#include "__Tracking__HeartRateSample.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"
#include "transient/ToOneRelationship.hh"

namespace masld_Tracking
{
  class maslo_WorkoutSession;
}
namespace transient
{
  namespace masld_Tracking
  {
    class maslo_WorkoutSession;
  }
  namespace masld_Tracking
  {
    class maslo_HeartRateSample
      : public ::masld_Tracking::maslo_HeartRateSample
    {

      // Constructors and Destructors
      public:
        maslo_HeartRateSample ( int32_t                 masla_heartRate,
                                int32_t                 masla_time,
                                const ::SWA::Timestamp& masla_session_startTime );


      // Setters for each object attribute
      public:
        virtual void set_masla_heartRate ( int32_t value ) { this->masla_heartRate = value; }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_heartRate ( ) const { return masla_heartRate; }
        virtual int32_t get_masla_time ( ) const { return masla_time; }
        virtual ::SWA::Timestamp get_masla_session_startTime ( ) const { return masla_session_startTime; }


      // Relationship Navigators
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> navigate_R6_was_collected_during_WorkoutSession ( ) const;


      // Relationship Counters
      public:
        virtual ::std::size_t count_R6_was_collected_during_WorkoutSession ( ) const;


      // Relationship Linkers
      public:
        virtual void link_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );
        virtual void unlink_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_heartRate;
        int32_t masla_time;
        ::SWA::Timestamp masla_session_startTime;


      // Relationship Getters
      public:
        ToOneRelationship<maslo_WorkoutSession>& get_R6_was_collected_during_WorkoutSession ( );
        const ToOneRelationship<maslo_WorkoutSession>& get_R6_was_collected_during_WorkoutSession ( ) const;


      // Storage for each relationship
      private:
        ToOneRelationship<maslo_WorkoutSession> R6_was_collected_during_WorkoutSession;


    };
  }
}
#endif // Transient_Tracking_Heart_Rate_Sample_hh
