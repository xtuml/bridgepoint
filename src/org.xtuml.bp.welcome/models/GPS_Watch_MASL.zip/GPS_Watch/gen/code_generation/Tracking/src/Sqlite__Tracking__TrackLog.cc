//
// File: Sqlite__Tracking__TrackLog.cc
//
#include "Sqlite__Tracking__LapMarker.hh"
#include "Sqlite__Tracking__TrackLog.hh"
#include "Sqlite__Tracking__TrackLogPopulation.hh"
#include "Sqlite__Tracking__TrackPoint.hh"
#include "Sqlite__Tracking__WorkoutSession.hh"
#include "__Tracking__LapMarker.hh"
#include "__Tracking__TrackPoint.hh"
#include "__Tracking__WorkoutSession.hh"
#include <cstddef>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_TrackLog::maslo_TrackLog ( ::SWA::IdType           architectureId,
                                     const ::SWA::Timestamp& masla_session_startTime )
      : architectureId(architectureId),
        masla_session_startTime(masla_session_startTime),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_TrackLog::maslo_TrackLog ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_session_startTime(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_TrackLog::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_TrackLog::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_TrackLogPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_TrackLog::PrimaryKeyType maslo_TrackLog::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_session_startTime );
    }

    const maslo_TrackLog::IndexKeyType_1 maslo_TrackLog::get_index_1 ( )
    {
      return IndexKeyType_1( masla_session_startTime );
    }

    void maslo_TrackLog::link_R1_has_first_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> derivedrhs(rhs.downcast<maslo_TrackPoint>());
      maslo_TrackLogPopulation::getPopulation().link_R1_has_first_TrackPoint( ::SWA::ObjectPtr<maslo_TrackLog>( this ), derivedrhs );
    }

    void maslo_TrackLog::unlink_R1_has_first_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> derivedrhs(rhs.downcast<maslo_TrackPoint>());
      maslo_TrackLogPopulation::getPopulation().unlink_R1_has_first_TrackPoint( ::SWA::ObjectPtr<maslo_TrackLog>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> maslo_TrackLog::navigate_R1_has_first_TrackPoint ( ) const
    {
      ::SWA::ObjectPtr<maslo_TrackLog> self(const_cast<maslo_TrackLog*>( this ));
      return maslo_TrackLogPopulation::getPopulation().navigate_R1_has_first_TrackPoint( self );
    }

    ::std::size_t maslo_TrackLog::count_R1_has_first_TrackPoint ( ) const
    {
      ::SWA::ObjectPtr<maslo_TrackLog> self(const_cast<maslo_TrackLog*>( this ));
      return maslo_TrackLogPopulation::getPopulation().count_R1_has_first_TrackPoint( self );
    }

    void maslo_TrackLog::link_R3_has_last_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> derivedrhs(rhs.downcast<maslo_TrackPoint>());
      maslo_TrackLogPopulation::getPopulation().link_R3_has_last_TrackPoint( ::SWA::ObjectPtr<maslo_TrackLog>( this ), derivedrhs );
    }

    void maslo_TrackLog::unlink_R3_has_last_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> derivedrhs(rhs.downcast<maslo_TrackPoint>());
      maslo_TrackLogPopulation::getPopulation().unlink_R3_has_last_TrackPoint( ::SWA::ObjectPtr<maslo_TrackLog>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> maslo_TrackLog::navigate_R3_has_last_TrackPoint ( ) const
    {
      ::SWA::ObjectPtr<maslo_TrackLog> self(const_cast<maslo_TrackLog*>( this ));
      return maslo_TrackLogPopulation::getPopulation().navigate_R3_has_last_TrackPoint( self );
    }

    ::std::size_t maslo_TrackLog::count_R3_has_last_TrackPoint ( ) const
    {
      ::SWA::ObjectPtr<maslo_TrackLog> self(const_cast<maslo_TrackLog*>( this ));
      return maslo_TrackLogPopulation::getPopulation().count_R3_has_last_TrackPoint( self );
    }

    void maslo_TrackLog::link_R5_has_laps_defined_by_LapMarker ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker>& rhs )
    {
      ::SWA::ObjectPtr<maslo_LapMarker> derivedrhs(rhs.downcast<maslo_LapMarker>());
      maslo_TrackLogPopulation::getPopulation().link_R5_has_laps_defined_by_LapMarker( ::SWA::ObjectPtr<maslo_TrackLog>( this ), derivedrhs );
    }

    void maslo_TrackLog::unlink_R5_has_laps_defined_by_LapMarker ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker>& rhs )
    {
      ::SWA::ObjectPtr<maslo_LapMarker> derivedrhs(rhs.downcast<maslo_LapMarker>());
      maslo_TrackLogPopulation::getPopulation().unlink_R5_has_laps_defined_by_LapMarker( ::SWA::ObjectPtr<maslo_TrackLog>( this ), derivedrhs );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> > maslo_TrackLog::navigate_R5_has_laps_defined_by_LapMarker ( ) const
    {
      ::SWA::ObjectPtr<maslo_TrackLog> self(const_cast<maslo_TrackLog*>( this ));
      return maslo_TrackLogPopulation::getPopulation().navigate_R5_has_laps_defined_by_LapMarker( self );
    }

    ::std::size_t maslo_TrackLog::count_R5_has_laps_defined_by_LapMarker ( ) const
    {
      ::SWA::ObjectPtr<maslo_TrackLog> self(const_cast<maslo_TrackLog*>( this ));
      return maslo_TrackLogPopulation::getPopulation().count_R5_has_laps_defined_by_LapMarker( self );
    }

    void maslo_TrackLog::link_R4_represents_path_for_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> derivedrhs(rhs.downcast<maslo_WorkoutSession>());
      maslo_TrackLogPopulation::getPopulation().link_R4_represents_path_for_WorkoutSession( ::SWA::ObjectPtr<maslo_TrackLog>( this ), derivedrhs );
    }

    void maslo_TrackLog::unlink_R4_represents_path_for_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> derivedrhs(rhs.downcast<maslo_WorkoutSession>());
      maslo_TrackLogPopulation::getPopulation().unlink_R4_represents_path_for_WorkoutSession( ::SWA::ObjectPtr<maslo_TrackLog>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_TrackLog::navigate_R4_represents_path_for_WorkoutSession ( ) const
    {
      ::SWA::ObjectPtr<maslo_TrackLog> self(const_cast<maslo_TrackLog*>( this ));
      return maslo_TrackLogPopulation::getPopulation().navigate_R4_represents_path_for_WorkoutSession( self );
    }

    ::std::size_t maslo_TrackLog::count_R4_represents_path_for_WorkoutSession ( ) const
    {
      ::SWA::ObjectPtr<maslo_TrackLog> self(const_cast<maslo_TrackLog*>( this ));
      return maslo_TrackLogPopulation::getPopulation().count_R4_represents_path_for_WorkoutSession( self );
    }

  }
}
