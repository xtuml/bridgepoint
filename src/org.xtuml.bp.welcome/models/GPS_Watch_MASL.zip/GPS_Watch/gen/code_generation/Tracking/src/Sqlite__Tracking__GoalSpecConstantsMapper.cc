//
// File: Sqlite__Tracking__GoalSpecConstantsMapper.cc
//
#include "Sqlite__Tracking__GoalSpecConstants.hh"
#include "Sqlite__Tracking__GoalSpecConstantsMapper.hh"
#include "Sqlite__Tracking__GoalSpecConstantsMapperSql.hh"
#include "__Tracking__GoalSpecConstants.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_GoalSpecConstantsMapper::maslo_GoalSpecConstantsMapper ( )
      : ::SQL::ObjectMapper< ::masld_Tracking::maslo_GoalSpecConstants,maslo_GoalSpecConstants>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_Tracking::maslo_GoalSpecConstants,maslo_GoalSpecConstants> >( new maslo_GoalSpecConstantsSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_GoalSpecConstantsMapper::~maslo_GoalSpecConstantsMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> maslo_GoalSpecConstantsMapper::createInstance ( int32_t masla_id,
                                                                                                                 int32_t masla_GoalSpecOrigin )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_GoalSpecConstants::PrimaryKeyType>::value_type( masla_id ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_GoalSpecConstants> instance(new maslo_GoalSpecConstants(  uniqueId,
                              masla_id,
                              masla_GoalSpecOrigin ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_GoalSpecConstantsMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> instance )
    {
      ::SQL::ObjectMapper< ::masld_Tracking::maslo_GoalSpecConstants,maslo_GoalSpecConstants>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_GoalSpecConstants>()->getPrimaryKey() );
    }

    bool maslo_GoalSpecConstantsMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
