//
// File: __Tracking__Speed__initialize.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__Speed.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_Tracking
{
  void maslo_Speed::masls_initialize ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_Speed, serviceId_masls_initialize);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // speed : instance of Speed;
        ::SWA::ObjectPtr<maslo_Speed> maslv_speed;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_speed(0, maslv_speed);

        // speed := find_one Speed ();
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslv_speed = findOne();
        }

        // if (null = speed) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          if ( ::SWA::Null == maslv_speed )
          {

            // speed := create Speed (
            //            id => 1 );
            {
              ::SWA::Stack::ExecutingStatement statement(6);
              maslv_speed = createInstance( 1ll, int32_t(), int32_t() );
            }

            // speed.SpeedAveragingWindow := 5;
            {
              ::SWA::Stack::ExecutingStatement statement(7);
              maslv_speed->set_masla_SpeedAveragingWindow( 5ll );
            }

            // speed.SecondsPerHour := 3600;
            {
              ::SWA::Stack::ExecutingStatement statement(8);
              maslv_speed->set_masla_SecondsPerHour( 3600ll );
            }
          }
        }
      }
    }
  }

}
