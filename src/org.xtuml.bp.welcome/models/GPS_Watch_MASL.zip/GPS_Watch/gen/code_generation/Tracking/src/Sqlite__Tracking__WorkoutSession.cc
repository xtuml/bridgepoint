//
// File: Sqlite__Tracking__WorkoutSession.cc
//
#include "Sqlite__Tracking__Display.hh"
#include "Sqlite__Tracking__Goal.hh"
#include "Sqlite__Tracking__GoalSpec.hh"
#include "Sqlite__Tracking__HeartRateSample.hh"
#include "Sqlite__Tracking__TrackLog.hh"
#include "Sqlite__Tracking__WorkoutSession.hh"
#include "Sqlite__Tracking__WorkoutSessionPopulation.hh"
#include "Sqlite__Tracking__WorkoutTimer.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__HeartRateSample.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__WorkoutTimer.hh"
#include <cstddef>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_WorkoutSession::maslo_WorkoutSession ( ::SWA::IdType           architectureId,
                                                 const ::SWA::Timestamp& masla_startTime,
                                                 double                  masla_accumulatedDistance )
      : architectureId(architectureId),
        masla_startTime(masla_startTime),
        masla_accumulatedDistance(masla_accumulatedDistance),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_WorkoutSession::maslo_WorkoutSession ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_startTime(),
        masla_accumulatedDistance(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_WorkoutSession::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_WorkoutSession::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_WorkoutSessionPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_WorkoutSession::PrimaryKeyType maslo_WorkoutSession::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_startTime );
    }

    const maslo_WorkoutSession::IndexKeyType_1 maslo_WorkoutSession::get_index_1 ( )
    {
      return IndexKeyType_1( masla_startTime );
    }

    void maslo_WorkoutSession::link_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Display> derivedrhs(rhs.downcast<maslo_Display>());
      maslo_WorkoutSessionPopulation::getPopulation().link_R7_current_status_indicated_on_Display( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), derivedrhs );
    }

    void maslo_WorkoutSession::unlink_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Display> derivedrhs(rhs.downcast<maslo_Display>());
      maslo_WorkoutSessionPopulation::getPopulation().unlink_R7_current_status_indicated_on_Display( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> maslo_WorkoutSession::navigate_R7_current_status_indicated_on_Display ( ) const
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> self(const_cast<maslo_WorkoutSession*>( this ));
      return maslo_WorkoutSessionPopulation::getPopulation().navigate_R7_current_status_indicated_on_Display( self );
    }

    ::std::size_t maslo_WorkoutSession::count_R7_current_status_indicated_on_Display ( ) const
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> self(const_cast<maslo_WorkoutSession*>( this ));
      return maslo_WorkoutSessionPopulation::getPopulation().count_R7_current_status_indicated_on_Display( self );
    }

    void maslo_WorkoutSession::link_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutTimer> derivedrhs(rhs.downcast<maslo_WorkoutTimer>());
      maslo_WorkoutSessionPopulation::getPopulation().link_R8_is_timed_by_WorkoutTimer( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), derivedrhs );
    }

    void maslo_WorkoutSession::unlink_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutTimer> derivedrhs(rhs.downcast<maslo_WorkoutTimer>());
      maslo_WorkoutSessionPopulation::getPopulation().unlink_R8_is_timed_by_WorkoutTimer( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> maslo_WorkoutSession::navigate_R8_is_timed_by_WorkoutTimer ( ) const
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> self(const_cast<maslo_WorkoutSession*>( this ));
      return maslo_WorkoutSessionPopulation::getPopulation().navigate_R8_is_timed_by_WorkoutTimer( self );
    }

    ::std::size_t maslo_WorkoutSession::count_R8_is_timed_by_WorkoutTimer ( ) const
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> self(const_cast<maslo_WorkoutSession*>( this ));
      return maslo_WorkoutSessionPopulation::getPopulation().count_R8_is_timed_by_WorkoutTimer( self );
    }

    void maslo_WorkoutSession::link_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackLog> derivedrhs(rhs.downcast<maslo_TrackLog>());
      maslo_WorkoutSessionPopulation::getPopulation().link_R4_captures_path_in_TrackLog( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), derivedrhs );
    }

    void maslo_WorkoutSession::unlink_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackLog> derivedrhs(rhs.downcast<maslo_TrackLog>());
      maslo_WorkoutSessionPopulation::getPopulation().unlink_R4_captures_path_in_TrackLog( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> maslo_WorkoutSession::navigate_R4_captures_path_in_TrackLog ( ) const
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> self(const_cast<maslo_WorkoutSession*>( this ));
      return maslo_WorkoutSessionPopulation::getPopulation().navigate_R4_captures_path_in_TrackLog( self );
    }

    ::std::size_t maslo_WorkoutSession::count_R4_captures_path_in_TrackLog ( ) const
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> self(const_cast<maslo_WorkoutSession*>( this ));
      return maslo_WorkoutSessionPopulation::getPopulation().count_R4_captures_path_in_TrackLog( self );
    }

    void maslo_WorkoutSession::link_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample>& rhs )
    {
      ::SWA::ObjectPtr<maslo_HeartRateSample> derivedrhs(rhs.downcast<maslo_HeartRateSample>());
      maslo_WorkoutSessionPopulation::getPopulation().link_R6_tracks_heart_rate_over_time_as_HeartRateSample( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), derivedrhs );
    }

    void maslo_WorkoutSession::unlink_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample>& rhs )
    {
      ::SWA::ObjectPtr<maslo_HeartRateSample> derivedrhs(rhs.downcast<maslo_HeartRateSample>());
      maslo_WorkoutSessionPopulation::getPopulation().unlink_R6_tracks_heart_rate_over_time_as_HeartRateSample( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), derivedrhs );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> > maslo_WorkoutSession::navigate_R6_tracks_heart_rate_over_time_as_HeartRateSample ( ) const
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> self(const_cast<maslo_WorkoutSession*>( this ));
      return maslo_WorkoutSessionPopulation::getPopulation().navigate_R6_tracks_heart_rate_over_time_as_HeartRateSample( self );
    }

    ::std::size_t maslo_WorkoutSession::count_R6_tracks_heart_rate_over_time_as_HeartRateSample ( ) const
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> self(const_cast<maslo_WorkoutSession*>( this ));
      return maslo_WorkoutSessionPopulation::getPopulation().count_R6_tracks_heart_rate_over_time_as_HeartRateSample( self );
    }

    void maslo_WorkoutSession::link_R10_includes_GoalSpec ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& rhs )
    {
      ::SWA::ObjectPtr<maslo_GoalSpec> derivedrhs(rhs.downcast<maslo_GoalSpec>());
      maslo_WorkoutSessionPopulation::getPopulation().link_R10_includes_GoalSpec( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), derivedrhs );
    }

    void maslo_WorkoutSession::unlink_R10_includes_GoalSpec ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& rhs )
    {
      ::SWA::ObjectPtr<maslo_GoalSpec> derivedrhs(rhs.downcast<maslo_GoalSpec>());
      maslo_WorkoutSessionPopulation::getPopulation().unlink_R10_includes_GoalSpec( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), derivedrhs );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> > maslo_WorkoutSession::navigate_R10_includes_GoalSpec ( ) const
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> self(const_cast<maslo_WorkoutSession*>( this ));
      return maslo_WorkoutSessionPopulation::getPopulation().navigate_R10_includes_GoalSpec( self );
    }

    ::std::size_t maslo_WorkoutSession::count_R10_includes_GoalSpec ( ) const
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> self(const_cast<maslo_WorkoutSession*>( this ));
      return maslo_WorkoutSessionPopulation::getPopulation().count_R10_includes_GoalSpec( self );
    }

    void maslo_WorkoutSession::link_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> derivedrhs(rhs.downcast<maslo_Goal>());
      maslo_WorkoutSessionPopulation::getPopulation().link_R11_is_currently_executing_Goal( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), derivedrhs );
    }

    void maslo_WorkoutSession::unlink_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> derivedrhs(rhs.downcast<maslo_Goal>());
      maslo_WorkoutSessionPopulation::getPopulation().unlink_R11_is_currently_executing_Goal( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> maslo_WorkoutSession::navigate_R11_is_currently_executing_Goal ( ) const
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> self(const_cast<maslo_WorkoutSession*>( this ));
      return maslo_WorkoutSessionPopulation::getPopulation().navigate_R11_is_currently_executing_Goal( self );
    }

    ::std::size_t maslo_WorkoutSession::count_R11_is_currently_executing_Goal ( ) const
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> self(const_cast<maslo_WorkoutSession*>( this ));
      return maslo_WorkoutSessionPopulation::getPopulation().count_R11_is_currently_executing_Goal( self );
    }

    void maslo_WorkoutSession::link_R13_has_executed_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> derivedrhs(rhs.downcast<maslo_Goal>());
      maslo_WorkoutSessionPopulation::getPopulation().link_R13_has_executed_Goal( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), derivedrhs );
    }

    void maslo_WorkoutSession::unlink_R13_has_executed_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> derivedrhs(rhs.downcast<maslo_Goal>());
      maslo_WorkoutSessionPopulation::getPopulation().unlink_R13_has_executed_Goal( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), derivedrhs );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> > maslo_WorkoutSession::navigate_R13_has_executed_Goal ( ) const
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> self(const_cast<maslo_WorkoutSession*>( this ));
      return maslo_WorkoutSessionPopulation::getPopulation().navigate_R13_has_executed_Goal( self );
    }

    ::std::size_t maslo_WorkoutSession::count_R13_has_executed_Goal ( ) const
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> self(const_cast<maslo_WorkoutSession*>( this ));
      return maslo_WorkoutSessionPopulation::getPopulation().count_R13_has_executed_Goal( self );
    }

  }
}
