//
// File: Sqlite__Tracking__WorkoutTimerConstantsMapper.cc
//
#include "Sqlite__Tracking__WorkoutTimerConstants.hh"
#include "Sqlite__Tracking__WorkoutTimerConstantsMapper.hh"
#include "Sqlite__Tracking__WorkoutTimerConstantsMapperSql.hh"
#include "__Tracking__WorkoutTimerConstants.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_WorkoutTimerConstantsMapper::maslo_WorkoutTimerConstantsMapper ( )
      : ::SQL::ObjectMapper< ::masld_Tracking::maslo_WorkoutTimerConstants,maslo_WorkoutTimerConstants>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_Tracking::maslo_WorkoutTimerConstants,maslo_WorkoutTimerConstants> >( new maslo_WorkoutTimerConstantsSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_WorkoutTimerConstantsMapper::~maslo_WorkoutTimerConstantsMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimerConstants> maslo_WorkoutTimerConstantsMapper::createInstance ( int32_t masla_id,
                                                                                                                         int32_t masla_timerPeriod )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_WorkoutTimerConstants::PrimaryKeyType>::value_type( masla_id ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_WorkoutTimerConstants> instance(new maslo_WorkoutTimerConstants(  uniqueId,
                                  masla_id,
                                  masla_timerPeriod ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_WorkoutTimerConstantsMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimerConstants> instance )
    {
      ::SQL::ObjectMapper< ::masld_Tracking::maslo_WorkoutTimerConstants,maslo_WorkoutTimerConstants>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_WorkoutTimerConstants>()->getPrimaryKey() );
    }

    bool maslo_WorkoutTimerConstantsMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
