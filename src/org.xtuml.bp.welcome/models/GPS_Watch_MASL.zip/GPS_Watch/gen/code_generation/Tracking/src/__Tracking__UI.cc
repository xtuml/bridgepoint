//
// File: __Tracking__UI.cc
//
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include <stdint.h>

namespace masld_Tracking
{
  maslb_UI& maslb_UI::getInstance ( )
  {
    static maslb_UI instance;
    return instance;
  }

  maslb_UI::maslb_UI ( )
    : override_masls_setData(&domain_masls_setData),
      override_masls_setIndicator(&domain_masls_setIndicator),
      override_masls_setTime(&domain_masls_setTime)
  {
  }

}
