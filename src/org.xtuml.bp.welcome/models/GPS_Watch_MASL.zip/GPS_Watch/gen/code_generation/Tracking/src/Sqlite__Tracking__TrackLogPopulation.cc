//
// File: Sqlite__Tracking__TrackLogPopulation.cc
//
#include "Sqlite__Tracking__LapMarker.hh"
#include "Sqlite__Tracking__LapMarkerPopulation.hh"
#include "Sqlite__Tracking__R1Mapper.hh"
#include "Sqlite__Tracking__R1MapperSql.hh"
#include "Sqlite__Tracking__R3Mapper.hh"
#include "Sqlite__Tracking__R3MapperSql.hh"
#include "Sqlite__Tracking__R4Mapper.hh"
#include "Sqlite__Tracking__R4MapperSql.hh"
#include "Sqlite__Tracking__R5Mapper.hh"
#include "Sqlite__Tracking__R5MapperSql.hh"
#include "Sqlite__Tracking__TrackLog.hh"
#include "Sqlite__Tracking__TrackLogPopulation.hh"
#include "Sqlite__Tracking__TrackPoint.hh"
#include "Sqlite__Tracking__TrackPointPopulation.hh"
#include "Sqlite__Tracking__WorkoutSession.hh"
#include "Sqlite__Tracking__WorkoutSessionPopulation.hh"
#include "__Tracking__LapMarker.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__TrackPoint.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/bind.hpp"
#include "boost/shared_ptr.hpp"
#include "boost/signals2.hpp"
#include <cstddef>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_TrackLogPopulation::maslo_TrackLogPopulation ( )
      : R1Mapper(RelationshipR1Mapper::singleton()),
        R3Mapper(RelationshipR3Mapper::singleton()),
        R5Mapper(RelationshipR5Mapper::singleton()),
        R4Mapper(RelationshipR4Mapper::singleton())
    {
    }

    maslo_TrackLogPopulation::~maslo_TrackLogPopulation ( )
    {
    }

    void maslo_TrackLogPopulation::initialise ( )
    {
      mapper->initialise();
      if ( R1Mapper.isInitialised() == false )
      {
        R1Mapper.initialise( ::boost::shared_ptr<RelationshipR1Mapper::RelSqlGeneratorType>( new RelationshipR1SqlGenerator() ) );
      }

      if ( R3Mapper.isInitialised() == false )
      {
        R3Mapper.initialise( ::boost::shared_ptr<RelationshipR3Mapper::RelSqlGeneratorType>( new RelationshipR3SqlGenerator() ) );
      }

      if ( R5Mapper.isInitialised() == false )
      {
        R5Mapper.initialise( ::boost::shared_ptr<RelationshipR5Mapper::RelSqlGeneratorType>( new RelationshipR5SqlGenerator() ) );
      }

      if ( R4Mapper.isInitialised() == false )
      {
        R4Mapper.initialise( ::boost::shared_ptr<RelationshipR4Mapper::RelSqlGeneratorType>( new RelationshipR4SqlGenerator() ) );
      }

    }

    maslo_TrackLogPopulation& maslo_TrackLogPopulation::getPopulation ( )
    {
      static maslo_TrackLogPopulation population;
      return population;
    }

    bool maslo_TrackLogPopulation::registered = maslo_TrackLogPopulation::registerSingleton( &maslo_TrackLogPopulation::getPopulation );

    ::boost::signals2::connection maslo_TrackLogPopulation::initialised = ::SWA::Process::getInstance().registerInitialisingListener( ::boost::bind( &maslo_TrackLogPopulation::initialise, ::boost::bind( &maslo_TrackLogPopulation::getPopulation ) ) );

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> maslo_TrackLogPopulation::findObject ( const ::SWA::IdType& obj )
    {
      return mapper->find( obj );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> > maslo_TrackLogPopulation::findObject ( const MapperType::PsObjectIdSet& obj )
    {
      MapperType::PsObjectPtrSet objectSet = mapper->find( obj );
      return ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> >( objectSet.begin(), objectSet.end(), true );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> maslo_TrackLogPopulation::createInstance ( const ::SWA::Timestamp& masla_session_startTime )
    {
      return mapper->createInstance( masla_session_startTime );
    }

    void maslo_TrackLogPopulation::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> instance )
    {
      {
        R1Mapper.objectDeletedLhs( instance.downcast<maslo_TrackLog>() );
        R3Mapper.objectDeletedLhs( instance.downcast<maslo_TrackLog>() );
        R5Mapper.objectDeletedLhs( instance.downcast<maslo_TrackLog>() );
        R4Mapper.objectDeletedRhs( instance.downcast<maslo_TrackLog>() );
      }
      mapper->deleteInstance( instance );
    }

    void maslo_TrackLogPopulation::link_R1_has_first_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackLog>&   lhs,
                                                                  const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs )
    {
      R1Mapper.linkFromLhsToRhs( lhs, rhs );
    }

    void maslo_TrackLogPopulation::unlink_R1_has_first_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackLog>&   lhs,
                                                                    const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs )
    {
      R1Mapper.unlinkFromLhsToRhs( lhs, rhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> maslo_TrackLogPopulation::navigate_R1_has_first_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackLog>& lhs )
    {
      const RelationshipR1Mapper::NavigatedRhsType& navigated(R1Mapper.navigateFromLhsToRhs( lhs ));
      return maslo_TrackPointPopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_TrackLogPopulation::count_R1_has_first_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackLog>& lhs )
    {
      return R1Mapper.countFromLhsToRhs( lhs );
    }

    void maslo_TrackLogPopulation::link_R3_has_last_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackLog>&   lhs,
                                                                 const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs )
    {
      R3Mapper.linkFromLhsToRhs( lhs, rhs );
    }

    void maslo_TrackLogPopulation::unlink_R3_has_last_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackLog>&   lhs,
                                                                   const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs )
    {
      R3Mapper.unlinkFromLhsToRhs( lhs, rhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> maslo_TrackLogPopulation::navigate_R3_has_last_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackLog>& lhs )
    {
      const RelationshipR3Mapper::NavigatedRhsType& navigated(R3Mapper.navigateFromLhsToRhs( lhs ));
      return maslo_TrackPointPopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_TrackLogPopulation::count_R3_has_last_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackLog>& lhs )
    {
      return R3Mapper.countFromLhsToRhs( lhs );
    }

    void maslo_TrackLogPopulation::link_R5_has_laps_defined_by_LapMarker ( const ::SWA::ObjectPtr<maslo_TrackLog>&  lhs,
                                                                           const ::SWA::ObjectPtr<maslo_LapMarker>& rhs )
    {
      R5Mapper.linkFromLhsToRhs( lhs, rhs );
    }

    void maslo_TrackLogPopulation::unlink_R5_has_laps_defined_by_LapMarker ( const ::SWA::ObjectPtr<maslo_TrackLog>&  lhs,
                                                                             const ::SWA::ObjectPtr<maslo_LapMarker>& rhs )
    {
      R5Mapper.unlinkFromLhsToRhs( lhs, rhs );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> > maslo_TrackLogPopulation::navigate_R5_has_laps_defined_by_LapMarker ( const ::SWA::ObjectPtr<maslo_TrackLog>& lhs )
    {
      const RelationshipR5Mapper::NavigatedRhsType& navigated(R5Mapper.navigateFromLhsToRhs( lhs ));
      return maslo_LapMarkerPopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_TrackLogPopulation::count_R5_has_laps_defined_by_LapMarker ( const ::SWA::ObjectPtr<maslo_TrackLog>& lhs )
    {
      return R5Mapper.countFromLhsToRhs( lhs );
    }

    void maslo_TrackLogPopulation::link_R4_represents_path_for_WorkoutSession ( const ::SWA::ObjectPtr<maslo_TrackLog>&       lhs,
                                                                                const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs )
    {
      R4Mapper.linkFromRhsToLhs( lhs, rhs );
    }

    void maslo_TrackLogPopulation::unlink_R4_represents_path_for_WorkoutSession ( const ::SWA::ObjectPtr<maslo_TrackLog>&       lhs,
                                                                                  const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs )
    {
      R4Mapper.unlinkFromRhsToLhs( lhs, rhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_TrackLogPopulation::navigate_R4_represents_path_for_WorkoutSession ( const ::SWA::ObjectPtr<maslo_TrackLog>& lhs )
    {
      const RelationshipR4Mapper::NavigatedLhsType& navigated(R4Mapper.navigateFromRhsToLhs( lhs ));
      return maslo_WorkoutSessionPopulation::getPopulation().findObject( navigated );
    }

    ::std::size_t maslo_TrackLogPopulation::count_R4_represents_path_for_WorkoutSession ( const ::SWA::ObjectPtr<maslo_TrackLog>& lhs )
    {
      return R4Mapper.countFromRhsToLhs( lhs );
    }

  }
}
