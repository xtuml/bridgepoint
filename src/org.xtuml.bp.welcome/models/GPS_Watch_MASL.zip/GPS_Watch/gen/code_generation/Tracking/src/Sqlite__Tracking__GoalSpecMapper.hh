//
// File: Sqlite__Tracking__GoalSpecMapper.hh
//
#ifndef Sqlite_Tracking_Goal_Spec_Mapper_hh
#define Sqlite_Tracking_Goal_Spec_Mapper_hh

#include "Sqlite__Tracking__GoalSpec.hh"
#include "__Tracking__GoalSpec.hh"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"

namespace masld_Tracking
{
  class maslt_GoalCriteria;
  class maslt_GoalSpan;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_GoalSpecMapper
      : public ::SQL::ObjectMapper< ::masld_Tracking::maslo_GoalSpec,maslo_GoalSpec>
    {

      // Finds
      public:
        // MASL identifier find: (sequenceNumber = p1)
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> findOne_OPmasl_sequenceNumber_maslEQp1CP ( int32_t p1 );


      // Instance creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> createInstance ( double                                      masla_minimum,
                                                                                     double                                      masla_maximum,
                                                                                     double                                      masla_span,
                                                                                     const ::masld_Tracking::maslt_GoalCriteria& masla_criteriaType,
                                                                                     const ::masld_Tracking::maslt_GoalSpan&     masla_spanType,
                                                                                     int32_t                                     masla_sequenceNumber,
                                                                                     const ::SWA::Timestamp&                     masla_session_startTime,
                                                                                     int32_t                                     masla_last_goal_ID );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> instance );
      protected:
        virtual bool doPostInit ( );


      // Constructors and Destructors
      public:
        maslo_GoalSpecMapper ( );
        virtual ~maslo_GoalSpecMapper ( );


      // Attributes
      private:
        ::boost::unordered_set<maslo_GoalSpec::PrimaryKeyType> primarykey_cache;


    };
  }
}
#endif // Sqlite_Tracking_Goal_Spec_Mapper_hh
