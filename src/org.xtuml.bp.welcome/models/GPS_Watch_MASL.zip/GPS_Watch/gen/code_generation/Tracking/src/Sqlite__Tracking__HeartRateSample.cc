//
// File: Sqlite__Tracking__HeartRateSample.cc
//
#include "Sqlite__Tracking__HeartRateSample.hh"
#include "Sqlite__Tracking__HeartRateSamplePopulation.hh"
#include "Sqlite__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutSession.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_HeartRateSample::maslo_HeartRateSample ( ::SWA::IdType           architectureId,
                                                   int32_t                 masla_heartRate,
                                                   int32_t                 masla_time,
                                                   const ::SWA::Timestamp& masla_session_startTime )
      : architectureId(architectureId),
        masla_heartRate(masla_heartRate),
        masla_time(masla_time),
        masla_session_startTime(masla_session_startTime),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_HeartRateSample::maslo_HeartRateSample ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_heartRate(),
        masla_time(),
        masla_session_startTime(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_HeartRateSample::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_HeartRateSample::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_HeartRateSamplePopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_HeartRateSample::PrimaryKeyType maslo_HeartRateSample::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_time, masla_session_startTime );
    }

    const maslo_HeartRateSample::IndexKeyType_1 maslo_HeartRateSample::get_index_1 ( )
    {
      return IndexKeyType_1( masla_time, masla_session_startTime );
    }

    void maslo_HeartRateSample::link_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> derivedrhs(rhs.downcast<maslo_WorkoutSession>());
      maslo_HeartRateSamplePopulation::getPopulation().link_R6_was_collected_during_WorkoutSession( ::SWA::ObjectPtr<maslo_HeartRateSample>( this ), derivedrhs );
    }

    void maslo_HeartRateSample::unlink_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> derivedrhs(rhs.downcast<maslo_WorkoutSession>());
      maslo_HeartRateSamplePopulation::getPopulation().unlink_R6_was_collected_during_WorkoutSession( ::SWA::ObjectPtr<maslo_HeartRateSample>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_HeartRateSample::navigate_R6_was_collected_during_WorkoutSession ( ) const
    {
      ::SWA::ObjectPtr<maslo_HeartRateSample> self(const_cast<maslo_HeartRateSample*>( this ));
      return maslo_HeartRateSamplePopulation::getPopulation().navigate_R6_was_collected_during_WorkoutSession( self );
    }

    ::std::size_t maslo_HeartRateSample::count_R6_was_collected_during_WorkoutSession ( ) const
    {
      ::SWA::ObjectPtr<maslo_HeartRateSample> self(const_cast<maslo_HeartRateSample*>( this ));
      return maslo_HeartRateSamplePopulation::getPopulation().count_R6_was_collected_during_WorkoutSession( self );
    }

  }
}
