//
// File: __Tracking__Goal__initialize.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalAchievement.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/shared_ptr.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Duration.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  void maslo_Goal::masls_initialize ( int32_t maslp_sequenceNumber )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_Goal, serviceId_masls_initialize);
      ::SWA::Stack::DeclareParameter pm_maslp_sequenceNumber(maslp_sequenceNumber);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(6);
      {

        // goalSpec : instance of GoalSpec;
        ::SWA::ObjectPtr<maslo_GoalSpec> maslv_goalSpec;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_goalSpec(0, maslv_goalSpec);

        // goal : instance of Goal;
        ::SWA::ObjectPtr<maslo_Goal> maslv_goal;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_goal(1, maslv_goal);

        // session : instance of WorkoutSession;
        ::SWA::ObjectPtr<maslo_WorkoutSession> maslv_session;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_session(2, maslv_session);

        // goalachievement : instance of GoalAchievement;
        ::SWA::ObjectPtr<maslo_GoalAchievement> maslv_goalachievement;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_goalachievement(3, maslv_goalachievement);

        // goalSpec := find_one GoalSpec ((sequenceNumber = sequenceNumber));
        {
          ::SWA::Stack::ExecutingStatement statement(14);
          maslv_goalSpec = maslo_GoalSpec::findOne_OPmasl_sequenceNumber_maslEQp1CP( maslp_sequenceNumber );
        }

        // if (null /= goalSpec) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(15);
          if ( ::SWA::Null != maslv_goalSpec )
          {

            // goal := create Goal (
            //               session_startTime   => goalSpec.session_startTime,
            //               spec_sequenceNumber => goalSpec.sequenceNumber,
            //               ID                  => (goalSpec.last_goal_ID + 1) ,
            // Current_State => Executing);
            {
              ::SWA::Stack::ExecutingStatement statement(16);
              maslv_goal = createInstance( maslt_GoalDisposition(), double(), maslv_goalSpec->get_masla_last_goal_ID() + 1ll, ::SWA::EventTimers::getInstance().createTimer(), maslv_goalSpec->get_masla_session_startTime(), maslv_goalSpec->get_masla_sequenceNumber(), maslst_Executing );
            }

            // link goal R9.specified_by.GoalSpec  goalSpec;
            {
              ::SWA::Stack::ExecutingStatement statement(17);
              maslv_goal->checked_link_R9_specified_by_GoalSpec( maslv_goalSpec );
            }

            // session := find_one WorkoutSession ();
            {
              ::SWA::Stack::ExecutingStatement statement(18);
              maslv_session = maslo_WorkoutSession::findOne();
            }

            // link goal R11.is_currently_executing_within.WorkoutSession  session;
            {
              ::SWA::Stack::ExecutingStatement statement(19);
              maslv_goal->checked_link_R11_is_currently_executing_within_WorkoutSession( maslv_session );
            }

            // goalSpec.last_goal_ID := goal.ID;
            {
              ::SWA::Stack::ExecutingStatement statement(20);
              maslv_goalSpec->set_masla_last_goal_ID( maslv_goal->get_masla_ID() );
            }

            // goal.calculateStart()
            {
              ::SWA::Stack::ExecutingStatement statement(23);
              maslv_goal->masls_calculateStart();
            }

            // goal.disposition := Tracking::GoalDisposition.Increase;
            {
              ::SWA::Stack::ExecutingStatement statement(24);
              maslv_goal->set_masla_disposition( maslt_GoalDisposition::masle_Increase );
            }

            // GoalAchievement.initialize()
            {
              ::SWA::Stack::ExecutingStatement statement(27);
              maslo_GoalAchievement::masls_initialize();
            }

            // goalachievement := find_one GoalAchievement ();
            {
              ::SWA::Stack::ExecutingStatement statement(28);
              maslv_goalachievement = maslo_GoalAchievement::findOne();
            }

            // schedule goal.evaluationTimer generate Goal.Evaluate () to goal delay (@PT0.000001S@ * goalachievement.evaluationPeriod) delta (@PT0.000001S@ * goalachievement.evaluationPeriod);
            {
              ::SWA::Stack::ExecutingStatement statement(29);
              ::SWA::EventTimers::getInstance().scheduleTimer( maslv_goal->get_masla_evaluationTimer(), ::SWA::Duration::fromNanos( 1000ll ) * maslv_goalachievement->get_masla_evaluationPeriod() + ::SWA::Timestamp::now(), ::SWA::Duration::fromNanos( 1000ll ) * maslv_goalachievement->get_masla_evaluationPeriod(), maslv_goal->create_maslo_Goal_maslev_Evaluate() );
            }
          }
        }
      }
    }
  }

}
