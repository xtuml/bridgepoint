//
// File: __Tracking__Display__displayLapCount.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__LapMarker.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/bind.hpp"
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Stack.hh"
#include "swa/navigate.hh"

namespace masld_Tracking
{
  void maslo_Display::state_maslst_displayLapCount ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_Display, stateId_maslst_displayLapCount);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // lapMarkers : set of instance of LapMarker;
        ::SWA::Set< ::SWA::ObjectPtr<maslo_LapMarker> > maslv_lapMarkers;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_lapMarkers(0, maslv_lapMarkers);

        // lapMarkers := this -> R7.indicates_current_status_of.WorkoutSession -> R4.captures_path_in.TrackLog -> R5.has_laps_defined_by.LapMarker;
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslv_lapMarkers = ::SWA::navigate_many<maslo_LapMarker>( ::SWA::navigate_one<maslo_TrackLog>( ::SWA::navigate_one<maslo_WorkoutSession>( ::SWA::ObjectPtr<maslo_Display>( this ), ::boost::bind( &maslo_Display::navigate_R7_indicates_current_status_of_WorkoutSession, _1 ) ), ::boost::bind( &maslo_WorkoutSession::navigate_R4_captures_path_in_TrackLog, _1 ) ), ::boost::bind( &maslo_TrackLog::navigate_R5_has_laps_defined_by_LapMarker, _1 ) );
        }

        // UI~>setData(real(lapMarkers'length), Tracking::Unit.laps)
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          maslb_UI::masls_setData( static_cast<double>( maslv_lapMarkers.size() ), maslt_Unit::masle_laps );
        }

        // UI~>setIndicator(Display.goalDispositionIndicator())
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          maslb_UI::masls_setIndicator( masls_goalDispositionIndicator() );
        }
      }
    }
  }

}
