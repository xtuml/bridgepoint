//
// File: __Tracking__GoalSpecConstants.hh
//
#ifndef _Tracking_Goal_Spec_Constants_hh
#define _Tracking_Goal_Spec_Constants_hh

#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_GoalSpecConstants;
  class maslo_GoalSpecConstants
  {

    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_GoalSpecConstants> createInstance ( int32_t masla_id,
                                                                        int32_t masla_GoalSpecOrigin );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_GoalSpecConstants> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_GoalSpecOrigin ( int32_t value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual int32_t get_masla_id ( ) const = 0;
      virtual int32_t get_masla_GoalSpecOrigin ( ) const = 0;


    // Object Services
    public:
      static void masls_initialize ( );


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_GoalSpecConstants> > findAll ( );
      static ::SWA::ObjectPtr<maslo_GoalSpecConstants> findOne ( );
      static ::SWA::ObjectPtr<maslo_GoalSpecConstants> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_GoalSpecConstants ( );
      virtual ~maslo_GoalSpecConstants ( );


    // Prevent copy
    private:
      maslo_GoalSpecConstants ( const maslo_GoalSpecConstants& rhs );
      maslo_GoalSpecConstants& operator= ( const maslo_GoalSpecConstants& rhs );


    // Id Enumerations
    public:
      enum StateIds {};
      enum EventIds {};
      enum ServiceIds {  serviceId_masls_initialize };


  };
  ::std::ostream& operator<< ( ::std::ostream&                stream,
                               const maslo_GoalSpecConstants& obj );
}
#endif // _Tracking_Goal_Spec_Constants_hh
