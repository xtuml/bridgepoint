//
// File: Sqlite__Tracking__HeartRateConstants.hh
//
#ifndef Sqlite_Tracking_Heart_Rate_Constants_hh
#define Sqlite_Tracking_Heart_Rate_Constants_hh

#include "__Tracking__HeartRateConstants.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <stdint.h>
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_HeartRateConstants
      : public ::masld_Tracking::maslo_HeartRateConstants
    {

      // Type definitions
      public:
        typedef ::boost::tuple<int32_t> PrimaryKeyType;
        typedef ::boost::tuple<int32_t> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_HeartRateConstants ( ::SWA::IdType architectureId );
        maslo_HeartRateConstants ( ::SWA::IdType architectureId,
                                   int32_t       masla_id,
                                   int32_t       masla_HeartRateAveragingWindow,
                                   int32_t       masla_HeartRateSamplingPeriod );


      // Setters for each object attribute
      public:
        void set_masla_id ( int32_t value )
        {
          this->masla_id = value;
          markAsModified();
        }
        virtual void set_masla_HeartRateAveragingWindow ( int32_t value )
        {
          this->masla_HeartRateAveragingWindow = value;
          markAsModified();
        }
        virtual void set_masla_HeartRateSamplingPeriod ( int32_t value )
        {
          this->masla_HeartRateSamplingPeriod = value;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual int32_t get_masla_HeartRateAveragingWindow ( ) const { return masla_HeartRateAveragingWindow; }
        virtual int32_t get_masla_HeartRateSamplingPeriod ( ) const { return masla_HeartRateSamplingPeriod; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_id;
        int32_t masla_HeartRateAveragingWindow;
        int32_t masla_HeartRateSamplingPeriod;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_Tracking_Heart_Rate_Constants_hh
