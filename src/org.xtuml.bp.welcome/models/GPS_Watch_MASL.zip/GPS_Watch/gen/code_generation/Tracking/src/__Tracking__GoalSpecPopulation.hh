//
// File: __Tracking__GoalSpecPopulation.hh
//
#ifndef _Tracking_Goal_Spec_Population_hh
#define _Tracking_Goal_Spec_Population_hh

#include <cstddef>
#include <stdint.h>
#include "swa/DynamicSingleton.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_GoalSpec;
  class maslt_GoalCriteria;
  class maslt_GoalSpan;
  class maslo_GoalSpecPopulation
    : public ::SWA::DynamicSingleton<maslo_GoalSpecPopulation>
  {

    // Instance Creation
    public:
      virtual ::SWA::IdType getNextArchId ( ) = 0;
      virtual ::SWA::ObjectPtr<maslo_GoalSpec> createInstance ( double                    masla_minimum,
                                                                double                    masla_maximum,
                                                                double                    masla_span,
                                                                const maslt_GoalCriteria& masla_criteriaType,
                                                                const maslt_GoalSpan&     masla_spanType,
                                                                int32_t                   masla_sequenceNumber,
                                                                const ::SWA::Timestamp&   masla_session_startTime,
                                                                int32_t                   masla_last_goal_ID ) = 0;
      virtual void deleteInstance ( ::SWA::ObjectPtr<maslo_GoalSpec> instance ) = 0;
      virtual ::std::size_t size ( ) const = 0;


    // Instance Retrieval
    public:
      virtual ::SWA::ObjectPtr<maslo_GoalSpec> getInstance ( ::SWA::IdType id ) const = 0;
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_GoalSpec> > findAll ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_GoalSpec> findOne ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_GoalSpec> findOnly ( ) const = 0;
      // MASL find: (sequenceNumber = p1)
      virtual ::SWA::ObjectPtr<maslo_GoalSpec> findOne_OPmasl_sequenceNumber_maslEQp1CP ( int32_t p1 ) const = 0;


    // Constructors and Destructors
    protected:
      maslo_GoalSpecPopulation ( );
      virtual ~maslo_GoalSpecPopulation ( );


    // Prevent copy
    private:
      maslo_GoalSpecPopulation ( const maslo_GoalSpecPopulation& rhs );
      maslo_GoalSpecPopulation& operator= ( const maslo_GoalSpecPopulation& rhs );


  };
}
#endif // _Tracking_Goal_Spec_Population_hh
