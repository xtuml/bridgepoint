//
// File: Inspector__Tracking__WorkoutTimer.cc
//
#include "Inspector__Tracking__WorkoutTimer.hh"
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "__Tracking__WorkoutTimerConstants.hh"
#include "__Tracking__WorkoutTimerEvents.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/EventHandler.hh"
#include "inspector/ObjectHandler.hh"
#include "inspector/ProcessHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include <string>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_WorkoutTimer
    {
      class masls_activateHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_activateInvoker
      {

        public:
          masls_activateInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_activate(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> thisVar;


      };
      class masls_deactivateHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_deactivateInvoker
      {

        public:
          masls_deactivateInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_deactivate(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> thisVar;


      };
      class masls_initializeHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_initializeInvoker
      {

        public:
          masls_initializeInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_initialize(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> thisVar;


      };
      class maslst_stoppedHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_runningHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_pausedHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_processingStartHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_resetLapHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslo_WorkoutTimer_maslev_startStopPressedHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_WorkoutTimer_maslev_lapResetPressedHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_WorkoutTimer_maslev_tickHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_WorkoutTimer_maslev_pauseHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_WorkoutTimer_maslev_resumeHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_WorkoutTimer_maslev_startTimerHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_WorkoutTimer_maslev_lapResetCompleteHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      Callable masls_activateHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_activateInvoker( channel );
      }

      void masls_activateHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                   const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>( frame.getThis< ::masld_Tracking::maslo_WorkoutTimer>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write wtc
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimerConstants> >();
              break;

            case 1:

              // Write executingGoal
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> >();
              break;

          }

        }
      }

      Callable masls_deactivateHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_deactivateInvoker( channel );
      }

      void masls_deactivateHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>( frame.getThis< ::masld_Tracking::maslo_WorkoutTimer>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write executingGoal
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> >();
              break;

          }

        }
      }

      Callable masls_initializeHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_initializeInvoker( channel );
      }

      void masls_initializeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>( frame.getThis< ::masld_Tracking::maslo_WorkoutTimer>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      void maslst_stoppedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                   const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>( frame.getThis< ::masld_Tracking::maslo_WorkoutTimer>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write session
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
              break;

            case 1:

              // Write display
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> >();
              break;

          }

        }
      }

      void maslst_runningHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                   const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>( frame.getThis< ::masld_Tracking::maslo_WorkoutTimer>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write wtc
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimerConstants> >();
              break;

            case 1:

              // Write trackLog
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> >();
              break;

          }

        }
      }

      void maslst_pausedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                  const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>( frame.getThis< ::masld_Tracking::maslo_WorkoutTimer>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      void maslst_processingStartHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                           const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>( frame.getThis< ::masld_Tracking::maslo_WorkoutTimer>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      void maslst_resetLapHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                    const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>( frame.getThis< ::masld_Tracking::maslo_WorkoutTimer>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write trackLog
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> >();
              break;

          }

        }
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_WorkoutTimer_maslev_startStopPressedHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_WorkoutTimer_maslev_startStopPressed( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_WorkoutTimer_maslev_startStopPressedHandler::writeParameters ( const ::SWA::Event&   event,
                                                                                BufferedOutputStream& stream ) const
      {
        const ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_startStopPressed& typedEvent = dynamic_cast<const ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_startStopPressed&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_WorkoutTimer_maslev_lapResetPressedHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_WorkoutTimer_maslev_lapResetPressed( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_WorkoutTimer_maslev_lapResetPressedHandler::writeParameters ( const ::SWA::Event&   event,
                                                                               BufferedOutputStream& stream ) const
      {
        const ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_lapResetPressed& typedEvent = dynamic_cast<const ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_lapResetPressed&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_WorkoutTimer_maslev_tickHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_WorkoutTimer_maslev_tick( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_WorkoutTimer_maslev_tickHandler::writeParameters ( const ::SWA::Event&   event,
                                                                    BufferedOutputStream& stream ) const
      {
        const ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_tick& typedEvent = dynamic_cast<const ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_tick&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_WorkoutTimer_maslev_pauseHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_WorkoutTimer_maslev_pause( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_WorkoutTimer_maslev_pauseHandler::writeParameters ( const ::SWA::Event&   event,
                                                                     BufferedOutputStream& stream ) const
      {
        const ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_pause& typedEvent = dynamic_cast<const ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_pause&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_WorkoutTimer_maslev_resumeHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_WorkoutTimer_maslev_resume( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_WorkoutTimer_maslev_resumeHandler::writeParameters ( const ::SWA::Event&   event,
                                                                      BufferedOutputStream& stream ) const
      {
        const ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_resume& typedEvent = dynamic_cast<const ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_resume&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_WorkoutTimer_maslev_startTimerHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_WorkoutTimer_maslev_startTimer( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_WorkoutTimer_maslev_startTimerHandler::writeParameters ( const ::SWA::Event&   event,
                                                                          BufferedOutputStream& stream ) const
      {
        const ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_startTimer& typedEvent = dynamic_cast<const ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_startTimer&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_WorkoutTimer_maslev_lapResetCompleteHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_WorkoutTimer_maslev_lapResetComplete( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_WorkoutTimer_maslev_lapResetCompleteHandler::writeParameters ( const ::SWA::Event&   event,
                                                                                BufferedOutputStream& stream ) const
      {
        const ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_lapResetComplete& typedEvent = dynamic_cast<const ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_lapResetComplete&>( event );
      }

      maslo_WorkoutTimerHandler::maslo_WorkoutTimerHandler ( )
      {
        registerServiceHandler( ::masld_Tracking::maslo_WorkoutTimer::serviceId_masls_activate, ::boost::shared_ptr<ActionHandler>( new masls_activateHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslo_WorkoutTimer::serviceId_masls_deactivate, ::boost::shared_ptr<ActionHandler>( new masls_deactivateHandler() ) );
        registerServiceHandler( ::masld_Tracking::maslo_WorkoutTimer::serviceId_masls_initialize, ::boost::shared_ptr<ActionHandler>( new masls_initializeHandler() ) );
        registerStateHandler( ::masld_Tracking::maslo_WorkoutTimer::stateId_maslst_stopped, ::boost::shared_ptr<ActionHandler>( new maslst_stoppedHandler() ) );
        registerStateHandler( ::masld_Tracking::maslo_WorkoutTimer::stateId_maslst_running, ::boost::shared_ptr<ActionHandler>( new maslst_runningHandler() ) );
        registerStateHandler( ::masld_Tracking::maslo_WorkoutTimer::stateId_maslst_paused, ::boost::shared_ptr<ActionHandler>( new maslst_pausedHandler() ) );
        registerStateHandler( ::masld_Tracking::maslo_WorkoutTimer::stateId_maslst_processingStart, ::boost::shared_ptr<ActionHandler>( new maslst_processingStartHandler() ) );
        registerStateHandler( ::masld_Tracking::maslo_WorkoutTimer::stateId_maslst_resetLap, ::boost::shared_ptr<ActionHandler>( new maslst_resetLapHandler() ) );
        registerEventHandler( ::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_startStopPressed, ::boost::shared_ptr<EventHandler>( new maslo_WorkoutTimer_maslev_startStopPressedHandler() ) );
        registerEventHandler( ::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_lapResetPressed, ::boost::shared_ptr<EventHandler>( new maslo_WorkoutTimer_maslev_lapResetPressedHandler() ) );
        registerEventHandler( ::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_tick, ::boost::shared_ptr<EventHandler>( new maslo_WorkoutTimer_maslev_tickHandler() ) );
        registerEventHandler( ::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_pause, ::boost::shared_ptr<EventHandler>( new maslo_WorkoutTimer_maslev_pauseHandler() ) );
        registerEventHandler( ::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_resume, ::boost::shared_ptr<EventHandler>( new maslo_WorkoutTimer_maslev_resumeHandler() ) );
        registerEventHandler( ::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_startTimer, ::boost::shared_ptr<EventHandler>( new maslo_WorkoutTimer_maslev_startTimerHandler() ) );
        registerEventHandler( ::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_lapResetComplete, ::boost::shared_ptr<EventHandler>( new maslo_WorkoutTimer_maslev_lapResetCompleteHandler() ) );
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslo_WorkoutTimer> ( const ::masld_Tracking::maslo_WorkoutTimer& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_time() );
    write( ::SWA::EventTimers::getInstance().getTimer( instance.get_masla_timer() ) );
    write( instance.get_masla_session_startTime() );
    write( static_cast<int>( instance.getCurrentState() ) );
    write( instance.navigate_R8_acts_as_the_stopwatch_for_WorkoutSession() );
  }

  namespace masld_Tracking
  {
    namespace maslo_WorkoutTimer
    {
      void maslo_WorkoutTimerHandler::createInstance ( CommunicationChannel& channel ) const
      {
        int32_t masla_time;
        ::SWA::Timestamp masla_session_startTime;
        int currentState;
        channel >> masla_time >> masla_session_startTime >> currentState;
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> instance = ::masld_Tracking::maslo_WorkoutTimer::createInstance( masla_time, ::SWA::EventTimers::getInstance().createTimer(), masla_session_startTime, ::masld_Tracking::maslo_WorkoutTimer::Type( currentState ) );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_WorkoutTimerHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_session_startTime() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> > ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_Tracking::maslo_WorkoutTimer::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_Tracking
  {
    namespace maslo_WorkoutTimer
    {
      void maslo_WorkoutTimerHandler::writeRelatedInstances ( CommunicationChannel&                                   channel,
                                                              ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> instance,
                                                              int                                                     relId ) const
      {
        switch ( relId )
        {
          case 0:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_WorkoutSession>( ::masld_Tracking::objectId_maslo_WorkoutSession ).writeInstances( channel, instance ? instance->navigate_R8_acts_as_the_stopwatch_for_WorkoutSession()
                                                                                                                                                                                                                                                   : ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>() );
            break;

        }

      }

    }
  }
}
