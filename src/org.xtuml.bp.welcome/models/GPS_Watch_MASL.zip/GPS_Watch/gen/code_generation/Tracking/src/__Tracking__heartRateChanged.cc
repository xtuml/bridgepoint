//
// File: __Tracking__heartRateChanged.cc
//
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_services.hh"
#include "__Tracking__WorkoutSession.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_Tracking
{
  void masls_heartRateChanged ( int32_t maslp_heartRate )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_heartRateChanged);
      ::SWA::Stack::DeclareParameter pm_maslp_heartRate(maslp_heartRate);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // session : instance of WorkoutSession;
        ::SWA::ObjectPtr<maslo_WorkoutSession> maslv_session;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_session(0, maslv_session);

        // session := find_one WorkoutSession ();
        {
          ::SWA::Stack::ExecutingStatement statement(9);
          maslv_session = maslo_WorkoutSession::findOne();
        }

        // if (null /= session) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(10);
          if ( ::SWA::Null != maslv_session )
          {

            // session.addHeartRateSample(heartRate)
            {
              ::SWA::Stack::ExecutingStatement statement(11);
              maslv_session->masls_addHeartRateSample( maslp_heartRate );
            }
          }
        }
      }
    }
  }

  const bool localServiceRegistration_masls_heartRateChanged = interceptor_masls_heartRateChanged::instance().registerLocal( &masls_heartRateChanged );

}
