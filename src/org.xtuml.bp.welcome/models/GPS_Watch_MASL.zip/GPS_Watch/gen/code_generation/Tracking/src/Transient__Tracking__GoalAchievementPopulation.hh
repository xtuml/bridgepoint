//
// File: Transient__Tracking__GoalAchievementPopulation.hh
//
#ifndef Transient_Tracking_Goal_Achievement_Population_hh
#define Transient_Tracking_Goal_Achievement_Population_hh

#include "__Tracking__GoalAchievement.hh"
#include "__Tracking__GoalAchievementPopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace transient
{
  namespace masld_Tracking
  {
    class maslo_GoalAchievementPopulation
      : public TransientPopulation< ::masld_Tracking::maslo_GoalAchievement,::masld_Tracking::maslo_GoalAchievementPopulation>
    {

      // Instance Creation
      private:
        maslo_GoalAchievementPopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> createInstance ( int32_t masla_id,
                                                                                            int32_t masla_evaluationPeriod );


      // Singleton Registration
      public:
        static maslo_GoalAchievementPopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> > masla_id_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> instance );
      protected:
        bool exists_masla_id ( int32_t masla_id ) const;


    };
  }
}
#endif // Transient_Tracking_Goal_Achievement_Population_hh
