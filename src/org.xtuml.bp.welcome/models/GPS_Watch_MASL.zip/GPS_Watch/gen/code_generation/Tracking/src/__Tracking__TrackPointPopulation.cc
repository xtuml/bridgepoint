//
// File: __Tracking__TrackPointPopulation.cc
//
#include "__Tracking__TrackPointPopulation.hh"

namespace masld_Tracking
{
  maslo_TrackPointPopulation::maslo_TrackPointPopulation ( )
  {
  }

  maslo_TrackPointPopulation::~maslo_TrackPointPopulation ( )
  {
  }

}
