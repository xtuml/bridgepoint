//
// File: Sqlite__Tracking__Speed.hh
//
#ifndef Sqlite_Tracking_Speed_hh
#define Sqlite_Tracking_Speed_hh

#include "__Tracking__Speed.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <stdint.h>
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_Speed
      : public ::masld_Tracking::maslo_Speed
    {

      // Type definitions
      public:
        typedef ::boost::tuple<int32_t> PrimaryKeyType;
        typedef ::boost::tuple<int32_t> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_Speed ( ::SWA::IdType architectureId );
        maslo_Speed ( ::SWA::IdType architectureId,
                      int32_t       masla_id,
                      int32_t       masla_SpeedAveragingWindow,
                      int32_t       masla_SecondsPerHour );


      // Setters for each object attribute
      public:
        void set_masla_id ( int32_t value )
        {
          this->masla_id = value;
          markAsModified();
        }
        virtual void set_masla_SpeedAveragingWindow ( int32_t value )
        {
          this->masla_SpeedAveragingWindow = value;
          markAsModified();
        }
        virtual void set_masla_SecondsPerHour ( int32_t value )
        {
          this->masla_SecondsPerHour = value;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual int32_t get_masla_SpeedAveragingWindow ( ) const { return masla_SpeedAveragingWindow; }
        virtual int32_t get_masla_SecondsPerHour ( ) const { return masla_SecondsPerHour; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_id;
        int32_t masla_SpeedAveragingWindow;
        int32_t masla_SecondsPerHour;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_Tracking_Speed_hh
