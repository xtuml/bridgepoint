//
// File: __Tracking__TrackLog__clearTrackPoints.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__TrackPoint.hh"
#include "boost/bind.hpp"
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/navigate.hh"

namespace masld_Tracking
{
  void maslo_TrackLog::masls_clearTrackPoints ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_TrackLog, serviceId_masls_clearTrackPoints);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(5);
      {

        // nextPoint : instance of TrackPoint;
        ::SWA::ObjectPtr<maslo_TrackPoint> maslv_nextPoint;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_nextPoint(0, maslv_nextPoint);

        // lastPoint : instance of TrackPoint;
        ::SWA::ObjectPtr<maslo_TrackPoint> maslv_lastPoint;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_lastPoint(1, maslv_lastPoint);

        // prevPoint : instance of TrackPoint;
        ::SWA::ObjectPtr<maslo_TrackPoint> maslv_prevPoint;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_prevPoint(2, maslv_prevPoint);

        // nextPoint := this -> R1.has_first.TrackPoint;
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          maslv_nextPoint = ::SWA::navigate_one<maslo_TrackPoint>( ::SWA::ObjectPtr<maslo_TrackLog>( this ), ::boost::bind( &maslo_TrackLog::navigate_R1_has_first_TrackPoint, _1 ) );
        }

        // lastPoint := this -> R3.has_last.TrackPoint;
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          maslv_lastPoint = ::SWA::navigate_one<maslo_TrackPoint>( ::SWA::ObjectPtr<maslo_TrackLog>( this ), ::boost::bind( &maslo_TrackLog::navigate_R3_has_last_TrackPoint, _1 ) );
        }

        // if (null /= lastPoint) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(9);
          if ( ::SWA::Null != maslv_lastPoint )
          {

            // unlink this R3.has_last.TrackPoint  lastPoint;
            {
              ::SWA::Stack::ExecutingStatement statement(10);
              ::SWA::ObjectPtr<maslo_TrackLog>( this )->unlink_R3_has_last_TrackPoint( maslv_lastPoint );
            }
          }
        }

        // if (null /= nextPoint) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(13);
          if ( ::SWA::Null != maslv_nextPoint )
          {

            // unlink this R1.has_first.TrackPoint  nextPoint;
            {
              ::SWA::Stack::ExecutingStatement statement(14);
              ::SWA::ObjectPtr<maslo_TrackLog>( this )->unlink_R1_has_first_TrackPoint( maslv_nextPoint );
            }
          }
        }

        // while (null /= nextPoint) loop ...
        {
          ::SWA::Stack::ExecutingStatement statement(17);
          while ( ::SWA::Null != maslv_nextPoint )
          {

            // prevPoint := nextPoint;
            {
              ::SWA::Stack::ExecutingStatement statement(18);
              maslv_prevPoint = maslv_nextPoint;
            }

            // nextPoint := nextPoint -> R2.follows.TrackPoint;
            {
              ::SWA::Stack::ExecutingStatement statement(19);
              maslv_nextPoint = ::SWA::navigate_one<maslo_TrackPoint>( maslv_nextPoint, ::boost::bind( &maslo_TrackPoint::navigate_R2_follows_TrackPoint, _1 ) );
            }

            // if (null /= nextPoint) then ...
            {
              ::SWA::Stack::ExecutingStatement statement(20);
              if ( ::SWA::Null != maslv_nextPoint )
              {

                // unlink prevPoint R2.follows.TrackPoint  nextPoint;
                {
                  ::SWA::Stack::ExecutingStatement statement(21);
                  maslv_prevPoint->unlink_R2_follows_TrackPoint( maslv_nextPoint );
                }
              }
            }

            // delete prevPoint;
            {
              ::SWA::Stack::ExecutingStatement statement(23);
              maslv_prevPoint.deleteInstance();
            }
          }
        }
      }
    }
  }

}
