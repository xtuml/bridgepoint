//
// File: Sqlite__Tracking__WorkoutTimer.cc
//
#include "Sqlite__Tracking__WorkoutSession.hh"
#include "Sqlite__Tracking__WorkoutTimer.hh"
#include "Sqlite__Tracking__WorkoutTimerPopulation.hh"
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "__Tracking__WorkoutTimerEvents.hh"
#include "boost/shared_ptr.hpp"
#include <cstddef>
#include "sqlite/BlobData.hh"
#include "sqlite/EventParameterCodecs.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_WorkoutTimer::maslo_WorkoutTimer ( ::SWA::IdType                              architectureId,
                                             int32_t                                    masla_time,
                                             const ::SWA::EventTimers::TimerIdType&     masla_timer,
                                             const ::SWA::Timestamp&                    masla_session_startTime,
                                             ::masld_Tracking::maslo_WorkoutTimer::Type currentState )
      : architectureId(architectureId),
        masla_time(masla_time),
        masla_timer(masla_timer),
        masla_session_startTime(masla_session_startTime),
        currentState(currentState),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_WorkoutTimer::maslo_WorkoutTimer ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_time(),
        masla_timer(),
        masla_session_startTime(),
        currentState(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_WorkoutTimer::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_WorkoutTimer::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_WorkoutTimerPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_WorkoutTimer::PrimaryKeyType maslo_WorkoutTimer::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_session_startTime );
    }

    const maslo_WorkoutTimer::IndexKeyType_1 maslo_WorkoutTimer::get_index_1 ( )
    {
      return IndexKeyType_1( masla_session_startTime );
    }

    void maslo_WorkoutTimer::link_R8_acts_as_the_stopwatch_for_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> derivedrhs(rhs.downcast<maslo_WorkoutSession>());
      maslo_WorkoutTimerPopulation::getPopulation().link_R8_acts_as_the_stopwatch_for_WorkoutSession( ::SWA::ObjectPtr<maslo_WorkoutTimer>( this ), derivedrhs );
    }

    void maslo_WorkoutTimer::unlink_R8_acts_as_the_stopwatch_for_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> derivedrhs(rhs.downcast<maslo_WorkoutSession>());
      maslo_WorkoutTimerPopulation::getPopulation().unlink_R8_acts_as_the_stopwatch_for_WorkoutSession( ::SWA::ObjectPtr<maslo_WorkoutTimer>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_WorkoutTimer::navigate_R8_acts_as_the_stopwatch_for_WorkoutSession ( ) const
    {
      ::SWA::ObjectPtr<maslo_WorkoutTimer> self(const_cast<maslo_WorkoutTimer*>( this ));
      return maslo_WorkoutTimerPopulation::getPopulation().navigate_R8_acts_as_the_stopwatch_for_WorkoutSession( self );
    }

    ::std::size_t maslo_WorkoutTimer::count_R8_acts_as_the_stopwatch_for_WorkoutSession ( ) const
    {
      ::SWA::ObjectPtr<maslo_WorkoutTimer> self(const_cast<maslo_WorkoutTimer*>( this ));
      return maslo_WorkoutTimerPopulation::getPopulation().count_R8_acts_as_the_stopwatch_for_WorkoutSession( self );
    }

    void encode_maslo_WorkoutTimer_maslev_startStopPressed ( ::boost::shared_ptr< ::SWA::Event> event,
                                                             BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_WorkoutTimer_maslev_startStopPressed ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_startStopPressed() );
    }

    bool registermaslo_WorkoutTimer_maslev_startStopPressed = EventParameterCodecs::getInstance().registerCodec( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer, ::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_startStopPressed, &encode_maslo_WorkoutTimer_maslev_startStopPressed, &decode_maslo_WorkoutTimer_maslev_startStopPressed );

    void encode_maslo_WorkoutTimer_maslev_lapResetPressed ( ::boost::shared_ptr< ::SWA::Event> event,
                                                            BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_WorkoutTimer_maslev_lapResetPressed ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_lapResetPressed() );
    }

    bool registermaslo_WorkoutTimer_maslev_lapResetPressed = EventParameterCodecs::getInstance().registerCodec( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer, ::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_lapResetPressed, &encode_maslo_WorkoutTimer_maslev_lapResetPressed, &decode_maslo_WorkoutTimer_maslev_lapResetPressed );

    void encode_maslo_WorkoutTimer_maslev_tick ( ::boost::shared_ptr< ::SWA::Event> event,
                                                 BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_WorkoutTimer_maslev_tick ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_tick() );
    }

    bool registermaslo_WorkoutTimer_maslev_tick = EventParameterCodecs::getInstance().registerCodec( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer, ::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_tick, &encode_maslo_WorkoutTimer_maslev_tick, &decode_maslo_WorkoutTimer_maslev_tick );

    void encode_maslo_WorkoutTimer_maslev_pause ( ::boost::shared_ptr< ::SWA::Event> event,
                                                  BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_WorkoutTimer_maslev_pause ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_pause() );
    }

    bool registermaslo_WorkoutTimer_maslev_pause = EventParameterCodecs::getInstance().registerCodec( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer, ::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_pause, &encode_maslo_WorkoutTimer_maslev_pause, &decode_maslo_WorkoutTimer_maslev_pause );

    void encode_maslo_WorkoutTimer_maslev_resume ( ::boost::shared_ptr< ::SWA::Event> event,
                                                   BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_WorkoutTimer_maslev_resume ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_resume() );
    }

    bool registermaslo_WorkoutTimer_maslev_resume = EventParameterCodecs::getInstance().registerCodec( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer, ::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_resume, &encode_maslo_WorkoutTimer_maslev_resume, &decode_maslo_WorkoutTimer_maslev_resume );

    void encode_maslo_WorkoutTimer_maslev_startTimer ( ::boost::shared_ptr< ::SWA::Event> event,
                                                       BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_WorkoutTimer_maslev_startTimer ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_startTimer() );
    }

    bool registermaslo_WorkoutTimer_maslev_startTimer = EventParameterCodecs::getInstance().registerCodec( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer, ::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_startTimer, &encode_maslo_WorkoutTimer_maslev_startTimer, &decode_maslo_WorkoutTimer_maslev_startTimer );

    void encode_maslo_WorkoutTimer_maslev_lapResetComplete ( ::boost::shared_ptr< ::SWA::Event> event,
                                                             BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_WorkoutTimer_maslev_lapResetComplete ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_Tracking::Event_maslo_WorkoutTimer_maslev_lapResetComplete() );
    }

    bool registermaslo_WorkoutTimer_maslev_lapResetComplete = EventParameterCodecs::getInstance().registerCodec( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::objectId_maslo_WorkoutTimer, ::masld_Tracking::maslo_WorkoutTimer::eventId_maslo_WorkoutTimer_maslev_lapResetComplete, &encode_maslo_WorkoutTimer_maslev_lapResetComplete, &decode_maslo_WorkoutTimer_maslev_lapResetComplete );

  }
}
