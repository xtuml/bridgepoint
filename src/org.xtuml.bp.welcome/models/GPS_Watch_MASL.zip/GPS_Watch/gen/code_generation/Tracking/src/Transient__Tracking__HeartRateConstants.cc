//
// File: Transient__Tracking__HeartRateConstants.cc
//
#include "Transient__Tracking__HeartRateConstants.hh"
#include <stdint.h>

namespace transient
{
  namespace masld_Tracking
  {
    maslo_HeartRateConstants::maslo_HeartRateConstants ( int32_t masla_id,
                                                         int32_t masla_HeartRateAveragingWindow,
                                                         int32_t masla_HeartRateSamplingPeriod )
      : architectureId(getNextArchId()),
        masla_id(masla_id),
        masla_HeartRateAveragingWindow(masla_HeartRateAveragingWindow),
        masla_HeartRateSamplingPeriod(masla_HeartRateSamplingPeriod)
    {
    }

  }
}
