//
// File: __Tracking__TrackPoint.cc
//
#include "__Tracking__TrackLog.hh"
#include "__Tracking__TrackPoint.hh"
#include "__Tracking__TrackPointPopulation.hh"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  ::SWA::ObjectPtr<maslo_TrackPoint> maslo_TrackPoint::getInstance ( ::SWA::IdType id )
  {
    return maslo_TrackPointPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_TrackPoint::getNextArchId ( )
  {
    return maslo_TrackPointPopulation::getSingleton().getNextArchId();
  }

  maslo_TrackPoint::maslo_TrackPoint ( )
    : isDeletedFlag()
  {
  }

  maslo_TrackPoint::~maslo_TrackPoint ( )
  {
  }

  ::SWA::ObjectPtr<maslo_TrackPoint> maslo_TrackPoint::createInstance ( int32_t                 masla_time,
                                                                        double                  masla_longitude,
                                                                        double                  masla_latitude,
                                                                        const ::SWA::Timestamp& masla_session_startTime )
  {
    return maslo_TrackPointPopulation::getSingleton().createInstance( masla_time, masla_longitude, masla_latitude, masla_session_startTime );
  }

  void maslo_TrackPoint::deleteInstance ( )
  {
    if ( count_R1_is_start_of_TrackLog() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R1 still linked" );
    if ( count_R2_follows_TrackPoint() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R2 still linked" );
    if ( count_R2_preceeds_TrackPoint() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R2 still linked" );
    if ( count_R3_is_last_for_TrackLog() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R3 still linked" );
    maslo_TrackPointPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_TrackPoint>( this ) );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_TrackPoint::getPopulationSize ( )
  {
    return maslo_TrackPointPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_TrackPoint> > maslo_TrackPoint::findAll ( )
  {
    return maslo_TrackPointPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_TrackPoint> maslo_TrackPoint::findOne ( )
  {
    return maslo_TrackPointPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_TrackPoint> maslo_TrackPoint::findOnly ( )
  {
    return maslo_TrackPointPopulation::getSingleton().findOnly();
  }

  int32_t maslo_TrackPoint::get_masla_next_time ( ) const
  {
    return navigate_R2_preceeds_TrackPoint()->get_masla_time();
  }

  ::std::size_t maslo_TrackPoint::count_R1_is_start_of_TrackLog ( ) const
  {
    return navigate_R1_is_start_of_TrackLog() == ::SWA::Null ? 0
                                                             : 1;
  }

  void maslo_TrackPoint::checked_link_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackLog>& rhs )
  {
    if ( get_masla_session_startTime() != rhs->get_masla_session_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R1_is_start_of_TrackLog( rhs );
  }

  void maslo_TrackPoint::unlink_R1_is_start_of_TrackLog ( )
  {
    const ::SWA::ObjectPtr<maslo_TrackLog>& rhs = navigate_R1_is_start_of_TrackLog();
    if ( rhs ) unlink_R1_is_start_of_TrackLog( rhs );
  }

  ::std::size_t maslo_TrackPoint::count_R2_follows_TrackPoint ( ) const
  {
    return navigate_R2_follows_TrackPoint() == ::SWA::Null ? 0
                                                           : 1;
  }

  void maslo_TrackPoint::checked_link_R2_follows_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs )
  {
    if ( rhs->get_masla_session_startTime() != get_masla_session_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R2_follows_TrackPoint( rhs );
  }

  void maslo_TrackPoint::unlink_R2_follows_TrackPoint ( )
  {
    const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs = navigate_R2_follows_TrackPoint();
    if ( rhs ) unlink_R2_follows_TrackPoint( rhs );
  }

  ::std::size_t maslo_TrackPoint::count_R2_preceeds_TrackPoint ( ) const
  {
    return navigate_R2_preceeds_TrackPoint() == ::SWA::Null ? 0
                                                            : 1;
  }

  void maslo_TrackPoint::checked_link_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs )
  {
    if ( get_masla_session_startTime() != rhs->get_masla_session_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R2_preceeds_TrackPoint( rhs );
  }

  void maslo_TrackPoint::unlink_R2_preceeds_TrackPoint ( )
  {
    const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs = navigate_R2_preceeds_TrackPoint();
    if ( rhs ) unlink_R2_preceeds_TrackPoint( rhs );
  }

  ::std::size_t maslo_TrackPoint::count_R3_is_last_for_TrackLog ( ) const
  {
    return navigate_R3_is_last_for_TrackLog() == ::SWA::Null ? 0
                                                             : 1;
  }

  void maslo_TrackPoint::checked_link_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackLog>& rhs )
  {
    if ( get_masla_session_startTime() != rhs->get_masla_session_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R3_is_last_for_TrackLog( rhs );
  }

  void maslo_TrackPoint::unlink_R3_is_last_for_TrackLog ( )
  {
    const ::SWA::ObjectPtr<maslo_TrackLog>& rhs = navigate_R3_is_last_for_TrackLog();
    if ( rhs ) unlink_R3_is_last_for_TrackLog( rhs );
  }

  ::std::ostream& operator<< ( ::std::ostream&         stream,
                               const maslo_TrackPoint& obj )
  {
    stream << "(";
    stream << obj.get_masla_time();
    stream << ",";
    stream << obj.get_masla_longitude();
    stream << ",";
    stream << obj.get_masla_latitude();
    stream << ",";
    stream << obj.get_masla_session_startTime();
    stream << ",";
    if ( obj.navigate_R2_preceeds_TrackPoint() ) stream << obj.get_masla_next_time();
    else stream << "<null>";
    stream << ")";
    return stream;
  }

}
