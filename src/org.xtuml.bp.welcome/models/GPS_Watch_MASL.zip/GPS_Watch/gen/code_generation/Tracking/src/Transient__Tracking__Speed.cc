//
// File: Transient__Tracking__Speed.cc
//
#include "Transient__Tracking__Speed.hh"
#include <stdint.h>

namespace transient
{
  namespace masld_Tracking
  {
    maslo_Speed::maslo_Speed ( int32_t masla_id,
                               int32_t masla_SpeedAveragingWindow,
                               int32_t masla_SecondsPerHour )
      : architectureId(getNextArchId()),
        masla_id(masla_id),
        masla_SpeedAveragingWindow(masla_SpeedAveragingWindow),
        masla_SecondsPerHour(masla_SecondsPerHour)
    {
    }

  }
}
