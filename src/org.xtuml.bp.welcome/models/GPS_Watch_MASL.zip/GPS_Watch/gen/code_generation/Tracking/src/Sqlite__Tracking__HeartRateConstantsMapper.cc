//
// File: Sqlite__Tracking__HeartRateConstantsMapper.cc
//
#include "Sqlite__Tracking__HeartRateConstants.hh"
#include "Sqlite__Tracking__HeartRateConstantsMapper.hh"
#include "Sqlite__Tracking__HeartRateConstantsMapperSql.hh"
#include "__Tracking__HeartRateConstants.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_HeartRateConstantsMapper::maslo_HeartRateConstantsMapper ( )
      : ::SQL::ObjectMapper< ::masld_Tracking::maslo_HeartRateConstants,maslo_HeartRateConstants>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_Tracking::maslo_HeartRateConstants,maslo_HeartRateConstants> >( new maslo_HeartRateConstantsSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_HeartRateConstantsMapper::~maslo_HeartRateConstantsMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> maslo_HeartRateConstantsMapper::createInstance ( int32_t masla_id,
                                                                                                                   int32_t masla_HeartRateAveragingWindow,
                                                                                                                   int32_t masla_HeartRateSamplingPeriod )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_HeartRateConstants::PrimaryKeyType>::value_type( masla_id ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_HeartRateConstants> instance(new maslo_HeartRateConstants(  uniqueId,
                               masla_id,
                               masla_HeartRateAveragingWindow,
                               masla_HeartRateSamplingPeriod ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_HeartRateConstantsMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> instance )
    {
      ::SQL::ObjectMapper< ::masld_Tracking::maslo_HeartRateConstants,maslo_HeartRateConstants>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_HeartRateConstants>()->getPrimaryKey() );
    }

    bool maslo_HeartRateConstantsMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
