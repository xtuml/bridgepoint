//
// File: Sqlite__Tracking__GoalAchievementMapper.cc
//
#include "Sqlite__Tracking__GoalAchievement.hh"
#include "Sqlite__Tracking__GoalAchievementMapper.hh"
#include "Sqlite__Tracking__GoalAchievementMapperSql.hh"
#include "__Tracking__GoalAchievement.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_GoalAchievementMapper::maslo_GoalAchievementMapper ( )
      : ::SQL::ObjectMapper< ::masld_Tracking::maslo_GoalAchievement,maslo_GoalAchievement>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_Tracking::maslo_GoalAchievement,maslo_GoalAchievement> >( new maslo_GoalAchievementSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_GoalAchievementMapper::~maslo_GoalAchievementMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> maslo_GoalAchievementMapper::createInstance ( int32_t masla_id,
                                                                                                             int32_t masla_evaluationPeriod )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_GoalAchievement::PrimaryKeyType>::value_type( masla_id ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_GoalAchievement> instance(new maslo_GoalAchievement(  uniqueId,
                            masla_id,
                            masla_evaluationPeriod ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_GoalAchievementMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalAchievement> instance )
    {
      ::SQL::ObjectMapper< ::masld_Tracking::maslo_GoalAchievement,maslo_GoalAchievement>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_GoalAchievement>()->getPrimaryKey() );
    }

    bool maslo_GoalAchievementMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
