//
// File: Sqlite__Tracking__WorkoutTimerConstants.cc
//
#include "Sqlite__Tracking__WorkoutTimerConstants.hh"
#include "Sqlite__Tracking__WorkoutTimerConstantsPopulation.hh"
#include <stdint.h>
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_WorkoutTimerConstants::maslo_WorkoutTimerConstants ( ::SWA::IdType architectureId,
                                                               int32_t       masla_id,
                                                               int32_t       masla_timerPeriod )
      : architectureId(architectureId),
        masla_id(masla_id),
        masla_timerPeriod(masla_timerPeriod),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_WorkoutTimerConstants::maslo_WorkoutTimerConstants ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_id(),
        masla_timerPeriod(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_WorkoutTimerConstants::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_WorkoutTimerConstants::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_WorkoutTimerConstantsPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_WorkoutTimerConstants::PrimaryKeyType maslo_WorkoutTimerConstants::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_id );
    }

    const maslo_WorkoutTimerConstants::IndexKeyType_1 maslo_WorkoutTimerConstants::get_index_1 ( )
    {
      return IndexKeyType_1( masla_id );
    }

  }
}
