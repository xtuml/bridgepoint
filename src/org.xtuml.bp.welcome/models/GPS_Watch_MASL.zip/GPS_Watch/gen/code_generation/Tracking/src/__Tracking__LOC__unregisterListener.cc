//
// File: __Tracking__LOC__unregisterListener.cc
//
#include "LOG_OOA/__LOG_services.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"

namespace masld_Tracking
{
  void maslb_LOC::masls_unregisterListener ( )
  {
    getInstance().override_masls_unregisterListener.getFunction()();
  }

  bool maslb_LOC::register_masls_unregisterListener ( ::SWA::FunctionOverrider<void()>::FunctionPtr override )
  {
    getInstance().override_masls_unregisterListener.override( override );
    return true;
  }

  bool maslb_LOC::overriden_masls_unregisterListener ( )
  {
    return getInstance().override_masls_unregisterListener.isOverridden();
  }

  void maslb_LOC::domain_masls_unregisterListener ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringTerminatorService enteringActionMarker(getDomain().getId(), terminatorId_maslb_LOC, serviceId_masls_unregisterListener);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // LOG::LogInfo("Sending message 'unregisterListener' on terminator LOC")
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          ::masld_LOG::interceptor_masls_LogInfo::instance().callService()( ::SWA::String( "Sending message 'unregisterListener' on terminator LOC" ) );
        }
      }
    }
  }

}
