//
// File: MetaData__Tracking.hh
//
#ifndef Tracking_OOA_Meta_Data_Tracking_hh
#define Tracking_OOA_Meta_Data_Tracking_hh

namespace masld_Tracking
{
  enum TypeIds {  typeId_maslt_GoalCriteria,
                  typeId_maslt_GoalDisposition,
                  typeId_maslt_GoalSpan,
                  typeId_maslt_Indicator,
                  typeId_maslt_Unit };
}
#endif // Tracking_OOA_Meta_Data_Tracking_hh
