//
// File: __Tracking__Achievement.cc
//
#include "__Tracking__Achievement.hh"
#include "__Tracking__AchievementPopulation.hh"
#include "__Tracking__Goal.hh"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  ::SWA::ObjectPtr<maslo_Achievement> maslo_Achievement::getInstance ( ::SWA::IdType id )
  {
    return maslo_AchievementPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_Achievement::getNextArchId ( )
  {
    return maslo_AchievementPopulation::getSingleton().getNextArchId();
  }

  maslo_Achievement::maslo_Achievement ( )
    : isDeletedFlag()
  {
  }

  maslo_Achievement::~maslo_Achievement ( )
  {
  }

  ::SWA::ObjectPtr<maslo_Achievement> maslo_Achievement::createInstance ( int32_t                 masla_startTime,
                                                                          int32_t                 masla_endTime,
                                                                          const ::SWA::Timestamp& masla_session_startTime,
                                                                          int32_t                 masla_goal_ID,
                                                                          int32_t                 masla_spec_sequenceNumber )
  {
    return maslo_AchievementPopulation::getSingleton().createInstance( masla_startTime, masla_endTime, masla_session_startTime, masla_goal_ID, masla_spec_sequenceNumber );
  }

  void maslo_Achievement::deleteInstance ( )
  {
    if ( count_R12_specifies_achievement_of_Goal() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R12 still linked" );
    if ( count_R14_is_open_for_Goal() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R14 still linked" );
    maslo_AchievementPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_Achievement>( this ) );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_Achievement::getPopulationSize ( )
  {
    return maslo_AchievementPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_Achievement> > maslo_Achievement::findAll ( )
  {
    return maslo_AchievementPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_Achievement> maslo_Achievement::findOne ( )
  {
    return maslo_AchievementPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_Achievement> maslo_Achievement::findOnly ( )
  {
    return maslo_AchievementPopulation::getSingleton().findOnly();
  }

  ::std::size_t maslo_Achievement::count_R12_specifies_achievement_of_Goal ( ) const
  {
    return navigate_R12_specifies_achievement_of_Goal() == ::SWA::Null ? 0
                                                                       : 1;
  }

  void maslo_Achievement::checked_link_R12_specifies_achievement_of_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs )
  {
    if ( get_masla_session_startTime() != rhs->get_masla_session_startTime() || get_masla_goal_ID() != rhs->get_masla_ID() || get_masla_spec_sequenceNumber() != rhs->get_masla_spec_sequenceNumber() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R12_specifies_achievement_of_Goal( rhs );
  }

  void maslo_Achievement::unlink_R12_specifies_achievement_of_Goal ( )
  {
    const ::SWA::ObjectPtr<maslo_Goal>& rhs = navigate_R12_specifies_achievement_of_Goal();
    if ( rhs ) unlink_R12_specifies_achievement_of_Goal( rhs );
  }

  ::std::size_t maslo_Achievement::count_R14_is_open_for_Goal ( ) const
  {
    return navigate_R14_is_open_for_Goal() == ::SWA::Null ? 0
                                                          : 1;
  }

  void maslo_Achievement::checked_link_R14_is_open_for_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs )
  {
    if ( get_masla_session_startTime() != rhs->get_masla_session_startTime() || get_masla_goal_ID() != rhs->get_masla_ID() || get_masla_spec_sequenceNumber() != rhs->get_masla_spec_sequenceNumber() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R14_is_open_for_Goal( rhs );
  }

  void maslo_Achievement::unlink_R14_is_open_for_Goal ( )
  {
    const ::SWA::ObjectPtr<maslo_Goal>& rhs = navigate_R14_is_open_for_Goal();
    if ( rhs ) unlink_R14_is_open_for_Goal( rhs );
  }

  ::std::ostream& operator<< ( ::std::ostream&          stream,
                               const maslo_Achievement& obj )
  {
    stream << "(";
    stream << obj.get_masla_startTime();
    stream << ",";
    stream << obj.get_masla_endTime();
    stream << ",";
    stream << obj.get_masla_session_startTime();
    stream << ",";
    stream << obj.get_masla_goal_ID();
    stream << ",";
    stream << obj.get_masla_spec_sequenceNumber();
    stream << ")";
    return stream;
  }

}
