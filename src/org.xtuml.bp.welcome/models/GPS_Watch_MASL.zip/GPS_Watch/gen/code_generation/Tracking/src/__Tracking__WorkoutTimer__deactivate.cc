//
// File: __Tracking__WorkoutTimer__deactivate.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/bind.hpp"
#include "boost/shared_ptr.hpp"
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/navigate.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  void maslo_WorkoutTimer::masls_deactivate ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_WorkoutTimer, serviceId_masls_deactivate);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // executingGoal : instance of Goal;
        ::SWA::ObjectPtr<maslo_Goal> maslv_executingGoal;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_executingGoal(0, maslv_executingGoal);

        // cancel this.timer;
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          ::SWA::EventTimers::getInstance().cancelTimer( ::SWA::ObjectPtr<maslo_WorkoutTimer>( this )->get_masla_timer() );
        }

        // executingGoal := this -> R8.acts_as_the_stopwatch_for.WorkoutSession -> R11.is_currently_executing.Goal;
        {
          ::SWA::Stack::ExecutingStatement statement(8);
          maslv_executingGoal = ::SWA::navigate_one<maslo_Goal>( ::SWA::navigate_one<maslo_WorkoutSession>( ::SWA::ObjectPtr<maslo_WorkoutTimer>( this ), ::boost::bind( &maslo_WorkoutTimer::navigate_R8_acts_as_the_stopwatch_for_WorkoutSession, _1 ) ), ::boost::bind( &maslo_WorkoutSession::navigate_R11_is_currently_executing_Goal, _1 ) );
        }

        // if (null /= executingGoal) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(9);
          if ( ::SWA::Null != maslv_executingGoal )
          {

            // generate Goal.Pause () to executingGoal;
            {
              ::SWA::Stack::ExecutingStatement statement(10);
              ::SWA::Process::getInstance().getEventQueue().addEvent( maslv_executingGoal->create_maslo_Goal_maslev_Pause( objectId_maslo_WorkoutTimer, getArchitectureId() ) );
            }
          }
        }

        // LOC~>unregisterListener()
        {
          ::SWA::Stack::ExecutingStatement statement(14);
          maslb_LOC::masls_unregisterListener();
        }

        // HR~>unregisterListener()
        {
          ::SWA::Stack::ExecutingStatement statement(15);
          maslb_HR::masls_unregisterListener();
        }
      }
    }
  }

}
