//
// File: Sqlite__Tracking__TrackPointMapperSql.cc
//
#include "Sqlite__Tracking__TrackPoint.hh"
#include "Sqlite__Tracking__TrackPointMapperSql.hh"
#include "__Tracking__TrackPoint.hh"
#include "boost/shared_ptr.hpp"
#include "boost/tuple/tuple_comparison.hpp"
#include <map>
#include "sql/Criteria.hh"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/Schema.hh"
#include "sql/Util.hh"
#include "sqlite/Database.hh"
#include "sqlite/Exception.hh"
#include "sqlite/Resultset.hh"
#include "sqlite/SqlMonitor.hh"
#include "sqlite3.h"
#include <stdint.h>
#include <string>
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace 
{
  const ::std::string createTableStatment ( )
  {
    return "CREATE TABLE S_Tracking_TRACKPOINT(   architecture_id  INTEGER ,   masla_time INTEGER,   masla_longitude REAL,   masla_latitude REAL,   masla_session_startTime INTEGER, PRIMARY KEY (architecture_id));\n";
  }

  bool registerSchema = ::SQL::Schema::singleton().registerTable( "S_Tracking_TRACKPOINT", createTableStatment() );

}
namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_TrackPointSqlGenerator::maslo_TrackPointSqlGenerator ( )
      : tableName("S_Tracking_TRACKPOINT"),
        objectName("TrackPoint"),
        insertStatement("INSERT INTO S_Tracking_TRACKPOINT VALUES(:1,:2,:3,:4,:5);"),
        updateStatement("UPDATE S_Tracking_TRACKPOINT SET masla_time = :2  , masla_longitude = :3  , masla_latitude = :4  , masla_session_startTime = :5  WHERE architecture_id = :1;"),
        deleteStatement("DELETE  FROM S_Tracking_TRACKPOINT WHERE architecture_id = :1;"),
        columnNameMapper()
    {
    }

    maslo_TrackPointSqlGenerator::~maslo_TrackPointSqlGenerator ( )
    {
    }

    void maslo_TrackPointSqlGenerator::initialise ( )
    {
      columnNameMapper["architecture_id"] = ::std::string( "architecture_id" );
      columnNameMapper["time"] = ::std::string( "masla_time" );
      columnNameMapper["longitude"] = ::std::string( "masla_longitude" );
      columnNameMapper["latitude"] = ::std::string( "masla_latitude" );
      columnNameMapper["session_startTime"] = ::std::string( "masla_session_startTime" );
      insertStatement.prepare();
      updateStatement.prepare();
      deleteStatement.prepare();
    }

    const ::std::string maslo_TrackPointSqlGenerator::getDomainName ( ) const
    {
      return "Tracking";
    }

    const ::std::string& maslo_TrackPointSqlGenerator::getTableName ( ) const
    {
      return tableName;
    }

    const ::std::string& maslo_TrackPointSqlGenerator::getObjectName ( ) const
    {
      return objectName;
    }

    const ::std::string maslo_TrackPointSqlGenerator::getColumnName ( const ::std::string& attribute ) const
    {
      ::std::map< ::std::string,::std::string>::const_iterator requiredNameItr = columnNameMapper.find( attribute );
      if ( requiredNameItr == columnNameMapper.end() )
      {
        throw SqliteException( "maslo_TrackPointSqlGenerator::getColumnName - failed to find attribute name " );
      }
      return requiredNameItr->second;
    }

    void maslo_TrackPointSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                  int32_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_Tracking_TRACKPOINT;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_TrackPointSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_TrackPointSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    void maslo_TrackPointSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                  int64_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_Tracking_TRACKPOINT;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_TrackPointSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int64_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_TrackPointSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    ::SWA::IdType maslo_TrackPointSqlGenerator::executeGetRowCount ( ) const
    {
      int32_t rowCount = 0;
      ::std::string valueSelect("SELECT count(*) FROM S_Tracking_TRACKPOINT;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_TrackPointSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          rowCount = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_TrackPointSqlGenerator::executeGetRowCount - query failed" );
      }
      return rowCount;
    }

    ::SWA::IdType maslo_TrackPointSqlGenerator::executeGetMaxIdentifier ( ) const
    {
      ::SWA::IdType maxIdValue = 0;
      executeGetMaxColumnValue( "architecture_id", maxIdValue );
      return maxIdValue;
    }

    void maslo_TrackPointSqlGenerator::executeUpdate ( const PsObjectPtr& object ) const
    {
      updateStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_time(), object.getChecked()->get_masla_longitude(), object.getChecked()->get_masla_latitude(), object.getChecked()->get_masla_session_startTime() ) );
    }

    void maslo_TrackPointSqlGenerator::executeInsert ( const PsObjectPtr& object ) const
    {
      insertStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_time(), object.getChecked()->get_masla_longitude(), object.getChecked()->get_masla_latitude(), object.getChecked()->get_masla_session_startTime() ) );
    }

    void maslo_TrackPointSqlGenerator::executeRemove ( const PsObjectPtr& object ) const
    {
      deleteStatement.execute( object.getChecked()->getArchitectureId() );
    }

    void maslo_TrackPointSqlGenerator::executeRemoveId ( const ::SWA::IdType object ) const
    {
      deleteStatement.execute( object );
    }

    void maslo_TrackPointSqlGenerator::executeSelect ( CacheType&             cache,
                                                       const ::SQL::Criteria& criteria,
                                                       PsBaseObjectPtrSwaSet& result ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("TrackPoint::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "TrackPoint::executeSelect", compile_result, query );
        database.checkColumnCount( "TrackPoint::executeSelect", sqlite3_column_count( ppStmt ), 5, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr != cache.end() )
          {
            PsBaseObjectPtr currentObject(objectItr->second.get());
            result += currentObject;
          }
          else
          {
            PsObjectPtr currentObject(new maslo_TrackPoint(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );
            result += currentObject;

            int32_t time = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_time( time );

            double longitude = sqlite3_column_double( ppStmt, 2 );
            currentObject->set_masla_longitude( longitude );

            double latitude = sqlite3_column_double( ppStmt, 3 );
            currentObject->set_masla_latitude( latitude );

            ::SWA::Timestamp session_startTime = ::SWA::Timestamp::fromNanosSinceEpoch( sqlite3_column_int64( ppStmt, 4 ) );
            currentObject->set_masla_session_startTime( session_startTime );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

    void maslo_TrackPointSqlGenerator::executeSelect ( CacheType&             cache,
                                                       const ::SQL::Criteria& criteria ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("TrackPoint::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "TrackPoint::executeSelect", compile_result, query );
        database.checkColumnCount( "TrackPoint::executeSelect", sqlite3_column_count( ppStmt ), 5, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr == cache.end() )
          {
            PsObjectPtr currentObject(new maslo_TrackPoint(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );

            int32_t time = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_time( time );

            double longitude = sqlite3_column_double( ppStmt, 2 );
            currentObject->set_masla_longitude( longitude );

            double latitude = sqlite3_column_double( ppStmt, 3 );
            currentObject->set_masla_latitude( latitude );

            ::SWA::Timestamp session_startTime = ::SWA::Timestamp::fromNanosSinceEpoch( sqlite3_column_int64( ppStmt, 4 ) );
            currentObject->set_masla_session_startTime( session_startTime );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

  }
}
