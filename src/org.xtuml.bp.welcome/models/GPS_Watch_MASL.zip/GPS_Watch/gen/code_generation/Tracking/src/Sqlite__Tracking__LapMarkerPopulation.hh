//
// File: Sqlite__Tracking__LapMarkerPopulation.hh
//
#ifndef Sqlite_Tracking_Lap_Marker_Population_hh
#define Sqlite_Tracking_Lap_Marker_Population_hh

#include "Sqlite__Tracking__LapMarker.hh"
#include "Sqlite__Tracking__LapMarkerMapper.hh"
#include "Sqlite__Tracking__R5Mapper.hh"
#include "__Tracking__LapMarker.hh"
#include "__Tracking__LapMarkerPopulation.hh"
#include "boost/signals2.hpp"
#include <cstddef>
#include "sql/Population.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_TrackLog;
  }
}
namespace masld_Tracking
{
  class maslo_TrackLog;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_LapMarkerPopulation
      : public ::SQL::SqlPopulation< ::masld_Tracking::maslo_LapMarker,maslo_LapMarker,maslo_LapMarkerMapper,::masld_Tracking::maslo_LapMarkerPopulation>
    {

      // Constructors and Destructors
      private:
        maslo_LapMarkerPopulation ( );
        ~maslo_LapMarkerPopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> createInstance ( int32_t                 masla_lapTime,
                                                                                      const ::SWA::Timestamp& masla_session_startTime );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> instance );


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Relationship Counts
      public:
        ::std::size_t count_R5_marks_end_of_lap_in_TrackLog ( const ::SWA::ObjectPtr<maslo_LapMarker>& lhs );


      // Relationship Links
      public:
        void link_R5_marks_end_of_lap_in_TrackLog ( const ::SWA::ObjectPtr<maslo_LapMarker>& lhs,
                                                    const ::SWA::ObjectPtr<maslo_TrackLog>&  rhs );
        void unlink_R5_marks_end_of_lap_in_TrackLog ( const ::SWA::ObjectPtr<maslo_LapMarker>& lhs,
                                                      const ::SWA::ObjectPtr<maslo_TrackLog>&  rhs );


      // Relationship Navigations
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> navigate_R5_marks_end_of_lap_in_TrackLog ( const ::SWA::ObjectPtr<maslo_LapMarker>& lhs );


      // Singleton Registration
      public:
        static maslo_LapMarkerPopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;
        RelationshipR5Mapper& R5Mapper;


    };
  }
}
#endif // Sqlite_Tracking_Lap_Marker_Population_hh
