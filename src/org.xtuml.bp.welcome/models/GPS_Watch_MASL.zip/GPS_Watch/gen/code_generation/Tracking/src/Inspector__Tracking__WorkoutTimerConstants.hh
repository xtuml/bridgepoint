//
// File: Inspector__Tracking__WorkoutTimerConstants.hh
//
#ifndef Inspector_Tracking_Workout_Timer_Constants_hh
#define Inspector_Tracking_Workout_Timer_Constants_hh

#include "__Tracking__WorkoutTimerConstants.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_WorkoutTimerConstants
    {
      class maslo_WorkoutTimerConstantsHandler
        : public ObjectHandler< ::masld_Tracking::maslo_WorkoutTimerConstants>
      {

        // Constructors
        public:
          maslo_WorkoutTimerConstantsHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimerConstants> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                                            channel,
                                       ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimerConstants> instance,
                                       int                                                              relId ) const;


      };
    }
  }
}
#endif // Inspector_Tracking_Workout_Timer_Constants_hh
