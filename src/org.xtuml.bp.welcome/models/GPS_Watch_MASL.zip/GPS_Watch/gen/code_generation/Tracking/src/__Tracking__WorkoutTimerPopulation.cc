//
// File: __Tracking__WorkoutTimerPopulation.cc
//
#include "__Tracking__WorkoutTimerPopulation.hh"

namespace masld_Tracking
{
  maslo_WorkoutTimerPopulation::maslo_WorkoutTimerPopulation ( )
  {
  }

  maslo_WorkoutTimerPopulation::~maslo_WorkoutTimerPopulation ( )
  {
  }

}
