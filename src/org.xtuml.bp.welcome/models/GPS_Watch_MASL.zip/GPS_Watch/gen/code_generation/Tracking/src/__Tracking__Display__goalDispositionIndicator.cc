//
// File: __Tracking__Display__goalDispositionIndicator.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/bind.hpp"
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/navigate.hh"

namespace masld_Tracking
{
  maslt_Indicator maslo_Display::masls_goalDispositionIndicator ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_Display, serviceId_masls_goalDispositionIndicator);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(5);
      {

        // session : instance of WorkoutSession;
        ::SWA::ObjectPtr<maslo_WorkoutSession> maslv_session;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_session(0, maslv_session);

        // goal : instance of Goal;
        ::SWA::ObjectPtr<maslo_Goal> maslv_goal;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_goal(1, maslv_goal);

        // indicator : Tracking::Indicator;
        maslt_Indicator maslv_indicator;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_indicator(2, maslv_indicator);

        // session := find_one WorkoutSession ();
        {
          ::SWA::Stack::ExecutingStatement statement(12);
          maslv_session = maslo_WorkoutSession::findOne();
        }

        // goal := session -> R11.is_currently_executing.Goal;
        {
          ::SWA::Stack::ExecutingStatement statement(13);
          maslv_goal = ::SWA::navigate_one<maslo_Goal>( maslv_session, ::boost::bind( &maslo_WorkoutSession::navigate_R11_is_currently_executing_Goal, _1 ) );
        }

        // indicator := Tracking::Indicator.Blank;
        {
          ::SWA::Stack::ExecutingStatement statement(17);
          maslv_indicator = maslt_Indicator::masle_Blank;
        }

        // if (null /= goal) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(18);
          if ( ::SWA::Null != maslv_goal )
          {

            // if (goal.disposition = Tracking::GoalDisposition.Increase) then ...
            // elsif (goal.disposition = Tracking::GoalDisposition.Decrease) then ...
            // else ...
            {
              ::SWA::Stack::ExecutingStatement statement(19);
              if ( maslv_goal->get_masla_disposition() == maslt_GoalDisposition::masle_Increase )
              {

                // indicator := Tracking::Indicator.Up;
                {
                  ::SWA::Stack::ExecutingStatement statement(20);
                  maslv_indicator = maslt_Indicator::masle_Up;
                }
              }
              else if ( maslv_goal->get_masla_disposition() == maslt_GoalDisposition::masle_Decrease )
              {

                // indicator := Tracking::Indicator.Down;
                {
                  ::SWA::Stack::ExecutingStatement statement(22);
                  maslv_indicator = maslt_Indicator::masle_Down;
                }
              }
              else
              {

                // indicator := Tracking::Indicator.Flat;
                {
                  ::SWA::Stack::ExecutingStatement statement(24);
                  maslv_indicator = maslt_Indicator::masle_Flat;
                }
              }
            }
          }
        }

        // return indicator;
        {
          ::SWA::Stack::ExecutingStatement statement(28);
          return maslv_indicator;
        }
      }
    }
  }

}
