//
// File: Transient__Tracking__Goal.hh
//
#ifndef Transient_Tracking_Goal_hh
#define Transient_Tracking_Goal_hh

#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Goal.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"
#include "transient/ToManyRelationship.hh"
#include "transient/ToOneRelationship.hh"

namespace masld_Tracking
{
  class maslo_GoalSpec;
  class maslo_WorkoutSession;
  class maslo_Achievement;
}
namespace transient
{
  namespace masld_Tracking
  {
    class maslo_GoalSpec;
  }
  namespace masld_Tracking
  {
    class maslo_WorkoutSession;
  }
  namespace masld_Tracking
  {
    class maslo_Achievement;
  }
  namespace masld_Tracking
  {
    class maslo_Goal
      : public ::masld_Tracking::maslo_Goal
    {

      // Constructors and Destructors
      public:
        maslo_Goal ( const ::masld_Tracking::maslt_GoalDisposition& masla_disposition,
                     double                                         masla_startingPoint,
                     int32_t                                        masla_ID,
                     const ::SWA::EventTimers::TimerIdType&         masla_evaluationTimer,
                     const ::SWA::Timestamp&                        masla_session_startTime,
                     int32_t                                        masla_spec_sequenceNumber,
                     ::masld_Tracking::maslo_Goal::Type             currentState );


      // Setters for each object attribute
      public:
        virtual void set_masla_disposition ( const ::masld_Tracking::maslt_GoalDisposition& value ) { this->masla_disposition = value; }
        virtual void set_masla_startingPoint ( double value ) { this->masla_startingPoint = value; }
        virtual void set_masla_evaluationTimer ( const ::SWA::EventTimers::TimerIdType& value ) { this->masla_evaluationTimer = value; }
        virtual void setCurrentState ( ::masld_Tracking::maslo_Goal::Type newState ) { currentState = newState; }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual ::masld_Tracking::maslt_GoalDisposition get_masla_disposition ( ) const { return masla_disposition; }
        virtual double get_masla_startingPoint ( ) const { return masla_startingPoint; }
        virtual int32_t get_masla_ID ( ) const { return masla_ID; }
        virtual ::SWA::EventTimers::TimerIdType get_masla_evaluationTimer ( ) const { return masla_evaluationTimer; }
        virtual ::SWA::Timestamp get_masla_session_startTime ( ) const { return masla_session_startTime; }
        virtual int32_t get_masla_spec_sequenceNumber ( ) const { return masla_spec_sequenceNumber; }
        virtual ::masld_Tracking::maslo_Goal::Type getCurrentState ( ) const { return currentState; }


      // Relationship Navigators
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> navigate_R9_specified_by_GoalSpec ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> navigate_R11_is_currently_executing_within_WorkoutSession ( ) const;
        virtual ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> > navigate_R12_has_recorded_Achievement ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> navigate_R13_was_executed_within_WorkoutSession ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> navigate_R14_has_open_Achievement ( ) const;


      // Relationship Counters
      public:
        virtual ::std::size_t count_R9_specified_by_GoalSpec ( ) const;
        virtual ::std::size_t count_R11_is_currently_executing_within_WorkoutSession ( ) const;
        virtual ::std::size_t count_R12_has_recorded_Achievement ( ) const;
        virtual ::std::size_t count_R13_was_executed_within_WorkoutSession ( ) const;
        virtual ::std::size_t count_R14_has_open_Achievement ( ) const;


      // Relationship Linkers
      public:
        virtual void link_R9_specified_by_GoalSpec ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& rhs );
        virtual void unlink_R9_specified_by_GoalSpec ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& rhs );
        virtual void link_R11_is_currently_executing_within_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );
        virtual void unlink_R11_is_currently_executing_within_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );
        virtual void link_R12_has_recorded_Achievement ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& rhs );
        virtual void unlink_R12_has_recorded_Achievement ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& rhs );
        virtual void link_R13_was_executed_within_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );
        virtual void unlink_R13_was_executed_within_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );
        virtual void link_R14_has_open_Achievement ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& rhs );
        virtual void unlink_R14_has_open_Achievement ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& rhs );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        ::masld_Tracking::maslt_GoalDisposition masla_disposition;
        double masla_startingPoint;
        int32_t masla_ID;
        ::SWA::EventTimers::TimerIdType masla_evaluationTimer;
        ::SWA::Timestamp masla_session_startTime;
        int32_t masla_spec_sequenceNumber;
        ::masld_Tracking::maslo_Goal::Type currentState;


      // Relationship Getters
      public:
        ToOneRelationship<maslo_GoalSpec>& get_R9_specified_by_GoalSpec ( );
        const ToOneRelationship<maslo_GoalSpec>& get_R9_specified_by_GoalSpec ( ) const;
        ToOneRelationship<maslo_WorkoutSession>& get_R11_is_currently_executing_within_WorkoutSession ( );
        const ToOneRelationship<maslo_WorkoutSession>& get_R11_is_currently_executing_within_WorkoutSession ( ) const;
        ToManyRelationship<maslo_Achievement>& get_R12_has_recorded_Achievement ( );
        const ToManyRelationship<maslo_Achievement>& get_R12_has_recorded_Achievement ( ) const;
        ToOneRelationship<maslo_WorkoutSession>& get_R13_was_executed_within_WorkoutSession ( );
        const ToOneRelationship<maslo_WorkoutSession>& get_R13_was_executed_within_WorkoutSession ( ) const;
        ToOneRelationship<maslo_Achievement>& get_R14_has_open_Achievement ( );
        const ToOneRelationship<maslo_Achievement>& get_R14_has_open_Achievement ( ) const;


      // Storage for each relationship
      private:
        ToOneRelationship<maslo_GoalSpec> R9_specified_by_GoalSpec;
        ToOneRelationship<maslo_WorkoutSession> R11_is_currently_executing_within_WorkoutSession;
        ToManyRelationship<maslo_Achievement> R12_has_recorded_Achievement;
        ToOneRelationship<maslo_WorkoutSession> R13_was_executed_within_WorkoutSession;
        ToOneRelationship<maslo_Achievement> R14_has_open_Achievement;


    };
  }
}
#endif // Transient_Tracking_Goal_hh
