//
// File: __Tracking__HeartRateConstantsPopulation.cc
//
#include "__Tracking__HeartRateConstantsPopulation.hh"

namespace masld_Tracking
{
  maslo_HeartRateConstantsPopulation::maslo_HeartRateConstantsPopulation ( )
  {
  }

  maslo_HeartRateConstantsPopulation::~maslo_HeartRateConstantsPopulation ( )
  {
  }

}
