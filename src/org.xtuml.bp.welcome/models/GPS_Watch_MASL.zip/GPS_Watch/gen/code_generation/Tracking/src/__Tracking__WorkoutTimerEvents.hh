//
// File: __Tracking__WorkoutTimerEvents.hh
//
#ifndef _Tracking_Workout_Timer_Events_hh
#define _Tracking_Workout_Timer_Events_hh

#include "swa/Event.hh"

namespace masld_Tracking
{
  class Event_maslo_WorkoutTimer_maslev_startStopPressed
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_WorkoutTimer_maslev_startStopPressed ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_WorkoutTimer_maslev_lapResetPressed
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_WorkoutTimer_maslev_lapResetPressed ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_WorkoutTimer_maslev_tick
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_WorkoutTimer_maslev_tick ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_WorkoutTimer_maslev_pause
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_WorkoutTimer_maslev_pause ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_WorkoutTimer_maslev_resume
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_WorkoutTimer_maslev_resume ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_WorkoutTimer_maslev_startTimer
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_WorkoutTimer_maslev_startTimer ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_WorkoutTimer_maslev_lapResetComplete
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_WorkoutTimer_maslev_lapResetComplete ( );
      virtual void invoke ( ) const;


  };
}
#endif // _Tracking_Workout_Timer_Events_hh
