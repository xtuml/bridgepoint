//
// File: __Tracking__GoalSpecConstants.cc
//
#include "__Tracking__GoalSpecConstants.hh"
#include "__Tracking__GoalSpecConstantsPopulation.hh"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  ::SWA::ObjectPtr<maslo_GoalSpecConstants> maslo_GoalSpecConstants::getInstance ( ::SWA::IdType id )
  {
    return maslo_GoalSpecConstantsPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_GoalSpecConstants::getNextArchId ( )
  {
    return maslo_GoalSpecConstantsPopulation::getSingleton().getNextArchId();
  }

  maslo_GoalSpecConstants::maslo_GoalSpecConstants ( )
    : isDeletedFlag()
  {
  }

  maslo_GoalSpecConstants::~maslo_GoalSpecConstants ( )
  {
  }

  ::SWA::ObjectPtr<maslo_GoalSpecConstants> maslo_GoalSpecConstants::createInstance ( int32_t masla_id,
                                                                                      int32_t masla_GoalSpecOrigin )
  {
    return maslo_GoalSpecConstantsPopulation::getSingleton().createInstance( masla_id, masla_GoalSpecOrigin );
  }

  void maslo_GoalSpecConstants::deleteInstance ( )
  {
    maslo_GoalSpecConstantsPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_GoalSpecConstants>( this ) );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_GoalSpecConstants::getPopulationSize ( )
  {
    return maslo_GoalSpecConstantsPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_GoalSpecConstants> > maslo_GoalSpecConstants::findAll ( )
  {
    return maslo_GoalSpecConstantsPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_GoalSpecConstants> maslo_GoalSpecConstants::findOne ( )
  {
    return maslo_GoalSpecConstantsPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_GoalSpecConstants> maslo_GoalSpecConstants::findOnly ( )
  {
    return maslo_GoalSpecConstantsPopulation::getSingleton().findOnly();
  }

  ::std::ostream& operator<< ( ::std::ostream&                stream,
                               const maslo_GoalSpecConstants& obj )
  {
    stream << "(";
    stream << obj.get_masla_id();
    stream << ",";
    stream << obj.get_masla_GoalSpecOrigin();
    stream << ")";
    return stream;
  }

}
