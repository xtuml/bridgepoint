//
// File: __Tracking__WorkoutTimerPopulation.hh
//
#ifndef _Tracking_Workout_Timer_Population_hh
#define _Tracking_Workout_Timer_Population_hh

#include "__Tracking__WorkoutTimer.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/DynamicSingleton.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_WorkoutTimerPopulation
    : public ::SWA::DynamicSingleton<maslo_WorkoutTimerPopulation>
  {

    // Instance Creation
    public:
      virtual ::SWA::IdType getNextArchId ( ) = 0;
      virtual ::SWA::ObjectPtr<maslo_WorkoutTimer> createInstance ( int32_t                                masla_time,
                                                                    const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                    const ::SWA::Timestamp&                masla_session_startTime,
                                                                    maslo_WorkoutTimer::Type               currentState ) = 0;
      virtual void deleteInstance ( ::SWA::ObjectPtr<maslo_WorkoutTimer> instance ) = 0;
      virtual ::std::size_t size ( ) const = 0;


    // Instance Retrieval
    public:
      virtual ::SWA::ObjectPtr<maslo_WorkoutTimer> getInstance ( ::SWA::IdType id ) const = 0;
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_WorkoutTimer> > findAll ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_WorkoutTimer> findOne ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_WorkoutTimer> findOnly ( ) const = 0;


    // Constructors and Destructors
    protected:
      maslo_WorkoutTimerPopulation ( );
      virtual ~maslo_WorkoutTimerPopulation ( );


    // Prevent copy
    private:
      maslo_WorkoutTimerPopulation ( const maslo_WorkoutTimerPopulation& rhs );
      maslo_WorkoutTimerPopulation& operator= ( const maslo_WorkoutTimerPopulation& rhs );


  };
}
#endif // _Tracking_Workout_Timer_Population_hh
