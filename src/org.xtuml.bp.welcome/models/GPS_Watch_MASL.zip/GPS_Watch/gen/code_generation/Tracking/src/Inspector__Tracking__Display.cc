//
// File: Inspector__Tracking__Display.cc
//
#include "Inspector__Tracking__Display.hh"
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__DisplayEvents.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__LapMarker.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/EventHandler.hh"
#include "inspector/ObjectHandler.hh"
#include "inspector/ProcessHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include <string>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Stack.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_Display
    {
      class masls_goalDispositionIndicatorHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_goalDispositionIndicatorInvoker
      {

        public:
          masls_goalDispositionIndicatorInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_Tracking::maslo_Display::masls_goalDispositionIndicator(); }


      };
      class maslst_displayDistanceHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_displaySpeedHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_displayPaceHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_displayHeartRateHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslst_displayLapCountHandler
        : public ActionHandler
      {

        public:
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class maslo_Display_maslev_modeChangeHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      class maslo_Display_maslev_refreshHandler
        : public EventHandler
      {

        public:
          ::boost::shared_ptr< ::SWA::Event> getEvent ( CommunicationChannel& channel ) const;
          void writeParameters ( const ::SWA::Event&   event,
                                 BufferedOutputStream& stream ) const;


      };
      Callable masls_goalDispositionIndicatorHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_goalDispositionIndicatorInvoker( channel );
      }

      void masls_goalDispositionIndicatorHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                                   const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write session
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
              break;

            case 1:

              // Write goal
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> >();
              break;

            case 2:

              // Write indicator
              channel << frame.getLocalVars()[i].getValue< ::masld_Tracking::maslt_Indicator>();
              break;

          }

        }
      }

      void maslst_displayDistanceHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                           const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display>( frame.getThis< ::masld_Tracking::maslo_Display>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write session
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
              break;

            case 1:

              // Write distance
              channel << frame.getLocalVars()[i].getValue<double>();
              break;

          }

        }
      }

      void maslst_displaySpeedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                        const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display>( frame.getThis< ::masld_Tracking::maslo_Display>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write session
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
              break;

            case 1:

              // Write speed
              channel << frame.getLocalVars()[i].getValue<double>();
              break;

          }

        }
      }

      void maslst_displayPaceHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                       const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display>( frame.getThis< ::masld_Tracking::maslo_Display>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write session
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
              break;

            case 1:

              // Write pace
              channel << frame.getLocalVars()[i].getValue<double>();
              break;

          }

        }
      }

      void maslst_displayHeartRateHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                            const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display>( frame.getThis< ::masld_Tracking::maslo_Display>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write session
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >();
              break;

            case 1:

              // Write heartRate
              channel << frame.getLocalVars()[i].getValue<int32_t>();
              break;

          }

        }
      }

      void maslst_displayLapCountHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                           const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display>( frame.getThis< ::masld_Tracking::maslo_Display>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write lapMarkers
              channel << frame.getLocalVars()[i].getValue< ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> > >();
              break;

          }

        }
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_Display_maslev_modeChangeHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_Display_maslev_modeChange( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_Display_maslev_modeChangeHandler::writeParameters ( const ::SWA::Event&   event,
                                                                     BufferedOutputStream& stream ) const
      {
        const ::masld_Tracking::Event_maslo_Display_maslev_modeChange& typedEvent = dynamic_cast<const ::masld_Tracking::Event_maslo_Display_maslev_modeChange&>( event );
      }

      ::boost::shared_ptr< ::SWA::Event> maslo_Display_maslev_refreshHandler::getEvent ( CommunicationChannel& channel ) const
      {
        int32_t sourceObjId = -1;
        int32_t sourceInstanceId = 0;
        bool hasSource;
        channel >> hasSource;
        if ( hasSource )
        {
          channel >> sourceObjId;
          channel >> sourceInstanceId;
        }
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> thisVar;
        channel >> thisVar;
        return thisVar ? thisVar->create_maslo_Display_maslev_refresh( sourceObjId, sourceInstanceId )
                       : ::boost::shared_ptr< ::SWA::Event>();
      }

      void maslo_Display_maslev_refreshHandler::writeParameters ( const ::SWA::Event&   event,
                                                                  BufferedOutputStream& stream ) const
      {
        const ::masld_Tracking::Event_maslo_Display_maslev_refresh& typedEvent = dynamic_cast<const ::masld_Tracking::Event_maslo_Display_maslev_refresh&>( event );
      }

      maslo_DisplayHandler::maslo_DisplayHandler ( )
      {
        registerServiceHandler( ::masld_Tracking::maslo_Display::serviceId_masls_goalDispositionIndicator, ::boost::shared_ptr<ActionHandler>( new masls_goalDispositionIndicatorHandler() ) );
        registerStateHandler( ::masld_Tracking::maslo_Display::stateId_maslst_displayDistance, ::boost::shared_ptr<ActionHandler>( new maslst_displayDistanceHandler() ) );
        registerStateHandler( ::masld_Tracking::maslo_Display::stateId_maslst_displaySpeed, ::boost::shared_ptr<ActionHandler>( new maslst_displaySpeedHandler() ) );
        registerStateHandler( ::masld_Tracking::maslo_Display::stateId_maslst_displayPace, ::boost::shared_ptr<ActionHandler>( new maslst_displayPaceHandler() ) );
        registerStateHandler( ::masld_Tracking::maslo_Display::stateId_maslst_displayHeartRate, ::boost::shared_ptr<ActionHandler>( new maslst_displayHeartRateHandler() ) );
        registerStateHandler( ::masld_Tracking::maslo_Display::stateId_maslst_displayLapCount, ::boost::shared_ptr<ActionHandler>( new maslst_displayLapCountHandler() ) );
        registerEventHandler( ::masld_Tracking::maslo_Display::eventId_maslo_Display_maslev_modeChange, ::boost::shared_ptr<EventHandler>( new maslo_Display_maslev_modeChangeHandler() ) );
        registerEventHandler( ::masld_Tracking::maslo_Display::eventId_maslo_Display_maslev_refresh, ::boost::shared_ptr<EventHandler>( new maslo_Display_maslev_refreshHandler() ) );
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslo_Display> ( const ::masld_Tracking::maslo_Display& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_session_startTime() );
    write( static_cast<int>( instance.getCurrentState() ) );
    write( instance.navigate_R7_indicates_current_status_of_WorkoutSession() );
  }

  namespace masld_Tracking
  {
    namespace maslo_Display
    {
      void maslo_DisplayHandler::createInstance ( CommunicationChannel& channel ) const
      {
        ::SWA::Timestamp masla_session_startTime;
        int currentState;
        channel >> masla_session_startTime >> currentState;
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> instance = ::masld_Tracking::maslo_Display::createInstance( masla_session_startTime, ::masld_Tracking::maslo_Display::Type( currentState ) );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_DisplayHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_session_startTime() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> > ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_Tracking::maslo_Display::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_Tracking
  {
    namespace maslo_Display
    {
      void maslo_DisplayHandler::writeRelatedInstances ( CommunicationChannel&                              channel,
                                                         ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> instance,
                                                         int                                                relId ) const
      {
        switch ( relId )
        {
          case 0:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_WorkoutSession>( ::masld_Tracking::objectId_maslo_WorkoutSession ).writeInstances( channel, instance ? instance->navigate_R7_indicates_current_status_of_WorkoutSession()
                                                                                                                                                                                                                                                   : ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>() );
            break;

        }

      }

    }
  }
}
