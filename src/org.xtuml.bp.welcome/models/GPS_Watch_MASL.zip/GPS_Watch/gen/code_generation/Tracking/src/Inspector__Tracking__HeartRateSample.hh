//
// File: Inspector__Tracking__HeartRateSample.hh
//
#ifndef Inspector_Tracking_Heart_Rate_Sample_hh
#define Inspector_Tracking_Heart_Rate_Sample_hh

#include "__Tracking__HeartRateSample.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_HeartRateSample
    {
      class maslo_HeartRateSampleHandler
        : public ObjectHandler< ::masld_Tracking::maslo_HeartRateSample>
      {

        // Constructors
        public:
          maslo_HeartRateSampleHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                                      channel,
                                       ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> instance,
                                       int                                                        relId ) const;


      };
    }
  }
}
#endif // Inspector_Tracking_Heart_Rate_Sample_hh
