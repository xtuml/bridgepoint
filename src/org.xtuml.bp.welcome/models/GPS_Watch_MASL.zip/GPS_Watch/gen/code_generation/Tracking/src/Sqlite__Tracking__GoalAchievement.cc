//
// File: Sqlite__Tracking__GoalAchievement.cc
//
#include "Sqlite__Tracking__GoalAchievement.hh"
#include "Sqlite__Tracking__GoalAchievementPopulation.hh"
#include <stdint.h>
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_GoalAchievement::maslo_GoalAchievement ( ::SWA::IdType architectureId,
                                                   int32_t       masla_id,
                                                   int32_t       masla_evaluationPeriod )
      : architectureId(architectureId),
        masla_id(masla_id),
        masla_evaluationPeriod(masla_evaluationPeriod),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_GoalAchievement::maslo_GoalAchievement ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_id(),
        masla_evaluationPeriod(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_GoalAchievement::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_GoalAchievement::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_GoalAchievementPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_GoalAchievement::PrimaryKeyType maslo_GoalAchievement::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_id );
    }

    const maslo_GoalAchievement::IndexKeyType_1 maslo_GoalAchievement::get_index_1 ( )
    {
      return IndexKeyType_1( masla_id );
    }

  }
}
