//
// File: __Tracking__Goal__nextGoal.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalSpecConstants.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/bind.hpp"
#include "boost/shared_ptr.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/navigate.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  void maslo_Goal::masls_nextGoal ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_Goal, serviceId_masls_nextGoal);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(5);
      {

        // session : instance of WorkoutSession;
        ::SWA::ObjectPtr<maslo_WorkoutSession> maslv_session;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_session(0, maslv_session);

        // goal : instance of Goal;
        ::SWA::ObjectPtr<maslo_Goal> maslv_goal;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_goal(1, maslv_goal);

        // gsc : instance of GoalSpecConstants;
        ::SWA::ObjectPtr<maslo_GoalSpecConstants> maslv_gsc;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_gsc(2, maslv_gsc);

        // session := find_one WorkoutSession ();
        {
          ::SWA::Stack::ExecutingStatement statement(13);
          maslv_session = maslo_WorkoutSession::findOne();
        }

        // if (null /= session) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(14);
          if ( ::SWA::Null != maslv_session )
          {

            // goal := session -> R11.is_currently_executing.Goal;
            {
              ::SWA::Stack::ExecutingStatement statement(15);
              maslv_goal = ::SWA::navigate_one<maslo_Goal>( maslv_session, ::boost::bind( &maslo_WorkoutSession::navigate_R11_is_currently_executing_Goal, _1 ) );
            }

            // if (null /= goal) then ...
            // else ...
            {
              ::SWA::Stack::ExecutingStatement statement(16);
              if ( ::SWA::Null != maslv_goal )
              {

                // generate Goal.Completed () to goal;
                {
                  ::SWA::Stack::ExecutingStatement statement(17);
                  ::SWA::Process::getInstance().getEventQueue().addEvent( maslv_goal->create_maslo_Goal_maslev_Completed() );
                }
              }
              else
              {

                // GoalSpecConstants.initialize()
                {
                  ::SWA::Stack::ExecutingStatement statement(19);
                  maslo_GoalSpecConstants::masls_initialize();
                }

                // gsc := find_one GoalSpecConstants ();
                {
                  ::SWA::Stack::ExecutingStatement statement(20);
                  maslv_gsc = maslo_GoalSpecConstants::findOne();
                }

                // Goal.initialize(gsc.GoalSpecOrigin)
                {
                  ::SWA::Stack::ExecutingStatement statement(21);
                  masls_initialize( maslv_gsc->get_masla_GoalSpecOrigin() );
                }
              }
            }
          }
        }
      }
    }
  }

}
