//
// File: __Tracking__Display.hh
//
#ifndef _Tracking_Display_hh
#define _Tracking_Display_hh

#include "boost/shared_ptr.hpp"
#include <cstddef>
#include <iostream>
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslt_Indicator;
  class maslo_WorkoutSession;
  class maslo_Display;
  class maslo_Display
  {

    public:
      enum Type {  maslst_displayDistance,
                   maslst_displaySpeed,
                   maslst_displayPace,
                   maslst_displayHeartRate,
                   maslst_displayLapCount };


    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_Display> createInstance ( const ::SWA::Timestamp& masla_session_startTime,
                                                              Type                    currentState );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_Display> getInstance ( ::SWA::IdType id );


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual ::SWA::Timestamp get_masla_session_startTime ( ) const = 0;


    // Object Services
    public:
      static maslt_Indicator masls_goalDispositionIndicator ( );


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_Display> > findAll ( );
      static ::SWA::ObjectPtr<maslo_Display> findOne ( );
      static ::SWA::ObjectPtr<maslo_Display> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_Display ( );
      virtual ~maslo_Display ( );


    // Prevent copy
    private:
      maslo_Display ( const maslo_Display& rhs );
      maslo_Display& operator= ( const maslo_Display& rhs );


    // State Machine
    public:
      virtual Type getCurrentState ( ) const = 0;
      virtual void setCurrentState ( Type newState ) = 0;


    // State Actions
    private:
      void state_maslst_displayDistance ( );
      void state_maslst_displaySpeed ( );
      void state_maslst_displayPace ( );
      void state_maslst_displayHeartRate ( );
      void state_maslst_displayLapCount ( );


    // Generate Events
    public:
      ::boost::shared_ptr< ::SWA::Event> create_maslo_Display_maslev_modeChange ( int           sourceObj = -1,
                                                                                  ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_Display_maslev_refresh ( int           sourceObj = -1,
                                                                               ::SWA::IdType sourceInstance = 0 );


    // Consume Events
    public:
      static void consume_maslo_Display_maslev_modeChange ( ::SWA::IdType id );
      static void consume_maslo_Display_maslev_refresh ( ::SWA::IdType id );


    // Process Events
    public:
      void process_maslo_Display_maslev_modeChange ( );
      void process_maslo_Display_maslev_refresh ( );


    // Id Enumerations
    public:
      enum StateIds {  stateId_maslst_displayDistance,
                       stateId_maslst_displaySpeed,
                       stateId_maslst_displayPace,
                       stateId_maslst_displayHeartRate,
                       stateId_maslst_displayLapCount };
      enum EventIds {  eventId_maslo_Display_maslev_modeChange,
                       eventId_maslo_Display_maslev_refresh };
      enum ServiceIds {  serviceId_masls_goalDispositionIndicator };


    // Relationship R7.indicates_current_status_of.WorkoutSession
    public:
      virtual ::SWA::ObjectPtr<maslo_WorkoutSession> navigate_R7_indicates_current_status_of_WorkoutSession ( ) const = 0;
      virtual ::std::size_t count_R7_indicates_current_status_of_WorkoutSession ( ) const;
      virtual void link_R7_indicates_current_status_of_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs ) = 0;
      void checked_link_R7_indicates_current_status_of_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs );
      virtual void unlink_R7_indicates_current_status_of_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs ) = 0;
      virtual void unlink_R7_indicates_current_status_of_WorkoutSession ( );


  };
  ::std::ostream& operator<< ( ::std::ostream&      stream,
                               const maslo_Display& obj );
}
#endif // _Tracking_Display_hh
