//
// File: __Tracking__TrackLog.hh
//
#ifndef _Tracking_Track_Log_hh
#define _Tracking_Track_Log_hh

#include <cstddef>
#include <iostream>
#include "swa/Bag.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_TrackPoint;
  class maslo_LapMarker;
  class maslo_WorkoutSession;
  class maslo_TrackLog;
  class maslo_TrackLog
  {

    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_TrackLog> createInstance ( const ::SWA::Timestamp& masla_session_startTime );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_TrackLog> getInstance ( ::SWA::IdType id );


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual ::SWA::Timestamp get_masla_session_startTime ( ) const = 0;


    // Instance Services
    public:
      void masls_addTrackPoint ( );
      void masls_clearTrackPoints ( );
      void masls_addLapMarker ( );
      void masls_clearLapMarkers ( );
      void masls_updateDisplay ( );


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_TrackLog> > findAll ( );
      static ::SWA::ObjectPtr<maslo_TrackLog> findOne ( );
      static ::SWA::ObjectPtr<maslo_TrackLog> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_TrackLog ( );
      virtual ~maslo_TrackLog ( );


    // Prevent copy
    private:
      maslo_TrackLog ( const maslo_TrackLog& rhs );
      maslo_TrackLog& operator= ( const maslo_TrackLog& rhs );


    // Id Enumerations
    public:
      enum StateIds {};
      enum EventIds {};
      enum ServiceIds {  serviceId_masls_addTrackPoint,
                         serviceId_masls_clearTrackPoints,
                         serviceId_masls_addLapMarker,
                         serviceId_masls_clearLapMarkers,
                         serviceId_masls_updateDisplay };


    // Relationship R1.has_first.TrackPoint
    public:
      virtual ::SWA::ObjectPtr<maslo_TrackPoint> navigate_R1_has_first_TrackPoint ( ) const = 0;
      virtual ::std::size_t count_R1_has_first_TrackPoint ( ) const;
      virtual void link_R1_has_first_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs ) = 0;
      void checked_link_R1_has_first_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs );
      virtual void unlink_R1_has_first_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs ) = 0;
      virtual void unlink_R1_has_first_TrackPoint ( );


    // Relationship R3.has_last.TrackPoint
    public:
      virtual ::SWA::ObjectPtr<maslo_TrackPoint> navigate_R3_has_last_TrackPoint ( ) const = 0;
      virtual ::std::size_t count_R3_has_last_TrackPoint ( ) const;
      virtual void link_R3_has_last_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs ) = 0;
      void checked_link_R3_has_last_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs );
      virtual void unlink_R3_has_last_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs ) = 0;
      virtual void unlink_R3_has_last_TrackPoint ( );


    // Relationship R5.has_laps_defined_by.LapMarker
    public:
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_LapMarker> > navigate_R5_has_laps_defined_by_LapMarker ( ) const = 0;
      virtual ::std::size_t count_R5_has_laps_defined_by_LapMarker ( ) const;
      virtual void link_R5_has_laps_defined_by_LapMarker ( const ::SWA::ObjectPtr<maslo_LapMarker>& rhs ) = 0;
      virtual void link_R5_has_laps_defined_by_LapMarker ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_LapMarker> >& rhs );
      void checked_link_R5_has_laps_defined_by_LapMarker ( const ::SWA::ObjectPtr<maslo_LapMarker>& rhs );
      void checked_link_R5_has_laps_defined_by_LapMarker ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_LapMarker> >& rhs );
      virtual void unlink_R5_has_laps_defined_by_LapMarker ( const ::SWA::ObjectPtr<maslo_LapMarker>& rhs ) = 0;
      virtual void unlink_R5_has_laps_defined_by_LapMarker ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_LapMarker> >& rhs );
      virtual void unlink_R5_has_laps_defined_by_LapMarker ( );


    // Relationship R4.represents_path_for.WorkoutSession
    public:
      virtual ::SWA::ObjectPtr<maslo_WorkoutSession> navigate_R4_represents_path_for_WorkoutSession ( ) const = 0;
      virtual ::std::size_t count_R4_represents_path_for_WorkoutSession ( ) const;
      virtual void link_R4_represents_path_for_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs ) = 0;
      void checked_link_R4_represents_path_for_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs );
      virtual void unlink_R4_represents_path_for_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs ) = 0;
      virtual void unlink_R4_represents_path_for_WorkoutSession ( );


  };
  ::std::ostream& operator<< ( ::std::ostream&       stream,
                               const maslo_TrackLog& obj );
}
#endif // _Tracking_Track_Log_hh
