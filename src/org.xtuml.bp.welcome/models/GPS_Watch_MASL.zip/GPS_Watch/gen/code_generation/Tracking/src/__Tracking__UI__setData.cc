//
// File: __Tracking__UI__setData.cc
//
#include "LOG_OOA/__LOG_services.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"

namespace masld_Tracking
{
  void maslb_UI::masls_setData ( double            maslp_value,
                                 const maslt_Unit& maslp_unit )
  {
    getInstance().override_masls_setData.getFunction()( maslp_value, maslp_unit );
  }

  bool maslb_UI::register_masls_setData ( ::SWA::FunctionOverrider<void (double,const maslt_Unit&)>::FunctionPtr override )
  {
    getInstance().override_masls_setData.override( override );
    return true;
  }

  bool maslb_UI::overriden_masls_setData ( )
  {
    return getInstance().override_masls_setData.isOverridden();
  }

  void maslb_UI::domain_masls_setData ( double            maslp_value,
                                        const maslt_Unit& maslp_unit )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringTerminatorService enteringActionMarker(getDomain().getId(), terminatorId_maslb_UI, serviceId_masls_setData);
      ::SWA::Stack::DeclareParameter pm_maslp_value(maslp_value);
      ::SWA::Stack::DeclareParameter pm_maslp_unit(maslp_unit);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // LOG::LogInfo("Sending message 'setData' on terminator UI")
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          ::masld_LOG::interceptor_masls_LogInfo::instance().callService()( ::SWA::String( "Sending message 'setData' on terminator UI" ) );
        }
      }
    }
  }

}
