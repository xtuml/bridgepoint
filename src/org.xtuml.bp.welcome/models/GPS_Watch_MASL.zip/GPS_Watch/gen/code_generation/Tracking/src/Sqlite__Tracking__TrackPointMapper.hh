//
// File: Sqlite__Tracking__TrackPointMapper.hh
//
#ifndef Sqlite_Tracking_Track_Point_Mapper_hh
#define Sqlite_Tracking_Track_Point_Mapper_hh

#include "Sqlite__Tracking__TrackPoint.hh"
#include "__Tracking__TrackPoint.hh"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_TrackPointMapper
      : public ::SQL::ObjectMapper< ::masld_Tracking::maslo_TrackPoint,maslo_TrackPoint>
    {

      // Instance creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> createInstance ( int32_t                 masla_time,
                                                                                       double                  masla_longitude,
                                                                                       double                  masla_latitude,
                                                                                       const ::SWA::Timestamp& masla_session_startTime );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> instance );
      protected:
        virtual bool doPostInit ( );


      // Constructors and Destructors
      public:
        maslo_TrackPointMapper ( );
        virtual ~maslo_TrackPointMapper ( );


      // Attributes
      private:
        ::boost::unordered_set<maslo_TrackPoint::PrimaryKeyType> primarykey_cache;


    };
  }
}
#endif // Sqlite_Tracking_Track_Point_Mapper_hh
