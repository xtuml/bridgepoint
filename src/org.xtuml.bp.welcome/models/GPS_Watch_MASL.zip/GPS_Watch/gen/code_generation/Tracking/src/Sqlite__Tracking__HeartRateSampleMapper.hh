//
// File: Sqlite__Tracking__HeartRateSampleMapper.hh
//
#ifndef Sqlite_Tracking_Heart_Rate_Sample_Mapper_hh
#define Sqlite_Tracking_Heart_Rate_Sample_Mapper_hh

#include "Sqlite__Tracking__HeartRateSample.hh"
#include "__Tracking__HeartRateSample.hh"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_HeartRateSampleMapper
      : public ::SQL::ObjectMapper< ::masld_Tracking::maslo_HeartRateSample,maslo_HeartRateSample>
    {

      // Instance creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> createInstance ( int32_t                 masla_heartRate,
                                                                                            int32_t                 masla_time,
                                                                                            const ::SWA::Timestamp& masla_session_startTime );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> instance );
      protected:
        virtual bool doPostInit ( );


      // Constructors and Destructors
      public:
        maslo_HeartRateSampleMapper ( );
        virtual ~maslo_HeartRateSampleMapper ( );


      // Attributes
      private:
        ::boost::unordered_set<maslo_HeartRateSample::PrimaryKeyType> primarykey_cache;


    };
  }
}
#endif // Sqlite_Tracking_Heart_Rate_Sample_Mapper_hh
