//
// File: __Tracking__LOC__getLocation.cc
//
#include "LOG_OOA/__LOG_services.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"

namespace masld_Tracking
{
  void maslb_LOC::masls_getLocation ( double& maslp_longitude,
                                      double& maslp_latitude )
  {
    getInstance().override_masls_getLocation.getFunction()( maslp_longitude, maslp_latitude );
  }

  bool maslb_LOC::register_masls_getLocation ( ::SWA::FunctionOverrider<void (double&,double&)>::FunctionPtr override )
  {
    getInstance().override_masls_getLocation.override( override );
    return true;
  }

  bool maslb_LOC::overriden_masls_getLocation ( )
  {
    return getInstance().override_masls_getLocation.isOverridden();
  }

  void maslb_LOC::domain_masls_getLocation ( double& maslp_longitude,
                                             double& maslp_latitude )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringTerminatorService enteringActionMarker(getDomain().getId(), terminatorId_maslb_LOC, serviceId_masls_getLocation);
      ::SWA::Stack::DeclareParameter pm_maslp_longitude(maslp_longitude);
      ::SWA::Stack::DeclareParameter pm_maslp_latitude(maslp_latitude);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // LOG::LogInfo("Sending message 'getLocation' on terminator LOC")
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          ::masld_LOG::interceptor_masls_LogInfo::instance().callService()( ::SWA::String( "Sending message 'getLocation' on terminator LOC" ) );
        }
      }
    }
  }

}
