//
// File: __Tracking_types.cc
//
#include "Tracking_OOA/__Tracking_types.hh"
#include <iostream>
#include <stdint.h>
#include <string>
#include "swa/ProgramError.hh"

namespace masld_Tracking
{
  maslt_GoalCriteria::maslt_GoalCriteria ( )
    : index(index_masle_HeartRate)
  {
  }

  maslt_GoalCriteria::maslt_GoalCriteria ( Index index )
    : index(index)
  {
  }

  const maslt_GoalCriteria maslt_GoalCriteria::masle_HeartRate = maslt_GoalCriteria( maslt_GoalCriteria::index_masle_HeartRate );

  const maslt_GoalCriteria maslt_GoalCriteria::masle_Pace = maslt_GoalCriteria( maslt_GoalCriteria::index_masle_Pace );

  maslt_GoalCriteria::maslt_GoalCriteria ( const ::std::string& text )
    : index(fromText( text ))
  {
  }

  const char* const maslt_GoalCriteria::textLookup[] = { "HeartRate",
     "Pace"};

  maslt_GoalCriteria::TextLookupTable maslt_GoalCriteria::getLookupTable ( )
  {
    TextLookupTable lookup;
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_HeartRate], index_masle_HeartRate ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Pace], index_masle_Pace ) );
    return lookup;
  }

  maslt_GoalCriteria::Index maslt_GoalCriteria::fromText ( const ::std::string& text )
  {
    static TextLookupTable lookup = getLookupTable();
    TextLookupTable::const_iterator pos = lookup.find( text );
    if ( pos == lookup.end() ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    return pos->second;
  }

  maslt_GoalCriteria::maslt_GoalCriteria ( Value value )
    : index(fromValue( value ))
  {
  }

  maslt_GoalCriteria::Value maslt_GoalCriteria::valueLookup[] = { maslt_GoalCriteria::value_masle_HeartRate,
     maslt_GoalCriteria::value_masle_Pace};

  maslt_GoalCriteria::Index maslt_GoalCriteria::fromValue ( Value value )
  {
    switch ( value )
    {
      case value_masle_HeartRate: return index_masle_HeartRate;
      case value_masle_Pace:      return index_masle_Pace;
      default:                    throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    }

  }

  maslt_GoalCriteria::maslt_GoalCriteria ( int32_t value )
    : index(fromValue( Value( value ) ))
  {
  }

  maslt_GoalCriteria& maslt_GoalCriteria::operator++ ( )
  {
    if ( index == index_masle_Pace ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index + 1 );
    return *this;
  }

  maslt_GoalCriteria& maslt_GoalCriteria::operator-- ( )
  {
    if ( index == index_masle_HeartRate ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index - 1 );
    return *this;
  }

  ::std::ostream& operator<< ( ::std::ostream&           stream,
                               const maslt_GoalCriteria& obj )
  {
    return stream << obj.getText();
  }

  ::std::istream& operator>> ( ::std::istream&     stream,
                               maslt_GoalCriteria& obj )
  {
    ::std::string text;
    stream >> text;
    obj = maslt_GoalCriteria( text );
    return stream;
  }

  maslt_GoalDisposition::maslt_GoalDisposition ( )
    : index(index_masle_Achieving)
  {
  }

  maslt_GoalDisposition::maslt_GoalDisposition ( Index index )
    : index(index)
  {
  }

  const maslt_GoalDisposition maslt_GoalDisposition::masle_Achieving = maslt_GoalDisposition( maslt_GoalDisposition::index_masle_Achieving );

  const maslt_GoalDisposition maslt_GoalDisposition::masle_Increase = maslt_GoalDisposition( maslt_GoalDisposition::index_masle_Increase );

  const maslt_GoalDisposition maslt_GoalDisposition::masle_Decrease = maslt_GoalDisposition( maslt_GoalDisposition::index_masle_Decrease );

  maslt_GoalDisposition::maslt_GoalDisposition ( const ::std::string& text )
    : index(fromText( text ))
  {
  }

  const char* const maslt_GoalDisposition::textLookup[] = { "Achieving",
     "Increase",
     "Decrease"};

  maslt_GoalDisposition::TextLookupTable maslt_GoalDisposition::getLookupTable ( )
  {
    TextLookupTable lookup;
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Achieving], index_masle_Achieving ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Increase], index_masle_Increase ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Decrease], index_masle_Decrease ) );
    return lookup;
  }

  maslt_GoalDisposition::Index maslt_GoalDisposition::fromText ( const ::std::string& text )
  {
    static TextLookupTable lookup = getLookupTable();
    TextLookupTable::const_iterator pos = lookup.find( text );
    if ( pos == lookup.end() ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    return pos->second;
  }

  maslt_GoalDisposition::maslt_GoalDisposition ( Value value )
    : index(fromValue( value ))
  {
  }

  maslt_GoalDisposition::Value maslt_GoalDisposition::valueLookup[] = { maslt_GoalDisposition::value_masle_Achieving,
     maslt_GoalDisposition::value_masle_Increase,
     maslt_GoalDisposition::value_masle_Decrease};

  maslt_GoalDisposition::Index maslt_GoalDisposition::fromValue ( Value value )
  {
    switch ( value )
    {
      case value_masle_Achieving: return index_masle_Achieving;
      case value_masle_Increase:  return index_masle_Increase;
      case value_masle_Decrease:  return index_masle_Decrease;
      default:                    throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    }

  }

  maslt_GoalDisposition::maslt_GoalDisposition ( int32_t value )
    : index(fromValue( Value( value ) ))
  {
  }

  maslt_GoalDisposition& maslt_GoalDisposition::operator++ ( )
  {
    if ( index == index_masle_Decrease ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index + 1 );
    return *this;
  }

  maslt_GoalDisposition& maslt_GoalDisposition::operator-- ( )
  {
    if ( index == index_masle_Achieving ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index - 1 );
    return *this;
  }

  ::std::ostream& operator<< ( ::std::ostream&              stream,
                               const maslt_GoalDisposition& obj )
  {
    return stream << obj.getText();
  }

  ::std::istream& operator>> ( ::std::istream&        stream,
                               maslt_GoalDisposition& obj )
  {
    ::std::string text;
    stream >> text;
    obj = maslt_GoalDisposition( text );
    return stream;
  }

  maslt_GoalSpan::maslt_GoalSpan ( )
    : index(index_masle_Distance)
  {
  }

  maslt_GoalSpan::maslt_GoalSpan ( Index index )
    : index(index)
  {
  }

  const maslt_GoalSpan maslt_GoalSpan::masle_Distance = maslt_GoalSpan( maslt_GoalSpan::index_masle_Distance );

  const maslt_GoalSpan maslt_GoalSpan::masle_Time = maslt_GoalSpan( maslt_GoalSpan::index_masle_Time );

  maslt_GoalSpan::maslt_GoalSpan ( const ::std::string& text )
    : index(fromText( text ))
  {
  }

  const char* const maslt_GoalSpan::textLookup[] = { "Distance",
     "Time"};

  maslt_GoalSpan::TextLookupTable maslt_GoalSpan::getLookupTable ( )
  {
    TextLookupTable lookup;
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Distance], index_masle_Distance ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Time], index_masle_Time ) );
    return lookup;
  }

  maslt_GoalSpan::Index maslt_GoalSpan::fromText ( const ::std::string& text )
  {
    static TextLookupTable lookup = getLookupTable();
    TextLookupTable::const_iterator pos = lookup.find( text );
    if ( pos == lookup.end() ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    return pos->second;
  }

  maslt_GoalSpan::maslt_GoalSpan ( Value value )
    : index(fromValue( value ))
  {
  }

  maslt_GoalSpan::Value maslt_GoalSpan::valueLookup[] = { maslt_GoalSpan::value_masle_Distance,
     maslt_GoalSpan::value_masle_Time};

  maslt_GoalSpan::Index maslt_GoalSpan::fromValue ( Value value )
  {
    switch ( value )
    {
      case value_masle_Distance: return index_masle_Distance;
      case value_masle_Time:     return index_masle_Time;
      default:                   throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    }

  }

  maslt_GoalSpan::maslt_GoalSpan ( int32_t value )
    : index(fromValue( Value( value ) ))
  {
  }

  maslt_GoalSpan& maslt_GoalSpan::operator++ ( )
  {
    if ( index == index_masle_Time ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index + 1 );
    return *this;
  }

  maslt_GoalSpan& maslt_GoalSpan::operator-- ( )
  {
    if ( index == index_masle_Distance ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index - 1 );
    return *this;
  }

  ::std::ostream& operator<< ( ::std::ostream&       stream,
                               const maslt_GoalSpan& obj )
  {
    return stream << obj.getText();
  }

  ::std::istream& operator>> ( ::std::istream& stream,
                               maslt_GoalSpan& obj )
  {
    ::std::string text;
    stream >> text;
    obj = maslt_GoalSpan( text );
    return stream;
  }

  maslt_Indicator::maslt_Indicator ( )
    : index(index_masle_Blank)
  {
  }

  maslt_Indicator::maslt_Indicator ( Index index )
    : index(index)
  {
  }

  const maslt_Indicator maslt_Indicator::masle_Blank = maslt_Indicator( maslt_Indicator::index_masle_Blank );

  const maslt_Indicator maslt_Indicator::masle_Down = maslt_Indicator( maslt_Indicator::index_masle_Down );

  const maslt_Indicator maslt_Indicator::masle_Flat = maslt_Indicator( maslt_Indicator::index_masle_Flat );

  const maslt_Indicator maslt_Indicator::masle_Up = maslt_Indicator( maslt_Indicator::index_masle_Up );

  maslt_Indicator::maslt_Indicator ( const ::std::string& text )
    : index(fromText( text ))
  {
  }

  const char* const maslt_Indicator::textLookup[] = { "Blank",
     "Down",
     "Flat",
     "Up"};

  maslt_Indicator::TextLookupTable maslt_Indicator::getLookupTable ( )
  {
    TextLookupTable lookup;
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Blank], index_masle_Blank ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Down], index_masle_Down ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Flat], index_masle_Flat ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_Up], index_masle_Up ) );
    return lookup;
  }

  maslt_Indicator::Index maslt_Indicator::fromText ( const ::std::string& text )
  {
    static TextLookupTable lookup = getLookupTable();
    TextLookupTable::const_iterator pos = lookup.find( text );
    if ( pos == lookup.end() ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    return pos->second;
  }

  maslt_Indicator::maslt_Indicator ( Value value )
    : index(fromValue( value ))
  {
  }

  maslt_Indicator::Value maslt_Indicator::valueLookup[] = { maslt_Indicator::value_masle_Blank,
     maslt_Indicator::value_masle_Down,
     maslt_Indicator::value_masle_Flat,
     maslt_Indicator::value_masle_Up};

  maslt_Indicator::Index maslt_Indicator::fromValue ( Value value )
  {
    switch ( value )
    {
      case value_masle_Blank: return index_masle_Blank;
      case value_masle_Down:  return index_masle_Down;
      case value_masle_Flat:  return index_masle_Flat;
      case value_masle_Up:    return index_masle_Up;
      default:                throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    }

  }

  maslt_Indicator::maslt_Indicator ( int32_t value )
    : index(fromValue( Value( value ) ))
  {
  }

  maslt_Indicator& maslt_Indicator::operator++ ( )
  {
    if ( index == index_masle_Up ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index + 1 );
    return *this;
  }

  maslt_Indicator& maslt_Indicator::operator-- ( )
  {
    if ( index == index_masle_Blank ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index - 1 );
    return *this;
  }

  ::std::ostream& operator<< ( ::std::ostream&        stream,
                               const maslt_Indicator& obj )
  {
    return stream << obj.getText();
  }

  ::std::istream& operator>> ( ::std::istream&  stream,
                               maslt_Indicator& obj )
  {
    ::std::string text;
    stream >> text;
    obj = maslt_Indicator( text );
    return stream;
  }

  maslt_Unit::maslt_Unit ( )
    : index(index_masle_km)
  {
  }

  maslt_Unit::maslt_Unit ( Index index )
    : index(index)
  {
  }

  const maslt_Unit maslt_Unit::masle_km = maslt_Unit( maslt_Unit::index_masle_km );

  const maslt_Unit maslt_Unit::masle_meters = maslt_Unit( maslt_Unit::index_masle_meters );

  const maslt_Unit maslt_Unit::masle_minPerKm = maslt_Unit( maslt_Unit::index_masle_minPerKm );

  const maslt_Unit maslt_Unit::masle_kmPerHour = maslt_Unit( maslt_Unit::index_masle_kmPerHour );

  const maslt_Unit maslt_Unit::masle_miles = maslt_Unit( maslt_Unit::index_masle_miles );

  const maslt_Unit maslt_Unit::masle_yards = maslt_Unit( maslt_Unit::index_masle_yards );

  const maslt_Unit maslt_Unit::masle_feet = maslt_Unit( maslt_Unit::index_masle_feet );

  const maslt_Unit maslt_Unit::masle_minPerMile = maslt_Unit( maslt_Unit::index_masle_minPerMile );

  const maslt_Unit maslt_Unit::masle_mph = maslt_Unit( maslt_Unit::index_masle_mph );

  const maslt_Unit maslt_Unit::masle_bpm = maslt_Unit( maslt_Unit::index_masle_bpm );

  const maslt_Unit maslt_Unit::masle_laps = maslt_Unit( maslt_Unit::index_masle_laps );

  maslt_Unit::maslt_Unit ( const ::std::string& text )
    : index(fromText( text ))
  {
  }

  const char* const maslt_Unit::textLookup[] = { "km",
     "meters",
     "minPerKm",
     "kmPerHour",
     "miles",
     "yards",
     "feet",
     "minPerMile",
     "mph",
     "bpm",
     "laps"};

  maslt_Unit::TextLookupTable maslt_Unit::getLookupTable ( )
  {
    TextLookupTable lookup;
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_km], index_masle_km ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_meters], index_masle_meters ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_minPerKm], index_masle_minPerKm ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_kmPerHour], index_masle_kmPerHour ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_miles], index_masle_miles ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_yards], index_masle_yards ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_feet], index_masle_feet ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_minPerMile], index_masle_minPerMile ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_mph], index_masle_mph ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_bpm], index_masle_bpm ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_laps], index_masle_laps ) );
    return lookup;
  }

  maslt_Unit::Index maslt_Unit::fromText ( const ::std::string& text )
  {
    static TextLookupTable lookup = getLookupTable();
    TextLookupTable::const_iterator pos = lookup.find( text );
    if ( pos == lookup.end() ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    return pos->second;
  }

  maslt_Unit::maslt_Unit ( Value value )
    : index(fromValue( value ))
  {
  }

  maslt_Unit::Value maslt_Unit::valueLookup[] = { maslt_Unit::value_masle_km,
     maslt_Unit::value_masle_meters,
     maslt_Unit::value_masle_minPerKm,
     maslt_Unit::value_masle_kmPerHour,
     maslt_Unit::value_masle_miles,
     maslt_Unit::value_masle_yards,
     maslt_Unit::value_masle_feet,
     maslt_Unit::value_masle_minPerMile,
     maslt_Unit::value_masle_mph,
     maslt_Unit::value_masle_bpm,
     maslt_Unit::value_masle_laps};

  maslt_Unit::Index maslt_Unit::fromValue ( Value value )
  {
    switch ( value )
    {
      case value_masle_km:         return index_masle_km;
      case value_masle_meters:     return index_masle_meters;
      case value_masle_minPerKm:   return index_masle_minPerKm;
      case value_masle_kmPerHour:  return index_masle_kmPerHour;
      case value_masle_miles:      return index_masle_miles;
      case value_masle_yards:      return index_masle_yards;
      case value_masle_feet:       return index_masle_feet;
      case value_masle_minPerMile: return index_masle_minPerMile;
      case value_masle_mph:        return index_masle_mph;
      case value_masle_bpm:        return index_masle_bpm;
      case value_masle_laps:       return index_masle_laps;
      default:                     throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    }

  }

  maslt_Unit::maslt_Unit ( int32_t value )
    : index(fromValue( Value( value ) ))
  {
  }

  maslt_Unit& maslt_Unit::operator++ ( )
  {
    if ( index == index_masle_laps ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index + 1 );
    return *this;
  }

  maslt_Unit& maslt_Unit::operator-- ( )
  {
    if ( index == index_masle_km ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index - 1 );
    return *this;
  }

  ::std::ostream& operator<< ( ::std::ostream&   stream,
                               const maslt_Unit& obj )
  {
    return stream << obj.getText();
  }

  ::std::istream& operator>> ( ::std::istream& stream,
                               maslt_Unit&     obj )
  {
    ::std::string text;
    stream >> text;
    obj = maslt_Unit( text );
    return stream;
  }

}
