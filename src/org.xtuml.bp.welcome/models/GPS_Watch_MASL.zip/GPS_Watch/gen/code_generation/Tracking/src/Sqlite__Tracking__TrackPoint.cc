//
// File: Sqlite__Tracking__TrackPoint.cc
//
#include "Sqlite__Tracking__TrackLog.hh"
#include "Sqlite__Tracking__TrackPoint.hh"
#include "Sqlite__Tracking__TrackPointPopulation.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__TrackPoint.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_TrackPoint::maslo_TrackPoint ( ::SWA::IdType           architectureId,
                                         int32_t                 masla_time,
                                         double                  masla_longitude,
                                         double                  masla_latitude,
                                         const ::SWA::Timestamp& masla_session_startTime )
      : architectureId(architectureId),
        masla_time(masla_time),
        masla_longitude(masla_longitude),
        masla_latitude(masla_latitude),
        masla_session_startTime(masla_session_startTime),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_TrackPoint::maslo_TrackPoint ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_time(),
        masla_longitude(),
        masla_latitude(),
        masla_session_startTime(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_TrackPoint::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_TrackPoint::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_TrackPointPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_TrackPoint::PrimaryKeyType maslo_TrackPoint::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_time, masla_session_startTime );
    }

    const maslo_TrackPoint::IndexKeyType_1 maslo_TrackPoint::get_index_1 ( )
    {
      return IndexKeyType_1( masla_time, masla_session_startTime );
    }

    void maslo_TrackPoint::link_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackLog> derivedrhs(rhs.downcast<maslo_TrackLog>());
      maslo_TrackPointPopulation::getPopulation().link_R1_is_start_of_TrackLog( ::SWA::ObjectPtr<maslo_TrackPoint>( this ), derivedrhs );
    }

    void maslo_TrackPoint::unlink_R1_is_start_of_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackLog> derivedrhs(rhs.downcast<maslo_TrackLog>());
      maslo_TrackPointPopulation::getPopulation().unlink_R1_is_start_of_TrackLog( ::SWA::ObjectPtr<maslo_TrackPoint>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> maslo_TrackPoint::navigate_R1_is_start_of_TrackLog ( ) const
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> self(const_cast<maslo_TrackPoint*>( this ));
      return maslo_TrackPointPopulation::getPopulation().navigate_R1_is_start_of_TrackLog( self );
    }

    ::std::size_t maslo_TrackPoint::count_R1_is_start_of_TrackLog ( ) const
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> self(const_cast<maslo_TrackPoint*>( this ));
      return maslo_TrackPointPopulation::getPopulation().count_R1_is_start_of_TrackLog( self );
    }

    void maslo_TrackPoint::link_R2_follows_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> derivedrhs(rhs.downcast<maslo_TrackPoint>());
      maslo_TrackPointPopulation::getPopulation().link_R2_follows_TrackPoint( ::SWA::ObjectPtr<maslo_TrackPoint>( this ), derivedrhs );
    }

    void maslo_TrackPoint::unlink_R2_follows_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> derivedrhs(rhs.downcast<maslo_TrackPoint>());
      maslo_TrackPointPopulation::getPopulation().unlink_R2_follows_TrackPoint( ::SWA::ObjectPtr<maslo_TrackPoint>( this ), derivedrhs );
    }

    void maslo_TrackPoint::link_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> derivedrhs(rhs.downcast<maslo_TrackPoint>());
      maslo_TrackPointPopulation::getPopulation().link_R2_preceeds_TrackPoint( ::SWA::ObjectPtr<maslo_TrackPoint>( this ), derivedrhs );
    }

    void maslo_TrackPoint::unlink_R2_preceeds_TrackPoint ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> derivedrhs(rhs.downcast<maslo_TrackPoint>());
      maslo_TrackPointPopulation::getPopulation().unlink_R2_preceeds_TrackPoint( ::SWA::ObjectPtr<maslo_TrackPoint>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> maslo_TrackPoint::navigate_R2_follows_TrackPoint ( ) const
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> self(const_cast<maslo_TrackPoint*>( this ));
      return maslo_TrackPointPopulation::getPopulation().navigate_R2_follows_TrackPoint( self );
    }

    ::std::size_t maslo_TrackPoint::count_R2_follows_TrackPoint ( ) const
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> self(const_cast<maslo_TrackPoint*>( this ));
      return maslo_TrackPointPopulation::getPopulation().count_R2_follows_TrackPoint( self );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackPoint> maslo_TrackPoint::navigate_R2_preceeds_TrackPoint ( ) const
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> self(const_cast<maslo_TrackPoint*>( this ));
      return maslo_TrackPointPopulation::getPopulation().navigate_R2_preceeds_TrackPoint( self );
    }

    ::std::size_t maslo_TrackPoint::count_R2_preceeds_TrackPoint ( ) const
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> self(const_cast<maslo_TrackPoint*>( this ));
      return maslo_TrackPointPopulation::getPopulation().count_R2_preceeds_TrackPoint( self );
    }

    void maslo_TrackPoint::link_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackLog> derivedrhs(rhs.downcast<maslo_TrackLog>());
      maslo_TrackPointPopulation::getPopulation().link_R3_is_last_for_TrackLog( ::SWA::ObjectPtr<maslo_TrackPoint>( this ), derivedrhs );
    }

    void maslo_TrackPoint::unlink_R3_is_last_for_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackLog> derivedrhs(rhs.downcast<maslo_TrackLog>());
      maslo_TrackPointPopulation::getPopulation().unlink_R3_is_last_for_TrackLog( ::SWA::ObjectPtr<maslo_TrackPoint>( this ), derivedrhs );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> maslo_TrackPoint::navigate_R3_is_last_for_TrackLog ( ) const
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> self(const_cast<maslo_TrackPoint*>( this ));
      return maslo_TrackPointPopulation::getPopulation().navigate_R3_is_last_for_TrackLog( self );
    }

    ::std::size_t maslo_TrackPoint::count_R3_is_last_for_TrackLog ( ) const
    {
      ::SWA::ObjectPtr<maslo_TrackPoint> self(const_cast<maslo_TrackPoint*>( this ));
      return maslo_TrackPointPopulation::getPopulation().count_R3_is_last_for_TrackLog( self );
    }

  }
}
