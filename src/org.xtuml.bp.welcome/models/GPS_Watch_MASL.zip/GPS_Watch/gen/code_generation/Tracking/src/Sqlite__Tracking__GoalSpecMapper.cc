//
// File: Sqlite__Tracking__GoalSpecMapper.cc
//
#include "Sqlite__Tracking__GoalSpec.hh"
#include "Sqlite__Tracking__GoalSpecMapper.hh"
#include "Sqlite__Tracking__GoalSpecMapperSql.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__GoalSpec.hh"
#include "boost/bind.hpp"
#include "boost/function.hpp"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/Criteria.hh"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSql.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ObjectSqlRepository.hh"
#include "sql/ResourceMonitorObserver.hh"
#include "sql/Util.hh"
#include <stdint.h>
#include <string>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_GoalSpecMapper::maslo_GoalSpecMapper ( )
      : ::SQL::ObjectMapper< ::masld_Tracking::maslo_GoalSpec,maslo_GoalSpec>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_Tracking::maslo_GoalSpec,maslo_GoalSpec> >( new maslo_GoalSpecSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_GoalSpecMapper::~maslo_GoalSpecMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> maslo_GoalSpecMapper::createInstance ( double                                      masla_minimum,
                                                                                               double                                      masla_maximum,
                                                                                               double                                      masla_span,
                                                                                               const ::masld_Tracking::maslt_GoalCriteria& masla_criteriaType,
                                                                                               const ::masld_Tracking::maslt_GoalSpan&     masla_spanType,
                                                                                               int32_t                                     masla_sequenceNumber,
                                                                                               const ::SWA::Timestamp&                     masla_session_startTime,
                                                                                               int32_t                                     masla_last_goal_ID )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_GoalSpec::PrimaryKeyType>::value_type( masla_sequenceNumber, masla_session_startTime ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_GoalSpec> instance(new maslo_GoalSpec(  uniqueId,
                     masla_minimum,
                     masla_maximum,
                     masla_span,
                     masla_criteriaType,
                     masla_spanType,
                     masla_sequenceNumber,
                     masla_session_startTime,
                     masla_last_goal_ID ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_GoalSpecMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> instance )
    {
      ::SQL::ObjectMapper< ::masld_Tracking::maslo_GoalSpec,maslo_GoalSpec>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_GoalSpec>()->getPrimaryKey() );
    }

    bool maslo_GoalSpecMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

    // MASL identifier find: (sequenceNumber = p1)
    ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> maslo_GoalSpecMapper::findOne_OPmasl_sequenceNumber_maslEQp1CP ( int32_t p1 )
    {
      PsBaseObjectPtr selectedObject;
      if ( allowInMemoryFind() )
      {
        ::boost::function<bool (maslo_GoalSpec*)> predicate = ::boost::bind( &::masld_Tracking::maslo_GoalSpec::findPredicate_OPmasl_sequenceNumber_maslEQp1CP, _1, p1 );
        selectOne( predicate, selectedObject );
      }
      else
      {
        ::SQL::Criteria sqlCriteria;

        const ::SQL::ObjectSql& GoalSpecSql = ::SQL::ObjectSqlRepository::getInstance().getObjectSql( "Tracking", "GoalSpec" );

        sqlCriteria.addFromClause( GoalSpecSql.getTableName() );

        ::std::string whereClause;
        whereClause += ::std::string( "(" ) + sqlGenerator->getColumnName( "sequenceNumber" ) + " = " + ::SQL::convertToColumnValue( p1 ) + ")";

        sqlCriteria.addAllColumns( GoalSpecSql.getTableName() );
        sqlCriteria.addWhereClause( whereClause );


        selectOne( sqlCriteria, selectedObject );
      }
      return selectedObject;
    }

  }
}
