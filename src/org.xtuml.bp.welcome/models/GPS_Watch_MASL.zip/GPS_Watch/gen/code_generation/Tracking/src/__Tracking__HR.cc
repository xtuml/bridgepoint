//
// File: __Tracking__HR.cc
//
#include "Tracking_OOA/__Tracking_terminators.hh"

namespace masld_Tracking
{
  maslb_HR& maslb_HR::getInstance ( )
  {
    static maslb_HR instance;
    return instance;
  }

  maslb_HR::maslb_HR ( )
    : override_masls_registerListener(&domain_masls_registerListener),
      override_masls_unregisterListener(&domain_masls_unregisterListener)
  {
  }

}
