//
// File: Sqlite__Tracking__GoalSpec.hh
//
#ifndef Sqlite_Tracking_Goal_Spec_hh
#define Sqlite_Tracking_Goal_Spec_hh

#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__GoalSpec.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_Goal;
  class maslo_WorkoutSession;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_GoalSpec
      : public ::masld_Tracking::maslo_GoalSpec
    {

      // Type definitions
      public:
        typedef ::boost::tuple<int32_t,::SWA::Timestamp> PrimaryKeyType;
        typedef ::boost::tuple<int32_t,::SWA::Timestamp> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_GoalSpec ( ::SWA::IdType architectureId );
        maslo_GoalSpec ( ::SWA::IdType                               architectureId,
                         double                                      masla_minimum,
                         double                                      masla_maximum,
                         double                                      masla_span,
                         const ::masld_Tracking::maslt_GoalCriteria& masla_criteriaType,
                         const ::masld_Tracking::maslt_GoalSpan&     masla_spanType,
                         int32_t                                     masla_sequenceNumber,
                         const ::SWA::Timestamp&                     masla_session_startTime,
                         int32_t                                     masla_last_goal_ID );


      // Setters for each object attribute
      public:
        virtual void set_masla_minimum ( double value )
        {
          this->masla_minimum = value;
          markAsModified();
        }
        virtual void set_masla_maximum ( double value )
        {
          this->masla_maximum = value;
          markAsModified();
        }
        virtual void set_masla_span ( double value )
        {
          this->masla_span = value;
          markAsModified();
        }
        virtual void set_masla_criteriaType ( const ::masld_Tracking::maslt_GoalCriteria& value )
        {
          this->masla_criteriaType = value;
          markAsModified();
        }
        virtual void set_masla_spanType ( const ::masld_Tracking::maslt_GoalSpan& value )
        {
          this->masla_spanType = value;
          markAsModified();
        }
        void set_masla_sequenceNumber ( int32_t value )
        {
          this->masla_sequenceNumber = value;
          markAsModified();
        }
        void set_masla_session_startTime ( const ::SWA::Timestamp& value )
        {
          this->masla_session_startTime = value;
          markAsModified();
        }
        virtual void set_masla_last_goal_ID ( int32_t value )
        {
          this->masla_last_goal_ID = value;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual double get_masla_minimum ( ) const { return masla_minimum; }
        virtual double get_masla_maximum ( ) const { return masla_maximum; }
        virtual double get_masla_span ( ) const { return masla_span; }
        virtual ::masld_Tracking::maslt_GoalCriteria get_masla_criteriaType ( ) const { return masla_criteriaType; }
        virtual ::masld_Tracking::maslt_GoalSpan get_masla_spanType ( ) const { return masla_spanType; }
        virtual int32_t get_masla_sequenceNumber ( ) const { return masla_sequenceNumber; }
        virtual ::SWA::Timestamp get_masla_session_startTime ( ) const { return masla_session_startTime; }
        virtual int32_t get_masla_last_goal_ID ( ) const { return masla_last_goal_ID; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Relationship Navigators
      public:
        virtual ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> > navigate_R9_specifies_Goal ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> navigate_R10_included_in_WorkoutSession ( ) const;


      // Relationship Counts
      public:
        virtual ::std::size_t count_R9_specifies_Goal ( ) const;
        virtual ::std::size_t count_R10_included_in_WorkoutSession ( ) const;


      // Relationship Linkers
      public:
        virtual void link_R9_specifies_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs );
        virtual void unlink_R9_specifies_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs );
        virtual void link_R10_included_in_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );
        virtual void unlink_R10_included_in_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        double masla_minimum;
        double masla_maximum;
        double masla_span;
        ::masld_Tracking::maslt_GoalCriteria masla_criteriaType;
        ::masld_Tracking::maslt_GoalSpan masla_spanType;
        int32_t masla_sequenceNumber;
        ::SWA::Timestamp masla_session_startTime;
        int32_t masla_last_goal_ID;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_Tracking_Goal_Spec_hh
