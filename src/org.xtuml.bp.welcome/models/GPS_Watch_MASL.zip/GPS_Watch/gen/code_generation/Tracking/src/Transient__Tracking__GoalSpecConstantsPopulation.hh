//
// File: Transient__Tracking__GoalSpecConstantsPopulation.hh
//
#ifndef Transient_Tracking_Goal_Spec_Constants_Population_hh
#define Transient_Tracking_Goal_Spec_Constants_Population_hh

#include "__Tracking__GoalSpecConstants.hh"
#include "__Tracking__GoalSpecConstantsPopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace transient
{
  namespace masld_Tracking
  {
    class maslo_GoalSpecConstantsPopulation
      : public TransientPopulation< ::masld_Tracking::maslo_GoalSpecConstants,::masld_Tracking::maslo_GoalSpecConstantsPopulation>
    {

      // Instance Creation
      private:
        maslo_GoalSpecConstantsPopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> createInstance ( int32_t masla_id,
                                                                                              int32_t masla_GoalSpecOrigin );


      // Singleton Registration
      public:
        static maslo_GoalSpecConstantsPopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> > masla_id_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> instance );
      protected:
        bool exists_masla_id ( int32_t masla_id ) const;


    };
  }
}
#endif // Transient_Tracking_Goal_Spec_Constants_Population_hh
