//
// File: Transient__Tracking__HeartRateSamplePopulation.hh
//
#ifndef Transient_Tracking_Heart_Rate_Sample_Population_hh
#define Transient_Tracking_Heart_Rate_Sample_Population_hh

#include "__Tracking__HeartRateSample.hh"
#include "__Tracking__HeartRateSamplePopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace transient
{
  namespace masld_Tracking
  {
    class maslo_HeartRateSamplePopulation
      : public TransientPopulation< ::masld_Tracking::maslo_HeartRateSample,::masld_Tracking::maslo_HeartRateSamplePopulation>
    {

      // Instance Creation
      private:
        maslo_HeartRateSamplePopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> createInstance ( int32_t                 masla_heartRate,
                                                                                            int32_t                 masla_time,
                                                                                            const ::SWA::Timestamp& masla_session_startTime );


      // Singleton Registration
      public:
        static maslo_HeartRateSamplePopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple<int32_t,::SWA::Timestamp>,::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> > masla_timemasla_session_startTime_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> instance );
      protected:
        bool exists_masla_timemasla_session_startTime ( int32_t                 masla_time,
                                                        const ::SWA::Timestamp& masla_session_startTime ) const;


    };
  }
}
#endif // Transient_Tracking_Heart_Rate_Sample_Population_hh
