//
// File: Transient__Tracking__GoalSpecConstants.cc
//
#include "Transient__Tracking__GoalSpecConstants.hh"
#include <stdint.h>

namespace transient
{
  namespace masld_Tracking
  {
    maslo_GoalSpecConstants::maslo_GoalSpecConstants ( int32_t masla_id,
                                                       int32_t masla_GoalSpecOrigin )
      : architectureId(getNextArchId()),
        masla_id(masla_id),
        masla_GoalSpecOrigin(masla_GoalSpecOrigin)
    {
    }

  }
}
