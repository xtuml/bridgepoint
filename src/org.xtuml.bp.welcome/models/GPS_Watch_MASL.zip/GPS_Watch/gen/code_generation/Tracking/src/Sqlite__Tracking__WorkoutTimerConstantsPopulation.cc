//
// File: Sqlite__Tracking__WorkoutTimerConstantsPopulation.cc
//
#include "Sqlite__Tracking__WorkoutTimerConstantsPopulation.hh"
#include "__Tracking__WorkoutTimerConstants.hh"
#include "boost/bind.hpp"
#include "boost/signals2.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_WorkoutTimerConstantsPopulation::maslo_WorkoutTimerConstantsPopulation ( )
    {
    }

    maslo_WorkoutTimerConstantsPopulation::~maslo_WorkoutTimerConstantsPopulation ( )
    {
    }

    void maslo_WorkoutTimerConstantsPopulation::initialise ( )
    {
      mapper->initialise();
    }

    maslo_WorkoutTimerConstantsPopulation& maslo_WorkoutTimerConstantsPopulation::getPopulation ( )
    {
      static maslo_WorkoutTimerConstantsPopulation population;
      return population;
    }

    bool maslo_WorkoutTimerConstantsPopulation::registered = maslo_WorkoutTimerConstantsPopulation::registerSingleton( &maslo_WorkoutTimerConstantsPopulation::getPopulation );

    ::boost::signals2::connection maslo_WorkoutTimerConstantsPopulation::initialised = ::SWA::Process::getInstance().registerInitialisingListener( ::boost::bind( &maslo_WorkoutTimerConstantsPopulation::initialise, ::boost::bind( &maslo_WorkoutTimerConstantsPopulation::getPopulation ) ) );

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimerConstants> maslo_WorkoutTimerConstantsPopulation::findObject ( const ::SWA::IdType& obj )
    {
      return mapper->find( obj );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimerConstants> > maslo_WorkoutTimerConstantsPopulation::findObject ( const MapperType::PsObjectIdSet& obj )
    {
      MapperType::PsObjectPtrSet objectSet = mapper->find( obj );
      return ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimerConstants> >( objectSet.begin(), objectSet.end(), true );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimerConstants> maslo_WorkoutTimerConstantsPopulation::createInstance ( int32_t masla_id,
                                                                                                                             int32_t masla_timerPeriod )
    {
      return mapper->createInstance( masla_id, masla_timerPeriod );
    }

    void maslo_WorkoutTimerConstantsPopulation::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimerConstants> instance )
    {
      {
      }
      mapper->deleteInstance( instance );
    }

  }
}
