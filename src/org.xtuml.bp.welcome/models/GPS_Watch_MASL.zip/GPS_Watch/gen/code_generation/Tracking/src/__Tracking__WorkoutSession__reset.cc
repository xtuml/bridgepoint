//
// File: __Tracking__WorkoutSession__reset.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__Achievement.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/bind.hpp"
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Stack.hh"
#include "swa/navigate.hh"

namespace masld_Tracking
{
  void maslo_WorkoutSession::masls_reset ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_WorkoutSession, serviceId_masls_reset);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(9);
      {

        // workoutTimer : instance of WorkoutTimer;
        ::SWA::ObjectPtr<maslo_WorkoutTimer> maslv_workoutTimer;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_workoutTimer(0, maslv_workoutTimer);

        // trackLog : instance of TrackLog;
        ::SWA::ObjectPtr<maslo_TrackLog> maslv_trackLog;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_trackLog(1, maslv_trackLog);

        // goalSpecs : set of instance of GoalSpec;
        ::SWA::Set< ::SWA::ObjectPtr<maslo_GoalSpec> > maslv_goalSpecs;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_goalSpecs(2, maslv_goalSpecs);

        // executingGoal : instance of Goal;
        ::SWA::ObjectPtr<maslo_Goal> maslv_executingGoal;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_executingGoal(3, maslv_executingGoal);

        // openAchievement : instance of Achievement;
        ::SWA::ObjectPtr<maslo_Achievement> maslv_openAchievement;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_openAchievement(4, maslv_openAchievement);

        // goals : set of instance of Goal;
        ::SWA::Set< ::SWA::ObjectPtr<maslo_Goal> > maslv_goals;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_goals(5, maslv_goals);

        // achievements : set of instance of Achievement;
        ::SWA::Set< ::SWA::ObjectPtr<maslo_Achievement> > maslv_achievements;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_achievements(6, maslv_achievements);

        // workoutTimer := this -> R8.is_timed_by.WorkoutTimer;
        {
          ::SWA::Stack::ExecutingStatement statement(14);
          maslv_workoutTimer = ::SWA::navigate_one<maslo_WorkoutTimer>( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), ::boost::bind( &maslo_WorkoutSession::navigate_R8_is_timed_by_WorkoutTimer, _1 ) );
        }

        // workoutTimer.initialize()
        {
          ::SWA::Stack::ExecutingStatement statement(15);
          maslv_workoutTimer->masls_initialize();
        }

        // trackLog := this -> R4.captures_path_in.TrackLog;
        {
          ::SWA::Stack::ExecutingStatement statement(18);
          maslv_trackLog = ::SWA::navigate_one<maslo_TrackLog>( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), ::boost::bind( &maslo_WorkoutSession::navigate_R4_captures_path_in_TrackLog, _1 ) );
        }

        // trackLog.clearTrackPoints()
        {
          ::SWA::Stack::ExecutingStatement statement(19);
          maslv_trackLog->masls_clearTrackPoints();
        }

        // trackLog.clearLapMarkers()
        {
          ::SWA::Stack::ExecutingStatement statement(20);
          maslv_trackLog->masls_clearLapMarkers();
        }

        // goalSpecs := this -> R10.includes.GoalSpec;
        {
          ::SWA::Stack::ExecutingStatement statement(23);
          maslv_goalSpecs = ::SWA::navigate_many<maslo_GoalSpec>( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), ::boost::bind( &maslo_WorkoutSession::navigate_R10_includes_GoalSpec, _1 ) );
        }

        // for goalSpec in goalSpecs'elements loop ...
        {
          ::SWA::Stack::ExecutingStatement statement(24);
          ::SWA::Set< ::SWA::ObjectPtr<maslo_GoalSpec> > collection = maslv_goalSpecs;
          for ( ::SWA::Set< ::SWA::ObjectPtr<maslo_GoalSpec> >::const_iterator i = collection.begin(); i != collection.end(); ++i )
          {
            const ::SWA::ObjectPtr<maslo_GoalSpec>& maslv_goalSpec = *i;
            ::SWA::Stack::DeclareLocalVariable pm_maslv_goalSpec(7, maslv_goalSpec);

            // unlink this R10.includes.GoalSpec  goalSpec;
            {
              ::SWA::Stack::ExecutingStatement statement(25);
              ::SWA::ObjectPtr<maslo_WorkoutSession>( this )->unlink_R10_includes_GoalSpec( maslv_goalSpec );
            }

            // delete goalSpec;
            {
              ::SWA::Stack::ExecutingStatement statement(26);
              maslv_goalSpec.deleteInstance();
            }
          }
        }

        // executingGoal := this -> R11.is_currently_executing.Goal;
        {
          ::SWA::Stack::ExecutingStatement statement(30);
          maslv_executingGoal = ::SWA::navigate_one<maslo_Goal>( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), ::boost::bind( &maslo_WorkoutSession::navigate_R11_is_currently_executing_Goal, _1 ) );
        }

        // if (null /= executingGoal) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(31);
          if ( ::SWA::Null != maslv_executingGoal )
          {

            // openAchievement := executingGoal -> R14.has_open.Achievement;
            {
              ::SWA::Stack::ExecutingStatement statement(32);
              maslv_openAchievement = ::SWA::navigate_one<maslo_Achievement>( maslv_executingGoal, ::boost::bind( &maslo_Goal::navigate_R14_has_open_Achievement, _1 ) );
            }

            // if (null /= openAchievement) then ...
            {
              ::SWA::Stack::ExecutingStatement statement(33);
              if ( ::SWA::Null != maslv_openAchievement )
              {

                // unlink openAchievement R14.is_open_for.Goal  executingGoal;
                {
                  ::SWA::Stack::ExecutingStatement statement(34);
                  maslv_openAchievement->unlink_R14_is_open_for_Goal( maslv_executingGoal );
                }

                // delete openAchievement;
                {
                  ::SWA::Stack::ExecutingStatement statement(35);
                  maslv_openAchievement.deleteInstance();
                }
              }
            }

            // unlink this R11.is_currently_executing.Goal  executingGoal;
            {
              ::SWA::Stack::ExecutingStatement statement(37);
              ::SWA::ObjectPtr<maslo_WorkoutSession>( this )->unlink_R11_is_currently_executing_Goal( maslv_executingGoal );
            }

            // delete executingGoal;
            {
              ::SWA::Stack::ExecutingStatement statement(38);
              maslv_executingGoal.deleteInstance();
            }
          }
        }

        // goals := this -> R13.has_executed.Goal;
        {
          ::SWA::Stack::ExecutingStatement statement(42);
          maslv_goals = ::SWA::navigate_many<maslo_Goal>( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), ::boost::bind( &maslo_WorkoutSession::navigate_R13_has_executed_Goal, _1 ) );
        }

        // for goal in goals'elements loop ...
        {
          ::SWA::Stack::ExecutingStatement statement(43);
          ::SWA::Set< ::SWA::ObjectPtr<maslo_Goal> > collection = maslv_goals;
          for ( ::SWA::Set< ::SWA::ObjectPtr<maslo_Goal> >::const_iterator i = collection.begin(); i != collection.end(); ++i )
          {
            const ::SWA::ObjectPtr<maslo_Goal>& maslv_goal = *i;
            ::SWA::Stack::DeclareLocalVariable pm_maslv_goal(8, maslv_goal);

            // achievements := goal -> R12.has_recorded.Achievement;
            {
              ::SWA::Stack::ExecutingStatement statement(44);
              maslv_achievements = ::SWA::navigate_many<maslo_Achievement>( maslv_goal, ::boost::bind( &maslo_Goal::navigate_R12_has_recorded_Achievement, _1 ) );
            }

            // for achievement in achievements'elements loop ...
            {
              ::SWA::Stack::ExecutingStatement statement(45);
              ::SWA::Set< ::SWA::ObjectPtr<maslo_Achievement> > collection = maslv_achievements;
              for ( ::SWA::Set< ::SWA::ObjectPtr<maslo_Achievement> >::const_iterator i = collection.begin(); i != collection.end(); ++i )
              {
                const ::SWA::ObjectPtr<maslo_Achievement>& maslv_achievement = *i;
                ::SWA::Stack::DeclareLocalVariable pm_maslv_achievement(9, maslv_achievement);

                // unlink goal R12.has_recorded.Achievement  achievement;
                {
                  ::SWA::Stack::ExecutingStatement statement(46);
                  maslv_goal->unlink_R12_has_recorded_Achievement( maslv_achievement );
                }

                // delete achievement;
                {
                  ::SWA::Stack::ExecutingStatement statement(47);
                  maslv_achievement.deleteInstance();
                }
              }
            }

            // unlink this R13.has_executed.Goal  goal;
            {
              ::SWA::Stack::ExecutingStatement statement(49);
              ::SWA::ObjectPtr<maslo_WorkoutSession>( this )->unlink_R13_has_executed_Goal( maslv_goal );
            }

            // delete goal;
            {
              ::SWA::Stack::ExecutingStatement statement(50);
              maslv_goal.deleteInstance();
            }
          }
        }

        // this.accumulatedDistance := 0.0;
        {
          ::SWA::Stack::ExecutingStatement statement(54);
          ::SWA::ObjectPtr<maslo_WorkoutSession>( this )->set_masla_accumulatedDistance( 0.0 );
        }

        // this.clearHeartRateSamples()
        {
          ::SWA::Stack::ExecutingStatement statement(55);
          ::SWA::ObjectPtr<maslo_WorkoutSession>( this )->masls_clearHeartRateSamples();
        }
      }
    }
  }

}
