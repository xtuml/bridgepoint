//
// File: Sqlite__Tracking__DisplayMapper.cc
//
#include "Sqlite__Tracking__Display.hh"
#include "Sqlite__Tracking__DisplayMapper.hh"
#include "Sqlite__Tracking__DisplayMapperSql.hh"
#include "__Tracking__Display.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_DisplayMapper::maslo_DisplayMapper ( )
      : ::SQL::ObjectMapper< ::masld_Tracking::maslo_Display,maslo_Display>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_Tracking::maslo_Display,maslo_Display> >( new maslo_DisplaySqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_DisplayMapper::~maslo_DisplayMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> maslo_DisplayMapper::createInstance ( const ::SWA::Timestamp&               masla_session_startTime,
                                                                                             ::masld_Tracking::maslo_Display::Type currentState )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_Display::PrimaryKeyType>::value_type( masla_session_startTime ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_Display> instance(new maslo_Display(  uniqueId,
                    masla_session_startTime,
                    currentState ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_DisplayMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> instance )
    {
      ::SQL::ObjectMapper< ::masld_Tracking::maslo_Display,maslo_Display>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_Display>()->getPrimaryKey() );
    }

    bool maslo_DisplayMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
