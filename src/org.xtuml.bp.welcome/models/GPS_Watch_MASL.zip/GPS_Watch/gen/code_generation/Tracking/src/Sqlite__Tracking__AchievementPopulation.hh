//
// File: Sqlite__Tracking__AchievementPopulation.hh
//
#ifndef Sqlite_Tracking_Achievement_Population_hh
#define Sqlite_Tracking_Achievement_Population_hh

#include "Sqlite__Tracking__Achievement.hh"
#include "Sqlite__Tracking__AchievementMapper.hh"
#include "Sqlite__Tracking__R12Mapper.hh"
#include "Sqlite__Tracking__R14Mapper.hh"
#include "__Tracking__Achievement.hh"
#include "__Tracking__AchievementPopulation.hh"
#include "boost/signals2.hpp"
#include <cstddef>
#include "sql/Population.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_Goal;
  }
}
namespace masld_Tracking
{
  class maslo_Goal;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_AchievementPopulation
      : public ::SQL::SqlPopulation< ::masld_Tracking::maslo_Achievement,maslo_Achievement,maslo_AchievementMapper,::masld_Tracking::maslo_AchievementPopulation>
    {

      // Constructors and Destructors
      private:
        maslo_AchievementPopulation ( );
        ~maslo_AchievementPopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> createInstance ( int32_t                 masla_startTime,
                                                                                        int32_t                 masla_endTime,
                                                                                        const ::SWA::Timestamp& masla_session_startTime,
                                                                                        int32_t                 masla_goal_ID,
                                                                                        int32_t                 masla_spec_sequenceNumber );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> instance );


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Relationship Counts
      public:
        ::std::size_t count_R12_specifies_achievement_of_Goal ( const ::SWA::ObjectPtr<maslo_Achievement>& lhs );
        ::std::size_t count_R14_is_open_for_Goal ( const ::SWA::ObjectPtr<maslo_Achievement>& lhs );


      // Relationship Links
      public:
        void link_R12_specifies_achievement_of_Goal ( const ::SWA::ObjectPtr<maslo_Achievement>& lhs,
                                                      const ::SWA::ObjectPtr<maslo_Goal>&        rhs );
        void unlink_R12_specifies_achievement_of_Goal ( const ::SWA::ObjectPtr<maslo_Achievement>& lhs,
                                                        const ::SWA::ObjectPtr<maslo_Goal>&        rhs );
        void link_R14_is_open_for_Goal ( const ::SWA::ObjectPtr<maslo_Achievement>& lhs,
                                         const ::SWA::ObjectPtr<maslo_Goal>&        rhs );
        void unlink_R14_is_open_for_Goal ( const ::SWA::ObjectPtr<maslo_Achievement>& lhs,
                                           const ::SWA::ObjectPtr<maslo_Goal>&        rhs );


      // Relationship Navigations
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> navigate_R12_specifies_achievement_of_Goal ( const ::SWA::ObjectPtr<maslo_Achievement>& lhs );
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> navigate_R14_is_open_for_Goal ( const ::SWA::ObjectPtr<maslo_Achievement>& lhs );


      // Singleton Registration
      public:
        static maslo_AchievementPopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;
        RelationshipR12Mapper& R12Mapper;
        RelationshipR14Mapper& R14Mapper;


    };
  }
}
#endif // Sqlite_Tracking_Achievement_Population_hh
