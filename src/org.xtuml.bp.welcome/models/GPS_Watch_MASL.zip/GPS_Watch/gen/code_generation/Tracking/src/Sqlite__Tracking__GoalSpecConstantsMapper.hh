//
// File: Sqlite__Tracking__GoalSpecConstantsMapper.hh
//
#ifndef Sqlite_Tracking_Goal_Spec_Constants_Mapper_hh
#define Sqlite_Tracking_Goal_Spec_Constants_Mapper_hh

#include "Sqlite__Tracking__GoalSpecConstants.hh"
#include "__Tracking__GoalSpecConstants.hh"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_GoalSpecConstantsMapper
      : public ::SQL::ObjectMapper< ::masld_Tracking::maslo_GoalSpecConstants,maslo_GoalSpecConstants>
    {

      // Instance creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> createInstance ( int32_t masla_id,
                                                                                              int32_t masla_GoalSpecOrigin );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> instance );
      protected:
        virtual bool doPostInit ( );


      // Constructors and Destructors
      public:
        maslo_GoalSpecConstantsMapper ( );
        virtual ~maslo_GoalSpecConstantsMapper ( );


      // Attributes
      private:
        ::boost::unordered_set<maslo_GoalSpecConstants::PrimaryKeyType> primarykey_cache;


    };
  }
}
#endif // Sqlite_Tracking_Goal_Spec_Constants_Mapper_hh
