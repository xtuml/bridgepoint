//
// File: __Tracking__GoalAchievement.cc
//
#include "__Tracking__GoalAchievement.hh"
#include "__Tracking__GoalAchievementPopulation.hh"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  ::SWA::ObjectPtr<maslo_GoalAchievement> maslo_GoalAchievement::getInstance ( ::SWA::IdType id )
  {
    return maslo_GoalAchievementPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_GoalAchievement::getNextArchId ( )
  {
    return maslo_GoalAchievementPopulation::getSingleton().getNextArchId();
  }

  maslo_GoalAchievement::maslo_GoalAchievement ( )
    : isDeletedFlag()
  {
  }

  maslo_GoalAchievement::~maslo_GoalAchievement ( )
  {
  }

  ::SWA::ObjectPtr<maslo_GoalAchievement> maslo_GoalAchievement::createInstance ( int32_t masla_id,
                                                                                  int32_t masla_evaluationPeriod )
  {
    return maslo_GoalAchievementPopulation::getSingleton().createInstance( masla_id, masla_evaluationPeriod );
  }

  void maslo_GoalAchievement::deleteInstance ( )
  {
    maslo_GoalAchievementPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_GoalAchievement>( this ) );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_GoalAchievement::getPopulationSize ( )
  {
    return maslo_GoalAchievementPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_GoalAchievement> > maslo_GoalAchievement::findAll ( )
  {
    return maslo_GoalAchievementPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_GoalAchievement> maslo_GoalAchievement::findOne ( )
  {
    return maslo_GoalAchievementPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_GoalAchievement> maslo_GoalAchievement::findOnly ( )
  {
    return maslo_GoalAchievementPopulation::getSingleton().findOnly();
  }

  ::std::ostream& operator<< ( ::std::ostream&              stream,
                               const maslo_GoalAchievement& obj )
  {
    stream << "(";
    stream << obj.get_masla_id();
    stream << ",";
    stream << obj.get_masla_evaluationPeriod();
    stream << ")";
    return stream;
  }

}
