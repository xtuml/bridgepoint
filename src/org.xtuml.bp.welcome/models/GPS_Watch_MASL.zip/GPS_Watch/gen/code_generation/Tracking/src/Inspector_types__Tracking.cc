//
// File: Inspector_types__Tracking.cc
//
#include "Tracking_OOA/__Tracking_types.hh"
#include "inspector/BufferedIO.hh"

namespace Inspector
{
  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslt_GoalCriteria> ( const ::masld_Tracking::maslt_GoalCriteria& value )
  {
    write( static_cast<int>( value.getIndex() ) );
  }

  template<>
  void BufferedInputStream::read< ::masld_Tracking::maslt_GoalCriteria> ( ::masld_Tracking::maslt_GoalCriteria& value )
  {
    int index;
    read( index );
    value = ::masld_Tracking::maslt_GoalCriteria( ::masld_Tracking::maslt_GoalCriteria::Index( index ) );
  }

  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslt_GoalDisposition> ( const ::masld_Tracking::maslt_GoalDisposition& value )
  {
    write( static_cast<int>( value.getIndex() ) );
  }

  template<>
  void BufferedInputStream::read< ::masld_Tracking::maslt_GoalDisposition> ( ::masld_Tracking::maslt_GoalDisposition& value )
  {
    int index;
    read( index );
    value = ::masld_Tracking::maslt_GoalDisposition( ::masld_Tracking::maslt_GoalDisposition::Index( index ) );
  }

  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslt_GoalSpan> ( const ::masld_Tracking::maslt_GoalSpan& value )
  {
    write( static_cast<int>( value.getIndex() ) );
  }

  template<>
  void BufferedInputStream::read< ::masld_Tracking::maslt_GoalSpan> ( ::masld_Tracking::maslt_GoalSpan& value )
  {
    int index;
    read( index );
    value = ::masld_Tracking::maslt_GoalSpan( ::masld_Tracking::maslt_GoalSpan::Index( index ) );
  }

  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslt_Indicator> ( const ::masld_Tracking::maslt_Indicator& value )
  {
    write( static_cast<int>( value.getIndex() ) );
  }

  template<>
  void BufferedInputStream::read< ::masld_Tracking::maslt_Indicator> ( ::masld_Tracking::maslt_Indicator& value )
  {
    int index;
    read( index );
    value = ::masld_Tracking::maslt_Indicator( ::masld_Tracking::maslt_Indicator::Index( index ) );
  }

  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslt_Unit> ( const ::masld_Tracking::maslt_Unit& value )
  {
    write( static_cast<int>( value.getIndex() ) );
  }

  template<>
  void BufferedInputStream::read< ::masld_Tracking::maslt_Unit> ( ::masld_Tracking::maslt_Unit& value )
  {
    int index;
    read( index );
    value = ::masld_Tracking::maslt_Unit( ::masld_Tracking::maslt_Unit::Index( index ) );
  }

}
