//
// File: Transient__Location__DistancePopulation.hh
//
#ifndef Transient_Location_Distance_Population_hh
#define Transient_Location_Distance_Population_hh

#include "__Location__Distance.hh"
#include "__Location__DistancePopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace transient
{
  namespace masld_Location
  {
    class maslo_DistancePopulation
      : public TransientPopulation< ::masld_Location::maslo_Distance,::masld_Location::maslo_DistancePopulation>
    {

      // Instance Creation
      private:
        maslo_DistancePopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> createInstance ( int32_t masla_id,
                                                                                     double  masla_kmPerDegree );


      // Singleton Registration
      public:
        static maslo_DistancePopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_Location::maslo_Distance> > masla_id_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> instance );
      protected:
        bool exists_masla_id ( int32_t masla_id ) const;


    };
  }
}
#endif // Transient_Location_Distance_Population_hh
