//
// File: __Location__getDistance.cc
//
#include "Location_OOA/__Location_interface.hh"
#include "Location_OOA/__Location_services.hh"
#include "__Location__Distance.hh"
#include "__Location_private_services.hh"
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_Location
{
  void masls_getDistance ( double& maslp_result,
                           double  maslp_fromLat,
                           double  maslp_fromLong,
                           double  maslp_toLat,
                           double  maslp_toLong )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_getDistance);
      ::SWA::Stack::DeclareParameter pm_maslp_result(maslp_result);
      ::SWA::Stack::DeclareParameter pm_maslp_fromLat(maslp_fromLat);
      ::SWA::Stack::DeclareParameter pm_maslp_fromLong(maslp_fromLong);
      ::SWA::Stack::DeclareParameter pm_maslp_toLat(maslp_toLat);
      ::SWA::Stack::DeclareParameter pm_maslp_toLong(maslp_toLong);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(11);
      {

        // distance : instance of Distance;
        ::SWA::ObjectPtr<maslo_Distance> maslv_distance;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_distance(0, maslv_distance);

        // deltaLat : real;
        double maslv_deltaLat = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_deltaLat(1, maslv_deltaLat);

        // deltaLong : real;
        double maslv_deltaLong = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_deltaLong(2, maslv_deltaLong);

        // sumSquares : real;
        double maslv_sumSquares = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_sumSquares(3, maslv_sumSquares);

        // sqrtSum : real;
        double maslv_sqrtSum = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_sqrtSum(4, maslv_sqrtSum);

        // Distance.initialize()
        {
          ::SWA::Stack::ExecutingStatement statement(15);
          maslo_Distance::masls_initialize();
        }

        // distance := find_one Distance ();
        {
          ::SWA::Stack::ExecutingStatement statement(16);
          maslv_distance = maslo_Distance::findOne();
        }

        // deltaLat := (toLat - fromLat);
        {
          ::SWA::Stack::ExecutingStatement statement(17);
          maslv_deltaLat = maslp_toLat - maslp_fromLat;
        }

        // deltaLong := (toLong - fromLong);
        {
          ::SWA::Stack::ExecutingStatement statement(18);
          maslv_deltaLong = maslp_toLong - maslp_fromLong;
        }

        // sumSquares := ((deltaLat * deltaLat) + (deltaLong * deltaLong));
        {
          ::SWA::Stack::ExecutingStatement statement(19);
          maslv_sumSquares = maslv_deltaLat * maslv_deltaLat + maslv_deltaLong * maslv_deltaLong;
        }

        // sqrtSum := Location::sqrt(sumSquares);
        {
          ::SWA::Stack::ExecutingStatement statement(20);
          maslv_sqrtSum = masls_sqrt( maslv_sumSquares );
        }

        // result := ((sqrtSum * distance.kmPerDegree) * 1000);
        {
          ::SWA::Stack::ExecutingStatement statement(21);
          maslp_result = maslv_sqrtSum * maslv_distance->get_masla_kmPerDegree() * 1000ll;
        }
      }
    }
  }

  const bool localServiceRegistration_masls_getDistance = interceptor_masls_getDistance::instance().registerLocal( &masls_getDistance );

}
