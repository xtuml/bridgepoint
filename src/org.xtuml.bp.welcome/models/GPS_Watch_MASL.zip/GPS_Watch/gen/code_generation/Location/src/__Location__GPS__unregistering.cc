//
// File: __Location__GPS__unregistering.cc
//
#include "LOG_OOA/__LOG_services.hh"
#include "Location_OOA/__Location.hh"
#include "Location_OOA/__Location_interface.hh"
#include "__Location__GPS.hh"
#include "boost/shared_ptr.hpp"
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"
#include "swa/types.hh"

namespace masld_Location
{
  void maslo_GPS::state_maslst_unregistering ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_GPS, stateId_maslst_unregistering);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // cancel this.timer;
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          ::SWA::EventTimers::getInstance().cancelTimer( ::SWA::ObjectPtr<maslo_GPS>( this )->get_masla_timer() );
        }

        // LOG::LogInfo("Location listener unregistered.")
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          ::masld_LOG::interceptor_masls_LogInfo::instance().callService()( ::SWA::String( "Location listener unregistered." ) );
        }

        // generate GPS.unregisterComplete () to this;
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          ::SWA::Process::getInstance().getEventQueue().addEvent( ::SWA::ObjectPtr<maslo_GPS>( this )->create_maslo_GPS_maslev_unregisterComplete( objectId_maslo_GPS, getArchitectureId() ) );
        }
      }
    }
  }

}
