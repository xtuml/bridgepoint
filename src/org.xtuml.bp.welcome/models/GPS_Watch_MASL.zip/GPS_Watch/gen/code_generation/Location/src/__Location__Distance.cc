//
// File: __Location__Distance.cc
//
#include "__Location__Distance.hh"
#include "__Location__DistancePopulation.hh"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Location
{
  ::SWA::ObjectPtr<maslo_Distance> maslo_Distance::getInstance ( ::SWA::IdType id )
  {
    return maslo_DistancePopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_Distance::getNextArchId ( )
  {
    return maslo_DistancePopulation::getSingleton().getNextArchId();
  }

  maslo_Distance::maslo_Distance ( )
    : isDeletedFlag()
  {
  }

  maslo_Distance::~maslo_Distance ( )
  {
  }

  ::SWA::ObjectPtr<maslo_Distance> maslo_Distance::createInstance ( int32_t masla_id,
                                                                    double  masla_kmPerDegree )
  {
    return maslo_DistancePopulation::getSingleton().createInstance( masla_id, masla_kmPerDegree );
  }

  void maslo_Distance::deleteInstance ( )
  {
    maslo_DistancePopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_Distance>( this ) );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_Distance::getPopulationSize ( )
  {
    return maslo_DistancePopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_Distance> > maslo_Distance::findAll ( )
  {
    return maslo_DistancePopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_Distance> maslo_Distance::findOne ( )
  {
    return maslo_DistancePopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_Distance> maslo_Distance::findOnly ( )
  {
    return maslo_DistancePopulation::getSingleton().findOnly();
  }

  ::std::ostream& operator<< ( ::std::ostream&       stream,
                               const maslo_Distance& obj )
  {
    stream << "(";
    stream << obj.get_masla_id();
    stream << ",";
    stream << obj.get_masla_kmPerDegree();
    stream << ")";
    return stream;
  }

}
