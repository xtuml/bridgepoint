//
// File: MetaData__Location.cc
//
#include "Location_OOA/__Location.hh"
#include "Location_OOA/__Location_interface.hh"
#include "__Location__Distance.hh"
#include "__Location__GPS.hh"
#include "__Location__simulatedGPS.hh"
#include "metadata/MetaData.hh"
#include "swa/Domain.hh"
#include <vector>

namespace 
{
  namespace init_masld_Location
  {
    ::SWA::ServiceMetaData get_masls_getLocation_MetaData ( );
    ::SWA::ServiceMetaData get_masls_getDistance_MetaData ( );
    ::SWA::ServiceMetaData get_masls_registerListener_MetaData ( );
    ::SWA::ServiceMetaData get_masls_unregisterListener_MetaData ( );
    ::SWA::ServiceMetaData get_masls_sqrt_MetaData ( );
    namespace maslo_Distance
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( );
    }
    namespace maslo_GPS
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( );
      ::SWA::StateMetaData get_maslst_idle_MetaData ( );
      ::SWA::StateMetaData get_maslst_locating_MetaData ( );
      ::SWA::StateMetaData get_maslst_registeringListener_MetaData ( );
      ::SWA::StateMetaData get_maslst_unregistering_MetaData ( );
      ::SWA::EventMetaData get_maslev_tick_MetaData ( );
      ::SWA::EventMetaData get_maslev_registeringComplete_MetaData ( );
      ::SWA::EventMetaData get_maslev_registerListener_MetaData ( );
      ::SWA::EventMetaData get_maslev_unregisterListener_MetaData ( );
      ::SWA::EventMetaData get_maslev_unregisterComplete_MetaData ( );
    }
    namespace maslo_simulatedGPS
    {
      ::SWA::ObjectMetaData getMetaData ( );
      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( );
    }
    ::SWA::DomainMetaData initDomainMetaData ( )
    {
      ::SWA::DomainMetaData domain(::masld_Location::getDomain().getId(), "Location", false);
      domain.addService( get_masls_getLocation_MetaData() );
      domain.addService( get_masls_getDistance_MetaData() );
      domain.addService( get_masls_registerListener_MetaData() );
      domain.addService( get_masls_unregisterListener_MetaData() );
      domain.addService( get_masls_sqrt_MetaData() );
      domain.addObject( maslo_Distance::getMetaData() );
      domain.addObject( maslo_GPS::getMetaData() );
      domain.addObject( maslo_simulatedGPS::getMetaData() );
      return domain;
    }

    ::SWA::DomainMetaData& getDomainMetaData ( )
    {
      static ::SWA::DomainMetaData domain = initDomainMetaData();
      return domain;
    }

    bool registered = ::SWA::ProcessMetaData::getProcess().addDomain( ::masld_Location::getDomain().getId(), &getDomainMetaData );

    ::SWA::ServiceMetaData get_masls_getLocation_MetaData ( )
    {
      int lines[] = { 4,
     7,
     8,
     9,
     10};
      ::SWA::ServiceMetaData service(::masld_Location::serviceId_masls_getLocation, ::SWA::ServiceMetaData::Domain, "getLocation", ::std::vector<int>( lines, lines + 5 ), "getLocation.svc", "e37bdb50c2b41e785c988d3e47793c2b");
      service.addParameter( ::SWA::ParameterMetaData( "latitude", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), true ) );
      service.addParameter( ::SWA::ParameterMetaData( "longitude", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), true ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "gps", "instance of GPS", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Location::getDomain().getId(), ::masld_Location::objectId_maslo_GPS ) ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_getDistance_MetaData ( )
    {
      int lines[] = { 11,
     15,
     16,
     17,
     18,
     19,
     20,
     21};
      ::SWA::ServiceMetaData service(::masld_Location::serviceId_masls_getDistance, ::SWA::ServiceMetaData::Domain, "getDistance", ::std::vector<int>( lines, lines + 8 ), "getDistance.svc", "cb2eee9d9969215603f6fc3fc26a16ab");
      service.addParameter( ::SWA::ParameterMetaData( "result", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), true ) );
      service.addParameter( ::SWA::ParameterMetaData( "fromLat", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "fromLong", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "toLat", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "toLong", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "distance", "instance of Distance", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Location::getDomain().getId(), ::masld_Location::objectId_maslo_Distance ) ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "deltaLat", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "deltaLong", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "sumSquares", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "sqrtSum", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_registerListener_MetaData ( )
    {
      int lines[] = { 3,
     4,
     5,
     6};
      ::SWA::ServiceMetaData service(::masld_Location::serviceId_masls_registerListener, ::SWA::ServiceMetaData::Domain, "registerListener", ::std::vector<int>( lines, lines + 4 ), "registerListener.svc", "a0dbd44d7002d7d7d87a4ccf6b8f4d23");
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "gps", "instance of GPS", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Location::getDomain().getId(), ::masld_Location::objectId_maslo_GPS ) ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_unregisterListener_MetaData ( )
    {
      int lines[] = { 3,
     4,
     5};
      ::SWA::ServiceMetaData service(::masld_Location::serviceId_masls_unregisterListener, ::SWA::ServiceMetaData::Domain, "unregisterListener", ::std::vector<int>( lines, lines + 3 ), "unregisterListener.svc", "4cdc0ff96f23818df89a55b632d7614c");
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "gps", "instance of GPS", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Location::getDomain().getId(), ::masld_Location::objectId_maslo_GPS ) ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_sqrt_MetaData ( )
    {
      int lines[] = { 8,
     13,
     15,
     18,
     19,
     22,
     24,
     25,
     26,
     27,
     28,
     29,
     30,
     31,
     33,
     36};
      ::SWA::ServiceMetaData service(::masld_Location::serviceId_masls_sqrt, ::SWA::ServiceMetaData::Domain, "sqrt", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), ::std::vector<int>( lines, lines + 16 ), "sqrt.svc", "40fa5cf7335015ed3e5cf67af8adda55");
      service.addParameter( ::SWA::ParameterMetaData( "x", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "result", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "inputValue", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "guess", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "MAX_ITERATIONS", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "i", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
      service.addLocalVariable( ::SWA::LocalVariableMetaData( "prev_value", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
      return service;
    }

    namespace maslo_Distance
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Location::objectId_maslo_Distance, "Distance", "Distance");
        object.addAttribute( ::SWA::AttributeMetaData( "id", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "kmPerDegree", false, "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        object.addService( get_masls_initialize_MetaData() );
        return object;
      }

      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( )
      {
        int lines[] = { 3,
     4,
     5,
     6,
     7};
        ::SWA::ServiceMetaData service(::masld_Location::maslo_Distance::serviceId_masls_initialize, ::SWA::ServiceMetaData::Object, "initialize", ::std::vector<int>( lines, lines + 5 ), "Distance_initialize.svc", "d7bbc79e5f637fc1620be77a0f7c7ea3");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "distance", "instance of Distance", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Location::getDomain().getId(), ::masld_Location::objectId_maslo_Distance ) ) );
        return service;
      }

    }
    namespace maslo_GPS
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Location::objectId_maslo_GPS, "GPS", "GPS");
        object.addAttribute( ::SWA::AttributeMetaData( "timer", false, "timer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "currentLatitude", false, "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "currentLongitude", false, "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "motionSegments", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "id", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addService( get_masls_initialize_MetaData() );
        object.addState( get_maslst_idle_MetaData() );
        object.addState( get_maslst_locating_MetaData() );
        object.addState( get_maslst_registeringListener_MetaData() );
        object.addState( get_maslst_unregistering_MetaData() );
        object.addEvent( get_maslev_tick_MetaData() );
        object.addEvent( get_maslev_registeringComplete_MetaData() );
        object.addEvent( get_maslev_registerListener_MetaData() );
        object.addEvent( get_maslev_unregisterListener_MetaData() );
        object.addEvent( get_maslev_unregisterComplete_MetaData() );
        return object;
      }

      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( )
      {
        int lines[] = { 4,
     7,
     8,
     10,
     11,
     13,
     14,
     15,
     16};
        ::SWA::ServiceMetaData service(::masld_Location::maslo_GPS::serviceId_masls_initialize, ::SWA::ServiceMetaData::Object, "initialize", ::std::vector<int>( lines, lines + 9 ), "GPS_initialize.svc", "0ebc5dadee85e6f1ce9e975cd0f8f58b");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "gps", "instance of GPS", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Location::getDomain().getId(), ::masld_Location::objectId_maslo_GPS ) ) );
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "simgps", "instance of simulatedGPS", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Location::getDomain().getId(), ::masld_Location::objectId_maslo_simulatedGPS ) ) );
        return service;
      }

      ::SWA::StateMetaData get_maslst_idle_MetaData ( )
      {
        int lines[] = { 2,
     3};
        ::SWA::StateMetaData state(::masld_Location::maslo_GPS::stateId_maslst_idle, ::SWA::StateMetaData::Normal, "idle", ::std::vector<int>( lines, lines + 2 ), "GPS_idle.al", "64d2cac409b7507139f6a23f4e39df38");
        return state;
      }

      ::SWA::StateMetaData get_maslst_locating_MetaData ( )
      {
        int lines[] = { 3,
     5,
     6,
     7,
     8,
     9,
     11,
     12,
     14,
     15,
     18};
        ::SWA::StateMetaData state(::masld_Location::maslo_GPS::stateId_maslst_locating, ::SWA::StateMetaData::Normal, "locating", ::std::vector<int>( lines, lines + 11 ), "GPS_locating.al", "0d99b0ae88f45fff7e3f0145aaa85b42");
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "simgps", "instance of simulatedGPS", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Location::getDomain().getId(), ::masld_Location::objectId_maslo_simulatedGPS ) ) );
        return state;
      }

      ::SWA::StateMetaData get_maslst_registeringListener_MetaData ( )
      {
        int lines[] = { 3,
     6,
     7,
     8,
     9,
     11};
        ::SWA::StateMetaData state(::masld_Location::maslo_GPS::stateId_maslst_registeringListener, ::SWA::StateMetaData::Normal, "registeringListener", ::std::vector<int>( lines, lines + 6 ), "GPS_registeringListener.al", "8c2faab76009391c530f33c13241f310");
        state.addLocalVariable( ::SWA::LocalVariableMetaData( "simgps", "instance of simulatedGPS", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Location::getDomain().getId(), ::masld_Location::objectId_maslo_simulatedGPS ) ) );
        return state;
      }

      ::SWA::StateMetaData get_maslst_unregistering_MetaData ( )
      {
        int lines[] = { 2,
     4,
     5,
     6};
        ::SWA::StateMetaData state(::masld_Location::maslo_GPS::stateId_maslst_unregistering, ::SWA::StateMetaData::Normal, "unregistering", ::std::vector<int>( lines, lines + 4 ), "GPS_unregistering.al", "9f9a898cd71118d7924cceac966b078c");
        return state;
      }

      ::SWA::EventMetaData get_maslev_tick_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Location::maslo_GPS::eventId_maslo_GPS_maslev_tick, ::masld_Location::objectId_maslo_GPS, ::SWA::EventMetaData::Normal, "tick");
        return event;
      }

      ::SWA::EventMetaData get_maslev_registeringComplete_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Location::maslo_GPS::eventId_maslo_GPS_maslev_registeringComplete, ::masld_Location::objectId_maslo_GPS, ::SWA::EventMetaData::Normal, "registeringComplete");
        return event;
      }

      ::SWA::EventMetaData get_maslev_registerListener_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Location::maslo_GPS::eventId_maslo_GPS_maslev_registerListener, ::masld_Location::objectId_maslo_GPS, ::SWA::EventMetaData::Normal, "registerListener");
        return event;
      }

      ::SWA::EventMetaData get_maslev_unregisterListener_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Location::maslo_GPS::eventId_maslo_GPS_maslev_unregisterListener, ::masld_Location::objectId_maslo_GPS, ::SWA::EventMetaData::Normal, "unregisterListener");
        return event;
      }

      ::SWA::EventMetaData get_maslev_unregisterComplete_MetaData ( )
      {
        ::SWA::EventMetaData event(::masld_Location::maslo_GPS::eventId_maslo_GPS_maslev_unregisterComplete, ::masld_Location::objectId_maslo_GPS, ::SWA::EventMetaData::Normal, "unregisterComplete");
        return event;
      }

    }
    namespace maslo_simulatedGPS
    {
      ::SWA::ObjectMetaData getMetaData ( )
      {
        ::SWA::ObjectMetaData object(::masld_Location::objectId_maslo_simulatedGPS, "simulatedGPS", "simulatedGPS");
        object.addAttribute( ::SWA::AttributeMetaData( "id", true, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "initialLatitude", false, "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "initialLongitude", false, "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "latitudeIncrement", false, "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "longitudeIncrement", false, "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
        object.addAttribute( ::SWA::AttributeMetaData( "updatePeriod", false, "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ) ) );
        object.addService( get_masls_initialize_MetaData() );
        return object;
      }

      ::SWA::ServiceMetaData get_masls_initialize_MetaData ( )
      {
        int lines[] = { 3,
     4,
     5,
     6,
     7,
     8,
     9,
     10,
     11};
        ::SWA::ServiceMetaData service(::masld_Location::maslo_simulatedGPS::serviceId_masls_initialize, ::SWA::ServiceMetaData::Object, "initialize", ::std::vector<int>( lines, lines + 9 ), "simulatedGPS_initialize.svc", "d81158fd8ff8634e3b90a73074f8c4cf");
        service.addLocalVariable( ::SWA::LocalVariableMetaData( "simgps", "instance of simulatedGPS", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Instance, ::masld_Location::getDomain().getId(), ::masld_Location::objectId_maslo_simulatedGPS ) ) );
        return service;
      }

    }
  }
}
