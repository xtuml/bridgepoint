//
// File: Transient__Location__DistancePopulation.cc
//
#include "Transient__Location__Distance.hh"
#include "Transient__Location__DistancePopulation.hh"
#include "__Location__Distance.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"

namespace transient
{
  namespace masld_Location
  {
    maslo_DistancePopulation::maslo_DistancePopulation ( )
      : masla_id_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> maslo_DistancePopulation::createInstance ( int32_t masla_id,
                                                                                                   double  masla_kmPerDegree )
    {
      if ( exists_masla_id( masla_id ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> instance(new maslo_Distance(  masla_id,
                     masla_kmPerDegree ));
      addInstance( instance );
      return instance;
    }

    void maslo_DistancePopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> instance )
    {
      masla_id_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_Location::maslo_Distance> >::value_type( ::boost::make_tuple( instance->get_masla_id() ), instance ) );
    }

    void maslo_DistancePopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> instance )
    {
      masla_id_Lookup.erase( ::boost::make_tuple( instance->get_masla_id() ) );
    }

    bool maslo_DistancePopulation::exists_masla_id ( int32_t masla_id ) const
    {
      return masla_id_Lookup.find( ::boost::make_tuple( masla_id ) ) != masla_id_Lookup.end();
    }

    maslo_DistancePopulation& maslo_DistancePopulation::getPopulation ( )
    {
      static maslo_DistancePopulation population;
      return population;
    }

    bool maslo_DistancePopulation::registered = maslo_DistancePopulation::registerSingleton( &maslo_DistancePopulation::getPopulation );

  }
}
