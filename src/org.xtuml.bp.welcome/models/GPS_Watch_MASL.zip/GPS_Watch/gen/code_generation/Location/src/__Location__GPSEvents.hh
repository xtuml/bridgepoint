//
// File: __Location__GPSEvents.hh
//
#ifndef _Location_GPS_Events_hh
#define _Location_GPS_Events_hh

#include "swa/Event.hh"

namespace masld_Location
{
  class Event_maslo_GPS_maslev_tick
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_GPS_maslev_tick ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_GPS_maslev_registeringComplete
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_GPS_maslev_registeringComplete ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_GPS_maslev_registerListener
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_GPS_maslev_registerListener ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_GPS_maslev_unregisterListener
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_GPS_maslev_unregisterListener ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_GPS_maslev_unregisterComplete
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_GPS_maslev_unregisterComplete ( );
      virtual void invoke ( ) const;


  };
}
#endif // _Location_GPS_Events_hh
