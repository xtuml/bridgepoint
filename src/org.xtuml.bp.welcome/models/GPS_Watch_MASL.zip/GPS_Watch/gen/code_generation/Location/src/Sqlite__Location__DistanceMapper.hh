//
// File: Sqlite__Location__DistanceMapper.hh
//
#ifndef Sqlite_Location_Distance_Mapper_hh
#define Sqlite_Location_Distance_Mapper_hh

#include "Sqlite__Location__Distance.hh"
#include "__Location__Distance.hh"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"

namespace SQLITE
{
  namespace masld_Location
  {
    class maslo_DistanceMapper
      : public ::SQL::ObjectMapper< ::masld_Location::maslo_Distance,maslo_Distance>
    {

      // Instance creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> createInstance ( int32_t masla_id,
                                                                                     double  masla_kmPerDegree );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> instance );
      protected:
        virtual bool doPostInit ( );


      // Constructors and Destructors
      public:
        maslo_DistanceMapper ( );
        virtual ~maslo_DistanceMapper ( );


      // Attributes
      private:
        ::boost::unordered_set<maslo_Distance::PrimaryKeyType> primarykey_cache;


    };
  }
}
#endif // Sqlite_Location_Distance_Mapper_hh
