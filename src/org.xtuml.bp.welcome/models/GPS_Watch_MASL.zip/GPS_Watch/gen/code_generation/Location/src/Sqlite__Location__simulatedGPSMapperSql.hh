//
// File: Sqlite__Location__simulatedGPSMapperSql.hh
//
#ifndef Sqlite_Location_simulated_GPS_Mapper_Sql_hh
#define Sqlite_Location_simulated_GPS_Mapper_Sql_hh

#include "Sqlite__Location__simulatedGPS.hh"
#include "__Location__simulatedGPS.hh"
#include <map>
#include "sql/Criteria.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sqlite/PreparedStatement.hh"
#include <stdint.h>
#include <string>
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Location
  {
    class maslo_simulatedGPSSqlGenerator
      : public ::SQL::ObjectSqlGenerator< ::masld_Location::maslo_simulatedGPS,maslo_simulatedGPS>
    {

      // execute methods
      public:
        void executeGetMaxColumnValue ( const ::std::string& attribute,
                                        int32_t&             value ) const;
        void executeGetMaxColumnValue ( const ::std::string& attribute,
                                        int64_t&             value ) const;
        ::SWA::IdType executeGetRowCount ( ) const;
        ::SWA::IdType executeGetMaxIdentifier ( ) const;
        void executeUpdate ( const PsObjectPtr& object ) const;
        void executeInsert ( const PsObjectPtr& object ) const;
        void executeRemove ( const PsObjectPtr& object ) const;
        void executeRemoveId ( const ::SWA::IdType object ) const;
        void executeSelect ( CacheType&             cache,
                             const ::SQL::Criteria& criteria,
                             PsBaseObjectPtrSwaSet& result ) const;
        void executeSelect ( CacheType&             cache,
                             const ::SQL::Criteria& criteria ) const;


      // getter methods
      public:
        const ::std::string getDomainName ( ) const;
        const ::std::string& getTableName ( ) const;
        const ::std::string& getObjectName ( ) const;
        const ::std::string getColumnName ( const ::std::string& attribute ) const;


      // Constructors and Destructors
      public:
        maslo_simulatedGPSSqlGenerator ( );
        ~maslo_simulatedGPSSqlGenerator ( );
        void initialise ( );


      // Data Members
      private:
        ::std::string tableName;
        ::std::string objectName;
        PreparedStatement insertStatement;
        PreparedStatement updateStatement;
        PreparedStatement deleteStatement;
        ::std::map< ::std::string,::std::string> columnNameMapper;


    };
  }
}
#endif // Sqlite_Location_simulated_GPS_Mapper_Sql_hh
