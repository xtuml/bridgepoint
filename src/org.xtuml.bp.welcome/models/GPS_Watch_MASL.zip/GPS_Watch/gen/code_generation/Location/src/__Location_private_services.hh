//
// File: __Location_private_services.hh
//
#ifndef _Location_private_services_hh
#define _Location_private_services_hh

namespace masld_Location
{
  double masls_sqrt ( double maslp_x );
}
#endif // _Location_private_services_hh
