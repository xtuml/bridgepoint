//
// File: __Location__DistancePopulation.cc
//
#include "__Location__DistancePopulation.hh"

namespace masld_Location
{
  maslo_DistancePopulation::maslo_DistancePopulation ( )
  {
  }

  maslo_DistancePopulation::~maslo_DistancePopulation ( )
  {
  }

}
