//
// File: Sqlite__Location__simulatedGPS.hh
//
#ifndef Sqlite_Location_simulated_GPS_hh
#define Sqlite_Location_simulated_GPS_hh

#include "__Location__simulatedGPS.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <stdint.h>
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Location
  {
    class maslo_simulatedGPS
      : public ::masld_Location::maslo_simulatedGPS
    {

      // Type definitions
      public:
        typedef ::boost::tuple<int32_t> PrimaryKeyType;
        typedef ::boost::tuple<int32_t> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_simulatedGPS ( ::SWA::IdType architectureId );
        maslo_simulatedGPS ( ::SWA::IdType architectureId,
                             int32_t       masla_id,
                             double        masla_initialLatitude,
                             double        masla_initialLongitude,
                             double        masla_latitudeIncrement,
                             double        masla_longitudeIncrement,
                             int32_t       masla_updatePeriod );


      // Setters for each object attribute
      public:
        void set_masla_id ( int32_t value )
        {
          this->masla_id = value;
          markAsModified();
        }
        virtual void set_masla_initialLatitude ( double value )
        {
          this->masla_initialLatitude = value;
          markAsModified();
        }
        virtual void set_masla_initialLongitude ( double value )
        {
          this->masla_initialLongitude = value;
          markAsModified();
        }
        virtual void set_masla_latitudeIncrement ( double value )
        {
          this->masla_latitudeIncrement = value;
          markAsModified();
        }
        virtual void set_masla_longitudeIncrement ( double value )
        {
          this->masla_longitudeIncrement = value;
          markAsModified();
        }
        virtual void set_masla_updatePeriod ( int32_t value )
        {
          this->masla_updatePeriod = value;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual double get_masla_initialLatitude ( ) const { return masla_initialLatitude; }
        virtual double get_masla_initialLongitude ( ) const { return masla_initialLongitude; }
        virtual double get_masla_latitudeIncrement ( ) const { return masla_latitudeIncrement; }
        virtual double get_masla_longitudeIncrement ( ) const { return masla_longitudeIncrement; }
        virtual int32_t get_masla_updatePeriod ( ) const { return masla_updatePeriod; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_id;
        double masla_initialLatitude;
        double masla_initialLongitude;
        double masla_latitudeIncrement;
        double masla_longitudeIncrement;
        int32_t masla_updatePeriod;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_Location_simulated_GPS_hh
