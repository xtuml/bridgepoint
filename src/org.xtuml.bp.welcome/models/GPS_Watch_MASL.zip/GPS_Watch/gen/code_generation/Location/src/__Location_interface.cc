//
// File: __Location_interface.cc
//
#include "Location_OOA/__Location_interface.hh"
#include "swa/Domain.hh"
#include "swa/Process.hh"

namespace masld_Location
{
  ::SWA::Domain& getDomain ( )
  {
    static ::SWA::Domain& domain = ::SWA::Process::getInstance().registerDomain( "Location" );
    return domain;
  }

  bool initialiseInterface ( )
  {
    getDomain();
  }

  const bool interfaceInitialised = initialiseInterface();

}
