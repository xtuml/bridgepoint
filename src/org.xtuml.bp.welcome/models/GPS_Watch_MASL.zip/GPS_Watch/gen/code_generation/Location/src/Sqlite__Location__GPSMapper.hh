//
// File: Sqlite__Location__GPSMapper.hh
//
#ifndef Sqlite_Location_GPS_Mapper_hh
#define Sqlite_Location_GPS_Mapper_hh

#include "Sqlite__Location__GPS.hh"
#include "__Location__GPS.hh"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"

namespace SQLITE
{
  namespace masld_Location
  {
    class maslo_GPSMapper
      : public ::SQL::ObjectMapper< ::masld_Location::maslo_GPS,maslo_GPS>
    {

      // Instance creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> createInstance ( const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                                double                                 masla_currentLatitude,
                                                                                double                                 masla_currentLongitude,
                                                                                int32_t                                masla_motionSegments,
                                                                                int32_t                                masla_id,
                                                                                ::masld_Location::maslo_GPS::Type      currentState );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> instance );
      protected:
        virtual bool doPostInit ( );


      // Constructors and Destructors
      public:
        maslo_GPSMapper ( );
        virtual ~maslo_GPSMapper ( );


      // Attributes
      private:
        ::boost::unordered_set<maslo_GPS::PrimaryKeyType> primarykey_cache;


    };
  }
}
#endif // Sqlite_Location_GPS_Mapper_hh
