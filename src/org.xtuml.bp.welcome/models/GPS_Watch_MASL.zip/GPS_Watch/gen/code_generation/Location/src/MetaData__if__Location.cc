//
// File: MetaData__if__Location.cc
//
#include "Location_OOA/__Location_interface.hh"
#include "metadata/MetaData.hh"
#include "swa/Domain.hh"

namespace 
{
  namespace init_interface_masld_Location
  {
    ::SWA::DomainMetaData initDomainMetaData ( )
    {
      ::SWA::DomainMetaData domain(::masld_Location::getDomain().getId(), "Location", true);
      return domain;
    }

    ::SWA::DomainMetaData& getDomainMetaData ( )
    {
      static ::SWA::DomainMetaData domain = initDomainMetaData();
      return domain;
    }

    bool registered = ::SWA::ProcessMetaData::getProcess().addDomain( ::masld_Location::getDomain().getId(), &getDomainMetaData );

  }
}
