//
// File: Inspector__Location.cc
//
#include "Inspector__Location__Distance.hh"
#include "Inspector__Location__GPS.hh"
#include "Inspector__Location__simulatedGPS.hh"
#include "Location_OOA/__Location.hh"
#include "Location_OOA/__Location_interface.hh"
#include "Location_OOA/__Location_services.hh"
#include "__Location__Distance.hh"
#include "__Location__GPS.hh"
#include "__Location_private_services.hh"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/GenericObjectHandler.hh"
#include "inspector/ProcessHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"

namespace Inspector
{
  namespace masld_Location
  {
    class masls_getLocationHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_getLocationInvoker
    {

      public:
        masls_getLocationInvoker ( CommunicationChannel& channel )
          : maslp_latitude(),
            maslp_longitude()

        {
          channel >> maslp_latitude;
          channel >> maslp_longitude;
        }
        void operator() ( ) { ::masld_Location::interceptor_masls_getLocation::instance().callService()( maslp_latitude, maslp_longitude ); }


      private:
        double maslp_latitude;
        double maslp_longitude;


    };
    class masls_getDistanceHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_getDistanceInvoker
    {

      public:
        masls_getDistanceInvoker ( CommunicationChannel& channel )
          : maslp_result(),
            maslp_fromLat(),
            maslp_fromLong(),
            maslp_toLat(),
            maslp_toLong()

        {
          channel >> maslp_result;
          channel >> maslp_fromLat;
          channel >> maslp_fromLong;
          channel >> maslp_toLat;
          channel >> maslp_toLong;
        }
        void operator() ( ) { ::masld_Location::interceptor_masls_getDistance::instance().callService()( maslp_result, maslp_fromLat, maslp_fromLong, maslp_toLat, maslp_toLong ); }


      private:
        double maslp_result;
        double maslp_fromLat;
        double maslp_fromLong;
        double maslp_toLat;
        double maslp_toLong;


    };
    class masls_registerListenerHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_registerListenerInvoker
    {

      public:
        masls_registerListenerInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_Location::interceptor_masls_registerListener::instance().callService()(); }


    };
    class masls_unregisterListenerHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_unregisterListenerInvoker
    {

      public:
        masls_unregisterListenerInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_Location::interceptor_masls_unregisterListener::instance().callService()(); }


    };
    class masls_sqrtHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_sqrtInvoker
    {

      public:
        masls_sqrtInvoker ( CommunicationChannel& channel )
          : maslp_x()
 { channel >> maslp_x; }
        void operator() ( ) { ::masld_Location::masls_sqrt( maslp_x ); }


      private:
        double maslp_x;


    };
    class masld_LocationHandler
      : public DomainHandler
    {

      public:
        masld_LocationHandler ( );
        void createRelationship ( CommunicationChannel& channel,
                                  int                   relId );


    };
    Callable masls_getLocationHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_getLocationInvoker( channel );
    }

    void masls_getLocationHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                    const ::SWA::StackFrame& frame ) const
    {

      // Write latitude
      channel << frame.getParameters()[0].getValue<double>();

      // Write longitude
      channel << frame.getParameters()[1].getValue<double>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
      for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
      {
        channel << frame.getLocalVars()[i].getId();
        switch ( frame.getLocalVars()[i].getId() )
        {
          case 0:

            // Write gps
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> >();
            break;

        }

      }
    }

    Callable masls_getDistanceHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_getDistanceInvoker( channel );
    }

    void masls_getDistanceHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                    const ::SWA::StackFrame& frame ) const
    {

      // Write result
      channel << frame.getParameters()[0].getValue<double>();

      // Write fromLat
      channel << frame.getParameters()[1].getValue<double>();

      // Write fromLong
      channel << frame.getParameters()[2].getValue<double>();

      // Write toLat
      channel << frame.getParameters()[3].getValue<double>();

      // Write toLong
      channel << frame.getParameters()[4].getValue<double>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
      for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
      {
        channel << frame.getLocalVars()[i].getId();
        switch ( frame.getLocalVars()[i].getId() )
        {
          case 0:

            // Write distance
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> >();
            break;

          case 1:

            // Write deltaLat
            channel << frame.getLocalVars()[i].getValue<double>();
            break;

          case 2:

            // Write deltaLong
            channel << frame.getLocalVars()[i].getValue<double>();
            break;

          case 3:

            // Write sumSquares
            channel << frame.getLocalVars()[i].getValue<double>();
            break;

          case 4:

            // Write sqrtSum
            channel << frame.getLocalVars()[i].getValue<double>();
            break;

        }

      }
    }

    Callable masls_registerListenerHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_registerListenerInvoker( channel );
    }

    void masls_registerListenerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                         const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
      for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
      {
        channel << frame.getLocalVars()[i].getId();
        switch ( frame.getLocalVars()[i].getId() )
        {
          case 0:

            // Write gps
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> >();
            break;

        }

      }
    }

    Callable masls_unregisterListenerHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_unregisterListenerInvoker( channel );
    }

    void masls_unregisterListenerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                           const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
      for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
      {
        channel << frame.getLocalVars()[i].getId();
        switch ( frame.getLocalVars()[i].getId() )
        {
          case 0:

            // Write gps
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> >();
            break;

        }

      }
    }

    Callable masls_sqrtHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_sqrtInvoker( channel );
    }

    void masls_sqrtHandler::writeLocalVars ( CommunicationChannel&    channel,
                                             const ::SWA::StackFrame& frame ) const
    {

      // Write x
      channel << frame.getParameters()[0].getValue<double>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
      for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
      {
        channel << frame.getLocalVars()[i].getId();
        switch ( frame.getLocalVars()[i].getId() )
        {
          case 0:

            // Write result
            channel << frame.getLocalVars()[i].getValue<double>();
            break;

          case 1:

            // Write inputValue
            channel << frame.getLocalVars()[i].getValue<double>();
            break;

          case 2:

            // Write guess
            channel << frame.getLocalVars()[i].getValue<double>();
            break;

          case 3:

            // Write MAX_ITERATIONS
            channel << frame.getLocalVars()[i].getValue<int32_t>();
            break;

          case 4:

            // Write i
            channel << frame.getLocalVars()[i].getValue<int32_t>();
            break;

          case 5:

            // Write prev_value
            channel << frame.getLocalVars()[i].getValue<double>();
            break;

        }

      }
    }

    masld_LocationHandler::masld_LocationHandler ( )
    {
      registerObjectHandler( ::masld_Location::objectId_maslo_Distance, ::boost::shared_ptr<GenericObjectHandler>( new maslo_Distance::maslo_DistanceHandler() ) );
      registerObjectHandler( ::masld_Location::objectId_maslo_GPS, ::boost::shared_ptr<GenericObjectHandler>( new maslo_GPS::maslo_GPSHandler() ) );
      registerObjectHandler( ::masld_Location::objectId_maslo_simulatedGPS, ::boost::shared_ptr<GenericObjectHandler>( new maslo_simulatedGPS::maslo_simulatedGPSHandler() ) );
      registerServiceHandler( ::masld_Location::serviceId_masls_getLocation, ::boost::shared_ptr<ActionHandler>( new masls_getLocationHandler() ) );
      registerServiceHandler( ::masld_Location::serviceId_masls_getDistance, ::boost::shared_ptr<ActionHandler>( new masls_getDistanceHandler() ) );
      registerServiceHandler( ::masld_Location::serviceId_masls_registerListener, ::boost::shared_ptr<ActionHandler>( new masls_registerListenerHandler() ) );
      registerServiceHandler( ::masld_Location::serviceId_masls_unregisterListener, ::boost::shared_ptr<ActionHandler>( new masls_unregisterListenerHandler() ) );
      registerServiceHandler( ::masld_Location::serviceId_masls_sqrt, ::boost::shared_ptr<ActionHandler>( new masls_sqrtHandler() ) );
    }

    void masld_LocationHandler::createRelationship ( CommunicationChannel& channel,
                                                     int                   relId )
    {
      switch ( relId )
      {
      }

    }

  }
}
namespace 
{
  bool masld_Location_registered = ::Inspector::ProcessHandler::getInstance().registerDomainHandler( ::SWA::Process::getInstance().getDomain( "Location" ).getId(), ::boost::shared_ptr< ::Inspector::DomainHandler>( new ::Inspector::masld_Location::masld_LocationHandler() ) );

}
