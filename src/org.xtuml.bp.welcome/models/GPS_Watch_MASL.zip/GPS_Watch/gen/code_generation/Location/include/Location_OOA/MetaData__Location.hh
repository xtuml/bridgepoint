//
// File: MetaData__Location.hh
//
#ifndef Location_OOA_Meta_Data_Location_hh
#define Location_OOA_Meta_Data_Location_hh

namespace masld_Location
{
  enum TypeIds {};
}
#endif // Location_OOA_Meta_Data_Location_hh
