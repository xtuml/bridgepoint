//
// File: Sqlite__Location__DistancePopulation.cc
//
#include "Sqlite__Location__DistancePopulation.hh"
#include "__Location__Distance.hh"
#include "boost/bind.hpp"
#include "boost/signals2.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Location
  {
    maslo_DistancePopulation::maslo_DistancePopulation ( )
    {
    }

    maslo_DistancePopulation::~maslo_DistancePopulation ( )
    {
    }

    void maslo_DistancePopulation::initialise ( )
    {
      mapper->initialise();
    }

    maslo_DistancePopulation& maslo_DistancePopulation::getPopulation ( )
    {
      static maslo_DistancePopulation population;
      return population;
    }

    bool maslo_DistancePopulation::registered = maslo_DistancePopulation::registerSingleton( &maslo_DistancePopulation::getPopulation );

    ::boost::signals2::connection maslo_DistancePopulation::initialised = ::SWA::Process::getInstance().registerInitialisingListener( ::boost::bind( &maslo_DistancePopulation::initialise, ::boost::bind( &maslo_DistancePopulation::getPopulation ) ) );

    ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> maslo_DistancePopulation::findObject ( const ::SWA::IdType& obj )
    {
      return mapper->find( obj );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> > maslo_DistancePopulation::findObject ( const MapperType::PsObjectIdSet& obj )
    {
      MapperType::PsObjectPtrSet objectSet = mapper->find( obj );
      return ::SWA::Set< ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> >( objectSet.begin(), objectSet.end(), true );
    }

    ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> maslo_DistancePopulation::createInstance ( int32_t masla_id,
                                                                                                   double  masla_kmPerDegree )
    {
      return mapper->createInstance( masla_id, masla_kmPerDegree );
    }

    void maslo_DistancePopulation::deleteInstance ( ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> instance )
    {
      {
      }
      mapper->deleteInstance( instance );
    }

  }
}
