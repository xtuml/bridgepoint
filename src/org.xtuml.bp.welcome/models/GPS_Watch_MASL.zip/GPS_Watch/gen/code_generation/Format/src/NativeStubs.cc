//
// File: NativeStubs.cc
//
#include "Format_OOA/__Format_services.hh"
#include <stdint.h>

namespace masld_Format
{
  uint8_t masls_to_ascii ( char maslp_input )
  {
  }

}
