//
// File: MetaData__if__Format.cc
//
#include "Format_OOA/MetaData__Format.hh"
#include "Format_OOA/__Format_interface.hh"
#include "Format_OOA/__Format_types.hh"
#include "metadata/MetaData.hh"
#include "swa/Domain.hh"

namespace 
{
  namespace init_interface_masld_Format
  {
    ::SWA::EnumerateMetaData get_maslt_justify_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_base_case_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_rounding_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_duration_field_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_timestamp_field_MetaData ( );
    ::SWA::DomainMetaData initDomainMetaData ( )
    {
      ::SWA::DomainMetaData domain(::masld_Format::getDomain().getId(), "Format", true);
      domain.addEnumerate( get_maslt_justify_MetaData() );
      domain.addEnumerate( get_maslt_base_case_MetaData() );
      domain.addEnumerate( get_maslt_rounding_MetaData() );
      domain.addEnumerate( get_maslt_duration_field_MetaData() );
      domain.addEnumerate( get_maslt_timestamp_field_MetaData() );
      return domain;
    }

    ::SWA::DomainMetaData& getDomainMetaData ( )
    {
      static ::SWA::DomainMetaData domain = initDomainMetaData();
      return domain;
    }

    bool registered = ::SWA::ProcessMetaData::getProcess().addDomain( ::masld_Format::getDomain().getId(), &getDomainMetaData );

    ::SWA::EnumerateMetaData get_maslt_justify_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Format::typeId_maslt_justify, "justify");
      enumeration.addValue( ::masld_Format::maslt_justify::masle_left.getValue(), "left" );
      enumeration.addValue( ::masld_Format::maslt_justify::masle_right.getValue(), "right" );
      enumeration.addValue( ::masld_Format::maslt_justify::masle_internal.getValue(), "internal" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_base_case_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Format::typeId_maslt_base_case, "base_case");
      enumeration.addValue( ::masld_Format::maslt_base_case::masle_upper.getValue(), "upper" );
      enumeration.addValue( ::masld_Format::maslt_base_case::masle_lower.getValue(), "lower" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_rounding_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Format::typeId_maslt_rounding, "rounding");
      enumeration.addValue( ::masld_Format::maslt_rounding::masle_towards_zero.getValue(), "towards_zero" );
      enumeration.addValue( ::masld_Format::maslt_rounding::masle_towards_nearest.getValue(), "towards_nearest" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_duration_field_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Format::typeId_maslt_duration_field, "duration_field");
      enumeration.addValue( ::masld_Format::maslt_duration_field::masle_weeks.getValue(), "weeks" );
      enumeration.addValue( ::masld_Format::maslt_duration_field::masle_days.getValue(), "days" );
      enumeration.addValue( ::masld_Format::maslt_duration_field::masle_hours.getValue(), "hours" );
      enumeration.addValue( ::masld_Format::maslt_duration_field::masle_minutes.getValue(), "minutes" );
      enumeration.addValue( ::masld_Format::maslt_duration_field::masle_seconds.getValue(), "seconds" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_timestamp_field_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Format::typeId_maslt_timestamp_field, "timestamp_field");
      enumeration.addValue( ::masld_Format::maslt_timestamp_field::masle_year.getValue(), "year" );
      enumeration.addValue( ::masld_Format::maslt_timestamp_field::masle_month.getValue(), "month" );
      enumeration.addValue( ::masld_Format::maslt_timestamp_field::masle_week.getValue(), "week" );
      enumeration.addValue( ::masld_Format::maslt_timestamp_field::masle_day.getValue(), "day" );
      enumeration.addValue( ::masld_Format::maslt_timestamp_field::masle_hour.getValue(), "hour" );
      enumeration.addValue( ::masld_Format::maslt_timestamp_field::masle_minute.getValue(), "minute" );
      enumeration.addValue( ::masld_Format::maslt_timestamp_field::masle_second.getValue(), "second" );
      return enumeration;
    }

  }
}
