//
// File: MetaData__Format.hh
//
#ifndef Format_OOA_Meta_Data_Format_hh
#define Format_OOA_Meta_Data_Format_hh

namespace masld_Format
{
  enum TypeIds {  typeId_maslt_justify,
                  typeId_maslt_base_case,
                  typeId_maslt_rounding,
                  typeId_maslt_duration_field,
                  typeId_maslt_timestamp_field };
}
#endif // Format_OOA_Meta_Data_Format_hh
