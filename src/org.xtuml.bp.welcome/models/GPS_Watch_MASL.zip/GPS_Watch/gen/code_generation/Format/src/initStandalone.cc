//
// File: initStandalone.cc
//
#include "swa/Main.hh"
#include "swa/Process.hh"

namespace masld_Format
{
  bool initialiseProcess ( )
  {
    ::SWA::Process::getInstance().setProjectName( "Format" );
    return true;
  }

  const bool processInitialised = initialiseProcess();

}
int main ( int                 argc,
           const char* const * argv )
{
  return SWA::main( argc, argv );
}

