//
// File: NativeStubs.cc
//
#include "Logger_OOA/__Logger_services.hh"
#include "Logger_OOA/__Logger_types.hh"
#include "swa/String.hh"

namespace masld_Logger
{
  void masls_log ( const maslt_Priority& maslp_priority,
                   const ::SWA::String&  maslp_message )
  {
  }

  const bool localServiceRegistration_masls_log = interceptor_masls_log::instance().registerLocal( &masls_log );

}
