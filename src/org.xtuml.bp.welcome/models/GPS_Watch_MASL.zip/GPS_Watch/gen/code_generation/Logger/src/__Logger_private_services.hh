//
// File: __Logger_private_services.hh
//
#ifndef _Logger_private_services_hh
#define _Logger_private_services_hh

#endif // _Logger_private_services_hh
