//
// File: __Logger_interface.cc
//
#include "Logger_OOA/__Logger_interface.hh"
#include "swa/Domain.hh"
#include "swa/Process.hh"

namespace masld_Logger
{
  ::SWA::Domain& getDomain ( )
  {
    static ::SWA::Domain& domain = ::SWA::Process::getInstance().registerDomain( "Logger" );
    return domain;
  }

  bool initialiseInterface ( )
  {
    getDomain();
  }

  const bool interfaceInitialised = initialiseInterface();

}
