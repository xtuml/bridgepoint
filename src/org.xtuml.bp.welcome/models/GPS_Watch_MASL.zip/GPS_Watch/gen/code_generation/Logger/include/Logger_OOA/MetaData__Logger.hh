//
// File: MetaData__Logger.hh
//
#ifndef Logger_OOA_Meta_Data_Logger_hh
#define Logger_OOA_Meta_Data_Logger_hh

namespace masld_Logger
{
  enum TypeIds {  typeId_maslt_Priority };
}
#endif // Logger_OOA_Meta_Data_Logger_hh
