//
// File: __GPS_Watch__Tracking__UI__setIndicator.hh
//
#ifndef _GPS_Watch_Tracking_UI_set_Indicator_hh
#define _GPS_Watch_Tracking_UI_set_Indicator_hh

namespace masld_Tracking
{
  class maslt_Indicator;
}
namespace maslp_GPS_Watch
{
  namespace masld_Tracking
  {
    namespace maslb_UI
    {
      void masls_setIndicator ( const ::masld_Tracking::maslt_Indicator& maslp_indicator );
    }
  }
}
#endif // _GPS_Watch_Tracking_UI_set_Indicator_hh
