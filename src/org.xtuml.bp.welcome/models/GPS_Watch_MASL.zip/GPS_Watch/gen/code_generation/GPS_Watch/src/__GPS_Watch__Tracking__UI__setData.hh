//
// File: __GPS_Watch__Tracking__UI__setData.hh
//
#ifndef _GPS_Watch_Tracking_UI_set_Data_hh
#define _GPS_Watch_Tracking_UI_set_Data_hh

namespace masld_Tracking
{
  class maslt_Unit;
}
namespace maslp_GPS_Watch
{
  namespace masld_Tracking
  {
    namespace maslb_UI
    {
      void masls_setData ( double                              maslp_value,
                           const ::masld_Tracking::maslt_Unit& maslp_unit );
    }
  }
}
#endif // _GPS_Watch_Tracking_UI_set_Data_hh
