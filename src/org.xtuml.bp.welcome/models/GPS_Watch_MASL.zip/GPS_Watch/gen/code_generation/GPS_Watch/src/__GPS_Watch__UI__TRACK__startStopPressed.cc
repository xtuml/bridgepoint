//
// File: __GPS_Watch__UI__TRACK__startStopPressed.cc
//
#include "Tracking_OOA/__Tracking_services.hh"
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_terminators.hh"
#include "__GPS_Watch__UI__TRACK__startStopPressed.hh"
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"

namespace maslp_GPS_Watch
{
  namespace masld_UI
  {
    namespace maslb_TRACK
    {
      bool register_masls_startStopPressed = ::masld_UI::maslb_TRACK::register_masls_startStopPressed( &masls_startStopPressed );

      void masls_startStopPressed ( )
      {

        // begin ...
        // end;
        {
          ::SWA::Stack::EnteringTerminatorService enteringActionMarker(::masld_UI::getDomain().getId(), ::masld_UI::terminatorId_maslb_TRACK, ::masld_UI::maslb_TRACK::serviceId_masls_startStopPressed);
          ::SWA::Stack::EnteredAction enteredActionMarker;
          ::SWA::Stack::ExecutingStatement statement(2);
          {

            // Tracking::startStopPressed()
            {
              ::SWA::Stack::ExecutingStatement statement(3);
              ::masld_Tracking::interceptor_masls_startStopPressed::instance().callService()();
            }
          }
        }
      }

    }
  }
}
