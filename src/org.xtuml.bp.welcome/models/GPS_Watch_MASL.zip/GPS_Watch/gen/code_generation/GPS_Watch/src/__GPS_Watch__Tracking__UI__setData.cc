//
// File: __GPS_Watch__Tracking__UI__setData.cc
//
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "UI_OOA/__UI_services.hh"
#include "UI_OOA/__UI_types.hh"
#include "__GPS_Watch__Tracking__UI__setData.hh"
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"

namespace maslp_GPS_Watch
{
  namespace masld_Tracking
  {
    namespace maslb_UI
    {
      bool register_masls_setData = ::masld_Tracking::maslb_UI::register_masls_setData( &masls_setData );

      void masls_setData ( double                              maslp_value,
                           const ::masld_Tracking::maslt_Unit& maslp_unit )
      {

        // begin ...
        // end;
        {
          ::SWA::Stack::EnteringTerminatorService enteringActionMarker(::masld_Tracking::getDomain().getId(), ::masld_Tracking::terminatorId_maslb_UI, ::masld_Tracking::maslb_UI::serviceId_masls_setData);
          ::SWA::Stack::DeclareParameter pm_maslp_value(maslp_value);
          ::SWA::Stack::DeclareParameter pm_maslp_unit(maslp_unit);
          ::SWA::Stack::EnteredAction enteredActionMarker;
          ::SWA::Stack::ExecutingStatement statement(3);
          {

            // if (unit = Tracking::Unit.km) then ...
            // elsif (unit = Tracking::Unit.meters) then ...
            // elsif (unit = Tracking::Unit.minPerKm) then ...
            // elsif (unit = Tracking::Unit.kmPerHour) then ...
            // elsif (unit = Tracking::Unit.miles) then ...
            // elsif (unit = Tracking::Unit.yards) then ...
            // elsif (unit = Tracking::Unit.feet) then ...
            // elsif (unit = Tracking::Unit.minPerMile) then ...
            // elsif (unit = Tracking::Unit.mph) then ...
            // elsif (unit = Tracking::Unit.bpm) then ...
            // elsif (unit = Tracking::Unit.laps) then ...
            {
              ::SWA::Stack::ExecutingStatement statement(4);
              if ( maslp_unit == ::masld_Tracking::maslt_Unit::masle_km )
              {

                // UI::setData(value, UI::UIUnit.km)
                {
                  ::SWA::Stack::ExecutingStatement statement(5);
                  ::masld_UI::interceptor_masls_setData::instance().callService()( maslp_value, ::masld_UI::maslt_UIUnit::masle_km );
                }
              }
              else if ( maslp_unit == ::masld_Tracking::maslt_Unit::masle_meters )
              {

                // UI::setData(value, UI::UIUnit.meters)
                {
                  ::SWA::Stack::ExecutingStatement statement(7);
                  ::masld_UI::interceptor_masls_setData::instance().callService()( maslp_value, ::masld_UI::maslt_UIUnit::masle_meters );
                }
              }
              else if ( maslp_unit == ::masld_Tracking::maslt_Unit::masle_minPerKm )
              {

                // UI::setData(value, UI::UIUnit.minPerKm)
                {
                  ::SWA::Stack::ExecutingStatement statement(9);
                  ::masld_UI::interceptor_masls_setData::instance().callService()( maslp_value, ::masld_UI::maslt_UIUnit::masle_minPerKm );
                }
              }
              else if ( maslp_unit == ::masld_Tracking::maslt_Unit::masle_kmPerHour )
              {

                // UI::setData(value, UI::UIUnit.kmPerHour)
                {
                  ::SWA::Stack::ExecutingStatement statement(11);
                  ::masld_UI::interceptor_masls_setData::instance().callService()( maslp_value, ::masld_UI::maslt_UIUnit::masle_kmPerHour );
                }
              }
              else if ( maslp_unit == ::masld_Tracking::maslt_Unit::masle_miles )
              {

                // UI::setData(value, UI::UIUnit.miles)
                {
                  ::SWA::Stack::ExecutingStatement statement(13);
                  ::masld_UI::interceptor_masls_setData::instance().callService()( maslp_value, ::masld_UI::maslt_UIUnit::masle_miles );
                }
              }
              else if ( maslp_unit == ::masld_Tracking::maslt_Unit::masle_yards )
              {

                // UI::setData(value, UI::UIUnit.yards)
                {
                  ::SWA::Stack::ExecutingStatement statement(15);
                  ::masld_UI::interceptor_masls_setData::instance().callService()( maslp_value, ::masld_UI::maslt_UIUnit::masle_yards );
                }
              }
              else if ( maslp_unit == ::masld_Tracking::maslt_Unit::masle_feet )
              {

                // UI::setData(value, UI::UIUnit.feet)
                {
                  ::SWA::Stack::ExecutingStatement statement(17);
                  ::masld_UI::interceptor_masls_setData::instance().callService()( maslp_value, ::masld_UI::maslt_UIUnit::masle_feet );
                }
              }
              else if ( maslp_unit == ::masld_Tracking::maslt_Unit::masle_minPerMile )
              {

                // UI::setData(value, UI::UIUnit.minPerMile)
                {
                  ::SWA::Stack::ExecutingStatement statement(19);
                  ::masld_UI::interceptor_masls_setData::instance().callService()( maslp_value, ::masld_UI::maslt_UIUnit::masle_minPerMile );
                }
              }
              else if ( maslp_unit == ::masld_Tracking::maslt_Unit::masle_mph )
              {

                // UI::setData(value, UI::UIUnit.mph)
                {
                  ::SWA::Stack::ExecutingStatement statement(21);
                  ::masld_UI::interceptor_masls_setData::instance().callService()( maslp_value, ::masld_UI::maslt_UIUnit::masle_mph );
                }
              }
              else if ( maslp_unit == ::masld_Tracking::maslt_Unit::masle_bpm )
              {

                // UI::setData(value, UI::UIUnit.bpm)
                {
                  ::SWA::Stack::ExecutingStatement statement(23);
                  ::masld_UI::interceptor_masls_setData::instance().callService()( maslp_value, ::masld_UI::maslt_UIUnit::masle_bpm );
                }
              }
              else if ( maslp_unit == ::masld_Tracking::maslt_Unit::masle_laps )
              {

                // UI::setData(value, UI::UIUnit.laps)
                {
                  ::SWA::Stack::ExecutingStatement statement(25);
                  ::masld_UI::interceptor_masls_setData::instance().callService()( maslp_value, ::masld_UI::maslt_UIUnit::masle_laps );
                }
              }
            }
          }
        }
      }

    }
  }
}
