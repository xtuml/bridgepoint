//
// File: Inspector__GPS_Watch.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_terminators.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_terminators.hh"
#include "UI_OOA/__UI_types.hh"
#include "__GPS_Watch__HeartRateMonitor__HRChange__heartRateChanged.hh"
#include "__GPS_Watch__Tracking__HR__registerListener.hh"
#include "__GPS_Watch__Tracking__HR__unregisterListener.hh"
#include "__GPS_Watch__Tracking__LOC__getDistance.hh"
#include "__GPS_Watch__Tracking__LOC__getLocation.hh"
#include "__GPS_Watch__Tracking__LOC__registerListener.hh"
#include "__GPS_Watch__Tracking__LOC__unregisterListener.hh"
#include "__GPS_Watch__Tracking__UI__setData.hh"
#include "__GPS_Watch__Tracking__UI__setIndicator.hh"
#include "__GPS_Watch__Tracking__UI__setTime.hh"
#include "__GPS_Watch__UI__TRACK__lapResetPressed.hh"
#include "__GPS_Watch__UI__TRACK__lightPressed.hh"
#include "__GPS_Watch__UI__TRACK__modePressed.hh"
#include "__GPS_Watch__UI__TRACK__newGoalSpec.hh"
#include "__GPS_Watch__UI__TRACK__setTargetPressed.hh"
#include "__GPS_Watch__UI__TRACK__startStopPressed.hh"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/ProcessHandler.hh"
#include "inspector/TerminatorHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Stack.hh"

namespace Inspector
{
  namespace maslp_GPS_Watch
  {
    namespace masld_HeartRateMonitor
    {
      namespace maslb_HRChange
      {
        class masls_heartRateChangedHandler
          : public ActionHandler
        {

          public:
            Callable getInvoker ( CommunicationChannel& channel ) const;
            void writeLocalVars ( CommunicationChannel&    channel,
                                  const ::SWA::StackFrame& frame ) const;


        };
        class masls_heartRateChangedInvoker
        {

          public:
            masls_heartRateChangedInvoker ( CommunicationChannel& channel )
              : maslp_heartRate()
 { channel >> maslp_heartRate; }
            void operator() ( ) { ::maslp_GPS_Watch::masld_HeartRateMonitor::maslb_HRChange::masls_heartRateChanged( maslp_heartRate ); }


          private:
            int32_t maslp_heartRate;


        };
      }
    }
    namespace masld_Tracking
    {
      namespace maslb_HR
      {
        class masls_registerListenerHandler
          : public ActionHandler
        {

          public:
            Callable getInvoker ( CommunicationChannel& channel ) const;
            void writeLocalVars ( CommunicationChannel&    channel,
                                  const ::SWA::StackFrame& frame ) const;


        };
        class masls_registerListenerInvoker
        {

          public:
            masls_registerListenerInvoker ( CommunicationChannel& channel )

            {
            }
            void operator() ( ) { ::maslp_GPS_Watch::masld_Tracking::maslb_HR::masls_registerListener(); }


        };
        class masls_unregisterListenerHandler
          : public ActionHandler
        {

          public:
            Callable getInvoker ( CommunicationChannel& channel ) const;
            void writeLocalVars ( CommunicationChannel&    channel,
                                  const ::SWA::StackFrame& frame ) const;


        };
        class masls_unregisterListenerInvoker
        {

          public:
            masls_unregisterListenerInvoker ( CommunicationChannel& channel )

            {
            }
            void operator() ( ) { ::maslp_GPS_Watch::masld_Tracking::maslb_HR::masls_unregisterListener(); }


        };
      }
      namespace maslb_LOC
      {
        class masls_getDistanceHandler
          : public ActionHandler
        {

          public:
            Callable getInvoker ( CommunicationChannel& channel ) const;
            void writeLocalVars ( CommunicationChannel&    channel,
                                  const ::SWA::StackFrame& frame ) const;


        };
        class masls_getDistanceInvoker
        {

          public:
            masls_getDistanceInvoker ( CommunicationChannel& channel )
              : maslp_result(),
                maslp_toLong(),
                maslp_toLat(),
                maslp_fromLong(),
                maslp_fromLat()

            {
              channel >> maslp_result;
              channel >> maslp_toLong;
              channel >> maslp_toLat;
              channel >> maslp_fromLong;
              channel >> maslp_fromLat;
            }
            void operator() ( ) { ::maslp_GPS_Watch::masld_Tracking::maslb_LOC::masls_getDistance( maslp_result, maslp_toLong, maslp_toLat, maslp_fromLong, maslp_fromLat ); }


          private:
            double maslp_result;
            double maslp_toLong;
            double maslp_toLat;
            double maslp_fromLong;
            double maslp_fromLat;


        };
        class masls_getLocationHandler
          : public ActionHandler
        {

          public:
            Callable getInvoker ( CommunicationChannel& channel ) const;
            void writeLocalVars ( CommunicationChannel&    channel,
                                  const ::SWA::StackFrame& frame ) const;


        };
        class masls_getLocationInvoker
        {

          public:
            masls_getLocationInvoker ( CommunicationChannel& channel )
              : maslp_longitude(),
                maslp_latitude()

            {
              channel >> maslp_longitude;
              channel >> maslp_latitude;
            }
            void operator() ( ) { ::maslp_GPS_Watch::masld_Tracking::maslb_LOC::masls_getLocation( maslp_longitude, maslp_latitude ); }


          private:
            double maslp_longitude;
            double maslp_latitude;


        };
        class masls_registerListenerHandler
          : public ActionHandler
        {

          public:
            Callable getInvoker ( CommunicationChannel& channel ) const;
            void writeLocalVars ( CommunicationChannel&    channel,
                                  const ::SWA::StackFrame& frame ) const;


        };
        class masls_registerListenerInvoker
        {

          public:
            masls_registerListenerInvoker ( CommunicationChannel& channel )

            {
            }
            void operator() ( ) { ::maslp_GPS_Watch::masld_Tracking::maslb_LOC::masls_registerListener(); }


        };
        class masls_unregisterListenerHandler
          : public ActionHandler
        {

          public:
            Callable getInvoker ( CommunicationChannel& channel ) const;
            void writeLocalVars ( CommunicationChannel&    channel,
                                  const ::SWA::StackFrame& frame ) const;


        };
        class masls_unregisterListenerInvoker
        {

          public:
            masls_unregisterListenerInvoker ( CommunicationChannel& channel )

            {
            }
            void operator() ( ) { ::maslp_GPS_Watch::masld_Tracking::maslb_LOC::masls_unregisterListener(); }


        };
      }
      namespace maslb_UI
      {
        class masls_setDataHandler
          : public ActionHandler
        {

          public:
            Callable getInvoker ( CommunicationChannel& channel ) const;
            void writeLocalVars ( CommunicationChannel&    channel,
                                  const ::SWA::StackFrame& frame ) const;


        };
        class masls_setDataInvoker
        {

          public:
            masls_setDataInvoker ( CommunicationChannel& channel )
              : maslp_value(),
                maslp_unit()

            {
              channel >> maslp_value;
              channel >> maslp_unit;
            }
            void operator() ( ) { ::maslp_GPS_Watch::masld_Tracking::maslb_UI::masls_setData( maslp_value, maslp_unit ); }


          private:
            double maslp_value;
            ::masld_Tracking::maslt_Unit maslp_unit;


        };
        class masls_setIndicatorHandler
          : public ActionHandler
        {

          public:
            Callable getInvoker ( CommunicationChannel& channel ) const;
            void writeLocalVars ( CommunicationChannel&    channel,
                                  const ::SWA::StackFrame& frame ) const;


        };
        class masls_setIndicatorInvoker
        {

          public:
            masls_setIndicatorInvoker ( CommunicationChannel& channel )
              : maslp_indicator()
 { channel >> maslp_indicator; }
            void operator() ( ) { ::maslp_GPS_Watch::masld_Tracking::maslb_UI::masls_setIndicator( maslp_indicator ); }


          private:
            ::masld_Tracking::maslt_Indicator maslp_indicator;


        };
        class masls_setTimeHandler
          : public ActionHandler
        {

          public:
            Callable getInvoker ( CommunicationChannel& channel ) const;
            void writeLocalVars ( CommunicationChannel&    channel,
                                  const ::SWA::StackFrame& frame ) const;


        };
        class masls_setTimeInvoker
        {

          public:
            masls_setTimeInvoker ( CommunicationChannel& channel )
              : maslp_time()
 { channel >> maslp_time; }
            void operator() ( ) { ::maslp_GPS_Watch::masld_Tracking::maslb_UI::masls_setTime( maslp_time ); }


          private:
            int32_t maslp_time;


        };
      }
    }
    namespace masld_UI
    {
      namespace maslb_TRACK
      {
        class masls_setTargetPressedHandler
          : public ActionHandler
        {

          public:
            Callable getInvoker ( CommunicationChannel& channel ) const;
            void writeLocalVars ( CommunicationChannel&    channel,
                                  const ::SWA::StackFrame& frame ) const;


        };
        class masls_setTargetPressedInvoker
        {

          public:
            masls_setTargetPressedInvoker ( CommunicationChannel& channel )

            {
            }
            void operator() ( ) { ::maslp_GPS_Watch::masld_UI::maslb_TRACK::masls_setTargetPressed(); }


        };
        class masls_startStopPressedHandler
          : public ActionHandler
        {

          public:
            Callable getInvoker ( CommunicationChannel& channel ) const;
            void writeLocalVars ( CommunicationChannel&    channel,
                                  const ::SWA::StackFrame& frame ) const;


        };
        class masls_startStopPressedInvoker
        {

          public:
            masls_startStopPressedInvoker ( CommunicationChannel& channel )

            {
            }
            void operator() ( ) { ::maslp_GPS_Watch::masld_UI::maslb_TRACK::masls_startStopPressed(); }


        };
        class masls_lapResetPressedHandler
          : public ActionHandler
        {

          public:
            Callable getInvoker ( CommunicationChannel& channel ) const;
            void writeLocalVars ( CommunicationChannel&    channel,
                                  const ::SWA::StackFrame& frame ) const;


        };
        class masls_lapResetPressedInvoker
        {

          public:
            masls_lapResetPressedInvoker ( CommunicationChannel& channel )

            {
            }
            void operator() ( ) { ::maslp_GPS_Watch::masld_UI::maslb_TRACK::masls_lapResetPressed(); }


        };
        class masls_lightPressedHandler
          : public ActionHandler
        {

          public:
            Callable getInvoker ( CommunicationChannel& channel ) const;
            void writeLocalVars ( CommunicationChannel&    channel,
                                  const ::SWA::StackFrame& frame ) const;


        };
        class masls_lightPressedInvoker
        {

          public:
            masls_lightPressedInvoker ( CommunicationChannel& channel )

            {
            }
            void operator() ( ) { ::maslp_GPS_Watch::masld_UI::maslb_TRACK::masls_lightPressed(); }


        };
        class masls_modePressedHandler
          : public ActionHandler
        {

          public:
            Callable getInvoker ( CommunicationChannel& channel ) const;
            void writeLocalVars ( CommunicationChannel&    channel,
                                  const ::SWA::StackFrame& frame ) const;


        };
        class masls_modePressedInvoker
        {

          public:
            masls_modePressedInvoker ( CommunicationChannel& channel )

            {
            }
            void operator() ( ) { ::maslp_GPS_Watch::masld_UI::maslb_TRACK::masls_modePressed(); }


        };
        class masls_newGoalSpecHandler
          : public ActionHandler
        {

          public:
            Callable getInvoker ( CommunicationChannel& channel ) const;
            void writeLocalVars ( CommunicationChannel&    channel,
                                  const ::SWA::StackFrame& frame ) const;


        };
        class masls_newGoalSpecInvoker
        {

          public:
            masls_newGoalSpecInvoker ( CommunicationChannel& channel )
              : maslp_spanType(),
                maslp_criteriaType(),
                maslp_span(),
                maslp_maximum(),
                maslp_minimum(),
                maslp_sequenceNumber()

            {
              channel >> maslp_spanType;
              channel >> maslp_criteriaType;
              channel >> maslp_span;
              channel >> maslp_maximum;
              channel >> maslp_minimum;
              channel >> maslp_sequenceNumber;
            }
            void operator() ( ) { ::maslp_GPS_Watch::masld_UI::maslb_TRACK::masls_newGoalSpec( maslp_spanType, maslp_criteriaType, maslp_span, maslp_maximum, maslp_minimum, maslp_sequenceNumber ); }


          private:
            ::masld_UI::maslt_UIGoalSpan maslp_spanType;
            ::masld_UI::maslt_UIGoalCriteria maslp_criteriaType;
            double maslp_span;
            double maslp_maximum;
            double maslp_minimum;
            int32_t maslp_sequenceNumber;


        };
      }
    }
  }
}
namespace 
{
  bool initProcessInspector ( )
  {
    if ( ::masld_HeartRateMonitor::maslb_HRChange::overriden_masls_heartRateChanged() )
    {
      ::Inspector::ProcessHandler::getInstance().getDomainHandler( ::masld_HeartRateMonitor::getDomain().getId() ).getTerminatorHandler( ::masld_HeartRateMonitor::terminatorId_maslb_HRChange ).overrideServiceHandler( ::masld_HeartRateMonitor::maslb_HRChange::serviceId_masls_heartRateChanged, ::boost::shared_ptr< ::Inspector::ActionHandler>( new ::Inspector::maslp_GPS_Watch::masld_HeartRateMonitor::maslb_HRChange::masls_heartRateChangedHandler() ) );
    }
    if ( ::masld_Tracking::maslb_HR::overriden_masls_registerListener() )
    {
      ::Inspector::ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getTerminatorHandler( ::masld_Tracking::terminatorId_maslb_HR ).overrideServiceHandler( ::masld_Tracking::maslb_HR::serviceId_masls_registerListener, ::boost::shared_ptr< ::Inspector::ActionHandler>( new ::Inspector::maslp_GPS_Watch::masld_Tracking::maslb_HR::masls_registerListenerHandler() ) );
    }
    if ( ::masld_Tracking::maslb_HR::overriden_masls_unregisterListener() )
    {
      ::Inspector::ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getTerminatorHandler( ::masld_Tracking::terminatorId_maslb_HR ).overrideServiceHandler( ::masld_Tracking::maslb_HR::serviceId_masls_unregisterListener, ::boost::shared_ptr< ::Inspector::ActionHandler>( new ::Inspector::maslp_GPS_Watch::masld_Tracking::maslb_HR::masls_unregisterListenerHandler() ) );
    }
    if ( ::masld_Tracking::maslb_LOC::overriden_masls_getDistance() )
    {
      ::Inspector::ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getTerminatorHandler( ::masld_Tracking::terminatorId_maslb_LOC ).overrideServiceHandler( ::masld_Tracking::maslb_LOC::serviceId_masls_getDistance, ::boost::shared_ptr< ::Inspector::ActionHandler>( new ::Inspector::maslp_GPS_Watch::masld_Tracking::maslb_LOC::masls_getDistanceHandler() ) );
    }
    if ( ::masld_Tracking::maslb_LOC::overriden_masls_getLocation() )
    {
      ::Inspector::ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getTerminatorHandler( ::masld_Tracking::terminatorId_maslb_LOC ).overrideServiceHandler( ::masld_Tracking::maslb_LOC::serviceId_masls_getLocation, ::boost::shared_ptr< ::Inspector::ActionHandler>( new ::Inspector::maslp_GPS_Watch::masld_Tracking::maslb_LOC::masls_getLocationHandler() ) );
    }
    if ( ::masld_Tracking::maslb_LOC::overriden_masls_registerListener() )
    {
      ::Inspector::ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getTerminatorHandler( ::masld_Tracking::terminatorId_maslb_LOC ).overrideServiceHandler( ::masld_Tracking::maslb_LOC::serviceId_masls_registerListener, ::boost::shared_ptr< ::Inspector::ActionHandler>( new ::Inspector::maslp_GPS_Watch::masld_Tracking::maslb_LOC::masls_registerListenerHandler() ) );
    }
    if ( ::masld_Tracking::maslb_LOC::overriden_masls_unregisterListener() )
    {
      ::Inspector::ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getTerminatorHandler( ::masld_Tracking::terminatorId_maslb_LOC ).overrideServiceHandler( ::masld_Tracking::maslb_LOC::serviceId_masls_unregisterListener, ::boost::shared_ptr< ::Inspector::ActionHandler>( new ::Inspector::maslp_GPS_Watch::masld_Tracking::maslb_LOC::masls_unregisterListenerHandler() ) );
    }
    if ( ::masld_Tracking::maslb_UI::overriden_masls_setData() )
    {
      ::Inspector::ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getTerminatorHandler( ::masld_Tracking::terminatorId_maslb_UI ).overrideServiceHandler( ::masld_Tracking::maslb_UI::serviceId_masls_setData, ::boost::shared_ptr< ::Inspector::ActionHandler>( new ::Inspector::maslp_GPS_Watch::masld_Tracking::maslb_UI::masls_setDataHandler() ) );
    }
    if ( ::masld_Tracking::maslb_UI::overriden_masls_setIndicator() )
    {
      ::Inspector::ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getTerminatorHandler( ::masld_Tracking::terminatorId_maslb_UI ).overrideServiceHandler( ::masld_Tracking::maslb_UI::serviceId_masls_setIndicator, ::boost::shared_ptr< ::Inspector::ActionHandler>( new ::Inspector::maslp_GPS_Watch::masld_Tracking::maslb_UI::masls_setIndicatorHandler() ) );
    }
    if ( ::masld_Tracking::maslb_UI::overriden_masls_setTime() )
    {
      ::Inspector::ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getTerminatorHandler( ::masld_Tracking::terminatorId_maslb_UI ).overrideServiceHandler( ::masld_Tracking::maslb_UI::serviceId_masls_setTime, ::boost::shared_ptr< ::Inspector::ActionHandler>( new ::Inspector::maslp_GPS_Watch::masld_Tracking::maslb_UI::masls_setTimeHandler() ) );
    }
    if ( ::masld_UI::maslb_TRACK::overriden_masls_setTargetPressed() )
    {
      ::Inspector::ProcessHandler::getInstance().getDomainHandler( ::masld_UI::getDomain().getId() ).getTerminatorHandler( ::masld_UI::terminatorId_maslb_TRACK ).overrideServiceHandler( ::masld_UI::maslb_TRACK::serviceId_masls_setTargetPressed, ::boost::shared_ptr< ::Inspector::ActionHandler>( new ::Inspector::maslp_GPS_Watch::masld_UI::maslb_TRACK::masls_setTargetPressedHandler() ) );
    }
    if ( ::masld_UI::maslb_TRACK::overriden_masls_startStopPressed() )
    {
      ::Inspector::ProcessHandler::getInstance().getDomainHandler( ::masld_UI::getDomain().getId() ).getTerminatorHandler( ::masld_UI::terminatorId_maslb_TRACK ).overrideServiceHandler( ::masld_UI::maslb_TRACK::serviceId_masls_startStopPressed, ::boost::shared_ptr< ::Inspector::ActionHandler>( new ::Inspector::maslp_GPS_Watch::masld_UI::maslb_TRACK::masls_startStopPressedHandler() ) );
    }
    if ( ::masld_UI::maslb_TRACK::overriden_masls_lapResetPressed() )
    {
      ::Inspector::ProcessHandler::getInstance().getDomainHandler( ::masld_UI::getDomain().getId() ).getTerminatorHandler( ::masld_UI::terminatorId_maslb_TRACK ).overrideServiceHandler( ::masld_UI::maslb_TRACK::serviceId_masls_lapResetPressed, ::boost::shared_ptr< ::Inspector::ActionHandler>( new ::Inspector::maslp_GPS_Watch::masld_UI::maslb_TRACK::masls_lapResetPressedHandler() ) );
    }
    if ( ::masld_UI::maslb_TRACK::overriden_masls_lightPressed() )
    {
      ::Inspector::ProcessHandler::getInstance().getDomainHandler( ::masld_UI::getDomain().getId() ).getTerminatorHandler( ::masld_UI::terminatorId_maslb_TRACK ).overrideServiceHandler( ::masld_UI::maslb_TRACK::serviceId_masls_lightPressed, ::boost::shared_ptr< ::Inspector::ActionHandler>( new ::Inspector::maslp_GPS_Watch::masld_UI::maslb_TRACK::masls_lightPressedHandler() ) );
    }
    if ( ::masld_UI::maslb_TRACK::overriden_masls_modePressed() )
    {
      ::Inspector::ProcessHandler::getInstance().getDomainHandler( ::masld_UI::getDomain().getId() ).getTerminatorHandler( ::masld_UI::terminatorId_maslb_TRACK ).overrideServiceHandler( ::masld_UI::maslb_TRACK::serviceId_masls_modePressed, ::boost::shared_ptr< ::Inspector::ActionHandler>( new ::Inspector::maslp_GPS_Watch::masld_UI::maslb_TRACK::masls_modePressedHandler() ) );
    }
    if ( ::masld_UI::maslb_TRACK::overriden_masls_newGoalSpec() )
    {
      ::Inspector::ProcessHandler::getInstance().getDomainHandler( ::masld_UI::getDomain().getId() ).getTerminatorHandler( ::masld_UI::terminatorId_maslb_TRACK ).overrideServiceHandler( ::masld_UI::maslb_TRACK::serviceId_masls_newGoalSpec, ::boost::shared_ptr< ::Inspector::ActionHandler>( new ::Inspector::maslp_GPS_Watch::masld_UI::maslb_TRACK::masls_newGoalSpecHandler() ) );
    }
    return true;
  }

  bool initialised = initProcessInspector();

}
namespace Inspector
{
  namespace maslp_GPS_Watch
  {
    namespace masld_HeartRateMonitor
    {
      namespace maslb_HRChange
      {
        Callable masls_heartRateChangedHandler::getInvoker ( CommunicationChannel& channel ) const
        {
          return masls_heartRateChangedInvoker( channel );
        }

        void masls_heartRateChangedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                             const ::SWA::StackFrame& frame ) const
        {

          // Write heartRate
          channel << frame.getParameters()[0].getValue<int32_t>();

          // Write Local Variables
          channel << static_cast<int32_t>( frame.getLocalVars().size() );
        }

      }
    }
    namespace masld_Tracking
    {
      namespace maslb_HR
      {
        Callable masls_registerListenerHandler::getInvoker ( CommunicationChannel& channel ) const
        {
          return masls_registerListenerInvoker( channel );
        }

        void masls_registerListenerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                             const ::SWA::StackFrame& frame ) const
        {

          // Write Local Variables
          channel << static_cast<int32_t>( frame.getLocalVars().size() );
        }

        Callable masls_unregisterListenerHandler::getInvoker ( CommunicationChannel& channel ) const
        {
          return masls_unregisterListenerInvoker( channel );
        }

        void masls_unregisterListenerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                               const ::SWA::StackFrame& frame ) const
        {

          // Write Local Variables
          channel << static_cast<int32_t>( frame.getLocalVars().size() );
        }

      }
      namespace maslb_LOC
      {
        Callable masls_getDistanceHandler::getInvoker ( CommunicationChannel& channel ) const
        {
          return masls_getDistanceInvoker( channel );
        }

        void masls_getDistanceHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                        const ::SWA::StackFrame& frame ) const
        {

          // Write result
          channel << frame.getParameters()[0].getValue<double>();

          // Write toLong
          channel << frame.getParameters()[1].getValue<double>();

          // Write toLat
          channel << frame.getParameters()[2].getValue<double>();

          // Write fromLong
          channel << frame.getParameters()[3].getValue<double>();

          // Write fromLat
          channel << frame.getParameters()[4].getValue<double>();

          // Write Local Variables
          channel << static_cast<int32_t>( frame.getLocalVars().size() );
          for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
          {
            channel << frame.getLocalVars()[i].getId();
            switch ( frame.getLocalVars()[i].getId() )
            {
              case 0:

                // Write distance
                channel << frame.getLocalVars()[i].getValue<double>();
                break;

            }

          }
        }

        Callable masls_getLocationHandler::getInvoker ( CommunicationChannel& channel ) const
        {
          return masls_getLocationInvoker( channel );
        }

        void masls_getLocationHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                        const ::SWA::StackFrame& frame ) const
        {

          // Write longitude
          channel << frame.getParameters()[0].getValue<double>();

          // Write latitude
          channel << frame.getParameters()[1].getValue<double>();

          // Write Local Variables
          channel << static_cast<int32_t>( frame.getLocalVars().size() );
          for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
          {
            channel << frame.getLocalVars()[i].getId();
            switch ( frame.getLocalVars()[i].getId() )
            {
              case 0:

                // Write lat
                channel << frame.getLocalVars()[i].getValue<double>();
                break;

              case 1:

                // Write longi
                channel << frame.getLocalVars()[i].getValue<double>();
                break;

            }

          }
        }

        Callable masls_registerListenerHandler::getInvoker ( CommunicationChannel& channel ) const
        {
          return masls_registerListenerInvoker( channel );
        }

        void masls_registerListenerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                             const ::SWA::StackFrame& frame ) const
        {

          // Write Local Variables
          channel << static_cast<int32_t>( frame.getLocalVars().size() );
        }

        Callable masls_unregisterListenerHandler::getInvoker ( CommunicationChannel& channel ) const
        {
          return masls_unregisterListenerInvoker( channel );
        }

        void masls_unregisterListenerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                               const ::SWA::StackFrame& frame ) const
        {

          // Write Local Variables
          channel << static_cast<int32_t>( frame.getLocalVars().size() );
        }

      }
      namespace maslb_UI
      {
        Callable masls_setDataHandler::getInvoker ( CommunicationChannel& channel ) const
        {
          return masls_setDataInvoker( channel );
        }

        void masls_setDataHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                    const ::SWA::StackFrame& frame ) const
        {

          // Write value
          channel << frame.getParameters()[0].getValue<double>();

          // Write unit
          channel << frame.getParameters()[1].getValue< ::masld_Tracking::maslt_Unit>();

          // Write Local Variables
          channel << static_cast<int32_t>( frame.getLocalVars().size() );
        }

        Callable masls_setIndicatorHandler::getInvoker ( CommunicationChannel& channel ) const
        {
          return masls_setIndicatorInvoker( channel );
        }

        void masls_setIndicatorHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                         const ::SWA::StackFrame& frame ) const
        {

          // Write indicator
          channel << frame.getParameters()[0].getValue< ::masld_Tracking::maslt_Indicator>();

          // Write Local Variables
          channel << static_cast<int32_t>( frame.getLocalVars().size() );
        }

        Callable masls_setTimeHandler::getInvoker ( CommunicationChannel& channel ) const
        {
          return masls_setTimeInvoker( channel );
        }

        void masls_setTimeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                    const ::SWA::StackFrame& frame ) const
        {

          // Write time
          channel << frame.getParameters()[0].getValue<int32_t>();

          // Write Local Variables
          channel << static_cast<int32_t>( frame.getLocalVars().size() );
        }

      }
    }
    namespace masld_UI
    {
      namespace maslb_TRACK
      {
        Callable masls_setTargetPressedHandler::getInvoker ( CommunicationChannel& channel ) const
        {
          return masls_setTargetPressedInvoker( channel );
        }

        void masls_setTargetPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                             const ::SWA::StackFrame& frame ) const
        {

          // Write Local Variables
          channel << static_cast<int32_t>( frame.getLocalVars().size() );
        }

        Callable masls_startStopPressedHandler::getInvoker ( CommunicationChannel& channel ) const
        {
          return masls_startStopPressedInvoker( channel );
        }

        void masls_startStopPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                             const ::SWA::StackFrame& frame ) const
        {

          // Write Local Variables
          channel << static_cast<int32_t>( frame.getLocalVars().size() );
        }

        Callable masls_lapResetPressedHandler::getInvoker ( CommunicationChannel& channel ) const
        {
          return masls_lapResetPressedInvoker( channel );
        }

        void masls_lapResetPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                            const ::SWA::StackFrame& frame ) const
        {

          // Write Local Variables
          channel << static_cast<int32_t>( frame.getLocalVars().size() );
        }

        Callable masls_lightPressedHandler::getInvoker ( CommunicationChannel& channel ) const
        {
          return masls_lightPressedInvoker( channel );
        }

        void masls_lightPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                         const ::SWA::StackFrame& frame ) const
        {

          // Write Local Variables
          channel << static_cast<int32_t>( frame.getLocalVars().size() );
        }

        Callable masls_modePressedHandler::getInvoker ( CommunicationChannel& channel ) const
        {
          return masls_modePressedInvoker( channel );
        }

        void masls_modePressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                        const ::SWA::StackFrame& frame ) const
        {

          // Write Local Variables
          channel << static_cast<int32_t>( frame.getLocalVars().size() );
        }

        Callable masls_newGoalSpecHandler::getInvoker ( CommunicationChannel& channel ) const
        {
          return masls_newGoalSpecInvoker( channel );
        }

        void masls_newGoalSpecHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                        const ::SWA::StackFrame& frame ) const
        {

          // Write spanType
          channel << frame.getParameters()[0].getValue< ::masld_UI::maslt_UIGoalSpan>();

          // Write criteriaType
          channel << frame.getParameters()[1].getValue< ::masld_UI::maslt_UIGoalCriteria>();

          // Write span
          channel << frame.getParameters()[2].getValue<double>();

          // Write maximum
          channel << frame.getParameters()[3].getValue<double>();

          // Write minimum
          channel << frame.getParameters()[4].getValue<double>();

          // Write sequenceNumber
          channel << frame.getParameters()[5].getValue<int32_t>();

          // Write Local Variables
          channel << static_cast<int32_t>( frame.getLocalVars().size() );
        }

      }
    }
  }
}
