//
// File: __GPS_Watch__HeartRateMonitor__HRChange__heartRateChanged.hh
//
#ifndef _GPS_Watch_Heart_Rate_Monitor_HR_Change_heart_Rate_Changed_hh
#define _GPS_Watch_Heart_Rate_Monitor_HR_Change_heart_Rate_Changed_hh

#include <stdint.h>

namespace maslp_GPS_Watch
{
  namespace masld_HeartRateMonitor
  {
    namespace maslb_HRChange
    {
      void masls_heartRateChanged ( int32_t maslp_heartRate );
    }
  }
}
#endif // _GPS_Watch_Heart_Rate_Monitor_HR_Change_heart_Rate_Changed_hh
