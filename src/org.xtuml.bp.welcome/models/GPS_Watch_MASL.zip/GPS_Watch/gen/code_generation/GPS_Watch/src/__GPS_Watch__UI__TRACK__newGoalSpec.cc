//
// File: __GPS_Watch__UI__TRACK__newGoalSpec.cc
//
#include "Tracking_OOA/__Tracking_services.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_terminators.hh"
#include "UI_OOA/__UI_types.hh"
#include "__GPS_Watch__UI__TRACK__newGoalSpec.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"

namespace maslp_GPS_Watch
{
  namespace masld_UI
  {
    namespace maslb_TRACK
    {
      bool register_masls_newGoalSpec = ::masld_UI::maslb_TRACK::register_masls_newGoalSpec( &masls_newGoalSpec );

      void masls_newGoalSpec ( const ::masld_UI::maslt_UIGoalSpan&     maslp_spanType,
                               const ::masld_UI::maslt_UIGoalCriteria& maslp_criteriaType,
                               double                                  maslp_span,
                               double                                  maslp_maximum,
                               double                                  maslp_minimum,
                               int32_t                                 maslp_sequenceNumber )
      {

        // begin ...
        // end;
        {
          ::SWA::Stack::EnteringTerminatorService enteringActionMarker(::masld_UI::getDomain().getId(), ::masld_UI::terminatorId_maslb_TRACK, ::masld_UI::maslb_TRACK::serviceId_masls_newGoalSpec);
          ::SWA::Stack::DeclareParameter pm_maslp_spanType(maslp_spanType);
          ::SWA::Stack::DeclareParameter pm_maslp_criteriaType(maslp_criteriaType);
          ::SWA::Stack::DeclareParameter pm_maslp_span(maslp_span);
          ::SWA::Stack::DeclareParameter pm_maslp_maximum(maslp_maximum);
          ::SWA::Stack::DeclareParameter pm_maslp_minimum(maslp_minimum);
          ::SWA::Stack::DeclareParameter pm_maslp_sequenceNumber(maslp_sequenceNumber);
          ::SWA::Stack::EnteredAction enteredActionMarker;
          ::SWA::Stack::ExecutingStatement statement(7);
          {

            // if (criteriaType = UI::UIGoalCriteria.HeartRate) then ...
            // elsif (criteriaType = UI::UIGoalCriteria.Pace) then ...
            {
              ::SWA::Stack::ExecutingStatement statement(8);
              if ( maslp_criteriaType == ::masld_UI::maslt_UIGoalCriteria::masle_HeartRate )
              {

                // if (spanType = UI::UIGoalSpan.Distance) then ...
                // elsif (spanType = UI::UIGoalSpan.Time) then ...
                {
                  ::SWA::Stack::ExecutingStatement statement(9);
                  if ( maslp_spanType == ::masld_UI::maslt_UIGoalSpan::masle_Distance )
                  {

                    // Tracking::newGoalSpec(Tracking::GoalSpan.Distance, Tracking::GoalCriteria.HeartRate, span, maximum, minimum, sequenceNumber)
                    {
                      ::SWA::Stack::ExecutingStatement statement(10);
                      ::masld_Tracking::interceptor_masls_newGoalSpec::instance().callService()( ::masld_Tracking::maslt_GoalSpan::masle_Distance, ::masld_Tracking::maslt_GoalCriteria::masle_HeartRate, maslp_span, maslp_maximum, maslp_minimum, maslp_sequenceNumber );
                    }
                  }
                  else if ( maslp_spanType == ::masld_UI::maslt_UIGoalSpan::masle_Time )
                  {

                    // Tracking::newGoalSpec(Tracking::GoalSpan.Time, Tracking::GoalCriteria.HeartRate, span, maximum, minimum, sequenceNumber)
                    {
                      ::SWA::Stack::ExecutingStatement statement(12);
                      ::masld_Tracking::interceptor_masls_newGoalSpec::instance().callService()( ::masld_Tracking::maslt_GoalSpan::masle_Time, ::masld_Tracking::maslt_GoalCriteria::masle_HeartRate, maslp_span, maslp_maximum, maslp_minimum, maslp_sequenceNumber );
                    }
                  }
                }
              }
              else if ( maslp_criteriaType == ::masld_UI::maslt_UIGoalCriteria::masle_Pace )
              {

                // if (spanType = UI::UIGoalSpan.Distance) then ...
                // elsif (spanType = UI::UIGoalSpan.Time) then ...
                {
                  ::SWA::Stack::ExecutingStatement statement(15);
                  if ( maslp_spanType == ::masld_UI::maslt_UIGoalSpan::masle_Distance )
                  {

                    // Tracking::newGoalSpec(Tracking::GoalSpan.Distance, Tracking::GoalCriteria.Pace, span, maximum, minimum, sequenceNumber)
                    {
                      ::SWA::Stack::ExecutingStatement statement(16);
                      ::masld_Tracking::interceptor_masls_newGoalSpec::instance().callService()( ::masld_Tracking::maslt_GoalSpan::masle_Distance, ::masld_Tracking::maslt_GoalCriteria::masle_Pace, maslp_span, maslp_maximum, maslp_minimum, maslp_sequenceNumber );
                    }
                  }
                  else if ( maslp_spanType == ::masld_UI::maslt_UIGoalSpan::masle_Time )
                  {

                    // Tracking::newGoalSpec(Tracking::GoalSpan.Time, Tracking::GoalCriteria.Pace, span, maximum, minimum, sequenceNumber)
                    {
                      ::SWA::Stack::ExecutingStatement statement(18);
                      ::masld_Tracking::interceptor_masls_newGoalSpec::instance().callService()( ::masld_Tracking::maslt_GoalSpan::masle_Time, ::masld_Tracking::maslt_GoalCriteria::masle_Pace, maslp_span, maslp_maximum, maslp_minimum, maslp_sequenceNumber );
                    }
                  }
                }
              }
            }
          }
        }
      }

    }
  }
}
