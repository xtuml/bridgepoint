//
// File: __LOG_types.cc
//
