//
// File: __LOG_private_services.hh
//
#ifndef _LOG_private_services_hh
#define _LOG_private_services_hh

#endif // _LOG_private_services_hh
