//
// File: __LOG__LogFailure.cc
//
#include "LOG_OOA/__LOG_interface.hh"
#include "LOG_OOA/__LOG_services.hh"
#include "Logger_OOA/__Logger_services.hh"
#include "Logger_OOA/__Logger_types.hh"
#include "swa/Domain.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"

namespace masld_LOG
{
  void masls_LogFailure ( const ::SWA::String& maslp_message )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_LogFailure);
      ::SWA::Stack::DeclareParameter pm_maslp_message(maslp_message);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // Logger::log(Logger::Priority.Error, message)
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          ::masld_Logger::interceptor_masls_log::instance().callService()( ::masld_Logger::maslt_Priority::masle_Error, maslp_message );
        }
      }
    }
  }

  const bool localServiceRegistration_masls_LogFailure = interceptor_masls_LogFailure::instance().registerLocal( &masls_LogFailure );

}
