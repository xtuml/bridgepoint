//
// File: Inspector_types__LOG.cc
//
