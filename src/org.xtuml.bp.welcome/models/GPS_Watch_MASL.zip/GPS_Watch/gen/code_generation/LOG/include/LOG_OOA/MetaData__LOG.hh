//
// File: MetaData__LOG.hh
//
#ifndef LOG_OOA_Meta_Data_LOG_hh
#define LOG_OOA_Meta_Data_LOG_hh

namespace masld_LOG
{
  enum TypeIds {};
}
#endif // LOG_OOA_Meta_Data_LOG_hh
