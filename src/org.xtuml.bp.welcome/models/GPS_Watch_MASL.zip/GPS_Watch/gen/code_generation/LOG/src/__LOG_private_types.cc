//
// File: __LOG_private_types.cc
//
