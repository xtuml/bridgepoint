//
// File: Inspector_private_types__LOG.cc
//
