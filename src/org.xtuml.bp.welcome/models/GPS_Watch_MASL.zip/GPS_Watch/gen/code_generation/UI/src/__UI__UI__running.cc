//
// File: __UI__UI__running.cc
//
#include "UI_OOA/__UI.hh"
#include "UI_OOA/__UI_interface.hh"
#include "__UI__UI.hh"
#include "__UI__UIConstants.hh"
#include "boost/shared_ptr.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace masld_UI
{
  void maslo_UI::state_maslst_running ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_UI, stateId_maslst_running);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(5);
      {

        // uiconst : instance of UIConstants;
        ::SWA::ObjectPtr<maslo_UIConstants> maslv_uiconst;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_uiconst(0, maslv_uiconst);

        // ui : instance of UI;
        ::SWA::ObjectPtr<maslo_UI> maslv_ui;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_ui(1, maslv_ui);

        // signal_no : integer;
        int32_t maslv_signal_no = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_signal_no(2, maslv_signal_no);

        // UIConstants.initialize()
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          maslo_UIConstants::masls_initialize();
        }

        // uiconst := find_one UIConstants ();
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          maslv_uiconst = maslo_UIConstants::findOne();
        }

        // signal_no := this.poll();
        {
          ::SWA::Stack::ExecutingStatement statement(8);
          maslv_signal_no = ::SWA::ObjectPtr<maslo_UI>( this )->masls_poll();
        }

        // if (uiconst.SOCKET_ERROR = signal_no) then ...
        // elsif (uiconst.SIGNAL_NO_START_STOP_PRESSED = signal_no) then ...
        // elsif (uiconst.SIGNAL_NO_TARGET_PRESSED = signal_no) then ...
        // elsif (uiconst.SIGNAL_NO_LAP_RESET_PRESSED = signal_no) then ...
        // elsif (uiconst.SIGNAL_NO_LIGHT_PRESSED = signal_no) then ...
        // elsif (uiconst.SIGNAL_NO_MODE_PRESSED = signal_no) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(9);
          if ( maslv_uiconst->get_masla_SOCKET_ERROR() == maslv_signal_no )
          {

            // this.socket_id := uiconst.SOCKET_ERROR;
            {
              ::SWA::Stack::ExecutingStatement statement(10);
              ::SWA::ObjectPtr<maslo_UI>( this )->set_masla_socket_id( maslv_uiconst->get_masla_SOCKET_ERROR() );
            }

            // cancel this.timer;
            {
              ::SWA::Stack::ExecutingStatement statement(11);
              ::SWA::EventTimers::getInstance().cancelTimer( ::SWA::ObjectPtr<maslo_UI>( this )->get_masla_timer() );
            }
          }
          else if ( maslv_uiconst->get_masla_SIGNAL_NO_START_STOP_PRESSED() == maslv_signal_no )
          {

            // generate UI.startStopPressed () to this;
            {
              ::SWA::Stack::ExecutingStatement statement(13);
              ::SWA::Process::getInstance().getEventQueue().addEvent( ::SWA::ObjectPtr<maslo_UI>( this )->create_maslo_UI_maslev_startStopPressed( objectId_maslo_UI, getArchitectureId() ) );
            }
          }
          else if ( maslv_uiconst->get_masla_SIGNAL_NO_TARGET_PRESSED() == maslv_signal_no )
          {

            // generate UI.setTargetPressed () to this;
            {
              ::SWA::Stack::ExecutingStatement statement(15);
              ::SWA::Process::getInstance().getEventQueue().addEvent( ::SWA::ObjectPtr<maslo_UI>( this )->create_maslo_UI_maslev_setTargetPressed( objectId_maslo_UI, getArchitectureId() ) );
            }
          }
          else if ( maslv_uiconst->get_masla_SIGNAL_NO_LAP_RESET_PRESSED() == maslv_signal_no )
          {

            // generate UI.lapResetPressed () to this;
            {
              ::SWA::Stack::ExecutingStatement statement(17);
              ::SWA::Process::getInstance().getEventQueue().addEvent( ::SWA::ObjectPtr<maslo_UI>( this )->create_maslo_UI_maslev_lapResetPressed( objectId_maslo_UI, getArchitectureId() ) );
            }
          }
          else if ( maslv_uiconst->get_masla_SIGNAL_NO_LIGHT_PRESSED() == maslv_signal_no )
          {

            // generate UI.lightPressed () to this;
            {
              ::SWA::Stack::ExecutingStatement statement(19);
              ::SWA::Process::getInstance().getEventQueue().addEvent( ::SWA::ObjectPtr<maslo_UI>( this )->create_maslo_UI_maslev_lightPressed( objectId_maslo_UI, getArchitectureId() ) );
            }
          }
          else if ( maslv_uiconst->get_masla_SIGNAL_NO_MODE_PRESSED() == maslv_signal_no )
          {

            // generate UI.modePressed () to this;
            {
              ::SWA::Stack::ExecutingStatement statement(21);
              ::SWA::Process::getInstance().getEventQueue().addEvent( ::SWA::ObjectPtr<maslo_UI>( this )->create_maslo_UI_maslev_modePressed( objectId_maslo_UI, getArchitectureId() ) );
            }
          }
        }
      }
    }
  }

}
