//
// File: Sqlite__UI__UIConstantsPopulation.hh
//
#ifndef Sqlite_UI_UI_Constants_Population_hh
#define Sqlite_UI_UI_Constants_Population_hh

#include "Sqlite__UI__UIConstants.hh"
#include "Sqlite__UI__UIConstantsMapper.hh"
#include "__UI__UIConstants.hh"
#include "__UI__UIConstantsPopulation.hh"
#include "boost/signals2.hpp"
#include "sql/Population.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_UI
  {
    class maslo_UIConstantsPopulation
      : public ::SQL::SqlPopulation< ::masld_UI::maslo_UIConstants,maslo_UIConstants,maslo_UIConstantsMapper,::masld_UI::maslo_UIConstantsPopulation>
    {

      // Constructors and Destructors
      private:
        maslo_UIConstantsPopulation ( );
        ~maslo_UIConstantsPopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> createInstance ( int32_t masla_id,
                                                                                  int32_t masla_SIGNAL_NO_NULL_SIGNAL,
                                                                                  int32_t masla_SIGNAL_NO_START_STOP_PRESSED,
                                                                                  int32_t masla_SIGNAL_NO_TARGET_PRESSED,
                                                                                  int32_t masla_SIGNAL_NO_LAP_RESET_PRESSED,
                                                                                  int32_t masla_SIGNAL_NO_LIGHT_PRESSED,
                                                                                  int32_t masla_SIGNAL_NO_MODE_PRESSED,
                                                                                  int32_t masla_SOCKET_ERROR,
                                                                                  int32_t masla_tick_period );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> instance );


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Singleton Registration
      public:
        static maslo_UIConstantsPopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;


    };
  }
}
#endif // Sqlite_UI_UI_Constants_Population_hh
