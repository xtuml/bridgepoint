//
// File: Sqlite__UI__UIPopulation.hh
//
#ifndef Sqlite_UI_UI_Population_hh
#define Sqlite_UI_UI_Population_hh

#include "Sqlite__UI__UI.hh"
#include "Sqlite__UI__UIMapper.hh"
#include "__UI__UI.hh"
#include "__UI__UIPopulation.hh"
#include "boost/signals2.hpp"
#include "sql/Population.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_UI
  {
    class maslo_UIPopulation
      : public ::SQL::SqlPopulation< ::masld_UI::maslo_UI,maslo_UI,maslo_UIMapper,::masld_UI::maslo_UIPopulation>
    {

      // Constructors and Destructors
      private:
        maslo_UIPopulation ( );
        ~maslo_UIPopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_UI::maslo_UI> createInstance ( int32_t                                masla_id,
                                                                         int32_t                                masla_socket_id,
                                                                         const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                         ::masld_UI::maslo_UI::Type             currentState );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_UI::maslo_UI> instance );


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_UI::maslo_UI> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_UI::maslo_UI> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Singleton Registration
      public:
        static maslo_UIPopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;


    };
  }
}
#endif // Sqlite_UI_UI_Population_hh
