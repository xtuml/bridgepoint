//
// File: Sqlite__UI__UI.cc
//
#include "Sqlite__UI__UI.hh"
#include "Sqlite__UI__UIPopulation.hh"
#include "UI_OOA/__UI.hh"
#include "UI_OOA/__UI_interface.hh"
#include "__UI__UI.hh"
#include "__UI__UIEvents.hh"
#include "boost/shared_ptr.hpp"
#include "sqlite/BlobData.hh"
#include "sqlite/EventParameterCodecs.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_UI
  {
    maslo_UI::maslo_UI ( ::SWA::IdType                          architectureId,
                         int32_t                                masla_id,
                         int32_t                                masla_socket_id,
                         const ::SWA::EventTimers::TimerIdType& masla_timer,
                         ::masld_UI::maslo_UI::Type             currentState )
      : architectureId(architectureId),
        masla_id(masla_id),
        masla_socket_id(masla_socket_id),
        masla_timer(masla_timer),
        currentState(currentState),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_UI::maslo_UI ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_id(),
        masla_socket_id(),
        masla_timer(),
        currentState(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_UI::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_UI::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_UIPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_UI::PrimaryKeyType maslo_UI::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_id );
    }

    const maslo_UI::IndexKeyType_1 maslo_UI::get_index_1 ( )
    {
      return IndexKeyType_1( masla_id );
    }

    void encode_maslo_UI_maslev_setTargetPressed ( ::boost::shared_ptr< ::SWA::Event> event,
                                                   BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_UI_maslev_setTargetPressed ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_UI::Event_maslo_UI_maslev_setTargetPressed() );
    }

    bool registermaslo_UI_maslev_setTargetPressed = EventParameterCodecs::getInstance().registerCodec( ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_UI, ::masld_UI::maslo_UI::eventId_maslo_UI_maslev_setTargetPressed, &encode_maslo_UI_maslev_setTargetPressed, &decode_maslo_UI_maslev_setTargetPressed );

    void encode_maslo_UI_maslev_startStopPressed ( ::boost::shared_ptr< ::SWA::Event> event,
                                                   BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_UI_maslev_startStopPressed ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_UI::Event_maslo_UI_maslev_startStopPressed() );
    }

    bool registermaslo_UI_maslev_startStopPressed = EventParameterCodecs::getInstance().registerCodec( ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_UI, ::masld_UI::maslo_UI::eventId_maslo_UI_maslev_startStopPressed, &encode_maslo_UI_maslev_startStopPressed, &decode_maslo_UI_maslev_startStopPressed );

    void encode_maslo_UI_maslev_lapResetPressed ( ::boost::shared_ptr< ::SWA::Event> event,
                                                  BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_UI_maslev_lapResetPressed ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_UI::Event_maslo_UI_maslev_lapResetPressed() );
    }

    bool registermaslo_UI_maslev_lapResetPressed = EventParameterCodecs::getInstance().registerCodec( ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_UI, ::masld_UI::maslo_UI::eventId_maslo_UI_maslev_lapResetPressed, &encode_maslo_UI_maslev_lapResetPressed, &decode_maslo_UI_maslev_lapResetPressed );

    void encode_maslo_UI_maslev_lightPressed ( ::boost::shared_ptr< ::SWA::Event> event,
                                               BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_UI_maslev_lightPressed ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_UI::Event_maslo_UI_maslev_lightPressed() );
    }

    bool registermaslo_UI_maslev_lightPressed = EventParameterCodecs::getInstance().registerCodec( ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_UI, ::masld_UI::maslo_UI::eventId_maslo_UI_maslev_lightPressed, &encode_maslo_UI_maslev_lightPressed, &decode_maslo_UI_maslev_lightPressed );

    void encode_maslo_UI_maslev_modePressed ( ::boost::shared_ptr< ::SWA::Event> event,
                                              BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_UI_maslev_modePressed ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_UI::Event_maslo_UI_maslev_modePressed() );
    }

    bool registermaslo_UI_maslev_modePressed = EventParameterCodecs::getInstance().registerCodec( ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_UI, ::masld_UI::maslo_UI::eventId_maslo_UI_maslev_modePressed, &encode_maslo_UI_maslev_modePressed, &decode_maslo_UI_maslev_modePressed );

    void encode_maslo_UI_maslev_running ( ::boost::shared_ptr< ::SWA::Event> event,
                                          BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_UI_maslev_running ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_UI::Event_maslo_UI_maslev_running() );
    }

    bool registermaslo_UI_maslev_running = EventParameterCodecs::getInstance().registerCodec( ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_UI, ::masld_UI::maslo_UI::eventId_maslo_UI_maslev_running, &encode_maslo_UI_maslev_running, &decode_maslo_UI_maslev_running );

    void encode_maslo_UI_maslev_tick ( ::boost::shared_ptr< ::SWA::Event> event,
                                       BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_UI_maslev_tick ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_UI::Event_maslo_UI_maslev_tick() );
    }

    bool registermaslo_UI_maslev_tick = EventParameterCodecs::getInstance().registerCodec( ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_UI, ::masld_UI::maslo_UI::eventId_maslo_UI_maslev_tick, &encode_maslo_UI_maslev_tick, &decode_maslo_UI_maslev_tick );

  }
}
