//
// File: Sqlite__UI__UIMapper.cc
//
#include "Sqlite__UI__UI.hh"
#include "Sqlite__UI__UIMapper.hh"
#include "Sqlite__UI__UIMapperSql.hh"
#include "__UI__UI.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_UI
  {
    maslo_UIMapper::maslo_UIMapper ( )
      : ::SQL::ObjectMapper< ::masld_UI::maslo_UI,maslo_UI>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_UI::maslo_UI,maslo_UI> >( new maslo_UISqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_UIMapper::~maslo_UIMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_UI::maslo_UI> maslo_UIMapper::createInstance ( int32_t                                masla_id,
                                                                             int32_t                                masla_socket_id,
                                                                             const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                             ::masld_UI::maslo_UI::Type             currentState )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_UI::PrimaryKeyType>::value_type( masla_id ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_UI> instance(new maslo_UI(  uniqueId,
               masla_id,
               masla_socket_id,
               masla_timer,
               currentState ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_UIMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_UI::maslo_UI> instance )
    {
      ::SQL::ObjectMapper< ::masld_UI::maslo_UI,maslo_UI>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_UI>()->getPrimaryKey() );
    }

    bool maslo_UIMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
