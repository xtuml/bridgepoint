//
// File: Transient__UI__TestCasePopulation.cc
//
#include "Transient__UI__TestCase.hh"
#include "Transient__UI__TestCasePopulation.hh"
#include "__UI__TestCase.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"

namespace transient
{
  namespace masld_UI
  {
    maslo_TestCasePopulation::maslo_TestCasePopulation ( )
      : masla_id_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> maslo_TestCasePopulation::createInstance ( int32_t                          masla_iterations,
                                                                                             int32_t                          masla_id,
                                                                                             ::masld_UI::maslo_TestCase::Type currentState )
    {
      if ( exists_masla_id( masla_id ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> instance(new maslo_TestCase(  masla_iterations,
                     masla_id,
                     currentState ));
      addInstance( instance );
      return instance;
    }

    void maslo_TestCasePopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> instance )
    {
      masla_id_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> >::value_type( ::boost::make_tuple( instance->get_masla_id() ), instance ) );
    }

    void maslo_TestCasePopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> instance )
    {
      masla_id_Lookup.erase( ::boost::make_tuple( instance->get_masla_id() ) );
    }

    bool maslo_TestCasePopulation::exists_masla_id ( int32_t masla_id ) const
    {
      return masla_id_Lookup.find( ::boost::make_tuple( masla_id ) ) != masla_id_Lookup.end();
    }

    maslo_TestCasePopulation& maslo_TestCasePopulation::getPopulation ( )
    {
      static maslo_TestCasePopulation population;
      return population;
    }

    bool maslo_TestCasePopulation::registered = maslo_TestCasePopulation::registerSingleton( &maslo_TestCasePopulation::getPopulation );

  }
}
