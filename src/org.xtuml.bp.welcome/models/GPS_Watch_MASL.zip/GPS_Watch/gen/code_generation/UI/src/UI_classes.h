/* Included for compatibliity with OAL implementation of GuiBridge */
