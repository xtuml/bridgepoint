//
// File: Inspector_types__UI.cc
//
#include "UI_OOA/__UI_types.hh"
#include "inspector/BufferedIO.hh"

namespace Inspector
{
  template<>
  void BufferedOutputStream::write< ::masld_UI::maslt_UIGoalCriteria> ( const ::masld_UI::maslt_UIGoalCriteria& value )
  {
    write( static_cast<int>( value.getIndex() ) );
  }

  template<>
  void BufferedInputStream::read< ::masld_UI::maslt_UIGoalCriteria> ( ::masld_UI::maslt_UIGoalCriteria& value )
  {
    int index;
    read( index );
    value = ::masld_UI::maslt_UIGoalCriteria( ::masld_UI::maslt_UIGoalCriteria::Index( index ) );
  }

  template<>
  void BufferedOutputStream::write< ::masld_UI::maslt_UIGoalSpan> ( const ::masld_UI::maslt_UIGoalSpan& value )
  {
    write( static_cast<int>( value.getIndex() ) );
  }

  template<>
  void BufferedInputStream::read< ::masld_UI::maslt_UIGoalSpan> ( ::masld_UI::maslt_UIGoalSpan& value )
  {
    int index;
    read( index );
    value = ::masld_UI::maslt_UIGoalSpan( ::masld_UI::maslt_UIGoalSpan::Index( index ) );
  }

  template<>
  void BufferedOutputStream::write< ::masld_UI::maslt_UIIndicator> ( const ::masld_UI::maslt_UIIndicator& value )
  {
    write( static_cast<int>( value.getIndex() ) );
  }

  template<>
  void BufferedInputStream::read< ::masld_UI::maslt_UIIndicator> ( ::masld_UI::maslt_UIIndicator& value )
  {
    int index;
    read( index );
    value = ::masld_UI::maslt_UIIndicator( ::masld_UI::maslt_UIIndicator::Index( index ) );
  }

  template<>
  void BufferedOutputStream::write< ::masld_UI::maslt_UIUnit> ( const ::masld_UI::maslt_UIUnit& value )
  {
    write( static_cast<int>( value.getIndex() ) );
  }

  template<>
  void BufferedInputStream::read< ::masld_UI::maslt_UIUnit> ( ::masld_UI::maslt_UIUnit& value )
  {
    int index;
    read( index );
    value = ::masld_UI::maslt_UIUnit( ::masld_UI::maslt_UIUnit::Index( index ) );
  }

}
