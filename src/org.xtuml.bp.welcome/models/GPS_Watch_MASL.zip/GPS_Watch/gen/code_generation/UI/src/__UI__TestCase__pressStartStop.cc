//
// File: __UI__TestCase__pressStartStop.cc
//
#include "UI_OOA/__UI.hh"
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_terminators.hh"
#include "__UI__TestCase.hh"
#include "boost/shared_ptr.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Duration.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_UI
{
  void maslo_TestCase::state_maslst_pressStartStop ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_TestCase, stateId_maslst_pressStartStop);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // handle : timer;
        ::SWA::EventTimers::TimerIdType maslv_handle = ::SWA::EventTimers::TimerIdType();
        ::SWA::Stack::DeclareLocalVariable pm_maslv_handle(0, maslv_handle);

        // if (this.iterations > 0) then ...
        // else ...
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          if ( ::SWA::ObjectPtr<maslo_TestCase>( this )->get_masla_iterations() > 0ll )
          {

            // this.iterations := (this.iterations - 1);
            {
              ::SWA::Stack::ExecutingStatement statement(5);
              ::SWA::ObjectPtr<maslo_TestCase>( this )->set_masla_iterations( ::SWA::ObjectPtr<maslo_TestCase>( this )->get_masla_iterations() - 1ll );
            }

            // schedule handle generate TestCase.doDelay () to this delay @PT4S@;
            {
              ::SWA::Stack::ExecutingStatement statement(6);
              ::SWA::EventTimers::getInstance().scheduleTimer( maslv_handle, ::SWA::Duration::fromNanos( 4000000000ll ) + ::SWA::Timestamp::now(), ::SWA::Duration::zero(), ::SWA::ObjectPtr<maslo_TestCase>( this )->create_maslo_TestCase_maslev_doDelay( objectId_maslo_TestCase, getArchitectureId() ) );
            }

            // TRACK~>startStopPressed()
            {
              ::SWA::Stack::ExecutingStatement statement(7);
              maslb_TRACK::masls_startStopPressed();
            }
          }
          else
          {

            // generate TestCase.finish () to this;
            {
              ::SWA::Stack::ExecutingStatement statement(9);
              ::SWA::Process::getInstance().getEventQueue().addEvent( ::SWA::ObjectPtr<maslo_TestCase>( this )->create_maslo_TestCase_maslev_finish( objectId_maslo_TestCase, getArchitectureId() ) );
            }

            // TRACK~>lapResetPressed()
            {
              ::SWA::Stack::ExecutingStatement statement(10);
              maslb_TRACK::masls_lapResetPressed();
            }
          }
        }
      }
    }
  }

}
