//
// File: __UI__TestCasePopulation.cc
//
#include "__UI__TestCasePopulation.hh"

namespace masld_UI
{
  maslo_TestCasePopulation::maslo_TestCasePopulation ( )
  {
  }

  maslo_TestCasePopulation::~maslo_TestCasePopulation ( )
  {
  }

}
