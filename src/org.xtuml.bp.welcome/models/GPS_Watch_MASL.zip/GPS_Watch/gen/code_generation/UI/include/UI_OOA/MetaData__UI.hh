//
// File: MetaData__UI.hh
//
#ifndef UI_OOA_Meta_Data_UI_hh
#define UI_OOA_Meta_Data_UI_hh

namespace masld_UI
{
  enum TypeIds {  typeId_maslt_UIGoalCriteria,
                  typeId_maslt_UIGoalSpan,
                  typeId_maslt_UIIndicator,
                  typeId_maslt_UIUnit };
}
#endif // UI_OOA_Meta_Data_UI_hh
