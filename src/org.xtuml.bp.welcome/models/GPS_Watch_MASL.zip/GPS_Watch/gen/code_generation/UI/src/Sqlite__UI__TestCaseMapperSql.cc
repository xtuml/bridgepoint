//
// File: Sqlite__UI__TestCaseMapperSql.cc
//
#include "Sqlite__UI__TestCase.hh"
#include "Sqlite__UI__TestCaseMapperSql.hh"
#include "__UI__TestCase.hh"
#include "boost/shared_ptr.hpp"
#include "boost/tuple/tuple_comparison.hpp"
#include <map>
#include "sql/Criteria.hh"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/Schema.hh"
#include "sql/Util.hh"
#include "sqlite/Database.hh"
#include "sqlite/Exception.hh"
#include "sqlite/Resultset.hh"
#include "sqlite/SqlMonitor.hh"
#include "sqlite3.h"
#include <stdint.h>
#include <string>
#include "swa/types.hh"

namespace 
{
  const ::std::string createTableStatment ( )
  {
    return "CREATE TABLE S_UI_TESTCASE(   architecture_id  INTEGER ,   masla_iterations INTEGER,   masla_id INTEGER,   CurrentState INTEGER, PRIMARY KEY (architecture_id));\n";
  }

  bool registerSchema = ::SQL::Schema::singleton().registerTable( "S_UI_TESTCASE", createTableStatment() );

}
namespace SQLITE
{
  namespace masld_UI
  {
    maslo_TestCaseSqlGenerator::maslo_TestCaseSqlGenerator ( )
      : tableName("S_UI_TESTCASE"),
        objectName("TestCase"),
        insertStatement("INSERT INTO S_UI_TESTCASE VALUES(:1,:2,:3,:4);"),
        updateStatement("UPDATE S_UI_TESTCASE SET masla_iterations = :2  , masla_id = :3  , CurrentState = :4  WHERE architecture_id = :1;"),
        deleteStatement("DELETE  FROM S_UI_TESTCASE WHERE architecture_id = :1;"),
        columnNameMapper()
    {
    }

    maslo_TestCaseSqlGenerator::~maslo_TestCaseSqlGenerator ( )
    {
    }

    void maslo_TestCaseSqlGenerator::initialise ( )
    {
      columnNameMapper["architecture_id"] = ::std::string( "architecture_id" );
      columnNameMapper["iterations"] = ::std::string( "masla_iterations" );
      columnNameMapper["id"] = ::std::string( "masla_id" );
      columnNameMapper["CurrentState"] = ::std::string( "CurrentState" );
      insertStatement.prepare();
      updateStatement.prepare();
      deleteStatement.prepare();
    }

    const ::std::string maslo_TestCaseSqlGenerator::getDomainName ( ) const
    {
      return "UI";
    }

    const ::std::string& maslo_TestCaseSqlGenerator::getTableName ( ) const
    {
      return tableName;
    }

    const ::std::string& maslo_TestCaseSqlGenerator::getObjectName ( ) const
    {
      return objectName;
    }

    const ::std::string maslo_TestCaseSqlGenerator::getColumnName ( const ::std::string& attribute ) const
    {
      ::std::map< ::std::string,::std::string>::const_iterator requiredNameItr = columnNameMapper.find( attribute );
      if ( requiredNameItr == columnNameMapper.end() )
      {
        throw SqliteException( "maslo_TestCaseSqlGenerator::getColumnName - failed to find attribute name " );
      }
      return requiredNameItr->second;
    }

    void maslo_TestCaseSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                int32_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_UI_TESTCASE;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_TestCaseSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_TestCaseSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    void maslo_TestCaseSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                int64_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_UI_TESTCASE;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_TestCaseSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int64_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_TestCaseSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    ::SWA::IdType maslo_TestCaseSqlGenerator::executeGetRowCount ( ) const
    {
      int32_t rowCount = 0;
      ::std::string valueSelect("SELECT count(*) FROM S_UI_TESTCASE;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_TestCaseSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          rowCount = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_TestCaseSqlGenerator::executeGetRowCount - query failed" );
      }
      return rowCount;
    }

    ::SWA::IdType maslo_TestCaseSqlGenerator::executeGetMaxIdentifier ( ) const
    {
      ::SWA::IdType maxIdValue = 0;
      executeGetMaxColumnValue( "architecture_id", maxIdValue );
      return maxIdValue;
    }

    void maslo_TestCaseSqlGenerator::executeUpdate ( const PsObjectPtr& object ) const
    {
      updateStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_iterations(), object.getChecked()->get_masla_id(), object->getCurrentState() ) );
    }

    void maslo_TestCaseSqlGenerator::executeInsert ( const PsObjectPtr& object ) const
    {
      insertStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_iterations(), object.getChecked()->get_masla_id(), object->getCurrentState() ) );
    }

    void maslo_TestCaseSqlGenerator::executeRemove ( const PsObjectPtr& object ) const
    {
      deleteStatement.execute( object.getChecked()->getArchitectureId() );
    }

    void maslo_TestCaseSqlGenerator::executeRemoveId ( const ::SWA::IdType object ) const
    {
      deleteStatement.execute( object );
    }

    void maslo_TestCaseSqlGenerator::executeSelect ( CacheType&             cache,
                                                     const ::SQL::Criteria& criteria,
                                                     PsBaseObjectPtrSwaSet& result ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("TestCase::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "TestCase::executeSelect", compile_result, query );
        database.checkColumnCount( "TestCase::executeSelect", sqlite3_column_count( ppStmt ), 4, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr != cache.end() )
          {
            PsBaseObjectPtr currentObject(objectItr->second.get());
            result += currentObject;
          }
          else
          {
            PsObjectPtr currentObject(new maslo_TestCase(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );
            result += currentObject;

            int32_t iterations = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_iterations( iterations );

            int32_t id = sqlite3_column_int( ppStmt, 2 );
            currentObject->set_masla_id( id );

            int32_t currentState = sqlite3_column_int( ppStmt, 3 );
            currentObject->setCurrentState( static_cast< ::masld_UI::maslo_TestCase::Type>( currentState ) );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

    void maslo_TestCaseSqlGenerator::executeSelect ( CacheType&             cache,
                                                     const ::SQL::Criteria& criteria ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("TestCase::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "TestCase::executeSelect", compile_result, query );
        database.checkColumnCount( "TestCase::executeSelect", sqlite3_column_count( ppStmt ), 4, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr == cache.end() )
          {
            PsObjectPtr currentObject(new maslo_TestCase(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );

            int32_t iterations = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_iterations( iterations );

            int32_t id = sqlite3_column_int( ppStmt, 2 );
            currentObject->set_masla_id( id );

            int32_t currentState = sqlite3_column_int( ppStmt, 3 );
            currentObject->setCurrentState( static_cast< ::masld_UI::maslo_TestCase::Type>( currentState ) );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

  }
}
