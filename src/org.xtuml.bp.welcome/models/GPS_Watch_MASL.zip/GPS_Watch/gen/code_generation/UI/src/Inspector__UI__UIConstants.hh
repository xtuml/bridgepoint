//
// File: Inspector__UI__UIConstants.hh
//
#ifndef Inspector_UI_UI_Constants_hh
#define Inspector_UI_UI_Constants_hh

#include "__UI__UIConstants.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_UI
  {
    namespace maslo_UIConstants
    {
      class maslo_UIConstantsHandler
        : public ObjectHandler< ::masld_UI::maslo_UIConstants>
      {

        // Constructors
        public:
          maslo_UIConstantsHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                            channel,
                                       ::SWA::ObjectPtr< ::masld_UI::maslo_UIConstants> instance,
                                       int                                              relId ) const;


      };
    }
  }
}
#endif // Inspector_UI_UI_Constants_hh
