//
// File: __UI__sendLapResetPressed.cc
//
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_terminators.hh"
#include "__UI_private_services.hh"
#include "swa/Domain.hh"
#include "swa/Stack.hh"

namespace masld_UI
{
  void masls_sendLapResetPressed ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_sendLapResetPressed);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // TRACK~>lapResetPressed()
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          maslb_TRACK::masls_lapResetPressed();
        }
      }
    }
  }

  const bool localServiceRegistration_masls_sendLapResetPressed = interceptor_masls_sendLapResetPressed::instance().registerLocal( &masls_sendLapResetPressed );

}
