//
// File: Inspector__UI__UI.hh
//
#ifndef Inspector_UI_UI_hh
#define Inspector_UI_UI_hh

#include "__UI__UI.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_UI
  {
    namespace maslo_UI
    {
      class maslo_UIHandler
        : public ObjectHandler< ::masld_UI::maslo_UI>
      {

        // Constructors
        public:
          maslo_UIHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_UI::maslo_UI> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                   channel,
                                       ::SWA::ObjectPtr< ::masld_UI::maslo_UI> instance,
                                       int                                     relId ) const;


      };
    }
  }
}
#endif // Inspector_UI_UI_hh
