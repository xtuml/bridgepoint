//
// File: __UI__createGoals_1.cc
//
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_terminators.hh"
#include "UI_OOA/__UI_types.hh"
#include "__UI_private_services.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Stack.hh"

namespace masld_UI
{
  void masls_createGoals_1 ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_createGoals_1);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // TRACK~>newGoalSpec(UI::UIGoalSpan.Distance, UI::UIGoalCriteria.Pace, 150.0, 8.0, 2.0, 1)
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          maslb_TRACK::masls_newGoalSpec( maslt_UIGoalSpan::masle_Distance, maslt_UIGoalCriteria::masle_Pace, 150.0, 8.0, 2.0, 1ll );
        }

        // TRACK~>newGoalSpec(UI::UIGoalSpan.Time, UI::UIGoalCriteria.HeartRate, 10, 80.0, 60.0, 2)
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslb_TRACK::masls_newGoalSpec( maslt_UIGoalSpan::masle_Time, maslt_UIGoalCriteria::masle_HeartRate, 10ll, 80.0, 60.0, 2ll );
        }

        // TRACK~>newGoalSpec(UI::UIGoalSpan.Time, UI::UIGoalCriteria.Pace, 15, 6.0, 5.0, 3)
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          maslb_TRACK::masls_newGoalSpec( maslt_UIGoalSpan::masle_Time, maslt_UIGoalCriteria::masle_Pace, 15ll, 6.0, 5.0, 3ll );
        }

        // TRACK~>newGoalSpec(UI::UIGoalSpan.Time, UI::UIGoalCriteria.Pace, 15, 2.0, 1.0, 4)
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          maslb_TRACK::masls_newGoalSpec( maslt_UIGoalSpan::masle_Time, maslt_UIGoalCriteria::masle_Pace, 15ll, 2.0, 1.0, 4ll );
        }
      }
    }
  }

  const bool localServiceRegistration_masls_createGoals_1 = interceptor_masls_createGoals_1::instance().registerLocal( &masls_createGoals_1 );

}
