//
// File: __UI_private_types.cc
//
