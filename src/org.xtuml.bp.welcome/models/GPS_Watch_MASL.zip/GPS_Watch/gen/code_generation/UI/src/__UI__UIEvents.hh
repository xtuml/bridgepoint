//
// File: __UI__UIEvents.hh
//
#ifndef _UI_UI_Events_hh
#define _UI_UI_Events_hh

#include "swa/Event.hh"

namespace masld_UI
{
  class Event_maslo_UI_maslev_setTargetPressed
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_UI_maslev_setTargetPressed ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_UI_maslev_startStopPressed
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_UI_maslev_startStopPressed ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_UI_maslev_lapResetPressed
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_UI_maslev_lapResetPressed ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_UI_maslev_lightPressed
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_UI_maslev_lightPressed ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_UI_maslev_modePressed
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_UI_maslev_modePressed ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_UI_maslev_running
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_UI_maslev_running ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_UI_maslev_tick
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_UI_maslev_tick ( );
      virtual void invoke ( ) const;


  };
}
#endif // _UI_UI_Events_hh
