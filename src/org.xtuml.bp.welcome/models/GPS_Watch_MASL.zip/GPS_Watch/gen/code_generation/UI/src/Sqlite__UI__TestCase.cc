//
// File: Sqlite__UI__TestCase.cc
//
#include "Sqlite__UI__TestCase.hh"
#include "Sqlite__UI__TestCasePopulation.hh"
#include "UI_OOA/__UI.hh"
#include "UI_OOA/__UI_interface.hh"
#include "__UI__TestCase.hh"
#include "__UI__TestCaseEvents.hh"
#include "asn1/BERDecode.hh"
#include "asn1/BERDecoder.hh"
#include "asn1/DEREncode.hh"
#include "asn1/DEREncoder.hh"
#include "asn1/UniversalTag.hh"
#include "boost/shared_ptr.hpp"
#include "sqlite/BlobData.hh"
#include "sqlite/EventParameterCodecs.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_UI
  {
    maslo_TestCase::maslo_TestCase ( ::SWA::IdType                    architectureId,
                                     int32_t                          masla_iterations,
                                     int32_t                          masla_id,
                                     ::masld_UI::maslo_TestCase::Type currentState )
      : architectureId(architectureId),
        masla_iterations(masla_iterations),
        masla_id(masla_id),
        currentState(currentState),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_TestCase::maslo_TestCase ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_iterations(),
        masla_id(),
        currentState(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_TestCase::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_TestCase::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_TestCasePopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_TestCase::PrimaryKeyType maslo_TestCase::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_id );
    }

    const maslo_TestCase::IndexKeyType_1 maslo_TestCase::get_index_1 ( )
    {
      return IndexKeyType_1( masla_id );
    }

    void encode_maslo_TestCase_maslev_doDelay ( ::boost::shared_ptr< ::SWA::Event> event,
                                                BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_TestCase_maslev_doDelay ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_UI::Event_maslo_TestCase_maslev_doDelay() );
    }

    bool registermaslo_TestCase_maslev_doDelay = EventParameterCodecs::getInstance().registerCodec( ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_TestCase, ::masld_UI::maslo_TestCase::eventId_maslo_TestCase_maslev_doDelay, &encode_maslo_TestCase_maslev_doDelay, &decode_maslo_TestCase_maslev_doDelay );

    void encode_maslo_TestCase_maslev_finish ( ::boost::shared_ptr< ::SWA::Event> event,
                                               BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_TestCase_maslev_finish ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_UI::Event_maslo_TestCase_maslev_finish() );
    }

    bool registermaslo_TestCase_maslev_finish = EventParameterCodecs::getInstance().registerCodec( ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_TestCase, ::masld_UI::maslo_TestCase::eventId_maslo_TestCase_maslev_finish, &encode_maslo_TestCase_maslev_finish, &decode_maslo_TestCase_maslev_finish );

    void encode_maslo_TestCase_maslev_initializationComplete ( ::boost::shared_ptr< ::SWA::Event> event,
                                                               BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_TestCase_maslev_initializationComplete ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_UI::Event_maslo_TestCase_maslev_initializationComplete() );
    }

    bool registermaslo_TestCase_maslev_initializationComplete = EventParameterCodecs::getInstance().registerCodec( ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_TestCase, ::masld_UI::maslo_TestCase::eventId_maslo_TestCase_maslev_initializationComplete, &encode_maslo_TestCase_maslev_initializationComplete, &decode_maslo_TestCase_maslev_initializationComplete );

    void encode_maslo_TestCase_maslev_initialize ( ::boost::shared_ptr< ::SWA::Event> event,
                                                   BlobData&                          blob )
    {
      ::boost::shared_ptr< ::masld_UI::Event_maslo_TestCase_maslev_initialize> thisEvent = ::boost::dynamic_pointer_cast< ::masld_UI::Event_maslo_TestCase_maslev_initialize>( event );
      ::ASN1::DER::Encoder encoder(::ASN1::SEQUENCE);
      encoder.addChild( ::ASN1::DER::encode( thisEvent->getmaslp_iterations() ) );
      blob.assign( encoder.begin(), encoder.end() );
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_TestCase_maslev_initialize ( BlobData& blob )
    {
      int32_t maslp_iterations;
      ::ASN1::BER::Decoder<BlobData::const_iterator> decoder(blob.begin());
      decoder.checkHeader( ::ASN1::SEQUENCE, true );
      ::ASN1::BER::Decoder<BlobData::const_iterator>::ChildIterator childIt = decoder.getChildrenBegin();
      decoder.checkChildPresent( childIt );
      ::ASN1::BER::decode( *childIt++, maslp_iterations );
      decoder.checkNoMoreChildren( childIt );
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_UI::Event_maslo_TestCase_maslev_initialize(  maslp_iterations ) );
    }

    bool registermaslo_TestCase_maslev_initialize = EventParameterCodecs::getInstance().registerCodec( ::masld_UI::getDomain().getId(), ::masld_UI::objectId_maslo_TestCase, ::masld_UI::maslo_TestCase::eventId_maslo_TestCase_maslev_initialize, &encode_maslo_TestCase_maslev_initialize, &decode_maslo_TestCase_maslev_initialize );

  }
}
