//
// File: __UI__UIPopulation.cc
//
#include "__UI__UIPopulation.hh"

namespace masld_UI
{
  maslo_UIPopulation::maslo_UIPopulation ( )
  {
  }

  maslo_UIPopulation::~maslo_UIPopulation ( )
  {
  }

}
