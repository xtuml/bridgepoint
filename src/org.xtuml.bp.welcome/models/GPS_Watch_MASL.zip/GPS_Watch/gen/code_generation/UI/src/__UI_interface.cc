//
// File: __UI_interface.cc
//
#include "UI_OOA/__UI_interface.hh"
#include "swa/Domain.hh"
#include "swa/Process.hh"

namespace masld_UI
{
  ::SWA::Domain& getDomain ( )
  {
    static ::SWA::Domain& domain = ::SWA::Process::getInstance().registerDomain( "UI" );
    return domain;
  }

  bool initialiseInterface ( )
  {
    getDomain();
  }

  const bool interfaceInitialised = initialiseInterface();

}
