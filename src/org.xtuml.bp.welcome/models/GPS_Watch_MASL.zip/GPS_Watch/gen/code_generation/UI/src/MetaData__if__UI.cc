//
// File: MetaData__if__UI.cc
//
#include "UI_OOA/MetaData__UI.hh"
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_types.hh"
#include "metadata/MetaData.hh"
#include "swa/Domain.hh"

namespace 
{
  namespace init_interface_masld_UI
  {
    ::SWA::EnumerateMetaData get_maslt_UIGoalCriteria_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_UIGoalSpan_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_UIIndicator_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_UIUnit_MetaData ( );
    ::SWA::DomainMetaData initDomainMetaData ( )
    {
      ::SWA::DomainMetaData domain(::masld_UI::getDomain().getId(), "UI", true);
      domain.addEnumerate( get_maslt_UIGoalCriteria_MetaData() );
      domain.addEnumerate( get_maslt_UIGoalSpan_MetaData() );
      domain.addEnumerate( get_maslt_UIIndicator_MetaData() );
      domain.addEnumerate( get_maslt_UIUnit_MetaData() );
      return domain;
    }

    ::SWA::DomainMetaData& getDomainMetaData ( )
    {
      static ::SWA::DomainMetaData domain = initDomainMetaData();
      return domain;
    }

    bool registered = ::SWA::ProcessMetaData::getProcess().addDomain( ::masld_UI::getDomain().getId(), &getDomainMetaData );

    ::SWA::EnumerateMetaData get_maslt_UIGoalCriteria_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_UI::typeId_maslt_UIGoalCriteria, "UIGoalCriteria");
      enumeration.addValue( ::masld_UI::maslt_UIGoalCriteria::masle_HeartRate.getValue(), "HeartRate" );
      enumeration.addValue( ::masld_UI::maslt_UIGoalCriteria::masle_Pace.getValue(), "Pace" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_UIGoalSpan_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_UI::typeId_maslt_UIGoalSpan, "UIGoalSpan");
      enumeration.addValue( ::masld_UI::maslt_UIGoalSpan::masle_Distance.getValue(), "Distance" );
      enumeration.addValue( ::masld_UI::maslt_UIGoalSpan::masle_Time.getValue(), "Time" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_UIIndicator_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_UI::typeId_maslt_UIIndicator, "UIIndicator");
      enumeration.addValue( ::masld_UI::maslt_UIIndicator::masle_Blank.getValue(), "Blank" );
      enumeration.addValue( ::masld_UI::maslt_UIIndicator::masle_Down.getValue(), "Down" );
      enumeration.addValue( ::masld_UI::maslt_UIIndicator::masle_Flat.getValue(), "Flat" );
      enumeration.addValue( ::masld_UI::maslt_UIIndicator::masle_Up.getValue(), "Up" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_UIUnit_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_UI::typeId_maslt_UIUnit, "UIUnit");
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_km.getValue(), "km" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_meters.getValue(), "meters" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_minPerKm.getValue(), "minPerKm" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_kmPerHour.getValue(), "kmPerHour" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_miles.getValue(), "miles" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_yards.getValue(), "yards" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_feet.getValue(), "feet" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_minPerMile.getValue(), "minPerMile" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_mph.getValue(), "mph" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_bpm.getValue(), "bpm" );
      enumeration.addValue( ::masld_UI::maslt_UIUnit::masle_laps.getValue(), "laps" );
      return enumeration;
    }

  }
}
