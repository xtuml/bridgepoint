//
// File: Sqlite__UI__UIMapper.hh
//
#ifndef Sqlite_UI_UI_Mapper_hh
#define Sqlite_UI_UI_Mapper_hh

#include "Sqlite__UI__UI.hh"
#include "__UI__UI.hh"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"

namespace SQLITE
{
  namespace masld_UI
  {
    class maslo_UIMapper
      : public ::SQL::ObjectMapper< ::masld_UI::maslo_UI,maslo_UI>
    {

      // Instance creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_UI::maslo_UI> createInstance ( int32_t                                masla_id,
                                                                         int32_t                                masla_socket_id,
                                                                         const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                         ::masld_UI::maslo_UI::Type             currentState );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_UI::maslo_UI> instance );
      protected:
        virtual bool doPostInit ( );


      // Constructors and Destructors
      public:
        maslo_UIMapper ( );
        virtual ~maslo_UIMapper ( );


      // Attributes
      private:
        ::boost::unordered_set<maslo_UI::PrimaryKeyType> primarykey_cache;


    };
  }
}
#endif // Sqlite_UI_UI_Mapper_hh
