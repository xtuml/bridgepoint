//
// File: __Location_types.hh
//
#ifndef Location_OOA_Location_types_hh
#define Location_OOA_Location_types_hh

#endif // Location_OOA_Location_types_hh
