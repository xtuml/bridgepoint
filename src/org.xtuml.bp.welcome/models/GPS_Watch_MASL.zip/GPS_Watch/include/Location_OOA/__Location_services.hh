//
// File: __Location_services.hh
//
#ifndef Location_OOA_Location_services_hh
#define Location_OOA_Location_services_hh

#include "swa/ServiceInterceptor.hh"

namespace masld_Location
{
  void masls_getLocation ( double& maslp_latitude,
                           double& maslp_longitude );
  class masls_getLocation_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_getLocation_tag,void (double&,double&)> interceptor_masls_getLocation;
  void masls_getDistance ( double& maslp_result,
                           double  maslp_fromLat,
                           double  maslp_fromLong,
                           double  maslp_toLat,
                           double  maslp_toLong );
  class masls_getDistance_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_getDistance_tag,void (double&,double,double,double,double)> interceptor_masls_getDistance;
  void masls_registerListener ( );
  class masls_registerListener_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_registerListener_tag,void()> interceptor_masls_registerListener;
  void masls_unregisterListener ( );
  class masls_unregisterListener_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_unregisterListener_tag,void()> interceptor_masls_unregisterListener;
}
#endif // Location_OOA_Location_services_hh
