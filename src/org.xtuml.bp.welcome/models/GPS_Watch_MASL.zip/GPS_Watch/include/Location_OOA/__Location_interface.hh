//
// File: __Location_interface.hh
//
#ifndef Location_OOA_Location_interface_hh
#define Location_OOA_Location_interface_hh

#include "swa/Domain.hh"

namespace masld_Location
{
  ::SWA::Domain& getDomain ( );
  enum ServiceIds {  serviceId_masls_getLocation,
                     serviceId_masls_getDistance,
                     serviceId_masls_registerListener,
                     serviceId_masls_unregisterListener,
                     serviceId_masls_sqrt };
  enum TerminatorIds {};
}
#endif // Location_OOA_Location_interface_hh
