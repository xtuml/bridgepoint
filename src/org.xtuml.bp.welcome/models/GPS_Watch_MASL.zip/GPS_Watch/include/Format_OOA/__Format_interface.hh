//
// File: __Format_interface.hh
//
#ifndef Format_OOA_Format_interface_hh
#define Format_OOA_Format_interface_hh

#include "swa/Domain.hh"

namespace masld_Format
{
  ::SWA::Domain& getDomain ( );
  enum ServiceIds {  serviceId_masls_to_ascii,
                     serviceId_masls_overload1_to_ascii,
                     serviceId_masls_from_ascii,
                     serviceId_masls_overload1_from_ascii,
                     serviceId_masls_format_integer,
                     serviceId_masls_overload1_format_integer,
                     serviceId_masls_format_based_integer,
                     serviceId_masls_overload1_format_based_integer,
                     serviceId_masls_format_number,
                     serviceId_masls_overload1_format_number,
                     serviceId_masls_format_decimal,
                     serviceId_masls_overload1_format_decimal,
                     serviceId_masls_format_scientific,
                     serviceId_masls_overload1_format_scientific,
                     serviceId_masls_format_fixed,
                     serviceId_masls_overload1_format_fixed,
                     serviceId_masls_format_boolean,
                     serviceId_masls_overload1_format_boolean,
                     serviceId_masls_format_string,
                     serviceId_masls_format_duration_iso,
                     serviceId_masls_format_duration_hms,
                     serviceId_masls_format_duration,
                     serviceId_masls_format_timestamp_iso_ymdhms,
                     serviceId_masls_format_timestamp_iso_ydhms,
                     serviceId_masls_format_timestamp_iso_ywdhms,
                     serviceId_masls_format_timestamp_compact_iso_ymdhms,
                     serviceId_masls_format_timestamp_compact_iso_ydhms,
                     serviceId_masls_format_timestamp_compact_iso_ywdhms,
                     serviceId_masls_format_timestamp_dmy,
                     serviceId_masls_format_timestamp_mdy,
                     serviceId_masls_format_timestamp_dtg,
                     serviceId_masls_format_timestamp_time,
                     serviceId_masls_format_timestamp_compact_time };
  enum TerminatorIds {};
}
#endif // Format_OOA_Format_interface_hh
