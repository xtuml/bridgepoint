//
// File: __Format_terminators.hh
//
#ifndef Format_OOA_Format_terminators_hh
#define Format_OOA_Format_terminators_hh

#endif // Format_OOA_Format_terminators_hh
