//
// File: __Format_services.hh
//
#ifndef Format_OOA_Format_services_hh
#define Format_OOA_Format_services_hh

#include <stdint.h>
#include "swa/Duration.hh"
#include "swa/Sequence.hh"
#include "swa/String.hh"
#include "swa/Timestamp.hh"

namespace masld_Format
{
  class maslt_justify;
  class maslt_base_case;
  class maslt_duration_field;
  class maslt_rounding;
  class maslt_timestamp_field;
  uint8_t masls_to_ascii ( char maslp_input );
  ::SWA::Sequence<uint8_t> masls_overload1_to_ascii ( const ::SWA::String& maslp_input );
  char masls_from_ascii ( uint8_t maslp_input );
  ::SWA::String masls_overload1_from_ascii ( const ::SWA::Sequence<uint8_t>& maslp_input );
  ::SWA::String masls_format_integer ( int64_t maslp_input,
                                       bool    maslp_show_positive );
  ::SWA::String masls_overload1_format_integer ( int64_t              maslp_input,
                                                 bool                 maslp_show_positive,
                                                 const maslt_justify& maslp_justification,
                                                 int32_t              maslp_width,
                                                 char                 maslp_pad );
  ::SWA::String masls_format_based_integer ( int64_t                maslp_input,
                                             bool                   maslp_show_positive,
                                             int32_t                maslp_base,
                                             const maslt_base_case& maslp_base_case );
  ::SWA::String masls_overload1_format_based_integer ( int64_t                maslp_input,
                                                       bool                   maslp_show_positive,
                                                       int32_t                maslp_base,
                                                       const maslt_base_case& maslp_base_case,
                                                       const maslt_justify&   maslp_justification,
                                                       int32_t                maslp_width,
                                                       char                   maslp_pad );
  ::SWA::String masls_format_number ( double  maslp_input,
                                      bool    maslp_show_positive,
                                      int32_t maslp_sigfigs );
  ::SWA::String masls_overload1_format_number ( double               maslp_input,
                                                bool                 maslp_show_positive,
                                                int32_t              maslp_sigfigs,
                                                const maslt_justify& maslp_justification,
                                                int32_t              maslp_width,
                                                char                 maslp_pad );
  ::SWA::String masls_format_decimal ( double  maslp_input,
                                       bool    maslp_show_positive,
                                       int32_t maslp_sigfigs );
  ::SWA::String masls_overload1_format_decimal ( double               maslp_input,
                                                 bool                 maslp_show_positive,
                                                 int32_t              maslp_sigfigs,
                                                 const maslt_justify& maslp_justification,
                                                 int32_t              maslp_width,
                                                 char                 maslp_pad );
  ::SWA::String masls_format_scientific ( double  maslp_input,
                                          bool    maslp_show_positive,
                                          int32_t maslp_sigfigs );
  ::SWA::String masls_overload1_format_scientific ( double               maslp_input,
                                                    bool                 maslp_show_positive,
                                                    int32_t              maslp_sigfigs,
                                                    const maslt_justify& maslp_justification,
                                                    int32_t              maslp_width,
                                                    char                 maslp_pad );
  ::SWA::String masls_format_fixed ( double  maslp_input,
                                     bool    maslp_show_positive,
                                     int32_t maslp_places );
  ::SWA::String masls_overload1_format_fixed ( double               maslp_input,
                                               bool                 maslp_show_positive,
                                               int32_t              maslp_places,
                                               const maslt_justify& maslp_justification,
                                               int32_t              maslp_width,
                                               char                 maslp_pad );
  ::SWA::String masls_format_boolean ( bool maslp_input );
  ::SWA::String masls_overload1_format_boolean ( bool                 maslp_input,
                                                 const ::SWA::String& maslp_true_text,
                                                 const ::SWA::String& maslp_false_text );
  ::SWA::String masls_format_string ( const ::SWA::String& maslp_input,
                                      const maslt_justify& maslp_justification,
                                      int32_t              maslp_width,
                                      char                 maslp_pad );
  ::SWA::String masls_format_duration_iso ( const ::SWA::Duration&      maslp_input,
                                            const maslt_duration_field& maslp_max_field,
                                            const maslt_duration_field& maslp_min_field,
                                            bool                        maslp_hide_zero,
                                            int32_t                     maslp_places,
                                            bool                        maslp_truncate );
  ::SWA::String masls_format_duration_hms ( const ::SWA::Duration&      maslp_input,
                                            const maslt_duration_field& maslp_min_field,
                                            int32_t                     maslp_places,
                                            bool                        maslp_truncate );
  ::SWA::String masls_format_duration ( const ::SWA::Duration&                 maslp_input,
                                        const maslt_duration_field&            maslp_max_field,
                                        const maslt_duration_field&            maslp_min_field,
                                        const maslt_rounding&                  maslp_rounding_mode,
                                        bool                                   maslp_hide_zero,
                                        int32_t                                maslp_places,
                                        bool                                   maslp_truncate,
                                        int32_t                                maslp_field_width,
                                        const ::SWA::String&                   maslp_prefix,
                                        const ::SWA::String&                   maslp_time_prefix,
                                        const ::SWA::Sequence< ::SWA::String>& maslp_suffixes );
  ::SWA::String masls_format_timestamp_iso_ymdhms ( const ::SWA::Timestamp&      maslp_input,
                                                    const maslt_timestamp_field& maslp_min_field,
                                                    int32_t                      maslp_places,
                                                    bool                         maslp_truncate );
  ::SWA::String masls_format_timestamp_iso_ydhms ( const ::SWA::Timestamp&      maslp_input,
                                                   const maslt_timestamp_field& maslp_min_field,
                                                   int32_t                      maslp_places,
                                                   bool                         maslp_truncate );
  ::SWA::String masls_format_timestamp_iso_ywdhms ( const ::SWA::Timestamp&      maslp_input,
                                                    const maslt_timestamp_field& maslp_min_field,
                                                    int32_t                      maslp_places,
                                                    bool                         maslp_truncate );
  ::SWA::String masls_format_timestamp_compact_iso_ymdhms ( const ::SWA::Timestamp&      maslp_input,
                                                            const maslt_timestamp_field& maslp_min_field,
                                                            int32_t                      maslp_places,
                                                            bool                         maslp_truncate );
  ::SWA::String masls_format_timestamp_compact_iso_ydhms ( const ::SWA::Timestamp&      maslp_input,
                                                           const maslt_timestamp_field& maslp_min_field,
                                                           int32_t                      maslp_places,
                                                           bool                         maslp_truncate );
  ::SWA::String masls_format_timestamp_compact_iso_ywdhms ( const ::SWA::Timestamp&      maslp_input,
                                                            const maslt_timestamp_field& maslp_min_field,
                                                            int32_t                      maslp_places,
                                                            bool                         maslp_truncate );
  ::SWA::String masls_format_timestamp_dmy ( const ::SWA::Timestamp& maslp_input );
  ::SWA::String masls_format_timestamp_mdy ( const ::SWA::Timestamp& maslp_input );
  ::SWA::String masls_format_timestamp_dtg ( const ::SWA::Timestamp& maslp_input );
  ::SWA::String masls_format_timestamp_time ( const ::SWA::Timestamp&      maslp_input,
                                              const maslt_timestamp_field& maslp_min_field,
                                              int32_t                      maslp_places,
                                              bool                         maslp_truncate );
  ::SWA::String masls_format_timestamp_compact_time ( const ::SWA::Timestamp&      maslp_input,
                                                      const maslt_timestamp_field& maslp_min_field,
                                                      int32_t                      maslp_places,
                                                      bool                         maslp_truncate );
}
#endif // Format_OOA_Format_services_hh
