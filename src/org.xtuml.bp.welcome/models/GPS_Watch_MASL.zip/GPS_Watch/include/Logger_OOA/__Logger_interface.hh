//
// File: __Logger_interface.hh
//
#ifndef Logger_OOA_Logger_interface_hh
#define Logger_OOA_Logger_interface_hh

#include "swa/Domain.hh"

namespace masld_Logger
{
  ::SWA::Domain& getDomain ( );
  enum ServiceIds {  serviceId_masls_log,
                     serviceId_masls_overload1_log,
                     serviceId_masls_trace,
                     serviceId_masls_overload1_trace,
                     serviceId_masls_debug,
                     serviceId_masls_overload1_debug,
                     serviceId_masls_information,
                     serviceId_masls_overload1_information,
                     serviceId_masls_notice,
                     serviceId_masls_overload1_notice,
                     serviceId_masls_warning,
                     serviceId_masls_overload1_warning,
                     serviceId_masls_error,
                     serviceId_masls_overload1_error,
                     serviceId_masls_critical,
                     serviceId_masls_overload1_critical,
                     serviceId_masls_fatal,
                     serviceId_masls_overload1_fatal,
                     serviceId_masls_setLogLevel,
                     serviceId_masls_overload1_setLogLevel,
                     serviceId_masls_printLoggers };
  enum TerminatorIds {};
}
#endif // Logger_OOA_Logger_interface_hh
