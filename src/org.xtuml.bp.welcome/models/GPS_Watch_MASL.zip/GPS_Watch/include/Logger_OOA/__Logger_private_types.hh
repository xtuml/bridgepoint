//
// File: __Logger_private_types.hh
//
#ifndef Logger_OOA_Logger_private_types_hh
#define Logger_OOA_Logger_private_types_hh

#endif // Logger_OOA_Logger_private_types_hh
