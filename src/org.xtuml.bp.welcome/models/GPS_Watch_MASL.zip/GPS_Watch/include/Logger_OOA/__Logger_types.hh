//
// File: __Logger_types.hh
//
#ifndef Logger_OOA_Logger_types_hh
#define Logger_OOA_Logger_types_hh

#include "asn1/BERDecode.hh"
#include "asn1/BERDecoder.hh"
#include "asn1/DEREncode.hh"
#include "asn1/DEREncoder.hh"
#include "boost/operators.hpp"
#include <cstddef>
#include <iostream>
#include <map>
#include <stdint.h>
#include <string>
#include "swa/RangeIterator.hh"

namespace masld_Logger
{
  class maslt_Priority;
  class maslt_Priority
    : private ::boost::less_than_comparable<maslt_Priority,::boost::equality_comparable<maslt_Priority,::boost::incrementable<maslt_Priority,::boost::decrementable<maslt_Priority> > > >
  {

    // Enumerates
    public:
      static const maslt_Priority masle_Fatal;
      static const maslt_Priority masle_Critical;
      static const maslt_Priority masle_Error;
      static const maslt_Priority masle_Warning;
      static const maslt_Priority masle_Notice;
      static const maslt_Priority masle_Information;
      static const maslt_Priority masle_Debug;
      static const maslt_Priority masle_Trace;


    // Enumeration
    public:
      maslt_Priority ( );
      static maslt_Priority getFirst ( ) { return masle_Fatal; }
      static maslt_Priority getLast ( ) { return masle_Trace; }


    // Index Conversions
    public:
      enum Index {  index_masle_Fatal,
                    index_masle_Critical,
                    index_masle_Error,
                    index_masle_Warning,
                    index_masle_Notice,
                    index_masle_Information,
                    index_masle_Debug,
                    index_masle_Trace };
    private:
      Index index;
    public:
      explicit maslt_Priority ( Index index );
      Index getIndex ( ) const { return index; }
      Index& setIndex ( ) { return index; }
      typedef ::SWA::RangeIterator<maslt_Priority> const_iterator;
      static const_iterator beginEnum ( ) { return const_iterator( masle_Fatal, masle_Trace ); }
      static const_iterator endEnum ( ) { return const_iterator( masle_Trace ); }


    // Value Conversions
    public:
      enum Value {  value_masle_Fatal,
                    value_masle_Critical,
                    value_masle_Error,
                    value_masle_Warning,
                    value_masle_Notice,
                    value_masle_Information,
                    value_masle_Debug,
                    value_masle_Trace };
      explicit maslt_Priority ( Value value );
      Value getValue ( ) const { return valueLookup[index]; }
    private:
      static Value valueLookup[];
      static Index fromValue ( Value value );
    public:
      explicit maslt_Priority ( int32_t value );
      operator int32_t ( ) const { return static_cast<int32_t>( getValue() ); }


    // Text Conversions
    public:
      explicit maslt_Priority ( const ::std::string& text );
      const char* const getText ( ) const { return textLookup[index]; }
    private:
      static const char* const textLookup[];
      typedef ::std::map< ::std::string,Index> TextLookupTable;
      static TextLookupTable getLookupTable ( );
      static Index fromText ( const ::std::string& text );


    // Operators
    public:
      bool operator< ( const maslt_Priority& rhs ) const { return index < rhs.index; }
      bool operator== ( const maslt_Priority& rhs ) const { return index == rhs.index; }
      maslt_Priority& operator++ ( );
      maslt_Priority& operator-- ( );
      int64_t operator- ( const maslt_Priority& rhs ) const { return index - rhs.index; }


  };
  ::std::ostream& operator<< ( ::std::ostream&       stream,
                               const maslt_Priority& obj );
  ::std::istream& operator>> ( ::std::istream& stream,
                               maslt_Priority& obj );
  inline ::std::size_t hash_value ( const maslt_Priority& value ) { return value.getIndex(); }
}
namespace ASN1
{
  namespace DER
  {
    inline Encoder encodeValue ( const ::masld_Logger::maslt_Priority& value )
    {
      return encode( value.getIndex() );
    }

  }
  namespace BER
  {
    template<class I>
    void decodeValue ( const Decoder<I>&               decoder,
                       ::masld_Logger::maslt_Priority& value )
    {
      decode( decoder, value.setIndex() );
    }

  }
}
#endif // Logger_OOA_Logger_types_hh
