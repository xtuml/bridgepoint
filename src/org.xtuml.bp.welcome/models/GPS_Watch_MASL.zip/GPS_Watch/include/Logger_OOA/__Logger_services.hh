//
// File: __Logger_services.hh
//
#ifndef Logger_OOA_Logger_services_hh
#define Logger_OOA_Logger_services_hh

#include "swa/ServiceInterceptor.hh"
#include "swa/String.hh"

namespace masld_Logger
{
  class maslt_Priority;
  void masls_log ( const maslt_Priority& maslp_priority,
                   const ::SWA::String&  maslp_message );
  class masls_log_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_log_tag,void (const maslt_Priority&,const ::SWA::String&)> interceptor_masls_log;
  void masls_overload1_log ( const maslt_Priority& maslp_priority,
                             const ::SWA::String&  maslp_logger,
                             const ::SWA::String&  maslp_message );
  class masls_overload1_log_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_overload1_log_tag,void (const maslt_Priority&,const ::SWA::String&,const ::SWA::String&)> interceptor_masls_overload1_log;
  void masls_trace ( const ::SWA::String& maslp_message );
  class masls_trace_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_trace_tag,void (const ::SWA::String&)> interceptor_masls_trace;
  void masls_overload1_trace ( const ::SWA::String& maslp_logger,
                               const ::SWA::String& maslp_message );
  class masls_overload1_trace_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_overload1_trace_tag,void (const ::SWA::String&,const ::SWA::String&)> interceptor_masls_overload1_trace;
  void masls_debug ( const ::SWA::String& maslp_message );
  class masls_debug_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_debug_tag,void (const ::SWA::String&)> interceptor_masls_debug;
  void masls_overload1_debug ( const ::SWA::String& maslp_logger,
                               const ::SWA::String& maslp_message );
  class masls_overload1_debug_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_overload1_debug_tag,void (const ::SWA::String&,const ::SWA::String&)> interceptor_masls_overload1_debug;
  void masls_information ( const ::SWA::String& maslp_message );
  class masls_information_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_information_tag,void (const ::SWA::String&)> interceptor_masls_information;
  void masls_overload1_information ( const ::SWA::String& maslp_logger,
                                     const ::SWA::String& maslp_message );
  class masls_overload1_information_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_overload1_information_tag,void (const ::SWA::String&,const ::SWA::String&)> interceptor_masls_overload1_information;
  void masls_notice ( const ::SWA::String& maslp_message );
  class masls_notice_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_notice_tag,void (const ::SWA::String&)> interceptor_masls_notice;
  void masls_overload1_notice ( const ::SWA::String& maslp_logger,
                                const ::SWA::String& maslp_message );
  class masls_overload1_notice_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_overload1_notice_tag,void (const ::SWA::String&,const ::SWA::String&)> interceptor_masls_overload1_notice;
  void masls_warning ( const ::SWA::String& maslp_message );
  class masls_warning_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_warning_tag,void (const ::SWA::String&)> interceptor_masls_warning;
  void masls_overload1_warning ( const ::SWA::String& maslp_logger,
                                 const ::SWA::String& maslp_message );
  class masls_overload1_warning_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_overload1_warning_tag,void (const ::SWA::String&,const ::SWA::String&)> interceptor_masls_overload1_warning;
  void masls_error ( const ::SWA::String& maslp_message );
  class masls_error_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_error_tag,void (const ::SWA::String&)> interceptor_masls_error;
  void masls_overload1_error ( const ::SWA::String& maslp_logger,
                               const ::SWA::String& maslp_message );
  class masls_overload1_error_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_overload1_error_tag,void (const ::SWA::String&,const ::SWA::String&)> interceptor_masls_overload1_error;
  void masls_critical ( const ::SWA::String& maslp_message );
  class masls_critical_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_critical_tag,void (const ::SWA::String&)> interceptor_masls_critical;
  void masls_overload1_critical ( const ::SWA::String& maslp_logger,
                                  const ::SWA::String& maslp_message );
  class masls_overload1_critical_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_overload1_critical_tag,void (const ::SWA::String&,const ::SWA::String&)> interceptor_masls_overload1_critical;
  void masls_fatal ( const ::SWA::String& maslp_message );
  class masls_fatal_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_fatal_tag,void (const ::SWA::String&)> interceptor_masls_fatal;
  void masls_overload1_fatal ( const ::SWA::String& maslp_logger,
                               const ::SWA::String& maslp_message );
  class masls_overload1_fatal_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_overload1_fatal_tag,void (const ::SWA::String&,const ::SWA::String&)> interceptor_masls_overload1_fatal;
  void masls_setLogLevel ( const maslt_Priority& maslp_priority );
  class masls_setLogLevel_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_setLogLevel_tag,void (const maslt_Priority&)> interceptor_masls_setLogLevel;
  void masls_overload1_setLogLevel ( const ::SWA::String&  maslp_logger,
                                     const maslt_Priority& maslp_priority );
  class masls_overload1_setLogLevel_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_overload1_setLogLevel_tag,void (const ::SWA::String&,const maslt_Priority&)> interceptor_masls_overload1_setLogLevel;
  void masls_printLoggers ( );
  class masls_printLoggers_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_printLoggers_tag,void()> interceptor_masls_printLoggers;
}
#endif // Logger_OOA_Logger_services_hh
