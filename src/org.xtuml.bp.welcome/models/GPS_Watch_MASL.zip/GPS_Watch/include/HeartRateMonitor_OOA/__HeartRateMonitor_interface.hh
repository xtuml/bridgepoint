//
// File: __HeartRateMonitor_interface.hh
//
#ifndef Heart_Rate_Monitor_OOA_Heart_Rate_Monitor_interface_hh
#define Heart_Rate_Monitor_OOA_Heart_Rate_Monitor_interface_hh

#include "swa/Domain.hh"

namespace masld_HeartRateMonitor
{
  ::SWA::Domain& getDomain ( );
  enum ServiceIds {  serviceId_masls_registerListener,
                     serviceId_masls_unregisterListener };
  enum TerminatorIds {  terminatorId_maslb_HRChange };
}
#endif // Heart_Rate_Monitor_OOA_Heart_Rate_Monitor_interface_hh
