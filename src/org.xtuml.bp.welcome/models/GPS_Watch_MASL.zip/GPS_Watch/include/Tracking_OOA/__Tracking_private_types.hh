//
// File: __Tracking_private_types.hh
//
#ifndef Tracking_OOA_Tracking_private_types_hh
#define Tracking_OOA_Tracking_private_types_hh

#endif // Tracking_OOA_Tracking_private_types_hh
