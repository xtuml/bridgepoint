//
// File: __Tracking.hh
//
#ifndef Tracking_OOA_Tracking_hh
#define Tracking_OOA_Tracking_hh

namespace masld_Tracking
{
  enum ObjectIds {  objectId_maslo_WorkoutSession,
                    objectId_maslo_WorkoutTimer,
                    objectId_maslo_TrackPoint,
                    objectId_maslo_TrackLog,
                    objectId_maslo_LapMarker,
                    objectId_maslo_HeartRateSample,
                    objectId_maslo_GoalSpec,
                    objectId_maslo_Goal,
                    objectId_maslo_Display,
                    objectId_maslo_Achievement,
                    objectId_maslo_GoalAchievement,
                    objectId_maslo_GoalSpecConstants,
                    objectId_maslo_HeartRateConstants,
                    objectId_maslo_Speed,
                    objectId_maslo_WorkoutTimerConstants };
  enum RelationshipIds {  relationshipId_R1,
                          relationshipId_R2,
                          relationshipId_R3,
                          relationshipId_R5,
                          relationshipId_R7,
                          relationshipId_R8,
                          relationshipId_R4,
                          relationshipId_R6,
                          relationshipId_R9,
                          relationshipId_R10,
                          relationshipId_R11,
                          relationshipId_R12,
                          relationshipId_R13,
                          relationshipId_R14 };
}
#endif // Tracking_OOA_Tracking_hh
