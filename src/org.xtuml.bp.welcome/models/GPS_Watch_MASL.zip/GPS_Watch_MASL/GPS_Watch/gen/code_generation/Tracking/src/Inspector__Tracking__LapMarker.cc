//
// File: Inspector__Tracking__LapMarker.cc
//
#include "Inspector__Tracking__LapMarker.hh"
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__LapMarker.hh"
#include "__Tracking__TrackLog.hh"
#include "boost/lexical_cast.hpp"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/ObjectHandler.hh"
#include "inspector/ProcessHandler.hh"
#include <stdint.h>
#include <string>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_LapMarker
    {
      maslo_LapMarkerHandler::maslo_LapMarkerHandler ( )
      {
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslo_LapMarker> ( const ::masld_Tracking::maslo_LapMarker& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_lapTime() );
    write( instance.get_masla_session_startTime() );
    write( instance.navigate_R5_marks_end_of_lap_in_TrackLog() );
  }

  namespace masld_Tracking
  {
    namespace maslo_LapMarker
    {
      void maslo_LapMarkerHandler::createInstance ( CommunicationChannel& channel ) const
      {
        int32_t masla_lapTime;
        ::SWA::Timestamp masla_session_startTime;
        channel >> masla_lapTime >> masla_session_startTime;
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> instance = ::masld_Tracking::maslo_LapMarker::createInstance( masla_lapTime, masla_session_startTime );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_LapMarkerHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_lapTime() ) + "," + ::boost::lexical_cast< ::std::string>( instance->get_masla_session_startTime() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> > ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_Tracking::maslo_LapMarker::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_Tracking
  {
    namespace maslo_LapMarker
    {
      void maslo_LapMarkerHandler::writeRelatedInstances ( CommunicationChannel&                                channel,
                                                           ::SWA::ObjectPtr< ::masld_Tracking::maslo_LapMarker> instance,
                                                           int                                                  relId ) const
      {
        switch ( relId )
        {
          case 0:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_TrackLog>( ::masld_Tracking::objectId_maslo_TrackLog ).writeInstances( channel, instance ? instance->navigate_R5_marks_end_of_lap_in_TrackLog()
                                                                                                                                                                                                                                       : ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>() );
            break;

        }

      }

    }
  }
}
