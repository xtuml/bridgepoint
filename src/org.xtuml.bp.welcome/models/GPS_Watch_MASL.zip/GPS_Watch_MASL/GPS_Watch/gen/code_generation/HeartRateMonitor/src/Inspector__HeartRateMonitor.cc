//
// File: Inspector__HeartRateMonitor.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_services.hh"
#include "Inspector__HeartRateMonitor__HRChange.hh"
#include "Inspector__HeartRateMonitor__HeartRateConstants.hh"
#include "Inspector__HeartRateMonitor__HeartRateMonitor.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/GenericObjectHandler.hh"
#include "inspector/ProcessHandler.hh"
#include "inspector/TerminatorHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"

namespace Inspector
{
  namespace masld_HeartRateMonitor
  {
    class masls_registerListenerHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_registerListenerInvoker
    {

      public:
        masls_registerListenerInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_HeartRateMonitor::interceptor_masls_registerListener::instance().callService()(); }


    };
    class masls_unregisterListenerHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_unregisterListenerInvoker
    {

      public:
        masls_unregisterListenerInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_HeartRateMonitor::interceptor_masls_unregisterListener::instance().callService()(); }


    };
    class masld_HeartRateMonitorHandler
      : public DomainHandler
    {

      public:
        masld_HeartRateMonitorHandler ( );
        void createRelationship ( CommunicationChannel& channel,
                                  int                   relId );


    };
    Callable masls_registerListenerHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_registerListenerInvoker( channel );
    }

    void masls_registerListenerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                         const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
      for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
      {
        channel << frame.getLocalVars()[i].getId();
        switch ( frame.getLocalVars()[i].getId() )
        {
          case 0:

            // Write hr
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> >();
            break;

        }

      }
    }

    Callable masls_unregisterListenerHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_unregisterListenerInvoker( channel );
    }

    void masls_unregisterListenerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                           const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
      for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
      {
        channel << frame.getLocalVars()[i].getId();
        switch ( frame.getLocalVars()[i].getId() )
        {
          case 0:

            // Write hr
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> >();
            break;

        }

      }
    }

    masld_HeartRateMonitorHandler::masld_HeartRateMonitorHandler ( )
    {
      registerObjectHandler( ::masld_HeartRateMonitor::objectId_maslo_HeartRateConstants, ::boost::shared_ptr<GenericObjectHandler>( new maslo_HeartRateConstants::maslo_HeartRateConstantsHandler() ) );
      registerObjectHandler( ::masld_HeartRateMonitor::objectId_maslo_HeartRateMonitor, ::boost::shared_ptr<GenericObjectHandler>( new maslo_HeartRateMonitor::maslo_HeartRateMonitorHandler() ) );
      registerTerminatorHandler( ::masld_HeartRateMonitor::terminatorId_maslb_HRChange, ::boost::shared_ptr<TerminatorHandler>( new maslb_HRChange::maslb_HRChangeHandler() ) );
      registerServiceHandler( ::masld_HeartRateMonitor::serviceId_masls_registerListener, ::boost::shared_ptr<ActionHandler>( new masls_registerListenerHandler() ) );
      registerServiceHandler( ::masld_HeartRateMonitor::serviceId_masls_unregisterListener, ::boost::shared_ptr<ActionHandler>( new masls_unregisterListenerHandler() ) );
    }

    void masld_HeartRateMonitorHandler::createRelationship ( CommunicationChannel& channel,
                                                             int                   relId )
    {
      switch ( relId )
      {
      }

    }

  }
}
namespace 
{
  bool masld_HeartRateMonitor_registered = ::Inspector::ProcessHandler::getInstance().registerDomainHandler( ::SWA::Process::getInstance().getDomain( "HeartRateMonitor" ).getId(), ::boost::shared_ptr< ::Inspector::DomainHandler>( new ::Inspector::masld_HeartRateMonitor::masld_HeartRateMonitorHandler() ) );

}
