//
// File: Sqlite__Tracking__HeartRateConstantsPopulation.cc
//
#include "Sqlite__Tracking__HeartRateConstantsPopulation.hh"
#include "__Tracking__HeartRateConstants.hh"
#include "boost/bind.hpp"
#include "boost/signals2.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_HeartRateConstantsPopulation::maslo_HeartRateConstantsPopulation ( )
    {
    }

    maslo_HeartRateConstantsPopulation::~maslo_HeartRateConstantsPopulation ( )
    {
    }

    void maslo_HeartRateConstantsPopulation::initialise ( )
    {
      mapper->initialise();
    }

    maslo_HeartRateConstantsPopulation& maslo_HeartRateConstantsPopulation::getPopulation ( )
    {
      static maslo_HeartRateConstantsPopulation population;
      return population;
    }

    bool maslo_HeartRateConstantsPopulation::registered = maslo_HeartRateConstantsPopulation::registerSingleton( &maslo_HeartRateConstantsPopulation::getPopulation );

    ::boost::signals2::connection maslo_HeartRateConstantsPopulation::initialised = ::SWA::Process::getInstance().registerInitialisingListener( ::boost::bind( &maslo_HeartRateConstantsPopulation::initialise, ::boost::bind( &maslo_HeartRateConstantsPopulation::getPopulation ) ) );

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> maslo_HeartRateConstantsPopulation::findObject ( const ::SWA::IdType& obj )
    {
      return mapper->find( obj );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> > maslo_HeartRateConstantsPopulation::findObject ( const MapperType::PsObjectIdSet& obj )
    {
      MapperType::PsObjectPtrSet objectSet = mapper->find( obj );
      return ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> >( objectSet.begin(), objectSet.end(), true );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> maslo_HeartRateConstantsPopulation::createInstance ( int32_t masla_id,
                                                                                                                       int32_t masla_HeartRateAveragingWindow,
                                                                                                                       int32_t masla_HeartRateSamplingPeriod )
    {
      return mapper->createInstance( masla_id, masla_HeartRateAveragingWindow, masla_HeartRateSamplingPeriod );
    }

    void maslo_HeartRateConstantsPopulation::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> instance )
    {
      {
      }
      mapper->deleteInstance( instance );
    }

  }
}
