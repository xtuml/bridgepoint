//
// File: Sqlite__HeartRateMonitor__HeartRateConstants.cc
//
#include "Sqlite__HeartRateMonitor__HeartRateConstants.hh"
#include "Sqlite__HeartRateMonitor__HeartRateConstantsPopulation.hh"
#include <stdint.h>
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_HeartRateMonitor
  {
    maslo_HeartRateConstants::maslo_HeartRateConstants ( ::SWA::IdType architectureId,
                                                         int32_t       masla_id,
                                                         int32_t       masla_HeartRateAveragingWindow,
                                                         int32_t       masla_HeartRateSamplingPeriod )
      : architectureId(architectureId),
        masla_id(masla_id),
        masla_HeartRateAveragingWindow(masla_HeartRateAveragingWindow),
        masla_HeartRateSamplingPeriod(masla_HeartRateSamplingPeriod),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_HeartRateConstants::maslo_HeartRateConstants ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_id(),
        masla_HeartRateAveragingWindow(),
        masla_HeartRateSamplingPeriod(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_HeartRateConstants::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_HeartRateConstants::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_HeartRateConstantsPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_HeartRateConstants::PrimaryKeyType maslo_HeartRateConstants::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_id );
    }

    const maslo_HeartRateConstants::IndexKeyType_1 maslo_HeartRateConstants::get_index_1 ( )
    {
      return IndexKeyType_1( masla_id );
    }

  }
}
