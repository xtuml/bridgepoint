//
// File: __HeartRateMonitor__HeartRateMonitor__idle.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "swa/Domain.hh"
#include "swa/Stack.hh"

namespace masld_HeartRateMonitor
{
  void maslo_HeartRateMonitor::state_maslst_idle ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_HeartRateMonitor, stateId_maslst_idle);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {
      }
    }
  }

}
