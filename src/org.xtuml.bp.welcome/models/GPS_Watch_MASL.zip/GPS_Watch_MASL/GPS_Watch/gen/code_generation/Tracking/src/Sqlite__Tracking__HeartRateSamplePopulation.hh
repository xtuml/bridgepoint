//
// File: Sqlite__Tracking__HeartRateSamplePopulation.hh
//
#ifndef Sqlite_Tracking_Heart_Rate_Sample_Population_hh
#define Sqlite_Tracking_Heart_Rate_Sample_Population_hh

#include "Sqlite__Tracking__HeartRateSample.hh"
#include "Sqlite__Tracking__HeartRateSampleMapper.hh"
#include "Sqlite__Tracking__R6Mapper.hh"
#include "__Tracking__HeartRateSample.hh"
#include "__Tracking__HeartRateSamplePopulation.hh"
#include "boost/signals2.hpp"
#include <cstddef>
#include "sql/Population.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_WorkoutSession;
  }
}
namespace masld_Tracking
{
  class maslo_WorkoutSession;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_HeartRateSamplePopulation
      : public ::SQL::SqlPopulation< ::masld_Tracking::maslo_HeartRateSample,maslo_HeartRateSample,maslo_HeartRateSampleMapper,::masld_Tracking::maslo_HeartRateSamplePopulation>
    {

      // Constructors and Destructors
      private:
        maslo_HeartRateSamplePopulation ( );
        ~maslo_HeartRateSamplePopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> createInstance ( int32_t                 masla_heartRate,
                                                                                            int32_t                 masla_time,
                                                                                            const ::SWA::Timestamp& masla_session_startTime );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> instance );


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Relationship Counts
      public:
        ::std::size_t count_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr<maslo_HeartRateSample>& lhs );


      // Relationship Links
      public:
        void link_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr<maslo_HeartRateSample>& lhs,
                                                           const ::SWA::ObjectPtr<maslo_WorkoutSession>&  rhs );
        void unlink_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr<maslo_HeartRateSample>& lhs,
                                                             const ::SWA::ObjectPtr<maslo_WorkoutSession>&  rhs );


      // Relationship Navigations
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> navigate_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr<maslo_HeartRateSample>& lhs );


      // Singleton Registration
      public:
        static maslo_HeartRateSamplePopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;
        RelationshipR6Mapper& R6Mapper;


    };
  }
}
#endif // Sqlite_Tracking_Heart_Rate_Sample_Population_hh
