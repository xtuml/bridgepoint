//
// File: __UI__startTest.cc
//
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_services.hh"
#include "__UI__TestCase.hh"
#include "boost/shared_ptr.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace masld_UI
{
  void masls_startTest ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_startTest);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // tc : instance of TestCase;
        ::SWA::ObjectPtr<maslo_TestCase> maslv_tc;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_tc(0, maslv_tc);

        // tc := create TestCase (
        //               id => 1 ,
        // Current_State => Idle);
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslv_tc = maslo_TestCase::createInstance( int32_t(), 1ll, maslo_TestCase::maslst_Idle );
        }

        // generate TestCase.initialize (2) to tc;
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          ::SWA::Process::getInstance().getEventQueue().addEvent( maslv_tc->create_maslo_TestCase_maslev_initialize( 2ll ) );
        }
      }
    }
  }

  const bool localServiceRegistration_masls_startTest = interceptor_masls_startTest::instance().registerLocal( &masls_startTest );

}
