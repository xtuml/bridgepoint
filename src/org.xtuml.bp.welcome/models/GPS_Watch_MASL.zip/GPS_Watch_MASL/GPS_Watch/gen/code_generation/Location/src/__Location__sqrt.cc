//
// File: __Location__sqrt.cc
//
#include "Location_OOA/__Location_interface.hh"
#include "__Location_private_services.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Stack.hh"

namespace masld_Location
{
  double masls_sqrt ( double maslp_x )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_sqrt);
      ::SWA::Stack::DeclareParameter pm_maslp_x(maslp_x);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(8);
      {

        // result : real;
        double maslv_result = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_result(0, maslv_result);

        // inputValue : real;
        double maslv_inputValue = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_inputValue(1, maslv_inputValue);

        // guess : real;
        double maslv_guess = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_guess(2, maslv_guess);

        // MAX_ITERATIONS : integer;
        int32_t maslv_MAX_ITERATIONS = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_MAX_ITERATIONS(3, maslv_MAX_ITERATIONS);

        // i : integer;
        int32_t maslv_i = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_i(4, maslv_i);

        // prev_value : real;
        double maslv_prev_value = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_prev_value(5, maslv_prev_value);

        // result := 0.0;
        {
          ::SWA::Stack::ExecutingStatement statement(13);
          maslv_result = 0.0;
        }

        // inputValue := x;
        {
          ::SWA::Stack::ExecutingStatement statement(15);
          maslv_inputValue = maslp_x;
        }

        // if (inputValue < 0) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(18);
          if ( maslv_inputValue < 0ll )
          {

            // inputValue := (- x);
            {
              ::SWA::Stack::ExecutingStatement statement(19);
              maslv_inputValue = -maslp_x;
            }
          }
        }

        // if (x > 0) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(22);
          if ( maslp_x > 0ll )
          {

            // guess := x;
            {
              ::SWA::Stack::ExecutingStatement statement(24);
              maslv_guess = maslp_x;
            }

            // MAX_ITERATIONS := 24;
            {
              ::SWA::Stack::ExecutingStatement statement(25);
              maslv_MAX_ITERATIONS = 24ll;
            }

            // i := 0;
            {
              ::SWA::Stack::ExecutingStatement statement(26);
              maslv_i = 0ll;
            }

            // prev_value := (- 1.0);
            {
              ::SWA::Stack::ExecutingStatement statement(27);
              maslv_prev_value = -1.0;
            }

            // while ((i < MAX_ITERATIONS) and (prev_value /= guess)) loop ...
            {
              ::SWA::Stack::ExecutingStatement statement(28);
              while ( maslv_i < maslv_MAX_ITERATIONS && maslv_prev_value != maslv_guess )
              {

                // prev_value := guess;
                {
                  ::SWA::Stack::ExecutingStatement statement(29);
                  maslv_prev_value = maslv_guess;
                }

                // guess := (guess - (((guess * guess) - inputValue) / (2 * guess)));
                {
                  ::SWA::Stack::ExecutingStatement statement(30);
                  maslv_guess = maslv_guess - (maslv_guess * maslv_guess - maslv_inputValue) / (2ll * maslv_guess);
                }

                // i := (i + 1);
                {
                  ::SWA::Stack::ExecutingStatement statement(31);
                  maslv_i = maslv_i + 1ll;
                }
              }
            }

            // result := guess;
            {
              ::SWA::Stack::ExecutingStatement statement(33);
              maslv_result = maslv_guess;
            }
          }
        }

        // return result;
        {
          ::SWA::Stack::ExecutingStatement statement(36);
          return maslv_result;
        }
      }
    }
  }

}
