//
// File: Inspector__Format.cc
//
#include "Format_OOA/__Format_interface.hh"
#include "Format_OOA/__Format_services.hh"
#include "Format_OOA/__Format_types.hh"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/ProcessHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include "swa/Duration.hh"
#include "swa/Process.hh"
#include "swa/Sequence.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"
#include "swa/Timestamp.hh"

namespace Inspector
{
  namespace masld_Format
  {
    class masls_to_asciiHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_to_asciiInvoker
    {

      public:
        masls_to_asciiInvoker ( CommunicationChannel& channel )
          : maslp_input()
 { channel >> maslp_input; }
        void operator() ( ) { ::masld_Format::masls_to_ascii( maslp_input ); }


      private:
        char maslp_input;


    };
    class masls_overload1_to_asciiHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_to_asciiInvoker
    {

      public:
        masls_overload1_to_asciiInvoker ( CommunicationChannel& channel )
          : maslp_input()
 { channel >> maslp_input; }
        void operator() ( ) { ::masld_Format::masls_overload1_to_ascii( maslp_input ); }


      private:
        ::SWA::String maslp_input;


    };
    class masls_from_asciiHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_from_asciiInvoker
    {

      public:
        masls_from_asciiInvoker ( CommunicationChannel& channel )
          : maslp_input()
 { channel >> maslp_input; }
        void operator() ( ) { ::masld_Format::masls_from_ascii( maslp_input ); }


      private:
        uint8_t maslp_input;


    };
    class masls_overload1_from_asciiHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_from_asciiInvoker
    {

      public:
        masls_overload1_from_asciiInvoker ( CommunicationChannel& channel )
          : maslp_input()
 { channel >> maslp_input; }
        void operator() ( ) { ::masld_Format::masls_overload1_from_ascii( maslp_input ); }


      private:
        ::SWA::Sequence<uint8_t> maslp_input;


    };
    class masls_format_integerHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_integerInvoker
    {

      public:
        masls_format_integerInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_show_positive()

        {
          channel >> maslp_input;
          channel >> maslp_show_positive;
        }
        void operator() ( ) { ::masld_Format::masls_format_integer( maslp_input, maslp_show_positive ); }


      private:
        int64_t maslp_input;
        bool maslp_show_positive;


    };
    class masls_overload1_format_integerHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_format_integerInvoker
    {

      public:
        masls_overload1_format_integerInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_show_positive(),
            maslp_justification(),
            maslp_width(),
            maslp_pad()

        {
          channel >> maslp_input;
          channel >> maslp_show_positive;
          channel >> maslp_justification;
          channel >> maslp_width;
          channel >> maslp_pad;
        }
        void operator() ( ) { ::masld_Format::masls_overload1_format_integer( maslp_input, maslp_show_positive, maslp_justification, maslp_width, maslp_pad ); }


      private:
        int64_t maslp_input;
        bool maslp_show_positive;
        ::masld_Format::maslt_justify maslp_justification;
        int32_t maslp_width;
        char maslp_pad;


    };
    class masls_format_based_integerHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_based_integerInvoker
    {

      public:
        masls_format_based_integerInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_show_positive(),
            maslp_base(),
            maslp_base_case()

        {
          channel >> maslp_input;
          channel >> maslp_show_positive;
          channel >> maslp_base;
          channel >> maslp_base_case;
        }
        void operator() ( ) { ::masld_Format::masls_format_based_integer( maslp_input, maslp_show_positive, maslp_base, maslp_base_case ); }


      private:
        int64_t maslp_input;
        bool maslp_show_positive;
        int32_t maslp_base;
        ::masld_Format::maslt_base_case maslp_base_case;


    };
    class masls_overload1_format_based_integerHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_format_based_integerInvoker
    {

      public:
        masls_overload1_format_based_integerInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_show_positive(),
            maslp_base(),
            maslp_base_case(),
            maslp_justification(),
            maslp_width(),
            maslp_pad()

        {
          channel >> maslp_input;
          channel >> maslp_show_positive;
          channel >> maslp_base;
          channel >> maslp_base_case;
          channel >> maslp_justification;
          channel >> maslp_width;
          channel >> maslp_pad;
        }
        void operator() ( ) { ::masld_Format::masls_overload1_format_based_integer( maslp_input, maslp_show_positive, maslp_base, maslp_base_case, maslp_justification, maslp_width, maslp_pad ); }


      private:
        int64_t maslp_input;
        bool maslp_show_positive;
        int32_t maslp_base;
        ::masld_Format::maslt_base_case maslp_base_case;
        ::masld_Format::maslt_justify maslp_justification;
        int32_t maslp_width;
        char maslp_pad;


    };
    class masls_format_numberHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_numberInvoker
    {

      public:
        masls_format_numberInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_show_positive(),
            maslp_sigfigs()

        {
          channel >> maslp_input;
          channel >> maslp_show_positive;
          channel >> maslp_sigfigs;
        }
        void operator() ( ) { ::masld_Format::masls_format_number( maslp_input, maslp_show_positive, maslp_sigfigs ); }


      private:
        double maslp_input;
        bool maslp_show_positive;
        int32_t maslp_sigfigs;


    };
    class masls_overload1_format_numberHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_format_numberInvoker
    {

      public:
        masls_overload1_format_numberInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_show_positive(),
            maslp_sigfigs(),
            maslp_justification(),
            maslp_width(),
            maslp_pad()

        {
          channel >> maslp_input;
          channel >> maslp_show_positive;
          channel >> maslp_sigfigs;
          channel >> maslp_justification;
          channel >> maslp_width;
          channel >> maslp_pad;
        }
        void operator() ( ) { ::masld_Format::masls_overload1_format_number( maslp_input, maslp_show_positive, maslp_sigfigs, maslp_justification, maslp_width, maslp_pad ); }


      private:
        double maslp_input;
        bool maslp_show_positive;
        int32_t maslp_sigfigs;
        ::masld_Format::maslt_justify maslp_justification;
        int32_t maslp_width;
        char maslp_pad;


    };
    class masls_format_decimalHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_decimalInvoker
    {

      public:
        masls_format_decimalInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_show_positive(),
            maslp_sigfigs()

        {
          channel >> maslp_input;
          channel >> maslp_show_positive;
          channel >> maslp_sigfigs;
        }
        void operator() ( ) { ::masld_Format::masls_format_decimal( maslp_input, maslp_show_positive, maslp_sigfigs ); }


      private:
        double maslp_input;
        bool maslp_show_positive;
        int32_t maslp_sigfigs;


    };
    class masls_overload1_format_decimalHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_format_decimalInvoker
    {

      public:
        masls_overload1_format_decimalInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_show_positive(),
            maslp_sigfigs(),
            maslp_justification(),
            maslp_width(),
            maslp_pad()

        {
          channel >> maslp_input;
          channel >> maslp_show_positive;
          channel >> maslp_sigfigs;
          channel >> maslp_justification;
          channel >> maslp_width;
          channel >> maslp_pad;
        }
        void operator() ( ) { ::masld_Format::masls_overload1_format_decimal( maslp_input, maslp_show_positive, maslp_sigfigs, maslp_justification, maslp_width, maslp_pad ); }


      private:
        double maslp_input;
        bool maslp_show_positive;
        int32_t maslp_sigfigs;
        ::masld_Format::maslt_justify maslp_justification;
        int32_t maslp_width;
        char maslp_pad;


    };
    class masls_format_scientificHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_scientificInvoker
    {

      public:
        masls_format_scientificInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_show_positive(),
            maslp_sigfigs()

        {
          channel >> maslp_input;
          channel >> maslp_show_positive;
          channel >> maslp_sigfigs;
        }
        void operator() ( ) { ::masld_Format::masls_format_scientific( maslp_input, maslp_show_positive, maslp_sigfigs ); }


      private:
        double maslp_input;
        bool maslp_show_positive;
        int32_t maslp_sigfigs;


    };
    class masls_overload1_format_scientificHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_format_scientificInvoker
    {

      public:
        masls_overload1_format_scientificInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_show_positive(),
            maslp_sigfigs(),
            maslp_justification(),
            maslp_width(),
            maslp_pad()

        {
          channel >> maslp_input;
          channel >> maslp_show_positive;
          channel >> maslp_sigfigs;
          channel >> maslp_justification;
          channel >> maslp_width;
          channel >> maslp_pad;
        }
        void operator() ( ) { ::masld_Format::masls_overload1_format_scientific( maslp_input, maslp_show_positive, maslp_sigfigs, maslp_justification, maslp_width, maslp_pad ); }


      private:
        double maslp_input;
        bool maslp_show_positive;
        int32_t maslp_sigfigs;
        ::masld_Format::maslt_justify maslp_justification;
        int32_t maslp_width;
        char maslp_pad;


    };
    class masls_format_fixedHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_fixedInvoker
    {

      public:
        masls_format_fixedInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_show_positive(),
            maslp_places()

        {
          channel >> maslp_input;
          channel >> maslp_show_positive;
          channel >> maslp_places;
        }
        void operator() ( ) { ::masld_Format::masls_format_fixed( maslp_input, maslp_show_positive, maslp_places ); }


      private:
        double maslp_input;
        bool maslp_show_positive;
        int32_t maslp_places;


    };
    class masls_overload1_format_fixedHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_format_fixedInvoker
    {

      public:
        masls_overload1_format_fixedInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_show_positive(),
            maslp_places(),
            maslp_justification(),
            maslp_width(),
            maslp_pad()

        {
          channel >> maslp_input;
          channel >> maslp_show_positive;
          channel >> maslp_places;
          channel >> maslp_justification;
          channel >> maslp_width;
          channel >> maslp_pad;
        }
        void operator() ( ) { ::masld_Format::masls_overload1_format_fixed( maslp_input, maslp_show_positive, maslp_places, maslp_justification, maslp_width, maslp_pad ); }


      private:
        double maslp_input;
        bool maslp_show_positive;
        int32_t maslp_places;
        ::masld_Format::maslt_justify maslp_justification;
        int32_t maslp_width;
        char maslp_pad;


    };
    class masls_format_booleanHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_booleanInvoker
    {

      public:
        masls_format_booleanInvoker ( CommunicationChannel& channel )
          : maslp_input()
 { channel >> maslp_input; }
        void operator() ( ) { ::masld_Format::masls_format_boolean( maslp_input ); }


      private:
        bool maslp_input;


    };
    class masls_overload1_format_booleanHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_format_booleanInvoker
    {

      public:
        masls_overload1_format_booleanInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_true_text(),
            maslp_false_text()

        {
          channel >> maslp_input;
          channel >> maslp_true_text;
          channel >> maslp_false_text;
        }
        void operator() ( ) { ::masld_Format::masls_overload1_format_boolean( maslp_input, maslp_true_text, maslp_false_text ); }


      private:
        bool maslp_input;
        ::SWA::String maslp_true_text;
        ::SWA::String maslp_false_text;


    };
    class masls_format_stringHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_stringInvoker
    {

      public:
        masls_format_stringInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_justification(),
            maslp_width(),
            maslp_pad()

        {
          channel >> maslp_input;
          channel >> maslp_justification;
          channel >> maslp_width;
          channel >> maslp_pad;
        }
        void operator() ( ) { ::masld_Format::masls_format_string( maslp_input, maslp_justification, maslp_width, maslp_pad ); }


      private:
        ::SWA::String maslp_input;
        ::masld_Format::maslt_justify maslp_justification;
        int32_t maslp_width;
        char maslp_pad;


    };
    class masls_format_duration_isoHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_duration_isoInvoker
    {

      public:
        masls_format_duration_isoInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_max_field(),
            maslp_min_field(),
            maslp_hide_zero(),
            maslp_places(),
            maslp_truncate()

        {
          channel >> maslp_input;
          channel >> maslp_max_field;
          channel >> maslp_min_field;
          channel >> maslp_hide_zero;
          channel >> maslp_places;
          channel >> maslp_truncate;
        }
        void operator() ( ) { ::masld_Format::masls_format_duration_iso( maslp_input, maslp_max_field, maslp_min_field, maslp_hide_zero, maslp_places, maslp_truncate ); }


      private:
        ::SWA::Duration maslp_input;
        ::masld_Format::maslt_duration_field maslp_max_field;
        ::masld_Format::maslt_duration_field maslp_min_field;
        bool maslp_hide_zero;
        int32_t maslp_places;
        bool maslp_truncate;


    };
    class masls_format_duration_hmsHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_duration_hmsInvoker
    {

      public:
        masls_format_duration_hmsInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_min_field(),
            maslp_places(),
            maslp_truncate()

        {
          channel >> maslp_input;
          channel >> maslp_min_field;
          channel >> maslp_places;
          channel >> maslp_truncate;
        }
        void operator() ( ) { ::masld_Format::masls_format_duration_hms( maslp_input, maslp_min_field, maslp_places, maslp_truncate ); }


      private:
        ::SWA::Duration maslp_input;
        ::masld_Format::maslt_duration_field maslp_min_field;
        int32_t maslp_places;
        bool maslp_truncate;


    };
    class masls_format_durationHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_durationInvoker
    {

      public:
        masls_format_durationInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_max_field(),
            maslp_min_field(),
            maslp_rounding_mode(),
            maslp_hide_zero(),
            maslp_places(),
            maslp_truncate(),
            maslp_field_width(),
            maslp_prefix(),
            maslp_time_prefix(),
            maslp_suffixes()

        {
          channel >> maslp_input;
          channel >> maslp_max_field;
          channel >> maslp_min_field;
          channel >> maslp_rounding_mode;
          channel >> maslp_hide_zero;
          channel >> maslp_places;
          channel >> maslp_truncate;
          channel >> maslp_field_width;
          channel >> maslp_prefix;
          channel >> maslp_time_prefix;
          channel >> maslp_suffixes;
        }
        void operator() ( ) { ::masld_Format::masls_format_duration( maslp_input, maslp_max_field, maslp_min_field, maslp_rounding_mode, maslp_hide_zero, maslp_places, maslp_truncate, maslp_field_width, maslp_prefix, maslp_time_prefix, maslp_suffixes ); }


      private:
        ::SWA::Duration maslp_input;
        ::masld_Format::maslt_duration_field maslp_max_field;
        ::masld_Format::maslt_duration_field maslp_min_field;
        ::masld_Format::maslt_rounding maslp_rounding_mode;
        bool maslp_hide_zero;
        int32_t maslp_places;
        bool maslp_truncate;
        int32_t maslp_field_width;
        ::SWA::String maslp_prefix;
        ::SWA::String maslp_time_prefix;
        ::SWA::Sequence< ::SWA::String> maslp_suffixes;


    };
    class masls_format_timestamp_iso_ymdhmsHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_timestamp_iso_ymdhmsInvoker
    {

      public:
        masls_format_timestamp_iso_ymdhmsInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_min_field(),
            maslp_places(),
            maslp_truncate()

        {
          channel >> maslp_input;
          channel >> maslp_min_field;
          channel >> maslp_places;
          channel >> maslp_truncate;
        }
        void operator() ( ) { ::masld_Format::masls_format_timestamp_iso_ymdhms( maslp_input, maslp_min_field, maslp_places, maslp_truncate ); }


      private:
        ::SWA::Timestamp maslp_input;
        ::masld_Format::maslt_timestamp_field maslp_min_field;
        int32_t maslp_places;
        bool maslp_truncate;


    };
    class masls_format_timestamp_iso_ydhmsHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_timestamp_iso_ydhmsInvoker
    {

      public:
        masls_format_timestamp_iso_ydhmsInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_min_field(),
            maslp_places(),
            maslp_truncate()

        {
          channel >> maslp_input;
          channel >> maslp_min_field;
          channel >> maslp_places;
          channel >> maslp_truncate;
        }
        void operator() ( ) { ::masld_Format::masls_format_timestamp_iso_ydhms( maslp_input, maslp_min_field, maslp_places, maslp_truncate ); }


      private:
        ::SWA::Timestamp maslp_input;
        ::masld_Format::maslt_timestamp_field maslp_min_field;
        int32_t maslp_places;
        bool maslp_truncate;


    };
    class masls_format_timestamp_iso_ywdhmsHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_timestamp_iso_ywdhmsInvoker
    {

      public:
        masls_format_timestamp_iso_ywdhmsInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_min_field(),
            maslp_places(),
            maslp_truncate()

        {
          channel >> maslp_input;
          channel >> maslp_min_field;
          channel >> maslp_places;
          channel >> maslp_truncate;
        }
        void operator() ( ) { ::masld_Format::masls_format_timestamp_iso_ywdhms( maslp_input, maslp_min_field, maslp_places, maslp_truncate ); }


      private:
        ::SWA::Timestamp maslp_input;
        ::masld_Format::maslt_timestamp_field maslp_min_field;
        int32_t maslp_places;
        bool maslp_truncate;


    };
    class masls_format_timestamp_compact_iso_ymdhmsHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_timestamp_compact_iso_ymdhmsInvoker
    {

      public:
        masls_format_timestamp_compact_iso_ymdhmsInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_min_field(),
            maslp_places(),
            maslp_truncate()

        {
          channel >> maslp_input;
          channel >> maslp_min_field;
          channel >> maslp_places;
          channel >> maslp_truncate;
        }
        void operator() ( ) { ::masld_Format::masls_format_timestamp_compact_iso_ymdhms( maslp_input, maslp_min_field, maslp_places, maslp_truncate ); }


      private:
        ::SWA::Timestamp maslp_input;
        ::masld_Format::maslt_timestamp_field maslp_min_field;
        int32_t maslp_places;
        bool maslp_truncate;


    };
    class masls_format_timestamp_compact_iso_ydhmsHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_timestamp_compact_iso_ydhmsInvoker
    {

      public:
        masls_format_timestamp_compact_iso_ydhmsInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_min_field(),
            maslp_places(),
            maslp_truncate()

        {
          channel >> maslp_input;
          channel >> maslp_min_field;
          channel >> maslp_places;
          channel >> maslp_truncate;
        }
        void operator() ( ) { ::masld_Format::masls_format_timestamp_compact_iso_ydhms( maslp_input, maslp_min_field, maslp_places, maslp_truncate ); }


      private:
        ::SWA::Timestamp maslp_input;
        ::masld_Format::maslt_timestamp_field maslp_min_field;
        int32_t maslp_places;
        bool maslp_truncate;


    };
    class masls_format_timestamp_compact_iso_ywdhmsHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_timestamp_compact_iso_ywdhmsInvoker
    {

      public:
        masls_format_timestamp_compact_iso_ywdhmsInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_min_field(),
            maslp_places(),
            maslp_truncate()

        {
          channel >> maslp_input;
          channel >> maslp_min_field;
          channel >> maslp_places;
          channel >> maslp_truncate;
        }
        void operator() ( ) { ::masld_Format::masls_format_timestamp_compact_iso_ywdhms( maslp_input, maslp_min_field, maslp_places, maslp_truncate ); }


      private:
        ::SWA::Timestamp maslp_input;
        ::masld_Format::maslt_timestamp_field maslp_min_field;
        int32_t maslp_places;
        bool maslp_truncate;


    };
    class masls_format_timestamp_dmyHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_timestamp_dmyInvoker
    {

      public:
        masls_format_timestamp_dmyInvoker ( CommunicationChannel& channel )
          : maslp_input()
 { channel >> maslp_input; }
        void operator() ( ) { ::masld_Format::masls_format_timestamp_dmy( maslp_input ); }


      private:
        ::SWA::Timestamp maslp_input;


    };
    class masls_format_timestamp_mdyHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_timestamp_mdyInvoker
    {

      public:
        masls_format_timestamp_mdyInvoker ( CommunicationChannel& channel )
          : maslp_input()
 { channel >> maslp_input; }
        void operator() ( ) { ::masld_Format::masls_format_timestamp_mdy( maslp_input ); }


      private:
        ::SWA::Timestamp maslp_input;


    };
    class masls_format_timestamp_dtgHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_timestamp_dtgInvoker
    {

      public:
        masls_format_timestamp_dtgInvoker ( CommunicationChannel& channel )
          : maslp_input()
 { channel >> maslp_input; }
        void operator() ( ) { ::masld_Format::masls_format_timestamp_dtg( maslp_input ); }


      private:
        ::SWA::Timestamp maslp_input;


    };
    class masls_format_timestamp_timeHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_timestamp_timeInvoker
    {

      public:
        masls_format_timestamp_timeInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_min_field(),
            maslp_places(),
            maslp_truncate()

        {
          channel >> maslp_input;
          channel >> maslp_min_field;
          channel >> maslp_places;
          channel >> maslp_truncate;
        }
        void operator() ( ) { ::masld_Format::masls_format_timestamp_time( maslp_input, maslp_min_field, maslp_places, maslp_truncate ); }


      private:
        ::SWA::Timestamp maslp_input;
        ::masld_Format::maslt_timestamp_field maslp_min_field;
        int32_t maslp_places;
        bool maslp_truncate;


    };
    class masls_format_timestamp_compact_timeHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_format_timestamp_compact_timeInvoker
    {

      public:
        masls_format_timestamp_compact_timeInvoker ( CommunicationChannel& channel )
          : maslp_input(),
            maslp_min_field(),
            maslp_places(),
            maslp_truncate()

        {
          channel >> maslp_input;
          channel >> maslp_min_field;
          channel >> maslp_places;
          channel >> maslp_truncate;
        }
        void operator() ( ) { ::masld_Format::masls_format_timestamp_compact_time( maslp_input, maslp_min_field, maslp_places, maslp_truncate ); }


      private:
        ::SWA::Timestamp maslp_input;
        ::masld_Format::maslt_timestamp_field maslp_min_field;
        int32_t maslp_places;
        bool maslp_truncate;


    };
    class masld_FormatHandler
      : public DomainHandler
    {

      public:
        masld_FormatHandler ( );
        void createRelationship ( CommunicationChannel& channel,
                                  int                   relId );


    };
    Callable masls_to_asciiHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_to_asciiInvoker( channel );
    }

    void masls_to_asciiHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                 const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue<char>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_to_asciiHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_to_asciiInvoker( channel );
    }

    void masls_overload1_to_asciiHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                           const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_from_asciiHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_from_asciiInvoker( channel );
    }

    void masls_from_asciiHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                   const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue<uint8_t>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_from_asciiHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_from_asciiInvoker( channel );
    }

    void masls_overload1_from_asciiHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                             const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::Sequence<uint8_t> >();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_integerHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_integerInvoker( channel );
    }

    void masls_format_integerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                       const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue<int64_t>();

      // Write show_positive
      channel << frame.getParameters()[1].getValue<bool>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_format_integerHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_format_integerInvoker( channel );
    }

    void masls_overload1_format_integerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                                 const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue<int64_t>();

      // Write show_positive
      channel << frame.getParameters()[1].getValue<bool>();

      // Write justification
      channel << frame.getParameters()[2].getValue< ::masld_Format::maslt_justify>();

      // Write width
      channel << frame.getParameters()[3].getValue<int32_t>();

      // Write pad
      channel << frame.getParameters()[4].getValue<char>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_based_integerHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_based_integerInvoker( channel );
    }

    void masls_format_based_integerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                             const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue<int64_t>();

      // Write show_positive
      channel << frame.getParameters()[1].getValue<bool>();

      // Write base
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write base_case
      channel << frame.getParameters()[3].getValue< ::masld_Format::maslt_base_case>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_format_based_integerHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_format_based_integerInvoker( channel );
    }

    void masls_overload1_format_based_integerHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                                       const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue<int64_t>();

      // Write show_positive
      channel << frame.getParameters()[1].getValue<bool>();

      // Write base
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write base_case
      channel << frame.getParameters()[3].getValue< ::masld_Format::maslt_base_case>();

      // Write justification
      channel << frame.getParameters()[4].getValue< ::masld_Format::maslt_justify>();

      // Write width
      channel << frame.getParameters()[5].getValue<int32_t>();

      // Write pad
      channel << frame.getParameters()[6].getValue<char>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_numberHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_numberInvoker( channel );
    }

    void masls_format_numberHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                      const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue<double>();

      // Write show_positive
      channel << frame.getParameters()[1].getValue<bool>();

      // Write sigfigs
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_format_numberHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_format_numberInvoker( channel );
    }

    void masls_overload1_format_numberHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                                const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue<double>();

      // Write show_positive
      channel << frame.getParameters()[1].getValue<bool>();

      // Write sigfigs
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write justification
      channel << frame.getParameters()[3].getValue< ::masld_Format::maslt_justify>();

      // Write width
      channel << frame.getParameters()[4].getValue<int32_t>();

      // Write pad
      channel << frame.getParameters()[5].getValue<char>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_decimalHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_decimalInvoker( channel );
    }

    void masls_format_decimalHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                       const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue<double>();

      // Write show_positive
      channel << frame.getParameters()[1].getValue<bool>();

      // Write sigfigs
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_format_decimalHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_format_decimalInvoker( channel );
    }

    void masls_overload1_format_decimalHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                                 const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue<double>();

      // Write show_positive
      channel << frame.getParameters()[1].getValue<bool>();

      // Write sigfigs
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write justification
      channel << frame.getParameters()[3].getValue< ::masld_Format::maslt_justify>();

      // Write width
      channel << frame.getParameters()[4].getValue<int32_t>();

      // Write pad
      channel << frame.getParameters()[5].getValue<char>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_scientificHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_scientificInvoker( channel );
    }

    void masls_format_scientificHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                          const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue<double>();

      // Write show_positive
      channel << frame.getParameters()[1].getValue<bool>();

      // Write sigfigs
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_format_scientificHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_format_scientificInvoker( channel );
    }

    void masls_overload1_format_scientificHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                                    const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue<double>();

      // Write show_positive
      channel << frame.getParameters()[1].getValue<bool>();

      // Write sigfigs
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write justification
      channel << frame.getParameters()[3].getValue< ::masld_Format::maslt_justify>();

      // Write width
      channel << frame.getParameters()[4].getValue<int32_t>();

      // Write pad
      channel << frame.getParameters()[5].getValue<char>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_fixedHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_fixedInvoker( channel );
    }

    void masls_format_fixedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue<double>();

      // Write show_positive
      channel << frame.getParameters()[1].getValue<bool>();

      // Write places
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_format_fixedHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_format_fixedInvoker( channel );
    }

    void masls_overload1_format_fixedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                               const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue<double>();

      // Write show_positive
      channel << frame.getParameters()[1].getValue<bool>();

      // Write places
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write justification
      channel << frame.getParameters()[3].getValue< ::masld_Format::maslt_justify>();

      // Write width
      channel << frame.getParameters()[4].getValue<int32_t>();

      // Write pad
      channel << frame.getParameters()[5].getValue<char>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_booleanHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_booleanInvoker( channel );
    }

    void masls_format_booleanHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                       const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue<bool>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_format_booleanHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_format_booleanInvoker( channel );
    }

    void masls_overload1_format_booleanHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                                 const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue<bool>();

      // Write true_text
      channel << frame.getParameters()[1].getValue< ::SWA::String>();

      // Write false_text
      channel << frame.getParameters()[2].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_stringHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_stringInvoker( channel );
    }

    void masls_format_stringHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                      const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write justification
      channel << frame.getParameters()[1].getValue< ::masld_Format::maslt_justify>();

      // Write width
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write pad
      channel << frame.getParameters()[3].getValue<char>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_duration_isoHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_duration_isoInvoker( channel );
    }

    void masls_format_duration_isoHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                            const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::Duration>();

      // Write max_field
      channel << frame.getParameters()[1].getValue< ::masld_Format::maslt_duration_field>();

      // Write min_field
      channel << frame.getParameters()[2].getValue< ::masld_Format::maslt_duration_field>();

      // Write hide_zero
      channel << frame.getParameters()[3].getValue<bool>();

      // Write places
      channel << frame.getParameters()[4].getValue<int32_t>();

      // Write truncate
      channel << frame.getParameters()[5].getValue<bool>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_duration_hmsHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_duration_hmsInvoker( channel );
    }

    void masls_format_duration_hmsHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                            const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::Duration>();

      // Write min_field
      channel << frame.getParameters()[1].getValue< ::masld_Format::maslt_duration_field>();

      // Write places
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write truncate
      channel << frame.getParameters()[3].getValue<bool>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_durationHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_durationInvoker( channel );
    }

    void masls_format_durationHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                        const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::Duration>();

      // Write max_field
      channel << frame.getParameters()[1].getValue< ::masld_Format::maslt_duration_field>();

      // Write min_field
      channel << frame.getParameters()[2].getValue< ::masld_Format::maslt_duration_field>();

      // Write rounding_mode
      channel << frame.getParameters()[3].getValue< ::masld_Format::maslt_rounding>();

      // Write hide_zero
      channel << frame.getParameters()[4].getValue<bool>();

      // Write places
      channel << frame.getParameters()[5].getValue<int32_t>();

      // Write truncate
      channel << frame.getParameters()[6].getValue<bool>();

      // Write field_width
      channel << frame.getParameters()[7].getValue<int32_t>();

      // Write prefix
      channel << frame.getParameters()[8].getValue< ::SWA::String>();

      // Write time_prefix
      channel << frame.getParameters()[9].getValue< ::SWA::String>();

      // Write suffixes
      channel << frame.getParameters()[10].getValue< ::SWA::Sequence< ::SWA::String> >();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_timestamp_iso_ymdhmsHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_timestamp_iso_ymdhmsInvoker( channel );
    }

    void masls_format_timestamp_iso_ymdhmsHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                                    const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::Timestamp>();

      // Write min_field
      channel << frame.getParameters()[1].getValue< ::masld_Format::maslt_timestamp_field>();

      // Write places
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write truncate
      channel << frame.getParameters()[3].getValue<bool>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_timestamp_iso_ydhmsHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_timestamp_iso_ydhmsInvoker( channel );
    }

    void masls_format_timestamp_iso_ydhmsHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                                   const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::Timestamp>();

      // Write min_field
      channel << frame.getParameters()[1].getValue< ::masld_Format::maslt_timestamp_field>();

      // Write places
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write truncate
      channel << frame.getParameters()[3].getValue<bool>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_timestamp_iso_ywdhmsHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_timestamp_iso_ywdhmsInvoker( channel );
    }

    void masls_format_timestamp_iso_ywdhmsHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                                    const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::Timestamp>();

      // Write min_field
      channel << frame.getParameters()[1].getValue< ::masld_Format::maslt_timestamp_field>();

      // Write places
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write truncate
      channel << frame.getParameters()[3].getValue<bool>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_timestamp_compact_iso_ymdhmsHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_timestamp_compact_iso_ymdhmsInvoker( channel );
    }

    void masls_format_timestamp_compact_iso_ymdhmsHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                                            const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::Timestamp>();

      // Write min_field
      channel << frame.getParameters()[1].getValue< ::masld_Format::maslt_timestamp_field>();

      // Write places
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write truncate
      channel << frame.getParameters()[3].getValue<bool>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_timestamp_compact_iso_ydhmsHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_timestamp_compact_iso_ydhmsInvoker( channel );
    }

    void masls_format_timestamp_compact_iso_ydhmsHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                                           const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::Timestamp>();

      // Write min_field
      channel << frame.getParameters()[1].getValue< ::masld_Format::maslt_timestamp_field>();

      // Write places
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write truncate
      channel << frame.getParameters()[3].getValue<bool>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_timestamp_compact_iso_ywdhmsHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_timestamp_compact_iso_ywdhmsInvoker( channel );
    }

    void masls_format_timestamp_compact_iso_ywdhmsHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                                            const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::Timestamp>();

      // Write min_field
      channel << frame.getParameters()[1].getValue< ::masld_Format::maslt_timestamp_field>();

      // Write places
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write truncate
      channel << frame.getParameters()[3].getValue<bool>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_timestamp_dmyHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_timestamp_dmyInvoker( channel );
    }

    void masls_format_timestamp_dmyHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                             const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::Timestamp>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_timestamp_mdyHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_timestamp_mdyInvoker( channel );
    }

    void masls_format_timestamp_mdyHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                             const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::Timestamp>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_timestamp_dtgHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_timestamp_dtgInvoker( channel );
    }

    void masls_format_timestamp_dtgHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                             const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::Timestamp>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_timestamp_timeHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_timestamp_timeInvoker( channel );
    }

    void masls_format_timestamp_timeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                              const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::Timestamp>();

      // Write min_field
      channel << frame.getParameters()[1].getValue< ::masld_Format::maslt_timestamp_field>();

      // Write places
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write truncate
      channel << frame.getParameters()[3].getValue<bool>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_format_timestamp_compact_timeHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_format_timestamp_compact_timeInvoker( channel );
    }

    void masls_format_timestamp_compact_timeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                                      const ::SWA::StackFrame& frame ) const
    {

      // Write input
      channel << frame.getParameters()[0].getValue< ::SWA::Timestamp>();

      // Write min_field
      channel << frame.getParameters()[1].getValue< ::masld_Format::maslt_timestamp_field>();

      // Write places
      channel << frame.getParameters()[2].getValue<int32_t>();

      // Write truncate
      channel << frame.getParameters()[3].getValue<bool>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    masld_FormatHandler::masld_FormatHandler ( )
    {
      registerServiceHandler( ::masld_Format::serviceId_masls_to_ascii, ::boost::shared_ptr<ActionHandler>( new masls_to_asciiHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_overload1_to_ascii, ::boost::shared_ptr<ActionHandler>( new masls_overload1_to_asciiHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_from_ascii, ::boost::shared_ptr<ActionHandler>( new masls_from_asciiHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_overload1_from_ascii, ::boost::shared_ptr<ActionHandler>( new masls_overload1_from_asciiHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_integer, ::boost::shared_ptr<ActionHandler>( new masls_format_integerHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_overload1_format_integer, ::boost::shared_ptr<ActionHandler>( new masls_overload1_format_integerHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_based_integer, ::boost::shared_ptr<ActionHandler>( new masls_format_based_integerHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_overload1_format_based_integer, ::boost::shared_ptr<ActionHandler>( new masls_overload1_format_based_integerHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_number, ::boost::shared_ptr<ActionHandler>( new masls_format_numberHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_overload1_format_number, ::boost::shared_ptr<ActionHandler>( new masls_overload1_format_numberHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_decimal, ::boost::shared_ptr<ActionHandler>( new masls_format_decimalHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_overload1_format_decimal, ::boost::shared_ptr<ActionHandler>( new masls_overload1_format_decimalHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_scientific, ::boost::shared_ptr<ActionHandler>( new masls_format_scientificHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_overload1_format_scientific, ::boost::shared_ptr<ActionHandler>( new masls_overload1_format_scientificHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_fixed, ::boost::shared_ptr<ActionHandler>( new masls_format_fixedHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_overload1_format_fixed, ::boost::shared_ptr<ActionHandler>( new masls_overload1_format_fixedHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_boolean, ::boost::shared_ptr<ActionHandler>( new masls_format_booleanHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_overload1_format_boolean, ::boost::shared_ptr<ActionHandler>( new masls_overload1_format_booleanHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_string, ::boost::shared_ptr<ActionHandler>( new masls_format_stringHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_duration_iso, ::boost::shared_ptr<ActionHandler>( new masls_format_duration_isoHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_duration_hms, ::boost::shared_ptr<ActionHandler>( new masls_format_duration_hmsHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_duration, ::boost::shared_ptr<ActionHandler>( new masls_format_durationHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_timestamp_iso_ymdhms, ::boost::shared_ptr<ActionHandler>( new masls_format_timestamp_iso_ymdhmsHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_timestamp_iso_ydhms, ::boost::shared_ptr<ActionHandler>( new masls_format_timestamp_iso_ydhmsHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_timestamp_iso_ywdhms, ::boost::shared_ptr<ActionHandler>( new masls_format_timestamp_iso_ywdhmsHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_timestamp_compact_iso_ymdhms, ::boost::shared_ptr<ActionHandler>( new masls_format_timestamp_compact_iso_ymdhmsHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_timestamp_compact_iso_ydhms, ::boost::shared_ptr<ActionHandler>( new masls_format_timestamp_compact_iso_ydhmsHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_timestamp_compact_iso_ywdhms, ::boost::shared_ptr<ActionHandler>( new masls_format_timestamp_compact_iso_ywdhmsHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_timestamp_dmy, ::boost::shared_ptr<ActionHandler>( new masls_format_timestamp_dmyHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_timestamp_mdy, ::boost::shared_ptr<ActionHandler>( new masls_format_timestamp_mdyHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_timestamp_dtg, ::boost::shared_ptr<ActionHandler>( new masls_format_timestamp_dtgHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_timestamp_time, ::boost::shared_ptr<ActionHandler>( new masls_format_timestamp_timeHandler() ) );
      registerServiceHandler( ::masld_Format::serviceId_masls_format_timestamp_compact_time, ::boost::shared_ptr<ActionHandler>( new masls_format_timestamp_compact_timeHandler() ) );
    }

    void masld_FormatHandler::createRelationship ( CommunicationChannel& channel,
                                                   int                   relId )
    {
      switch ( relId )
      {
      }

    }

  }
}
namespace 
{
  bool masld_Format_registered = ::Inspector::ProcessHandler::getInstance().registerDomainHandler( ::SWA::Process::getInstance().getDomain( "Format" ).getId(), ::boost::shared_ptr< ::Inspector::DomainHandler>( new ::Inspector::masld_Format::masld_FormatHandler() ) );

}
