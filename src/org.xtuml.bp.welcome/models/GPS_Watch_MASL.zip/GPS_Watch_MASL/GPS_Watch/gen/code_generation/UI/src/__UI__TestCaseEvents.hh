//
// File: __UI__TestCaseEvents.hh
//
#ifndef _UI_Test_Case_Events_hh
#define _UI_Test_Case_Events_hh

#include <stdint.h>
#include "swa/Event.hh"

namespace masld_UI
{
  class Event_maslo_TestCase_maslev_doDelay
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_TestCase_maslev_doDelay ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_TestCase_maslev_finish
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_TestCase_maslev_finish ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_TestCase_maslev_initializationComplete
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_TestCase_maslev_initializationComplete ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_TestCase_maslev_initialize
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_TestCase_maslev_initialize ( );
      Event_maslo_TestCase_maslev_initialize ( int32_t maslp_iterations );
      virtual void invoke ( ) const;
    private:
      int32_t maslp_iterations;
    public:
      int32_t getmaslp_iterations ( ) const { return maslp_iterations; }


  };
}
#endif // _UI_Test_Case_Events_hh
