//
// File: __Format_types.cc
//
#include "Format_OOA/__Format_types.hh"
#include <iostream>
#include <stdint.h>
#include <string>
#include "swa/ProgramError.hh"

namespace masld_Format
{
  maslt_justify::maslt_justify ( )
    : index(index_masle_left)
  {
  }

  maslt_justify::maslt_justify ( Index index )
    : index(index)
  {
  }

  const maslt_justify maslt_justify::masle_left = maslt_justify( maslt_justify::index_masle_left );

  const maslt_justify maslt_justify::masle_right = maslt_justify( maslt_justify::index_masle_right );

  const maslt_justify maslt_justify::masle_internal = maslt_justify( maslt_justify::index_masle_internal );

  maslt_justify::maslt_justify ( const ::std::string& text )
    : index(fromText( text ))
  {
  }

  const char* const maslt_justify::textLookup[] = { "left",
     "right",
     "internal"};

  maslt_justify::TextLookupTable maslt_justify::getLookupTable ( )
  {
    TextLookupTable lookup;
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_left], index_masle_left ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_right], index_masle_right ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_internal], index_masle_internal ) );
    return lookup;
  }

  maslt_justify::Index maslt_justify::fromText ( const ::std::string& text )
  {
    static TextLookupTable lookup = getLookupTable();
    TextLookupTable::const_iterator pos = lookup.find( text );
    if ( pos == lookup.end() ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    return pos->second;
  }

  maslt_justify::maslt_justify ( Value value )
    : index(fromValue( value ))
  {
  }

  maslt_justify::Value maslt_justify::valueLookup[] = { maslt_justify::value_masle_left,
     maslt_justify::value_masle_right,
     maslt_justify::value_masle_internal};

  maslt_justify::Index maslt_justify::fromValue ( Value value )
  {
    switch ( value )
    {
      case value_masle_left:     return index_masle_left;
      case value_masle_right:    return index_masle_right;
      case value_masle_internal: return index_masle_internal;
      default:                   throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    }

  }

  maslt_justify::maslt_justify ( int32_t value )
    : index(fromValue( Value( value ) ))
  {
  }

  maslt_justify& maslt_justify::operator++ ( )
  {
    if ( index == index_masle_internal ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index + 1 );
    return *this;
  }

  maslt_justify& maslt_justify::operator-- ( )
  {
    if ( index == index_masle_left ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index - 1 );
    return *this;
  }

  ::std::ostream& operator<< ( ::std::ostream&      stream,
                               const maslt_justify& obj )
  {
    return stream << obj.getText();
  }

  ::std::istream& operator>> ( ::std::istream& stream,
                               maslt_justify&  obj )
  {
    ::std::string text;
    stream >> text;
    obj = maslt_justify( text );
    return stream;
  }

  maslt_base_case::maslt_base_case ( )
    : index(index_masle_upper)
  {
  }

  maslt_base_case::maslt_base_case ( Index index )
    : index(index)
  {
  }

  const maslt_base_case maslt_base_case::masle_upper = maslt_base_case( maslt_base_case::index_masle_upper );

  const maslt_base_case maslt_base_case::masle_lower = maslt_base_case( maslt_base_case::index_masle_lower );

  maslt_base_case::maslt_base_case ( const ::std::string& text )
    : index(fromText( text ))
  {
  }

  const char* const maslt_base_case::textLookup[] = { "upper",
     "lower"};

  maslt_base_case::TextLookupTable maslt_base_case::getLookupTable ( )
  {
    TextLookupTable lookup;
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_upper], index_masle_upper ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_lower], index_masle_lower ) );
    return lookup;
  }

  maslt_base_case::Index maslt_base_case::fromText ( const ::std::string& text )
  {
    static TextLookupTable lookup = getLookupTable();
    TextLookupTable::const_iterator pos = lookup.find( text );
    if ( pos == lookup.end() ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    return pos->second;
  }

  maslt_base_case::maslt_base_case ( Value value )
    : index(fromValue( value ))
  {
  }

  maslt_base_case::Value maslt_base_case::valueLookup[] = { maslt_base_case::value_masle_upper,
     maslt_base_case::value_masle_lower};

  maslt_base_case::Index maslt_base_case::fromValue ( Value value )
  {
    switch ( value )
    {
      case value_masle_upper: return index_masle_upper;
      case value_masle_lower: return index_masle_lower;
      default:                throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    }

  }

  maslt_base_case::maslt_base_case ( int32_t value )
    : index(fromValue( Value( value ) ))
  {
  }

  maslt_base_case& maslt_base_case::operator++ ( )
  {
    if ( index == index_masle_lower ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index + 1 );
    return *this;
  }

  maslt_base_case& maslt_base_case::operator-- ( )
  {
    if ( index == index_masle_upper ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index - 1 );
    return *this;
  }

  ::std::ostream& operator<< ( ::std::ostream&        stream,
                               const maslt_base_case& obj )
  {
    return stream << obj.getText();
  }

  ::std::istream& operator>> ( ::std::istream&  stream,
                               maslt_base_case& obj )
  {
    ::std::string text;
    stream >> text;
    obj = maslt_base_case( text );
    return stream;
  }

  maslt_rounding::maslt_rounding ( )
    : index(index_masle_towards_zero)
  {
  }

  maslt_rounding::maslt_rounding ( Index index )
    : index(index)
  {
  }

  const maslt_rounding maslt_rounding::masle_towards_zero = maslt_rounding( maslt_rounding::index_masle_towards_zero );

  const maslt_rounding maslt_rounding::masle_towards_nearest = maslt_rounding( maslt_rounding::index_masle_towards_nearest );

  maslt_rounding::maslt_rounding ( const ::std::string& text )
    : index(fromText( text ))
  {
  }

  const char* const maslt_rounding::textLookup[] = { "towards_zero",
     "towards_nearest"};

  maslt_rounding::TextLookupTable maslt_rounding::getLookupTable ( )
  {
    TextLookupTable lookup;
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_towards_zero], index_masle_towards_zero ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_towards_nearest], index_masle_towards_nearest ) );
    return lookup;
  }

  maslt_rounding::Index maslt_rounding::fromText ( const ::std::string& text )
  {
    static TextLookupTable lookup = getLookupTable();
    TextLookupTable::const_iterator pos = lookup.find( text );
    if ( pos == lookup.end() ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    return pos->second;
  }

  maslt_rounding::maslt_rounding ( Value value )
    : index(fromValue( value ))
  {
  }

  maslt_rounding::Value maslt_rounding::valueLookup[] = { maslt_rounding::value_masle_towards_zero,
     maslt_rounding::value_masle_towards_nearest};

  maslt_rounding::Index maslt_rounding::fromValue ( Value value )
  {
    switch ( value )
    {
      case value_masle_towards_zero:    return index_masle_towards_zero;
      case value_masle_towards_nearest: return index_masle_towards_nearest;
      default:                          throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    }

  }

  maslt_rounding::maslt_rounding ( int32_t value )
    : index(fromValue( Value( value ) ))
  {
  }

  maslt_rounding& maslt_rounding::operator++ ( )
  {
    if ( index == index_masle_towards_nearest ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index + 1 );
    return *this;
  }

  maslt_rounding& maslt_rounding::operator-- ( )
  {
    if ( index == index_masle_towards_zero ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index - 1 );
    return *this;
  }

  ::std::ostream& operator<< ( ::std::ostream&       stream,
                               const maslt_rounding& obj )
  {
    return stream << obj.getText();
  }

  ::std::istream& operator>> ( ::std::istream& stream,
                               maslt_rounding& obj )
  {
    ::std::string text;
    stream >> text;
    obj = maslt_rounding( text );
    return stream;
  }

  maslt_duration_field::maslt_duration_field ( )
    : index(index_masle_weeks)
  {
  }

  maslt_duration_field::maslt_duration_field ( Index index )
    : index(index)
  {
  }

  const maslt_duration_field maslt_duration_field::masle_weeks = maslt_duration_field( maslt_duration_field::index_masle_weeks );

  const maslt_duration_field maslt_duration_field::masle_days = maslt_duration_field( maslt_duration_field::index_masle_days );

  const maslt_duration_field maslt_duration_field::masle_hours = maslt_duration_field( maslt_duration_field::index_masle_hours );

  const maslt_duration_field maslt_duration_field::masle_minutes = maslt_duration_field( maslt_duration_field::index_masle_minutes );

  const maslt_duration_field maslt_duration_field::masle_seconds = maslt_duration_field( maslt_duration_field::index_masle_seconds );

  maslt_duration_field::maslt_duration_field ( const ::std::string& text )
    : index(fromText( text ))
  {
  }

  const char* const maslt_duration_field::textLookup[] = { "weeks",
     "days",
     "hours",
     "minutes",
     "seconds"};

  maslt_duration_field::TextLookupTable maslt_duration_field::getLookupTable ( )
  {
    TextLookupTable lookup;
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_weeks], index_masle_weeks ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_days], index_masle_days ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_hours], index_masle_hours ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_minutes], index_masle_minutes ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_seconds], index_masle_seconds ) );
    return lookup;
  }

  maslt_duration_field::Index maslt_duration_field::fromText ( const ::std::string& text )
  {
    static TextLookupTable lookup = getLookupTable();
    TextLookupTable::const_iterator pos = lookup.find( text );
    if ( pos == lookup.end() ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    return pos->second;
  }

  maslt_duration_field::maslt_duration_field ( Value value )
    : index(fromValue( value ))
  {
  }

  maslt_duration_field::Value maslt_duration_field::valueLookup[] = { maslt_duration_field::value_masle_weeks,
     maslt_duration_field::value_masle_days,
     maslt_duration_field::value_masle_hours,
     maslt_duration_field::value_masle_minutes,
     maslt_duration_field::value_masle_seconds};

  maslt_duration_field::Index maslt_duration_field::fromValue ( Value value )
  {
    switch ( value )
    {
      case value_masle_weeks:   return index_masle_weeks;
      case value_masle_days:    return index_masle_days;
      case value_masle_hours:   return index_masle_hours;
      case value_masle_minutes: return index_masle_minutes;
      case value_masle_seconds: return index_masle_seconds;
      default:                  throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    }

  }

  maslt_duration_field::maslt_duration_field ( int32_t value )
    : index(fromValue( Value( value ) ))
  {
  }

  maslt_duration_field& maslt_duration_field::operator++ ( )
  {
    if ( index == index_masle_seconds ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index + 1 );
    return *this;
  }

  maslt_duration_field& maslt_duration_field::operator-- ( )
  {
    if ( index == index_masle_weeks ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index - 1 );
    return *this;
  }

  ::std::ostream& operator<< ( ::std::ostream&             stream,
                               const maslt_duration_field& obj )
  {
    return stream << obj.getText();
  }

  ::std::istream& operator>> ( ::std::istream&       stream,
                               maslt_duration_field& obj )
  {
    ::std::string text;
    stream >> text;
    obj = maslt_duration_field( text );
    return stream;
  }

  maslt_timestamp_field::maslt_timestamp_field ( )
    : index(index_masle_year)
  {
  }

  maslt_timestamp_field::maslt_timestamp_field ( Index index )
    : index(index)
  {
  }

  const maslt_timestamp_field maslt_timestamp_field::masle_year = maslt_timestamp_field( maslt_timestamp_field::index_masle_year );

  const maslt_timestamp_field maslt_timestamp_field::masle_month = maslt_timestamp_field( maslt_timestamp_field::index_masle_month );

  const maslt_timestamp_field maslt_timestamp_field::masle_week = maslt_timestamp_field( maslt_timestamp_field::index_masle_week );

  const maslt_timestamp_field maslt_timestamp_field::masle_day = maslt_timestamp_field( maslt_timestamp_field::index_masle_day );

  const maslt_timestamp_field maslt_timestamp_field::masle_hour = maslt_timestamp_field( maslt_timestamp_field::index_masle_hour );

  const maslt_timestamp_field maslt_timestamp_field::masle_minute = maslt_timestamp_field( maslt_timestamp_field::index_masle_minute );

  const maslt_timestamp_field maslt_timestamp_field::masle_second = maslt_timestamp_field( maslt_timestamp_field::index_masle_second );

  maslt_timestamp_field::maslt_timestamp_field ( const ::std::string& text )
    : index(fromText( text ))
  {
  }

  const char* const maslt_timestamp_field::textLookup[] = { "year",
     "month",
     "week",
     "day",
     "hour",
     "minute",
     "second"};

  maslt_timestamp_field::TextLookupTable maslt_timestamp_field::getLookupTable ( )
  {
    TextLookupTable lookup;
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_year], index_masle_year ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_month], index_masle_month ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_week], index_masle_week ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_day], index_masle_day ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_hour], index_masle_hour ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_minute], index_masle_minute ) );
    lookup.insert( TextLookupTable::value_type( textLookup[index_masle_second], index_masle_second ) );
    return lookup;
  }

  maslt_timestamp_field::Index maslt_timestamp_field::fromText ( const ::std::string& text )
  {
    static TextLookupTable lookup = getLookupTable();
    TextLookupTable::const_iterator pos = lookup.find( text );
    if ( pos == lookup.end() ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    return pos->second;
  }

  maslt_timestamp_field::maslt_timestamp_field ( Value value )
    : index(fromValue( value ))
  {
  }

  maslt_timestamp_field::Value maslt_timestamp_field::valueLookup[] = { maslt_timestamp_field::value_masle_year,
     maslt_timestamp_field::value_masle_month,
     maslt_timestamp_field::value_masle_week,
     maslt_timestamp_field::value_masle_day,
     maslt_timestamp_field::value_masle_hour,
     maslt_timestamp_field::value_masle_minute,
     maslt_timestamp_field::value_masle_second};

  maslt_timestamp_field::Index maslt_timestamp_field::fromValue ( Value value )
  {
    switch ( value )
    {
      case value_masle_year:   return index_masle_year;
      case value_masle_month:  return index_masle_month;
      case value_masle_week:   return index_masle_week;
      case value_masle_day:    return index_masle_day;
      case value_masle_hour:   return index_masle_hour;
      case value_masle_minute: return index_masle_minute;
      case value_masle_second: return index_masle_second;
      default:                 throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    }

  }

  maslt_timestamp_field::maslt_timestamp_field ( int32_t value )
    : index(fromValue( Value( value ) ))
  {
  }

  maslt_timestamp_field& maslt_timestamp_field::operator++ ( )
  {
    if ( index == index_masle_second ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index + 1 );
    return *this;
  }

  maslt_timestamp_field& maslt_timestamp_field::operator-- ( )
  {
    if ( index == index_masle_year ) throw ::SWA::ProgramError( "Enumerate out of RangeExpression" );
    index = Index( index - 1 );
    return *this;
  }

  ::std::ostream& operator<< ( ::std::ostream&              stream,
                               const maslt_timestamp_field& obj )
  {
    return stream << obj.getText();
  }

  ::std::istream& operator>> ( ::std::istream&        stream,
                               maslt_timestamp_field& obj )
  {
    ::std::string text;
    stream >> text;
    obj = maslt_timestamp_field( text );
    return stream;
  }

}
