//
// File: __GPS_Watch__Tracking__LOC__getDistance.cc
//
#include "Location_OOA/__Location_services.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "__GPS_Watch__Tracking__LOC__getDistance.hh"
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"

namespace maslp_GPS_Watch
{
  namespace masld_Tracking
  {
    namespace maslb_LOC
    {
      bool register_masls_getDistance = ::masld_Tracking::maslb_LOC::register_masls_getDistance( &masls_getDistance );

      void masls_getDistance ( double& maslp_result,
                               double  maslp_toLong,
                               double  maslp_toLat,
                               double  maslp_fromLong,
                               double  maslp_fromLat )
      {

        // declare ...
        // begin ...
        // end;
        {
          ::SWA::Stack::EnteringTerminatorService enteringActionMarker(::masld_Tracking::getDomain().getId(), ::masld_Tracking::terminatorId_maslb_LOC, ::masld_Tracking::maslb_LOC::serviceId_masls_getDistance);
          ::SWA::Stack::DeclareParameter pm_maslp_result(maslp_result);
          ::SWA::Stack::DeclareParameter pm_maslp_toLong(maslp_toLong);
          ::SWA::Stack::DeclareParameter pm_maslp_toLat(maslp_toLat);
          ::SWA::Stack::DeclareParameter pm_maslp_fromLong(maslp_fromLong);
          ::SWA::Stack::DeclareParameter pm_maslp_fromLat(maslp_fromLat);
          ::SWA::Stack::EnteredAction enteredActionMarker;
          ::SWA::Stack::ExecutingStatement statement(7);
          {

            // distance : real;
            double maslv_distance = 0;
            ::SWA::Stack::DeclareLocalVariable pm_maslv_distance(0, maslv_distance);

            // Location::getDistance(distance, toLong, toLat, fromLong, fromLat)
            {
              ::SWA::Stack::ExecutingStatement statement(8);
              ::masld_Location::interceptor_masls_getDistance::instance().callService()( maslv_distance, maslp_toLong, maslp_toLat, maslp_fromLong, maslp_fromLat );
            }

            // result := distance;
            {
              ::SWA::Stack::ExecutingStatement statement(9);
              maslp_result = maslv_distance;
            }
          }
        }
      }

    }
  }
}
