//
// File: __Tracking__WorkoutTimerConstants.hh
//
#ifndef _Tracking_Workout_Timer_Constants_hh
#define _Tracking_Workout_Timer_Constants_hh

#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_WorkoutTimerConstants;
  class maslo_WorkoutTimerConstants
  {

    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_WorkoutTimerConstants> createInstance ( int32_t masla_id,
                                                                            int32_t masla_timerPeriod );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_WorkoutTimerConstants> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_timerPeriod ( int32_t value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual int32_t get_masla_id ( ) const = 0;
      virtual int32_t get_masla_timerPeriod ( ) const = 0;


    // Object Services
    public:
      static void masls_initialize ( );


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_WorkoutTimerConstants> > findAll ( );
      static ::SWA::ObjectPtr<maslo_WorkoutTimerConstants> findOne ( );
      static ::SWA::ObjectPtr<maslo_WorkoutTimerConstants> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_WorkoutTimerConstants ( );
      virtual ~maslo_WorkoutTimerConstants ( );


    // Prevent copy
    private:
      maslo_WorkoutTimerConstants ( const maslo_WorkoutTimerConstants& rhs );
      maslo_WorkoutTimerConstants& operator= ( const maslo_WorkoutTimerConstants& rhs );


    // Id Enumerations
    public:
      enum StateIds {};
      enum EventIds {};
      enum ServiceIds {  serviceId_masls_initialize };


  };
  ::std::ostream& operator<< ( ::std::ostream&                    stream,
                               const maslo_WorkoutTimerConstants& obj );
}
#endif // _Tracking_Workout_Timer_Constants_hh
