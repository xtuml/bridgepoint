//
// File: Transient__Tracking__TrackLogPopulation.hh
//
#ifndef Transient_Tracking_Track_Log_Population_hh
#define Transient_Tracking_Track_Log_Population_hh

#include "__Tracking__TrackLog.hh"
#include "__Tracking__TrackLogPopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace transient
{
  namespace masld_Tracking
  {
    class maslo_TrackLogPopulation
      : public TransientPopulation< ::masld_Tracking::maslo_TrackLog,::masld_Tracking::maslo_TrackLogPopulation>
    {

      // Instance Creation
      private:
        maslo_TrackLogPopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> createInstance ( const ::SWA::Timestamp& masla_session_startTime );


      // Singleton Registration
      public:
        static maslo_TrackLogPopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple< ::SWA::Timestamp>,::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> > masla_session_startTime_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> instance );
      protected:
        bool exists_masla_session_startTime ( const ::SWA::Timestamp& masla_session_startTime ) const;


    };
  }
}
#endif // Transient_Tracking_Track_Log_Population_hh
