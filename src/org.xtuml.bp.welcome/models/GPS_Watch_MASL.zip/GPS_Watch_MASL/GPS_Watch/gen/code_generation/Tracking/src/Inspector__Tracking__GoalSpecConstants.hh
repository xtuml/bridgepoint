//
// File: Inspector__Tracking__GoalSpecConstants.hh
//
#ifndef Inspector_Tracking_Goal_Spec_Constants_hh
#define Inspector_Tracking_Goal_Spec_Constants_hh

#include "__Tracking__GoalSpecConstants.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_GoalSpecConstants
    {
      class maslo_GoalSpecConstantsHandler
        : public ObjectHandler< ::masld_Tracking::maslo_GoalSpecConstants>
      {

        // Constructors
        public:
          maslo_GoalSpecConstantsHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                                        channel,
                                       ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> instance,
                                       int                                                          relId ) const;


      };
    }
  }
}
#endif // Inspector_Tracking_Goal_Spec_Constants_hh
