//
// File: __GPS_Watch__Tracking__HR__registerListener.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor_services.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "__GPS_Watch__Tracking__HR__registerListener.hh"
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"

namespace maslp_GPS_Watch
{
  namespace masld_Tracking
  {
    namespace maslb_HR
    {
      bool register_masls_registerListener = ::masld_Tracking::maslb_HR::register_masls_registerListener( &masls_registerListener );

      void masls_registerListener ( )
      {

        // begin ...
        // end;
        {
          ::SWA::Stack::EnteringTerminatorService enteringActionMarker(::masld_Tracking::getDomain().getId(), ::masld_Tracking::terminatorId_maslb_HR, ::masld_Tracking::maslb_HR::serviceId_masls_registerListener);
          ::SWA::Stack::EnteredAction enteredActionMarker;
          ::SWA::Stack::ExecutingStatement statement(2);
          {

            // HeartRateMonitor::registerListener()
            {
              ::SWA::Stack::ExecutingStatement statement(3);
              ::masld_HeartRateMonitor::interceptor_masls_registerListener::instance().callService()();
            }
          }
        }
      }

    }
  }
}
