//
// File: Inspector__Tracking__Display.hh
//
#ifndef Inspector_Tracking_Display_hh
#define Inspector_Tracking_Display_hh

#include "__Tracking__Display.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_Display
    {
      class maslo_DisplayHandler
        : public ObjectHandler< ::masld_Tracking::maslo_Display>
      {

        // Constructors
        public:
          maslo_DisplayHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                              channel,
                                       ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> instance,
                                       int                                                relId ) const;


      };
    }
  }
}
#endif // Inspector_Tracking_Display_hh
