//
// File: __HeartRateMonitor__HeartRateMonitorEvents.hh
//
#ifndef _Heart_Rate_Monitor_Heart_Rate_Monitor_Events_hh
#define _Heart_Rate_Monitor_Heart_Rate_Monitor_Events_hh

#include "swa/Event.hh"

namespace masld_HeartRateMonitor
{
  class Event_maslo_HeartRateMonitor_maslev_timeout
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_HeartRateMonitor_maslev_timeout ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_HeartRateMonitor_maslev_registerComplete
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_HeartRateMonitor_maslev_registerComplete ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_HeartRateMonitor_maslev_unregisterComplete
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_HeartRateMonitor_maslev_unregisterComplete ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_HeartRateMonitor_maslev_registerListener
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_HeartRateMonitor_maslev_registerListener ( );
      virtual void invoke ( ) const;


  };
  class Event_maslo_HeartRateMonitor_maslev_unregisterListener
    : public ::SWA::Event
  {

    // Get Id Overrides
    public:
      virtual int getDomainId ( ) const;
      virtual int getObjectId ( ) const;
      virtual int getEventId ( ) const;


    public:
      Event_maslo_HeartRateMonitor_maslev_unregisterListener ( );
      virtual void invoke ( ) const;


  };
}
#endif // _Heart_Rate_Monitor_Heart_Rate_Monitor_Events_hh
