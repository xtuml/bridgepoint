//
// File: Transient__Location__simulatedGPS.cc
//
#include "Transient__Location__simulatedGPS.hh"
#include <stdint.h>

namespace transient
{
  namespace masld_Location
  {
    maslo_simulatedGPS::maslo_simulatedGPS ( int32_t masla_id,
                                             double  masla_initialLatitude,
                                             double  masla_initialLongitude,
                                             double  masla_latitudeIncrement,
                                             double  masla_longitudeIncrement,
                                             int32_t masla_updatePeriod )
      : architectureId(getNextArchId()),
        masla_id(masla_id),
        masla_initialLatitude(masla_initialLatitude),
        masla_initialLongitude(masla_initialLongitude),
        masla_latitudeIncrement(masla_latitudeIncrement),
        masla_longitudeIncrement(masla_longitudeIncrement),
        masla_updatePeriod(masla_updatePeriod)
    {
    }

  }
}
