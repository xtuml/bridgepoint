//
// File: Sqlite__UI__UI.hh
//
#ifndef Sqlite_UI_UI_hh
#define Sqlite_UI_UI_hh

#include "__UI__UI.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_UI
  {
    class maslo_UI
      : public ::masld_UI::maslo_UI
    {

      // Type definitions
      public:
        typedef ::boost::tuple<int32_t> PrimaryKeyType;
        typedef ::boost::tuple<int32_t> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_UI ( ::SWA::IdType architectureId );
        maslo_UI ( ::SWA::IdType                          architectureId,
                   int32_t                                masla_id,
                   int32_t                                masla_socket_id,
                   const ::SWA::EventTimers::TimerIdType& masla_timer,
                   ::masld_UI::maslo_UI::Type             currentState );


      // Setters for each object attribute
      public:
        void set_masla_id ( int32_t value )
        {
          this->masla_id = value;
          markAsModified();
        }
        virtual void set_masla_socket_id ( int32_t value )
        {
          this->masla_socket_id = value;
          markAsModified();
        }
        virtual void set_masla_timer ( const ::SWA::EventTimers::TimerIdType& value )
        {
          this->masla_timer = value;
          markAsModified();
        }
        virtual void setCurrentState ( ::masld_UI::maslo_UI::Type newState )
        {
          currentState = newState;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual int32_t get_masla_socket_id ( ) const { return masla_socket_id; }
        virtual ::SWA::EventTimers::TimerIdType get_masla_timer ( ) const { return masla_timer; }
        virtual ::masld_UI::maslo_UI::Type getCurrentState ( ) const { return currentState; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_id;
        int32_t masla_socket_id;
        ::SWA::EventTimers::TimerIdType masla_timer;
        ::masld_UI::maslo_UI::Type currentState;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_UI_UI_hh
