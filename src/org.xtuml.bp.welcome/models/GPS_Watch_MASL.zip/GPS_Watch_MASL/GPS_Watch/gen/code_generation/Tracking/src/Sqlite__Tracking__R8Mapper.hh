//
// File: Sqlite__Tracking__R8Mapper.hh
//
#ifndef Sqlite_Tracking_R_8_Mapper_hh
#define Sqlite_Tracking_R_8_Mapper_hh

#include "Sqlite__Tracking__WorkoutSession.hh"
#include "Sqlite__Tracking__WorkoutTimer.hh"
#include "sql/RelationshipBinaryDefinitions.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    typedef ::SQL::OneToOneRelationship<8,maslo_WorkoutSession,maslo_WorkoutTimer,false,false>::mapper_type RelationshipR8Mapper;
  }
}
#endif // Sqlite_Tracking_R_8_Mapper_hh
