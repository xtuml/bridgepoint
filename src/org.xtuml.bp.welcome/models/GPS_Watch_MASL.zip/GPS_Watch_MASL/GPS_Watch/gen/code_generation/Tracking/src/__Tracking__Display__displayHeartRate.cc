//
// File: __Tracking__Display__displayHeartRate.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/bind.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/navigate.hh"

namespace masld_Tracking
{
  void maslo_Display::state_maslst_displayHeartRate ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_Display, stateId_maslst_displayHeartRate);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(4);
      {

        // session : instance of WorkoutSession;
        ::SWA::ObjectPtr<maslo_WorkoutSession> maslv_session;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_session(0, maslv_session);

        // heartRate : integer;
        int32_t maslv_heartRate = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_heartRate(1, maslv_heartRate);

        // session := this -> R7.indicates_current_status_of.WorkoutSession;
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          maslv_session = ::SWA::navigate_one<maslo_WorkoutSession>( ::SWA::ObjectPtr<maslo_Display>( this ), ::boost::bind( &maslo_Display::navigate_R7_indicates_current_status_of_WorkoutSession, _1 ) );
        }

        // heartRate := session.getCurrentHeartRate();
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          maslv_heartRate = maslv_session->masls_getCurrentHeartRate();
        }

        // UI~>setData(real(heartRate), Tracking::Unit.bpm)
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          maslb_UI::masls_setData( static_cast<double>( maslv_heartRate ), maslt_Unit::masle_bpm );
        }

        // UI~>setIndicator(Display.goalDispositionIndicator())
        {
          ::SWA::Stack::ExecutingStatement statement(8);
          maslb_UI::masls_setIndicator( masls_goalDispositionIndicator() );
        }
      }
    }
  }

}
