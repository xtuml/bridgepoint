//
// File: Sqlite__Location__DistancePopulation.hh
//
#ifndef Sqlite_Location_Distance_Population_hh
#define Sqlite_Location_Distance_Population_hh

#include "Sqlite__Location__Distance.hh"
#include "Sqlite__Location__DistanceMapper.hh"
#include "__Location__Distance.hh"
#include "__Location__DistancePopulation.hh"
#include "boost/signals2.hpp"
#include "sql/Population.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Location
  {
    class maslo_DistancePopulation
      : public ::SQL::SqlPopulation< ::masld_Location::maslo_Distance,maslo_Distance,maslo_DistanceMapper,::masld_Location::maslo_DistancePopulation>
    {

      // Constructors and Destructors
      private:
        maslo_DistancePopulation ( );
        ~maslo_DistancePopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> createInstance ( int32_t masla_id,
                                                                                     double  masla_kmPerDegree );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> instance );


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Location::maslo_Distance> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Singleton Registration
      public:
        static maslo_DistancePopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;


    };
  }
}
#endif // Sqlite_Location_Distance_Population_hh
