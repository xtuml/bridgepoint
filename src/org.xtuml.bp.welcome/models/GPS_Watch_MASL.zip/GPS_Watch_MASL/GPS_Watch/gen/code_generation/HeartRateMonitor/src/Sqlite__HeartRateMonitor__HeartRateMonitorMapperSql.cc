//
// File: Sqlite__HeartRateMonitor__HeartRateMonitorMapperSql.cc
//
#include "Sqlite__HeartRateMonitor__HeartRateMonitor.hh"
#include "Sqlite__HeartRateMonitor__HeartRateMonitorMapperSql.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "boost/shared_ptr.hpp"
#include "boost/tuple/tuple_comparison.hpp"
#include <map>
#include "sql/Criteria.hh"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/Schema.hh"
#include "sql/Util.hh"
#include "sqlite/Database.hh"
#include "sqlite/Exception.hh"
#include "sqlite/Resultset.hh"
#include "sqlite/SqlMonitor.hh"
#include "sqlite3.h"
#include <stdint.h>
#include <string>
#include "swa/EventTimers.hh"
#include "swa/types.hh"

namespace 
{
  const ::std::string createTableStatment ( )
  {
    return "CREATE TABLE S_HeartRateMonitor_HEARTRATEMONITOR(   architecture_id  INTEGER ,   masla_recentHeartRate INTEGER,   masla_timer INTEGER,   masla_id INTEGER,   CurrentState INTEGER, PRIMARY KEY (architecture_id));\n";
  }

  bool registerSchema = ::SQL::Schema::singleton().registerTable( "S_HeartRateMonitor_HEARTRATEMONITOR", createTableStatment() );

}
namespace SQLITE
{
  namespace masld_HeartRateMonitor
  {
    maslo_HeartRateMonitorSqlGenerator::maslo_HeartRateMonitorSqlGenerator ( )
      : tableName("S_HeartRateMonitor_HEARTRATEMONITOR"),
        objectName("HeartRateMonitor"),
        insertStatement("INSERT INTO S_HeartRateMonitor_HEARTRATEMONITOR VALUES(:1,:2,:3,:4,:5);"),
        updateStatement("UPDATE S_HeartRateMonitor_HEARTRATEMONITOR SET masla_recentHeartRate = :2  , masla_timer = :3  , masla_id = :4  , CurrentState = :5  WHERE architecture_id = :1;"),
        deleteStatement("DELETE  FROM S_HeartRateMonitor_HEARTRATEMONITOR WHERE architecture_id = :1;"),
        columnNameMapper()
    {
    }

    maslo_HeartRateMonitorSqlGenerator::~maslo_HeartRateMonitorSqlGenerator ( )
    {
    }

    void maslo_HeartRateMonitorSqlGenerator::initialise ( )
    {
      columnNameMapper["architecture_id"] = ::std::string( "architecture_id" );
      columnNameMapper["recentHeartRate"] = ::std::string( "masla_recentHeartRate" );
      columnNameMapper["timer"] = ::std::string( "masla_timer" );
      columnNameMapper["id"] = ::std::string( "masla_id" );
      columnNameMapper["CurrentState"] = ::std::string( "CurrentState" );
      insertStatement.prepare();
      updateStatement.prepare();
      deleteStatement.prepare();
    }

    const ::std::string maslo_HeartRateMonitorSqlGenerator::getDomainName ( ) const
    {
      return "HeartRateMonitor";
    }

    const ::std::string& maslo_HeartRateMonitorSqlGenerator::getTableName ( ) const
    {
      return tableName;
    }

    const ::std::string& maslo_HeartRateMonitorSqlGenerator::getObjectName ( ) const
    {
      return objectName;
    }

    const ::std::string maslo_HeartRateMonitorSqlGenerator::getColumnName ( const ::std::string& attribute ) const
    {
      ::std::map< ::std::string,::std::string>::const_iterator requiredNameItr = columnNameMapper.find( attribute );
      if ( requiredNameItr == columnNameMapper.end() )
      {
        throw SqliteException( "maslo_HeartRateMonitorSqlGenerator::getColumnName - failed to find attribute name " );
      }
      return requiredNameItr->second;
    }

    void maslo_HeartRateMonitorSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                        int32_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_HeartRateMonitor_HEARTRATEMONITOR;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_HeartRateMonitorSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_HeartRateMonitorSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    void maslo_HeartRateMonitorSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                        int64_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_HeartRateMonitor_HEARTRATEMONITOR;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_HeartRateMonitorSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int64_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_HeartRateMonitorSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    ::SWA::IdType maslo_HeartRateMonitorSqlGenerator::executeGetRowCount ( ) const
    {
      int32_t rowCount = 0;
      ::std::string valueSelect("SELECT count(*) FROM S_HeartRateMonitor_HEARTRATEMONITOR;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_HeartRateMonitorSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          rowCount = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_HeartRateMonitorSqlGenerator::executeGetRowCount - query failed" );
      }
      return rowCount;
    }

    ::SWA::IdType maslo_HeartRateMonitorSqlGenerator::executeGetMaxIdentifier ( ) const
    {
      ::SWA::IdType maxIdValue = 0;
      executeGetMaxColumnValue( "architecture_id", maxIdValue );
      return maxIdValue;
    }

    void maslo_HeartRateMonitorSqlGenerator::executeUpdate ( const PsObjectPtr& object ) const
    {
      updateStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_recentHeartRate(), object.getChecked()->get_masla_timer(), object.getChecked()->get_masla_id(), object->getCurrentState() ) );
    }

    void maslo_HeartRateMonitorSqlGenerator::executeInsert ( const PsObjectPtr& object ) const
    {
      insertStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_recentHeartRate(), object.getChecked()->get_masla_timer(), object.getChecked()->get_masla_id(), object->getCurrentState() ) );
    }

    void maslo_HeartRateMonitorSqlGenerator::executeRemove ( const PsObjectPtr& object ) const
    {
      deleteStatement.execute( object.getChecked()->getArchitectureId() );
    }

    void maslo_HeartRateMonitorSqlGenerator::executeRemoveId ( const ::SWA::IdType object ) const
    {
      deleteStatement.execute( object );
    }

    void maslo_HeartRateMonitorSqlGenerator::executeSelect ( CacheType&             cache,
                                                             const ::SQL::Criteria& criteria,
                                                             PsBaseObjectPtrSwaSet& result ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("HeartRateMonitor::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "HeartRateMonitor::executeSelect", compile_result, query );
        database.checkColumnCount( "HeartRateMonitor::executeSelect", sqlite3_column_count( ppStmt ), 5, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr != cache.end() )
          {
            PsBaseObjectPtr currentObject(objectItr->second.get());
            result += currentObject;
          }
          else
          {
            PsObjectPtr currentObject(new maslo_HeartRateMonitor(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );
            result += currentObject;

            int32_t recentHeartRate = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_recentHeartRate( recentHeartRate );

            int32_t timer = sqlite3_column_int( ppStmt, 2 );
            currentObject->set_masla_timer( timer );

            int32_t id = sqlite3_column_int( ppStmt, 3 );
            currentObject->set_masla_id( id );

            int32_t currentState = sqlite3_column_int( ppStmt, 4 );
            currentObject->setCurrentState( static_cast< ::masld_HeartRateMonitor::maslo_HeartRateMonitor::Type>( currentState ) );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

    void maslo_HeartRateMonitorSqlGenerator::executeSelect ( CacheType&             cache,
                                                             const ::SQL::Criteria& criteria ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("HeartRateMonitor::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "HeartRateMonitor::executeSelect", compile_result, query );
        database.checkColumnCount( "HeartRateMonitor::executeSelect", sqlite3_column_count( ppStmt ), 5, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr == cache.end() )
          {
            PsObjectPtr currentObject(new maslo_HeartRateMonitor(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );

            int32_t recentHeartRate = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_recentHeartRate( recentHeartRate );

            int32_t timer = sqlite3_column_int( ppStmt, 2 );
            currentObject->set_masla_timer( timer );

            int32_t id = sqlite3_column_int( ppStmt, 3 );
            currentObject->set_masla_id( id );

            int32_t currentState = sqlite3_column_int( ppStmt, 4 );
            currentObject->setCurrentState( static_cast< ::masld_HeartRateMonitor::maslo_HeartRateMonitor::Type>( currentState ) );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

  }
}
