//
// File: __UI__setData.cc
//
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_services.hh"
#include "UI_OOA/__UI_types.hh"
#include "__UI__UI.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_UI
{
  void masls_setData ( double              maslp_value,
                       const maslt_UIUnit& maslp_unit )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_setData);
      ::SWA::Stack::DeclareParameter pm_maslp_value(maslp_value);
      ::SWA::Stack::DeclareParameter pm_maslp_unit(maslp_unit);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(4);
      {

        // ui : instance of UI;
        ::SWA::ObjectPtr<maslo_UI> maslv_ui;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_ui(0, maslv_ui);

        // ui := find_one UI ();
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          maslv_ui = maslo_UI::findOne();
        }

        // if (null /= ui) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          if ( ::SWA::Null != maslv_ui )
          {

            // if (unit = UI::UIUnit.km) then ...
            // elsif (unit = UI::UIUnit.meters) then ...
            // elsif (unit = UI::UIUnit.minPerKm) then ...
            // elsif (unit = UI::UIUnit.kmPerHour) then ...
            // elsif (unit = UI::UIUnit.miles) then ...
            // elsif (unit = UI::UIUnit.yards) then ...
            // elsif (unit = UI::UIUnit.feet) then ...
            // elsif (unit = UI::UIUnit.minPerMile) then ...
            // elsif (unit = UI::UIUnit.mph) then ...
            // elsif (unit = UI::UIUnit.bpm) then ...
            // elsif (unit = UI::UIUnit.laps) then ...
            {
              ::SWA::Stack::ExecutingStatement statement(7);
              if ( maslp_unit == maslt_UIUnit::masle_km )
              {

                // ui.setData(value, 0)
                {
                  ::SWA::Stack::ExecutingStatement statement(8);
                  maslv_ui->masls_setData( maslp_value, 0ll );
                }
              }
              else if ( maslp_unit == maslt_UIUnit::masle_meters )
              {

                // ui.setData(value, 1)
                {
                  ::SWA::Stack::ExecutingStatement statement(10);
                  maslv_ui->masls_setData( maslp_value, 1ll );
                }
              }
              else if ( maslp_unit == maslt_UIUnit::masle_minPerKm )
              {

                // ui.setData(value, 2)
                {
                  ::SWA::Stack::ExecutingStatement statement(12);
                  maslv_ui->masls_setData( maslp_value, 2ll );
                }
              }
              else if ( maslp_unit == maslt_UIUnit::masle_kmPerHour )
              {

                // ui.setData(value, 3)
                {
                  ::SWA::Stack::ExecutingStatement statement(14);
                  maslv_ui->masls_setData( maslp_value, 3ll );
                }
              }
              else if ( maslp_unit == maslt_UIUnit::masle_miles )
              {

                // ui.setData(value, 4)
                {
                  ::SWA::Stack::ExecutingStatement statement(16);
                  maslv_ui->masls_setData( maslp_value, 4ll );
                }
              }
              else if ( maslp_unit == maslt_UIUnit::masle_yards )
              {

                // ui.setData(value, 5)
                {
                  ::SWA::Stack::ExecutingStatement statement(18);
                  maslv_ui->masls_setData( maslp_value, 5ll );
                }
              }
              else if ( maslp_unit == maslt_UIUnit::masle_feet )
              {

                // ui.setData(value, 6)
                {
                  ::SWA::Stack::ExecutingStatement statement(20);
                  maslv_ui->masls_setData( maslp_value, 6ll );
                }
              }
              else if ( maslp_unit == maslt_UIUnit::masle_minPerMile )
              {

                // ui.setData(value, 7)
                {
                  ::SWA::Stack::ExecutingStatement statement(22);
                  maslv_ui->masls_setData( maslp_value, 7ll );
                }
              }
              else if ( maslp_unit == maslt_UIUnit::masle_mph )
              {

                // ui.setData(value, 8)
                {
                  ::SWA::Stack::ExecutingStatement statement(24);
                  maslv_ui->masls_setData( maslp_value, 8ll );
                }
              }
              else if ( maslp_unit == maslt_UIUnit::masle_bpm )
              {

                // ui.setData(value, 9)
                {
                  ::SWA::Stack::ExecutingStatement statement(26);
                  maslv_ui->masls_setData( maslp_value, 9ll );
                }
              }
              else if ( maslp_unit == maslt_UIUnit::masle_laps )
              {

                // ui.setData(value, 10)
                {
                  ::SWA::Stack::ExecutingStatement statement(28);
                  maslv_ui->masls_setData( maslp_value, 10ll );
                }
              }
            }
          }
        }
      }
    }
  }

  const bool localServiceRegistration_masls_setData = interceptor_masls_setData::instance().registerLocal( &masls_setData );

}
