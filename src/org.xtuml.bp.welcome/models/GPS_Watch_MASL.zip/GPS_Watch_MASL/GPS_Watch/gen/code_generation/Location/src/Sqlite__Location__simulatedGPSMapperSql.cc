//
// File: Sqlite__Location__simulatedGPSMapperSql.cc
//
#include "Sqlite__Location__simulatedGPS.hh"
#include "Sqlite__Location__simulatedGPSMapperSql.hh"
#include "__Location__simulatedGPS.hh"
#include "boost/shared_ptr.hpp"
#include "boost/tuple/tuple_comparison.hpp"
#include <map>
#include "sql/Criteria.hh"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/Schema.hh"
#include "sql/Util.hh"
#include "sqlite/Database.hh"
#include "sqlite/Exception.hh"
#include "sqlite/Resultset.hh"
#include "sqlite/SqlMonitor.hh"
#include "sqlite3.h"
#include <stdint.h>
#include <string>
#include "swa/types.hh"

namespace 
{
  const ::std::string createTableStatment ( )
  {
    return "CREATE TABLE S_Location_SIMULATEDGPS(   architecture_id  INTEGER ,   masla_id INTEGER,   masla_initialLatitude REAL,   masla_initialLongitude REAL,   masla_latitudeIncrement REAL,   masla_longitudeIncrement REAL,   masla_updatePeriod INTEGER, PRIMARY KEY (architecture_id));\n";
  }

  bool registerSchema = ::SQL::Schema::singleton().registerTable( "S_Location_SIMULATEDGPS", createTableStatment() );

}
namespace SQLITE
{
  namespace masld_Location
  {
    maslo_simulatedGPSSqlGenerator::maslo_simulatedGPSSqlGenerator ( )
      : tableName("S_Location_SIMULATEDGPS"),
        objectName("simulatedGPS"),
        insertStatement("INSERT INTO S_Location_SIMULATEDGPS VALUES(:1,:2,:3,:4,:5,:6,:7);"),
        updateStatement("UPDATE S_Location_SIMULATEDGPS SET masla_id = :2  , masla_initialLatitude = :3  , masla_initialLongitude = :4  , masla_latitudeIncrement = :5  , masla_longitudeIncrement = :6  , masla_updatePeriod = :7  WHERE architecture_id = :1;"),
        deleteStatement("DELETE  FROM S_Location_SIMULATEDGPS WHERE architecture_id = :1;"),
        columnNameMapper()
    {
    }

    maslo_simulatedGPSSqlGenerator::~maslo_simulatedGPSSqlGenerator ( )
    {
    }

    void maslo_simulatedGPSSqlGenerator::initialise ( )
    {
      columnNameMapper["architecture_id"] = ::std::string( "architecture_id" );
      columnNameMapper["id"] = ::std::string( "masla_id" );
      columnNameMapper["initialLatitude"] = ::std::string( "masla_initialLatitude" );
      columnNameMapper["initialLongitude"] = ::std::string( "masla_initialLongitude" );
      columnNameMapper["latitudeIncrement"] = ::std::string( "masla_latitudeIncrement" );
      columnNameMapper["longitudeIncrement"] = ::std::string( "masla_longitudeIncrement" );
      columnNameMapper["updatePeriod"] = ::std::string( "masla_updatePeriod" );
      insertStatement.prepare();
      updateStatement.prepare();
      deleteStatement.prepare();
    }

    const ::std::string maslo_simulatedGPSSqlGenerator::getDomainName ( ) const
    {
      return "Location";
    }

    const ::std::string& maslo_simulatedGPSSqlGenerator::getTableName ( ) const
    {
      return tableName;
    }

    const ::std::string& maslo_simulatedGPSSqlGenerator::getObjectName ( ) const
    {
      return objectName;
    }

    const ::std::string maslo_simulatedGPSSqlGenerator::getColumnName ( const ::std::string& attribute ) const
    {
      ::std::map< ::std::string,::std::string>::const_iterator requiredNameItr = columnNameMapper.find( attribute );
      if ( requiredNameItr == columnNameMapper.end() )
      {
        throw SqliteException( "maslo_simulatedGPSSqlGenerator::getColumnName - failed to find attribute name " );
      }
      return requiredNameItr->second;
    }

    void maslo_simulatedGPSSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                    int32_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_Location_SIMULATEDGPS;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_simulatedGPSSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_simulatedGPSSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    void maslo_simulatedGPSSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                    int64_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_Location_SIMULATEDGPS;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_simulatedGPSSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int64_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_simulatedGPSSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    ::SWA::IdType maslo_simulatedGPSSqlGenerator::executeGetRowCount ( ) const
    {
      int32_t rowCount = 0;
      ::std::string valueSelect("SELECT count(*) FROM S_Location_SIMULATEDGPS;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_simulatedGPSSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          rowCount = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_simulatedGPSSqlGenerator::executeGetRowCount - query failed" );
      }
      return rowCount;
    }

    ::SWA::IdType maslo_simulatedGPSSqlGenerator::executeGetMaxIdentifier ( ) const
    {
      ::SWA::IdType maxIdValue = 0;
      executeGetMaxColumnValue( "architecture_id", maxIdValue );
      return maxIdValue;
    }

    void maslo_simulatedGPSSqlGenerator::executeUpdate ( const PsObjectPtr& object ) const
    {
      updateStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_id(), object.getChecked()->get_masla_initialLatitude(), object.getChecked()->get_masla_initialLongitude(), object.getChecked()->get_masla_latitudeIncrement(), object.getChecked()->get_masla_longitudeIncrement(), object.getChecked()->get_masla_updatePeriod() ) );
    }

    void maslo_simulatedGPSSqlGenerator::executeInsert ( const PsObjectPtr& object ) const
    {
      insertStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_id(), object.getChecked()->get_masla_initialLatitude(), object.getChecked()->get_masla_initialLongitude(), object.getChecked()->get_masla_latitudeIncrement(), object.getChecked()->get_masla_longitudeIncrement(), object.getChecked()->get_masla_updatePeriod() ) );
    }

    void maslo_simulatedGPSSqlGenerator::executeRemove ( const PsObjectPtr& object ) const
    {
      deleteStatement.execute( object.getChecked()->getArchitectureId() );
    }

    void maslo_simulatedGPSSqlGenerator::executeRemoveId ( const ::SWA::IdType object ) const
    {
      deleteStatement.execute( object );
    }

    void maslo_simulatedGPSSqlGenerator::executeSelect ( CacheType&             cache,
                                                         const ::SQL::Criteria& criteria,
                                                         PsBaseObjectPtrSwaSet& result ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("simulatedGPS::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "simulatedGPS::executeSelect", compile_result, query );
        database.checkColumnCount( "simulatedGPS::executeSelect", sqlite3_column_count( ppStmt ), 7, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr != cache.end() )
          {
            PsBaseObjectPtr currentObject(objectItr->second.get());
            result += currentObject;
          }
          else
          {
            PsObjectPtr currentObject(new maslo_simulatedGPS(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );
            result += currentObject;

            int32_t id = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_id( id );

            double initialLatitude = sqlite3_column_double( ppStmt, 2 );
            currentObject->set_masla_initialLatitude( initialLatitude );

            double initialLongitude = sqlite3_column_double( ppStmt, 3 );
            currentObject->set_masla_initialLongitude( initialLongitude );

            double latitudeIncrement = sqlite3_column_double( ppStmt, 4 );
            currentObject->set_masla_latitudeIncrement( latitudeIncrement );

            double longitudeIncrement = sqlite3_column_double( ppStmt, 5 );
            currentObject->set_masla_longitudeIncrement( longitudeIncrement );

            int32_t updatePeriod = sqlite3_column_int( ppStmt, 6 );
            currentObject->set_masla_updatePeriod( updatePeriod );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

    void maslo_simulatedGPSSqlGenerator::executeSelect ( CacheType&             cache,
                                                         const ::SQL::Criteria& criteria ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("simulatedGPS::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "simulatedGPS::executeSelect", compile_result, query );
        database.checkColumnCount( "simulatedGPS::executeSelect", sqlite3_column_count( ppStmt ), 7, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr == cache.end() )
          {
            PsObjectPtr currentObject(new maslo_simulatedGPS(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );

            int32_t id = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_id( id );

            double initialLatitude = sqlite3_column_double( ppStmt, 2 );
            currentObject->set_masla_initialLatitude( initialLatitude );

            double initialLongitude = sqlite3_column_double( ppStmt, 3 );
            currentObject->set_masla_initialLongitude( initialLongitude );

            double latitudeIncrement = sqlite3_column_double( ppStmt, 4 );
            currentObject->set_masla_latitudeIncrement( latitudeIncrement );

            double longitudeIncrement = sqlite3_column_double( ppStmt, 5 );
            currentObject->set_masla_longitudeIncrement( longitudeIncrement );

            int32_t updatePeriod = sqlite3_column_int( ppStmt, 6 );
            currentObject->set_masla_updatePeriod( updatePeriod );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

  }
}
