//
// File: Inspector__UI.cc
//
#include "Inspector__UI__TRACK.hh"
#include "Inspector__UI__TestCase.hh"
#include "Inspector__UI__UI.hh"
#include "Inspector__UI__UIConstants.hh"
#include "UI_OOA/__UI.hh"
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_services.hh"
#include "UI_OOA/__UI_types.hh"
#include "__UI__TestCase.hh"
#include "__UI__UI.hh"
#include "__UI_private_services.hh"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/GenericObjectHandler.hh"
#include "inspector/ProcessHandler.hh"
#include "inspector/TerminatorHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"

namespace Inspector
{
  namespace masld_UI
  {
    class masls_RunTestCaseHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_RunTestCaseInvoker
    {

      public:
        masls_RunTestCaseInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_UI::interceptor_masls_RunTestCase::instance().callService()(); }


    };
    class masls_createGoals_1Handler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_createGoals_1Invoker
    {

      public:
        masls_createGoals_1Invoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_UI::interceptor_masls_createGoals_1::instance().callService()(); }


    };
    class masls_initHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_initInvoker
    {

      public:
        masls_initInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_UI::interceptor_masls_init::instance().callService()(); }


    };
    class masls_setDataHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_setDataInvoker
    {

      public:
        masls_setDataInvoker ( CommunicationChannel& channel )
          : maslp_value(),
            maslp_unit()

        {
          channel >> maslp_value;
          channel >> maslp_unit;
        }
        void operator() ( ) { ::masld_UI::interceptor_masls_setData::instance().callService()( maslp_value, maslp_unit ); }


      private:
        double maslp_value;
        ::masld_UI::maslt_UIUnit maslp_unit;


    };
    class masls_setIndicatorHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_setIndicatorInvoker
    {

      public:
        masls_setIndicatorInvoker ( CommunicationChannel& channel )
          : maslp_indicator()
 { channel >> maslp_indicator; }
        void operator() ( ) { ::masld_UI::interceptor_masls_setIndicator::instance().callService()( maslp_indicator ); }


      private:
        ::masld_UI::maslt_UIIndicator maslp_indicator;


    };
    class masls_setTimeHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_setTimeInvoker
    {

      public:
        masls_setTimeInvoker ( CommunicationChannel& channel )
          : maslp_time()
 { channel >> maslp_time; }
        void operator() ( ) { ::masld_UI::interceptor_masls_setTime::instance().callService()( maslp_time ); }


      private:
        int32_t maslp_time;


    };
    class masls_startTestHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_startTestInvoker
    {

      public:
        masls_startTestInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_UI::interceptor_masls_startTest::instance().callService()(); }


    };
    class masls_sendLapResetPressedHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_sendLapResetPressedInvoker
    {

      public:
        masls_sendLapResetPressedInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_UI::interceptor_masls_sendLapResetPressed::instance().callService()(); }


    };
    class masls_sendLightPressedHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_sendLightPressedInvoker
    {

      public:
        masls_sendLightPressedInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_UI::interceptor_masls_sendLightPressed::instance().callService()(); }


    };
    class masls_sendModePressedHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_sendModePressedInvoker
    {

      public:
        masls_sendModePressedInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_UI::interceptor_masls_sendModePressed::instance().callService()(); }


    };
    class masls_sendStartStopPressedHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_sendStartStopPressedInvoker
    {

      public:
        masls_sendStartStopPressedInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_UI::interceptor_masls_sendStartStopPressed::instance().callService()(); }


    };
    class masls_sendTargetPressedHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_sendTargetPressedInvoker
    {

      public:
        masls_sendTargetPressedInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_UI::interceptor_masls_sendTargetPressed::instance().callService()(); }


    };
    class masld_UIHandler
      : public DomainHandler
    {

      public:
        masld_UIHandler ( );
        void createRelationship ( CommunicationChannel& channel,
                                  int                   relId );


    };
    Callable masls_RunTestCaseHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_RunTestCaseInvoker( channel );
    }

    void masls_RunTestCaseHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                    const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_createGoals_1Handler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_createGoals_1Invoker( channel );
    }

    void masls_createGoals_1Handler::writeLocalVars ( CommunicationChannel&    channel,
                                                      const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_initHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_initInvoker( channel );
    }

    void masls_initHandler::writeLocalVars ( CommunicationChannel&    channel,
                                             const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_setDataHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_setDataInvoker( channel );
    }

    void masls_setDataHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                const ::SWA::StackFrame& frame ) const
    {

      // Write value
      channel << frame.getParameters()[0].getValue<double>();

      // Write unit
      channel << frame.getParameters()[1].getValue< ::masld_UI::maslt_UIUnit>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
      for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
      {
        channel << frame.getLocalVars()[i].getId();
        switch ( frame.getLocalVars()[i].getId() )
        {
          case 0:

            // Write ui
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_UI::maslo_UI> >();
            break;

        }

      }
    }

    Callable masls_setIndicatorHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_setIndicatorInvoker( channel );
    }

    void masls_setIndicatorHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
    {

      // Write indicator
      channel << frame.getParameters()[0].getValue< ::masld_UI::maslt_UIIndicator>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
      for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
      {
        channel << frame.getLocalVars()[i].getId();
        switch ( frame.getLocalVars()[i].getId() )
        {
          case 0:

            // Write ui
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_UI::maslo_UI> >();
            break;

        }

      }
    }

    Callable masls_setTimeHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_setTimeInvoker( channel );
    }

    void masls_setTimeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                const ::SWA::StackFrame& frame ) const
    {

      // Write time
      channel << frame.getParameters()[0].getValue<int32_t>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
      for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
      {
        channel << frame.getLocalVars()[i].getId();
        switch ( frame.getLocalVars()[i].getId() )
        {
          case 0:

            // Write ui
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_UI::maslo_UI> >();
            break;

        }

      }
    }

    Callable masls_startTestHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_startTestInvoker( channel );
    }

    void masls_startTestHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                  const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
      for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
      {
        channel << frame.getLocalVars()[i].getId();
        switch ( frame.getLocalVars()[i].getId() )
        {
          case 0:

            // Write tc
            channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> >();
            break;

        }

      }
    }

    Callable masls_sendLapResetPressedHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_sendLapResetPressedInvoker( channel );
    }

    void masls_sendLapResetPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                            const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_sendLightPressedHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_sendLightPressedInvoker( channel );
    }

    void masls_sendLightPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                         const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_sendModePressedHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_sendModePressedInvoker( channel );
    }

    void masls_sendModePressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                        const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_sendStartStopPressedHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_sendStartStopPressedInvoker( channel );
    }

    void masls_sendStartStopPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                             const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_sendTargetPressedHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_sendTargetPressedInvoker( channel );
    }

    void masls_sendTargetPressedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                          const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    masld_UIHandler::masld_UIHandler ( )
    {
      registerObjectHandler( ::masld_UI::objectId_maslo_TestCase, ::boost::shared_ptr<GenericObjectHandler>( new maslo_TestCase::maslo_TestCaseHandler() ) );
      registerObjectHandler( ::masld_UI::objectId_maslo_UI, ::boost::shared_ptr<GenericObjectHandler>( new maslo_UI::maslo_UIHandler() ) );
      registerObjectHandler( ::masld_UI::objectId_maslo_UIConstants, ::boost::shared_ptr<GenericObjectHandler>( new maslo_UIConstants::maslo_UIConstantsHandler() ) );
      registerTerminatorHandler( ::masld_UI::terminatorId_maslb_TRACK, ::boost::shared_ptr<TerminatorHandler>( new maslb_TRACK::maslb_TRACKHandler() ) );
      registerServiceHandler( ::masld_UI::serviceId_masls_RunTestCase, ::boost::shared_ptr<ActionHandler>( new masls_RunTestCaseHandler() ) );
      registerServiceHandler( ::masld_UI::serviceId_masls_createGoals_1, ::boost::shared_ptr<ActionHandler>( new masls_createGoals_1Handler() ) );
      registerServiceHandler( ::masld_UI::serviceId_masls_init, ::boost::shared_ptr<ActionHandler>( new masls_initHandler() ) );
      registerServiceHandler( ::masld_UI::serviceId_masls_setData, ::boost::shared_ptr<ActionHandler>( new masls_setDataHandler() ) );
      registerServiceHandler( ::masld_UI::serviceId_masls_setIndicator, ::boost::shared_ptr<ActionHandler>( new masls_setIndicatorHandler() ) );
      registerServiceHandler( ::masld_UI::serviceId_masls_setTime, ::boost::shared_ptr<ActionHandler>( new masls_setTimeHandler() ) );
      registerServiceHandler( ::masld_UI::serviceId_masls_startTest, ::boost::shared_ptr<ActionHandler>( new masls_startTestHandler() ) );
      registerServiceHandler( ::masld_UI::serviceId_masls_sendLapResetPressed, ::boost::shared_ptr<ActionHandler>( new masls_sendLapResetPressedHandler() ) );
      registerServiceHandler( ::masld_UI::serviceId_masls_sendLightPressed, ::boost::shared_ptr<ActionHandler>( new masls_sendLightPressedHandler() ) );
      registerServiceHandler( ::masld_UI::serviceId_masls_sendModePressed, ::boost::shared_ptr<ActionHandler>( new masls_sendModePressedHandler() ) );
      registerServiceHandler( ::masld_UI::serviceId_masls_sendStartStopPressed, ::boost::shared_ptr<ActionHandler>( new masls_sendStartStopPressedHandler() ) );
      registerServiceHandler( ::masld_UI::serviceId_masls_sendTargetPressed, ::boost::shared_ptr<ActionHandler>( new masls_sendTargetPressedHandler() ) );
    }

    void masld_UIHandler::createRelationship ( CommunicationChannel& channel,
                                               int                   relId )
    {
      switch ( relId )
      {
      }

    }

  }
}
namespace 
{
  bool masld_UI_registered = ::Inspector::ProcessHandler::getInstance().registerDomainHandler( ::SWA::Process::getInstance().getDomain( "UI" ).getId(), ::boost::shared_ptr< ::Inspector::DomainHandler>( new ::Inspector::masld_UI::masld_UIHandler() ) );

}
