//
// File: __Tracking__modePressed.cc
//
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_services.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/bind.hpp"
#include "boost/shared_ptr.hpp"
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/navigate.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  void masls_modePressed ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_modePressed);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(4);
      {

        // session : instance of WorkoutSession;
        ::SWA::ObjectPtr<maslo_WorkoutSession> maslv_session;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_session(0, maslv_session);

        // display : instance of Display;
        ::SWA::ObjectPtr<maslo_Display> maslv_display;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_display(1, maslv_display);

        // session := find_one WorkoutSession ();
        {
          ::SWA::Stack::ExecutingStatement statement(9);
          maslv_session = maslo_WorkoutSession::findOne();
        }

        // if (null /= session) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(10);
          if ( ::SWA::Null != maslv_session )
          {

            // display := session -> R7.current_status_indicated_on.Display;
            {
              ::SWA::Stack::ExecutingStatement statement(11);
              maslv_display = ::SWA::navigate_one<maslo_Display>( maslv_session, ::boost::bind( &maslo_WorkoutSession::navigate_R7_current_status_indicated_on_Display, _1 ) );
            }

            // generate Display.modeChange () to display;
            {
              ::SWA::Stack::ExecutingStatement statement(12);
              ::SWA::Process::getInstance().getEventQueue().addEvent( maslv_display->create_maslo_Display_maslev_modeChange() );
            }
          }
        }
      }
    }
  }

  const bool localServiceRegistration_masls_modePressed = interceptor_masls_modePressed::instance().registerLocal( &masls_modePressed );

}
