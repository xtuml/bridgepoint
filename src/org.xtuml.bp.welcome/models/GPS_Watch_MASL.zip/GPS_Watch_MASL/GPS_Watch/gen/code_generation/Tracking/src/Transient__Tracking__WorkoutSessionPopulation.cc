//
// File: Transient__Tracking__WorkoutSessionPopulation.cc
//
#include "Transient__Tracking__WorkoutSession.hh"
#include "Transient__Tracking__WorkoutSessionPopulation.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Timestamp.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_WorkoutSessionPopulation::maslo_WorkoutSessionPopulation ( )
      : masla_startTime_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_WorkoutSessionPopulation::createInstance ( const ::SWA::Timestamp& masla_startTime,
                                                                                                               double                  masla_accumulatedDistance )
    {
      if ( exists_masla_startTime( masla_startTime ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> instance(new maslo_WorkoutSession(  masla_startTime,
                           masla_accumulatedDistance ));
      addInstance( instance );
      return instance;
    }

    void maslo_WorkoutSessionPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> instance )
    {
      masla_startTime_Lookup.insert( ::boost::unordered_map< ::boost::tuple< ::SWA::Timestamp>,::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> >::value_type( ::boost::make_tuple( instance->get_masla_startTime() ), instance ) );
    }

    void maslo_WorkoutSessionPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> instance )
    {
      masla_startTime_Lookup.erase( ::boost::make_tuple( instance->get_masla_startTime() ) );
    }

    bool maslo_WorkoutSessionPopulation::exists_masla_startTime ( const ::SWA::Timestamp& masla_startTime ) const
    {
      return masla_startTime_Lookup.find( ::boost::make_tuple( masla_startTime ) ) != masla_startTime_Lookup.end();
    }

    maslo_WorkoutSessionPopulation& maslo_WorkoutSessionPopulation::getPopulation ( )
    {
      static maslo_WorkoutSessionPopulation population;
      return population;
    }

    bool maslo_WorkoutSessionPopulation::registered = maslo_WorkoutSessionPopulation::registerSingleton( &maslo_WorkoutSessionPopulation::getPopulation );

  }
}
