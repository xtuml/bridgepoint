//
// File: Sqlite__Tracking__R3Mapper.hh
//
#ifndef Sqlite_Tracking_R_3_Mapper_hh
#define Sqlite_Tracking_R_3_Mapper_hh

#include "Sqlite__Tracking__TrackLog.hh"
#include "Sqlite__Tracking__TrackPoint.hh"
#include "sql/RelationshipBinaryDefinitions.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    typedef ::SQL::OneToOneRelationship<3,maslo_TrackLog,maslo_TrackPoint,true,true>::mapper_type RelationshipR3Mapper;
  }
}
#endif // Sqlite_Tracking_R_3_Mapper_hh
