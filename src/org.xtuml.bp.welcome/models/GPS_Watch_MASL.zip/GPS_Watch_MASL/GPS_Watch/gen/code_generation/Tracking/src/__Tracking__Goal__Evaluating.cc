//
// File: __Tracking__Goal__Evaluating.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalAchievement.hh"
#include "boost/shared_ptr.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Duration.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  void maslo_Goal::state_maslst_Evaluating ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_Goal, stateId_maslst_Evaluating);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // goalachievement : instance of GoalAchievement;
        ::SWA::ObjectPtr<maslo_GoalAchievement> maslv_goalachievement;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_goalachievement(0, maslv_goalachievement);

        // GoalAchievement.initialize()
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          maslo_GoalAchievement::masls_initialize();
        }

        // goalachievement := find_one GoalAchievement ();
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          maslv_goalachievement = maslo_GoalAchievement::findOne();
        }

        // schedule this.evaluationTimer generate Goal.Evaluate () to this delay (@PT0.000001S@ * goalachievement.evaluationPeriod) delta (@PT0.000001S@ * goalachievement.evaluationPeriod);
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          ::SWA::EventTimers::getInstance().scheduleTimer( ::SWA::ObjectPtr<maslo_Goal>( this )->get_masla_evaluationTimer(), ::SWA::Duration::fromNanos( 1000ll ) * maslv_goalachievement->get_masla_evaluationPeriod() + ::SWA::Timestamp::now(), ::SWA::Duration::fromNanos( 1000ll ) * maslv_goalachievement->get_masla_evaluationPeriod(), ::SWA::ObjectPtr<maslo_Goal>( this )->create_maslo_Goal_maslev_Evaluate( objectId_maslo_Goal, getArchitectureId() ) );
        }

        // generate Goal.evaluationComplete () to this;
        {
          ::SWA::Stack::ExecutingStatement statement(9);
          ::SWA::Process::getInstance().getEventQueue().addEvent( ::SWA::ObjectPtr<maslo_Goal>( this )->create_maslo_Goal_maslev_evaluationComplete( objectId_maslo_Goal, getArchitectureId() ) );
        }
      }
    }
  }

}
