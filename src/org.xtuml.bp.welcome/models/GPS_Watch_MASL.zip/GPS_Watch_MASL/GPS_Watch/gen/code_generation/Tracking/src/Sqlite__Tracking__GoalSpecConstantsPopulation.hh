//
// File: Sqlite__Tracking__GoalSpecConstantsPopulation.hh
//
#ifndef Sqlite_Tracking_Goal_Spec_Constants_Population_hh
#define Sqlite_Tracking_Goal_Spec_Constants_Population_hh

#include "Sqlite__Tracking__GoalSpecConstants.hh"
#include "Sqlite__Tracking__GoalSpecConstantsMapper.hh"
#include "__Tracking__GoalSpecConstants.hh"
#include "__Tracking__GoalSpecConstantsPopulation.hh"
#include "boost/signals2.hpp"
#include "sql/Population.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_GoalSpecConstantsPopulation
      : public ::SQL::SqlPopulation< ::masld_Tracking::maslo_GoalSpecConstants,maslo_GoalSpecConstants,maslo_GoalSpecConstantsMapper,::masld_Tracking::maslo_GoalSpecConstantsPopulation>
    {

      // Constructors and Destructors
      private:
        maslo_GoalSpecConstantsPopulation ( );
        ~maslo_GoalSpecConstantsPopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> createInstance ( int32_t masla_id,
                                                                                              int32_t masla_GoalSpecOrigin );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> instance );


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Singleton Registration
      public:
        static maslo_GoalSpecConstantsPopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;


    };
  }
}
#endif // Sqlite_Tracking_Goal_Spec_Constants_Population_hh
