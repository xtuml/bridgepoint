//
// File: __Location__DistancePopulation.hh
//
#ifndef _Location_Distance_Population_hh
#define _Location_Distance_Population_hh

#include <cstddef>
#include <stdint.h>
#include "swa/DynamicSingleton.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Location
{
  class maslo_Distance;
  class maslo_DistancePopulation
    : public ::SWA::DynamicSingleton<maslo_DistancePopulation>
  {

    // Instance Creation
    public:
      virtual ::SWA::IdType getNextArchId ( ) = 0;
      virtual ::SWA::ObjectPtr<maslo_Distance> createInstance ( int32_t masla_id,
                                                                double  masla_kmPerDegree ) = 0;
      virtual void deleteInstance ( ::SWA::ObjectPtr<maslo_Distance> instance ) = 0;
      virtual ::std::size_t size ( ) const = 0;


    // Instance Retrieval
    public:
      virtual ::SWA::ObjectPtr<maslo_Distance> getInstance ( ::SWA::IdType id ) const = 0;
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_Distance> > findAll ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_Distance> findOne ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_Distance> findOnly ( ) const = 0;


    // Constructors and Destructors
    protected:
      maslo_DistancePopulation ( );
      virtual ~maslo_DistancePopulation ( );


    // Prevent copy
    private:
      maslo_DistancePopulation ( const maslo_DistancePopulation& rhs );
      maslo_DistancePopulation& operator= ( const maslo_DistancePopulation& rhs );


  };
}
#endif // _Location_Distance_Population_hh
