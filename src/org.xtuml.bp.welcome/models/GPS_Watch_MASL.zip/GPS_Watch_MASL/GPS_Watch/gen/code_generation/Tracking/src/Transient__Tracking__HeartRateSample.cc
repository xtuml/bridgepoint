//
// File: Transient__Tracking__HeartRateSample.cc
//
#include "Transient__Tracking__HeartRateSample.hh"
#include "Transient__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutSession.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "transient/ToManyRelationship.hh"
#include "transient/ToOneRelationship.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_HeartRateSample::maslo_HeartRateSample ( int32_t                 masla_heartRate,
                                                   int32_t                 masla_time,
                                                   const ::SWA::Timestamp& masla_session_startTime )
      : architectureId(getNextArchId()),
        masla_heartRate(masla_heartRate),
        masla_time(masla_time),
        masla_session_startTime(masla_session_startTime),
        R6_was_collected_during_WorkoutSession()
    {
    }

    ToOneRelationship<maslo_WorkoutSession>& maslo_HeartRateSample::get_R6_was_collected_during_WorkoutSession ( )
    {
      return R6_was_collected_during_WorkoutSession;
    }

    const ToOneRelationship<maslo_WorkoutSession>& maslo_HeartRateSample::get_R6_was_collected_during_WorkoutSession ( ) const
    {
      return R6_was_collected_during_WorkoutSession;
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_HeartRateSample::navigate_R6_was_collected_during_WorkoutSession ( ) const
    {
      return get_R6_was_collected_during_WorkoutSession().navigate();
    }

    ::std::size_t maslo_HeartRateSample::count_R6_was_collected_during_WorkoutSession ( ) const
    {
      return get_R6_was_collected_during_WorkoutSession().count();
    }

    void maslo_HeartRateSample::link_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> rhs2 = rhs.downcast<maslo_WorkoutSession>();
      this->get_R6_was_collected_during_WorkoutSession().link( rhs2 );
      try
      {
        rhs2->get_R6_tracks_heart_rate_over_time_as_HeartRateSample().link( ::SWA::ObjectPtr<maslo_HeartRateSample>( this ) );
      }
      catch ( ... )
      {
        this->get_R6_was_collected_during_WorkoutSession().unlink( rhs2 );
        throw;
      }
    }

    void maslo_HeartRateSample::unlink_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutSession> rhs2 = rhs.downcast<maslo_WorkoutSession>();
      this->get_R6_was_collected_during_WorkoutSession().unlink( rhs2 );
      try
      {
        rhs2->get_R6_tracks_heart_rate_over_time_as_HeartRateSample().unlink( ::SWA::ObjectPtr<maslo_HeartRateSample>( this ) );
      }
      catch ( ... )
      {
        this->get_R6_was_collected_during_WorkoutSession().link( rhs2 );
        throw;
      }
    }

  }
}
