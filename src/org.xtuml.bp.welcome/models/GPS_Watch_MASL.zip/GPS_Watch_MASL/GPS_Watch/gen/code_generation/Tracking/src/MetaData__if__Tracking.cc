//
// File: MetaData__if__Tracking.cc
//
#include "Tracking_OOA/MetaData__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "metadata/MetaData.hh"
#include "swa/Domain.hh"

namespace 
{
  namespace init_interface_masld_Tracking
  {
    ::SWA::EnumerateMetaData get_maslt_GoalCriteria_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_GoalDisposition_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_GoalSpan_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_Indicator_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_Unit_MetaData ( );
    ::SWA::DomainMetaData initDomainMetaData ( )
    {
      ::SWA::DomainMetaData domain(::masld_Tracking::getDomain().getId(), "Tracking", true);
      domain.addEnumerate( get_maslt_GoalCriteria_MetaData() );
      domain.addEnumerate( get_maslt_GoalDisposition_MetaData() );
      domain.addEnumerate( get_maslt_GoalSpan_MetaData() );
      domain.addEnumerate( get_maslt_Indicator_MetaData() );
      domain.addEnumerate( get_maslt_Unit_MetaData() );
      return domain;
    }

    ::SWA::DomainMetaData& getDomainMetaData ( )
    {
      static ::SWA::DomainMetaData domain = initDomainMetaData();
      return domain;
    }

    bool registered = ::SWA::ProcessMetaData::getProcess().addDomain( ::masld_Tracking::getDomain().getId(), &getDomainMetaData );

    ::SWA::EnumerateMetaData get_maslt_GoalCriteria_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Tracking::typeId_maslt_GoalCriteria, "GoalCriteria");
      enumeration.addValue( ::masld_Tracking::maslt_GoalCriteria::masle_HeartRate.getValue(), "HeartRate" );
      enumeration.addValue( ::masld_Tracking::maslt_GoalCriteria::masle_Pace.getValue(), "Pace" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_GoalDisposition_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Tracking::typeId_maslt_GoalDisposition, "GoalDisposition");
      enumeration.addValue( ::masld_Tracking::maslt_GoalDisposition::masle_Achieving.getValue(), "Achieving" );
      enumeration.addValue( ::masld_Tracking::maslt_GoalDisposition::masle_Increase.getValue(), "Increase" );
      enumeration.addValue( ::masld_Tracking::maslt_GoalDisposition::masle_Decrease.getValue(), "Decrease" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_GoalSpan_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Tracking::typeId_maslt_GoalSpan, "GoalSpan");
      enumeration.addValue( ::masld_Tracking::maslt_GoalSpan::masle_Distance.getValue(), "Distance" );
      enumeration.addValue( ::masld_Tracking::maslt_GoalSpan::masle_Time.getValue(), "Time" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_Indicator_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Tracking::typeId_maslt_Indicator, "Indicator");
      enumeration.addValue( ::masld_Tracking::maslt_Indicator::masle_Blank.getValue(), "Blank" );
      enumeration.addValue( ::masld_Tracking::maslt_Indicator::masle_Down.getValue(), "Down" );
      enumeration.addValue( ::masld_Tracking::maslt_Indicator::masle_Flat.getValue(), "Flat" );
      enumeration.addValue( ::masld_Tracking::maslt_Indicator::masle_Up.getValue(), "Up" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_Unit_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Tracking::typeId_maslt_Unit, "Unit");
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_km.getValue(), "km" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_meters.getValue(), "meters" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_minPerKm.getValue(), "minPerKm" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_kmPerHour.getValue(), "kmPerHour" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_miles.getValue(), "miles" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_yards.getValue(), "yards" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_feet.getValue(), "feet" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_minPerMile.getValue(), "minPerMile" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_mph.getValue(), "mph" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_bpm.getValue(), "bpm" );
      enumeration.addValue( ::masld_Tracking::maslt_Unit::masle_laps.getValue(), "laps" );
      return enumeration;
    }

  }
}
