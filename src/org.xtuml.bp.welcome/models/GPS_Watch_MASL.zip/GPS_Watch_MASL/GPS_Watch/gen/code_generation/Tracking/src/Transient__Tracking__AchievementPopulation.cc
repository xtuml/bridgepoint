//
// File: Transient__Tracking__AchievementPopulation.cc
//
#include "Transient__Tracking__Achievement.hh"
#include "Transient__Tracking__AchievementPopulation.hh"
#include "__Tracking__Achievement.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Timestamp.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_AchievementPopulation::maslo_AchievementPopulation ( )
      : masla_startTimemasla_session_startTimemasla_goal_IDmasla_spec_sequenceNumber_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> maslo_AchievementPopulation::createInstance ( int32_t                 masla_startTime,
                                                                                                         int32_t                 masla_endTime,
                                                                                                         const ::SWA::Timestamp& masla_session_startTime,
                                                                                                         int32_t                 masla_goal_ID,
                                                                                                         int32_t                 masla_spec_sequenceNumber )
    {
      if ( exists_masla_startTimemasla_session_startTimemasla_goal_IDmasla_spec_sequenceNumber( masla_startTime, masla_session_startTime, masla_goal_ID, masla_spec_sequenceNumber ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> instance(new maslo_Achievement(  masla_startTime,
                        masla_endTime,
                        masla_session_startTime,
                        masla_goal_ID,
                        masla_spec_sequenceNumber ));
      addInstance( instance );
      return instance;
    }

    void maslo_AchievementPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> instance )
    {
      masla_startTimemasla_session_startTimemasla_goal_IDmasla_spec_sequenceNumber_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t,::SWA::Timestamp,int32_t,int32_t>,::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> >::value_type( ::boost::make_tuple( instance->get_masla_startTime(), instance->get_masla_session_startTime(), instance->get_masla_goal_ID(), instance->get_masla_spec_sequenceNumber() ), instance ) );
    }

    void maslo_AchievementPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> instance )
    {
      masla_startTimemasla_session_startTimemasla_goal_IDmasla_spec_sequenceNumber_Lookup.erase( ::boost::make_tuple( instance->get_masla_startTime(), instance->get_masla_session_startTime(), instance->get_masla_goal_ID(), instance->get_masla_spec_sequenceNumber() ) );
    }

    bool maslo_AchievementPopulation::exists_masla_startTimemasla_session_startTimemasla_goal_IDmasla_spec_sequenceNumber ( int32_t                 masla_startTime,
                                                                                                                            const ::SWA::Timestamp& masla_session_startTime,
                                                                                                                            int32_t                 masla_goal_ID,
                                                                                                                            int32_t                 masla_spec_sequenceNumber ) const
    {
      return masla_startTimemasla_session_startTimemasla_goal_IDmasla_spec_sequenceNumber_Lookup.find( ::boost::make_tuple( masla_startTime, masla_session_startTime, masla_goal_ID, masla_spec_sequenceNumber ) ) != masla_startTimemasla_session_startTimemasla_goal_IDmasla_spec_sequenceNumber_Lookup.end();
    }

    maslo_AchievementPopulation& maslo_AchievementPopulation::getPopulation ( )
    {
      static maslo_AchievementPopulation population;
      return population;
    }

    bool maslo_AchievementPopulation::registered = maslo_AchievementPopulation::registerSingleton( &maslo_AchievementPopulation::getPopulation );

  }
}
