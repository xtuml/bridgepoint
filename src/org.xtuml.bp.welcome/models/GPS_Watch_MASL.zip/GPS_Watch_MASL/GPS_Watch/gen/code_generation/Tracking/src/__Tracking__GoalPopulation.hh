//
// File: __Tracking__GoalPopulation.hh
//
#ifndef _Tracking_Goal_Population_hh
#define _Tracking_Goal_Population_hh

#include "__Tracking__Goal.hh"
#include <cstddef>
#include <stdint.h>
#include "swa/DynamicSingleton.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslt_GoalDisposition;
  class maslo_GoalPopulation
    : public ::SWA::DynamicSingleton<maslo_GoalPopulation>
  {

    // Instance Creation
    public:
      virtual ::SWA::IdType getNextArchId ( ) = 0;
      virtual ::SWA::ObjectPtr<maslo_Goal> createInstance ( const maslt_GoalDisposition&           masla_disposition,
                                                            double                                 masla_startingPoint,
                                                            int32_t                                masla_ID,
                                                            const ::SWA::EventTimers::TimerIdType& masla_evaluationTimer,
                                                            const ::SWA::Timestamp&                masla_session_startTime,
                                                            int32_t                                masla_spec_sequenceNumber,
                                                            maslo_Goal::Type                       currentState ) = 0;
      virtual void deleteInstance ( ::SWA::ObjectPtr<maslo_Goal> instance ) = 0;
      virtual ::std::size_t size ( ) const = 0;


    // Instance Retrieval
    public:
      virtual ::SWA::ObjectPtr<maslo_Goal> getInstance ( ::SWA::IdType id ) const = 0;
      virtual ::SWA::Set< ::SWA::ObjectPtr<maslo_Goal> > findAll ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_Goal> findOne ( ) const = 0;
      virtual ::SWA::ObjectPtr<maslo_Goal> findOnly ( ) const = 0;


    // Constructors and Destructors
    protected:
      maslo_GoalPopulation ( );
      virtual ~maslo_GoalPopulation ( );


    // Prevent copy
    private:
      maslo_GoalPopulation ( const maslo_GoalPopulation& rhs );
      maslo_GoalPopulation& operator= ( const maslo_GoalPopulation& rhs );


  };
}
#endif // _Tracking_Goal_Population_hh
