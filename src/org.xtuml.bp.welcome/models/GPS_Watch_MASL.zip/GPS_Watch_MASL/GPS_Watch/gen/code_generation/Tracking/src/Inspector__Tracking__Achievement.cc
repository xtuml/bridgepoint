//
// File: Inspector__Tracking__Achievement.cc
//
#include "Inspector__Tracking__Achievement.hh"
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__Achievement.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/ObjectHandler.hh"
#include "inspector/ProcessHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include <string>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_Achievement
    {
      class masls_closeHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_closeInvoker
      {

        public:
          masls_closeInvoker ( CommunicationChannel& channel )
            : thisVar()
 { channel >> thisVar; }
          void operator() ( ) { if ( thisVar ) thisVar->masls_close(); }


        private:
          ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> thisVar;


      };
      Callable masls_closeHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_closeInvoker( channel );
      }

      void masls_closeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                const ::SWA::StackFrame& frame ) const
      {

        // Write this
        channel << ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>( frame.getThis< ::masld_Tracking::maslo_Achievement>() );

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write goal
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> >();
              break;

            case 1:

              // Write workoutTimer
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> >();
              break;

          }

        }
      }

      maslo_AchievementHandler::maslo_AchievementHandler ( )
      {
        registerServiceHandler( ::masld_Tracking::maslo_Achievement::serviceId_masls_close, ::boost::shared_ptr<ActionHandler>( new masls_closeHandler() ) );
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslo_Achievement> ( const ::masld_Tracking::maslo_Achievement& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_startTime() );
    write( instance.get_masla_endTime() );
    write( instance.get_masla_session_startTime() );
    write( instance.get_masla_goal_ID() );
    write( instance.get_masla_spec_sequenceNumber() );
    write( instance.navigate_R12_specifies_achievement_of_Goal() );
    write( instance.navigate_R14_is_open_for_Goal() );
  }

  namespace masld_Tracking
  {
    namespace maslo_Achievement
    {
      void maslo_AchievementHandler::createInstance ( CommunicationChannel& channel ) const
      {
        int32_t masla_startTime;
        int32_t masla_endTime;
        ::SWA::Timestamp masla_session_startTime;
        int32_t masla_goal_ID;
        int32_t masla_spec_sequenceNumber;
        channel >> masla_startTime >> masla_endTime >> masla_session_startTime >> masla_goal_ID >> masla_spec_sequenceNumber;
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> instance = ::masld_Tracking::maslo_Achievement::createInstance( masla_startTime, masla_endTime, masla_session_startTime, masla_goal_ID, masla_spec_sequenceNumber );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_AchievementHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_startTime() ) + "," + ::boost::lexical_cast< ::std::string>( instance->get_masla_session_startTime() ) + "," + ::boost::lexical_cast< ::std::string>( instance->get_masla_goal_ID() ) + "," + ::boost::lexical_cast< ::std::string>( instance->get_masla_spec_sequenceNumber() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> > ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_Tracking::maslo_Achievement::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_Tracking
  {
    namespace maslo_Achievement
    {
      void maslo_AchievementHandler::writeRelatedInstances ( CommunicationChannel&                                  channel,
                                                             ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> instance,
                                                             int                                                    relId ) const
      {
        switch ( relId )
        {
          case 0:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_Goal>( ::masld_Tracking::objectId_maslo_Goal ).writeInstances( channel, instance ? instance->navigate_R12_specifies_achievement_of_Goal()
                                                                                                                                                                                                                               : ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>() );
            break;

          case 1:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_Goal>( ::masld_Tracking::objectId_maslo_Goal ).writeInstances( channel, instance ? instance->navigate_R14_is_open_for_Goal()
                                                                                                                                                                                                                               : ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>() );
            break;

        }

      }

    }
  }
}
