//
// File: Sqlite__Location__GPSMapper.cc
//
#include "Sqlite__Location__GPS.hh"
#include "Sqlite__Location__GPSMapper.hh"
#include "Sqlite__Location__GPSMapperSql.hh"
#include "__Location__GPS.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_Location
  {
    maslo_GPSMapper::maslo_GPSMapper ( )
      : ::SQL::ObjectMapper< ::masld_Location::maslo_GPS,maslo_GPS>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_Location::maslo_GPS,maslo_GPS> >( new maslo_GPSSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_GPSMapper::~maslo_GPSMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> maslo_GPSMapper::createInstance ( const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                                     double                                 masla_currentLatitude,
                                                                                     double                                 masla_currentLongitude,
                                                                                     int32_t                                masla_motionSegments,
                                                                                     int32_t                                masla_id,
                                                                                     ::masld_Location::maslo_GPS::Type      currentState )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_GPS::PrimaryKeyType>::value_type( masla_id ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_GPS> instance(new maslo_GPS(  uniqueId,
                masla_timer,
                masla_currentLatitude,
                masla_currentLongitude,
                masla_motionSegments,
                masla_id,
                currentState ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_GPSMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> instance )
    {
      ::SQL::ObjectMapper< ::masld_Location::maslo_GPS,maslo_GPS>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_GPS>()->getPrimaryKey() );
    }

    bool maslo_GPSMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
