//
// File: Transient__HeartRateMonitor__HeartRateConstants.hh
//
#ifndef Transient_Heart_Rate_Monitor_Heart_Rate_Constants_hh
#define Transient_Heart_Rate_Monitor_Heart_Rate_Constants_hh

#include "__HeartRateMonitor__HeartRateConstants.hh"
#include <stdint.h>
#include "swa/types.hh"

namespace transient
{
  namespace masld_HeartRateMonitor
  {
    class maslo_HeartRateConstants
      : public ::masld_HeartRateMonitor::maslo_HeartRateConstants
    {

      // Constructors and Destructors
      public:
        maslo_HeartRateConstants ( int32_t masla_id,
                                   int32_t masla_HeartRateAveragingWindow,
                                   int32_t masla_HeartRateSamplingPeriod );


      // Setters for each object attribute
      public:
        virtual void set_masla_HeartRateAveragingWindow ( int32_t value ) { this->masla_HeartRateAveragingWindow = value; }
        virtual void set_masla_HeartRateSamplingPeriod ( int32_t value ) { this->masla_HeartRateSamplingPeriod = value; }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual int32_t get_masla_HeartRateAveragingWindow ( ) const { return masla_HeartRateAveragingWindow; }
        virtual int32_t get_masla_HeartRateSamplingPeriod ( ) const { return masla_HeartRateSamplingPeriod; }


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_id;
        int32_t masla_HeartRateAveragingWindow;
        int32_t masla_HeartRateSamplingPeriod;


    };
  }
}
#endif // Transient_Heart_Rate_Monitor_Heart_Rate_Constants_hh
