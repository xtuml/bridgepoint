//
// File: __Tracking__WorkoutTimer.hh
//
#ifndef _Tracking_Workout_Timer_hh
#define _Tracking_Workout_Timer_hh

#include "boost/shared_ptr.hpp"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_WorkoutSession;
  class maslo_WorkoutTimer;
  class maslo_WorkoutTimer
  {

    public:
      enum Type {  maslst_stopped,
                   maslst_running,
                   maslst_paused,
                   maslst_processingStart,
                   maslst_resetLap };


    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_WorkoutTimer> createInstance ( int32_t                                masla_time,
                                                                   const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                   const ::SWA::Timestamp&                masla_session_startTime,
                                                                   Type                                   currentState );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_WorkoutTimer> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_time ( int32_t value ) = 0;
      virtual void set_masla_timer ( const ::SWA::EventTimers::TimerIdType& value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual int32_t get_masla_time ( ) const = 0;
      virtual ::SWA::EventTimers::TimerIdType get_masla_timer ( ) const = 0;
      virtual ::SWA::Timestamp get_masla_session_startTime ( ) const = 0;


    // Instance Services
    public:
      void masls_activate ( );
      void masls_deactivate ( );
      void masls_initialize ( );


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_WorkoutTimer> > findAll ( );
      static ::SWA::ObjectPtr<maslo_WorkoutTimer> findOne ( );
      static ::SWA::ObjectPtr<maslo_WorkoutTimer> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_WorkoutTimer ( );
      virtual ~maslo_WorkoutTimer ( );


    // Prevent copy
    private:
      maslo_WorkoutTimer ( const maslo_WorkoutTimer& rhs );
      maslo_WorkoutTimer& operator= ( const maslo_WorkoutTimer& rhs );


    // State Machine
    public:
      virtual Type getCurrentState ( ) const = 0;
      virtual void setCurrentState ( Type newState ) = 0;


    // State Actions
    private:
      void state_maslst_stopped ( );
      void state_maslst_running ( );
      void state_maslst_paused ( );
      void state_maslst_processingStart ( );
      void state_maslst_resetLap ( );


    // Generate Events
    public:
      ::boost::shared_ptr< ::SWA::Event> create_maslo_WorkoutTimer_maslev_startStopPressed ( int           sourceObj = -1,
                                                                                             ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_WorkoutTimer_maslev_lapResetPressed ( int           sourceObj = -1,
                                                                                            ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_WorkoutTimer_maslev_tick ( int           sourceObj = -1,
                                                                                 ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_WorkoutTimer_maslev_pause ( int           sourceObj = -1,
                                                                                  ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_WorkoutTimer_maslev_resume ( int           sourceObj = -1,
                                                                                   ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_WorkoutTimer_maslev_startTimer ( int           sourceObj = -1,
                                                                                       ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_WorkoutTimer_maslev_lapResetComplete ( int           sourceObj = -1,
                                                                                             ::SWA::IdType sourceInstance = 0 );


    // Consume Events
    public:
      static void consume_maslo_WorkoutTimer_maslev_startStopPressed ( ::SWA::IdType id );
      static void consume_maslo_WorkoutTimer_maslev_lapResetPressed ( ::SWA::IdType id );
      static void consume_maslo_WorkoutTimer_maslev_tick ( ::SWA::IdType id );
      static void consume_maslo_WorkoutTimer_maslev_pause ( ::SWA::IdType id );
      static void consume_maslo_WorkoutTimer_maslev_resume ( ::SWA::IdType id );
      static void consume_maslo_WorkoutTimer_maslev_startTimer ( ::SWA::IdType id );
      static void consume_maslo_WorkoutTimer_maslev_lapResetComplete ( ::SWA::IdType id );


    // Process Events
    public:
      void process_maslo_WorkoutTimer_maslev_startStopPressed ( );
      void process_maslo_WorkoutTimer_maslev_lapResetPressed ( );
      void process_maslo_WorkoutTimer_maslev_tick ( );
      void process_maslo_WorkoutTimer_maslev_pause ( );
      void process_maslo_WorkoutTimer_maslev_resume ( );
      void process_maslo_WorkoutTimer_maslev_startTimer ( );
      void process_maslo_WorkoutTimer_maslev_lapResetComplete ( );


    // Id Enumerations
    public:
      enum StateIds {  stateId_maslst_stopped,
                       stateId_maslst_running,
                       stateId_maslst_paused,
                       stateId_maslst_processingStart,
                       stateId_maslst_resetLap };
      enum EventIds {  eventId_maslo_WorkoutTimer_maslev_startStopPressed,
                       eventId_maslo_WorkoutTimer_maslev_lapResetPressed,
                       eventId_maslo_WorkoutTimer_maslev_tick,
                       eventId_maslo_WorkoutTimer_maslev_pause,
                       eventId_maslo_WorkoutTimer_maslev_resume,
                       eventId_maslo_WorkoutTimer_maslev_startTimer,
                       eventId_maslo_WorkoutTimer_maslev_lapResetComplete };
      enum ServiceIds {  serviceId_masls_activate,
                         serviceId_masls_deactivate,
                         serviceId_masls_initialize };


    // Relationship R8.acts_as_the_stopwatch_for.WorkoutSession
    public:
      virtual ::SWA::ObjectPtr<maslo_WorkoutSession> navigate_R8_acts_as_the_stopwatch_for_WorkoutSession ( ) const = 0;
      virtual ::std::size_t count_R8_acts_as_the_stopwatch_for_WorkoutSession ( ) const;
      virtual void link_R8_acts_as_the_stopwatch_for_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs ) = 0;
      void checked_link_R8_acts_as_the_stopwatch_for_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs );
      virtual void unlink_R8_acts_as_the_stopwatch_for_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs ) = 0;
      virtual void unlink_R8_acts_as_the_stopwatch_for_WorkoutSession ( );


  };
  ::std::ostream& operator<< ( ::std::ostream&           stream,
                               const maslo_WorkoutTimer& obj );
}
#endif // _Tracking_Workout_Timer_hh
