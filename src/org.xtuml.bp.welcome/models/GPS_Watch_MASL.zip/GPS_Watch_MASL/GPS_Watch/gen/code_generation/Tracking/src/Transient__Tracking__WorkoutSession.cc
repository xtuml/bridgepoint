//
// File: Transient__Tracking__WorkoutSession.cc
//
#include "Transient__Tracking__Display.hh"
#include "Transient__Tracking__Goal.hh"
#include "Transient__Tracking__GoalSpec.hh"
#include "Transient__Tracking__HeartRateSample.hh"
#include "Transient__Tracking__TrackLog.hh"
#include "Transient__Tracking__WorkoutSession.hh"
#include "Transient__Tracking__WorkoutTimer.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__HeartRateSample.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__WorkoutTimer.hh"
#include <cstddef>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "transient/ToManyRelationship.hh"
#include "transient/ToOneRelationship.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_WorkoutSession::maslo_WorkoutSession ( const ::SWA::Timestamp& masla_startTime,
                                                 double                  masla_accumulatedDistance )
      : architectureId(getNextArchId()),
        masla_startTime(masla_startTime),
        masla_accumulatedDistance(masla_accumulatedDistance),
        R7_current_status_indicated_on_Display(),
        R8_is_timed_by_WorkoutTimer(),
        R4_captures_path_in_TrackLog(),
        R6_tracks_heart_rate_over_time_as_HeartRateSample(),
        R10_includes_GoalSpec(),
        R11_is_currently_executing_Goal(),
        R13_has_executed_Goal()
    {
    }

    ToOneRelationship<maslo_Display>& maslo_WorkoutSession::get_R7_current_status_indicated_on_Display ( )
    {
      return R7_current_status_indicated_on_Display;
    }

    const ToOneRelationship<maslo_Display>& maslo_WorkoutSession::get_R7_current_status_indicated_on_Display ( ) const
    {
      return R7_current_status_indicated_on_Display;
    }

    ToOneRelationship<maslo_WorkoutTimer>& maslo_WorkoutSession::get_R8_is_timed_by_WorkoutTimer ( )
    {
      return R8_is_timed_by_WorkoutTimer;
    }

    const ToOneRelationship<maslo_WorkoutTimer>& maslo_WorkoutSession::get_R8_is_timed_by_WorkoutTimer ( ) const
    {
      return R8_is_timed_by_WorkoutTimer;
    }

    ToOneRelationship<maslo_TrackLog>& maslo_WorkoutSession::get_R4_captures_path_in_TrackLog ( )
    {
      return R4_captures_path_in_TrackLog;
    }

    const ToOneRelationship<maslo_TrackLog>& maslo_WorkoutSession::get_R4_captures_path_in_TrackLog ( ) const
    {
      return R4_captures_path_in_TrackLog;
    }

    ToManyRelationship<maslo_HeartRateSample>& maslo_WorkoutSession::get_R6_tracks_heart_rate_over_time_as_HeartRateSample ( )
    {
      return R6_tracks_heart_rate_over_time_as_HeartRateSample;
    }

    const ToManyRelationship<maslo_HeartRateSample>& maslo_WorkoutSession::get_R6_tracks_heart_rate_over_time_as_HeartRateSample ( ) const
    {
      return R6_tracks_heart_rate_over_time_as_HeartRateSample;
    }

    ToManyRelationship<maslo_GoalSpec>& maslo_WorkoutSession::get_R10_includes_GoalSpec ( )
    {
      return R10_includes_GoalSpec;
    }

    const ToManyRelationship<maslo_GoalSpec>& maslo_WorkoutSession::get_R10_includes_GoalSpec ( ) const
    {
      return R10_includes_GoalSpec;
    }

    ToOneRelationship<maslo_Goal>& maslo_WorkoutSession::get_R11_is_currently_executing_Goal ( )
    {
      return R11_is_currently_executing_Goal;
    }

    const ToOneRelationship<maslo_Goal>& maslo_WorkoutSession::get_R11_is_currently_executing_Goal ( ) const
    {
      return R11_is_currently_executing_Goal;
    }

    ToManyRelationship<maslo_Goal>& maslo_WorkoutSession::get_R13_has_executed_Goal ( )
    {
      return R13_has_executed_Goal;
    }

    const ToManyRelationship<maslo_Goal>& maslo_WorkoutSession::get_R13_has_executed_Goal ( ) const
    {
      return R13_has_executed_Goal;
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display> maslo_WorkoutSession::navigate_R7_current_status_indicated_on_Display ( ) const
    {
      return get_R7_current_status_indicated_on_Display().navigate();
    }

    ::std::size_t maslo_WorkoutSession::count_R7_current_status_indicated_on_Display ( ) const
    {
      return get_R7_current_status_indicated_on_Display().count();
    }

    void maslo_WorkoutSession::link_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Display> rhs2 = rhs.downcast<maslo_Display>();
      this->get_R7_current_status_indicated_on_Display().link( rhs2 );
      try
      {
        rhs2->get_R7_indicates_current_status_of_WorkoutSession().link( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ) );
      }
      catch ( ... )
      {
        this->get_R7_current_status_indicated_on_Display().unlink( rhs2 );
        throw;
      }
    }

    void maslo_WorkoutSession::unlink_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Display>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Display> rhs2 = rhs.downcast<maslo_Display>();
      this->get_R7_current_status_indicated_on_Display().unlink( rhs2 );
      try
      {
        rhs2->get_R7_indicates_current_status_of_WorkoutSession().unlink( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ) );
      }
      catch ( ... )
      {
        this->get_R7_current_status_indicated_on_Display().link( rhs2 );
        throw;
      }
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer> maslo_WorkoutSession::navigate_R8_is_timed_by_WorkoutTimer ( ) const
    {
      return get_R8_is_timed_by_WorkoutTimer().navigate();
    }

    ::std::size_t maslo_WorkoutSession::count_R8_is_timed_by_WorkoutTimer ( ) const
    {
      return get_R8_is_timed_by_WorkoutTimer().count();
    }

    void maslo_WorkoutSession::link_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutTimer> rhs2 = rhs.downcast<maslo_WorkoutTimer>();
      this->get_R8_is_timed_by_WorkoutTimer().link( rhs2 );
      try
      {
        rhs2->get_R8_acts_as_the_stopwatch_for_WorkoutSession().link( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ) );
      }
      catch ( ... )
      {
        this->get_R8_is_timed_by_WorkoutTimer().unlink( rhs2 );
        throw;
      }
    }

    void maslo_WorkoutSession::unlink_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimer>& rhs )
    {
      ::SWA::ObjectPtr<maslo_WorkoutTimer> rhs2 = rhs.downcast<maslo_WorkoutTimer>();
      this->get_R8_is_timed_by_WorkoutTimer().unlink( rhs2 );
      try
      {
        rhs2->get_R8_acts_as_the_stopwatch_for_WorkoutSession().unlink( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ) );
      }
      catch ( ... )
      {
        this->get_R8_is_timed_by_WorkoutTimer().link( rhs2 );
        throw;
      }
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog> maslo_WorkoutSession::navigate_R4_captures_path_in_TrackLog ( ) const
    {
      return get_R4_captures_path_in_TrackLog().navigate();
    }

    ::std::size_t maslo_WorkoutSession::count_R4_captures_path_in_TrackLog ( ) const
    {
      return get_R4_captures_path_in_TrackLog().count();
    }

    void maslo_WorkoutSession::link_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackLog> rhs2 = rhs.downcast<maslo_TrackLog>();
      this->get_R4_captures_path_in_TrackLog().link( rhs2 );
      try
      {
        rhs2->get_R4_represents_path_for_WorkoutSession().link( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ) );
      }
      catch ( ... )
      {
        this->get_R4_captures_path_in_TrackLog().unlink( rhs2 );
        throw;
      }
    }

    void maslo_WorkoutSession::unlink_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_TrackLog>& rhs )
    {
      ::SWA::ObjectPtr<maslo_TrackLog> rhs2 = rhs.downcast<maslo_TrackLog>();
      this->get_R4_captures_path_in_TrackLog().unlink( rhs2 );
      try
      {
        rhs2->get_R4_represents_path_for_WorkoutSession().unlink( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ) );
      }
      catch ( ... )
      {
        this->get_R4_captures_path_in_TrackLog().link( rhs2 );
        throw;
      }
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> > maslo_WorkoutSession::navigate_R6_tracks_heart_rate_over_time_as_HeartRateSample ( ) const
    {
      return get_R6_tracks_heart_rate_over_time_as_HeartRateSample().navigate();
    }

    ::std::size_t maslo_WorkoutSession::count_R6_tracks_heart_rate_over_time_as_HeartRateSample ( ) const
    {
      return get_R6_tracks_heart_rate_over_time_as_HeartRateSample().count();
    }

    void maslo_WorkoutSession::link_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample>& rhs )
    {
      ::SWA::ObjectPtr<maslo_HeartRateSample> rhs2 = rhs.downcast<maslo_HeartRateSample>();
      this->get_R6_tracks_heart_rate_over_time_as_HeartRateSample().link( rhs2 );
      try
      {
        rhs2->get_R6_was_collected_during_WorkoutSession().link( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ) );
      }
      catch ( ... )
      {
        this->get_R6_tracks_heart_rate_over_time_as_HeartRateSample().unlink( rhs2 );
        throw;
      }
    }

    void maslo_WorkoutSession::unlink_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample>& rhs )
    {
      ::SWA::ObjectPtr<maslo_HeartRateSample> rhs2 = rhs.downcast<maslo_HeartRateSample>();
      this->get_R6_tracks_heart_rate_over_time_as_HeartRateSample().unlink( rhs2 );
      try
      {
        rhs2->get_R6_was_collected_during_WorkoutSession().unlink( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ) );
      }
      catch ( ... )
      {
        this->get_R6_tracks_heart_rate_over_time_as_HeartRateSample().link( rhs2 );
        throw;
      }
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> > maslo_WorkoutSession::navigate_R10_includes_GoalSpec ( ) const
    {
      return get_R10_includes_GoalSpec().navigate();
    }

    ::std::size_t maslo_WorkoutSession::count_R10_includes_GoalSpec ( ) const
    {
      return get_R10_includes_GoalSpec().count();
    }

    void maslo_WorkoutSession::link_R10_includes_GoalSpec ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& rhs )
    {
      ::SWA::ObjectPtr<maslo_GoalSpec> rhs2 = rhs.downcast<maslo_GoalSpec>();
      this->get_R10_includes_GoalSpec().link( rhs2 );
      try
      {
        rhs2->get_R10_included_in_WorkoutSession().link( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ) );
      }
      catch ( ... )
      {
        this->get_R10_includes_GoalSpec().unlink( rhs2 );
        throw;
      }
    }

    void maslo_WorkoutSession::unlink_R10_includes_GoalSpec ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& rhs )
    {
      ::SWA::ObjectPtr<maslo_GoalSpec> rhs2 = rhs.downcast<maslo_GoalSpec>();
      this->get_R10_includes_GoalSpec().unlink( rhs2 );
      try
      {
        rhs2->get_R10_included_in_WorkoutSession().unlink( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ) );
      }
      catch ( ... )
      {
        this->get_R10_includes_GoalSpec().link( rhs2 );
        throw;
      }
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> maslo_WorkoutSession::navigate_R11_is_currently_executing_Goal ( ) const
    {
      return get_R11_is_currently_executing_Goal().navigate();
    }

    ::std::size_t maslo_WorkoutSession::count_R11_is_currently_executing_Goal ( ) const
    {
      return get_R11_is_currently_executing_Goal().count();
    }

    void maslo_WorkoutSession::link_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> rhs2 = rhs.downcast<maslo_Goal>();
      this->get_R11_is_currently_executing_Goal().link( rhs2 );
      try
      {
        rhs2->get_R11_is_currently_executing_within_WorkoutSession().link( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ) );
      }
      catch ( ... )
      {
        this->get_R11_is_currently_executing_Goal().unlink( rhs2 );
        throw;
      }
    }

    void maslo_WorkoutSession::unlink_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> rhs2 = rhs.downcast<maslo_Goal>();
      this->get_R11_is_currently_executing_Goal().unlink( rhs2 );
      try
      {
        rhs2->get_R11_is_currently_executing_within_WorkoutSession().unlink( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ) );
      }
      catch ( ... )
      {
        this->get_R11_is_currently_executing_Goal().link( rhs2 );
        throw;
      }
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> > maslo_WorkoutSession::navigate_R13_has_executed_Goal ( ) const
    {
      return get_R13_has_executed_Goal().navigate();
    }

    ::std::size_t maslo_WorkoutSession::count_R13_has_executed_Goal ( ) const
    {
      return get_R13_has_executed_Goal().count();
    }

    void maslo_WorkoutSession::link_R13_has_executed_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> rhs2 = rhs.downcast<maslo_Goal>();
      this->get_R13_has_executed_Goal().link( rhs2 );
      try
      {
        rhs2->get_R13_was_executed_within_WorkoutSession().link( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ) );
      }
      catch ( ... )
      {
        this->get_R13_has_executed_Goal().unlink( rhs2 );
        throw;
      }
    }

    void maslo_WorkoutSession::unlink_R13_has_executed_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs )
    {
      ::SWA::ObjectPtr<maslo_Goal> rhs2 = rhs.downcast<maslo_Goal>();
      this->get_R13_has_executed_Goal().unlink( rhs2 );
      try
      {
        rhs2->get_R13_was_executed_within_WorkoutSession().unlink( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ) );
      }
      catch ( ... )
      {
        this->get_R13_has_executed_Goal().link( rhs2 );
        throw;
      }
    }

  }
}
