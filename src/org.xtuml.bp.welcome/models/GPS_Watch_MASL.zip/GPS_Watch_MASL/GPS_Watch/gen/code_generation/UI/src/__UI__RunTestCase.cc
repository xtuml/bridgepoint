//
// File: __UI__RunTestCase.cc
//
#include "UI_OOA/__UI_interface.hh"
#include "__UI__TestCase.hh"
#include "__UI_private_services.hh"
#include "swa/Domain.hh"
#include "swa/Stack.hh"

namespace masld_UI
{
  void masls_RunTestCase ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringDomainService enteringActionMarker(getDomain().getId(), serviceId_masls_RunTestCase);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // TestCase.execute()
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          maslo_TestCase::masls_execute();
        }
      }
    }
  }

  const bool localServiceRegistration_masls_RunTestCase = interceptor_masls_RunTestCase::instance().registerLocal( &masls_RunTestCase );

}
