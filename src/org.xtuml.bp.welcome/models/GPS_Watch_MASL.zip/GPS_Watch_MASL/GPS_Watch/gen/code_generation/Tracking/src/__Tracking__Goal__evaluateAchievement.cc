//
// File: __Tracking__Goal__evaluateAchievement.cc
//
#include "LOG_OOA/__LOG_services.hh"
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/bind.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"
#include "swa/navigate.hh"

namespace masld_Tracking
{
  maslt_GoalDisposition maslo_Goal::masls_evaluateAchievement ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_Goal, serviceId_masls_evaluateAchievement);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(6);
      {

        // goalSpec : instance of GoalSpec;
        ::SWA::ObjectPtr<maslo_GoalSpec> maslv_goalSpec;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_goalSpec(0, maslv_goalSpec);

        // session : instance of WorkoutSession;
        ::SWA::ObjectPtr<maslo_WorkoutSession> maslv_session;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_session(1, maslv_session);

        // currentValue : real;
        double maslv_currentValue = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_currentValue(2, maslv_currentValue);

        // goalDisposition : Tracking::GoalDisposition;
        maslt_GoalDisposition maslv_goalDisposition;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_goalDisposition(3, maslv_goalDisposition);

        // goalSpec := this -> R9.specified_by.GoalSpec;
        {
          ::SWA::Stack::ExecutingStatement statement(12);
          maslv_goalSpec = ::SWA::navigate_one<maslo_GoalSpec>( ::SWA::ObjectPtr<maslo_Goal>( this ), ::boost::bind( &maslo_Goal::navigate_R9_specified_by_GoalSpec, _1 ) );
        }

        // session := this -> R11.is_currently_executing_within.WorkoutSession;
        {
          ::SWA::Stack::ExecutingStatement statement(13);
          maslv_session = ::SWA::navigate_one<maslo_WorkoutSession>( ::SWA::ObjectPtr<maslo_Goal>( this ), ::boost::bind( &maslo_Goal::navigate_R11_is_currently_executing_within_WorkoutSession, _1 ) );
        }

        // currentValue := 0.0;
        {
          ::SWA::Stack::ExecutingStatement statement(17);
          maslv_currentValue = 0.0;
        }

        // if (goalSpec.criteriaType = Tracking::GoalCriteria.HeartRate) then ...
        // elsif (goalSpec.criteriaType = Tracking::GoalCriteria.Pace) then ...
        // else ...
        {
          ::SWA::Stack::ExecutingStatement statement(18);
          if ( maslv_goalSpec->get_masla_criteriaType() == maslt_GoalCriteria::masle_HeartRate )
          {

            // currentValue := real(session.getCurrentHeartRate());
            {
              ::SWA::Stack::ExecutingStatement statement(19);
              maslv_currentValue = static_cast<double>( maslv_session->masls_getCurrentHeartRate() );
            }
          }
          else if ( maslv_goalSpec->get_masla_criteriaType() == maslt_GoalCriteria::masle_Pace )
          {

            // currentValue := session.getCurrentPace();
            {
              ::SWA::Stack::ExecutingStatement statement(21);
              maslv_currentValue = maslv_session->masls_getCurrentPace();
            }
          }
          else
          {

            // LOG::LogFailure("Goal.evaluateAchievement: Unknown Goal Criteria Type.")
            {
              ::SWA::Stack::ExecutingStatement statement(23);
              ::masld_LOG::interceptor_masls_LogFailure::instance().callService()( ::SWA::String( "Goal.evaluateAchievement: Unknown Goal Criteria Type." ) );
            }
          }
        }

        // goalDisposition := Tracking::GoalDisposition.Achieving;
        {
          ::SWA::Stack::ExecutingStatement statement(27);
          maslv_goalDisposition = maslt_GoalDisposition::masle_Achieving;
        }

        // if (currentValue < goalSpec.minimum) then ...
        // elsif (currentValue > goalSpec.maximum) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(28);
          if ( maslv_currentValue < maslv_goalSpec->get_masla_minimum() )
          {

            // goalDisposition := Tracking::GoalDisposition.Increase;
            {
              ::SWA::Stack::ExecutingStatement statement(29);
              maslv_goalDisposition = maslt_GoalDisposition::masle_Increase;
            }
          }
          else if ( maslv_currentValue > maslv_goalSpec->get_masla_maximum() )
          {

            // goalDisposition := Tracking::GoalDisposition.Decrease;
            {
              ::SWA::Stack::ExecutingStatement statement(31);
              maslv_goalDisposition = maslt_GoalDisposition::masle_Decrease;
            }
          }
        }

        // if (goalSpec.criteriaType = Tracking::GoalCriteria.Pace) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(36);
          if ( maslv_goalSpec->get_masla_criteriaType() == maslt_GoalCriteria::masle_Pace )
          {

            // if (goalDisposition = Tracking::GoalDisposition.Increase) then ...
            // elsif (goalDisposition = Tracking::GoalDisposition.Decrease) then ...
            {
              ::SWA::Stack::ExecutingStatement statement(37);
              if ( maslv_goalDisposition == maslt_GoalDisposition::masle_Increase )
              {

                // goalDisposition := Tracking::GoalDisposition.Decrease;
                {
                  ::SWA::Stack::ExecutingStatement statement(38);
                  maslv_goalDisposition = maslt_GoalDisposition::masle_Decrease;
                }
              }
              else if ( maslv_goalDisposition == maslt_GoalDisposition::masle_Decrease )
              {

                // goalDisposition := Tracking::GoalDisposition.Increase;
                {
                  ::SWA::Stack::ExecutingStatement statement(40);
                  maslv_goalDisposition = maslt_GoalDisposition::masle_Increase;
                }
              }
            }
          }
        }

        // return goalDisposition;
        {
          ::SWA::Stack::ExecutingStatement statement(44);
          return maslv_goalDisposition;
        }
      }
    }
  }

}
