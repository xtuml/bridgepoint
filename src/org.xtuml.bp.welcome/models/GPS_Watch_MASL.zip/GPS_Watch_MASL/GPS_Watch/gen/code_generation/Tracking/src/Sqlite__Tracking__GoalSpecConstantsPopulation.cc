//
// File: Sqlite__Tracking__GoalSpecConstantsPopulation.cc
//
#include "Sqlite__Tracking__GoalSpecConstantsPopulation.hh"
#include "__Tracking__GoalSpecConstants.hh"
#include "boost/bind.hpp"
#include "boost/signals2.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_GoalSpecConstantsPopulation::maslo_GoalSpecConstantsPopulation ( )
    {
    }

    maslo_GoalSpecConstantsPopulation::~maslo_GoalSpecConstantsPopulation ( )
    {
    }

    void maslo_GoalSpecConstantsPopulation::initialise ( )
    {
      mapper->initialise();
    }

    maslo_GoalSpecConstantsPopulation& maslo_GoalSpecConstantsPopulation::getPopulation ( )
    {
      static maslo_GoalSpecConstantsPopulation population;
      return population;
    }

    bool maslo_GoalSpecConstantsPopulation::registered = maslo_GoalSpecConstantsPopulation::registerSingleton( &maslo_GoalSpecConstantsPopulation::getPopulation );

    ::boost::signals2::connection maslo_GoalSpecConstantsPopulation::initialised = ::SWA::Process::getInstance().registerInitialisingListener( ::boost::bind( &maslo_GoalSpecConstantsPopulation::initialise, ::boost::bind( &maslo_GoalSpecConstantsPopulation::getPopulation ) ) );

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> maslo_GoalSpecConstantsPopulation::findObject ( const ::SWA::IdType& obj )
    {
      return mapper->find( obj );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> > maslo_GoalSpecConstantsPopulation::findObject ( const MapperType::PsObjectIdSet& obj )
    {
      MapperType::PsObjectPtrSet objectSet = mapper->find( obj );
      return ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> >( objectSet.begin(), objectSet.end(), true );
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> maslo_GoalSpecConstantsPopulation::createInstance ( int32_t masla_id,
                                                                                                                     int32_t masla_GoalSpecOrigin )
    {
      return mapper->createInstance( masla_id, masla_GoalSpecOrigin );
    }

    void maslo_GoalSpecConstantsPopulation::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpecConstants> instance )
    {
      {
      }
      mapper->deleteInstance( instance );
    }

  }
}
