//
// File: Inspector_types__Format.cc
//
#include "Format_OOA/__Format_types.hh"
#include "inspector/BufferedIO.hh"

namespace Inspector
{
  template<>
  void BufferedOutputStream::write< ::masld_Format::maslt_justify> ( const ::masld_Format::maslt_justify& value )
  {
    write( static_cast<int>( value.getIndex() ) );
  }

  template<>
  void BufferedInputStream::read< ::masld_Format::maslt_justify> ( ::masld_Format::maslt_justify& value )
  {
    int index;
    read( index );
    value = ::masld_Format::maslt_justify( ::masld_Format::maslt_justify::Index( index ) );
  }

  template<>
  void BufferedOutputStream::write< ::masld_Format::maslt_base_case> ( const ::masld_Format::maslt_base_case& value )
  {
    write( static_cast<int>( value.getIndex() ) );
  }

  template<>
  void BufferedInputStream::read< ::masld_Format::maslt_base_case> ( ::masld_Format::maslt_base_case& value )
  {
    int index;
    read( index );
    value = ::masld_Format::maslt_base_case( ::masld_Format::maslt_base_case::Index( index ) );
  }

  template<>
  void BufferedOutputStream::write< ::masld_Format::maslt_rounding> ( const ::masld_Format::maslt_rounding& value )
  {
    write( static_cast<int>( value.getIndex() ) );
  }

  template<>
  void BufferedInputStream::read< ::masld_Format::maslt_rounding> ( ::masld_Format::maslt_rounding& value )
  {
    int index;
    read( index );
    value = ::masld_Format::maslt_rounding( ::masld_Format::maslt_rounding::Index( index ) );
  }

  template<>
  void BufferedOutputStream::write< ::masld_Format::maslt_duration_field> ( const ::masld_Format::maslt_duration_field& value )
  {
    write( static_cast<int>( value.getIndex() ) );
  }

  template<>
  void BufferedInputStream::read< ::masld_Format::maslt_duration_field> ( ::masld_Format::maslt_duration_field& value )
  {
    int index;
    read( index );
    value = ::masld_Format::maslt_duration_field( ::masld_Format::maslt_duration_field::Index( index ) );
  }

  template<>
  void BufferedOutputStream::write< ::masld_Format::maslt_timestamp_field> ( const ::masld_Format::maslt_timestamp_field& value )
  {
    write( static_cast<int>( value.getIndex() ) );
  }

  template<>
  void BufferedInputStream::read< ::masld_Format::maslt_timestamp_field> ( ::masld_Format::maslt_timestamp_field& value )
  {
    int index;
    read( index );
    value = ::masld_Format::maslt_timestamp_field( ::masld_Format::maslt_timestamp_field::Index( index ) );
  }

}
