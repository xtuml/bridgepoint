//
// File: Transient__HeartRateMonitor__HeartRateConstants.cc
//
#include "Transient__HeartRateMonitor__HeartRateConstants.hh"
#include <stdint.h>

namespace transient
{
  namespace masld_HeartRateMonitor
  {
    maslo_HeartRateConstants::maslo_HeartRateConstants ( int32_t masla_id,
                                                         int32_t masla_HeartRateAveragingWindow,
                                                         int32_t masla_HeartRateSamplingPeriod )
      : architectureId(getNextArchId()),
        masla_id(masla_id),
        masla_HeartRateAveragingWindow(masla_HeartRateAveragingWindow),
        masla_HeartRateSamplingPeriod(masla_HeartRateSamplingPeriod)
    {
    }

  }
}
