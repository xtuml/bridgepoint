//
// File: __GPS_Watch__HeartRateMonitor__HRChange__heartRateChanged.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_terminators.hh"
#include "Tracking_OOA/__Tracking_services.hh"
#include "__GPS_Watch__HeartRateMonitor__HRChange__heartRateChanged.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"

namespace maslp_GPS_Watch
{
  namespace masld_HeartRateMonitor
  {
    namespace maslb_HRChange
    {
      bool register_masls_heartRateChanged = ::masld_HeartRateMonitor::maslb_HRChange::register_masls_heartRateChanged( &masls_heartRateChanged );

      void masls_heartRateChanged ( int32_t maslp_heartRate )
      {

        // begin ...
        // end;
        {
          ::SWA::Stack::EnteringTerminatorService enteringActionMarker(::masld_HeartRateMonitor::getDomain().getId(), ::masld_HeartRateMonitor::terminatorId_maslb_HRChange, ::masld_HeartRateMonitor::maslb_HRChange::serviceId_masls_heartRateChanged);
          ::SWA::Stack::DeclareParameter pm_maslp_heartRate(maslp_heartRate);
          ::SWA::Stack::EnteredAction enteredActionMarker;
          ::SWA::Stack::ExecutingStatement statement(2);
          {

            // Tracking::heartRateChanged(heartRate)
            {
              ::SWA::Stack::ExecutingStatement statement(3);
              ::masld_Tracking::interceptor_masls_heartRateChanged::instance().callService()( maslp_heartRate );
            }
          }
        }
      }

    }
  }
}
