//
// File: Sqlite__Tracking__WorkoutSessionMapper.cc
//
#include "Sqlite__Tracking__WorkoutSession.hh"
#include "Sqlite__Tracking__WorkoutSessionMapper.hh"
#include "Sqlite__Tracking__WorkoutSessionMapperSql.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_WorkoutSessionMapper::maslo_WorkoutSessionMapper ( )
      : ::SQL::ObjectMapper< ::masld_Tracking::maslo_WorkoutSession,maslo_WorkoutSession>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_Tracking::maslo_WorkoutSession,maslo_WorkoutSession> >( new maslo_WorkoutSessionSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_WorkoutSessionMapper::~maslo_WorkoutSessionMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> maslo_WorkoutSessionMapper::createInstance ( const ::SWA::Timestamp& masla_startTime,
                                                                                                           double                  masla_accumulatedDistance )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_WorkoutSession::PrimaryKeyType>::value_type( masla_startTime ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_WorkoutSession> instance(new maslo_WorkoutSession(  uniqueId,
                           masla_startTime,
                           masla_accumulatedDistance ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_WorkoutSessionMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> instance )
    {
      ::SQL::ObjectMapper< ::masld_Tracking::maslo_WorkoutSession,maslo_WorkoutSession>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_WorkoutSession>()->getPrimaryKey() );
    }

    bool maslo_WorkoutSessionMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
