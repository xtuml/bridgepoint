//
// File: __Tracking__TrackLog.cc
//
#include "__Tracking__LapMarker.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__TrackLogPopulation.hh"
#include "__Tracking__TrackPoint.hh"
#include "__Tracking__WorkoutSession.hh"
#include <cstddef>
#include <iostream>
#include "swa/Bag.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  ::SWA::ObjectPtr<maslo_TrackLog> maslo_TrackLog::getInstance ( ::SWA::IdType id )
  {
    return maslo_TrackLogPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_TrackLog::getNextArchId ( )
  {
    return maslo_TrackLogPopulation::getSingleton().getNextArchId();
  }

  maslo_TrackLog::maslo_TrackLog ( )
    : isDeletedFlag()
  {
  }

  maslo_TrackLog::~maslo_TrackLog ( )
  {
  }

  ::SWA::ObjectPtr<maslo_TrackLog> maslo_TrackLog::createInstance ( const ::SWA::Timestamp& masla_session_startTime )
  {
    return maslo_TrackLogPopulation::getSingleton().createInstance( masla_session_startTime );
  }

  void maslo_TrackLog::deleteInstance ( )
  {
    if ( count_R1_has_first_TrackPoint() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R1 still linked" );
    if ( count_R3_has_last_TrackPoint() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R3 still linked" );
    if ( count_R5_has_laps_defined_by_LapMarker() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R5 still linked" );
    if ( count_R4_represents_path_for_WorkoutSession() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R4 still linked" );
    maslo_TrackLogPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_TrackLog>( this ) );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_TrackLog::getPopulationSize ( )
  {
    return maslo_TrackLogPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_TrackLog> > maslo_TrackLog::findAll ( )
  {
    return maslo_TrackLogPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_TrackLog> maslo_TrackLog::findOne ( )
  {
    return maslo_TrackLogPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_TrackLog> maslo_TrackLog::findOnly ( )
  {
    return maslo_TrackLogPopulation::getSingleton().findOnly();
  }

  ::std::size_t maslo_TrackLog::count_R1_has_first_TrackPoint ( ) const
  {
    return navigate_R1_has_first_TrackPoint() == ::SWA::Null ? 0
                                                             : 1;
  }

  void maslo_TrackLog::checked_link_R1_has_first_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs )
  {
    if ( rhs->get_masla_session_startTime() != get_masla_session_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R1_has_first_TrackPoint( rhs );
  }

  void maslo_TrackLog::unlink_R1_has_first_TrackPoint ( )
  {
    const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs = navigate_R1_has_first_TrackPoint();
    if ( rhs ) unlink_R1_has_first_TrackPoint( rhs );
  }

  ::std::size_t maslo_TrackLog::count_R3_has_last_TrackPoint ( ) const
  {
    return navigate_R3_has_last_TrackPoint() == ::SWA::Null ? 0
                                                            : 1;
  }

  void maslo_TrackLog::checked_link_R3_has_last_TrackPoint ( const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs )
  {
    if ( rhs->get_masla_session_startTime() != get_masla_session_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R3_has_last_TrackPoint( rhs );
  }

  void maslo_TrackLog::unlink_R3_has_last_TrackPoint ( )
  {
    const ::SWA::ObjectPtr<maslo_TrackPoint>& rhs = navigate_R3_has_last_TrackPoint();
    if ( rhs ) unlink_R3_has_last_TrackPoint( rhs );
  }

  ::std::size_t maslo_TrackLog::count_R5_has_laps_defined_by_LapMarker ( ) const
  {
    return navigate_R5_has_laps_defined_by_LapMarker().size();
  }

  void maslo_TrackLog::checked_link_R5_has_laps_defined_by_LapMarker ( const ::SWA::ObjectPtr<maslo_LapMarker>& rhs )
  {
    if ( rhs->get_masla_session_startTime() != get_masla_session_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R5_has_laps_defined_by_LapMarker( rhs );
  }

  void maslo_TrackLog::checked_link_R5_has_laps_defined_by_LapMarker ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_LapMarker> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_LapMarker> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it )
    {
      if ( (*it)->get_masla_session_startTime() != get_masla_session_startTime() )
      {
        throw ::SWA::ProgramError( "referential integrity failure" );
      }
    }
    link_R5_has_laps_defined_by_LapMarker( rhs );
  }

  void maslo_TrackLog::link_R5_has_laps_defined_by_LapMarker ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_LapMarker> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_LapMarker> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it ) link_R5_has_laps_defined_by_LapMarker( *it );
  }

  void maslo_TrackLog::unlink_R5_has_laps_defined_by_LapMarker ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_LapMarker> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_LapMarker> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it ) unlink_R5_has_laps_defined_by_LapMarker( *it );
  }

  void maslo_TrackLog::unlink_R5_has_laps_defined_by_LapMarker ( )
  {
    unlink_R5_has_laps_defined_by_LapMarker( navigate_R5_has_laps_defined_by_LapMarker() );
  }

  ::std::size_t maslo_TrackLog::count_R4_represents_path_for_WorkoutSession ( ) const
  {
    return navigate_R4_represents_path_for_WorkoutSession() == ::SWA::Null ? 0
                                                                           : 1;
  }

  void maslo_TrackLog::checked_link_R4_represents_path_for_WorkoutSession ( const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs )
  {
    if ( get_masla_session_startTime() != rhs->get_masla_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R4_represents_path_for_WorkoutSession( rhs );
  }

  void maslo_TrackLog::unlink_R4_represents_path_for_WorkoutSession ( )
  {
    const ::SWA::ObjectPtr<maslo_WorkoutSession>& rhs = navigate_R4_represents_path_for_WorkoutSession();
    if ( rhs ) unlink_R4_represents_path_for_WorkoutSession( rhs );
  }

  ::std::ostream& operator<< ( ::std::ostream&       stream,
                               const maslo_TrackLog& obj )
  {
    stream << "(";
    stream << obj.get_masla_session_startTime();
    stream << ")";
    return stream;
  }

}
