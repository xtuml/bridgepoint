//
// File: Sqlite__Tracking__Goal.hh
//
#ifndef Sqlite_Tracking_Goal_hh
#define Sqlite_Tracking_Goal_hh

#include "Tracking_OOA/__Tracking_types.hh"
#include "__Tracking__Goal.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <cstddef>
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_GoalSpec;
  class maslo_WorkoutSession;
  class maslo_Achievement;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_Goal
      : public ::masld_Tracking::maslo_Goal
    {

      // Type definitions
      public:
        typedef ::boost::tuple<int32_t,::SWA::Timestamp,int32_t> PrimaryKeyType;
        typedef ::boost::tuple<int32_t,::SWA::Timestamp,int32_t> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_Goal ( ::SWA::IdType architectureId );
        maslo_Goal ( ::SWA::IdType                                  architectureId,
                     const ::masld_Tracking::maslt_GoalDisposition& masla_disposition,
                     double                                         masla_startingPoint,
                     int32_t                                        masla_ID,
                     const ::SWA::EventTimers::TimerIdType&         masla_evaluationTimer,
                     const ::SWA::Timestamp&                        masla_session_startTime,
                     int32_t                                        masla_spec_sequenceNumber,
                     ::masld_Tracking::maslo_Goal::Type             currentState );


      // Setters for each object attribute
      public:
        virtual void set_masla_disposition ( const ::masld_Tracking::maslt_GoalDisposition& value )
        {
          this->masla_disposition = value;
          markAsModified();
        }
        virtual void set_masla_startingPoint ( double value )
        {
          this->masla_startingPoint = value;
          markAsModified();
        }
        void set_masla_ID ( int32_t value )
        {
          this->masla_ID = value;
          markAsModified();
        }
        virtual void set_masla_evaluationTimer ( const ::SWA::EventTimers::TimerIdType& value )
        {
          this->masla_evaluationTimer = value;
          markAsModified();
        }
        void set_masla_session_startTime ( const ::SWA::Timestamp& value )
        {
          this->masla_session_startTime = value;
          markAsModified();
        }
        void set_masla_spec_sequenceNumber ( int32_t value )
        {
          this->masla_spec_sequenceNumber = value;
          markAsModified();
        }
        virtual void setCurrentState ( ::masld_Tracking::maslo_Goal::Type newState )
        {
          currentState = newState;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual ::masld_Tracking::maslt_GoalDisposition get_masla_disposition ( ) const { return masla_disposition; }
        virtual double get_masla_startingPoint ( ) const { return masla_startingPoint; }
        virtual int32_t get_masla_ID ( ) const { return masla_ID; }
        virtual ::SWA::EventTimers::TimerIdType get_masla_evaluationTimer ( ) const { return masla_evaluationTimer; }
        virtual ::SWA::Timestamp get_masla_session_startTime ( ) const { return masla_session_startTime; }
        virtual int32_t get_masla_spec_sequenceNumber ( ) const { return masla_spec_sequenceNumber; }
        virtual ::masld_Tracking::maslo_Goal::Type getCurrentState ( ) const { return currentState; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Relationship Navigators
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> navigate_R9_specified_by_GoalSpec ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> navigate_R11_is_currently_executing_within_WorkoutSession ( ) const;
        virtual ::SWA::Set< ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> > navigate_R12_has_recorded_Achievement ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> navigate_R13_was_executed_within_WorkoutSession ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement> navigate_R14_has_open_Achievement ( ) const;


      // Relationship Counts
      public:
        virtual ::std::size_t count_R9_specified_by_GoalSpec ( ) const;
        virtual ::std::size_t count_R11_is_currently_executing_within_WorkoutSession ( ) const;
        virtual ::std::size_t count_R12_has_recorded_Achievement ( ) const;
        virtual ::std::size_t count_R13_was_executed_within_WorkoutSession ( ) const;
        virtual ::std::size_t count_R14_has_open_Achievement ( ) const;


      // Relationship Linkers
      public:
        virtual void link_R9_specified_by_GoalSpec ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& rhs );
        virtual void unlink_R9_specified_by_GoalSpec ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec>& rhs );
        virtual void link_R11_is_currently_executing_within_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );
        virtual void unlink_R11_is_currently_executing_within_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );
        virtual void link_R12_has_recorded_Achievement ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& rhs );
        virtual void unlink_R12_has_recorded_Achievement ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& rhs );
        virtual void link_R13_was_executed_within_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );
        virtual void unlink_R13_was_executed_within_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );
        virtual void link_R14_has_open_Achievement ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& rhs );
        virtual void unlink_R14_has_open_Achievement ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Achievement>& rhs );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        ::masld_Tracking::maslt_GoalDisposition masla_disposition;
        double masla_startingPoint;
        int32_t masla_ID;
        ::SWA::EventTimers::TimerIdType masla_evaluationTimer;
        ::SWA::Timestamp masla_session_startTime;
        int32_t masla_spec_sequenceNumber;
        ::masld_Tracking::maslo_Goal::Type currentState;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_Tracking_Goal_hh
