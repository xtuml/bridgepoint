//
// File: __Tracking__WorkoutTimer__stopped.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "__Tracking__Display.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/bind.hpp"
#include "boost/shared_ptr.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/navigate.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  void maslo_WorkoutTimer::state_maslst_stopped ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_WorkoutTimer, stateId_maslst_stopped);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(4);
      {

        // session : instance of WorkoutSession;
        ::SWA::ObjectPtr<maslo_WorkoutSession> maslv_session;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_session(0, maslv_session);

        // display : instance of Display;
        ::SWA::ObjectPtr<maslo_Display> maslv_display;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_display(1, maslv_display);

        // session := this -> R8.acts_as_the_stopwatch_for.WorkoutSession;
        {
          ::SWA::Stack::ExecutingStatement statement(6);
          maslv_session = ::SWA::navigate_one<maslo_WorkoutSession>( ::SWA::ObjectPtr<maslo_WorkoutTimer>( this ), ::boost::bind( &maslo_WorkoutTimer::navigate_R8_acts_as_the_stopwatch_for_WorkoutSession, _1 ) );
        }

        // session.reset()
        {
          ::SWA::Stack::ExecutingStatement statement(7);
          maslv_session->masls_reset();
        }

        // UI~>setTime(this.time)
        {
          ::SWA::Stack::ExecutingStatement statement(10);
          maslb_UI::masls_setTime( ::SWA::ObjectPtr<maslo_WorkoutTimer>( this )->get_masla_time() );
        }

        // display := this -> R8.acts_as_the_stopwatch_for.WorkoutSession -> R7.current_status_indicated_on.Display;
        {
          ::SWA::Stack::ExecutingStatement statement(11);
          maslv_display = ::SWA::navigate_one<maslo_Display>( ::SWA::navigate_one<maslo_WorkoutSession>( ::SWA::ObjectPtr<maslo_WorkoutTimer>( this ), ::boost::bind( &maslo_WorkoutTimer::navigate_R8_acts_as_the_stopwatch_for_WorkoutSession, _1 ) ), ::boost::bind( &maslo_WorkoutSession::navigate_R7_current_status_indicated_on_Display, _1 ) );
        }

        // generate Display.refresh () to display;
        {
          ::SWA::Stack::ExecutingStatement statement(12);
          ::SWA::Process::getInstance().getEventQueue().addEvent( maslv_display->create_maslo_Display_maslev_refresh( objectId_maslo_WorkoutTimer, getArchitectureId() ) );
        }
      }
    }
  }

}
