//
// File: __LOG_interface.cc
//
#include "LOG_OOA/__LOG_interface.hh"
#include "swa/Domain.hh"
#include "swa/Process.hh"

namespace masld_LOG
{
  ::SWA::Domain& getDomain ( )
  {
    static ::SWA::Domain& domain = ::SWA::Process::getInstance().registerDomain( "LOG" );
    return domain;
  }

  bool initialiseInterface ( )
  {
    getDomain();
  }

  const bool interfaceInitialised = initialiseInterface();

}
