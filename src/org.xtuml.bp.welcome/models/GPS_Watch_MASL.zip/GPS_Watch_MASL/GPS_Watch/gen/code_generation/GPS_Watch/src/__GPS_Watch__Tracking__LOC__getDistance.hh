//
// File: __GPS_Watch__Tracking__LOC__getDistance.hh
//
#ifndef _GPS_Watch_Tracking_LOC_get_Distance_hh
#define _GPS_Watch_Tracking_LOC_get_Distance_hh

namespace maslp_GPS_Watch
{
  namespace masld_Tracking
  {
    namespace maslb_LOC
    {
      void masls_getDistance ( double& maslp_result,
                               double  maslp_toLong,
                               double  maslp_toLat,
                               double  maslp_fromLong,
                               double  maslp_fromLat );
    }
  }
}
#endif // _GPS_Watch_Tracking_LOC_get_Distance_hh
