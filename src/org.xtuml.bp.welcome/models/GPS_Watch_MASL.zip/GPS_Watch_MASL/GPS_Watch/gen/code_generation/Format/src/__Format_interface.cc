//
// File: __Format_interface.cc
//
#include "Format_OOA/__Format_interface.hh"
#include "swa/Domain.hh"
#include "swa/Process.hh"

namespace masld_Format
{
  ::SWA::Domain& getDomain ( )
  {
    static ::SWA::Domain& domain = ::SWA::Process::getInstance().registerDomain( "Format" );
    return domain;
  }

  bool initialiseInterface ( )
  {
    getDomain();
  }

  const bool interfaceInitialised = initialiseInterface();

}
