//
// File: __HeartRateMonitor_types.cc
//
