//
// File: __GPS_Watch__UI__TRACK__lapResetPressed.hh
//
#ifndef _GPS_Watch_UI_TRACK_lap_Reset_Pressed_hh
#define _GPS_Watch_UI_TRACK_lap_Reset_Pressed_hh

namespace maslp_GPS_Watch
{
  namespace masld_UI
  {
    namespace maslb_TRACK
    {
      void masls_lapResetPressed ( );
    }
  }
}
#endif // _GPS_Watch_UI_TRACK_lap_Reset_Pressed_hh
