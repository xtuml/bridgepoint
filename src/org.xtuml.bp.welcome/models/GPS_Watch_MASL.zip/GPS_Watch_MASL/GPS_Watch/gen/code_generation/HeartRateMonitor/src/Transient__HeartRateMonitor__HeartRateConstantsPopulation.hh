//
// File: Transient__HeartRateMonitor__HeartRateConstantsPopulation.hh
//
#ifndef Transient_Heart_Rate_Monitor_Heart_Rate_Constants_Population_hh
#define Transient_Heart_Rate_Monitor_Heart_Rate_Constants_Population_hh

#include "__HeartRateMonitor__HeartRateConstants.hh"
#include "__HeartRateMonitor__HeartRateConstantsPopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace transient
{
  namespace masld_HeartRateMonitor
  {
    class maslo_HeartRateConstantsPopulation
      : public TransientPopulation< ::masld_HeartRateMonitor::maslo_HeartRateConstants,::masld_HeartRateMonitor::maslo_HeartRateConstantsPopulation>
    {

      // Instance Creation
      private:
        maslo_HeartRateConstantsPopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateConstants> createInstance ( int32_t masla_id,
                                                                                                       int32_t masla_HeartRateAveragingWindow,
                                                                                                       int32_t masla_HeartRateSamplingPeriod );


      // Singleton Registration
      public:
        static maslo_HeartRateConstantsPopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateConstants> > masla_id_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateConstants> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateConstants> instance );
      protected:
        bool exists_masla_id ( int32_t masla_id ) const;


    };
  }
}
#endif // Transient_Heart_Rate_Monitor_Heart_Rate_Constants_Population_hh
