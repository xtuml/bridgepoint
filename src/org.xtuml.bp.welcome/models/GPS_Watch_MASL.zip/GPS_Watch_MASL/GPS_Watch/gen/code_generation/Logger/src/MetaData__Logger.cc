//
// File: MetaData__Logger.cc
//
#include "Logger_OOA/MetaData__Logger.hh"
#include "Logger_OOA/__Logger_interface.hh"
#include "Logger_OOA/__Logger_types.hh"
#include "metadata/MetaData.hh"
#include "swa/Domain.hh"
#include <vector>

namespace 
{
  namespace init_masld_Logger
  {
    ::SWA::EnumerateMetaData get_maslt_Priority_MetaData ( );
    ::SWA::ServiceMetaData get_masls_log_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_log_MetaData ( );
    ::SWA::ServiceMetaData get_masls_trace_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_trace_MetaData ( );
    ::SWA::ServiceMetaData get_masls_debug_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_debug_MetaData ( );
    ::SWA::ServiceMetaData get_masls_information_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_information_MetaData ( );
    ::SWA::ServiceMetaData get_masls_notice_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_notice_MetaData ( );
    ::SWA::ServiceMetaData get_masls_warning_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_warning_MetaData ( );
    ::SWA::ServiceMetaData get_masls_error_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_error_MetaData ( );
    ::SWA::ServiceMetaData get_masls_critical_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_critical_MetaData ( );
    ::SWA::ServiceMetaData get_masls_fatal_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_fatal_MetaData ( );
    ::SWA::ServiceMetaData get_masls_setLogLevel_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_setLogLevel_MetaData ( );
    ::SWA::ServiceMetaData get_masls_printLoggers_MetaData ( );
    ::SWA::DomainMetaData initDomainMetaData ( )
    {
      ::SWA::DomainMetaData domain(::masld_Logger::getDomain().getId(), "Logger", false);
      domain.addEnumerate( get_maslt_Priority_MetaData() );
      domain.addService( get_masls_log_MetaData() );
      domain.addService( get_masls_overload1_log_MetaData() );
      domain.addService( get_masls_trace_MetaData() );
      domain.addService( get_masls_overload1_trace_MetaData() );
      domain.addService( get_masls_debug_MetaData() );
      domain.addService( get_masls_overload1_debug_MetaData() );
      domain.addService( get_masls_information_MetaData() );
      domain.addService( get_masls_overload1_information_MetaData() );
      domain.addService( get_masls_notice_MetaData() );
      domain.addService( get_masls_overload1_notice_MetaData() );
      domain.addService( get_masls_warning_MetaData() );
      domain.addService( get_masls_overload1_warning_MetaData() );
      domain.addService( get_masls_error_MetaData() );
      domain.addService( get_masls_overload1_error_MetaData() );
      domain.addService( get_masls_critical_MetaData() );
      domain.addService( get_masls_overload1_critical_MetaData() );
      domain.addService( get_masls_fatal_MetaData() );
      domain.addService( get_masls_overload1_fatal_MetaData() );
      domain.addService( get_masls_setLogLevel_MetaData() );
      domain.addService( get_masls_overload1_setLogLevel_MetaData() );
      domain.addService( get_masls_printLoggers_MetaData() );
      return domain;
    }

    ::SWA::DomainMetaData& getDomainMetaData ( )
    {
      static ::SWA::DomainMetaData domain = initDomainMetaData();
      return domain;
    }

    bool registered = ::SWA::ProcessMetaData::getProcess().addDomain( ::masld_Logger::getDomain().getId(), &getDomainMetaData );

    ::SWA::EnumerateMetaData get_maslt_Priority_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Logger::typeId_maslt_Priority, "Priority");
      enumeration.addValue( ::masld_Logger::maslt_Priority::masle_Fatal.getValue(), "Fatal" );
      enumeration.addValue( ::masld_Logger::maslt_Priority::masle_Critical.getValue(), "Critical" );
      enumeration.addValue( ::masld_Logger::maslt_Priority::masle_Error.getValue(), "Error" );
      enumeration.addValue( ::masld_Logger::maslt_Priority::masle_Warning.getValue(), "Warning" );
      enumeration.addValue( ::masld_Logger::maslt_Priority::masle_Notice.getValue(), "Notice" );
      enumeration.addValue( ::masld_Logger::maslt_Priority::masle_Information.getValue(), "Information" );
      enumeration.addValue( ::masld_Logger::maslt_Priority::masle_Debug.getValue(), "Debug" );
      enumeration.addValue( ::masld_Logger::maslt_Priority::masle_Trace.getValue(), "Trace" );
      return enumeration;
    }

    ::SWA::ServiceMetaData get_masls_log_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_log, ::SWA::ServiceMetaData::Domain, "log", ::std::vector<int>( lines, lines + 0 ), "log.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "priority", "Logger::Priority", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Logger::getDomain().getId(), ::masld_Logger::typeId_maslt_Priority ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_log_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_overload1_log, ::SWA::ServiceMetaData::Domain, "log", ::std::vector<int>( lines, lines + 0 ), "log.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "priority", "Logger::Priority", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Logger::getDomain().getId(), ::masld_Logger::typeId_maslt_Priority ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "logger", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_trace_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_trace, ::SWA::ServiceMetaData::Domain, "trace", ::std::vector<int>( lines, lines + 0 ), "trace.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_trace_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_overload1_trace, ::SWA::ServiceMetaData::Domain, "trace", ::std::vector<int>( lines, lines + 0 ), "trace.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "logger", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_debug_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_debug, ::SWA::ServiceMetaData::Domain, "debug", ::std::vector<int>( lines, lines + 0 ), "debug.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_debug_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_overload1_debug, ::SWA::ServiceMetaData::Domain, "debug", ::std::vector<int>( lines, lines + 0 ), "debug.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "logger", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_information_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_information, ::SWA::ServiceMetaData::Domain, "information", ::std::vector<int>( lines, lines + 0 ), "information.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_information_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_overload1_information, ::SWA::ServiceMetaData::Domain, "information", ::std::vector<int>( lines, lines + 0 ), "information.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "logger", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_notice_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_notice, ::SWA::ServiceMetaData::Domain, "notice", ::std::vector<int>( lines, lines + 0 ), "notice.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_notice_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_overload1_notice, ::SWA::ServiceMetaData::Domain, "notice", ::std::vector<int>( lines, lines + 0 ), "notice.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "logger", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_warning_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_warning, ::SWA::ServiceMetaData::Domain, "warning", ::std::vector<int>( lines, lines + 0 ), "warning.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_warning_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_overload1_warning, ::SWA::ServiceMetaData::Domain, "warning", ::std::vector<int>( lines, lines + 0 ), "warning.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "logger", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_error_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_error, ::SWA::ServiceMetaData::Domain, "error", ::std::vector<int>( lines, lines + 0 ), "error.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_error_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_overload1_error, ::SWA::ServiceMetaData::Domain, "error", ::std::vector<int>( lines, lines + 0 ), "error.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "logger", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_critical_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_critical, ::SWA::ServiceMetaData::Domain, "critical", ::std::vector<int>( lines, lines + 0 ), "critical.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_critical_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_overload1_critical, ::SWA::ServiceMetaData::Domain, "critical", ::std::vector<int>( lines, lines + 0 ), "critical.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "logger", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_fatal_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_fatal, ::SWA::ServiceMetaData::Domain, "fatal", ::std::vector<int>( lines, lines + 0 ), "fatal.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_fatal_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_overload1_fatal, ::SWA::ServiceMetaData::Domain, "fatal", ::std::vector<int>( lines, lines + 0 ), "fatal.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "logger", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "message", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_setLogLevel_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_setLogLevel, ::SWA::ServiceMetaData::Domain, "setLogLevel", ::std::vector<int>( lines, lines + 0 ), "setLogLevel.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "priority", "Logger::Priority", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Logger::getDomain().getId(), ::masld_Logger::typeId_maslt_Priority ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_setLogLevel_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_overload1_setLogLevel, ::SWA::ServiceMetaData::Domain, "setLogLevel", ::std::vector<int>( lines, lines + 0 ), "setLogLevel.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "logger", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "priority", "Logger::Priority", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Logger::getDomain().getId(), ::masld_Logger::typeId_maslt_Priority ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_printLoggers_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Logger::serviceId_masls_printLoggers, ::SWA::ServiceMetaData::Domain, "printLoggers", ::std::vector<int>( lines, lines + 0 ), "printLoggers.svc", "");
      return service;
    }

  }
}
