//
// File: __GPS_Watch__UI__TRACK__modePressed.hh
//
#ifndef _GPS_Watch_UI_TRACK_mode_Pressed_hh
#define _GPS_Watch_UI_TRACK_mode_Pressed_hh

namespace maslp_GPS_Watch
{
  namespace masld_UI
  {
    namespace maslb_TRACK
    {
      void masls_modePressed ( );
    }
  }
}
#endif // _GPS_Watch_UI_TRACK_mode_Pressed_hh
