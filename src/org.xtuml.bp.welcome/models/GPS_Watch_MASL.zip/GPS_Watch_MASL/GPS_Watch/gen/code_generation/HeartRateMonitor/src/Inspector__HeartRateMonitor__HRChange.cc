//
// File: Inspector__HeartRateMonitor__HRChange.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor_terminators.hh"
#include "Inspector__HeartRateMonitor__HRChange.hh"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include "swa/Stack.hh"

namespace Inspector
{
  namespace masld_HeartRateMonitor
  {
    namespace maslb_HRChange
    {
      class masls_heartRateChangedHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_heartRateChangedInvoker
      {

        public:
          masls_heartRateChangedInvoker ( CommunicationChannel& channel )
            : maslp_heartRate()
 { channel >> maslp_heartRate; }
          void operator() ( ) { ::masld_HeartRateMonitor::maslb_HRChange::masls_heartRateChanged( maslp_heartRate ); }


        private:
          int32_t maslp_heartRate;


      };
      Callable masls_heartRateChangedHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_heartRateChangedInvoker( channel );
      }

      void masls_heartRateChangedHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                           const ::SWA::StackFrame& frame ) const
      {

        // Write heartRate
        channel << frame.getParameters()[0].getValue<int32_t>();

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
      }

      maslb_HRChangeHandler::maslb_HRChangeHandler ( )
      {
        registerServiceHandler( ::masld_HeartRateMonitor::maslb_HRChange::serviceId_masls_heartRateChanged, ::boost::shared_ptr<ActionHandler>( new masls_heartRateChangedHandler() ) );
      }

    }
  }
}
