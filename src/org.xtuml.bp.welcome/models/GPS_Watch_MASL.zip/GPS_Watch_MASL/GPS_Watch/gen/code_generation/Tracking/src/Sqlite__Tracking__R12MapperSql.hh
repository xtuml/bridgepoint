//
// File: Sqlite__Tracking__R12MapperSql.hh
//
#ifndef Sqlite_Tracking_R_12_Mapper_Sql_hh
#define Sqlite_Tracking_R_12_Mapper_Sql_hh

#include "Sqlite__Tracking__R12Mapper.hh"
#include "sqlite/PreparedStatement.hh"
#include <string>
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Tracking
  {
    class RelationshipR12SqlGenerator
      : public RelationshipR12Mapper::RelSqlGeneratorType
    {

      // Constructor / Destructor
      public:
        RelationshipR12SqlGenerator ( );
        void initialise ( );


      // Getter methods
      public:
        const ::std::string& getTableName ( ) const;
        const ::std::string getDomainName ( ) const;
        const ::std::string getLhsColumnName ( ) const;
        const ::std::string getRhsColumnName ( ) const;
        const ::std::string& getRelationshipName ( ) const;


      // execute
      public:
        ::SWA::IdType executeGetRowCount ( ) const;


      // Commit methods 
      public:
        void commitLink ( const LinkedPairType& linkObjects ) const;
        void commitUnlink ( const LinkedPairType& unlinkObjects ) const;


      // Load methods
      public:
        void loadAll ( LhsToRhsContainerType& lhsToRhsLinkSet,
                       RhsToLhsContainerType& rhsToLhsLinkSet ) const;
        void loadLhs ( const ::SWA::IdType&   rhsIdentity,
                       LhsToRhsContainerType& lhsToRhsLinkSet,
                       RhsToLhsContainerType& rhsToLhsLinkSet ) const;
        void loadRhs ( const ::SWA::IdType&   lhsIdentity,
                       LhsToRhsContainerType& lhsToRhsLinkSet,
                       RhsToLhsContainerType& rhsToLhsLinkSet ) const;


      // Attributes
      private:
        ::std::string tableName;
        ::std::string relationshipName;
        PreparedStatement pepreparedLink;
        PreparedStatement pepreparedUnlink;


    };
  }
}
#endif // Sqlite_Tracking_R_12_Mapper_Sql_hh
