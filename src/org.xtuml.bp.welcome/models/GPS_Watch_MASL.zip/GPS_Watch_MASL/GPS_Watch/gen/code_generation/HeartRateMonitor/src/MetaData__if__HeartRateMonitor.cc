//
// File: MetaData__if__HeartRateMonitor.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "metadata/MetaData.hh"
#include "swa/Domain.hh"

namespace 
{
  namespace init_interface_masld_HeartRateMonitor
  {
    ::SWA::DomainMetaData initDomainMetaData ( )
    {
      ::SWA::DomainMetaData domain(::masld_HeartRateMonitor::getDomain().getId(), "HeartRateMonitor", true);
      return domain;
    }

    ::SWA::DomainMetaData& getDomainMetaData ( )
    {
      static ::SWA::DomainMetaData domain = initDomainMetaData();
      return domain;
    }

    bool registered = ::SWA::ProcessMetaData::getProcess().addDomain( ::masld_HeartRateMonitor::getDomain().getId(), &getDomainMetaData );

  }
}
