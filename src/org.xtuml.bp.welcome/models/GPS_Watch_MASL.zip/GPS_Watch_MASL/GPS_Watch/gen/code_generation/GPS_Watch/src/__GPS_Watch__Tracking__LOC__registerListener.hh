//
// File: __GPS_Watch__Tracking__LOC__registerListener.hh
//
#ifndef _GPS_Watch_Tracking_LOC_register_Listener_hh
#define _GPS_Watch_Tracking_LOC_register_Listener_hh

namespace maslp_GPS_Watch
{
  namespace masld_Tracking
  {
    namespace maslb_LOC
    {
      void masls_registerListener ( );
    }
  }
}
#endif // _GPS_Watch_Tracking_LOC_register_Listener_hh
