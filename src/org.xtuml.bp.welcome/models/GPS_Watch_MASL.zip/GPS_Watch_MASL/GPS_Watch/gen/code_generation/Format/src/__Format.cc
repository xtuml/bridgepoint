//
// File: __Format.cc
//
#include "Format_OOA/__Format_interface.hh"
#include "swa/Domain.hh"

namespace masld_Format
{
  bool initialiseDomain ( )
  {
    getDomain().setInterface( false );
    return true;
  }

  const bool domainInitialised = initialiseDomain();

}
