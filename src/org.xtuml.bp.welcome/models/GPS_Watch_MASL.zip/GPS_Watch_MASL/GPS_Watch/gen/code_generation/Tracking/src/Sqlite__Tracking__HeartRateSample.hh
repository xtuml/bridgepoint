//
// File: Sqlite__Tracking__HeartRateSample.hh
//
#ifndef Sqlite_Tracking_Heart_Rate_Sample_hh
#define Sqlite_Tracking_Heart_Rate_Sample_hh

#include "__Tracking__HeartRateSample.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_WorkoutSession;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_HeartRateSample
      : public ::masld_Tracking::maslo_HeartRateSample
    {

      // Type definitions
      public:
        typedef ::boost::tuple<int32_t,::SWA::Timestamp> PrimaryKeyType;
        typedef ::boost::tuple<int32_t,::SWA::Timestamp> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_HeartRateSample ( ::SWA::IdType architectureId );
        maslo_HeartRateSample ( ::SWA::IdType           architectureId,
                                int32_t                 masla_heartRate,
                                int32_t                 masla_time,
                                const ::SWA::Timestamp& masla_session_startTime );


      // Setters for each object attribute
      public:
        virtual void set_masla_heartRate ( int32_t value )
        {
          this->masla_heartRate = value;
          markAsModified();
        }
        void set_masla_time ( int32_t value )
        {
          this->masla_time = value;
          markAsModified();
        }
        void set_masla_session_startTime ( const ::SWA::Timestamp& value )
        {
          this->masla_session_startTime = value;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_heartRate ( ) const { return masla_heartRate; }
        virtual int32_t get_masla_time ( ) const { return masla_time; }
        virtual ::SWA::Timestamp get_masla_session_startTime ( ) const { return masla_session_startTime; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Relationship Navigators
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> navigate_R6_was_collected_during_WorkoutSession ( ) const;


      // Relationship Counts
      public:
        virtual ::std::size_t count_R6_was_collected_during_WorkoutSession ( ) const;


      // Relationship Linkers
      public:
        virtual void link_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );
        virtual void unlink_R6_was_collected_during_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_heartRate;
        int32_t masla_time;
        ::SWA::Timestamp masla_session_startTime;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_Tracking_Heart_Rate_Sample_hh
