//
// File: __UI_private_services.hh
//
#ifndef _UI_private_services_hh
#define _UI_private_services_hh

#include "swa/ServiceInterceptor.hh"

namespace masld_UI
{
  void masls_RunTestCase ( );
  class masls_RunTestCase_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_RunTestCase_tag,void()> interceptor_masls_RunTestCase;
  void masls_createGoals_1 ( );
  class masls_createGoals_1_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_createGoals_1_tag,void()> interceptor_masls_createGoals_1;
  void masls_init ( );
  class masls_init_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_init_tag,void()> interceptor_masls_init;
  void masls_sendLapResetPressed ( );
  class masls_sendLapResetPressed_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_sendLapResetPressed_tag,void()> interceptor_masls_sendLapResetPressed;
  void masls_sendLightPressed ( );
  class masls_sendLightPressed_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_sendLightPressed_tag,void()> interceptor_masls_sendLightPressed;
  void masls_sendModePressed ( );
  class masls_sendModePressed_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_sendModePressed_tag,void()> interceptor_masls_sendModePressed;
  void masls_sendStartStopPressed ( );
  class masls_sendStartStopPressed_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_sendStartStopPressed_tag,void()> interceptor_masls_sendStartStopPressed;
  void masls_sendTargetPressed ( );
  class masls_sendTargetPressed_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_sendTargetPressed_tag,void()> interceptor_masls_sendTargetPressed;
}
#endif // _UI_private_services_hh
