//
// File: Transient__Tracking__Display.hh
//
#ifndef Transient_Tracking_Display_hh
#define Transient_Tracking_Display_hh

#include "__Tracking__Display.hh"
#include <cstddef>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"
#include "transient/ToOneRelationship.hh"

namespace masld_Tracking
{
  class maslo_WorkoutSession;
}
namespace transient
{
  namespace masld_Tracking
  {
    class maslo_WorkoutSession;
  }
  namespace masld_Tracking
  {
    class maslo_Display
      : public ::masld_Tracking::maslo_Display
    {

      // Constructors and Destructors
      public:
        maslo_Display ( const ::SWA::Timestamp&               masla_session_startTime,
                        ::masld_Tracking::maslo_Display::Type currentState );


      // Setters for each object attribute
      public:
        virtual void setCurrentState ( ::masld_Tracking::maslo_Display::Type newState ) { currentState = newState; }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual ::SWA::Timestamp get_masla_session_startTime ( ) const { return masla_session_startTime; }
        virtual ::masld_Tracking::maslo_Display::Type getCurrentState ( ) const { return currentState; }


      // Relationship Navigators
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession> navigate_R7_indicates_current_status_of_WorkoutSession ( ) const;


      // Relationship Counters
      public:
        virtual ::std::size_t count_R7_indicates_current_status_of_WorkoutSession ( ) const;


      // Relationship Linkers
      public:
        virtual void link_R7_indicates_current_status_of_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );
        virtual void unlink_R7_indicates_current_status_of_WorkoutSession ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>& rhs );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        ::SWA::Timestamp masla_session_startTime;
        ::masld_Tracking::maslo_Display::Type currentState;


      // Relationship Getters
      public:
        ToOneRelationship<maslo_WorkoutSession>& get_R7_indicates_current_status_of_WorkoutSession ( );
        const ToOneRelationship<maslo_WorkoutSession>& get_R7_indicates_current_status_of_WorkoutSession ( ) const;


      // Storage for each relationship
      private:
        ToOneRelationship<maslo_WorkoutSession> R7_indicates_current_status_of_WorkoutSession;


    };
  }
}
#endif // Transient_Tracking_Display_hh
