//
// File: MetaData__GPS_Watch.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_terminators.hh"
#include "Tracking_OOA/MetaData__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "Tracking_OOA/__Tracking_terminators.hh"
#include "UI_OOA/MetaData__UI.hh"
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_terminators.hh"
#include "metadata/MetaData.hh"
#include "swa/Domain.hh"
#include <vector>

namespace 
{
  namespace init_maslp_GPS_Watch
  {
    namespace masld_HeartRateMonitor
    {
      namespace maslb_HRChange
      {
        ::SWA::ServiceMetaData get_masls_heartRateChanged_MetaData ( );
      }
    }
    namespace masld_Tracking
    {
      namespace maslb_HR
      {
        ::SWA::ServiceMetaData get_masls_registerListener_MetaData ( );
        ::SWA::ServiceMetaData get_masls_unregisterListener_MetaData ( );
      }
      namespace maslb_LOC
      {
        ::SWA::ServiceMetaData get_masls_getDistance_MetaData ( );
        ::SWA::ServiceMetaData get_masls_getLocation_MetaData ( );
        ::SWA::ServiceMetaData get_masls_registerListener_MetaData ( );
        ::SWA::ServiceMetaData get_masls_unregisterListener_MetaData ( );
      }
      namespace maslb_UI
      {
        ::SWA::ServiceMetaData get_masls_setData_MetaData ( );
        ::SWA::ServiceMetaData get_masls_setIndicator_MetaData ( );
        ::SWA::ServiceMetaData get_masls_setTime_MetaData ( );
      }
    }
    namespace masld_UI
    {
      namespace maslb_TRACK
      {
        ::SWA::ServiceMetaData get_masls_setTargetPressed_MetaData ( );
        ::SWA::ServiceMetaData get_masls_startStopPressed_MetaData ( );
        ::SWA::ServiceMetaData get_masls_lapResetPressed_MetaData ( );
        ::SWA::ServiceMetaData get_masls_lightPressed_MetaData ( );
        ::SWA::ServiceMetaData get_masls_modePressed_MetaData ( );
        ::SWA::ServiceMetaData get_masls_newGoalSpec_MetaData ( );
      }
    }
    bool initProcessMetaData ( )
    {
      ::SWA::ProcessMetaData::getProcess().setName( "GPS_Watch" );
      if ( ::masld_HeartRateMonitor::maslb_HRChange::overriden_masls_heartRateChanged() ) ::SWA::ProcessMetaData::getProcess().overrideTerminatorService( ::masld_HeartRateMonitor::getDomain().getId(), ::masld_HeartRateMonitor::terminatorId_maslb_HRChange, masld_HeartRateMonitor::maslb_HRChange::get_masls_heartRateChanged_MetaData() );
      if ( ::masld_Tracking::maslb_HR::overriden_masls_registerListener() ) ::SWA::ProcessMetaData::getProcess().overrideTerminatorService( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::terminatorId_maslb_HR, masld_Tracking::maslb_HR::get_masls_registerListener_MetaData() );
      if ( ::masld_Tracking::maslb_HR::overriden_masls_unregisterListener() ) ::SWA::ProcessMetaData::getProcess().overrideTerminatorService( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::terminatorId_maslb_HR, masld_Tracking::maslb_HR::get_masls_unregisterListener_MetaData() );
      if ( ::masld_Tracking::maslb_LOC::overriden_masls_getDistance() ) ::SWA::ProcessMetaData::getProcess().overrideTerminatorService( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::terminatorId_maslb_LOC, masld_Tracking::maslb_LOC::get_masls_getDistance_MetaData() );
      if ( ::masld_Tracking::maslb_LOC::overriden_masls_getLocation() ) ::SWA::ProcessMetaData::getProcess().overrideTerminatorService( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::terminatorId_maslb_LOC, masld_Tracking::maslb_LOC::get_masls_getLocation_MetaData() );
      if ( ::masld_Tracking::maslb_LOC::overriden_masls_registerListener() ) ::SWA::ProcessMetaData::getProcess().overrideTerminatorService( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::terminatorId_maslb_LOC, masld_Tracking::maslb_LOC::get_masls_registerListener_MetaData() );
      if ( ::masld_Tracking::maslb_LOC::overriden_masls_unregisterListener() ) ::SWA::ProcessMetaData::getProcess().overrideTerminatorService( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::terminatorId_maslb_LOC, masld_Tracking::maslb_LOC::get_masls_unregisterListener_MetaData() );
      if ( ::masld_Tracking::maslb_UI::overriden_masls_setData() ) ::SWA::ProcessMetaData::getProcess().overrideTerminatorService( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::terminatorId_maslb_UI, masld_Tracking::maslb_UI::get_masls_setData_MetaData() );
      if ( ::masld_Tracking::maslb_UI::overriden_masls_setIndicator() ) ::SWA::ProcessMetaData::getProcess().overrideTerminatorService( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::terminatorId_maslb_UI, masld_Tracking::maslb_UI::get_masls_setIndicator_MetaData() );
      if ( ::masld_Tracking::maslb_UI::overriden_masls_setTime() ) ::SWA::ProcessMetaData::getProcess().overrideTerminatorService( ::masld_Tracking::getDomain().getId(), ::masld_Tracking::terminatorId_maslb_UI, masld_Tracking::maslb_UI::get_masls_setTime_MetaData() );
      if ( ::masld_UI::maslb_TRACK::overriden_masls_setTargetPressed() ) ::SWA::ProcessMetaData::getProcess().overrideTerminatorService( ::masld_UI::getDomain().getId(), ::masld_UI::terminatorId_maslb_TRACK, masld_UI::maslb_TRACK::get_masls_setTargetPressed_MetaData() );
      if ( ::masld_UI::maslb_TRACK::overriden_masls_startStopPressed() ) ::SWA::ProcessMetaData::getProcess().overrideTerminatorService( ::masld_UI::getDomain().getId(), ::masld_UI::terminatorId_maslb_TRACK, masld_UI::maslb_TRACK::get_masls_startStopPressed_MetaData() );
      if ( ::masld_UI::maslb_TRACK::overriden_masls_lapResetPressed() ) ::SWA::ProcessMetaData::getProcess().overrideTerminatorService( ::masld_UI::getDomain().getId(), ::masld_UI::terminatorId_maslb_TRACK, masld_UI::maslb_TRACK::get_masls_lapResetPressed_MetaData() );
      if ( ::masld_UI::maslb_TRACK::overriden_masls_lightPressed() ) ::SWA::ProcessMetaData::getProcess().overrideTerminatorService( ::masld_UI::getDomain().getId(), ::masld_UI::terminatorId_maslb_TRACK, masld_UI::maslb_TRACK::get_masls_lightPressed_MetaData() );
      if ( ::masld_UI::maslb_TRACK::overriden_masls_modePressed() ) ::SWA::ProcessMetaData::getProcess().overrideTerminatorService( ::masld_UI::getDomain().getId(), ::masld_UI::terminatorId_maslb_TRACK, masld_UI::maslb_TRACK::get_masls_modePressed_MetaData() );
      if ( ::masld_UI::maslb_TRACK::overriden_masls_newGoalSpec() ) ::SWA::ProcessMetaData::getProcess().overrideTerminatorService( ::masld_UI::getDomain().getId(), ::masld_UI::terminatorId_maslb_TRACK, masld_UI::maslb_TRACK::get_masls_newGoalSpec_MetaData() );
      return true;
    }

    bool initialised = initProcessMetaData();

    namespace masld_HeartRateMonitor
    {
      namespace maslb_HRChange
      {
        ::SWA::ServiceMetaData get_masls_heartRateChanged_MetaData ( )
        {
          int lines[] = { 2,
     3};
          ::SWA::ServiceMetaData service(::masld_HeartRateMonitor::maslb_HRChange::serviceId_masls_heartRateChanged, ::SWA::ServiceMetaData::ProjectTerminator, "heartRateChanged", ::std::vector<int>( lines, lines + 2 ), "HeartRateMonitor_HRChange_heartRateChanged.tr", "e02b915f7ace30d3c9f8a4f1b190e29a");
          service.addParameter( ::SWA::ParameterMetaData( "heartRate", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
          return service;
        }

      }
    }
    namespace masld_Tracking
    {
      namespace maslb_HR
      {
        ::SWA::ServiceMetaData get_masls_registerListener_MetaData ( )
        {
          int lines[] = { 2,
     3};
          ::SWA::ServiceMetaData service(::masld_Tracking::maslb_HR::serviceId_masls_registerListener, ::SWA::ServiceMetaData::ProjectTerminator, "registerListener", ::std::vector<int>( lines, lines + 2 ), "Tracking_HR_registerListener.tr", "f08070b1666bd0205e33f0b9aa6e1bf6");
          return service;
        }

        ::SWA::ServiceMetaData get_masls_unregisterListener_MetaData ( )
        {
          int lines[] = { 2,
     3};
          ::SWA::ServiceMetaData service(::masld_Tracking::maslb_HR::serviceId_masls_unregisterListener, ::SWA::ServiceMetaData::ProjectTerminator, "unregisterListener", ::std::vector<int>( lines, lines + 2 ), "Tracking_HR_unregisterListener.tr", "17b5f76e284653c57702286fe11603a8");
          return service;
        }

      }
      namespace maslb_LOC
      {
        ::SWA::ServiceMetaData get_masls_getDistance_MetaData ( )
        {
          int lines[] = { 7,
     8,
     9};
          ::SWA::ServiceMetaData service(::masld_Tracking::maslb_LOC::serviceId_masls_getDistance, ::SWA::ServiceMetaData::ProjectTerminator, "getDistance", ::std::vector<int>( lines, lines + 3 ), "Tracking_LOC_getDistance.tr", "30502efe0844cf0910bf330f829985ad");
          service.addParameter( ::SWA::ParameterMetaData( "result", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), true ) );
          service.addParameter( ::SWA::ParameterMetaData( "toLong", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
          service.addParameter( ::SWA::ParameterMetaData( "toLat", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
          service.addParameter( ::SWA::ParameterMetaData( "fromLong", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
          service.addParameter( ::SWA::ParameterMetaData( "fromLat", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
          service.addLocalVariable( ::SWA::LocalVariableMetaData( "distance", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
          return service;
        }

        ::SWA::ServiceMetaData get_masls_getLocation_MetaData ( )
        {
          int lines[] = { 5,
     6,
     7,
     8,
     9,
     10};
          ::SWA::ServiceMetaData service(::masld_Tracking::maslb_LOC::serviceId_masls_getLocation, ::SWA::ServiceMetaData::ProjectTerminator, "getLocation", ::std::vector<int>( lines, lines + 6 ), "Tracking_LOC_getLocation.tr", "ff67f9bc3c68e22f72b71d4df314c678");
          service.addParameter( ::SWA::ParameterMetaData( "longitude", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), true ) );
          service.addParameter( ::SWA::ParameterMetaData( "latitude", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), true ) );
          service.addLocalVariable( ::SWA::LocalVariableMetaData( "lat", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
          service.addLocalVariable( ::SWA::LocalVariableMetaData( "longi", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ) ) );
          return service;
        }

        ::SWA::ServiceMetaData get_masls_registerListener_MetaData ( )
        {
          int lines[] = { 2,
     3};
          ::SWA::ServiceMetaData service(::masld_Tracking::maslb_LOC::serviceId_masls_registerListener, ::SWA::ServiceMetaData::ProjectTerminator, "registerListener", ::std::vector<int>( lines, lines + 2 ), "Tracking_LOC_registerListener.tr", "c50bde24a723a5128de0621c8e9d88f8");
          return service;
        }

        ::SWA::ServiceMetaData get_masls_unregisterListener_MetaData ( )
        {
          int lines[] = { 2,
     3};
          ::SWA::ServiceMetaData service(::masld_Tracking::maslb_LOC::serviceId_masls_unregisterListener, ::SWA::ServiceMetaData::ProjectTerminator, "unregisterListener", ::std::vector<int>( lines, lines + 2 ), "Tracking_LOC_unregisterListener.tr", "c35ac2e86306af5fde228440dfb76160");
          return service;
        }

      }
      namespace maslb_UI
      {
        ::SWA::ServiceMetaData get_masls_setData_MetaData ( )
        {
          int lines[] = { 3,
     4,
     5,
     7,
     9,
     11,
     13,
     15,
     17,
     19,
     21,
     23,
     25};
          ::SWA::ServiceMetaData service(::masld_Tracking::maslb_UI::serviceId_masls_setData, ::SWA::ServiceMetaData::ProjectTerminator, "setData", ::std::vector<int>( lines, lines + 13 ), "Tracking_UI_setData.tr", "1c67c112e9e2916ede5d7d0ec6791316");
          service.addParameter( ::SWA::ParameterMetaData( "value", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
          service.addParameter( ::SWA::ParameterMetaData( "unit", "Tracking::Unit", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::typeId_maslt_Unit ), false ) );
          return service;
        }

        ::SWA::ServiceMetaData get_masls_setIndicator_MetaData ( )
        {
          int lines[] = { 2,
     3,
     4,
     6,
     8,
     10};
          ::SWA::ServiceMetaData service(::masld_Tracking::maslb_UI::serviceId_masls_setIndicator, ::SWA::ServiceMetaData::ProjectTerminator, "setIndicator", ::std::vector<int>( lines, lines + 6 ), "Tracking_UI_setIndicator.tr", "c812ea70dc279d98a01425fbbc90a4a9");
          service.addParameter( ::SWA::ParameterMetaData( "indicator", "Tracking::Indicator", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Tracking::getDomain().getId(), ::masld_Tracking::typeId_maslt_Indicator ), false ) );
          return service;
        }

        ::SWA::ServiceMetaData get_masls_setTime_MetaData ( )
        {
          int lines[] = { 2,
     3};
          ::SWA::ServiceMetaData service(::masld_Tracking::maslb_UI::serviceId_masls_setTime, ::SWA::ServiceMetaData::ProjectTerminator, "setTime", ::std::vector<int>( lines, lines + 2 ), "Tracking_UI_setTime.tr", "621be13a18dfb8524089fac9265c3f8b");
          service.addParameter( ::SWA::ParameterMetaData( "time", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
          return service;
        }

      }
    }
    namespace masld_UI
    {
      namespace maslb_TRACK
      {
        ::SWA::ServiceMetaData get_masls_setTargetPressed_MetaData ( )
        {
          int lines[] = { 2,
     3};
          ::SWA::ServiceMetaData service(::masld_UI::maslb_TRACK::serviceId_masls_setTargetPressed, ::SWA::ServiceMetaData::ProjectTerminator, "setTargetPressed", ::std::vector<int>( lines, lines + 2 ), "UI_TRACK_setTargetPressed.tr", "6a03c35091f5d34ae772449cd8b4bb03");
          return service;
        }

        ::SWA::ServiceMetaData get_masls_startStopPressed_MetaData ( )
        {
          int lines[] = { 2,
     3};
          ::SWA::ServiceMetaData service(::masld_UI::maslb_TRACK::serviceId_masls_startStopPressed, ::SWA::ServiceMetaData::ProjectTerminator, "startStopPressed", ::std::vector<int>( lines, lines + 2 ), "UI_TRACK_startStopPressed.tr", "81a962b7c10d21aa48af79da2d775ee9");
          return service;
        }

        ::SWA::ServiceMetaData get_masls_lapResetPressed_MetaData ( )
        {
          int lines[] = { 2,
     3};
          ::SWA::ServiceMetaData service(::masld_UI::maslb_TRACK::serviceId_masls_lapResetPressed, ::SWA::ServiceMetaData::ProjectTerminator, "lapResetPressed", ::std::vector<int>( lines, lines + 2 ), "UI_TRACK_lapResetPressed.tr", "ba998cb6a1da43586f7796139352675e");
          return service;
        }

        ::SWA::ServiceMetaData get_masls_lightPressed_MetaData ( )
        {
          int lines[] = { 2,
     3};
          ::SWA::ServiceMetaData service(::masld_UI::maslb_TRACK::serviceId_masls_lightPressed, ::SWA::ServiceMetaData::ProjectTerminator, "lightPressed", ::std::vector<int>( lines, lines + 2 ), "UI_TRACK_lightPressed.tr", "1be49c55e02bdb1ec7a9cca457928dd6");
          return service;
        }

        ::SWA::ServiceMetaData get_masls_modePressed_MetaData ( )
        {
          int lines[] = { 2,
     3};
          ::SWA::ServiceMetaData service(::masld_UI::maslb_TRACK::serviceId_masls_modePressed, ::SWA::ServiceMetaData::ProjectTerminator, "modePressed", ::std::vector<int>( lines, lines + 2 ), "UI_TRACK_modePressed.tr", "a7396794311061134a654cf5bd57152b");
          return service;
        }

        ::SWA::ServiceMetaData get_masls_newGoalSpec_MetaData ( )
        {
          int lines[] = { 7,
     8,
     9,
     10,
     12,
     15,
     16,
     18};
          ::SWA::ServiceMetaData service(::masld_UI::maslb_TRACK::serviceId_masls_newGoalSpec, ::SWA::ServiceMetaData::ProjectTerminator, "newGoalSpec", ::std::vector<int>( lines, lines + 8 ), "UI_TRACK_newGoalSpec.tr", "43091b48594fc4d4307e2da19f56296a");
          service.addParameter( ::SWA::ParameterMetaData( "spanType", "UI::UIGoalSpan", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_UI::getDomain().getId(), ::masld_UI::typeId_maslt_UIGoalSpan ), false ) );
          service.addParameter( ::SWA::ParameterMetaData( "criteriaType", "UI::UIGoalCriteria", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_UI::getDomain().getId(), ::masld_UI::typeId_maslt_UIGoalCriteria ), false ) );
          service.addParameter( ::SWA::ParameterMetaData( "span", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
          service.addParameter( ::SWA::ParameterMetaData( "maximum", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
          service.addParameter( ::SWA::ParameterMetaData( "minimum", "real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
          service.addParameter( ::SWA::ParameterMetaData( "sequenceNumber", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
          return service;
        }

      }
    }
  }
}
