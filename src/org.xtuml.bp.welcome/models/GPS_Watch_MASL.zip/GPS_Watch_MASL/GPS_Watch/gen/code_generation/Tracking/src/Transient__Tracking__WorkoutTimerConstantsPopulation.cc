//
// File: Transient__Tracking__WorkoutTimerConstantsPopulation.cc
//
#include "Transient__Tracking__WorkoutTimerConstants.hh"
#include "Transient__Tracking__WorkoutTimerConstantsPopulation.hh"
#include "__Tracking__WorkoutTimerConstants.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"

namespace transient
{
  namespace masld_Tracking
  {
    maslo_WorkoutTimerConstantsPopulation::maslo_WorkoutTimerConstantsPopulation ( )
      : masla_id_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimerConstants> maslo_WorkoutTimerConstantsPopulation::createInstance ( int32_t masla_id,
                                                                                                                             int32_t masla_timerPeriod )
    {
      if ( exists_masla_id( masla_id ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimerConstants> instance(new maslo_WorkoutTimerConstants(  masla_id,
                                  masla_timerPeriod ));
      addInstance( instance );
      return instance;
    }

    void maslo_WorkoutTimerConstantsPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimerConstants> instance )
    {
      masla_id_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimerConstants> >::value_type( ::boost::make_tuple( instance->get_masla_id() ), instance ) );
    }

    void maslo_WorkoutTimerConstantsPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutTimerConstants> instance )
    {
      masla_id_Lookup.erase( ::boost::make_tuple( instance->get_masla_id() ) );
    }

    bool maslo_WorkoutTimerConstantsPopulation::exists_masla_id ( int32_t masla_id ) const
    {
      return masla_id_Lookup.find( ::boost::make_tuple( masla_id ) ) != masla_id_Lookup.end();
    }

    maslo_WorkoutTimerConstantsPopulation& maslo_WorkoutTimerConstantsPopulation::getPopulation ( )
    {
      static maslo_WorkoutTimerConstantsPopulation population;
      return population;
    }

    bool maslo_WorkoutTimerConstantsPopulation::registered = maslo_WorkoutTimerConstantsPopulation::registerSingleton( &maslo_WorkoutTimerConstantsPopulation::getPopulation );

  }
}
