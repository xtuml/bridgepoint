//
// File: Sqlite__Location__simulatedGPSMapper.cc
//
#include "Sqlite__Location__simulatedGPS.hh"
#include "Sqlite__Location__simulatedGPSMapper.hh"
#include "Sqlite__Location__simulatedGPSMapperSql.hh"
#include "__Location__simulatedGPS.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_Location
  {
    maslo_simulatedGPSMapper::maslo_simulatedGPSMapper ( )
      : ::SQL::ObjectMapper< ::masld_Location::maslo_simulatedGPS,maslo_simulatedGPS>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_Location::maslo_simulatedGPS,maslo_simulatedGPS> >( new maslo_simulatedGPSSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_simulatedGPSMapper::~maslo_simulatedGPSMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> maslo_simulatedGPSMapper::createInstance ( int32_t masla_id,
                                                                                                       double  masla_initialLatitude,
                                                                                                       double  masla_initialLongitude,
                                                                                                       double  masla_latitudeIncrement,
                                                                                                       double  masla_longitudeIncrement,
                                                                                                       int32_t masla_updatePeriod )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_simulatedGPS::PrimaryKeyType>::value_type( masla_id ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_simulatedGPS> instance(new maslo_simulatedGPS(  uniqueId,
                         masla_id,
                         masla_initialLatitude,
                         masla_initialLongitude,
                         masla_latitudeIncrement,
                         masla_longitudeIncrement,
                         masla_updatePeriod ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_simulatedGPSMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> instance )
    {
      ::SQL::ObjectMapper< ::masld_Location::maslo_simulatedGPS,maslo_simulatedGPS>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_simulatedGPS>()->getPrimaryKey() );
    }

    bool maslo_simulatedGPSMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
