//
// File: Sqlite__UI__TestCaseMapper.hh
//
#ifndef Sqlite_UI_Test_Case_Mapper_hh
#define Sqlite_UI_Test_Case_Mapper_hh

#include "Sqlite__UI__TestCase.hh"
#include "__UI__TestCase.hh"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"

namespace SQLITE
{
  namespace masld_UI
  {
    class maslo_TestCaseMapper
      : public ::SQL::ObjectMapper< ::masld_UI::maslo_TestCase,maslo_TestCase>
    {

      // Instance creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> createInstance ( int32_t                          masla_iterations,
                                                                               int32_t                          masla_id,
                                                                               ::masld_UI::maslo_TestCase::Type currentState );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> instance );
      protected:
        virtual bool doPostInit ( );


      // Constructors and Destructors
      public:
        maslo_TestCaseMapper ( );
        virtual ~maslo_TestCaseMapper ( );


      // Attributes
      private:
        ::boost::unordered_set<maslo_TestCase::PrimaryKeyType> primarykey_cache;


    };
  }
}
#endif // Sqlite_UI_Test_Case_Mapper_hh
