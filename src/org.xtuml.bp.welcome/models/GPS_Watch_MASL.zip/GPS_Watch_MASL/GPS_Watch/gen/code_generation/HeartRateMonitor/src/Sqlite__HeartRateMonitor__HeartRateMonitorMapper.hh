//
// File: Sqlite__HeartRateMonitor__HeartRateMonitorMapper.hh
//
#ifndef Sqlite_Heart_Rate_Monitor_Heart_Rate_Monitor_Mapper_hh
#define Sqlite_Heart_Rate_Monitor_Heart_Rate_Monitor_Mapper_hh

#include "Sqlite__HeartRateMonitor__HeartRateMonitor.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"

namespace SQLITE
{
  namespace masld_HeartRateMonitor
  {
    class maslo_HeartRateMonitorMapper
      : public ::SQL::ObjectMapper< ::masld_HeartRateMonitor::maslo_HeartRateMonitor,maslo_HeartRateMonitor>
    {

      // Instance creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> createInstance ( int32_t                                                masla_recentHeartRate,
                                                                                                     const ::SWA::EventTimers::TimerIdType&                 masla_timer,
                                                                                                     int32_t                                                masla_id,
                                                                                                     ::masld_HeartRateMonitor::maslo_HeartRateMonitor::Type currentState );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_HeartRateMonitor::maslo_HeartRateMonitor> instance );
      protected:
        virtual bool doPostInit ( );


      // Constructors and Destructors
      public:
        maslo_HeartRateMonitorMapper ( );
        virtual ~maslo_HeartRateMonitorMapper ( );


      // Attributes
      private:
        ::boost::unordered_set<maslo_HeartRateMonitor::PrimaryKeyType> primarykey_cache;


    };
  }
}
#endif // Sqlite_Heart_Rate_Monitor_Heart_Rate_Monitor_Mapper_hh
