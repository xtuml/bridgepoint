//
// File: Transient__UI__UIPopulation.cc
//
#include "Transient__UI__UI.hh"
#include "Transient__UI__UIPopulation.hh"
#include "__UI__UI.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"

namespace transient
{
  namespace masld_UI
  {
    maslo_UIPopulation::maslo_UIPopulation ( )
      : masla_id_Lookup()
    {
    }

    ::SWA::ObjectPtr< ::masld_UI::maslo_UI> maslo_UIPopulation::createInstance ( int32_t                                masla_id,
                                                                                 int32_t                                masla_socket_id,
                                                                                 const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                                 ::masld_UI::maslo_UI::Type             currentState )
    {
      if ( exists_masla_id( masla_id ) ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::ObjectPtr< ::masld_UI::maslo_UI> instance(new maslo_UI(  masla_id,
               masla_socket_id,
               masla_timer,
               currentState ));
      addInstance( instance );
      return instance;
    }

    void maslo_UIPopulation::instanceCreated ( ::SWA::ObjectPtr< ::masld_UI::maslo_UI> instance )
    {
      masla_id_Lookup.insert( ::boost::unordered_map< ::boost::tuple<int32_t>,::SWA::ObjectPtr< ::masld_UI::maslo_UI> >::value_type( ::boost::make_tuple( instance->get_masla_id() ), instance ) );
    }

    void maslo_UIPopulation::instanceDeleted ( ::SWA::ObjectPtr< ::masld_UI::maslo_UI> instance )
    {
      masla_id_Lookup.erase( ::boost::make_tuple( instance->get_masla_id() ) );
    }

    bool maslo_UIPopulation::exists_masla_id ( int32_t masla_id ) const
    {
      return masla_id_Lookup.find( ::boost::make_tuple( masla_id ) ) != masla_id_Lookup.end();
    }

    maslo_UIPopulation& maslo_UIPopulation::getPopulation ( )
    {
      static maslo_UIPopulation population;
      return population;
    }

    bool maslo_UIPopulation::registered = maslo_UIPopulation::registerSingleton( &maslo_UIPopulation::getPopulation );

  }
}
