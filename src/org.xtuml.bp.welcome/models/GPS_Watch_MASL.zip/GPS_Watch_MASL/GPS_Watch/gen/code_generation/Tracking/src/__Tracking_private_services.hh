//
// File: __Tracking_private_services.hh
//
#ifndef _Tracking_private_services_hh
#define _Tracking_private_services_hh

#include "swa/ServiceInterceptor.hh"

namespace masld_Tracking
{
  void masls_Initialize ( );
  class masls_Initialize_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_Initialize_tag,void()> interceptor_masls_Initialize;
  void masls_GoalTest_1 ( );
  class masls_GoalTest_1_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_GoalTest_1_tag,void()> interceptor_masls_GoalTest_1;
}
#endif // _Tracking_private_services_hh
