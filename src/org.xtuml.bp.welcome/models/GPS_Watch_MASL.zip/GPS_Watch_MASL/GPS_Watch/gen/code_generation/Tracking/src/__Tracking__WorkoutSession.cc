//
// File: __Tracking__WorkoutSession.cc
//
#include "__Tracking__Display.hh"
#include "__Tracking__Goal.hh"
#include "__Tracking__GoalSpec.hh"
#include "__Tracking__HeartRateSample.hh"
#include "__Tracking__TrackLog.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutSessionPopulation.hh"
#include "__Tracking__WorkoutTimer.hh"
#include <cstddef>
#include <iostream>
#include "swa/Bag.hh"
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/Set.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  ::SWA::ObjectPtr<maslo_WorkoutSession> maslo_WorkoutSession::getInstance ( ::SWA::IdType id )
  {
    return maslo_WorkoutSessionPopulation::getSingleton().getInstance( id );
  }

  ::SWA::IdType maslo_WorkoutSession::getNextArchId ( )
  {
    return maslo_WorkoutSessionPopulation::getSingleton().getNextArchId();
  }

  maslo_WorkoutSession::maslo_WorkoutSession ( )
    : isDeletedFlag()
  {
  }

  maslo_WorkoutSession::~maslo_WorkoutSession ( )
  {
  }

  ::SWA::ObjectPtr<maslo_WorkoutSession> maslo_WorkoutSession::createInstance ( const ::SWA::Timestamp& masla_startTime,
                                                                                double                  masla_accumulatedDistance )
  {
    return maslo_WorkoutSessionPopulation::getSingleton().createInstance( masla_startTime, masla_accumulatedDistance );
  }

  void maslo_WorkoutSession::deleteInstance ( )
  {
    if ( count_R7_current_status_indicated_on_Display() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R7 still linked" );
    if ( count_R8_is_timed_by_WorkoutTimer() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R8 still linked" );
    if ( count_R4_captures_path_in_TrackLog() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R4 still linked" );
    if ( count_R6_tracks_heart_rate_over_time_as_HeartRateSample() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R6 still linked" );
    if ( count_R10_includes_GoalSpec() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R10 still linked" );
    if ( count_R11_is_currently_executing_Goal() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R11 still linked" );
    if ( count_R13_has_executed_Goal() ) throw ::SWA::ProgramError( "Cannot delete instance - relationship R13 still linked" );
    maslo_WorkoutSessionPopulation::getSingleton().deleteInstance( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ) );
    isDeletedFlag = true;
  }

  ::std::size_t maslo_WorkoutSession::getPopulationSize ( )
  {
    return maslo_WorkoutSessionPopulation::getSingleton().size();
  }

  ::SWA::Set< ::SWA::ObjectPtr<maslo_WorkoutSession> > maslo_WorkoutSession::findAll ( )
  {
    return maslo_WorkoutSessionPopulation::getSingleton().findAll();
  }

  ::SWA::ObjectPtr<maslo_WorkoutSession> maslo_WorkoutSession::findOne ( )
  {
    return maslo_WorkoutSessionPopulation::getSingleton().findOne();
  }

  ::SWA::ObjectPtr<maslo_WorkoutSession> maslo_WorkoutSession::findOnly ( )
  {
    return maslo_WorkoutSessionPopulation::getSingleton().findOnly();
  }

  ::std::size_t maslo_WorkoutSession::count_R7_current_status_indicated_on_Display ( ) const
  {
    return navigate_R7_current_status_indicated_on_Display() == ::SWA::Null ? 0
                                                                            : 1;
  }

  void maslo_WorkoutSession::checked_link_R7_current_status_indicated_on_Display ( const ::SWA::ObjectPtr<maslo_Display>& rhs )
  {
    if ( rhs->get_masla_session_startTime() != get_masla_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R7_current_status_indicated_on_Display( rhs );
  }

  void maslo_WorkoutSession::unlink_R7_current_status_indicated_on_Display ( )
  {
    const ::SWA::ObjectPtr<maslo_Display>& rhs = navigate_R7_current_status_indicated_on_Display();
    if ( rhs ) unlink_R7_current_status_indicated_on_Display( rhs );
  }

  ::std::size_t maslo_WorkoutSession::count_R8_is_timed_by_WorkoutTimer ( ) const
  {
    return navigate_R8_is_timed_by_WorkoutTimer() == ::SWA::Null ? 0
                                                                 : 1;
  }

  void maslo_WorkoutSession::checked_link_R8_is_timed_by_WorkoutTimer ( const ::SWA::ObjectPtr<maslo_WorkoutTimer>& rhs )
  {
    if ( rhs->get_masla_session_startTime() != get_masla_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R8_is_timed_by_WorkoutTimer( rhs );
  }

  void maslo_WorkoutSession::unlink_R8_is_timed_by_WorkoutTimer ( )
  {
    const ::SWA::ObjectPtr<maslo_WorkoutTimer>& rhs = navigate_R8_is_timed_by_WorkoutTimer();
    if ( rhs ) unlink_R8_is_timed_by_WorkoutTimer( rhs );
  }

  ::std::size_t maslo_WorkoutSession::count_R4_captures_path_in_TrackLog ( ) const
  {
    return navigate_R4_captures_path_in_TrackLog() == ::SWA::Null ? 0
                                                                  : 1;
  }

  void maslo_WorkoutSession::checked_link_R4_captures_path_in_TrackLog ( const ::SWA::ObjectPtr<maslo_TrackLog>& rhs )
  {
    if ( rhs->get_masla_session_startTime() != get_masla_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R4_captures_path_in_TrackLog( rhs );
  }

  void maslo_WorkoutSession::unlink_R4_captures_path_in_TrackLog ( )
  {
    const ::SWA::ObjectPtr<maslo_TrackLog>& rhs = navigate_R4_captures_path_in_TrackLog();
    if ( rhs ) unlink_R4_captures_path_in_TrackLog( rhs );
  }

  ::std::size_t maslo_WorkoutSession::count_R6_tracks_heart_rate_over_time_as_HeartRateSample ( ) const
  {
    return navigate_R6_tracks_heart_rate_over_time_as_HeartRateSample().size();
  }

  void maslo_WorkoutSession::checked_link_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::ObjectPtr<maslo_HeartRateSample>& rhs )
  {
    if ( rhs->get_masla_session_startTime() != get_masla_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R6_tracks_heart_rate_over_time_as_HeartRateSample( rhs );
  }

  void maslo_WorkoutSession::checked_link_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_HeartRateSample> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_HeartRateSample> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it )
    {
      if ( (*it)->get_masla_session_startTime() != get_masla_startTime() )
      {
        throw ::SWA::ProgramError( "referential integrity failure" );
      }
    }
    link_R6_tracks_heart_rate_over_time_as_HeartRateSample( rhs );
  }

  void maslo_WorkoutSession::link_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_HeartRateSample> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_HeartRateSample> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it ) link_R6_tracks_heart_rate_over_time_as_HeartRateSample( *it );
  }

  void maslo_WorkoutSession::unlink_R6_tracks_heart_rate_over_time_as_HeartRateSample ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_HeartRateSample> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_HeartRateSample> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it ) unlink_R6_tracks_heart_rate_over_time_as_HeartRateSample( *it );
  }

  void maslo_WorkoutSession::unlink_R6_tracks_heart_rate_over_time_as_HeartRateSample ( )
  {
    unlink_R6_tracks_heart_rate_over_time_as_HeartRateSample( navigate_R6_tracks_heart_rate_over_time_as_HeartRateSample() );
  }

  ::std::size_t maslo_WorkoutSession::count_R10_includes_GoalSpec ( ) const
  {
    return navigate_R10_includes_GoalSpec().size();
  }

  void maslo_WorkoutSession::checked_link_R10_includes_GoalSpec ( const ::SWA::ObjectPtr<maslo_GoalSpec>& rhs )
  {
    if ( rhs->get_masla_session_startTime() != get_masla_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R10_includes_GoalSpec( rhs );
  }

  void maslo_WorkoutSession::checked_link_R10_includes_GoalSpec ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_GoalSpec> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_GoalSpec> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it )
    {
      if ( (*it)->get_masla_session_startTime() != get_masla_startTime() )
      {
        throw ::SWA::ProgramError( "referential integrity failure" );
      }
    }
    link_R10_includes_GoalSpec( rhs );
  }

  void maslo_WorkoutSession::link_R10_includes_GoalSpec ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_GoalSpec> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_GoalSpec> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it ) link_R10_includes_GoalSpec( *it );
  }

  void maslo_WorkoutSession::unlink_R10_includes_GoalSpec ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_GoalSpec> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_GoalSpec> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it ) unlink_R10_includes_GoalSpec( *it );
  }

  void maslo_WorkoutSession::unlink_R10_includes_GoalSpec ( )
  {
    unlink_R10_includes_GoalSpec( navigate_R10_includes_GoalSpec() );
  }

  ::std::size_t maslo_WorkoutSession::count_R11_is_currently_executing_Goal ( ) const
  {
    return navigate_R11_is_currently_executing_Goal() == ::SWA::Null ? 0
                                                                     : 1;
  }

  void maslo_WorkoutSession::checked_link_R11_is_currently_executing_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs )
  {
    if ( rhs->get_masla_session_startTime() != get_masla_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R11_is_currently_executing_Goal( rhs );
  }

  void maslo_WorkoutSession::unlink_R11_is_currently_executing_Goal ( )
  {
    const ::SWA::ObjectPtr<maslo_Goal>& rhs = navigate_R11_is_currently_executing_Goal();
    if ( rhs ) unlink_R11_is_currently_executing_Goal( rhs );
  }

  ::std::size_t maslo_WorkoutSession::count_R13_has_executed_Goal ( ) const
  {
    return navigate_R13_has_executed_Goal().size();
  }

  void maslo_WorkoutSession::checked_link_R13_has_executed_Goal ( const ::SWA::ObjectPtr<maslo_Goal>& rhs )
  {
    if ( rhs->get_masla_session_startTime() != get_masla_startTime() )
    {
      throw ::SWA::ProgramError( "referential integrity failure" );
    }
    link_R13_has_executed_Goal( rhs );
  }

  void maslo_WorkoutSession::checked_link_R13_has_executed_Goal ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it )
    {
      if ( (*it)->get_masla_session_startTime() != get_masla_startTime() )
      {
        throw ::SWA::ProgramError( "referential integrity failure" );
      }
    }
    link_R13_has_executed_Goal( rhs );
  }

  void maslo_WorkoutSession::link_R13_has_executed_Goal ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it ) link_R13_has_executed_Goal( *it );
  }

  void maslo_WorkoutSession::unlink_R13_has_executed_Goal ( const ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >& rhs )
  {
    for ( ::SWA::Bag< ::SWA::ObjectPtr<maslo_Goal> >::const_iterator it = rhs.begin(); it != rhs.end(); ++it ) unlink_R13_has_executed_Goal( *it );
  }

  void maslo_WorkoutSession::unlink_R13_has_executed_Goal ( )
  {
    unlink_R13_has_executed_Goal( navigate_R13_has_executed_Goal() );
  }

  ::std::ostream& operator<< ( ::std::ostream&             stream,
                               const maslo_WorkoutSession& obj )
  {
    stream << "(";
    stream << obj.get_masla_startTime();
    stream << ",";
    stream << obj.get_masla_accumulatedDistance();
    stream << ")";
    return stream;
  }

}
