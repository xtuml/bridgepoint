//
// File: __Tracking__WorkoutSession__getCurrentHeartRate.cc
//
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__HeartRateConstants.hh"
#include "__Tracking__HeartRateSample.hh"
#include "__Tracking__WorkoutSession.hh"
#include "__Tracking__WorkoutTimer.hh"
#include "boost/bind.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/Stack.hh"
#include "swa/navigate.hh"

namespace masld_Tracking
{
  int32_t maslo_WorkoutSession::masls_getCurrentHeartRate ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_WorkoutSession, serviceId_masls_getCurrentHeartRate);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(9);
      {

        // hrc : instance of HeartRateConstants;
        ::SWA::ObjectPtr<maslo_HeartRateConstants> maslv_hrc;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_hrc(0, maslv_hrc);

        // workoutTimer : instance of WorkoutTimer;
        ::SWA::ObjectPtr<maslo_WorkoutTimer> maslv_workoutTimer;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_workoutTimer(1, maslv_workoutTimer);

        // samples : set of instance of HeartRateSample;
        ::SWA::Set< ::SWA::ObjectPtr<maslo_HeartRateSample> > maslv_samples;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_samples(2, maslv_samples);

        // sample : instance of HeartRateSample;
        ::SWA::ObjectPtr<maslo_HeartRateSample> maslv_sample;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_sample(3, maslv_sample);

        // numberOfSamples : integer;
        int32_t maslv_numberOfSamples = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_numberOfSamples(4, maslv_numberOfSamples);

        // sum : integer;
        int32_t maslv_sum = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_sum(5, maslv_sum);

        // result : integer;
        int32_t maslv_result = 0;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_result(6, maslv_result);

        // HeartRateConstants.initialize()
        {
          ::SWA::Stack::ExecutingStatement statement(11);
          maslo_HeartRateConstants::masls_initialize();
        }

        // hrc := find_one HeartRateConstants ();
        {
          ::SWA::Stack::ExecutingStatement statement(12);
          maslv_hrc = maslo_HeartRateConstants::findOne();
        }

        // workoutTimer := this -> R8.is_timed_by.WorkoutTimer;
        {
          ::SWA::Stack::ExecutingStatement statement(13);
          maslv_workoutTimer = ::SWA::navigate_one<maslo_WorkoutTimer>( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), ::boost::bind( &maslo_WorkoutSession::navigate_R8_is_timed_by_WorkoutTimer, _1 ) );
        }

        // samples := find this -> R6.tracks_heart_rate_over_time_as.HeartRateSample ((time >= (workoutTimer.time - (hrc.HeartRateSamplingPeriod * hrc.HeartRateAveragingWindow))));
        {
          ::SWA::Stack::ExecutingStatement statement(14);
          maslv_samples = ::SWA::navigate_many<maslo_HeartRateSample>( ::SWA::ObjectPtr<maslo_WorkoutSession>( this ), ::boost::bind( &maslo_WorkoutSession::navigate_R6_tracks_heart_rate_over_time_as_HeartRateSample, _1 ) ).find( ::boost::bind( &maslo_HeartRateSample::findPredicate_OPmasl_time_maslGEp1CP, ::boost::bind( &::SWA::ObjectPtr<maslo_HeartRateSample>::deref, _1 ), maslv_workoutTimer->get_masla_time() - maslv_hrc->get_masla_HeartRateSamplingPeriod() * maslv_hrc->get_masla_HeartRateAveragingWindow() ) );
        }

        // numberOfSamples := 0;
        {
          ::SWA::Stack::ExecutingStatement statement(15);
          maslv_numberOfSamples = 0ll;
        }

        // sum := 0;
        {
          ::SWA::Stack::ExecutingStatement statement(16);
          maslv_sum = 0ll;
        }

        // result := 0;
        {
          ::SWA::Stack::ExecutingStatement statement(17);
          maslv_result = 0ll;
        }

        // for sample in samples'elements loop ...
        {
          ::SWA::Stack::ExecutingStatement statement(18);
          ::SWA::Set< ::SWA::ObjectPtr<maslo_HeartRateSample> > collection = maslv_samples;
          for ( ::SWA::Set< ::SWA::ObjectPtr<maslo_HeartRateSample> >::const_iterator i = collection.begin(); i != collection.end(); ++i )
          {
            const ::SWA::ObjectPtr<maslo_HeartRateSample>& maslv_sample = *i;
            ::SWA::Stack::DeclareLocalVariable pm_maslv_sample(7, maslv_sample);

            // numberOfSamples := (numberOfSamples + 1);
            {
              ::SWA::Stack::ExecutingStatement statement(19);
              maslv_numberOfSamples = maslv_numberOfSamples + 1ll;
            }

            // sum := (sum + sample.heartRate);
            {
              ::SWA::Stack::ExecutingStatement statement(20);
              maslv_sum = maslv_sum + maslv_sample->get_masla_heartRate();
            }
          }
        }

        // if (numberOfSamples > 0) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(22);
          if ( maslv_numberOfSamples > 0ll )
          {

            // result := (sum / numberOfSamples);
            {
              ::SWA::Stack::ExecutingStatement statement(23);
              maslv_result = maslv_sum / maslv_numberOfSamples;
            }
          }
        }

        // return result;
        {
          ::SWA::Stack::ExecutingStatement statement(26);
          return maslv_result;
        }
      }
    }
  }

}
