//
// File: Transient__HeartRateMonitor__HeartRateMonitor.cc
//
#include "Transient__HeartRateMonitor__HeartRateMonitor.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"

namespace transient
{
  namespace masld_HeartRateMonitor
  {
    maslo_HeartRateMonitor::maslo_HeartRateMonitor ( int32_t                                                masla_recentHeartRate,
                                                     const ::SWA::EventTimers::TimerIdType&                 masla_timer,
                                                     int32_t                                                masla_id,
                                                     ::masld_HeartRateMonitor::maslo_HeartRateMonitor::Type currentState )
      : architectureId(getNextArchId()),
        masla_recentHeartRate(masla_recentHeartRate),
        masla_timer(masla_timer),
        masla_id(masla_id),
        currentState(currentState)
    {
    }

  }
}
