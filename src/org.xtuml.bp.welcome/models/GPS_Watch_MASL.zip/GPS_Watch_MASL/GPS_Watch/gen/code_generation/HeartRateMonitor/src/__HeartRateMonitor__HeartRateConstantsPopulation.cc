//
// File: __HeartRateMonitor__HeartRateConstantsPopulation.cc
//
#include "__HeartRateMonitor__HeartRateConstantsPopulation.hh"

namespace masld_HeartRateMonitor
{
  maslo_HeartRateConstantsPopulation::maslo_HeartRateConstantsPopulation ( )
  {
  }

  maslo_HeartRateConstantsPopulation::~maslo_HeartRateConstantsPopulation ( )
  {
  }

}
