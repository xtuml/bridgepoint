//
// File: __Tracking__SpeedPopulation.cc
//
#include "__Tracking__SpeedPopulation.hh"

namespace masld_Tracking
{
  maslo_SpeedPopulation::maslo_SpeedPopulation ( )
  {
  }

  maslo_SpeedPopulation::~maslo_SpeedPopulation ( )
  {
  }

}
