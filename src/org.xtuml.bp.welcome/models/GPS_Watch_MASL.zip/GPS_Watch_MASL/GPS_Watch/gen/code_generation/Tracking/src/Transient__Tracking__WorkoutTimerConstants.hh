//
// File: Transient__Tracking__WorkoutTimerConstants.hh
//
#ifndef Transient_Tracking_Workout_Timer_Constants_hh
#define Transient_Tracking_Workout_Timer_Constants_hh

#include "__Tracking__WorkoutTimerConstants.hh"
#include <stdint.h>
#include "swa/types.hh"

namespace transient
{
  namespace masld_Tracking
  {
    class maslo_WorkoutTimerConstants
      : public ::masld_Tracking::maslo_WorkoutTimerConstants
    {

      // Constructors and Destructors
      public:
        maslo_WorkoutTimerConstants ( int32_t masla_id,
                                      int32_t masla_timerPeriod );


      // Setters for each object attribute
      public:
        virtual void set_masla_timerPeriod ( int32_t value ) { this->masla_timerPeriod = value; }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual int32_t get_masla_timerPeriod ( ) const { return masla_timerPeriod; }


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_id;
        int32_t masla_timerPeriod;


    };
  }
}
#endif // Transient_Tracking_Workout_Timer_Constants_hh
