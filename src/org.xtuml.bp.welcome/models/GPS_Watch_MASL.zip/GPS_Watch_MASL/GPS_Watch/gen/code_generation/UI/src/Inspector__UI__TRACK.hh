//
// File: Inspector__UI__TRACK.hh
//
#ifndef Inspector_UI_TRACK_hh
#define Inspector_UI_TRACK_hh

#include "inspector/TerminatorHandler.hh"

namespace Inspector
{
  namespace masld_UI
  {
    namespace maslb_TRACK
    {
      class maslb_TRACKHandler
        : public TerminatorHandler
      {

        // Constructors
        public:
          maslb_TRACKHandler ( );


      };
    }
  }
}
#endif // Inspector_UI_TRACK_hh
