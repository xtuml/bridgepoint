//
// File: Transient__Tracking__GoalSpecPopulation.hh
//
#ifndef Transient_Tracking_Goal_Spec_Population_hh
#define Transient_Tracking_Goal_Spec_Population_hh

#include "__Tracking__GoalSpec.hh"
#include "__Tracking__GoalSpecPopulation.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include "boost/unordered_map.hpp"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "transient/Population.hh"

namespace masld_Tracking
{
  class maslt_GoalCriteria;
  class maslt_GoalSpan;
}
namespace transient
{
  namespace masld_Tracking
  {
    class maslo_GoalSpecPopulation
      : public TransientPopulation< ::masld_Tracking::maslo_GoalSpec,::masld_Tracking::maslo_GoalSpecPopulation>
    {

      // Instance Creation
      private:
        maslo_GoalSpecPopulation ( );
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> createInstance ( double                                      masla_minimum,
                                                                                     double                                      masla_maximum,
                                                                                     double                                      masla_span,
                                                                                     const ::masld_Tracking::maslt_GoalCriteria& masla_criteriaType,
                                                                                     const ::masld_Tracking::maslt_GoalSpan&     masla_spanType,
                                                                                     int32_t                                     masla_sequenceNumber,
                                                                                     const ::SWA::Timestamp&                     masla_session_startTime,
                                                                                     int32_t                                     masla_last_goal_ID );


      // Find routines
      public:
        // MASL find: (sequenceNumber = p1)
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> findOne_OPmasl_sequenceNumber_maslEQp1CP ( int32_t p1 ) const;


      // Singleton Registration
      public:
        static maslo_GoalSpecPopulation& getPopulation ( );
      private:
        static bool registered;


      // Queries
      private:
        ::boost::unordered_map< ::boost::tuple<int32_t,::SWA::Timestamp>,::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> > masla_sequenceNumbermasla_session_startTime_Lookup;
        virtual void instanceCreated ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> instance );
        virtual void instanceDeleted ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_GoalSpec> instance );
      protected:
        bool exists_masla_sequenceNumbermasla_session_startTime ( int32_t                 masla_sequenceNumber,
                                                                  const ::SWA::Timestamp& masla_session_startTime ) const;


    };
  }
}
#endif // Transient_Tracking_Goal_Spec_Population_hh
