//
// File: Inspector__UI__TestCase.hh
//
#ifndef Inspector_UI_Test_Case_hh
#define Inspector_UI_Test_Case_hh

#include "__UI__TestCase.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_UI
  {
    namespace maslo_TestCase
    {
      class maslo_TestCaseHandler
        : public ObjectHandler< ::masld_UI::maslo_TestCase>
      {

        // Constructors
        public:
          maslo_TestCaseHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                         channel,
                                       ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> instance,
                                       int                                           relId ) const;


      };
    }
  }
}
#endif // Inspector_UI_Test_Case_hh
