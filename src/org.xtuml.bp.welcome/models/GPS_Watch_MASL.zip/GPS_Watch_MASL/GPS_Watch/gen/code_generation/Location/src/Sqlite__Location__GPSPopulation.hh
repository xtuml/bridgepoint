//
// File: Sqlite__Location__GPSPopulation.hh
//
#ifndef Sqlite_Location_GPS_Population_hh
#define Sqlite_Location_GPS_Population_hh

#include "Sqlite__Location__GPS.hh"
#include "Sqlite__Location__GPSMapper.hh"
#include "__Location__GPS.hh"
#include "__Location__GPSPopulation.hh"
#include "boost/signals2.hpp"
#include "sql/Population.hh"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_Location
  {
    class maslo_GPSPopulation
      : public ::SQL::SqlPopulation< ::masld_Location::maslo_GPS,maslo_GPS,maslo_GPSMapper,::masld_Location::maslo_GPSPopulation>
    {

      // Constructors and Destructors
      private:
        maslo_GPSPopulation ( );
        ~maslo_GPSPopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> createInstance ( const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                                double                                 masla_currentLatitude,
                                                                                double                                 masla_currentLongitude,
                                                                                int32_t                                masla_motionSegments,
                                                                                int32_t                                masla_id,
                                                                                ::masld_Location::maslo_GPS::Type      currentState );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> instance );


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_Location::maslo_GPS> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Singleton Registration
      public:
        static maslo_GPSPopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;


    };
  }
}
#endif // Sqlite_Location_GPS_Population_hh
