//
// File: __GPS_Watch__Tracking__LOC__getLocation.hh
//
#ifndef _GPS_Watch_Tracking_LOC_get_Location_hh
#define _GPS_Watch_Tracking_LOC_get_Location_hh

namespace maslp_GPS_Watch
{
  namespace masld_Tracking
  {
    namespace maslb_LOC
    {
      void masls_getLocation ( double& maslp_longitude,
                               double& maslp_latitude );
    }
  }
}
#endif // _GPS_Watch_Tracking_LOC_get_Location_hh
