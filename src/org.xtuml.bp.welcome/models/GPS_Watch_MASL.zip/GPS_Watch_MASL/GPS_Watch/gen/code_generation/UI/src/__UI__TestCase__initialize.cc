//
// File: __UI__TestCase__initialize.cc
//
#include "LOG_OOA/__LOG_services.hh"
#include "UI_OOA/__UI.hh"
#include "UI_OOA/__UI_interface.hh"
#include "__UI__TestCase.hh"
#include "boost/shared_ptr.hpp"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"
#include "swa/types.hh"

namespace masld_UI
{
  void maslo_TestCase::state_maslst_initialize ( int32_t maslp_iterations )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringState enteringActionMarker(getDomain().getId(), objectId_maslo_TestCase, stateId_maslst_initialize);
      ::SWA::Stack::DeclareThis thisVar(this);
      ::SWA::Stack::DeclareParameter pm_maslp_iterations(maslp_iterations);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // LOG::LogInfo("Start of test case")
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          ::masld_LOG::interceptor_masls_LogInfo::instance().callService()( ::SWA::String( "Start of test case" ) );
        }

        // this.iterations := (iterations * 2);
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          ::SWA::ObjectPtr<maslo_TestCase>( this )->set_masla_iterations( maslp_iterations * 2ll );
        }

        // generate TestCase.initializationComplete () to this;
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          ::SWA::Process::getInstance().getEventQueue().addEvent( ::SWA::ObjectPtr<maslo_TestCase>( this )->create_maslo_TestCase_maslev_initializationComplete( objectId_maslo_TestCase, getArchitectureId() ) );
        }
      }
    }
  }

}
