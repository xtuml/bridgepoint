//
// File: Sqlite__Tracking__Achievement.hh
//
#ifndef Sqlite_Tracking_Achievement_hh
#define Sqlite_Tracking_Achievement_hh

#include "__Tracking__Achievement.hh"
#include "boost/tuple/tuple_comparison.hpp"
#include <cstddef>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/tuple_hash.hh"
#include "swa/types.hh"

namespace masld_Tracking
{
  class maslo_Goal;
}
namespace SQLITE
{
  namespace masld_Tracking
  {
    class maslo_Achievement
      : public ::masld_Tracking::maslo_Achievement
    {

      // Type definitions
      public:
        typedef ::boost::tuple<int32_t,::SWA::Timestamp,int32_t,int32_t> PrimaryKeyType;
        typedef ::boost::tuple<int32_t,::SWA::Timestamp,int32_t,int32_t> IndexKeyType_1;


      // Constructors and Destructors
      public:
        maslo_Achievement ( ::SWA::IdType architectureId );
        maslo_Achievement ( ::SWA::IdType           architectureId,
                            int32_t                 masla_startTime,
                            int32_t                 masla_endTime,
                            const ::SWA::Timestamp& masla_session_startTime,
                            int32_t                 masla_goal_ID,
                            int32_t                 masla_spec_sequenceNumber );


      // Setters for each object attribute
      public:
        void set_masla_startTime ( int32_t value )
        {
          this->masla_startTime = value;
          markAsModified();
        }
        virtual void set_masla_endTime ( int32_t value )
        {
          this->masla_endTime = value;
          markAsModified();
        }
        void set_masla_session_startTime ( const ::SWA::Timestamp& value )
        {
          this->masla_session_startTime = value;
          markAsModified();
        }
        void set_masla_goal_ID ( int32_t value )
        {
          this->masla_goal_ID = value;
          markAsModified();
        }
        void set_masla_spec_sequenceNumber ( int32_t value )
        {
          this->masla_spec_sequenceNumber = value;
          markAsModified();
        }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_startTime ( ) const { return masla_startTime; }
        virtual int32_t get_masla_endTime ( ) const { return masla_endTime; }
        virtual ::SWA::Timestamp get_masla_session_startTime ( ) const { return masla_session_startTime; }
        virtual int32_t get_masla_goal_ID ( ) const { return masla_goal_ID; }
        virtual int32_t get_masla_spec_sequenceNumber ( ) const { return masla_spec_sequenceNumber; }
        const PrimaryKeyType getPrimaryKey ( );
        const IndexKeyType_1 get_index_1 ( );


      // Relationship Navigators
      public:
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> navigate_R12_specifies_achievement_of_Goal ( ) const;
        virtual ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal> navigate_R14_is_open_for_Goal ( ) const;


      // Relationship Counts
      public:
        virtual ::std::size_t count_R12_specifies_achievement_of_Goal ( ) const;
        virtual ::std::size_t count_R14_is_open_for_Goal ( ) const;


      // Relationship Linkers
      public:
        virtual void link_R12_specifies_achievement_of_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs );
        virtual void unlink_R12_specifies_achievement_of_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs );
        virtual void link_R14_is_open_for_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs );
        virtual void unlink_R14_is_open_for_Goal ( const ::SWA::ObjectPtr< ::masld_Tracking::maslo_Goal>& rhs );


      // Rdbms required functions
      public:
        void markAsClean ( );
        void markAsModified ( );


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_startTime;
        int32_t masla_endTime;
        ::SWA::Timestamp masla_session_startTime;
        int32_t masla_goal_ID;
        int32_t masla_spec_sequenceNumber;


      // Rdbms required data members
      private:
        bool dirty;
        bool constructFromDb;


    };
  }
}
#endif // Sqlite_Tracking_Achievement_hh
