//
// File: Transient__UI__UIConstants.hh
//
#ifndef Transient_UI_UI_Constants_hh
#define Transient_UI_UI_Constants_hh

#include "__UI__UIConstants.hh"
#include <stdint.h>
#include "swa/types.hh"

namespace transient
{
  namespace masld_UI
  {
    class maslo_UIConstants
      : public ::masld_UI::maslo_UIConstants
    {

      // Constructors and Destructors
      public:
        maslo_UIConstants ( int32_t masla_id,
                            int32_t masla_SIGNAL_NO_NULL_SIGNAL,
                            int32_t masla_SIGNAL_NO_START_STOP_PRESSED,
                            int32_t masla_SIGNAL_NO_TARGET_PRESSED,
                            int32_t masla_SIGNAL_NO_LAP_RESET_PRESSED,
                            int32_t masla_SIGNAL_NO_LIGHT_PRESSED,
                            int32_t masla_SIGNAL_NO_MODE_PRESSED,
                            int32_t masla_SOCKET_ERROR,
                            int32_t masla_tick_period );


      // Setters for each object attribute
      public:
        virtual void set_masla_SIGNAL_NO_NULL_SIGNAL ( int32_t value ) { this->masla_SIGNAL_NO_NULL_SIGNAL = value; }
        virtual void set_masla_SIGNAL_NO_START_STOP_PRESSED ( int32_t value ) { this->masla_SIGNAL_NO_START_STOP_PRESSED = value; }
        virtual void set_masla_SIGNAL_NO_TARGET_PRESSED ( int32_t value ) { this->masla_SIGNAL_NO_TARGET_PRESSED = value; }
        virtual void set_masla_SIGNAL_NO_LAP_RESET_PRESSED ( int32_t value ) { this->masla_SIGNAL_NO_LAP_RESET_PRESSED = value; }
        virtual void set_masla_SIGNAL_NO_LIGHT_PRESSED ( int32_t value ) { this->masla_SIGNAL_NO_LIGHT_PRESSED = value; }
        virtual void set_masla_SIGNAL_NO_MODE_PRESSED ( int32_t value ) { this->masla_SIGNAL_NO_MODE_PRESSED = value; }
        virtual void set_masla_SOCKET_ERROR ( int32_t value ) { this->masla_SOCKET_ERROR = value; }
        virtual void set_masla_tick_period ( int32_t value ) { this->masla_tick_period = value; }


      // Getters for each object attribute
      public:
        virtual ::SWA::IdType getArchitectureId ( ) const { return architectureId; }
        virtual int32_t get_masla_id ( ) const { return masla_id; }
        virtual int32_t get_masla_SIGNAL_NO_NULL_SIGNAL ( ) const { return masla_SIGNAL_NO_NULL_SIGNAL; }
        virtual int32_t get_masla_SIGNAL_NO_START_STOP_PRESSED ( ) const { return masla_SIGNAL_NO_START_STOP_PRESSED; }
        virtual int32_t get_masla_SIGNAL_NO_TARGET_PRESSED ( ) const { return masla_SIGNAL_NO_TARGET_PRESSED; }
        virtual int32_t get_masla_SIGNAL_NO_LAP_RESET_PRESSED ( ) const { return masla_SIGNAL_NO_LAP_RESET_PRESSED; }
        virtual int32_t get_masla_SIGNAL_NO_LIGHT_PRESSED ( ) const { return masla_SIGNAL_NO_LIGHT_PRESSED; }
        virtual int32_t get_masla_SIGNAL_NO_MODE_PRESSED ( ) const { return masla_SIGNAL_NO_MODE_PRESSED; }
        virtual int32_t get_masla_SOCKET_ERROR ( ) const { return masla_SOCKET_ERROR; }
        virtual int32_t get_masla_tick_period ( ) const { return masla_tick_period; }


      // Storage for each object attribute
      private:
        ::SWA::IdType architectureId;
        int32_t masla_id;
        int32_t masla_SIGNAL_NO_NULL_SIGNAL;
        int32_t masla_SIGNAL_NO_START_STOP_PRESSED;
        int32_t masla_SIGNAL_NO_TARGET_PRESSED;
        int32_t masla_SIGNAL_NO_LAP_RESET_PRESSED;
        int32_t masla_SIGNAL_NO_LIGHT_PRESSED;
        int32_t masla_SIGNAL_NO_MODE_PRESSED;
        int32_t masla_SOCKET_ERROR;
        int32_t masla_tick_period;


    };
  }
}
#endif // Transient_UI_UI_Constants_hh
