//
// File: Inspector__Location__simulatedGPS.hh
//
#ifndef Inspector_Location_simulated_GPS_hh
#define Inspector_Location_simulated_GPS_hh

#include "__Location__simulatedGPS.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/ObjectHandler.hh"
#include <string>
#include "swa/ObjectPtr.hh"

namespace Inspector
{
  namespace masld_Location
  {
    namespace maslo_simulatedGPS
    {
      class maslo_simulatedGPSHandler
        : public ObjectHandler< ::masld_Location::maslo_simulatedGPS>
      {

        // Constructors
        public:
          maslo_simulatedGPSHandler ( );


        // Relationship Navigators
        public:
          void createInstance ( CommunicationChannel& channel ) const;
          ::std::string getIdentifierText ( ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> instance ) const;
          void writeRelatedInstances ( CommunicationChannel&                                   channel,
                                       ::SWA::ObjectPtr< ::masld_Location::maslo_simulatedGPS> instance,
                                       int                                                     relId ) const;


      };
    }
  }
}
#endif // Inspector_Location_simulated_GPS_hh
