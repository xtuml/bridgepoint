//
// File: Sqlite__UI__UIPopulation.cc
//
#include "Sqlite__UI__UIPopulation.hh"
#include "__UI__UI.hh"
#include "boost/bind.hpp"
#include "boost/signals2.hpp"
#include <stdint.h>
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Process.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_UI
  {
    maslo_UIPopulation::maslo_UIPopulation ( )
    {
    }

    maslo_UIPopulation::~maslo_UIPopulation ( )
    {
    }

    void maslo_UIPopulation::initialise ( )
    {
      mapper->initialise();
    }

    maslo_UIPopulation& maslo_UIPopulation::getPopulation ( )
    {
      static maslo_UIPopulation population;
      return population;
    }

    bool maslo_UIPopulation::registered = maslo_UIPopulation::registerSingleton( &maslo_UIPopulation::getPopulation );

    ::boost::signals2::connection maslo_UIPopulation::initialised = ::SWA::Process::getInstance().registerInitialisingListener( ::boost::bind( &maslo_UIPopulation::initialise, ::boost::bind( &maslo_UIPopulation::getPopulation ) ) );

    ::SWA::ObjectPtr< ::masld_UI::maslo_UI> maslo_UIPopulation::findObject ( const ::SWA::IdType& obj )
    {
      return mapper->find( obj );
    }

    ::SWA::Set< ::SWA::ObjectPtr< ::masld_UI::maslo_UI> > maslo_UIPopulation::findObject ( const MapperType::PsObjectIdSet& obj )
    {
      MapperType::PsObjectPtrSet objectSet = mapper->find( obj );
      return ::SWA::Set< ::SWA::ObjectPtr< ::masld_UI::maslo_UI> >( objectSet.begin(), objectSet.end(), true );
    }

    ::SWA::ObjectPtr< ::masld_UI::maslo_UI> maslo_UIPopulation::createInstance ( int32_t                                masla_id,
                                                                                 int32_t                                masla_socket_id,
                                                                                 const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                                 ::masld_UI::maslo_UI::Type             currentState )
    {
      return mapper->createInstance( masla_id, masla_socket_id, masla_timer, currentState );
    }

    void maslo_UIPopulation::deleteInstance ( ::SWA::ObjectPtr< ::masld_UI::maslo_UI> instance )
    {
      {
      }
      mapper->deleteInstance( instance );
    }

  }
}
