//
// File: Inspector__Tracking__HeartRateConstants.cc
//
#include "Inspector__Tracking__HeartRateConstants.hh"
#include "__Tracking__HeartRateConstants.hh"
#include "boost/lexical_cast.hpp"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include <string>
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_HeartRateConstants
    {
      class masls_initializeHandler
        : public ActionHandler
      {

        public:
          Callable getInvoker ( CommunicationChannel& channel ) const;
          void writeLocalVars ( CommunicationChannel&    channel,
                                const ::SWA::StackFrame& frame ) const;


      };
      class masls_initializeInvoker
      {

        public:
          masls_initializeInvoker ( CommunicationChannel& channel )

          {
          }
          void operator() ( ) { ::masld_Tracking::maslo_HeartRateConstants::masls_initialize(); }


      };
      Callable masls_initializeHandler::getInvoker ( CommunicationChannel& channel ) const
      {
        return masls_initializeInvoker( channel );
      }

      void masls_initializeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
      {

        // Write Local Variables
        channel << static_cast<int32_t>( frame.getLocalVars().size() );
        for ( uint32_t i = 0; i < static_cast<int32_t>( frame.getLocalVars().size() ); ++i )
        {
          channel << frame.getLocalVars()[i].getId();
          switch ( frame.getLocalVars()[i].getId() )
          {
            case 0:

              // Write hrc
              channel << frame.getLocalVars()[i].getValue< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> >();
              break;

          }

        }
      }

      maslo_HeartRateConstantsHandler::maslo_HeartRateConstantsHandler ( )
      {
        registerServiceHandler( ::masld_Tracking::maslo_HeartRateConstants::serviceId_masls_initialize, ::boost::shared_ptr<ActionHandler>( new masls_initializeHandler() ) );
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslo_HeartRateConstants> ( const ::masld_Tracking::maslo_HeartRateConstants& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_id() );
    write( instance.get_masla_HeartRateAveragingWindow() );
    write( instance.get_masla_HeartRateSamplingPeriod() );
  }

  namespace masld_Tracking
  {
    namespace maslo_HeartRateConstants
    {
      void maslo_HeartRateConstantsHandler::createInstance ( CommunicationChannel& channel ) const
      {
        int32_t masla_id;
        int32_t masla_HeartRateAveragingWindow;
        int32_t masla_HeartRateSamplingPeriod;
        channel >> masla_id >> masla_HeartRateAveragingWindow >> masla_HeartRateSamplingPeriod;
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> instance = ::masld_Tracking::maslo_HeartRateConstants::createInstance( masla_id, masla_HeartRateAveragingWindow, masla_HeartRateSamplingPeriod );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_HeartRateConstantsHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_id() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> > ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_Tracking::maslo_HeartRateConstants::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_Tracking
  {
    namespace maslo_HeartRateConstants
    {
      void maslo_HeartRateConstantsHandler::writeRelatedInstances ( CommunicationChannel&                                         channel,
                                                                    ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateConstants> instance,
                                                                    int                                                           relId ) const
      {
        switch ( relId )
        {
        }

      }

    }
  }
}
