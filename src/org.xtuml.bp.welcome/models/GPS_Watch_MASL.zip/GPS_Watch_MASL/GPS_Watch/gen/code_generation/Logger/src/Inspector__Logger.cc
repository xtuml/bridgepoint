//
// File: Inspector__Logger.cc
//
#include "Logger_OOA/__Logger_interface.hh"
#include "Logger_OOA/__Logger_services.hh"
#include "Logger_OOA/__Logger_types.hh"
#include "boost/shared_ptr.hpp"
#include "inspector/ActionHandler.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/ProcessHandler.hh"
#include "inspector/types.hh"
#include <stdint.h>
#include "swa/Process.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"

namespace Inspector
{
  namespace masld_Logger
  {
    class masls_logHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_logInvoker
    {

      public:
        masls_logInvoker ( CommunicationChannel& channel )
          : maslp_priority(),
            maslp_message()

        {
          channel >> maslp_priority;
          channel >> maslp_message;
        }
        void operator() ( ) { ::masld_Logger::interceptor_masls_log::instance().callService()( maslp_priority, maslp_message ); }


      private:
        ::masld_Logger::maslt_Priority maslp_priority;
        ::SWA::String maslp_message;


    };
    class masls_overload1_logHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_logInvoker
    {

      public:
        masls_overload1_logInvoker ( CommunicationChannel& channel )
          : maslp_priority(),
            maslp_logger(),
            maslp_message()

        {
          channel >> maslp_priority;
          channel >> maslp_logger;
          channel >> maslp_message;
        }
        void operator() ( ) { ::masld_Logger::interceptor_masls_overload1_log::instance().callService()( maslp_priority, maslp_logger, maslp_message ); }


      private:
        ::masld_Logger::maslt_Priority maslp_priority;
        ::SWA::String maslp_logger;
        ::SWA::String maslp_message;


    };
    class masls_traceHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_traceInvoker
    {

      public:
        masls_traceInvoker ( CommunicationChannel& channel )
          : maslp_message()
 { channel >> maslp_message; }
        void operator() ( ) { ::masld_Logger::interceptor_masls_trace::instance().callService()( maslp_message ); }


      private:
        ::SWA::String maslp_message;


    };
    class masls_overload1_traceHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_traceInvoker
    {

      public:
        masls_overload1_traceInvoker ( CommunicationChannel& channel )
          : maslp_logger(),
            maslp_message()

        {
          channel >> maslp_logger;
          channel >> maslp_message;
        }
        void operator() ( ) { ::masld_Logger::interceptor_masls_overload1_trace::instance().callService()( maslp_logger, maslp_message ); }


      private:
        ::SWA::String maslp_logger;
        ::SWA::String maslp_message;


    };
    class masls_debugHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_debugInvoker
    {

      public:
        masls_debugInvoker ( CommunicationChannel& channel )
          : maslp_message()
 { channel >> maslp_message; }
        void operator() ( ) { ::masld_Logger::interceptor_masls_debug::instance().callService()( maslp_message ); }


      private:
        ::SWA::String maslp_message;


    };
    class masls_overload1_debugHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_debugInvoker
    {

      public:
        masls_overload1_debugInvoker ( CommunicationChannel& channel )
          : maslp_logger(),
            maslp_message()

        {
          channel >> maslp_logger;
          channel >> maslp_message;
        }
        void operator() ( ) { ::masld_Logger::interceptor_masls_overload1_debug::instance().callService()( maslp_logger, maslp_message ); }


      private:
        ::SWA::String maslp_logger;
        ::SWA::String maslp_message;


    };
    class masls_informationHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_informationInvoker
    {

      public:
        masls_informationInvoker ( CommunicationChannel& channel )
          : maslp_message()
 { channel >> maslp_message; }
        void operator() ( ) { ::masld_Logger::interceptor_masls_information::instance().callService()( maslp_message ); }


      private:
        ::SWA::String maslp_message;


    };
    class masls_overload1_informationHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_informationInvoker
    {

      public:
        masls_overload1_informationInvoker ( CommunicationChannel& channel )
          : maslp_logger(),
            maslp_message()

        {
          channel >> maslp_logger;
          channel >> maslp_message;
        }
        void operator() ( ) { ::masld_Logger::interceptor_masls_overload1_information::instance().callService()( maslp_logger, maslp_message ); }


      private:
        ::SWA::String maslp_logger;
        ::SWA::String maslp_message;


    };
    class masls_noticeHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_noticeInvoker
    {

      public:
        masls_noticeInvoker ( CommunicationChannel& channel )
          : maslp_message()
 { channel >> maslp_message; }
        void operator() ( ) { ::masld_Logger::interceptor_masls_notice::instance().callService()( maslp_message ); }


      private:
        ::SWA::String maslp_message;


    };
    class masls_overload1_noticeHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_noticeInvoker
    {

      public:
        masls_overload1_noticeInvoker ( CommunicationChannel& channel )
          : maslp_logger(),
            maslp_message()

        {
          channel >> maslp_logger;
          channel >> maslp_message;
        }
        void operator() ( ) { ::masld_Logger::interceptor_masls_overload1_notice::instance().callService()( maslp_logger, maslp_message ); }


      private:
        ::SWA::String maslp_logger;
        ::SWA::String maslp_message;


    };
    class masls_warningHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_warningInvoker
    {

      public:
        masls_warningInvoker ( CommunicationChannel& channel )
          : maslp_message()
 { channel >> maslp_message; }
        void operator() ( ) { ::masld_Logger::interceptor_masls_warning::instance().callService()( maslp_message ); }


      private:
        ::SWA::String maslp_message;


    };
    class masls_overload1_warningHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_warningInvoker
    {

      public:
        masls_overload1_warningInvoker ( CommunicationChannel& channel )
          : maslp_logger(),
            maslp_message()

        {
          channel >> maslp_logger;
          channel >> maslp_message;
        }
        void operator() ( ) { ::masld_Logger::interceptor_masls_overload1_warning::instance().callService()( maslp_logger, maslp_message ); }


      private:
        ::SWA::String maslp_logger;
        ::SWA::String maslp_message;


    };
    class masls_errorHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_errorInvoker
    {

      public:
        masls_errorInvoker ( CommunicationChannel& channel )
          : maslp_message()
 { channel >> maslp_message; }
        void operator() ( ) { ::masld_Logger::interceptor_masls_error::instance().callService()( maslp_message ); }


      private:
        ::SWA::String maslp_message;


    };
    class masls_overload1_errorHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_errorInvoker
    {

      public:
        masls_overload1_errorInvoker ( CommunicationChannel& channel )
          : maslp_logger(),
            maslp_message()

        {
          channel >> maslp_logger;
          channel >> maslp_message;
        }
        void operator() ( ) { ::masld_Logger::interceptor_masls_overload1_error::instance().callService()( maslp_logger, maslp_message ); }


      private:
        ::SWA::String maslp_logger;
        ::SWA::String maslp_message;


    };
    class masls_criticalHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_criticalInvoker
    {

      public:
        masls_criticalInvoker ( CommunicationChannel& channel )
          : maslp_message()
 { channel >> maslp_message; }
        void operator() ( ) { ::masld_Logger::interceptor_masls_critical::instance().callService()( maslp_message ); }


      private:
        ::SWA::String maslp_message;


    };
    class masls_overload1_criticalHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_criticalInvoker
    {

      public:
        masls_overload1_criticalInvoker ( CommunicationChannel& channel )
          : maslp_logger(),
            maslp_message()

        {
          channel >> maslp_logger;
          channel >> maslp_message;
        }
        void operator() ( ) { ::masld_Logger::interceptor_masls_overload1_critical::instance().callService()( maslp_logger, maslp_message ); }


      private:
        ::SWA::String maslp_logger;
        ::SWA::String maslp_message;


    };
    class masls_fatalHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_fatalInvoker
    {

      public:
        masls_fatalInvoker ( CommunicationChannel& channel )
          : maslp_message()
 { channel >> maslp_message; }
        void operator() ( ) { ::masld_Logger::interceptor_masls_fatal::instance().callService()( maslp_message ); }


      private:
        ::SWA::String maslp_message;


    };
    class masls_overload1_fatalHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_fatalInvoker
    {

      public:
        masls_overload1_fatalInvoker ( CommunicationChannel& channel )
          : maslp_logger(),
            maslp_message()

        {
          channel >> maslp_logger;
          channel >> maslp_message;
        }
        void operator() ( ) { ::masld_Logger::interceptor_masls_overload1_fatal::instance().callService()( maslp_logger, maslp_message ); }


      private:
        ::SWA::String maslp_logger;
        ::SWA::String maslp_message;


    };
    class masls_setLogLevelHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_setLogLevelInvoker
    {

      public:
        masls_setLogLevelInvoker ( CommunicationChannel& channel )
          : maslp_priority()
 { channel >> maslp_priority; }
        void operator() ( ) { ::masld_Logger::interceptor_masls_setLogLevel::instance().callService()( maslp_priority ); }


      private:
        ::masld_Logger::maslt_Priority maslp_priority;


    };
    class masls_overload1_setLogLevelHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_overload1_setLogLevelInvoker
    {

      public:
        masls_overload1_setLogLevelInvoker ( CommunicationChannel& channel )
          : maslp_logger(),
            maslp_priority()

        {
          channel >> maslp_logger;
          channel >> maslp_priority;
        }
        void operator() ( ) { ::masld_Logger::interceptor_masls_overload1_setLogLevel::instance().callService()( maslp_logger, maslp_priority ); }


      private:
        ::SWA::String maslp_logger;
        ::masld_Logger::maslt_Priority maslp_priority;


    };
    class masls_printLoggersHandler
      : public ActionHandler
    {

      public:
        Callable getInvoker ( CommunicationChannel& channel ) const;
        void writeLocalVars ( CommunicationChannel&    channel,
                              const ::SWA::StackFrame& frame ) const;


    };
    class masls_printLoggersInvoker
    {

      public:
        masls_printLoggersInvoker ( CommunicationChannel& channel )

        {
        }
        void operator() ( ) { ::masld_Logger::interceptor_masls_printLoggers::instance().callService()(); }


    };
    class masld_LoggerHandler
      : public DomainHandler
    {

      public:
        masld_LoggerHandler ( );
        void createRelationship ( CommunicationChannel& channel,
                                  int                   relId );


    };
    Callable masls_logHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_logInvoker( channel );
    }

    void masls_logHandler::writeLocalVars ( CommunicationChannel&    channel,
                                            const ::SWA::StackFrame& frame ) const
    {

      // Write priority
      channel << frame.getParameters()[0].getValue< ::masld_Logger::maslt_Priority>();

      // Write message
      channel << frame.getParameters()[1].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_logHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_logInvoker( channel );
    }

    void masls_overload1_logHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                      const ::SWA::StackFrame& frame ) const
    {

      // Write priority
      channel << frame.getParameters()[0].getValue< ::masld_Logger::maslt_Priority>();

      // Write logger
      channel << frame.getParameters()[1].getValue< ::SWA::String>();

      // Write message
      channel << frame.getParameters()[2].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_traceHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_traceInvoker( channel );
    }

    void masls_traceHandler::writeLocalVars ( CommunicationChannel&    channel,
                                              const ::SWA::StackFrame& frame ) const
    {

      // Write message
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_traceHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_traceInvoker( channel );
    }

    void masls_overload1_traceHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                        const ::SWA::StackFrame& frame ) const
    {

      // Write logger
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write message
      channel << frame.getParameters()[1].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_debugHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_debugInvoker( channel );
    }

    void masls_debugHandler::writeLocalVars ( CommunicationChannel&    channel,
                                              const ::SWA::StackFrame& frame ) const
    {

      // Write message
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_debugHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_debugInvoker( channel );
    }

    void masls_overload1_debugHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                        const ::SWA::StackFrame& frame ) const
    {

      // Write logger
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write message
      channel << frame.getParameters()[1].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_informationHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_informationInvoker( channel );
    }

    void masls_informationHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                    const ::SWA::StackFrame& frame ) const
    {

      // Write message
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_informationHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_informationInvoker( channel );
    }

    void masls_overload1_informationHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                              const ::SWA::StackFrame& frame ) const
    {

      // Write logger
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write message
      channel << frame.getParameters()[1].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_noticeHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_noticeInvoker( channel );
    }

    void masls_noticeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                               const ::SWA::StackFrame& frame ) const
    {

      // Write message
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_noticeHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_noticeInvoker( channel );
    }

    void masls_overload1_noticeHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                         const ::SWA::StackFrame& frame ) const
    {

      // Write logger
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write message
      channel << frame.getParameters()[1].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_warningHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_warningInvoker( channel );
    }

    void masls_warningHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                const ::SWA::StackFrame& frame ) const
    {

      // Write message
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_warningHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_warningInvoker( channel );
    }

    void masls_overload1_warningHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                          const ::SWA::StackFrame& frame ) const
    {

      // Write logger
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write message
      channel << frame.getParameters()[1].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_errorHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_errorInvoker( channel );
    }

    void masls_errorHandler::writeLocalVars ( CommunicationChannel&    channel,
                                              const ::SWA::StackFrame& frame ) const
    {

      // Write message
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_errorHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_errorInvoker( channel );
    }

    void masls_overload1_errorHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                        const ::SWA::StackFrame& frame ) const
    {

      // Write logger
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write message
      channel << frame.getParameters()[1].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_criticalHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_criticalInvoker( channel );
    }

    void masls_criticalHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                 const ::SWA::StackFrame& frame ) const
    {

      // Write message
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_criticalHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_criticalInvoker( channel );
    }

    void masls_overload1_criticalHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                           const ::SWA::StackFrame& frame ) const
    {

      // Write logger
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write message
      channel << frame.getParameters()[1].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_fatalHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_fatalInvoker( channel );
    }

    void masls_fatalHandler::writeLocalVars ( CommunicationChannel&    channel,
                                              const ::SWA::StackFrame& frame ) const
    {

      // Write message
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_fatalHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_fatalInvoker( channel );
    }

    void masls_overload1_fatalHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                        const ::SWA::StackFrame& frame ) const
    {

      // Write logger
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write message
      channel << frame.getParameters()[1].getValue< ::SWA::String>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_setLogLevelHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_setLogLevelInvoker( channel );
    }

    void masls_setLogLevelHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                    const ::SWA::StackFrame& frame ) const
    {

      // Write priority
      channel << frame.getParameters()[0].getValue< ::masld_Logger::maslt_Priority>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_overload1_setLogLevelHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_overload1_setLogLevelInvoker( channel );
    }

    void masls_overload1_setLogLevelHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                              const ::SWA::StackFrame& frame ) const
    {

      // Write logger
      channel << frame.getParameters()[0].getValue< ::SWA::String>();

      // Write priority
      channel << frame.getParameters()[1].getValue< ::masld_Logger::maslt_Priority>();

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    Callable masls_printLoggersHandler::getInvoker ( CommunicationChannel& channel ) const
    {
      return masls_printLoggersInvoker( channel );
    }

    void masls_printLoggersHandler::writeLocalVars ( CommunicationChannel&    channel,
                                                     const ::SWA::StackFrame& frame ) const
    {

      // Write Local Variables
      channel << static_cast<int32_t>( frame.getLocalVars().size() );
    }

    masld_LoggerHandler::masld_LoggerHandler ( )
    {
      registerServiceHandler( ::masld_Logger::serviceId_masls_log, ::boost::shared_ptr<ActionHandler>( new masls_logHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_overload1_log, ::boost::shared_ptr<ActionHandler>( new masls_overload1_logHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_trace, ::boost::shared_ptr<ActionHandler>( new masls_traceHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_overload1_trace, ::boost::shared_ptr<ActionHandler>( new masls_overload1_traceHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_debug, ::boost::shared_ptr<ActionHandler>( new masls_debugHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_overload1_debug, ::boost::shared_ptr<ActionHandler>( new masls_overload1_debugHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_information, ::boost::shared_ptr<ActionHandler>( new masls_informationHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_overload1_information, ::boost::shared_ptr<ActionHandler>( new masls_overload1_informationHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_notice, ::boost::shared_ptr<ActionHandler>( new masls_noticeHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_overload1_notice, ::boost::shared_ptr<ActionHandler>( new masls_overload1_noticeHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_warning, ::boost::shared_ptr<ActionHandler>( new masls_warningHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_overload1_warning, ::boost::shared_ptr<ActionHandler>( new masls_overload1_warningHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_error, ::boost::shared_ptr<ActionHandler>( new masls_errorHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_overload1_error, ::boost::shared_ptr<ActionHandler>( new masls_overload1_errorHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_critical, ::boost::shared_ptr<ActionHandler>( new masls_criticalHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_overload1_critical, ::boost::shared_ptr<ActionHandler>( new masls_overload1_criticalHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_fatal, ::boost::shared_ptr<ActionHandler>( new masls_fatalHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_overload1_fatal, ::boost::shared_ptr<ActionHandler>( new masls_overload1_fatalHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_setLogLevel, ::boost::shared_ptr<ActionHandler>( new masls_setLogLevelHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_overload1_setLogLevel, ::boost::shared_ptr<ActionHandler>( new masls_overload1_setLogLevelHandler() ) );
      registerServiceHandler( ::masld_Logger::serviceId_masls_printLoggers, ::boost::shared_ptr<ActionHandler>( new masls_printLoggersHandler() ) );
    }

    void masld_LoggerHandler::createRelationship ( CommunicationChannel& channel,
                                                   int                   relId )
    {
      switch ( relId )
      {
      }

    }

  }
}
namespace 
{
  bool masld_Logger_registered = ::Inspector::ProcessHandler::getInstance().registerDomainHandler( ::SWA::Process::getInstance().getDomain( "Logger" ).getId(), ::boost::shared_ptr< ::Inspector::DomainHandler>( new ::Inspector::masld_Logger::masld_LoggerHandler() ) );

}
