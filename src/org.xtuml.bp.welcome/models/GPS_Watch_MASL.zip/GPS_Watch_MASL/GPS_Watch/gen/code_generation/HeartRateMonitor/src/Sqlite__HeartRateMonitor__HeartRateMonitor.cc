//
// File: Sqlite__HeartRateMonitor__HeartRateMonitor.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "Sqlite__HeartRateMonitor__HeartRateMonitor.hh"
#include "Sqlite__HeartRateMonitor__HeartRateMonitorPopulation.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include "__HeartRateMonitor__HeartRateMonitorEvents.hh"
#include "boost/shared_ptr.hpp"
#include "sqlite/BlobData.hh"
#include "sqlite/EventParameterCodecs.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_HeartRateMonitor
  {
    maslo_HeartRateMonitor::maslo_HeartRateMonitor ( ::SWA::IdType                                          architectureId,
                                                     int32_t                                                masla_recentHeartRate,
                                                     const ::SWA::EventTimers::TimerIdType&                 masla_timer,
                                                     int32_t                                                masla_id,
                                                     ::masld_HeartRateMonitor::maslo_HeartRateMonitor::Type currentState )
      : architectureId(architectureId),
        masla_recentHeartRate(masla_recentHeartRate),
        masla_timer(masla_timer),
        masla_id(masla_id),
        currentState(currentState),
        dirty(true),
        constructFromDb(false)
    {
    }

    maslo_HeartRateMonitor::maslo_HeartRateMonitor ( ::SWA::IdType architectureId )
      : architectureId(architectureId),
        masla_recentHeartRate(),
        masla_timer(),
        masla_id(),
        currentState(),
        dirty(true),
        constructFromDb(true)
    {
    }

    void maslo_HeartRateMonitor::markAsClean ( )
    {
      dirty = false;
      constructFromDb = false;
    }

    void maslo_HeartRateMonitor::markAsModified ( )
    {
      if ( constructFromDb == false && (dirty == false && isDeleted() == false) )
      {
        dirty = true;
        maslo_HeartRateMonitorPopulation::getPopulation().markAsDirty( architectureId );
      }
    }

    const maslo_HeartRateMonitor::PrimaryKeyType maslo_HeartRateMonitor::getPrimaryKey ( )
    {
      return PrimaryKeyType( masla_id );
    }

    const maslo_HeartRateMonitor::IndexKeyType_1 maslo_HeartRateMonitor::get_index_1 ( )
    {
      return IndexKeyType_1( masla_id );
    }

    void encode_maslo_HeartRateMonitor_maslev_timeout ( ::boost::shared_ptr< ::SWA::Event> event,
                                                        BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_HeartRateMonitor_maslev_timeout ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_HeartRateMonitor::Event_maslo_HeartRateMonitor_maslev_timeout() );
    }

    bool registermaslo_HeartRateMonitor_maslev_timeout = EventParameterCodecs::getInstance().registerCodec( ::masld_HeartRateMonitor::getDomain().getId(), ::masld_HeartRateMonitor::objectId_maslo_HeartRateMonitor, ::masld_HeartRateMonitor::maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_timeout, &encode_maslo_HeartRateMonitor_maslev_timeout, &decode_maslo_HeartRateMonitor_maslev_timeout );

    void encode_maslo_HeartRateMonitor_maslev_registerComplete ( ::boost::shared_ptr< ::SWA::Event> event,
                                                                 BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_HeartRateMonitor_maslev_registerComplete ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_HeartRateMonitor::Event_maslo_HeartRateMonitor_maslev_registerComplete() );
    }

    bool registermaslo_HeartRateMonitor_maslev_registerComplete = EventParameterCodecs::getInstance().registerCodec( ::masld_HeartRateMonitor::getDomain().getId(), ::masld_HeartRateMonitor::objectId_maslo_HeartRateMonitor, ::masld_HeartRateMonitor::maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_registerComplete, &encode_maslo_HeartRateMonitor_maslev_registerComplete, &decode_maslo_HeartRateMonitor_maslev_registerComplete );

    void encode_maslo_HeartRateMonitor_maslev_unregisterComplete ( ::boost::shared_ptr< ::SWA::Event> event,
                                                                   BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_HeartRateMonitor_maslev_unregisterComplete ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_HeartRateMonitor::Event_maslo_HeartRateMonitor_maslev_unregisterComplete() );
    }

    bool registermaslo_HeartRateMonitor_maslev_unregisterComplete = EventParameterCodecs::getInstance().registerCodec( ::masld_HeartRateMonitor::getDomain().getId(), ::masld_HeartRateMonitor::objectId_maslo_HeartRateMonitor, ::masld_HeartRateMonitor::maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_unregisterComplete, &encode_maslo_HeartRateMonitor_maslev_unregisterComplete, &decode_maslo_HeartRateMonitor_maslev_unregisterComplete );

    void encode_maslo_HeartRateMonitor_maslev_registerListener ( ::boost::shared_ptr< ::SWA::Event> event,
                                                                 BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_HeartRateMonitor_maslev_registerListener ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_HeartRateMonitor::Event_maslo_HeartRateMonitor_maslev_registerListener() );
    }

    bool registermaslo_HeartRateMonitor_maslev_registerListener = EventParameterCodecs::getInstance().registerCodec( ::masld_HeartRateMonitor::getDomain().getId(), ::masld_HeartRateMonitor::objectId_maslo_HeartRateMonitor, ::masld_HeartRateMonitor::maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_registerListener, &encode_maslo_HeartRateMonitor_maslev_registerListener, &decode_maslo_HeartRateMonitor_maslev_registerListener );

    void encode_maslo_HeartRateMonitor_maslev_unregisterListener ( ::boost::shared_ptr< ::SWA::Event> event,
                                                                   BlobData&                          blob )
    {
    }

    ::boost::shared_ptr< ::SWA::Event> decode_maslo_HeartRateMonitor_maslev_unregisterListener ( BlobData& blob )
    {
      return ::boost::shared_ptr< ::SWA::Event>( new ::masld_HeartRateMonitor::Event_maslo_HeartRateMonitor_maslev_unregisterListener() );
    }

    bool registermaslo_HeartRateMonitor_maslev_unregisterListener = EventParameterCodecs::getInstance().registerCodec( ::masld_HeartRateMonitor::getDomain().getId(), ::masld_HeartRateMonitor::objectId_maslo_HeartRateMonitor, ::masld_HeartRateMonitor::maslo_HeartRateMonitor::eventId_maslo_HeartRateMonitor_maslev_unregisterListener, &encode_maslo_HeartRateMonitor_maslev_unregisterListener, &decode_maslo_HeartRateMonitor_maslev_unregisterListener );

  }
}
