//
// File: Inspector__Tracking__HeartRateSample.cc
//
#include "Inspector__Tracking__HeartRateSample.hh"
#include "Tracking_OOA/__Tracking.hh"
#include "Tracking_OOA/__Tracking_interface.hh"
#include "__Tracking__HeartRateSample.hh"
#include "__Tracking__WorkoutSession.hh"
#include "boost/lexical_cast.hpp"
#include "inspector/BufferedIO.hh"
#include "inspector/CommunicationChannel.hh"
#include "inspector/DomainHandler.hh"
#include "inspector/ObjectHandler.hh"
#include "inspector/ProcessHandler.hh"
#include <stdint.h>
#include <string>
#include "swa/Domain.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace Inspector
{
  namespace masld_Tracking
  {
    namespace maslo_HeartRateSample
    {
      maslo_HeartRateSampleHandler::maslo_HeartRateSampleHandler ( )
      {
      }

    }
  }
  template<>
  void BufferedOutputStream::write< ::masld_Tracking::maslo_HeartRateSample> ( const ::masld_Tracking::maslo_HeartRateSample& instance )
  {
    write( instance.getArchitectureId() );
    write( instance.get_masla_heartRate() );
    write( instance.get_masla_time() );
    write( instance.get_masla_session_startTime() );
    write( instance.navigate_R6_was_collected_during_WorkoutSession() );
  }

  namespace masld_Tracking
  {
    namespace maslo_HeartRateSample
    {
      void maslo_HeartRateSampleHandler::createInstance ( CommunicationChannel& channel ) const
      {
        int32_t masla_heartRate;
        int32_t masla_time;
        ::SWA::Timestamp masla_session_startTime;
        channel >> masla_heartRate >> masla_time >> masla_session_startTime;
        ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> instance = ::masld_Tracking::maslo_HeartRateSample::createInstance( masla_heartRate, masla_time, masla_session_startTime );
        channel << instance->getArchitectureId();
      }

      ::std::string maslo_HeartRateSampleHandler::getIdentifierText ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> instance ) const
      {
        return ::boost::lexical_cast< ::std::string>( instance->get_masla_time() ) + "," + ::boost::lexical_cast< ::std::string>( instance->get_masla_session_startTime() );
      }

    }
  }
  template<>
  void BufferedInputStream::read< ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> > ( ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample>& instance )
  {
    bool valid;
    read( valid );
    if ( valid )
    {
      ::SWA::IdType archId;
      read( archId );
      instance = ::masld_Tracking::maslo_HeartRateSample::getInstance( archId );
    }
    else
    {
      instance = ::SWA::Null;
    }
  }

  namespace masld_Tracking
  {
    namespace maslo_HeartRateSample
    {
      void maslo_HeartRateSampleHandler::writeRelatedInstances ( CommunicationChannel&                                      channel,
                                                                 ::SWA::ObjectPtr< ::masld_Tracking::maslo_HeartRateSample> instance,
                                                                 int                                                        relId ) const
      {
        switch ( relId )
        {
          case 0:
            ProcessHandler::getInstance().getDomainHandler( ::masld_Tracking::getDomain().getId() ).getObjectHandler< ::masld_Tracking::maslo_WorkoutSession>( ::masld_Tracking::objectId_maslo_WorkoutSession ).writeInstances( channel, instance ? instance->navigate_R6_was_collected_during_WorkoutSession()
                                                                                                                                                                                                                                                   : ::SWA::ObjectPtr< ::masld_Tracking::maslo_WorkoutSession>() );
            break;

        }

      }

    }
  }
}
