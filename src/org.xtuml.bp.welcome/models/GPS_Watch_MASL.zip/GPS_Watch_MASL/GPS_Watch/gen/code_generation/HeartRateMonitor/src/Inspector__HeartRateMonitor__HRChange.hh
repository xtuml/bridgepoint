//
// File: Inspector__HeartRateMonitor__HRChange.hh
//
#ifndef Inspector_Heart_Rate_Monitor_HR_Change_hh
#define Inspector_Heart_Rate_Monitor_HR_Change_hh

#include "inspector/TerminatorHandler.hh"

namespace Inspector
{
  namespace masld_HeartRateMonitor
  {
    namespace maslb_HRChange
    {
      class maslb_HRChangeHandler
        : public TerminatorHandler
      {

        // Constructors
        public:
          maslb_HRChangeHandler ( );


      };
    }
  }
}
#endif // Inspector_Heart_Rate_Monitor_HR_Change_hh
