//
// File: Sqlite__UI__TestCasePopulation.hh
//
#ifndef Sqlite_UI_Test_Case_Population_hh
#define Sqlite_UI_Test_Case_Population_hh

#include "Sqlite__UI__TestCase.hh"
#include "Sqlite__UI__TestCaseMapper.hh"
#include "__UI__TestCase.hh"
#include "__UI__TestCasePopulation.hh"
#include "boost/signals2.hpp"
#include "sql/Population.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace SQLITE
{
  namespace masld_UI
  {
    class maslo_TestCasePopulation
      : public ::SQL::SqlPopulation< ::masld_UI::maslo_TestCase,maslo_TestCase,maslo_TestCaseMapper,::masld_UI::maslo_TestCasePopulation>
    {

      // Constructors and Destructors
      private:
        maslo_TestCasePopulation ( );
        ~maslo_TestCasePopulation ( );


      // Initialisation
      public:
        void initialise ( );


      // Instance Creation
      public:
        virtual ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> createInstance ( int32_t                          masla_iterations,
                                                                               int32_t                          masla_id,
                                                                               ::masld_UI::maslo_TestCase::Type currentState );
        virtual void deleteInstance ( ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> instance );


      // Find object Routines
      public:
        ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> findObject ( const ::SWA::IdType& obj );
        ::SWA::Set< ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> > findObject ( const MapperType::PsObjectIdSet& obj );


      // Singleton Registration
      public:
        static maslo_TestCasePopulation& getPopulation ( );


      // Attributes
      private:
        static bool registered;
        static ::boost::signals2::connection initialised;


    };
  }
}
#endif // Sqlite_UI_Test_Case_Population_hh
