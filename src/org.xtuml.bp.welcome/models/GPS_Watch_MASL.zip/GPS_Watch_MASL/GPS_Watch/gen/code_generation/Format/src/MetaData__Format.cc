//
// File: MetaData__Format.cc
//
#include "Format_OOA/MetaData__Format.hh"
#include "Format_OOA/__Format_interface.hh"
#include "Format_OOA/__Format_types.hh"
#include "metadata/MetaData.hh"
#include "swa/Domain.hh"
#include <vector>

namespace 
{
  namespace init_masld_Format
  {
    ::SWA::EnumerateMetaData get_maslt_justify_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_base_case_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_rounding_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_duration_field_MetaData ( );
    ::SWA::EnumerateMetaData get_maslt_timestamp_field_MetaData ( );
    ::SWA::ServiceMetaData get_masls_to_ascii_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_to_ascii_MetaData ( );
    ::SWA::ServiceMetaData get_masls_from_ascii_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_from_ascii_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_integer_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_format_integer_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_based_integer_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_format_based_integer_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_number_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_format_number_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_decimal_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_format_decimal_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_scientific_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_format_scientific_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_fixed_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_format_fixed_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_boolean_MetaData ( );
    ::SWA::ServiceMetaData get_masls_overload1_format_boolean_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_string_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_duration_iso_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_duration_hms_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_duration_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_timestamp_iso_ymdhms_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_timestamp_iso_ydhms_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_timestamp_iso_ywdhms_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_timestamp_compact_iso_ymdhms_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_timestamp_compact_iso_ydhms_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_timestamp_compact_iso_ywdhms_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_timestamp_dmy_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_timestamp_mdy_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_timestamp_dtg_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_timestamp_time_MetaData ( );
    ::SWA::ServiceMetaData get_masls_format_timestamp_compact_time_MetaData ( );
    ::SWA::DomainMetaData initDomainMetaData ( )
    {
      ::SWA::DomainMetaData domain(::masld_Format::getDomain().getId(), "Format", false);
      domain.addEnumerate( get_maslt_justify_MetaData() );
      domain.addEnumerate( get_maslt_base_case_MetaData() );
      domain.addEnumerate( get_maslt_rounding_MetaData() );
      domain.addEnumerate( get_maslt_duration_field_MetaData() );
      domain.addEnumerate( get_maslt_timestamp_field_MetaData() );
      domain.addService( get_masls_to_ascii_MetaData() );
      domain.addService( get_masls_overload1_to_ascii_MetaData() );
      domain.addService( get_masls_from_ascii_MetaData() );
      domain.addService( get_masls_overload1_from_ascii_MetaData() );
      domain.addService( get_masls_format_integer_MetaData() );
      domain.addService( get_masls_overload1_format_integer_MetaData() );
      domain.addService( get_masls_format_based_integer_MetaData() );
      domain.addService( get_masls_overload1_format_based_integer_MetaData() );
      domain.addService( get_masls_format_number_MetaData() );
      domain.addService( get_masls_overload1_format_number_MetaData() );
      domain.addService( get_masls_format_decimal_MetaData() );
      domain.addService( get_masls_overload1_format_decimal_MetaData() );
      domain.addService( get_masls_format_scientific_MetaData() );
      domain.addService( get_masls_overload1_format_scientific_MetaData() );
      domain.addService( get_masls_format_fixed_MetaData() );
      domain.addService( get_masls_overload1_format_fixed_MetaData() );
      domain.addService( get_masls_format_boolean_MetaData() );
      domain.addService( get_masls_overload1_format_boolean_MetaData() );
      domain.addService( get_masls_format_string_MetaData() );
      domain.addService( get_masls_format_duration_iso_MetaData() );
      domain.addService( get_masls_format_duration_hms_MetaData() );
      domain.addService( get_masls_format_duration_MetaData() );
      domain.addService( get_masls_format_timestamp_iso_ymdhms_MetaData() );
      domain.addService( get_masls_format_timestamp_iso_ydhms_MetaData() );
      domain.addService( get_masls_format_timestamp_iso_ywdhms_MetaData() );
      domain.addService( get_masls_format_timestamp_compact_iso_ymdhms_MetaData() );
      domain.addService( get_masls_format_timestamp_compact_iso_ydhms_MetaData() );
      domain.addService( get_masls_format_timestamp_compact_iso_ywdhms_MetaData() );
      domain.addService( get_masls_format_timestamp_dmy_MetaData() );
      domain.addService( get_masls_format_timestamp_mdy_MetaData() );
      domain.addService( get_masls_format_timestamp_dtg_MetaData() );
      domain.addService( get_masls_format_timestamp_time_MetaData() );
      domain.addService( get_masls_format_timestamp_compact_time_MetaData() );
      return domain;
    }

    ::SWA::DomainMetaData& getDomainMetaData ( )
    {
      static ::SWA::DomainMetaData domain = initDomainMetaData();
      return domain;
    }

    bool registered = ::SWA::ProcessMetaData::getProcess().addDomain( ::masld_Format::getDomain().getId(), &getDomainMetaData );

    ::SWA::EnumerateMetaData get_maslt_justify_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Format::typeId_maslt_justify, "justify");
      enumeration.addValue( ::masld_Format::maslt_justify::masle_left.getValue(), "left" );
      enumeration.addValue( ::masld_Format::maslt_justify::masle_right.getValue(), "right" );
      enumeration.addValue( ::masld_Format::maslt_justify::masle_internal.getValue(), "internal" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_base_case_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Format::typeId_maslt_base_case, "base_case");
      enumeration.addValue( ::masld_Format::maslt_base_case::masle_upper.getValue(), "upper" );
      enumeration.addValue( ::masld_Format::maslt_base_case::masle_lower.getValue(), "lower" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_rounding_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Format::typeId_maslt_rounding, "rounding");
      enumeration.addValue( ::masld_Format::maslt_rounding::masle_towards_zero.getValue(), "towards_zero" );
      enumeration.addValue( ::masld_Format::maslt_rounding::masle_towards_nearest.getValue(), "towards_nearest" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_duration_field_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Format::typeId_maslt_duration_field, "duration_field");
      enumeration.addValue( ::masld_Format::maslt_duration_field::masle_weeks.getValue(), "weeks" );
      enumeration.addValue( ::masld_Format::maslt_duration_field::masle_days.getValue(), "days" );
      enumeration.addValue( ::masld_Format::maslt_duration_field::masle_hours.getValue(), "hours" );
      enumeration.addValue( ::masld_Format::maslt_duration_field::masle_minutes.getValue(), "minutes" );
      enumeration.addValue( ::masld_Format::maslt_duration_field::masle_seconds.getValue(), "seconds" );
      return enumeration;
    }

    ::SWA::EnumerateMetaData get_maslt_timestamp_field_MetaData ( )
    {
      ::SWA::EnumerateMetaData enumeration(::masld_Format::typeId_maslt_timestamp_field, "timestamp_field");
      enumeration.addValue( ::masld_Format::maslt_timestamp_field::masle_year.getValue(), "year" );
      enumeration.addValue( ::masld_Format::maslt_timestamp_field::masle_month.getValue(), "month" );
      enumeration.addValue( ::masld_Format::maslt_timestamp_field::masle_week.getValue(), "week" );
      enumeration.addValue( ::masld_Format::maslt_timestamp_field::masle_day.getValue(), "day" );
      enumeration.addValue( ::masld_Format::maslt_timestamp_field::masle_hour.getValue(), "hour" );
      enumeration.addValue( ::masld_Format::maslt_timestamp_field::masle_minute.getValue(), "minute" );
      enumeration.addValue( ::masld_Format::maslt_timestamp_field::masle_second.getValue(), "second" );
      return enumeration;
    }

    ::SWA::ServiceMetaData get_masls_to_ascii_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_to_ascii, ::SWA::ServiceMetaData::Domain, "to_ascii", "anonymous byte", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Byte ), ::std::vector<int>( lines, lines + 0 ), "to_ascii.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous character", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Character ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_to_ascii_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_overload1_to_ascii, ::SWA::ServiceMetaData::Domain, "to_ascii", "anonymous sequence of byte", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Byte, 1 ), ::std::vector<int>( lines, lines + 0 ), "to_ascii.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_from_ascii_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_from_ascii, ::SWA::ServiceMetaData::Domain, "from_ascii", "anonymous character", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Character ), ::std::vector<int>( lines, lines + 0 ), "from_ascii.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous byte", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Byte ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_from_ascii_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_overload1_from_ascii, ::SWA::ServiceMetaData::Domain, "from_ascii", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "from_ascii.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous sequence of anonymous byte", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Byte, 1 ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_integer_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_integer, ::SWA::ServiceMetaData::Domain, "format_integer", "string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_integer.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous long_integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::LongInteger ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "show_positive", "boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_format_integer_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_overload1_format_integer, ::SWA::ServiceMetaData::Domain, "format_integer", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_integer.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous long_integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::LongInteger ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "show_positive", "boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "justification", "Format::justify", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_justify ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "width", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "pad", "anonymous character", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Character ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_based_integer_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_based_integer, ::SWA::ServiceMetaData::Domain, "format_based_integer", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_based_integer.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous long_integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::LongInteger ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "show_positive", "boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "base", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "base_case", "Format::base_case", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_base_case ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_format_based_integer_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_overload1_format_based_integer, ::SWA::ServiceMetaData::Domain, "format_based_integer", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_based_integer.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous long_integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::LongInteger ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "show_positive", "boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "base", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "base_case", "Format::base_case", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_base_case ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "justification", "Format::justify", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_justify ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "width", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "pad", "anonymous character", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Character ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_number_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_number, ::SWA::ServiceMetaData::Domain, "format_number", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_number.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "show_positive", "boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "sigfigs", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_format_number_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_overload1_format_number, ::SWA::ServiceMetaData::Domain, "format_number", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_number.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "show_positive", "boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "sigfigs", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "justification", "Format::justify", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_justify ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "width", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "pad", "anonymous character", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Character ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_decimal_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_decimal, ::SWA::ServiceMetaData::Domain, "format_decimal", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_decimal.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "show_positive", "boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "sigfigs", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_format_decimal_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_overload1_format_decimal, ::SWA::ServiceMetaData::Domain, "format_decimal", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_decimal.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "show_positive", "boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "sigfigs", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "justification", "Format::justify", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_justify ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "width", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "pad", "anonymous character", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Character ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_scientific_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_scientific, ::SWA::ServiceMetaData::Domain, "format_scientific", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_scientific.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "show_positive", "boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "sigfigs", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_format_scientific_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_overload1_format_scientific, ::SWA::ServiceMetaData::Domain, "format_scientific", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_scientific.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "show_positive", "boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "sigfigs", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "justification", "Format::justify", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_justify ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "width", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "pad", "anonymous character", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Character ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_fixed_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_fixed, ::SWA::ServiceMetaData::Domain, "format_fixed", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_fixed.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "show_positive", "boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "places", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_format_fixed_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_overload1_format_fixed, ::SWA::ServiceMetaData::Domain, "format_fixed", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_fixed.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous real", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Real ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "show_positive", "boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "places", "integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "justification", "Format::justify", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_justify ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "width", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "pad", "anonymous character", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Character ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_boolean_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_boolean, ::SWA::ServiceMetaData::Domain, "format_boolean", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_boolean.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_overload1_format_boolean_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_overload1_format_boolean, ::SWA::ServiceMetaData::Domain, "format_boolean", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_boolean.1.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "true_text", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "false_text", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_string_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_string, ::SWA::ServiceMetaData::Domain, "format_string", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_string.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "justification", "Format::justify", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_justify ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "width", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "pad", "anonymous character", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Character ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_duration_iso_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_duration_iso, ::SWA::ServiceMetaData::Domain, "format_duration_iso", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_duration_iso.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous duration", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Duration ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "max_field", "Format::duration_field", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_duration_field ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "min_field", "Format::duration_field", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_duration_field ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "hide_zero", "anonymous boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "places", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "truncate", "anonymous boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_duration_hms_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_duration_hms, ::SWA::ServiceMetaData::Domain, "format_duration_hms", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_duration_hms.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous duration", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Duration ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "min_field", "Format::duration_field", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_duration_field ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "places", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "truncate", "anonymous boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_duration_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_duration, ::SWA::ServiceMetaData::Domain, "format_duration", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_duration.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous duration", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Duration ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "max_field", "Format::duration_field", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_duration_field ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "min_field", "Format::duration_field", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_duration_field ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "rounding_mode", "Format::rounding", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_rounding ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "hide_zero", "anonymous boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "places", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "truncate", "anonymous boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "field_width", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "prefix", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "time_prefix", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "suffixes", "anonymous sequence of anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String, 1 ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_timestamp_iso_ymdhms_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_timestamp_iso_ymdhms, ::SWA::ServiceMetaData::Domain, "format_timestamp_iso_ymdhms", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_timestamp_iso_ymdhms.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "min_field", "Format::timestamp_field", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_timestamp_field ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "places", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "truncate", "anonymous boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_timestamp_iso_ydhms_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_timestamp_iso_ydhms, ::SWA::ServiceMetaData::Domain, "format_timestamp_iso_ydhms", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_timestamp_iso_ydhms.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "min_field", "Format::timestamp_field", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_timestamp_field ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "places", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "truncate", "anonymous boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_timestamp_iso_ywdhms_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_timestamp_iso_ywdhms, ::SWA::ServiceMetaData::Domain, "format_timestamp_iso_ywdhms", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_timestamp_iso_ywdhms.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "min_field", "Format::timestamp_field", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_timestamp_field ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "places", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "truncate", "anonymous boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_timestamp_compact_iso_ymdhms_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_timestamp_compact_iso_ymdhms, ::SWA::ServiceMetaData::Domain, "format_timestamp_compact_iso_ymdhms", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_timestamp_compact_iso_ymdhms.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "min_field", "Format::timestamp_field", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_timestamp_field ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "places", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "truncate", "anonymous boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_timestamp_compact_iso_ydhms_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_timestamp_compact_iso_ydhms, ::SWA::ServiceMetaData::Domain, "format_timestamp_compact_iso_ydhms", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_timestamp_compact_iso_ydhms.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "min_field", "Format::timestamp_field", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_timestamp_field ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "places", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "truncate", "anonymous boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_timestamp_compact_iso_ywdhms_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_timestamp_compact_iso_ywdhms, ::SWA::ServiceMetaData::Domain, "format_timestamp_compact_iso_ywdhms", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_timestamp_compact_iso_ywdhms.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "min_field", "Format::timestamp_field", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_timestamp_field ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "places", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "truncate", "anonymous boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_timestamp_dmy_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_timestamp_dmy, ::SWA::ServiceMetaData::Domain, "format_timestamp_dmy", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_timestamp_dmy.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_timestamp_mdy_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_timestamp_mdy, ::SWA::ServiceMetaData::Domain, "format_timestamp_mdy", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_timestamp_mdy.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_timestamp_dtg_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_timestamp_dtg, ::SWA::ServiceMetaData::Domain, "format_timestamp_dtg", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_timestamp_dtg.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_timestamp_time_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_timestamp_time, ::SWA::ServiceMetaData::Domain, "format_timestamp_time", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_timestamp_time.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "min_field", "Format::timestamp_field", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_timestamp_field ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "places", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "truncate", "anonymous boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      return service;
    }

    ::SWA::ServiceMetaData get_masls_format_timestamp_compact_time_MetaData ( )
    {
      int lines[] = {};
      ::SWA::ServiceMetaData service(::masld_Format::serviceId_masls_format_timestamp_compact_time, ::SWA::ServiceMetaData::Domain, "format_timestamp_compact_time", "anonymous string", ::SWA::TypeMetaData( ::SWA::TypeMetaData::String ), ::std::vector<int>( lines, lines + 0 ), "format_timestamp_compact_time.svc", "");
      service.addParameter( ::SWA::ParameterMetaData( "input", "anonymous timestamp", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Timestamp ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "min_field", "Format::timestamp_field", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Enumeration, ::masld_Format::getDomain().getId(), ::masld_Format::typeId_maslt_timestamp_field ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "places", "anonymous integer", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Integer ), false ) );
      service.addParameter( ::SWA::ParameterMetaData( "truncate", "anonymous boolean", ::SWA::TypeMetaData( ::SWA::TypeMetaData::Boolean ), false ) );
      return service;
    }

  }
}
