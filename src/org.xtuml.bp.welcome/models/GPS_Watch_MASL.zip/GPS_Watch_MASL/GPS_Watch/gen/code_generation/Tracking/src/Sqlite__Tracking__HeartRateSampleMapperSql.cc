//
// File: Sqlite__Tracking__HeartRateSampleMapperSql.cc
//
#include "Sqlite__Tracking__HeartRateSample.hh"
#include "Sqlite__Tracking__HeartRateSampleMapperSql.hh"
#include "__Tracking__HeartRateSample.hh"
#include "boost/shared_ptr.hpp"
#include "boost/tuple/tuple_comparison.hpp"
#include <map>
#include "sql/Criteria.hh"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/Schema.hh"
#include "sql/Util.hh"
#include "sqlite/Database.hh"
#include "sqlite/Exception.hh"
#include "sqlite/Resultset.hh"
#include "sqlite/SqlMonitor.hh"
#include "sqlite3.h"
#include <stdint.h>
#include <string>
#include "swa/Timestamp.hh"
#include "swa/types.hh"

namespace 
{
  const ::std::string createTableStatment ( )
  {
    return "CREATE TABLE S_Tracking_HEARTRATESAMPLE(   architecture_id  INTEGER ,   masla_heartRate INTEGER,   masla_time INTEGER,   masla_session_startTime INTEGER, PRIMARY KEY (architecture_id));\n";
  }

  bool registerSchema = ::SQL::Schema::singleton().registerTable( "S_Tracking_HEARTRATESAMPLE", createTableStatment() );

}
namespace SQLITE
{
  namespace masld_Tracking
  {
    maslo_HeartRateSampleSqlGenerator::maslo_HeartRateSampleSqlGenerator ( )
      : tableName("S_Tracking_HEARTRATESAMPLE"),
        objectName("HeartRateSample"),
        insertStatement("INSERT INTO S_Tracking_HEARTRATESAMPLE VALUES(:1,:2,:3,:4);"),
        updateStatement("UPDATE S_Tracking_HEARTRATESAMPLE SET masla_heartRate = :2  , masla_time = :3  , masla_session_startTime = :4  WHERE architecture_id = :1;"),
        deleteStatement("DELETE  FROM S_Tracking_HEARTRATESAMPLE WHERE architecture_id = :1;"),
        columnNameMapper()
    {
    }

    maslo_HeartRateSampleSqlGenerator::~maslo_HeartRateSampleSqlGenerator ( )
    {
    }

    void maslo_HeartRateSampleSqlGenerator::initialise ( )
    {
      columnNameMapper["architecture_id"] = ::std::string( "architecture_id" );
      columnNameMapper["heartRate"] = ::std::string( "masla_heartRate" );
      columnNameMapper["time"] = ::std::string( "masla_time" );
      columnNameMapper["session_startTime"] = ::std::string( "masla_session_startTime" );
      insertStatement.prepare();
      updateStatement.prepare();
      deleteStatement.prepare();
    }

    const ::std::string maslo_HeartRateSampleSqlGenerator::getDomainName ( ) const
    {
      return "Tracking";
    }

    const ::std::string& maslo_HeartRateSampleSqlGenerator::getTableName ( ) const
    {
      return tableName;
    }

    const ::std::string& maslo_HeartRateSampleSqlGenerator::getObjectName ( ) const
    {
      return objectName;
    }

    const ::std::string maslo_HeartRateSampleSqlGenerator::getColumnName ( const ::std::string& attribute ) const
    {
      ::std::map< ::std::string,::std::string>::const_iterator requiredNameItr = columnNameMapper.find( attribute );
      if ( requiredNameItr == columnNameMapper.end() )
      {
        throw SqliteException( "maslo_HeartRateSampleSqlGenerator::getColumnName - failed to find attribute name " );
      }
      return requiredNameItr->second;
    }

    void maslo_HeartRateSampleSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                       int32_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_Tracking_HEARTRATESAMPLE;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_HeartRateSampleSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_HeartRateSampleSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    void maslo_HeartRateSampleSqlGenerator::executeGetMaxColumnValue ( const ::std::string& attribute,
                                                                       int64_t&             value ) const
    {
      ::std::string valueSelect(::std::string( "SELECT max(" ) + getColumnName( attribute ) + ") FROM S_Tracking_HEARTRATESAMPLE;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_HeartRateSampleSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          value = ::SQL::stringToValue<int64_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_HeartRateSampleSqlGenerator::executeGetRowCount - query failed" );
      }
    }

    ::SWA::IdType maslo_HeartRateSampleSqlGenerator::executeGetRowCount ( ) const
    {
      int32_t rowCount = 0;
      ::std::string valueSelect("SELECT count(*) FROM S_Tracking_HEARTRATESAMPLE;");
      Database& database = Database::singleton();
      ResultSet valueResult;
      if ( database.executeQuery( valueSelect, valueResult ) == true )
      {
        if ( valueResult.getRows() != 1 && valueResult.getColumns() != 1 )
        {
          throw SqliteException( "maslo_HeartRateSampleSqlGenerator::executeGetRowCount - incorrect result contents" );
        }
        const ::std::string& cellValue = valueResult.getRow( 0 ).at( 0 );
        if ( cellValue != "NULL" )
        {
          rowCount = ::SQL::stringToValue<int32_t>( cellValue );
        }
      }
      else
      {
        throw SqliteException( "maslo_HeartRateSampleSqlGenerator::executeGetRowCount - query failed" );
      }
      return rowCount;
    }

    ::SWA::IdType maslo_HeartRateSampleSqlGenerator::executeGetMaxIdentifier ( ) const
    {
      ::SWA::IdType maxIdValue = 0;
      executeGetMaxColumnValue( "architecture_id", maxIdValue );
      return maxIdValue;
    }

    void maslo_HeartRateSampleSqlGenerator::executeUpdate ( const PsObjectPtr& object ) const
    {
      updateStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_heartRate(), object.getChecked()->get_masla_time(), object.getChecked()->get_masla_session_startTime() ) );
    }

    void maslo_HeartRateSampleSqlGenerator::executeInsert ( const PsObjectPtr& object ) const
    {
      insertStatement.execute( ::boost::make_tuple( object.getChecked()->getArchitectureId(), object.getChecked()->get_masla_heartRate(), object.getChecked()->get_masla_time(), object.getChecked()->get_masla_session_startTime() ) );
    }

    void maslo_HeartRateSampleSqlGenerator::executeRemove ( const PsObjectPtr& object ) const
    {
      deleteStatement.execute( object.getChecked()->getArchitectureId() );
    }

    void maslo_HeartRateSampleSqlGenerator::executeRemoveId ( const ::SWA::IdType object ) const
    {
      deleteStatement.execute( object );
    }

    void maslo_HeartRateSampleSqlGenerator::executeSelect ( CacheType&             cache,
                                                            const ::SQL::Criteria& criteria,
                                                            PsBaseObjectPtrSwaSet& result ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("HeartRateSample::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "HeartRateSample::executeSelect", compile_result, query );
        database.checkColumnCount( "HeartRateSample::executeSelect", sqlite3_column_count( ppStmt ), 4, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr != cache.end() )
          {
            PsBaseObjectPtr currentObject(objectItr->second.get());
            result += currentObject;
          }
          else
          {
            PsObjectPtr currentObject(new maslo_HeartRateSample(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );
            result += currentObject;

            int32_t heartRate = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_heartRate( heartRate );

            int32_t time = sqlite3_column_int( ppStmt, 2 );
            currentObject->set_masla_time( time );

            ::SWA::Timestamp session_startTime = ::SWA::Timestamp::fromNanosSinceEpoch( sqlite3_column_int64( ppStmt, 3 ) );
            currentObject->set_masla_session_startTime( session_startTime );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

    void maslo_HeartRateSampleSqlGenerator::executeSelect ( CacheType&             cache,
                                                            const ::SQL::Criteria& criteria ) const
    {
      ::std::string query = criteria.selectStatement();
      {
        Database& database = Database::singleton();

        sqlite3_stmt* ppStmt = 0;
        Database::ScopedFinalise finaliser("HeartRateSample::executeSelect", ppStmt);
        int32_t compile_result = sqlite3_prepare( database.getDatabaseImpl(), query.c_str(), -1, &ppStmt, 0 );

        database.checkCompile( "HeartRateSample::executeSelect", compile_result, query );
        database.checkColumnCount( "HeartRateSample::executeSelect", sqlite3_column_count( ppStmt ), 4, query );

        while ( sqlite3_step( ppStmt ) == SQLITE_ROW )
        {

          int32_t column0 = sqlite3_column_int( ppStmt, 0 );
          CacheType::iterator objectItr = cache.find( column0 );
          if ( objectItr == cache.end() )
          {
            PsObjectPtr currentObject(new maslo_HeartRateSample(  column0 ));
            cache.insert( CacheType::value_type( column0, ::boost::shared_ptr<PsObject>( currentObject.get() ) ) );

            int32_t heartRate = sqlite3_column_int( ppStmt, 1 );
            currentObject->set_masla_heartRate( heartRate );

            int32_t time = sqlite3_column_int( ppStmt, 2 );
            currentObject->set_masla_time( time );

            ::SWA::Timestamp session_startTime = ::SWA::Timestamp::fromNanosSinceEpoch( sqlite3_column_int64( ppStmt, 3 ) );
            currentObject->set_masla_session_startTime( session_startTime );


            currentObject->markAsClean();
          }
        }
        SqlQueryMonitor queryMonitor(query);
      }
    }

  }
}
