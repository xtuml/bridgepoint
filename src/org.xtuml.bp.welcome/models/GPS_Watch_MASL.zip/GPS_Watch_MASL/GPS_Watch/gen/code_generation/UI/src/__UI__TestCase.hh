//
// File: __UI__TestCase.hh
//
#ifndef _UI_Test_Case_hh
#define _UI_Test_Case_hh

#include "boost/shared_ptr.hpp"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/Event.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_UI
{
  class maslo_TestCase;
  class maslo_TestCase
  {

    public:
      enum Type {  maslst_pressStartStop,
                   maslst_testCaseFinished,
                   maslst_initialize,
                   maslst_Idle };


    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_TestCase> createInstance ( int32_t masla_iterations,
                                                               int32_t masla_id,
                                                               Type    currentState );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_TestCase> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_iterations ( int32_t value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual int32_t get_masla_iterations ( ) const = 0;
      virtual int32_t get_masla_id ( ) const = 0;


    // Object Services
    public:
      static void masls_execute ( );


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_TestCase> > findAll ( );
      static ::SWA::ObjectPtr<maslo_TestCase> findOne ( );
      static ::SWA::ObjectPtr<maslo_TestCase> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_TestCase ( );
      virtual ~maslo_TestCase ( );


    // Prevent copy
    private:
      maslo_TestCase ( const maslo_TestCase& rhs );
      maslo_TestCase& operator= ( const maslo_TestCase& rhs );


    // State Machine
    public:
      virtual Type getCurrentState ( ) const = 0;
      virtual void setCurrentState ( Type newState ) = 0;


    // State Actions
    private:
      void state_maslst_pressStartStop ( );
      void state_maslst_testCaseFinished ( );
      void state_maslst_initialize ( int32_t maslp_iterations );
      void state_maslst_Idle ( );


    // Generate Events
    public:
      ::boost::shared_ptr< ::SWA::Event> create_maslo_TestCase_maslev_doDelay ( int           sourceObj = -1,
                                                                                ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_TestCase_maslev_finish ( int           sourceObj = -1,
                                                                               ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_TestCase_maslev_initializationComplete ( int           sourceObj = -1,
                                                                                               ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_TestCase_maslev_initialize ( int32_t       maslp_iterations,
                                                                                   int           sourceObj = -1,
                                                                                   ::SWA::IdType sourceInstance = 0 );


    // Consume Events
    public:
      static void consume_maslo_TestCase_maslev_doDelay ( ::SWA::IdType id );
      static void consume_maslo_TestCase_maslev_finish ( ::SWA::IdType id );
      static void consume_maslo_TestCase_maslev_initializationComplete ( ::SWA::IdType id );
      static void consume_maslo_TestCase_maslev_initialize ( ::SWA::IdType id,
                                                             int32_t       maslp_iterations );


    // Process Events
    public:
      void process_maslo_TestCase_maslev_doDelay ( );
      void process_maslo_TestCase_maslev_finish ( );
      void process_maslo_TestCase_maslev_initializationComplete ( );
      void process_maslo_TestCase_maslev_initialize ( int32_t maslp_iterations );


    // Id Enumerations
    public:
      enum StateIds {  stateId_maslst_pressStartStop,
                       stateId_maslst_testCaseFinished,
                       stateId_maslst_initialize,
                       stateId_maslst_Idle };
      enum EventIds {  eventId_maslo_TestCase_maslev_doDelay,
                       eventId_maslo_TestCase_maslev_finish,
                       eventId_maslo_TestCase_maslev_initializationComplete,
                       eventId_maslo_TestCase_maslev_initialize };
      enum ServiceIds {  serviceId_masls_execute };


  };
  ::std::ostream& operator<< ( ::std::ostream&       stream,
                               const maslo_TestCase& obj );
}
#endif // _UI_Test_Case_hh
