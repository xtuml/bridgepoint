//
// File: __HeartRateMonitor__HeartRateMonitor__initialize.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor.hh"
#include "HeartRateMonitor_OOA/__HeartRateMonitor_interface.hh"
#include "__HeartRateMonitor__HeartRateMonitor.hh"
#include <stdint.h>
#include "swa/Domain.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Stack.hh"

namespace masld_HeartRateMonitor
{
  void maslo_HeartRateMonitor::masls_initialize ( )
  {

    // declare ...
    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringObjectService enteringActionMarker(getDomain().getId(), objectId_maslo_HeartRateMonitor, serviceId_masls_initialize);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(3);
      {

        // monitor : instance of HeartRateMonitor;
        ::SWA::ObjectPtr<maslo_HeartRateMonitor> maslv_monitor;
        ::SWA::Stack::DeclareLocalVariable pm_maslv_monitor(0, maslv_monitor);

        // monitor := find_one HeartRateMonitor ();
        {
          ::SWA::Stack::ExecutingStatement statement(4);
          maslv_monitor = findOne();
        }

        // if (null = monitor) then ...
        {
          ::SWA::Stack::ExecutingStatement statement(5);
          if ( ::SWA::Null == maslv_monitor )
          {

            // monitor := create HeartRateMonitor (
            //               id => 1 ,
            // Current_State => idle);
            {
              ::SWA::Stack::ExecutingStatement statement(6);
              maslv_monitor = createInstance( int32_t(), ::SWA::EventTimers::getInstance().createTimer(), 1ll, maslst_idle );
            }
          }
        }
      }
    }
  }

}
