//
// File: __Tracking__HeartRateSamplePopulation.cc
//
#include "__Tracking__HeartRateSamplePopulation.hh"

namespace masld_Tracking
{
  maslo_HeartRateSamplePopulation::maslo_HeartRateSamplePopulation ( )
  {
  }

  maslo_HeartRateSamplePopulation::~maslo_HeartRateSamplePopulation ( )
  {
  }

}
