//
// File: __Location__simulatedGPS.hh
//
#ifndef _Location_simulated_GPS_hh
#define _Location_simulated_GPS_hh

#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_Location
{
  class maslo_simulatedGPS;
  class maslo_simulatedGPS
  {

    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_simulatedGPS> createInstance ( int32_t masla_id,
                                                                   double  masla_initialLatitude,
                                                                   double  masla_initialLongitude,
                                                                   double  masla_latitudeIncrement,
                                                                   double  masla_longitudeIncrement,
                                                                   int32_t masla_updatePeriod );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_simulatedGPS> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_initialLatitude ( double value ) = 0;
      virtual void set_masla_initialLongitude ( double value ) = 0;
      virtual void set_masla_latitudeIncrement ( double value ) = 0;
      virtual void set_masla_longitudeIncrement ( double value ) = 0;
      virtual void set_masla_updatePeriod ( int32_t value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual int32_t get_masla_id ( ) const = 0;
      virtual double get_masla_initialLatitude ( ) const = 0;
      virtual double get_masla_initialLongitude ( ) const = 0;
      virtual double get_masla_latitudeIncrement ( ) const = 0;
      virtual double get_masla_longitudeIncrement ( ) const = 0;
      virtual int32_t get_masla_updatePeriod ( ) const = 0;


    // Object Services
    public:
      static void masls_initialize ( );


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_simulatedGPS> > findAll ( );
      static ::SWA::ObjectPtr<maslo_simulatedGPS> findOne ( );
      static ::SWA::ObjectPtr<maslo_simulatedGPS> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_simulatedGPS ( );
      virtual ~maslo_simulatedGPS ( );


    // Prevent copy
    private:
      maslo_simulatedGPS ( const maslo_simulatedGPS& rhs );
      maslo_simulatedGPS& operator= ( const maslo_simulatedGPS& rhs );


    // Id Enumerations
    public:
      enum StateIds {};
      enum EventIds {};
      enum ServiceIds {  serviceId_masls_initialize };


  };
  ::std::ostream& operator<< ( ::std::ostream&           stream,
                               const maslo_simulatedGPS& obj );
}
#endif // _Location_simulated_GPS_hh
