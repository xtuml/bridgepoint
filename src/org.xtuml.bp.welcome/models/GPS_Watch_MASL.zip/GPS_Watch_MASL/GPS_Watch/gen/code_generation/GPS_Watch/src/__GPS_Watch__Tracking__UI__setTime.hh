//
// File: __GPS_Watch__Tracking__UI__setTime.hh
//
#ifndef _GPS_Watch_Tracking_UI_set_Time_hh
#define _GPS_Watch_Tracking_UI_set_Time_hh

#include <stdint.h>

namespace maslp_GPS_Watch
{
  namespace masld_Tracking
  {
    namespace maslb_UI
    {
      void masls_setTime ( int32_t maslp_time );
    }
  }
}
#endif // _GPS_Watch_Tracking_UI_set_Time_hh
