//
// File: Sqlite__UI__TestCaseMapper.cc
//
#include "Sqlite__UI__TestCase.hh"
#include "Sqlite__UI__TestCaseMapper.hh"
#include "Sqlite__UI__TestCaseMapperSql.hh"
#include "__UI__TestCase.hh"
#include "boost/shared_ptr.hpp"
#include "boost/unordered_set.hpp"
#include "sql/ObjectMapper.hh"
#include "sql/ObjectSqlGenerator.hh"
#include "sql/ResourceMonitorObserver.hh"
#include <stdint.h>
#include "swa/ObjectPtr.hh"
#include "swa/ProgramError.hh"
#include "swa/types.hh"
#include <utility>

namespace SQLITE
{
  namespace masld_UI
  {
    maslo_TestCaseMapper::maslo_TestCaseMapper ( )
      : ::SQL::ObjectMapper< ::masld_UI::maslo_TestCase,maslo_TestCase>( ::boost::shared_ptr< ::SQL::ObjectSqlGenerator< ::masld_UI::maslo_TestCase,maslo_TestCase> >( new maslo_TestCaseSqlGenerator() )),
        primarykey_cache()
    {
    }

    maslo_TestCaseMapper::~maslo_TestCaseMapper ( )
    {
    }

    ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> maslo_TestCaseMapper::createInstance ( int32_t                          masla_iterations,
                                                                                         int32_t                          masla_id,
                                                                                         ::masld_UI::maslo_TestCase::Type currentState )
    {
      if ( primarykey_cache.insert( ::boost::unordered_set<maslo_TestCase::PrimaryKeyType>::value_type( masla_id ) ).second == false ) throw ::SWA::ProgramError( "identifier already in use" );
      ::SWA::IdType uniqueId = getNextArchId();
      ::boost::shared_ptr<maslo_TestCase> instance(new maslo_TestCase(  uniqueId,
                     masla_iterations,
                     masla_id,
                     currentState ));
      unitOfWorkMap.registerInsert( PsObjectPtr( instance.get() ) );
      cache.insert( ::std::make_pair( uniqueId, instance ) );
      flushCache();
      return PsObjectPtr( instance.get() );
    }

    void maslo_TestCaseMapper::deleteInstance ( ::SWA::ObjectPtr< ::masld_UI::maslo_TestCase> instance )
    {
      ::SQL::ObjectMapper< ::masld_UI::maslo_TestCase,maslo_TestCase>::deleteInstance( instance );
      primarykey_cache.erase( instance.downcast<maslo_TestCase>()->getPrimaryKey() );
    }

    bool maslo_TestCaseMapper::doPostInit ( )
    {
      if ( allLoaded == false )
      {
        loadAll();
      }
      for ( PsCachedPtrMap::iterator objItr = cache.begin(); objItr != cache.end(); ++objItr )
      {
        primarykey_cache.insert( objItr->second->getPrimaryKey() );
      }
      ::SQL::ResourceMonitorContext context;
      compact( context );
      return true;
    }

  }
}
