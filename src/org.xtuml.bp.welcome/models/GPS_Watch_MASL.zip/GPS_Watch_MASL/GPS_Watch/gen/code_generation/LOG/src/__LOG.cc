//
// File: __LOG.cc
//
#include "LOG_OOA/__LOG_interface.hh"
#include "swa/Domain.hh"

namespace masld_LOG
{
  bool initialiseDomain ( )
  {
    getDomain().setInterface( false );
    return true;
  }

  const bool domainInitialised = initialiseDomain();

}
