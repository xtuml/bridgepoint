//
// File: __UI__TRACK__startStopPressed.cc
//
#include "LOG_OOA/__LOG_services.hh"
#include "UI_OOA/__UI_interface.hh"
#include "UI_OOA/__UI_terminators.hh"
#include "swa/Domain.hh"
#include "swa/FunctionOverrider.hh"
#include "swa/Stack.hh"
#include "swa/String.hh"

namespace masld_UI
{
  void maslb_TRACK::masls_startStopPressed ( )
  {
    getInstance().override_masls_startStopPressed.getFunction()();
  }

  bool maslb_TRACK::register_masls_startStopPressed ( ::SWA::FunctionOverrider<void()>::FunctionPtr override )
  {
    getInstance().override_masls_startStopPressed.override( override );
    return true;
  }

  bool maslb_TRACK::overriden_masls_startStopPressed ( )
  {
    return getInstance().override_masls_startStopPressed.isOverridden();
  }

  void maslb_TRACK::domain_masls_startStopPressed ( )
  {

    // begin ...
    // end;
    {
      ::SWA::Stack::EnteringTerminatorService enteringActionMarker(getDomain().getId(), terminatorId_maslb_TRACK, serviceId_masls_startStopPressed);
      ::SWA::Stack::EnteredAction enteredActionMarker;
      ::SWA::Stack::ExecutingStatement statement(2);
      {

        // LOG::LogInfo("Sending message 'startStopPressed' on terminator TRACK")
        {
          ::SWA::Stack::ExecutingStatement statement(3);
          ::masld_LOG::interceptor_masls_LogInfo::instance().callService()( ::SWA::String( "Sending message 'startStopPressed' on terminator TRACK" ) );
        }
      }
    }
  }

}
