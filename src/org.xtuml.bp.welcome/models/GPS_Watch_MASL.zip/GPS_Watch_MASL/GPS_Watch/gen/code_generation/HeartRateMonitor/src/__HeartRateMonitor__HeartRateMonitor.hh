//
// File: __HeartRateMonitor__HeartRateMonitor.hh
//
#ifndef _Heart_Rate_Monitor_Heart_Rate_Monitor_hh
#define _Heart_Rate_Monitor_Heart_Rate_Monitor_hh

#include "boost/shared_ptr.hpp"
#include <cstddef>
#include <iostream>
#include <stdint.h>
#include "swa/Event.hh"
#include "swa/EventTimers.hh"
#include "swa/ObjectPtr.hh"
#include "swa/Set.hh"
#include "swa/types.hh"

namespace masld_HeartRateMonitor
{
  class maslo_HeartRateMonitor;
  class maslo_HeartRateMonitor
  {

    public:
      enum Type {  maslst_idle,
                   maslst_monitoring,
                   maslst_Registering,
                   maslst_Unregistering };


    // Instance Creation
    public:
      static ::SWA::IdType getNextArchId ( );
      static ::SWA::ObjectPtr<maslo_HeartRateMonitor> createInstance ( int32_t                                masla_recentHeartRate,
                                                                       const ::SWA::EventTimers::TimerIdType& masla_timer,
                                                                       int32_t                                masla_id,
                                                                       Type                                   currentState );
    private:
      bool isDeletedFlag;
    public:
      bool isDeleted ( ) const { return isDeletedFlag; }
      void deleteInstance ( );
      static ::std::size_t getPopulationSize ( );


    // Instance Retrieval
    public:
      static ::SWA::ObjectPtr<maslo_HeartRateMonitor> getInstance ( ::SWA::IdType id );


    // Setters for each object attribute
    public:
      virtual void set_masla_recentHeartRate ( int32_t value ) = 0;
      virtual void set_masla_timer ( const ::SWA::EventTimers::TimerIdType& value ) = 0;


    // Getters for each object attribute
    public:
      virtual ::SWA::IdType getArchitectureId ( ) const = 0;
      virtual int32_t get_masla_recentHeartRate ( ) const = 0;
      virtual ::SWA::EventTimers::TimerIdType get_masla_timer ( ) const = 0;
      virtual int32_t get_masla_id ( ) const = 0;


    // Object Services
    public:
      static void masls_initialize ( );


    // Find Functions
    public:
      static ::SWA::Set< ::SWA::ObjectPtr<maslo_HeartRateMonitor> > findAll ( );
      static ::SWA::ObjectPtr<maslo_HeartRateMonitor> findOne ( );
      static ::SWA::ObjectPtr<maslo_HeartRateMonitor> findOnly ( );


    // Constructors and Destructors
    public:
      maslo_HeartRateMonitor ( );
      virtual ~maslo_HeartRateMonitor ( );


    // Prevent copy
    private:
      maslo_HeartRateMonitor ( const maslo_HeartRateMonitor& rhs );
      maslo_HeartRateMonitor& operator= ( const maslo_HeartRateMonitor& rhs );


    // State Machine
    public:
      virtual Type getCurrentState ( ) const = 0;
      virtual void setCurrentState ( Type newState ) = 0;


    // State Actions
    private:
      void state_maslst_idle ( );
      void state_maslst_monitoring ( );
      void state_maslst_Registering ( );
      void state_maslst_Unregistering ( );


    // Generate Events
    public:
      ::boost::shared_ptr< ::SWA::Event> create_maslo_HeartRateMonitor_maslev_timeout ( int           sourceObj = -1,
                                                                                        ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_HeartRateMonitor_maslev_registerComplete ( int           sourceObj = -1,
                                                                                                 ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_HeartRateMonitor_maslev_unregisterComplete ( int           sourceObj = -1,
                                                                                                   ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_HeartRateMonitor_maslev_registerListener ( int           sourceObj = -1,
                                                                                                 ::SWA::IdType sourceInstance = 0 );
      ::boost::shared_ptr< ::SWA::Event> create_maslo_HeartRateMonitor_maslev_unregisterListener ( int           sourceObj = -1,
                                                                                                   ::SWA::IdType sourceInstance = 0 );


    // Consume Events
    public:
      static void consume_maslo_HeartRateMonitor_maslev_timeout ( ::SWA::IdType id );
      static void consume_maslo_HeartRateMonitor_maslev_registerComplete ( ::SWA::IdType id );
      static void consume_maslo_HeartRateMonitor_maslev_unregisterComplete ( ::SWA::IdType id );
      static void consume_maslo_HeartRateMonitor_maslev_registerListener ( ::SWA::IdType id );
      static void consume_maslo_HeartRateMonitor_maslev_unregisterListener ( ::SWA::IdType id );


    // Process Events
    public:
      void process_maslo_HeartRateMonitor_maslev_timeout ( );
      void process_maslo_HeartRateMonitor_maslev_registerComplete ( );
      void process_maslo_HeartRateMonitor_maslev_unregisterComplete ( );
      void process_maslo_HeartRateMonitor_maslev_registerListener ( );
      void process_maslo_HeartRateMonitor_maslev_unregisterListener ( );


    // Id Enumerations
    public:
      enum StateIds {  stateId_maslst_idle,
                       stateId_maslst_monitoring,
                       stateId_maslst_Registering,
                       stateId_maslst_Unregistering };
      enum EventIds {  eventId_maslo_HeartRateMonitor_maslev_timeout,
                       eventId_maslo_HeartRateMonitor_maslev_registerComplete,
                       eventId_maslo_HeartRateMonitor_maslev_unregisterComplete,
                       eventId_maslo_HeartRateMonitor_maslev_registerListener,
                       eventId_maslo_HeartRateMonitor_maslev_unregisterListener };
      enum ServiceIds {  serviceId_masls_initialize };


  };
  ::std::ostream& operator<< ( ::std::ostream&               stream,
                               const maslo_HeartRateMonitor& obj );
}
#endif // _Heart_Rate_Monitor_Heart_Rate_Monitor_hh
