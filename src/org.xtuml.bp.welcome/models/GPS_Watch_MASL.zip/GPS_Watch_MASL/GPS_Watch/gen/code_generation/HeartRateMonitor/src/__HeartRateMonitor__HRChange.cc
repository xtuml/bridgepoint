//
// File: __HeartRateMonitor__HRChange.cc
//
#include "HeartRateMonitor_OOA/__HeartRateMonitor_terminators.hh"
#include <stdint.h>

namespace masld_HeartRateMonitor
{
  maslb_HRChange& maslb_HRChange::getInstance ( )
  {
    static maslb_HRChange instance;
    return instance;
  }

  maslb_HRChange::maslb_HRChange ( )
    : override_masls_heartRateChanged(&domain_masls_heartRateChanged)
  {
  }

}
