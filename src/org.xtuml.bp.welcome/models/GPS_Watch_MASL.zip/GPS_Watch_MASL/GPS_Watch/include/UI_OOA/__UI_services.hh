//
// File: __UI_services.hh
//
#ifndef UI_OOA_UI_services_hh
#define UI_OOA_UI_services_hh

#include <stdint.h>
#include "swa/ServiceInterceptor.hh"

namespace masld_UI
{
  class maslt_UIUnit;
  class maslt_UIIndicator;
  void masls_setData ( double              maslp_value,
                       const maslt_UIUnit& maslp_unit );
  class masls_setData_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_setData_tag,void (double,const maslt_UIUnit&)> interceptor_masls_setData;
  void masls_setIndicator ( const maslt_UIIndicator& maslp_indicator );
  class masls_setIndicator_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_setIndicator_tag,void (const maslt_UIIndicator&)> interceptor_masls_setIndicator;
  void masls_setTime ( int32_t maslp_time );
  class masls_setTime_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_setTime_tag,void (int32_t)> interceptor_masls_setTime;
  void masls_startTest ( );
  class masls_startTest_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_startTest_tag,void()> interceptor_masls_startTest;
}
#endif // UI_OOA_UI_services_hh
