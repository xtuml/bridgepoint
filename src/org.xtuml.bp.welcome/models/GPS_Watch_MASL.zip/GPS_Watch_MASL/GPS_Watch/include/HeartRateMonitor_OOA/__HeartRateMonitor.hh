//
// File: __HeartRateMonitor.hh
//
#ifndef Heart_Rate_Monitor_OOA_Heart_Rate_Monitor_hh
#define Heart_Rate_Monitor_OOA_Heart_Rate_Monitor_hh

namespace masld_HeartRateMonitor
{
  enum ObjectIds {  objectId_maslo_HeartRateConstants,
                    objectId_maslo_HeartRateMonitor };
  enum RelationshipIds {};
}
#endif // Heart_Rate_Monitor_OOA_Heart_Rate_Monitor_hh
