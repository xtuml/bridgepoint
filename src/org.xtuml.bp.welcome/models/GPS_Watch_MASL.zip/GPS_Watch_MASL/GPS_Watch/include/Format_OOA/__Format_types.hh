//
// File: __Format_types.hh
//
#ifndef Format_OOA_Format_types_hh
#define Format_OOA_Format_types_hh

#include "asn1/BERDecode.hh"
#include "asn1/BERDecoder.hh"
#include "asn1/DEREncode.hh"
#include "asn1/DEREncoder.hh"
#include "boost/operators.hpp"
#include <cstddef>
#include <iostream>
#include <map>
#include <stdint.h>
#include <string>
#include "swa/RangeIterator.hh"

namespace masld_Format
{
  class maslt_justify;
  class maslt_base_case;
  class maslt_rounding;
  class maslt_duration_field;
  class maslt_timestamp_field;
  class maslt_justify
    : private ::boost::less_than_comparable<maslt_justify,::boost::equality_comparable<maslt_justify,::boost::incrementable<maslt_justify,::boost::decrementable<maslt_justify> > > >
  {

    // Enumerates
    public:
      static const maslt_justify masle_left;
      static const maslt_justify masle_right;
      static const maslt_justify masle_internal;


    // Enumeration
    public:
      maslt_justify ( );
      static maslt_justify getFirst ( ) { return masle_left; }
      static maslt_justify getLast ( ) { return masle_internal; }


    // Index Conversions
    public:
      enum Index {  index_masle_left,
                    index_masle_right,
                    index_masle_internal };
    private:
      Index index;
    public:
      explicit maslt_justify ( Index index );
      Index getIndex ( ) const { return index; }
      Index& setIndex ( ) { return index; }
      typedef ::SWA::RangeIterator<maslt_justify> const_iterator;
      static const_iterator beginEnum ( ) { return const_iterator( masle_left, masle_internal ); }
      static const_iterator endEnum ( ) { return const_iterator( masle_internal ); }


    // Value Conversions
    public:
      enum Value {  value_masle_left,
                    value_masle_right,
                    value_masle_internal };
      explicit maslt_justify ( Value value );
      Value getValue ( ) const { return valueLookup[index]; }
    private:
      static Value valueLookup[];
      static Index fromValue ( Value value );
    public:
      explicit maslt_justify ( int32_t value );
      operator int32_t ( ) const { return static_cast<int32_t>( getValue() ); }


    // Text Conversions
    public:
      explicit maslt_justify ( const ::std::string& text );
      const char* const getText ( ) const { return textLookup[index]; }
    private:
      static const char* const textLookup[];
      typedef ::std::map< ::std::string,Index> TextLookupTable;
      static TextLookupTable getLookupTable ( );
      static Index fromText ( const ::std::string& text );


    // Operators
    public:
      bool operator< ( const maslt_justify& rhs ) const { return index < rhs.index; }
      bool operator== ( const maslt_justify& rhs ) const { return index == rhs.index; }
      maslt_justify& operator++ ( );
      maslt_justify& operator-- ( );
      int64_t operator- ( const maslt_justify& rhs ) const { return index - rhs.index; }


  };
  ::std::ostream& operator<< ( ::std::ostream&      stream,
                               const maslt_justify& obj );
  ::std::istream& operator>> ( ::std::istream& stream,
                               maslt_justify&  obj );
  inline ::std::size_t hash_value ( const maslt_justify& value ) { return value.getIndex(); }
  class maslt_base_case
    : private ::boost::less_than_comparable<maslt_base_case,::boost::equality_comparable<maslt_base_case,::boost::incrementable<maslt_base_case,::boost::decrementable<maslt_base_case> > > >
  {

    // Enumerates
    public:
      static const maslt_base_case masle_upper;
      static const maslt_base_case masle_lower;


    // Enumeration
    public:
      maslt_base_case ( );
      static maslt_base_case getFirst ( ) { return masle_upper; }
      static maslt_base_case getLast ( ) { return masle_lower; }


    // Index Conversions
    public:
      enum Index {  index_masle_upper,
                    index_masle_lower };
    private:
      Index index;
    public:
      explicit maslt_base_case ( Index index );
      Index getIndex ( ) const { return index; }
      Index& setIndex ( ) { return index; }
      typedef ::SWA::RangeIterator<maslt_base_case> const_iterator;
      static const_iterator beginEnum ( ) { return const_iterator( masle_upper, masle_lower ); }
      static const_iterator endEnum ( ) { return const_iterator( masle_lower ); }


    // Value Conversions
    public:
      enum Value {  value_masle_upper,
                    value_masle_lower };
      explicit maslt_base_case ( Value value );
      Value getValue ( ) const { return valueLookup[index]; }
    private:
      static Value valueLookup[];
      static Index fromValue ( Value value );
    public:
      explicit maslt_base_case ( int32_t value );
      operator int32_t ( ) const { return static_cast<int32_t>( getValue() ); }


    // Text Conversions
    public:
      explicit maslt_base_case ( const ::std::string& text );
      const char* const getText ( ) const { return textLookup[index]; }
    private:
      static const char* const textLookup[];
      typedef ::std::map< ::std::string,Index> TextLookupTable;
      static TextLookupTable getLookupTable ( );
      static Index fromText ( const ::std::string& text );


    // Operators
    public:
      bool operator< ( const maslt_base_case& rhs ) const { return index < rhs.index; }
      bool operator== ( const maslt_base_case& rhs ) const { return index == rhs.index; }
      maslt_base_case& operator++ ( );
      maslt_base_case& operator-- ( );
      int64_t operator- ( const maslt_base_case& rhs ) const { return index - rhs.index; }


  };
  ::std::ostream& operator<< ( ::std::ostream&        stream,
                               const maslt_base_case& obj );
  ::std::istream& operator>> ( ::std::istream&  stream,
                               maslt_base_case& obj );
  inline ::std::size_t hash_value ( const maslt_base_case& value ) { return value.getIndex(); }
  class maslt_rounding
    : private ::boost::less_than_comparable<maslt_rounding,::boost::equality_comparable<maslt_rounding,::boost::incrementable<maslt_rounding,::boost::decrementable<maslt_rounding> > > >
  {

    // Enumerates
    public:
      static const maslt_rounding masle_towards_zero;
      static const maslt_rounding masle_towards_nearest;


    // Enumeration
    public:
      maslt_rounding ( );
      static maslt_rounding getFirst ( ) { return masle_towards_zero; }
      static maslt_rounding getLast ( ) { return masle_towards_nearest; }


    // Index Conversions
    public:
      enum Index {  index_masle_towards_zero,
                    index_masle_towards_nearest };
    private:
      Index index;
    public:
      explicit maslt_rounding ( Index index );
      Index getIndex ( ) const { return index; }
      Index& setIndex ( ) { return index; }
      typedef ::SWA::RangeIterator<maslt_rounding> const_iterator;
      static const_iterator beginEnum ( ) { return const_iterator( masle_towards_zero, masle_towards_nearest ); }
      static const_iterator endEnum ( ) { return const_iterator( masle_towards_nearest ); }


    // Value Conversions
    public:
      enum Value {  value_masle_towards_zero,
                    value_masle_towards_nearest };
      explicit maslt_rounding ( Value value );
      Value getValue ( ) const { return valueLookup[index]; }
    private:
      static Value valueLookup[];
      static Index fromValue ( Value value );
    public:
      explicit maslt_rounding ( int32_t value );
      operator int32_t ( ) const { return static_cast<int32_t>( getValue() ); }


    // Text Conversions
    public:
      explicit maslt_rounding ( const ::std::string& text );
      const char* const getText ( ) const { return textLookup[index]; }
    private:
      static const char* const textLookup[];
      typedef ::std::map< ::std::string,Index> TextLookupTable;
      static TextLookupTable getLookupTable ( );
      static Index fromText ( const ::std::string& text );


    // Operators
    public:
      bool operator< ( const maslt_rounding& rhs ) const { return index < rhs.index; }
      bool operator== ( const maslt_rounding& rhs ) const { return index == rhs.index; }
      maslt_rounding& operator++ ( );
      maslt_rounding& operator-- ( );
      int64_t operator- ( const maslt_rounding& rhs ) const { return index - rhs.index; }


  };
  ::std::ostream& operator<< ( ::std::ostream&       stream,
                               const maslt_rounding& obj );
  ::std::istream& operator>> ( ::std::istream& stream,
                               maslt_rounding& obj );
  inline ::std::size_t hash_value ( const maslt_rounding& value ) { return value.getIndex(); }
  class maslt_duration_field
    : private ::boost::less_than_comparable<maslt_duration_field,::boost::equality_comparable<maslt_duration_field,::boost::incrementable<maslt_duration_field,::boost::decrementable<maslt_duration_field> > > >
  {

    // Enumerates
    public:
      static const maslt_duration_field masle_weeks;
      static const maslt_duration_field masle_days;
      static const maslt_duration_field masle_hours;
      static const maslt_duration_field masle_minutes;
      static const maslt_duration_field masle_seconds;


    // Enumeration
    public:
      maslt_duration_field ( );
      static maslt_duration_field getFirst ( ) { return masle_weeks; }
      static maslt_duration_field getLast ( ) { return masle_seconds; }


    // Index Conversions
    public:
      enum Index {  index_masle_weeks,
                    index_masle_days,
                    index_masle_hours,
                    index_masle_minutes,
                    index_masle_seconds };
    private:
      Index index;
    public:
      explicit maslt_duration_field ( Index index );
      Index getIndex ( ) const { return index; }
      Index& setIndex ( ) { return index; }
      typedef ::SWA::RangeIterator<maslt_duration_field> const_iterator;
      static const_iterator beginEnum ( ) { return const_iterator( masle_weeks, masle_seconds ); }
      static const_iterator endEnum ( ) { return const_iterator( masle_seconds ); }


    // Value Conversions
    public:
      enum Value {  value_masle_weeks,
                    value_masle_days,
                    value_masle_hours,
                    value_masle_minutes,
                    value_masle_seconds };
      explicit maslt_duration_field ( Value value );
      Value getValue ( ) const { return valueLookup[index]; }
    private:
      static Value valueLookup[];
      static Index fromValue ( Value value );
    public:
      explicit maslt_duration_field ( int32_t value );
      operator int32_t ( ) const { return static_cast<int32_t>( getValue() ); }


    // Text Conversions
    public:
      explicit maslt_duration_field ( const ::std::string& text );
      const char* const getText ( ) const { return textLookup[index]; }
    private:
      static const char* const textLookup[];
      typedef ::std::map< ::std::string,Index> TextLookupTable;
      static TextLookupTable getLookupTable ( );
      static Index fromText ( const ::std::string& text );


    // Operators
    public:
      bool operator< ( const maslt_duration_field& rhs ) const { return index < rhs.index; }
      bool operator== ( const maslt_duration_field& rhs ) const { return index == rhs.index; }
      maslt_duration_field& operator++ ( );
      maslt_duration_field& operator-- ( );
      int64_t operator- ( const maslt_duration_field& rhs ) const { return index - rhs.index; }


  };
  ::std::ostream& operator<< ( ::std::ostream&             stream,
                               const maslt_duration_field& obj );
  ::std::istream& operator>> ( ::std::istream&       stream,
                               maslt_duration_field& obj );
  inline ::std::size_t hash_value ( const maslt_duration_field& value ) { return value.getIndex(); }
  class maslt_timestamp_field
    : private ::boost::less_than_comparable<maslt_timestamp_field,::boost::equality_comparable<maslt_timestamp_field,::boost::incrementable<maslt_timestamp_field,::boost::decrementable<maslt_timestamp_field> > > >
  {

    // Enumerates
    public:
      static const maslt_timestamp_field masle_year;
      static const maslt_timestamp_field masle_month;
      static const maslt_timestamp_field masle_week;
      static const maslt_timestamp_field masle_day;
      static const maslt_timestamp_field masle_hour;
      static const maslt_timestamp_field masle_minute;
      static const maslt_timestamp_field masle_second;


    // Enumeration
    public:
      maslt_timestamp_field ( );
      static maslt_timestamp_field getFirst ( ) { return masle_year; }
      static maslt_timestamp_field getLast ( ) { return masle_second; }


    // Index Conversions
    public:
      enum Index {  index_masle_year,
                    index_masle_month,
                    index_masle_week,
                    index_masle_day,
                    index_masle_hour,
                    index_masle_minute,
                    index_masle_second };
    private:
      Index index;
    public:
      explicit maslt_timestamp_field ( Index index );
      Index getIndex ( ) const { return index; }
      Index& setIndex ( ) { return index; }
      typedef ::SWA::RangeIterator<maslt_timestamp_field> const_iterator;
      static const_iterator beginEnum ( ) { return const_iterator( masle_year, masle_second ); }
      static const_iterator endEnum ( ) { return const_iterator( masle_second ); }


    // Value Conversions
    public:
      enum Value {  value_masle_year,
                    value_masle_month,
                    value_masle_week,
                    value_masle_day,
                    value_masle_hour,
                    value_masle_minute,
                    value_masle_second };
      explicit maslt_timestamp_field ( Value value );
      Value getValue ( ) const { return valueLookup[index]; }
    private:
      static Value valueLookup[];
      static Index fromValue ( Value value );
    public:
      explicit maslt_timestamp_field ( int32_t value );
      operator int32_t ( ) const { return static_cast<int32_t>( getValue() ); }


    // Text Conversions
    public:
      explicit maslt_timestamp_field ( const ::std::string& text );
      const char* const getText ( ) const { return textLookup[index]; }
    private:
      static const char* const textLookup[];
      typedef ::std::map< ::std::string,Index> TextLookupTable;
      static TextLookupTable getLookupTable ( );
      static Index fromText ( const ::std::string& text );


    // Operators
    public:
      bool operator< ( const maslt_timestamp_field& rhs ) const { return index < rhs.index; }
      bool operator== ( const maslt_timestamp_field& rhs ) const { return index == rhs.index; }
      maslt_timestamp_field& operator++ ( );
      maslt_timestamp_field& operator-- ( );
      int64_t operator- ( const maslt_timestamp_field& rhs ) const { return index - rhs.index; }


  };
  ::std::ostream& operator<< ( ::std::ostream&              stream,
                               const maslt_timestamp_field& obj );
  ::std::istream& operator>> ( ::std::istream&        stream,
                               maslt_timestamp_field& obj );
  inline ::std::size_t hash_value ( const maslt_timestamp_field& value ) { return value.getIndex(); }
}
namespace ASN1
{
  namespace DER
  {
    inline Encoder encodeValue ( const ::masld_Format::maslt_justify& value )
    {
      return encode( value.getIndex() );
    }

  }
  namespace BER
  {
    template<class I>
    void decodeValue ( const Decoder<I>&              decoder,
                       ::masld_Format::maslt_justify& value )
    {
      decode( decoder, value.setIndex() );
    }

  }
  namespace DER
  {
    inline Encoder encodeValue ( const ::masld_Format::maslt_base_case& value )
    {
      return encode( value.getIndex() );
    }

  }
  namespace BER
  {
    template<class I>
    void decodeValue ( const Decoder<I>&                decoder,
                       ::masld_Format::maslt_base_case& value )
    {
      decode( decoder, value.setIndex() );
    }

  }
  namespace DER
  {
    inline Encoder encodeValue ( const ::masld_Format::maslt_rounding& value )
    {
      return encode( value.getIndex() );
    }

  }
  namespace BER
  {
    template<class I>
    void decodeValue ( const Decoder<I>&               decoder,
                       ::masld_Format::maslt_rounding& value )
    {
      decode( decoder, value.setIndex() );
    }

  }
  namespace DER
  {
    inline Encoder encodeValue ( const ::masld_Format::maslt_duration_field& value )
    {
      return encode( value.getIndex() );
    }

  }
  namespace BER
  {
    template<class I>
    void decodeValue ( const Decoder<I>&                     decoder,
                       ::masld_Format::maslt_duration_field& value )
    {
      decode( decoder, value.setIndex() );
    }

  }
  namespace DER
  {
    inline Encoder encodeValue ( const ::masld_Format::maslt_timestamp_field& value )
    {
      return encode( value.getIndex() );
    }

  }
  namespace BER
  {
    template<class I>
    void decodeValue ( const Decoder<I>&                      decoder,
                       ::masld_Format::maslt_timestamp_field& value )
    {
      decode( decoder, value.setIndex() );
    }

  }
}
#endif // Format_OOA_Format_types_hh
