//
// File: __LOG_terminators.hh
//
#ifndef LOG_OOA_LOG_terminators_hh
#define LOG_OOA_LOG_terminators_hh

#endif // LOG_OOA_LOG_terminators_hh
