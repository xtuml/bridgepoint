//
// File: __Tracking_interface.hh
//
#ifndef Tracking_OOA_Tracking_interface_hh
#define Tracking_OOA_Tracking_interface_hh

#include "swa/Domain.hh"

namespace masld_Tracking
{
  ::SWA::Domain& getDomain ( );
  enum ServiceIds {  serviceId_masls_Initialize,
                     serviceId_masls_GoalTest_1,
                     serviceId_masls_heartRateChanged,
                     serviceId_masls_setTargetPressed,
                     serviceId_masls_startStopPressed,
                     serviceId_masls_lapResetPressed,
                     serviceId_masls_lightPressed,
                     serviceId_masls_modePressed,
                     serviceId_masls_newGoalSpec };
  enum TerminatorIds {  terminatorId_maslb_HR,
                        terminatorId_maslb_LOC,
                        terminatorId_maslb_UI };
}
#endif // Tracking_OOA_Tracking_interface_hh
