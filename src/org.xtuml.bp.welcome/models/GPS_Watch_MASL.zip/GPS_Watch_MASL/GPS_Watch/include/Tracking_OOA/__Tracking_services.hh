//
// File: __Tracking_services.hh
//
#ifndef Tracking_OOA_Tracking_services_hh
#define Tracking_OOA_Tracking_services_hh

#include <stdint.h>
#include "swa/ServiceInterceptor.hh"

namespace masld_Tracking
{
  class maslt_GoalSpan;
  class maslt_GoalCriteria;
  void masls_heartRateChanged ( int32_t maslp_heartRate );
  class masls_heartRateChanged_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_heartRateChanged_tag,void (int32_t)> interceptor_masls_heartRateChanged;
  void masls_setTargetPressed ( );
  class masls_setTargetPressed_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_setTargetPressed_tag,void()> interceptor_masls_setTargetPressed;
  void masls_startStopPressed ( );
  class masls_startStopPressed_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_startStopPressed_tag,void()> interceptor_masls_startStopPressed;
  void masls_lapResetPressed ( );
  class masls_lapResetPressed_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_lapResetPressed_tag,void()> interceptor_masls_lapResetPressed;
  void masls_lightPressed ( );
  class masls_lightPressed_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_lightPressed_tag,void()> interceptor_masls_lightPressed;
  void masls_modePressed ( );
  class masls_modePressed_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_modePressed_tag,void()> interceptor_masls_modePressed;
  void masls_newGoalSpec ( const maslt_GoalSpan&     maslp_spanType,
                           const maslt_GoalCriteria& maslp_criteriaType,
                           double                    maslp_span,
                           double                    maslp_maximum,
                           double                    maslp_minimum,
                           int32_t                   maslp_sequenceNumber );
  class masls_newGoalSpec_tag
  {

  };
  typedef ::SWA::ServiceInterceptor<masls_newGoalSpec_tag,void (const maslt_GoalSpan&,const maslt_GoalCriteria&,double,double,double,int32_t)> interceptor_masls_newGoalSpec;
}
#endif // Tracking_OOA_Tracking_services_hh
