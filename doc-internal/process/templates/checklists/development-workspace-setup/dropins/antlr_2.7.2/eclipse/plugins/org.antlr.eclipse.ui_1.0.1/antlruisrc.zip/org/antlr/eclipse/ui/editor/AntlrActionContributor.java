package org.antlr.eclipse.ui.editor;

import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.antlr.eclipse.ui.actions.GotoErrorAction;
import org.antlr.eclipse.ui.actions.IAntlrActionConstants;
import org.antlr.eclipse.ui.actions.IAntlrActionDefinitionIds;
import org.antlr.eclipse.ui.actions.TogglePresentationAction;
import org.eclipse.jdt.ui.actions.IJavaEditorActionDefinitionIds;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.IWorkbenchActionConstants;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.texteditor.BasicTextEditorActionContributor;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.ITextEditorActionConstants;
import org.eclipse.ui.texteditor.ITextEditorActionDefinitionIds;
import org.eclipse.ui.texteditor.RetargetTextEditorAction;

/**
 * Contributes interesting ANTLR actions to the desktop's edit menu and the
 * toolbar.
 */
public class AntlrActionContributor extends BasicTextEditorActionContributor {
	private static final String PREFIX = "Editor.";

	private TogglePresentationAction fTogglePresentation;
	private GotoErrorAction fNextError;
	private GotoErrorAction fPreviousError;
	private RetargetTextEditorAction fGotoRule;
	private RetargetTextEditorAction fContentAssist;
	private RetargetTextEditorAction fComment;
	private RetargetTextEditorAction fUncomment;

	/**
	 * Default constructor.
	 */
	public AntlrActionContributor() {

		// Define toolbar actions
		fTogglePresentation = new TogglePresentationAction();
		fNextError = new GotoErrorAction(true);
		fPreviousError = new GotoErrorAction(false);

		// Define action handlers
		fGotoRule = new RetargetTextEditorAction(
								AntlrUIPlugin.getDefault().getResourceBundle(),
								PREFIX + "GotoRule.");
		fGotoRule.setActionDefinitionId(IAntlrActionDefinitionIds.GOTO_RULE);
		fContentAssist = new RetargetTextEditorAction(
								AntlrUIPlugin.getDefault().getResourceBundle(),
								PREFIX + "ContentAssist.");
		fContentAssist.setActionDefinitionId(
					  ITextEditorActionDefinitionIds.CONTENT_ASSIST_PROPOSALS);
		fComment = new RetargetTextEditorAction(
								AntlrUIPlugin.getDefault().getResourceBundle(),
								PREFIX + "Comment.");
		fComment.setActionDefinitionId(IJavaEditorActionDefinitionIds.COMMENT);
		fUncomment = new RetargetTextEditorAction(
								AntlrUIPlugin.getDefault().getResourceBundle(),
								PREFIX + "Uncomment.");
		fUncomment.setActionDefinitionId(
									 IJavaEditorActionDefinitionIds.UNCOMMENT);
	}
	
	/**
	 * @see IEditorActionBarContributor#setActiveEditor(IEditorPart)
	 */
	public void setActiveEditor(IEditorPart aPart) {
		super.setActiveEditor(aPart);
		doSetActiveEditor(aPart);
	}
	
	/**
	 * Internally sets the active editor to the actions provided by this
	 * contributor.
	 * @param aPart the editor
	 */
	private void doSetActiveEditor(IEditorPart aPart) {
		IStatusLineManager manager = getActionBars().getStatusLineManager();
		manager.setMessage(null);
		manager.setErrorMessage(null);

		ITextEditor editor = null;
		if (aPart instanceof ITextEditor) {
			editor = (ITextEditor)aPart;
		}

		// Set the underlying action (registered by the according editor) in
		// the action handlers
		fTogglePresentation.setEditor(editor);
		fNextError.setEditor(editor);
		fPreviousError.setEditor(editor);

		fGotoRule.setAction(getAction(editor,
									  IAntlrActionConstants.GOTO_RULE));
		fContentAssist.setAction(getAction(editor,
										IAntlrActionConstants.CONTENT_ASSIST));
		fComment.setAction(getAction(editor, IAntlrActionConstants.COMMENT));
		fUncomment.setAction(getAction(editor,
									   IAntlrActionConstants.UNCOMMENT));
	}

	/**
	 * Installs the global action handlers for the ANTLR text editor.
	 *
	 * @see IEditorActionBarContributor#init(IActionBars, IWorkbenchPage)
	 */
	public void init(IActionBars anActionBars, IWorkbenchPage aPage) {
		super.init(anActionBars, aPage);

		// register actions that have a dynamic editor. 
		anActionBars.setGlobalActionHandler(ITextEditorActionConstants.NEXT,
											fNextError);
		anActionBars.setGlobalActionHandler(ITextEditorActionConstants.PREVIOUS,
											fPreviousError);
	}
	
	/**
	 * @see EditorActionBarContributor#contributeToMenu(IMenuManager)
	 */
	public void contributeToMenu(IMenuManager aMenuManager) {
		super.contributeToMenu(aMenuManager);

		// Add actions to desktop's edit menu
		IMenuManager menu = aMenuManager.findMenuUsingPath(
											 IWorkbenchActionConstants.M_EDIT);
		if (menu != null) {
			menu.add(fContentAssist);
			menu.add(fComment);
			menu.add(fUncomment);
		}

		// Add actions to desktop's navigate menu
		menu = aMenuManager.findMenuUsingPath(
										 IWorkbenchActionConstants.M_NAVIGATE);
		if (menu != null) {
			menu.appendToGroup(IWorkbenchActionConstants.MB_ADDITIONS,
							   fGotoRule);
		}
	}

	/**
	 * @see org.eclipse.ui.part.EditorActionBarContributor#contributeToToolBar(org.eclipse.jface.action.IToolBarManager)
	 */
	public void contributeToToolBar(IToolBarManager aToolBar) {
		aToolBar.add(new Separator());
		aToolBar.add(fTogglePresentation);		
		aToolBar.add(fPreviousError);
		aToolBar.add(fNextError);
	}

	/**
	 * @see org.eclipse.ui.IEditorActionBarContributor#dispose()
	 */
	public void dispose() {
		doSetActiveEditor(null);
		super.dispose();
	}
}
