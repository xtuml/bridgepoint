package org.antlr.eclipse.ui.editor.outline;

import org.antlr.eclipse.core.parser.IModel;
import org.antlr.eclipse.ui.editor.AntlrEditor;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.Viewer;

public class AntlrOutlineContentProvider implements ITreeContentProvider {

	private AntlrEditor fEditor;

	public AntlrOutlineContentProvider(AntlrEditor anEditor) {
	    fEditor = anEditor;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IContentProvider#inputChanged(org.eclipse.jface.viewers.Viewer, java.lang.Object, java.lang.Object)
	 */
	public void inputChanged(Viewer aViewer, Object anOldInput,
							  Object aNewInput) {
    }

    /* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IContentProvider#dispose()
	 */
	public void dispose() {
    }
    
    /* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IStructuredContentProvider#getElements(java.lang.Object)
	 */
	public Object[] getElements(Object inputElement) {
        return fEditor.getRootElements();
    }
	
    /* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.ITreeContentProvider#getChildren(java.lang.Object)
	 */
	public Object[] getChildren(Object anElement) {
        return (anElement instanceof IModel) ?
						((IModel)anElement).getChildren() : IModel.NO_CHILDREN;
    }

    /* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.ITreeContentProvider#getParent(java.lang.Object)
	 */
	public Object getParent(Object anElement) {
		return (anElement instanceof IModel) ?
										((IModel)anElement).getParent() : null;
    }

    /* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.ITreeContentProvider#hasChildren(java.lang.Object)
	 */
    public boolean hasChildren(Object anElement) {
        return (anElement instanceof IModel) ?
									 ((IModel)anElement).hasChildren() : false;
    }
}
