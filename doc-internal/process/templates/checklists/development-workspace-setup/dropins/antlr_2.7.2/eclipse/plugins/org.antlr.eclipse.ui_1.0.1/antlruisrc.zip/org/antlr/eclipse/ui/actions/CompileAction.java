package org.antlr.eclipse.ui.actions;

import java.lang.reflect.InvocationTargetException;

import org.antlr.eclipse.core.builder.AntlrBuilder;
import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.util.Assert;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;
import org.eclipse.ui.actions.WorkspaceModifyOperation;

public class CompileAction implements IObjectActionDelegate {
    private IWorkbenchPart fPart;
    private IFile fGrammarFile;

    /**
     * @see IObjectActionDelegate#setActivePart(IAction, IWorkbenchPart)
     */
    public void setActivePart(IAction anAction, IWorkbenchPart aTargetPart) {
		fPart = aTargetPart;
    }

    /**
     * @see IActionDelegate#selectionChanged(IAction, ISelection)
     */
    public void selectionChanged(IAction anAction, ISelection aSelection) {
        IFile file = null;
		if (aSelection instanceof IStructuredSelection) {
			Object obj = ((IStructuredSelection)aSelection).getFirstElement();
			if (obj != null && obj instanceof IFile) {
				file = (IFile)obj;
			}
		}
		fGrammarFile = file;
    }

    /**
     * @see IActionDelegate#run(IAction)
     */
    public void run(IAction anAction) {
		Assert.isNotNull(fGrammarFile);
        Shell shell = AntlrUIPlugin.getActiveWorkbenchShell();
		ProgressMonitorDialog pmd = new ProgressMonitorDialog(shell);
		try {
			pmd.run(true, false, new Operation(fGrammarFile));	// cancel button disabled
		} catch (InterruptedException e) {
		} catch (InvocationTargetException e) {
			AntlrUIPlugin.log(e);
		}
	}

    private class Operation extends WorkspaceModifyOperation {
        IFile fFile;
        
        public Operation(IFile aFile) {
            fFile = aFile;
        }

        /**
         * @see WorkspaceModifyOperation#execute(IProgressMonitor)
         */
        protected void execute(IProgressMonitor aMonitor) throws CoreException,
        						 InvocationTargetException, InterruptedException {
        	new AntlrBuilder().compileFile(fFile, aMonitor);
        }
	}
}
