package org.antlr.eclipse.ui.actions;

import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.antlr.eclipse.ui.AntlrUIPluginImages;
import org.antlr.eclipse.ui.editor.AntlrEditor;
import org.eclipse.ui.texteditor.TextEditorAction;

public class GotoErrorAction extends TextEditorAction {
	private boolean fIsForward;

	public GotoErrorAction(boolean anIsForward) {
		super(AntlrUIPlugin.getDefault().getResourceBundle(), (anIsForward ?
						"Editor.NextError." : "Editor.PreviousError.") , null);
		setImageDescriptor(anIsForward ?
						   AntlrUIPluginImages.DESC_TOOL_GOTO_NEXT_ERROR :
						   AntlrUIPluginImages.DESC_TOOL_GOTO_PREV_ERROR);
		fIsForward = anIsForward;
	}
	
	/**
	 * @see Action#run()
	 */
	public void run() {
		AntlrEditor editor = (AntlrEditor)getTextEditor();
		editor.gotoError(fIsForward);
	}
	
	/**
	 * @see TextEditorAction#update()
	 */
	public void update() {
		setEnabled(true);
	}
}