package org.antlr.eclipse.ui.properties;

import org.antlr.eclipse.core.AntlrCorePlugin;
import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.dialogs.ElementTreeSelectionDialog;
import org.eclipse.ui.dialogs.ISelectionStatusValidator;
import org.eclipse.ui.dialogs.PropertyPage;
import org.eclipse.ui.model.WorkbenchContentProvider;
import org.eclipse.ui.model.WorkbenchLabelProvider;

/**
 * Properties page for ANTLR grammar files.
 * It appends the name of the according grammar file to the file name.
 */
public class GrammarPropertyPage extends PropertyPage {

	private static final String PREFIX = "Properties.Grammar.";

	private Text fOutputText;
	private Text fGrammarText;

	/* (non-Javadoc)
	 * @see org.eclipse.jface.preference.PreferencePage#createContents(org.eclipse.swt.widgets.Composite)
	 */
	protected Control createContents(Composite aParent) {
		Composite composite = new Composite(aParent, SWT.NONE);
		GridLayout layout = new GridLayout();
		composite.setLayout(layout);
		GridData data = new GridData(GridData.FILL);
		data.grabExcessHorizontalSpace = true;
		composite.setLayoutData(data);

		addOutputProperty(composite);
		addGrammarProperty(composite);

		return composite;
	}

	private void addOutputProperty(Composite aParent) {
		Composite composite = createDefaultComposite(aParent);

		// Label for output field
		Label label = new Label(composite, SWT.NONE);
		label.setText(getString("output.label"));
//		label.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_FILL));

		// Output text field
		fOutputText = new Text(composite, SWT.READ_ONLY | SWT.SINGLE | SWT.BORDER);
		String output;
		try {
			output = ((IResource)getElement()).getPersistentProperty(
											  AntlrCorePlugin.OUTPUT_PROPERTY);
			if (output != null) {
				fOutputText.setText(output);
			}
		} catch (CoreException e) {
		}
		GridData gd = new GridData();
		gd.horizontalAlignment= GridData.FILL_HORIZONTAL;
		gd.widthHint = convertWidthInCharsToPixels(50);
//		gd.grabExcessHorizontalSpace = true;
		fOutputText.setLayoutData(gd);

		// Choose folder button			
		Button button = new Button(composite, SWT.PUSH);
		button.setText(getString("output.button"));
		button.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent anEvent) {
				chooseOutputFolder();
			}
			public void widgetSelected(SelectionEvent anEvent) {
				chooseOutputFolder();
			}
		});	
	}

	private void addGrammarProperty(Composite aParent) {
		Composite composite = createDefaultComposite(aParent);

		// Label for grammar field
		Label label = new Label(composite, SWT.NONE);
		label.setText(getString("grammar.label"));
//		label.setLayoutData(new GridData(GridData.HORIZONTAL_ALIGN_FILL));

		// Grammar text field
		fGrammarText = new Text(composite, SWT.READ_ONLY | SWT.SINGLE | SWT.BORDER);
		String grammar;
		try {
			grammar = ((IResource)getElement()).getPersistentProperty(
									  AntlrCorePlugin.SUPER_GRAMMARS_PROPERTY);
			if (grammar != null) {
				fGrammarText.setText(grammar);
			}
		} catch (CoreException e) {
		}
		GridData gd = new GridData();
		gd.horizontalAlignment= GridData.FILL_HORIZONTAL;
		gd.widthHint = convertWidthInCharsToPixels(50);
//		gd.grabExcessHorizontalSpace = true;
		fGrammarText.setLayoutData(gd);

		// Choose folder button			
		Button button = new Button(composite, SWT.PUSH);
		button.setText(getString("grammar.button"));
		button.addSelectionListener(new SelectionListener() {
			public void widgetDefaultSelected(SelectionEvent anEvent) {
				chooseGrammarFile();
			}
			public void widgetSelected(SelectionEvent anEvent) {
				chooseGrammarFile();
			}
		});	
	}

	private Composite createDefaultComposite(Composite aParent) {
		Composite composite = new Composite(aParent, SWT.NULL);
		GridLayout layout = new GridLayout();
		layout.numColumns = 3;
		composite.setLayout(layout);

		GridData data = new GridData();
		data.verticalAlignment = GridData.FILL;
		data.horizontalAlignment = GridData.FILL;
		composite.setLayoutData(data);

		return composite;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.preference.IPreferencePage#performOk()
	 */
	public boolean performOk() {
		try {
			((IResource)getElement()).setPersistentProperty(
						AntlrCorePlugin.OUTPUT_PROPERTY, fOutputText.getText());
			((IResource)getElement()).setPersistentProperty(
			   AntlrCorePlugin.SUPER_GRAMMARS_PROPERTY, fGrammarText.getText());
		} catch (CoreException e) {
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.preference.PreferencePage#performDefaults()
	 */
	protected void performDefaults() {
		fOutputText.setText("");
		fGrammarText.setText("");
	}

	private String getString(String aKey) {
		return AntlrUIPlugin.getMessage(PREFIX + aKey);
	}

	private void chooseOutputFolder() {
		ISelectionStatusValidator validator = new ISelectionStatusValidator() {
			public IStatus validate(Object[] aSelection) {
				for (int i= 0; i < aSelection.length; i++) {
					if (!(aSelection[i] instanceof IFolder ||
										 aSelection[i] instanceof IProject)) {
						return new Status(IStatus.ERROR,
							   AntlrUIPlugin.getUniqueIdentifier(), IStatus.OK,
							   getString("output.choose.select"), null);
					}
				}
				return new Status(IStatus.OK,
							   AntlrUIPlugin.getUniqueIdentifier(), IStatus.OK,
							   "", null);
			}			
		};
		ElementTreeSelectionDialog dialog = new ElementTreeSelectionDialog(
									  getShell(), new WorkbenchLabelProvider(),
									  new WorkbenchContentProvider());
		dialog.setValidator(validator);
		dialog.setTitle(getString("output.choose.title"));
		dialog.setMessage(getString("output.choose.message"));
		dialog.addFilter(new FolderFilter());
		dialog.setInput(ResourcesPlugin.getWorkspace().getRoot());
		dialog.setAllowMultiple(false);	

		if (dialog.open() == Window.OK) {
			Object[] folders = dialog.getResult();
			String folder;
			if (folders.length > 0) {
				folder = ((IResource)folders[0]).getFullPath().toString();
			} else {
				folder = "";
			}
			fOutputText.setText(folder);
		}
	}
	
	private static class FolderFilter extends ViewerFilter {
		public boolean select(Viewer aViewer, Object aParent,
								Object anElement) {
			return ((anElement instanceof IProject &&
					  ((IProject)anElement).isOpen()) ||
					 anElement instanceof IFolder);
		}		
	}

	private void chooseGrammarFile() {
		ISelectionStatusValidator validator = new ISelectionStatusValidator() {
			public IStatus validate(Object[] aSelection) {
				for (int i= 0; i < aSelection.length; i++) {
					if (!(aSelection[i] instanceof IFile)) {
						return new Status(IStatus.ERROR,
							  AntlrUIPlugin.getUniqueIdentifier(), IStatus.OK,
							  getString("grammar.choose.select"), null);
					}
				}
				return new Status(IStatus.OK,
							   AntlrUIPlugin.getUniqueIdentifier(), IStatus.OK,
							   "", null);
			}			
		};
		ElementTreeSelectionDialog dialog = new ElementTreeSelectionDialog(
									  getShell(), new WorkbenchLabelProvider(),
									  new WorkbenchContentProvider());
		dialog.setValidator(validator);
		dialog.setTitle(getString("grammar.choose.title"));
		dialog.setMessage(getString("grammar.choose.message"));
		dialog.addFilter(new GrammarFileFilter());
		dialog.setInput(ResourcesPlugin.getWorkspace().getRoot());
		dialog.setAllowMultiple(true);	

		if (dialog.open() == Window.OK) {
			Object[] files = dialog.getResult();

			// Create list of grammars delimited by ';'
			StringBuffer grammars = new StringBuffer();
			for (int i = 0; i < files.length; i++) {
				grammars.append(((IFile)files[i]).getFullPath().toString());
				if (i < (files.length - 1)) {
					grammars.append(';');
				}
			}
			fGrammarText.setText(grammars.toString());
		}
	}
	
	private static class GrammarFileFilter extends ViewerFilter {
		public boolean select(Viewer aViewer, Object aParent,
								Object anElement) {
			boolean select = false;
			if (anElement instanceof IProject ||
					 anElement instanceof IFolder) {
				select = true;
			} else if (anElement instanceof IFile) {
				String extension = ((IFile)anElement).getFileExtension();
				if (extension != null && extension.equals("g")) {
					select = true;
				}
			}
			return select;
		}		
	}
}