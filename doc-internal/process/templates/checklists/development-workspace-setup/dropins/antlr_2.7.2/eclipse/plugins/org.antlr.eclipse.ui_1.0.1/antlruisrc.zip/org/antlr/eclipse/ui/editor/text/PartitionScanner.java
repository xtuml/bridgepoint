package org.antlr.eclipse.ui.editor.text;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.rules.EndOfLineRule;
import org.eclipse.jface.text.rules.IPredicateRule;
import org.eclipse.jface.text.rules.IToken;
import org.eclipse.jface.text.rules.MultiLineRule;
import org.eclipse.jface.text.rules.RuleBasedPartitionScanner;
import org.eclipse.jface.text.rules.SingleLineRule;
import org.eclipse.jface.text.rules.Token;
import org.eclipse.jface.text.rules.WordPatternRule;

/**
 * This scanner recognizes the ANTLR comments.
 */
public class PartitionScanner extends RuleBasedPartitionScanner {
	public final static String STRING = "__antlr_string";
	public final static String SINGLE_LINE_COMMENT =
												 "__antlr_single_line_comment";
	public final static String MULTI_LINE_COMMENT =
												  "__antlr_multi_line_comment";
	public final static String JAVA_DOC = "__java_doc";
	
	public static final String[] PARTITION_TYPES = new String[] {
							IDocument.DEFAULT_CONTENT_TYPE, STRING,
							SINGLE_LINE_COMMENT, MULTI_LINE_COMMENT, JAVA_DOC };
	/**
	 * Creates the partitioner and sets up the appropriate rules.
	 */
	public PartitionScanner() {
		IToken string = new Token(STRING);
		IToken singleLineComment = new Token(SINGLE_LINE_COMMENT);
		IToken multiLineComment = new Token(MULTI_LINE_COMMENT);
		IToken javaDoc = new Token(JAVA_DOC);

		List rules = new ArrayList();

		// Add rule for strings and character constants.
		rules.add(new SingleLineRule("\"", "\"", string, '\\'));
		rules.add(new SingleLineRule("'", "'", string, '\\'));

		// Add special empty comment word rule
		rules.add(new WordPatternRule(new EmptyCommentDetector(), "/**/",
									  null, multiLineComment));
		// Add rules for multi-line comments
		rules.add(new MultiLineRule("/*", "*/", multiLineComment));
		rules.add(new MultiLineRule("/**", "*/", javaDoc));

		// Add special empty comment word rules
		rules.add(new WordPatternRule(new EmptyCommentDetector(), "/**/",
									  null, multiLineComment));
		rules.add(new WordPatternRule(new EmptyCommentDetector(), "/***/",
									  null, javaDoc));
		// Add rule for single line comments
		rules.add(new EndOfLineRule("//", singleLineComment));

		IPredicateRule[] result = new IPredicateRule[rules.size()];
		rules.toArray(result);
		setPredicateRules(result);
	}
}
