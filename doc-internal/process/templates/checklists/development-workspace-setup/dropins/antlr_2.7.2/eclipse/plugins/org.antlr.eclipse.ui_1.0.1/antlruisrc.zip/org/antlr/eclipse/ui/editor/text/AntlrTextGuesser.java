package org.antlr.eclipse.ui.editor.text;

import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;

/**
 * Guesses the start/end of an ANTLR rule from a given offset.
 */
public class AntlrTextGuesser {
	private String fText;
	private int fLine;

	/**
	 * Create an empty text guesser.
	 */
	public AntlrTextGuesser() {
		fText = "";
		fLine = -1;
	}

	public AntlrTextGuesser(IDocument aDocument, int anOffset,
							 boolean aGuessEnd) {
		try {

		 	// Guess start position
			int start = anOffset;
			while (start >= 1 && isWordPart(aDocument.getChar(start - 1))) {
				start--;
			}

			// Guess end position
			int end = anOffset;
			if (aGuessEnd) {
				int len = aDocument.getLength() - 1;
				while (end < len && isWordPart(aDocument.getChar(end))) {
					end++;
				}
			}
			fText = aDocument.get(start, end - start);
			fLine = aDocument.getLineOfOffset(start) + 1;
		} catch (BadLocationException e) {
			fText = "";
			fLine = -1;
		}
	}

	public String getText() {
		return fText;
	}

	public int getLine() {
		return fLine;
	}

	/**
     * Determines if the specified character may be part of a ANTLR rule
     * as other than the first character. A character may be part of
     * a ANTLR rule if and only if it is one of the following:
     * <ul>
     * <li>a letter (a..z, A..Z)
     * <li>a digit (0..9)
     * <li>a hyphen ("-")
     * <li>a connecting punctuation character ("_")
     * </ul>
     * 
     * @param aChar  the character to be tested.
     * @return true if the character may be part of a ANTLR identifier; 
     *          false otherwise.
     * @see java.lang.Character#isLetterOrDigit(char)
	 */
	private static final boolean isWordPart(char aChar) {
		return Character.isLetterOrDigit(aChar) || aChar == '-' ||
													aChar == '_';
	}

	public String toString() {
		return "text=" + fText + ", line=" + fLine;
	}
}
