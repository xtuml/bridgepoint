package org.antlr.eclipse.ui.editor.outline;

import org.antlr.eclipse.core.parser.Block;
import org.antlr.eclipse.core.parser.Grammar;
import org.eclipse.jface.viewers.ContentViewer;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerSorter;

public class AntlrOutlineSorter extends ViewerSorter {
    
    // Categories
    public static final int BLOCK = 0;
    public static final int GRAMMAR = 1;
    public static final int RULE = 2;

    /**
     * @see ViewerSorter#category(Object)
     */
	public int category(Object anElement) {
	    int category;
	    if (anElement instanceof Block) {
	        category = BLOCK;
	    } else if (anElement instanceof Grammar) {
	        category = GRAMMAR;
	    } else {
	        category = RULE;
	    }
	    return category;
	}
    
    /**
     * @see ViewerSorter#compare(Viewer, Object, Object)
     */
 	public int compare(Viewer aViewer, Object anObject1, Object anObject2) {
 	    int compare;
		int cat1 = category(anObject1);
		int cat2 = category(anObject2);
		if (cat1 != cat2 || cat1 == BLOCK) {
		    compare = 0;
		} else {
			ILabelProvider lprov = (ILabelProvider)
								  ((ContentViewer)aViewer).getLabelProvider();
			compare = collator.compare(lprov.getText(anObject1),
									   lprov.getText(anObject2));
		}
		return compare;
	}
}
