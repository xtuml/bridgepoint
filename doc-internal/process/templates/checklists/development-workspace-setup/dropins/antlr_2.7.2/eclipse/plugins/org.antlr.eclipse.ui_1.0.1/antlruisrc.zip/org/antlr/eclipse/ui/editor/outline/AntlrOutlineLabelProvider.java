package org.antlr.eclipse.ui.editor.outline;

import java.util.HashMap;
import java.util.Iterator;

import org.antlr.eclipse.core.parser.AbstractModel;
import org.antlr.eclipse.core.parser.Grammar;
import org.antlr.eclipse.core.parser.Rule;
import org.antlr.eclipse.ui.AntlrUIPluginImages;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

public class AntlrOutlineLabelProvider extends LabelProvider {
	private HashMap fImageCache = new HashMap();
	
    /**
     * @see ILabelProvider#getImage(Object)
     */
	public Image getImage(Object anElement) {
	    ImageDescriptor descriptor;
	    if (anElement instanceof Grammar) {
	        descriptor = AntlrUIPluginImages.DESC_OBJS_CLASS;
	    } else if (anElement instanceof Rule) {
	        switch (((Rule)anElement).getVisibility()) {
	            case Rule.PRIVATE :
	            	descriptor = AntlrUIPluginImages.DESC_MISC_PRIVATE;
	            	break;

	            case Rule.PROTECTED :
	            	descriptor = AntlrUIPluginImages.DESC_MISC_PROTECTED;
	            	break;

	            default :
	            	descriptor = AntlrUIPluginImages.DESC_MISC_PUBLIC;
	            	break;
	        }
	    } else {
	        descriptor = AntlrUIPluginImages.DESC_MISC_DEFAULT;
	    }

		// obtain the cached image corresponding to the descriptor
		Image image = (Image)fImageCache.get(descriptor);
		if (image == null) {
			image = descriptor.createImage();
			fImageCache.put(descriptor, image);
		}
		return image;
	}

	/**
	 * @see ILabelProvider#getText(Object)
	 */
	public String getText(Object anElement) {
		if (anElement instanceof AbstractModel) {
		    return ((AbstractModel)anElement).getName();
		}
		return "<Noname>";
	}

    /**
     * @see IBaseLabelProvider#dispose()
     */
	public void dispose() {
		for (Iterator images = fImageCache.values().iterator();
														 images.hasNext(); ) {
			((Image)images.next()).dispose();
		}
		fImageCache.clear();
	}
}
