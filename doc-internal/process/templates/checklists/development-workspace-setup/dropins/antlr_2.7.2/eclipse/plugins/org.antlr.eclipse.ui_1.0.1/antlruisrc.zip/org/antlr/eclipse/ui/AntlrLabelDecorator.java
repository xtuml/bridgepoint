package org.antlr.eclipse.ui;

import org.antlr.eclipse.core.AntlrCorePlugin;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.viewers.ILabelDecorator;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

public class AntlrLabelDecorator extends LabelProvider
								  implements ILabelDecorator {
	/**
	 * @see ILabelDecorator#dispose
	 */
	public void dispose()  {
		super.dispose();
	}

	/**
	 * @see ILabelDecorator#decorateImage
	 */
	public Image decorateImage(Image anImage, Object anElement)  {
		return anImage;
	}

	/**
	 * @see ILabelDecorator#decorateText
	 */
	public String decorateText(String aText, Object anElement)  {
		String grammar = getGrammarProperty(anElement);
		if (grammar != null) {
			StringBuffer buf = new StringBuffer(aText);
			buf.append("  <");
			buf.append(grammar);
			buf.append(">");
			aText = buf.toString();
		}
		return aText;
	}

	private String getGrammarProperty(Object anElement) {
		String grammar = null;
		if (anElement instanceof IResource) {
			try {
				grammar = ((IResource)anElement).getPersistentProperty(
											 AntlrCorePlugin.GRAMMAR_PROPERTY);
			} catch (CoreException e) {
				AntlrUIPlugin.log(e);
			}
		}
		return grammar;
	}
}
