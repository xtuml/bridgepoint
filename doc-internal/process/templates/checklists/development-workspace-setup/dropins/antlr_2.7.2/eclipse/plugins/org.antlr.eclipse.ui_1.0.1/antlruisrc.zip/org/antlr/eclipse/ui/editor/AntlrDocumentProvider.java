package org.antlr.eclipse.ui.editor;

import org.antlr.eclipse.ui.editor.text.PartitionScanner;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IDocumentPartitioner;
import org.eclipse.jface.text.rules.DefaultPartitioner;
import org.eclipse.ui.editors.text.FileDocumentProvider;

/** 
 * This class provides the IDocuments used by ANTLR editors.
 * These IDocuments have an ANTLR-aware partition scanner (multi-line comments)
 * attached.
 */
public class AntlrDocumentProvider extends FileDocumentProvider {

	/* (non-Javadoc)
	 * @see org.eclipse.ui.texteditor.AbstractDocumentProvider#createDocument(java.lang.Object)
	 */
	protected IDocument createDocument(Object anElement)
	 													throws CoreException {
		IDocument document = super.createDocument(anElement);
		if (document != null) {
			IDocumentPartitioner partitioner = new DefaultPartitioner(
					 new PartitionScanner(), PartitionScanner.PARTITION_TYPES);
			partitioner.connect(document);
			document.setDocumentPartitioner(partitioner);
		}
		return document;
	}
}
