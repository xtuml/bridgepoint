package org.antlr.eclipse.ui.editor.text;

import org.eclipse.jface.text.rules.IWhitespaceDetector;

public class WhitespaceDetector implements IWhitespaceDetector {
	public boolean isWhitespace(char aChar) {
		return Character.isWhitespace(aChar);
	}
}
