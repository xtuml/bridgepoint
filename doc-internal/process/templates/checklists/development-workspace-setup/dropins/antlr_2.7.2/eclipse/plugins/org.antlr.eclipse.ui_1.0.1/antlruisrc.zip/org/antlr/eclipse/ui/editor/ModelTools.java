package org.antlr.eclipse.ui.editor;

import java.util.ArrayList;
import java.util.List;

import org.antlr.eclipse.core.parser.ISegment;
import org.antlr.eclipse.core.parser.ISegmentVisitor;
import org.antlr.eclipse.core.parser.Rule;

public class ModelTools {
	private AntlrEditor fEditor;

	public ModelTools(AntlrEditor anEditor) {
		fEditor = anEditor;	
	}

	/**
	 * Uses visitor design pattern to find segment which contains given line.
	 * @param aLine  line to find according segment for
	 * @return segment containing given line or null if no segment found
	 */
    public ISegment getSegment(int aLine) {
		SegmentLineVisitor visitor = new SegmentLineVisitor(aLine);
		fEditor.getReconcilingStrategy().getRootSegment().accept(visitor);
		return visitor.getSegment();
    }

	/**
	 * Uses visitor design pattern to find segment with given name.
	 * @param aName  name to find according segment for
	 * @return segment with given name or null if no segment found
	 */
    public ISegment getSegment(String aName) {
		SegmentRuleNameVisitor visitor = new SegmentRuleNameVisitor(aName);
		fEditor.getReconcilingStrategy().getRootSegment().accept(visitor);
		return visitor.getSegment();
    }

	/**
	 * Uses visitor design pattern to find all rules with given prefix.
	 */
    public String[] getRules(String aPrefix) {
		SegmentRulesVisitor visitor = new SegmentRulesVisitor(aPrefix);
		fEditor.getReconcilingStrategy().getRootSegment().accept(visitor);
		return visitor.getRules();
    }

	private class SegmentLineVisitor implements ISegmentVisitor {
		private int fLine;
		private ISegment fSegment;

		public SegmentLineVisitor(int aLine) {
			fLine = aLine;
			fSegment = null;
		}

		public boolean visit(ISegment aSegment) {
			boolean more;
			if (fLine >= aSegment.getStartLine() &&
										 	fLine <= aSegment.getEndLine()) {
				fSegment = aSegment;
				more = false;
			} else {
				more = true;
			}
			return more; 
		}

		public ISegment getSegment() {
			return fSegment;
		}
	}

	private class SegmentRulesVisitor implements ISegmentVisitor {
		private String fPrefix;
		private List fRules;

		public SegmentRulesVisitor(String aPrefix) {
			fPrefix = aPrefix;
			fRules = new ArrayList();
		}

		public boolean visit(ISegment aSegment) {
			if (aSegment instanceof Rule) {
				String name = ((Rule)aSegment).getName();
				if (name.startsWith(fPrefix)) {
					fRules.add(name);
				}
			}
			return true; 
		}

		public String[] getRules() {
			return (String[])fRules.toArray(new String[fRules.size()]);
		}
	}

	private class SegmentRuleNameVisitor implements ISegmentVisitor {
		private String fName;
		private ISegment fSegment;

		public SegmentRuleNameVisitor(String aName) {
			fName = aName;
			fSegment = null;
		}

		public boolean visit(ISegment aSegment) {
			boolean more;
			if (aSegment instanceof Rule &&
									((Rule)aSegment).getName().equals(fName)) {
				fSegment = aSegment;
				more = false;
			} else {
				more = true;
			}
			return more; 
		}

		public ISegment getSegment() {
			return fSegment;
		}
	}
}
