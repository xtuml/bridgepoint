package org.antlr.eclipse.ui.editor;

import org.antlr.eclipse.ui.AntlrColorProvider;
import org.antlr.eclipse.ui.IColorConstants;
import org.antlr.eclipse.ui.editor.text.AutoIndentStrategy;
import org.antlr.eclipse.ui.editor.text.DoubleClickStrategy;
import org.antlr.eclipse.ui.editor.text.NonRuleBasedDamagerRepairer;
import org.antlr.eclipse.ui.editor.text.PartitionScanner;
import org.eclipse.jface.text.DefaultAutoIndentStrategy;
import org.eclipse.jface.text.IAutoIndentStrategy;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.ITextDoubleClickStrategy;
import org.eclipse.jface.text.ITextHover;
import org.eclipse.jface.text.TextAttribute;
import org.eclipse.jface.text.contentassist.ContentAssistant;
import org.eclipse.jface.text.contentassist.IContentAssistant;
import org.eclipse.jface.text.presentation.IPresentationReconciler;
import org.eclipse.jface.text.presentation.PresentationReconciler;
import org.eclipse.jface.text.reconciler.IReconciler;
import org.eclipse.jface.text.reconciler.MonoReconciler;
import org.eclipse.jface.text.rules.DefaultDamagerRepairer;
import org.eclipse.jface.text.source.IAnnotationHover;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.text.source.SourceViewerConfiguration;

public class AntlrConfiguration extends SourceViewerConfiguration {

	private AntlrEditor fEditor;

	public AntlrConfiguration(AntlrEditor anEditor) {
		fEditor = anEditor;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.text.source.SourceViewerConfiguration#getAutoIndentStrategy(org.eclipse.jface.text.source.ISourceViewer, java.lang.String)
	 */
	public IAutoIndentStrategy getAutoIndentStrategy(ISourceViewer aViewer,
													  String aContentType) {
		return (aContentType.equals(IDocument.DEFAULT_CONTENT_TYPE) ?
				  new AutoIndentStrategy() : new DefaultAutoIndentStrategy());
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.text.source.SourceViewerConfiguration#getDoubleClickStrategy(org.eclipse.jface.text.source.ISourceViewer, java.lang.String)
	 */
	public ITextDoubleClickStrategy getDoubleClickStrategy(
								  ISourceViewer aViewer, String aContentType) {
		return new DoubleClickStrategy();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.text.source.SourceViewerConfiguration#getConfiguredContentTypes(org.eclipse.jface.text.source.ISourceViewer)
	 */
	public String[] getConfiguredContentTypes(ISourceViewer aSourceViewer) {
		return PartitionScanner.PARTITION_TYPES;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.text.source.SourceViewerConfiguration#getPresentationReconciler(org.eclipse.jface.text.source.ISourceViewer)
	 */
	public IPresentationReconciler getPresentationReconciler(
													   ISourceViewer aViewer) {
		PresentationReconciler reconciler = new PresentationReconciler();

		AntlrColorProvider cp = EditorEnvironment.getColorProvider();

		DefaultDamagerRepairer dr = new DefaultDamagerRepairer(
										   EditorEnvironment.getCodeScanner());
		reconciler.setDamager(dr, IDocument.DEFAULT_CONTENT_TYPE);
		reconciler.setRepairer(dr, IDocument.DEFAULT_CONTENT_TYPE);

		NonRuleBasedDamagerRepairer ndr = new NonRuleBasedDamagerRepairer(
					   new TextAttribute(cp.getColor(IColorConstants.STRING)));
		reconciler.setDamager(ndr, PartitionScanner.STRING);
		reconciler.setRepairer(ndr, PartitionScanner.STRING);

		ndr = new NonRuleBasedDamagerRepairer(new TextAttribute(
										cp.getColor(IColorConstants.COMMENT)));
		reconciler.setDamager(ndr, PartitionScanner.SINGLE_LINE_COMMENT);
		reconciler.setRepairer(ndr, PartitionScanner.SINGLE_LINE_COMMENT);

		ndr = new NonRuleBasedDamagerRepairer(new TextAttribute(
										cp.getColor(IColorConstants.COMMENT)));
		reconciler.setDamager(ndr, PartitionScanner.MULTI_LINE_COMMENT);
		reconciler.setRepairer(ndr, PartitionScanner.MULTI_LINE_COMMENT);

		ndr = new NonRuleBasedDamagerRepairer(new TextAttribute(
										cp.getColor(IColorConstants.COMMENT)));
		reconciler.setDamager(ndr, PartitionScanner.JAVA_DOC);
		reconciler.setRepairer(ndr, PartitionScanner.JAVA_DOC);

		return reconciler;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.text.source.SourceViewerConfiguration#getReconciler(org.eclipse.jface.text.source.ISourceViewer)
	 */
	public IReconciler getReconciler(ISourceViewer aSourceViewer) {
		return new MonoReconciler(fEditor.getReconcilingStrategy(), false);
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.jface.text.source.SourceViewerConfiguration#getContentAssistant(org.eclipse.jface.text.source.ISourceViewer)
	 */
	public IContentAssistant getContentAssistant(ISourceViewer aSourceViewer) {
		ContentAssistant assistant = new ContentAssistant();
		assistant.setContentAssistProcessor(new AntlrCompletionProcessor(
									 fEditor), IDocument.DEFAULT_CONTENT_TYPE);
		assistant.enableAutoInsert(true);
		return assistant;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.text.source.SourceViewerConfiguration#getAnnotationHover(org.eclipse.jface.text.source.ISourceViewer)
	 */
	public IAnnotationHover getAnnotationHover(ISourceViewer aSourceViewer) {
		return new AntlrAnnotationHover();
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.jface.text.source.SourceViewerConfiguration#getTextHover(org.eclipse.jface.text.source.ISourceViewer, java.lang.String)
	 */
	public ITextHover getTextHover(ISourceViewer aSourceViewer,
									String aContentType) {
		return new AntlrTextHover(fEditor);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.text.source.SourceViewerConfiguration#getDefaultPrefixes(org.eclipse.jface.text.source.ISourceViewer, java.lang.String)
	 */
	public String[] getDefaultPrefixes(ISourceViewer aSourceViewer,
										String aContentType) {
		return new String[] { "//", "" };
	}
}
