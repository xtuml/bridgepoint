package org.antlr.eclipse.ui.editor.text;

import java.util.ArrayList;
import java.util.List;

import org.antlr.eclipse.ui.AntlrColorProvider;
import org.antlr.eclipse.ui.IColorConstants;
import org.eclipse.jface.text.TextAttribute;
import org.eclipse.jface.text.rules.IRule;
import org.eclipse.jface.text.rules.IToken;
import org.eclipse.jface.text.rules.RuleBasedScanner;
import org.eclipse.jface.text.rules.Token;
import org.eclipse.jface.text.rules.WhitespaceRule;
import org.eclipse.jface.text.rules.WordRule;
import org.eclipse.swt.SWT;

/**
 * An ANTLR and Java aware code scanner.
 */
public class AntlrCodeScanner extends RuleBasedScanner {
	public static final String[] ANTLR_KEYWORDS = new String[] {
					   "header", "options", "tokens", "returns", "exception" };

	public static final String[] JAVA_KEYWORDS = new String[] {
			"abstract", "boolean", "break", "byte", "case", "catch", "char",
			"class", "const", "continue", "default", "do", "double", "else",
			"extends", "false", "final", "finally", "float", "for", "goto",
			"if", "implements", "import", "instanceof", "int", "interface",
			"long", "native", "new", "null", "package", "private", "protected",
			"public", "return", "short", "static", "super", "switch",
			"synchronized", "this", "throw", "throws", "transient", "true",
			"try", "void", "volatile", "while" };

	public AntlrCodeScanner(AntlrColorProvider aColorProvider) {

		IToken keyword = new Token(new TextAttribute(aColorProvider.getColor(
									IColorConstants.KEYWORD), null, SWT.BOLD));
		IToken other = new Token(new TextAttribute(aColorProvider.getColor(
													IColorConstants.DEFAULT)));
		List rules = new ArrayList();

		// Add generic whitespace rule
		rules.add(new WhitespaceRule(new WhitespaceDetector()));

		// Add word rule for ANTLR keywords
		WordRule wordRule = new WordRule(new WordDetector(), other);
		for (int i = 0; i < ANTLR_KEYWORDS.length; i++) {
			wordRule.addWord(ANTLR_KEYWORDS[i], keyword);
		}
		for (int i = 0; i < JAVA_KEYWORDS.length; i++) {
			wordRule.addWord(JAVA_KEYWORDS[i], keyword);
		}
		rules.add(wordRule);

		IRule[] result = new IRule[rules.size()];
		rules.toArray(result);
		setRules(result);
	}
}
