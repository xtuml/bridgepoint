package org.antlr.eclipse.ui.actions;

import org.eclipse.jdt.ui.actions.IJavaEditorActionDefinitionIds;

/**
 * Defines the definition IDs for the ANTLR editor actions.
 */
public interface IAntlrActionDefinitionIds	
									  extends IJavaEditorActionDefinitionIds {

	/**
	 * Action definition ID of the Navigate -> Go To -> Rule action.
	 */
	public static final String GOTO_RULE =
										 "org.antlr.eclipse.ui.edit.goto.rule";
}
