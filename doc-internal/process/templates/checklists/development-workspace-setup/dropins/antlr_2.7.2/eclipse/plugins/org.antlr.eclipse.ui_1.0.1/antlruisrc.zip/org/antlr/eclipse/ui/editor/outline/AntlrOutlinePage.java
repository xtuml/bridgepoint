package org.antlr.eclipse.ui.editor.outline;

import org.antlr.eclipse.core.parser.ISegment;
import org.antlr.eclipse.ui.actions.CollapseAllAction;
import org.antlr.eclipse.ui.actions.LexicalSortingAction;
import org.antlr.eclipse.ui.editor.AntlrEditor;
import org.eclipse.jface.action.IToolBarManager;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.ui.views.contentoutline.ContentOutlinePage;

/**
 * A content outline page which represents the content of an Velocity template
 * file.
 */
public class AntlrOutlinePage extends ContentOutlinePage {
	private AntlrEditor fEditor;
	private Object fInput;
	private String fSelectedSegmentID;
	private AntlrOutlineLabelProvider fLabelProvider;

	/**
	 * Creates a content outline page using the given editor.
	 */
	public AntlrOutlinePage(AntlrEditor anEditor) {
		fEditor = anEditor;
	}

	/**
	 * @see org.eclipse.ui.part.IPart#createControl(Composite)
	 */
	public void createControl(Composite aParent) {
		super.createControl(aParent);
		
		fLabelProvider = new AntlrOutlineLabelProvider();

		// Init tree viewer
		TreeViewer viewer = getTreeViewer();
		viewer.setContentProvider(new AntlrOutlineContentProvider(fEditor));
		viewer.setLabelProvider(fLabelProvider);
		viewer.addSelectionChangedListener(this);
		if (fInput != null) {
			viewer.setInput(fInput);
		}
		
		// Add collapse all button to viewer's toolbar
		IToolBarManager mgr = getSite().getActionBars().getToolBarManager();
		mgr.add(new LexicalSortingAction(viewer));
		mgr.add(new CollapseAllAction(viewer));

		// Refresh outline according to initial cursor position
		update();
	}

	/**
	 * @see org.eclipse.jface.viewers.ISelectionProvider#selectionChanged(SelectionChangedEvent)
	 */
	public void selectionChanged(SelectionChangedEvent anEvent) {
		super.selectionChanged(anEvent);

		ISelection selection = anEvent.getSelection();
		if (!selection.isEmpty()) {
			ISegment segment = (ISegment)
						   ((IStructuredSelection)selection).getFirstElement();
//System.out.println("selectionChanged: segmentID=" + node.getUniqueID() + ", fSelectedNodeID=" + fSelectedNodeID);
			if (fSelectedSegmentID == null || isDifferentSegment(segment)) {
				fEditor.highlightSegment(segment, true);
				fSelectedSegmentID = segment.getUniqueID();
			} else {
				fEditor.revealSegment(segment);
			}
		}
	}

	public void selectSegment(int aLine, boolean aForceSelect) {
		if (aLine > 0) {
			TreeViewer viewer = getTreeViewer();
			ISegment segment = fEditor.getSegment(aLine);
//System.out.println("selectSegment: aLine=" + aLine + ", segmentID=" + (segment != null ? segment.getUniqueID() : "<null>") + ", fSelectedSegmentID=" + fSelectedSegmentID);
			viewer.removeSelectionChangedListener(this);
			if (segment == null) {
				if (fSelectedSegmentID != null) {
					viewer.setSelection(new StructuredSelection());
					fEditor.resetHighlightRange();
					fSelectedSegmentID = null;
				}
			} else {
//System.out.println("   aForceSelect=" + aForceSelect + ", isDifferentBlock=" + isDifferentSegment(segment));
				if (aForceSelect || isDifferentSegment(segment)) {
					viewer.setSelection(new StructuredSelection(segment));
					fEditor.highlightSegment(segment, false);
					fSelectedSegmentID = segment.getUniqueID();
				}
				viewer.reveal(segment);
			}
			viewer.addSelectionChangedListener(this);
		}
	}
	
	private boolean isDifferentSegment(ISegment aSegment) {
		return (fSelectedSegmentID == null ||
				 !fSelectedSegmentID.equals(aSegment.getUniqueID()));
	}

	/**
	 * Sets the input of the outline page.
	 */
	public void setInput(Object aInput) {
		fInput = aInput;
		update();
	}

	/**
	 * Updates the outline page.
	 */
	public void update() {
		TreeViewer viewer = getTreeViewer();
		if (viewer != null) {
			Control control= viewer.getControl();
			if (control != null && !control.isDisposed()) {
				viewer.removeSelectionChangedListener(this);
				control.setRedraw(false);
				viewer.setInput(fInput);
//				viewer.expandAll();
				control.setRedraw(true);
				selectSegment(fEditor.getCursorLine(), true);
				viewer.addSelectionChangedListener(this);
			}
		}
	}

	/**
	 * @see org.eclipse.ui.part.Page#dispose()
	 */
	public void dispose() {
	    setInput(null);
	    if (fLabelProvider != null) {
	    	fLabelProvider.dispose();
	    	fLabelProvider = null;
	    }
	    fEditor.outlineDisposed();
	    super.dispose();
	}
}
