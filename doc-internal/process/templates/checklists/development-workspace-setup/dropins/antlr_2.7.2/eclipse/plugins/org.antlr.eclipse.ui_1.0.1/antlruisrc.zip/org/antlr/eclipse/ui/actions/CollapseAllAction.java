package org.antlr.eclipse.ui.actions;

import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.antlr.eclipse.ui.AntlrUIPluginImages;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.AbstractTreeViewer;

public class CollapseAllAction extends Action {
	private AbstractTreeViewer fViewer;

	public CollapseAllAction(AbstractTreeViewer aViewer) {
		fViewer = aViewer;
        setText(AntlrUIPlugin.getMessage("Editor.CollapseAllAction.label"));
        setToolTipText(AntlrUIPlugin.getMessage(
										  "Editor.CollapseAllAction.tooltip"));
        AntlrUIPluginImages.setLocalImageDescriptors(this, "collapseall.gif");
	}

	/**
	 * @see org.eclipse.jface.action.IAction#run()
	 */
	public void run() {
		fViewer.collapseAll();
	}
}
