package org.antlr.eclipse.ui;

import java.net.URL;
import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IPluginDescriptor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.plugin.AbstractUIPlugin;

/**
 * Central access point for the ANTLR UI plug-in
 * (id <code>"org.antlr.eclipse.ui"</code>).
 *
 * @author Torsten Juergeleit
 */
public class AntlrUIPlugin extends AbstractUIPlugin {
    
	/** The id of the ANTLR plugin
	 * (value <code>"org.antlr.eclipse.ui"</code>). */	
	public static final String PLUGIN_ID = "org.antlr.eclipse.ui";

	/** Singleton instance of this plugin */
	private static AntlrUIPlugin fPlugin;

	private static final String RESOURCE_NAME = PLUGIN_ID + ".messages";
	private ResourceBundle fResourceBundle;

	/**
	 * The constructor.
	 */
	public AntlrUIPlugin(IPluginDescriptor aDescriptor) {
		super(aDescriptor);
		fPlugin = this;
		try {
			fResourceBundle = ResourceBundle.getBundle(RESOURCE_NAME);
		} catch (MissingResourceException e) {
			log(e);
			fResourceBundle = null;
		}
	}

	/**
	 * Sets default preference values. These values will be used until some
	 * preferences are actually set using the preference dialog.
	 * @see org.eclipse.ui.plugin.AbstractUIPlugin#initializeDefaultPreferences(org.eclipse.jface.preference.IPreferenceStore)
	 */
	protected void initializeDefaultPreferences(IPreferenceStore aStore) {
		super.initializeDefaultPreferences(aStore);

		aStore.setDefault(IPreferencesConstants.EDITOR_SHOW_SEGMENTS, false);
		AntlrColorProvider.initializeDefaults(aStore);
	}

	/**
	 * Returns the shared instance.
	 */
	public static AntlrUIPlugin getDefault() {
		return fPlugin;
	}

	public ResourceBundle getResourceBundle() {
		return fResourceBundle;
	}

	public static IWorkspace getWorkspace() {
		return ResourcesPlugin.getWorkspace();
	}

	public static Shell getActiveWorkbenchShell() {
		IWorkbenchWindow window = getActiveWorkbenchWindow();
		return (window != null ? window.getShell() : null);
	}

	public static IWorkbenchWindow getActiveWorkbenchWindow() {
		return getDefault().getWorkbench().getActiveWorkbenchWindow();
	}
	
	public static String getPluginId() {
		return getDefault().getDescriptor().getUniqueIdentifier();
	}

	public static IPath getInstallLocation() {
		return new Path(getInstallURL().getFile());
	}

	public static URL getInstallURL() {
		return getDefault().getDescriptor().getInstallURL();
	}

	public static String getUniqueIdentifier() {
		return getDefault().getDescriptor().getUniqueIdentifier();
	}

	public static void log(IStatus aStatus) {
		getDefault().getLog().log(aStatus);
	}
	
	public static void log(Throwable aThrowable) {
		log(new Status(IStatus.ERROR, getPluginId(), Status.OK,
						getMessage("Plugin.internal_error"),
						aThrowable));
	}
	
	public static void logErrorMessage(String aMessage) {
		log(new Status(IStatus.ERROR, getPluginId(), Status.OK, aMessage,
			null));
	}

	public static void logErrorStatus(String aMessage, IStatus aStatus) {
		if (aStatus == null) {
			logErrorMessage(aMessage);
		} else {
			MultiStatus multi = new MultiStatus(getPluginId(), Status.OK,
											    aMessage, null);
			multi.add(aStatus);
			log(multi);
		}
	}
	
	public static boolean isDebug() {
		return getDefault().isDebugging();
	}

	public static String getMessage(String aKey) {
	    String bundleString;
		ResourceBundle bundle = getDefault().getResourceBundle();
		if (bundle != null) {
			try {
				bundleString = bundle.getString(aKey);
			} catch (MissingResourceException e) {
			    log(e);
				bundleString = "!" + aKey + "!";
			}
		} else {
			bundleString = "!" + aKey + "!";
		}
		return bundleString;
	}

	public static String getFormattedMessage(String aKey, String anArg) {
		return getFormattedMessage(aKey, new String[] { anArg });
	}

	public static String getFormattedMessage(String aKey, String[] anArgs) {
		return MessageFormat.format(getMessage(aKey), anArgs);
	}
}
