package org.antlr.eclipse.ui.editor;

import org.antlr.eclipse.ui.AntlrColorProvider;
import org.antlr.eclipse.ui.editor.outline.*;
import org.antlr.eclipse.ui.editor.text.AntlrCodeScanner;
import org.eclipse.jface.text.rules.ITokenScanner;
import org.eclipse.jface.viewers.ILabelProvider;

/**
 * The EditorEnvironment maintains singletons used by the ANTLR editor.
 *
 * @author Torsten Juergeleit
 */
public class EditorEnvironment {

	private static AntlrColorProvider fColorProvider;
	private static ITokenScanner fCodeScanner;
	private static ILabelProvider fLabelProvider;

	private static int fRefCount = 0;

	/**
	 * A connection has occured - initialize the receiver if it is the first activation.
	 */
	public static void connect(Object aClient) {
		if (++fRefCount == 1) {
			fColorProvider = new AntlrColorProvider();
			fCodeScanner = new AntlrCodeScanner(fColorProvider);
			fLabelProvider = new AntlrOutlineLabelProvider();
		}
	}
	
	/**
	 * A disconnection has occured - clear the receiver if it is the last deactivation.
	 */
	public static void disconnect(Object aClient) {
		if (--fRefCount == 0) {
			fColorProvider.dispose();
			fColorProvider = null;
			fCodeScanner = null;
			fLabelProvider.dispose();
			fLabelProvider = null;
		}
	}
	
	/**
	 * Returns the singleton color provider.
	 */
	public static AntlrColorProvider getColorProvider() {
		return fColorProvider;
	}
	
	/**
	 * Returns the singleton scanner.
	 */
	public static ITokenScanner getCodeScanner() {
		return fCodeScanner;
	}
	
	/**
	 * Returns the singleton label provider.
	 */
	public static ILabelProvider getLabelProvider() {
		return fLabelProvider;
	}
}
