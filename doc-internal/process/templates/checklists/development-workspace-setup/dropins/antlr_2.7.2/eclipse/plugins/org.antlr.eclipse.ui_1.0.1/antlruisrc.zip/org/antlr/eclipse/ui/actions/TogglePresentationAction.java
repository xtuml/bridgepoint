package org.antlr.eclipse.ui.actions;

import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.antlr.eclipse.ui.AntlrUIPluginImages;
import org.antlr.eclipse.ui.IPreferencesConstants;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.text.IRegion;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.TextEditorAction;

/**
 * A toolbar action which toggles the presentation model of the connected text
 * editor. The editor shows either the highlight range only or always the
 * whole document.
 */
public class TogglePresentationAction extends TextEditorAction {
	private static final String PREFIX = "Editor.TogglePresentation";

	/**
	 * Constructs and updates the action.
	 */
	public TogglePresentationAction() {
		super(AntlrUIPlugin.getDefault().getResourceBundle(), PREFIX, null);
        AntlrUIPluginImages.setToolImageDescriptors(this, "segment_edit.gif");
		update();
	}
	
	/**
	 * @see IAction#run()
	 */
	public void run() {
		ITextEditor editor = getTextEditor();
		if (editor != null) {
			IRegion remembered = editor.getHighlightRange();
			editor.resetHighlightRange();
			
			boolean showAll = !editor.showsHighlightRangeOnly();
			setChecked(showAll);
			setToolTipText(getToolTipText(showAll));
			
			editor.showHighlightRangeOnly(showAll);
			if (remembered != null)  {
				editor.setHighlightRange(remembered.getOffset(),
										 remembered.getLength(), true);
			}
			
			IPreferenceStore store = AntlrUIPlugin.getDefault().getPreferenceStore();
			store.setValue(IPreferencesConstants.EDITOR_SHOW_SEGMENTS, showAll);
		}
	}
	
	/**
	 * @see IUpdate#update()
	 */
	public void update() {
		ITextEditor editor = getTextEditor();
		boolean checked = (editor != null && editor.showsHighlightRangeOnly());
		setChecked(checked);
		setToolTipText(getToolTipText(checked));
		setEnabled(true);
	}
	
	/**
	 * @see TextEditorAction#setEditor(ITextEditor)
	 */
	public void setEditor(ITextEditor anEditor) {
		super.setEditor(anEditor);
		
		if (anEditor != null) {
			IPreferenceStore store = AntlrUIPlugin.getDefault().getPreferenceStore();
			boolean showSegments = store.getBoolean(
									IPreferencesConstants.EDITOR_SHOW_SEGMENTS);
			if (isChecked() != showSegments) {
				setChecked(showSegments);
				setToolTipText(getToolTipText(showSegments));
			}
			
			if (anEditor.showsHighlightRangeOnly() != showSegments) {
				IRegion remembered = anEditor.getHighlightRange();
				anEditor.resetHighlightRange();
				anEditor.showHighlightRangeOnly(showSegments);
				if (remembered != null) {
					anEditor.setHighlightRange(remembered.getOffset(),
											   remembered.getLength(), true);
				}
			}
		}
	}

	private String getToolTipText(boolean anIsChecked) {
		return (anIsChecked
				? AntlrUIPlugin.getMessage(PREFIX + ".tooltip.checked")
				: AntlrUIPlugin.getMessage(PREFIX + ".tooltip.unchecked"));
	}
}
