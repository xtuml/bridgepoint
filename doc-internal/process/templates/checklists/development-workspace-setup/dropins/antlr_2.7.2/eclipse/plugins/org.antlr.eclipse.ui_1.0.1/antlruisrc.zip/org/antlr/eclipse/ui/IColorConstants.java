package org.antlr.eclipse.ui;

public interface IColorConstants {
	String DEFAULT = "default";
	String KEYWORD = "keyword";
	String STRING = "string";
	String COMMENT = "comment";
}
