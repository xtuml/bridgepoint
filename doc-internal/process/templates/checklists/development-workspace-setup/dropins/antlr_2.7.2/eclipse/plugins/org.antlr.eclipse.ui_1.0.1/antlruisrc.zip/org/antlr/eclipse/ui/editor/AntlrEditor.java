package org.antlr.eclipse.ui.editor;

import java.util.Iterator;

import org.antlr.eclipse.core.parser.ISegment;
import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.antlr.eclipse.ui.actions.GotoRuleAction;
import org.antlr.eclipse.ui.actions.IAntlrActionConstants;
import org.antlr.eclipse.ui.actions.IAntlrActionDefinitionIds;
import org.antlr.eclipse.ui.editor.outline.AntlrOutlinePage;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.jdt.ui.actions.IJavaEditorActionDefinitionIds;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.IStatusLineManager;
import org.eclipse.jface.text.BadLocationException;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextOperationTarget;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.viewers.ISelectionChangedListener;
import org.eclipse.jface.viewers.ISelectionProvider;
import org.eclipse.jface.viewers.SelectionChangedEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.ui.IEditorActionBarContributor;
import org.eclipse.ui.IFileEditorInput;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.editors.text.TextEditor;
import org.eclipse.ui.part.EditorActionBarContributor;
import org.eclipse.ui.texteditor.ContentAssistAction;
import org.eclipse.ui.texteditor.ITextEditorActionConstants;
import org.eclipse.ui.texteditor.ITextEditorActionDefinitionIds;
import org.eclipse.ui.texteditor.MarkerAnnotation;
import org.eclipse.ui.texteditor.MarkerUtilities;
import org.eclipse.ui.texteditor.TextOperationAction;
import org.eclipse.ui.views.contentoutline.IContentOutlinePage;
import org.eclipse.ui.views.tasklist.TaskList;

public class AntlrEditor extends TextEditor {
	private static final String PREFIX = "Editor.";

	private ModelTools fModelTools;
	private AntlrReconcilingStrategy fReconcilingStrategy;

	/** The outline page */
	private AntlrOutlinePage fOutlinePage;

	/** The status line clearer */
	private ISelectionChangedListener fStatusLineClearer;

	/** Last cursor position (line) handled in
	 * <code>handleCursorPositionChanged()</code> */
	private int fLastCursorLine;

	public AntlrEditor() {
		fModelTools = new ModelTools(this);
		fReconcilingStrategy = new AntlrReconcilingStrategy(this);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.editors.text.TextEditor#initializeEditor()
	 */
	protected void initializeEditor() {
		super.initializeEditor();

		EditorEnvironment.connect(this);

		setDocumentProvider(new AntlrDocumentProvider());
		setSourceViewerConfiguration(new AntlrConfiguration(this));
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.editors.text.TextEditor#initializeKeyBindingScopes()
	 */
	protected void initializeKeyBindingScopes() {
		setKeyBindingScopes(new String[] { "org.antlr.ui.antlrEditorScope" });
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.ui.texteditor.AbstractTextEditor#createActions()
	 */
	protected void createActions() {
		super.createActions();

		// Add goto rule action
		IAction action = new GotoRuleAction(
								AntlrUIPlugin.getDefault().getResourceBundle(),
								PREFIX + "GotoRule.", this);
		action.setActionDefinitionId(IAntlrActionDefinitionIds.GOTO_RULE);
		setAction(IAntlrActionConstants.GOTO_RULE, action);

		// Add content assist propsal action
		action = new ContentAssistAction(
								AntlrUIPlugin.getDefault().getResourceBundle(),
								PREFIX + "ContentAssist.", this);
		action.setActionDefinitionId(
					  ITextEditorActionDefinitionIds.CONTENT_ASSIST_PROPOSALS);
		setAction(IAntlrActionConstants.CONTENT_ASSIST, action);

		// Add comment action
		action = new TextOperationAction(
					  AntlrUIPlugin.getDefault().getResourceBundle(),
					  PREFIX + "Comment.", this, ITextOperationTarget.PREFIX);
		action.setActionDefinitionId(IJavaEditorActionDefinitionIds.COMMENT);		
		setAction(IAntlrActionConstants.COMMENT, action);

		// Add uncomment action
		action = new TextOperationAction(
			  AntlrUIPlugin.getDefault().getResourceBundle(),
			  PREFIX + "Uncomment.", this, ITextOperationTarget.STRIP_PREFIX);
		action.setActionDefinitionId(IJavaEditorActionDefinitionIds.UNCOMMENT);		
		setAction(IAntlrActionConstants.UNCOMMENT, action);
	}

	/**
	 * Called from outline page during <code>dispose()</code>.
	 */
	public void outlineDisposed() {
		fOutlinePage = null;
	}
	
	/**
	 * The <code>AntlrEditor</code> implementation of this 
	 * <code>AbstractTextEditor</code> method gets the ANTLR content outline
	 * page if request is for a an outline page.
	 * 
	 * @see org.eclipse.core.runtime.IAdaptable.getAdapter(Class)
	 */ 
	public Object getAdapter(Class aClass) {
	    Object adapter;
		if (aClass.equals(IContentOutlinePage.class)) {
			if (fOutlinePage == null) {
			    fOutlinePage = new AntlrOutlinePage(this);
				if (getEditorInput() != null) {
					fOutlinePage.setInput(getEditorInput());
				}
			}
			adapter = fOutlinePage;
		} else {
		    adapter = super.getAdapter(aClass);
		}
		return adapter;
	}
	
	/**
	 * The <code>AntlrEditor</code> implementation of this 
	 * <code>AbstractTextEditor</code> method performs any extra 
	 * disposal actions required by the ANTLR editor.
	 *
	 * @see org.eclipse.ui.IWorkbenchPart#dispose()
	 */
	public void dispose() {
		EditorEnvironment.disconnect(this);
		if (fOutlinePage != null) {
			fOutlinePage.dispose();
		}
		super.dispose();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.texteditor.AbstractTextEditor#editorContextMenuAboutToShow(org.eclipse.jface.action.IMenuManager)
	 */
	protected void editorContextMenuAboutToShow(IMenuManager aMenu) {
		super.editorContextMenuAboutToShow(aMenu);
		addAction(aMenu, ITextEditorActionConstants.MB_ADDITIONS,
				  IAntlrActionConstants.GOTO_RULE);
		addAction(aMenu, ITextEditorActionConstants.MB_ADDITIONS,
				  IAntlrActionConstants.COMMENT);
		addAction(aMenu, ITextEditorActionConstants.MB_ADDITIONS,
				  IAntlrActionConstants.UNCOMMENT);
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.texteditor.AbstractTextEditor#handleCursorPositionChanged()
	 */
	protected void handleCursorPositionChanged() {
		super.handleCursorPositionChanged();
		int line = getCursorLine();
		if (line > 0 && line != fLastCursorLine) {
			fLastCursorLine = line;
			if (fOutlinePage != null) {
//System.out.println("handleCursorPositionChanged: line=" + line);
				fOutlinePage.selectSegment(line, false);
			}
		}
	}	

	public IDocument getDocument() {
		return getSourceViewer().getDocument();
	}

	public int getCursorLine() {
		int line = -1;

		ISourceViewer sourceViewer = getSourceViewer();
		if (sourceViewer != null) {
			StyledText styledText = sourceViewer.getTextWidget();
			int caret = widgetOffset2ModelOffset(sourceViewer,
												  styledText.getCaretOffset());
			IDocument document = sourceViewer.getDocument();
			if (document != null) {
				try {
					line = document.getLineOfOffset(caret) + 1;
				} catch (BadLocationException e) {
					AntlrUIPlugin.log(e);
				}
			}
		}
		return line;
	}

	public String[] getRules(String aPrefix) {
		return fModelTools.getRules(aPrefix);
	}

	public ISegment getSegment(int aLine) {
		return fModelTools.getSegment(aLine);
	}

	public ISegment getSegment(String aName) {
		return fModelTools.getSegment(aName);
	}

	public void highlightSegment(ISegment aSegment, boolean aMoveCursor) {
	    IDocument doc = getDocument();
		try {
			int offset = doc.getLineOffset(aSegment.getStartLine() - 1);
			IRegion endLine = doc.getLineInformation(aSegment.getEndLine() - 1);
			int length = endLine.getOffset() + endLine.getLength() - offset;
			setHighlightRange(offset, length, aMoveCursor);
		} catch (BadLocationException e) {
			resetHighlightRange();
		}
	}

	public void revealSegment(ISegment aSegment) {
		ISourceViewer viewer = getSourceViewer();
		if (viewer != null) {
		    IDocument doc = getDocument();
			try {
				int offset = doc.getLineOffset(aSegment.getStartLine() - 1);
				IRegion endLine = doc.getLineInformation(aSegment.getEndLine() - 1);
				int length = endLine.getOffset() + endLine.getLength() - offset;
				
				// Reveal segment's text area in document
				StyledText widget = getSourceViewer().getTextWidget();
				widget.setRedraw(false);
				viewer.revealRange(offset, length);
				widget.setRedraw(true);
			} catch (BadLocationException e) {
				resetHighlightRange();
			}
		}
	}

	public void gotoRule(String aName) {
		ISegment segment = fModelTools.getSegment(aName);
		if (segment != null) {
			highlightSegment(segment, true);
		}
	}

	/**
	 * Jumps to the next or previous error according to the given direction.
	 */
	public void gotoError(boolean anIsForward) {
		ISelectionProvider provider = getSelectionProvider();
		
		if (fStatusLineClearer != null) {
			provider.removeSelectionChangedListener(fStatusLineClearer);
			fStatusLineClearer= null;
		}
		
		ITextSelection s = (ITextSelection)provider.getSelection();
		IMarker nextError = getNextError(s.getOffset(), anIsForward);
		
		if (nextError != null) {
			
			gotoMarker(nextError);
			
			IWorkbenchPage page = getSite().getPage();
			
			IViewPart view = page.findView("org.eclipse.ui.views.TaskList");
			if (view instanceof TaskList) {
				StructuredSelection ss = new StructuredSelection(nextError);
				((TaskList)view).setSelection(ss, true);
			}
			
			getStatusLineManager().setErrorMessage(nextError.getAttribute(IMarker.MESSAGE, ""));
			fStatusLineClearer = new ISelectionChangedListener() {
				public void selectionChanged(SelectionChangedEvent event) {
					getSelectionProvider().removeSelectionChangedListener(fStatusLineClearer);
					fStatusLineClearer = null;
					getStatusLineManager().setErrorMessage("");
				}
			};
			provider.addSelectionChangedListener(fStatusLineClearer);
		
		} else {
			getStatusLineManager().setErrorMessage("");
		}
	}

	private IMarker getNextError(int anOffset, boolean anIsForward) {
		
		IMarker nextError = null;
		
		IDocument document = getDocument();
		int endOfDocument = document.getLength(); 
		int distance = 0;
		
		IAnnotationModel model = getDocumentProvider().getAnnotationModel(getEditorInput());
		Iterator iter = model.getAnnotationIterator();
		while (iter.hasNext()) {
			Annotation a = (Annotation)iter.next();
			if (a instanceof MarkerAnnotation) {
				IMarker marker = ((MarkerAnnotation)a).getMarker();
		
				if (MarkerUtilities.isMarkerType(marker, IMarker.PROBLEM)) {
					Position p = model.getPosition(a);
					if (!p.includes(anOffset)) {
						int currentDistance = 0;
						if (anIsForward) {
							currentDistance = p.getOffset() - anOffset;
							if (currentDistance < 0) {
								currentDistance = endOfDocument - anOffset +
												  p.getOffset();
							}
						} else {
							currentDistance = anOffset - p.getOffset();
							if (currentDistance < 0) {
								currentDistance = anOffset + endOfDocument -
												  p.getOffset();
							}
						}						
						if (nextError == null || currentDistance < distance) {
							distance = currentDistance;
							nextError = marker;
						}
					}
				}
		
			}
		}
		return nextError;
	}

	public AntlrReconcilingStrategy getReconcilingStrategy() {
		return fReconcilingStrategy;
	}

	public Object[] getRootElements() {
		return fReconcilingStrategy.getRootElements();
	}

	public ISegment getRootSegment() {
		return fReconcilingStrategy.getRootSegment();
	}

	public ISegment getLastRootSegment() {
		return fReconcilingStrategy.getLastRootSegment();
	}

	public void updateOutlinePage() {
		if (fOutlinePage != null) {
			fOutlinePage.update();
		}
	}

	public void moveCursor(int aLine) {
		ISourceViewer sourceViewer = getSourceViewer();
		try {
			int offset = getDocument().getLineOffset(aLine - 1);
			sourceViewer.setSelectedRange(offset, 0);
			sourceViewer.revealRange(offset, 0);
		} catch (BadLocationException e) {
		}
	}
	
	/**
	 * Returns the desktop's StatusLineManager.
	 */
	protected IStatusLineManager getStatusLineManager() {
		IStatusLineManager manager;
		IEditorActionBarContributor contributor =
									 getEditorSite().getActionBarContributor();
		if (contributor != null &&
						  contributor instanceof EditorActionBarContributor) {
			manager = ((EditorActionBarContributor)contributor).
										getActionBars().getStatusLineManager();
		} else {
			manager = null;
		}
		return manager;
	}	

	/**
	 * Displays an error message in editor's status line.
	 */
	public void displayErrorMessage(String aMessage) {
		IStatusLineManager manager = getStatusLineManager();
		if (manager != null) {
			manager.setErrorMessage(aMessage);
		}
	}	

	public void addProblemMarker(String aMessage, int aLine) {
		IFile file = ((IFileEditorInput)getEditorInput()).getFile(); 
		try {
			IMarker marker = file.createMarker(IMarker.PROBLEM);
			marker.setAttribute(IMarker.SEVERITY, IMarker.SEVERITY_ERROR);
			marker.setAttribute(IMarker.MESSAGE, aMessage);
			marker.setAttribute(IMarker.LINE_NUMBER, aLine);
			Position pos = new Position(getDocument().getLineOffset(aLine - 1));
			getSourceViewer().getAnnotationModel().addAnnotation(
											new MarkerAnnotation(marker), pos);
		} catch (Exception e) {
			AntlrUIPlugin.log(e);
		}
	}
}
