package org.antlr.eclipse.ui.editor;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import org.antlr.eclipse.core.parser.AntlrLexer;
import org.antlr.eclipse.core.parser.AntlrParser;
import org.antlr.eclipse.core.parser.Hierarchy;
import org.antlr.eclipse.core.parser.ISegment;
import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IResource;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.reconciler.DirtyRegion;
import org.eclipse.jface.text.reconciler.IReconcilingStrategy;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IFileEditorInput;

import antlr.DefaultFileLineFormatter;
import antlr.FileLineFormatter;
import antlr.RecognitionException;
import antlr.TokenStreamRecognitionException;

/**
 * Reconciler strategy which parses the whole editor's content (a ANTLR
 * grammar) on a document change.
 */
public class AntlrReconcilingStrategy implements IReconcilingStrategy {
	private AntlrEditor fEditor;
    private Hierarchy fHierarchy;
    private Hierarchy fLastHierarchy;
	private String fError;

	public AntlrReconcilingStrategy(AntlrEditor anEditor) {
		fEditor = anEditor;
	}

	public void setDocument(IDocument aDocument) {
		parse();
	}

	public void reconcile(DirtyRegion aDirtyRegion, IRegion aRegion) {
		parse();
	}

	public void reconcile(IRegion aPartition) {
		parse();
	}

	private void parse() {
		IFile file = ((IFileEditorInput)fEditor.getEditorInput()).getFile(); 
		String name = file.getName();
		Reader reader = new StringReader(fEditor.getDocument().get());
    	Hierarchy hierarchy = null;
        try {
			FileLineFormatter.setFormatter(new DefaultFileLineFormatter());
			file.deleteMarkers(IMarker.PROBLEM, true, IResource.DEPTH_INFINITE);
			AntlrParser parser = new AntlrParser(new AntlrLexer(reader));
			FileLineFormatter.setFormatter(new DefaultFileLineFormatter());
			hierarchy = parser.grammarFile(name);

			// If exception occured then display error message and optional
			// problem marker (for RecognitionException only)
			Exception e = hierarchy.getException();
			if (e != null) {
				fError = e.toString();
				if (e instanceof RecognitionException) {
					fEditor.addProblemMarker(fError,
										  ((RecognitionException)e).getLine());
				} else if (e instanceof TokenStreamRecognitionException) {
					fEditor.addProblemMarker(fError,
						 ((TokenStreamRecognitionException)e).recog.getLine());
				}
			} else {
				fError = "";
			}
		} catch (Exception e) {
			fError = "";
			AntlrUIPlugin.log(e);
        } finally {
        	try {
				reader.close();        
        	} catch (IOException e) {
        		AntlrUIPlugin.log(e);
        	}
        }

		// Examine parse tree
		synchronized (this) {
        	if (hierarchy != null) {
				fHierarchy = hierarchy;

				// Save last successful parse tree
				if (hierarchy.getException() != null) {
					fLastHierarchy = hierarchy;
				}
        	} else {
        		fHierarchy = new Hierarchy("<empty>");
        	}
		}

		// Update outline view and display error message in status line
		Display.getDefault().syncExec(new Runnable() {
			public void run(){	
				fEditor.updateOutlinePage();
				fEditor.displayErrorMessage(fError);
			}
		});
	}

	/**
	 * Returns root elements of current parse tree.
	 */    
    public Object[] getRootElements() {
        return fHierarchy.getChildren();
    }

	/**
	 * Returns root node of current parse tree.
	 */    
    public ISegment getRootSegment() {
        return fHierarchy;
    }

	/**
	 * Returns last successful parse tree.
	 */    
    public ISegment getLastRootSegment() {
        return fLastHierarchy;
    }
}
