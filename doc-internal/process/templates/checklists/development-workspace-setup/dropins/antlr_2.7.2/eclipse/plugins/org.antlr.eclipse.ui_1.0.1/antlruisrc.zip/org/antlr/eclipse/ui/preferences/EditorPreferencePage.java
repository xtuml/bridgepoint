package org.antlr.eclipse.ui.preferences;

import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.antlr.eclipse.ui.IPreferencesConstants;
import org.eclipse.jface.preference.ColorFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

/**
 * Color settings for editor syntax highliting.
 */
public class EditorPreferencePage extends FieldEditorPreferencePage
										 implements IWorkbenchPreferencePage {
	private final String PREFIX = "Preferences.Editor.";

	public EditorPreferencePage() {
		super(FieldEditorPreferencePage.GRID);
		setPreferenceStore(AntlrUIPlugin.getDefault().getPreferenceStore());
        setDescription(AntlrUIPlugin.getMessage(PREFIX + "description"));
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.preference.FieldEditorPreferencePage#createFieldEditors()
	 */
	protected void createFieldEditors() {
		addField(new ColorFieldEditor(IPreferencesConstants.COLOR_DEFAULT,
								  AntlrUIPlugin.getMessage(PREFIX + "default"),
								  getFieldEditorParent()));
		addField(new ColorFieldEditor(IPreferencesConstants.COLOR_KEYWORD,
								  AntlrUIPlugin.getMessage(PREFIX + "keyword"),
								  getFieldEditorParent()));
		addField(new ColorFieldEditor(IPreferencesConstants.COLOR_STRING,
								   AntlrUIPlugin.getMessage(PREFIX + "string"),
								   getFieldEditorParent()));
		addField(new ColorFieldEditor(IPreferencesConstants.COLOR_COMMENT,
								  AntlrUIPlugin.getMessage(PREFIX + "comment"),
								  getFieldEditorParent()));
    }

	/* (non-Javadoc)
	 * @see org.eclipse.ui.IWorkbenchPreferencePage#init(org.eclipse.ui.IWorkbench)
	 */
	public void init(IWorkbench aWorkbench) {
	}

    /* (non-Javadoc)
	 * @see org.eclipse.jface.preference.IPreferencePage#performOk()
	 */
	public boolean performOk() {
        boolean value = super.performOk();
        AntlrUIPlugin.getDefault().savePluginPreferences();
        return value;
    }
}
