package org.antlr.eclipse.ui;

/**
 * Defines constants which are used to refer to values in the plugin's
 * preference bundle.
 */
public interface IPreferencesConstants {
	String PREFIX = AntlrUIPlugin.PLUGIN_ID + ".";

	String EDITOR_SHOW_SEGMENTS = PREFIX + "editor.showSegments";
	String EDITOR_OUTLINE_SORT = PREFIX + "editor.outline.sort";

	String PREFIX_COLOR = PREFIX + "color.";

	String COLOR_DEFAULT = PREFIX_COLOR + IColorConstants.DEFAULT;
	String COLOR_KEYWORD = PREFIX_COLOR + IColorConstants.KEYWORD;
	String COLOR_STRING = PREFIX_COLOR + IColorConstants.STRING;
	String COLOR_COMMENT = PREFIX_COLOR + IColorConstants.COMMENT;
}