package org.antlr.eclipse.ui.actions;

import org.antlr.eclipse.ui.AntlrUIPlugin;
import org.antlr.eclipse.ui.AntlrUIPluginImages;
import org.antlr.eclipse.ui.IPreferencesConstants;
import org.antlr.eclipse.ui.editor.outline.AntlrOutlineSorter;
import org.eclipse.core.runtime.Preferences;
import org.eclipse.jface.action.Action;
import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.jface.viewers.ViewerSorter;

public class LexicalSortingAction extends Action {

	private static final String PREFIX = "OutlinePage.Sort.";
	private static final ViewerSorter SORTER = new AntlrOutlineSorter();
	private StructuredViewer fViewer;

    /**
     * Constructor for LexicalSortingAction.
     */
    public LexicalSortingAction(StructuredViewer aViewer) {
        fViewer = aViewer;
        setText(AntlrUIPlugin.getMessage(PREFIX + "label"));
        AntlrUIPluginImages.setLocalImageDescriptors(this, "alphab_sort_co.gif");
        Preferences prefs = AntlrUIPlugin.getDefault().getPluginPreferences();
        boolean checked = prefs.getBoolean(IPreferencesConstants.EDITOR_OUTLINE_SORT);
        valueChanged(checked, false);
    }

    public void run() {
        valueChanged(isChecked(), true);
    }

    private void valueChanged(boolean aValue, boolean aDoStore) {
        setChecked(aValue);
        fViewer.setSorter(aValue ? SORTER : null);
        setToolTipText(aValue ?
			AntlrUIPlugin.getMessage(PREFIX + "tooltip.checked") :
			AntlrUIPlugin.getMessage(PREFIX + "tooltip.unchecked"));
        setDescription(aValue ?
			AntlrUIPlugin.getMessage(PREFIX + "description.checked") :
			AntlrUIPlugin.getMessage(PREFIX + "description.unchecked"));
        if (aDoStore) {
	        Preferences prefs = AntlrUIPlugin.getDefault().getPluginPreferences();
	        prefs.setValue(IPreferencesConstants.EDITOR_OUTLINE_SORT, aValue);
        }
    }
}