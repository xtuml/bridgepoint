package org.antlr.eclipse.ui.actions;

import org.antlr.eclipse.core.AntlrNature;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.util.Assert;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;

public class ConversionAction implements IObjectActionDelegate {
    private IWorkbenchPart fPart;
	private IProject fProject;

    /**
     * @see IObjectActionDelegate#setActivePart(IAction, IWorkbenchPart)
     */
    public void setActivePart(IAction anAction, IWorkbenchPart aTargetPart) {
		fPart = aTargetPart;
    }

	/**
	 * @see org.eclipse.ui.IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction anAction, ISelection aSelection) {
		if (aSelection instanceof IStructuredSelection) {
			boolean enabled = false;
			Object obj = (((IStructuredSelection)aSelection).getFirstElement());
			if (obj == null) {
				fProject = null;
			} else {
				if (obj instanceof IProject) {
					fProject = (IProject)obj;
				} else {
	
					// In plugin.xml is configured to allow IResource instances
					// which are adaptable to IProject
					fProject = (IProject)((IAdaptable)obj).getAdapter(IProject.class);
				}
				if (fProject.isOpen()) {
					enabled = true;
				}
			}
			anAction.setEnabled(enabled);
		}
	}

	/**
	 * @see org.eclipse.ui.IActionDelegate#run(IAction)
	 */
	public void run(IAction anAction) {
		Assert.isNotNull(fProject);
		if (AntlrNature.hasNature(fProject)) {
			AntlrNature.removeNature(fProject, null);
		} else {
			AntlrNature.addNature(fProject, null);
		}
	}
}
