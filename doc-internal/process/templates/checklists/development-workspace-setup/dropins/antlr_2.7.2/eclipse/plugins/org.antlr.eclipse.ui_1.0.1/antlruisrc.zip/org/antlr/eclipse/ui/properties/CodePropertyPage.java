package org.antlr.eclipse.ui.properties;

import org.antlr.eclipse.core.AntlrCorePlugin;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.dialogs.PropertyPage;

/**
 * Properties page for Java files.
 * If the Java file is generated via ANTLR then the name of the according ANTLR
 * grammar file is displayed.
 */
public class CodePropertyPage extends PropertyPage {

	private static final String GRAMMAR_LABEL = "Grammar:";

	/**
	 * @see PreferencePage#createContents(Composite)
	 */
	protected Control createContents(Composite aParent) {

		// Get ANTLR grammar name from file property
		String grammar;
		try {
			grammar = ((IResource)getElement()).getPersistentProperty(
											 AntlrCorePlugin.GRAMMAR_PROPERTY);
		} catch (CoreException e) {
			grammar = null;
		}
		
		// If ANTLR grammar property found then display it
		Composite composite;
		if (grammar != null) {
			composite = new Composite(aParent, SWT.NULL);
			GridLayout layout = new GridLayout();
			layout.numColumns = 2;
			composite.setLayout(layout);
	
			GridData data = new GridData();
			data.verticalAlignment = GridData.FILL;
			data.horizontalAlignment = GridData.FILL;
			composite.setLayoutData(data);
	
			// Label for ANTLR grammar field
			Label grammarLabel = new Label(composite, SWT.NONE);
			grammarLabel.setText(GRAMMAR_LABEL);
	
			// ANTLR grammar text field
			Text grammarValueText = new Text(composite,
											  SWT.WRAP | SWT.READ_ONLY);
			grammarValueText.setText(grammar);
		} else {
			composite = aParent;
		}
		noDefaultAndApplyButton();
		return composite;
	}
}