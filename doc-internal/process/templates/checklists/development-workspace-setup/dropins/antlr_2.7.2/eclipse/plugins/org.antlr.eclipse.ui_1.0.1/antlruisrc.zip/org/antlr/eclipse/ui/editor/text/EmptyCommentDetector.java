package org.antlr.eclipse.ui.editor.text;

import org.eclipse.jface.text.rules.IWordDetector;

/**
 * Detector for empty ANTLR multi-line comments.
 */
public class EmptyCommentDetector implements IWordDetector {

	/**
	 * @see IWordDetector#isWordStart(char)
	 */
	public boolean isWordStart(char c) {
		return (c == '/');
	}

	/**
	 * @see IWordDetector#isWordPart(char)
	 */
	public boolean isWordPart(char c) {
		return (c == '*' || c == '/');
	}
}