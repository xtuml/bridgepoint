package org.antlr.eclipse.core.parser;

public class Block extends AbstractModel {
    public static final int HEADER = 0;
    public static final int OPTIONS = 1;
    public static final int TOKENS = 2;
    public static final int PREAMBLE = 3;
    public static final int ACTION = 4;
    public static final int EXCEPTION = 5;
	private static final String[] TYPES = { "Header", "Options", "Tokens",
	    									   "Preamble", "Action",
	    									   "Exception" };
	private int fType;
	
	public Block(IModel aParent, int aType, int aStartLine, int anEndLine) {
	    super(TYPES[aType], aParent);
	    fType = aType;
	    setStartLine(aStartLine);
	    setEndLine(anEndLine);
	}
	
    /**
     * @see IModel#hasChildren()
     */
	public boolean hasChildren() {
	    return false;
	}

    /**
     * @see IModel#getChildren()
     */
	public Object[] getChildren() {
	    return NO_CHILDREN;
	}
	
	/**
	 * @see ISegment#getUniqueID()
	 */
	public String getUniqueID() {
		return ((ISegment)getParent()).getUniqueID() + "/Block:" +
				TYPES[fType];
	}

	/**
	 * @see ISegment#accept(ISegmentVisitor)
	 */
	public boolean accept(ISegmentVisitor aVisitor) {
		return aVisitor.visit(this);
	}
	
	public int getType() {
	    return fType;
	}
	
	public String toString() {
	    return getUniqueID() + " [" + getStartLine() + ":" +
	    		getEndLine() + "]";
	}
}
