package org.antlr.eclipse.core.parser;

/**
 * Visitor design pattern.
 * @see ISegment#accept(ISegmentVisitor)
 */
public interface ISegmentVisitor {
	
	boolean visit(ISegment aSegment);
}
