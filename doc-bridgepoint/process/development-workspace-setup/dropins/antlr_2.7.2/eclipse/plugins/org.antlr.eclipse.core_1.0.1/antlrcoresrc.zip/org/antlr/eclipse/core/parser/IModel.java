package org.antlr.eclipse.core.parser;

public interface IModel {
    public static final Object[] NO_CHILDREN = new Object[0];
	
	String getName();
	
	Object getParent();
	
	boolean hasChildren();
	
	Object[] getChildren();
}
