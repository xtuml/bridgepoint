package org.antlr.eclipse.core.builder;

import java.io.File;
import java.io.PrintStream;
import java.security.Permission;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import org.antlr.eclipse.core.AntlrCorePlugin;
import org.antlr.eclipse.core.AntlrNature;
import org.eclipse.core.resources.IContainer;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IFolder;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.resources.IResourceDeltaVisitor;
import org.eclipse.core.resources.IResourceVisitor;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

import antlr.AntlrTool;

public class AntlrBuilder extends IncrementalProjectBuilder
												  implements IStreamListener {
    public static final String BUILDER_ID = AntlrCorePlugin.PLUGIN_ID +
    														  ".antlrbuilder";
	public static final String DEBUG_OPTION = AntlrCorePlugin.PLUGIN_ID +
															 "/builder/debug";
	public static boolean DEBUG = false;

	private IFile fFile;
	private PrintStream fOriginalOut;
	private PrintStream fOriginalErr;

	public AntlrBuilder() {
		DEBUG = AntlrCorePlugin.isDebug(DEBUG_OPTION);
	}

    /**
     * @see InternalBuilder#build(int, Map, IProgressMonitor)
     */
    protected IProject[] build(int aKind, Map anArgs,
    						 IProgressMonitor aMonitor) throws CoreException {   
		IResourceDelta delta = (aKind != FULL_BUILD ? getDelta(getProject()) :
													  null);
		if (delta == null || aKind == FULL_BUILD) {
			IProject project = getProject();
			if (AntlrNature.hasNature(project)) {
			    project.accept(new Visitor(aMonitor));
			}
		} else {
			delta.accept(new DeltaVisitor(aMonitor));
		}
		return null;
   	}
   
	/**
	 * @see IStreamListener#streamAppended(String, Object)
	 */
	public void streamAppended(String aText, Object aStream) {
    	if (DEBUG) {
    		fOriginalOut.println("ANTLR output: " + aText);
    	}
		int line = 0;
		String message = null;
		int severity = 0;

		// First check for messages with header "<file>|<line>|<column>"
		StringTokenizer st = new StringTokenizer(aText, "|");
		if (st.countTokens() > 3) {
			st.nextToken();	// file
			line = Integer.parseInt(st.nextToken());
			Integer.parseInt(st.nextToken());	// column
			message = st.nextToken();
			while (st.hasMoreTokens()) {
				message += st.nextToken();
			}
			if (message.startsWith("warning:")) {
				severity = IMarker.SEVERITY_WARNING;
				message = message.substring(8);
			} else {
				severity = IMarker.SEVERITY_ERROR;
			}
			message = message.replace('\t', ' ').trim();

		// Then check for messages without header
		} else if (aText.startsWith("panic: ")) {
			message = aText.substring(7);
			severity = IMarker.SEVERITY_ERROR;
		} else if (aText.startsWith("error: ")) {
			message = aText.substring(7);
			severity = IMarker.SEVERITY_ERROR;
		} else if (aText.startsWith("warning: ")) {
			severity = IMarker.SEVERITY_WARNING;
			message = message.substring(9);
		} else {
	    	if (DEBUG) {
	    		fOriginalOut.println("Unhandled ANTLR output: " + aText);
	    	}
		}

		// If valid error/warning message found then create problem marker
		if (message != null) {
			try {
				IMarker marker = fFile.createMarker(IMarker.PROBLEM);
				marker.setAttribute(IMarker.MESSAGE, message);
				marker.setAttribute(IMarker.SEVERITY, severity);
				if (line > 0) {
					marker.setAttribute(IMarker.LINE_NUMBER, line);
				}
			} catch (CoreException e) {
				AntlrCorePlugin.log(e);
			}
		}
	}

	private class Visitor implements IResourceVisitor {
		private IProgressMonitor fMonitor;
		
		public Visitor(IProgressMonitor aMonitor) {
			fMonitor = aMonitor;
		}

        /**
         * @see IResourceVisitor#visit(IResource)
         */
		public boolean visit(IResource aResource) {
			if (aResource instanceof IFile) {

				// see if this is it
				IFile file = (IFile)aResource;
				if (file.getName().endsWith(".g")) {
					compileFile(file, fMonitor);
				}
			}
			return true;
		}
	}

	private class DeltaVisitor implements IResourceDeltaVisitor {
		private IProgressMonitor fMonitor;
		
		public DeltaVisitor(IProgressMonitor aMonitor) {
			fMonitor = aMonitor;
		}

        /**
         * @see IResourceDeltaVisitor#visit(IResourceDelta)
         */
		public boolean visit(IResourceDelta aDelta) {
		    boolean visitChildren = false;

			IResource resource = aDelta.getResource();
			if (resource instanceof IProject) {

				// Only check projects with ANTLR nature
				IProject project = (IProject)resource;
				visitChildren = AntlrNature.hasNature(project);
			} else if (resource instanceof IFolder) {
				visitChildren = true;
			} else if (resource instanceof IFile) {

				// see if this is it
				IFile file = (IFile)resource;
				if (file.getName().endsWith(".g")) {

					// Only check it if it has been added or changed
					if (aDelta.getKind() != IResourceDelta.REMOVED) {
						compileFile(file, fMonitor);
						visitChildren = true;
					}
				}
			}
			return visitChildren;
		}
	}

	public void compileFile(IFile aFile, IProgressMonitor aMonitor) {
		aMonitor.beginTask(AntlrCorePlugin.getFormattedMessage(
				 "AntlrBuilder.compiling", aFile.getFullPath().toString()), 4);
		// Get output path and super grammars from grammar properties
		IContainer folder = (IContainer)aFile.getParent();
		String output;
		String superGrammars;
		try {		
			output = aFile.getPersistentProperty(
											  AntlrCorePlugin.OUTPUT_PROPERTY);
			superGrammars = aFile.getPersistentProperty(
									  AntlrCorePlugin.SUPER_GRAMMARS_PROPERTY);
		} catch (CoreException e) {
			output = null;
			superGrammars = null;
		}
		
		// Prepare arguments for ANTLR compiler
		ArrayList args = new ArrayList();
		args.add("-o");
		if (output != null && output.trim().length() > 0) {
			args.add(convertPath(output));
		} else {
			args.add(folder.getLocation().toString());
		}
		if (superGrammars != null && superGrammars.trim().length() > 0) {
			args.add("-glib");
			args.add(convertPathList(superGrammars));
		}
		args.add(aFile.getLocation().toOSString());
    	if (DEBUG) {
    		System.out.println("Compiling ANTLR grammar '" +
    						   aFile.getName() + "': arguments=" + args);
    	}

		// Monitor system out and err
		fOriginalOut = System.out;
		fOriginalErr = System.err;
		System.setOut(new PrintStream(new MonitoredOutputStream(this)));
		System.setErr(new PrintStream(new MonitoredOutputStream(this)));

		// Temporary workaround to disable 'System.exit()'
		SecurityManager originalSecurityManager = System.getSecurityManager();
		System.setSecurityManager(new SecurityManager() {
			public void checkExit(int status) {
				SecurityException e = new SecurityException();
				if (DEBUG) {
					e.printStackTrace(fOriginalErr);
				}
				throw e;
			}
			public void checkPermission(Permission perm) {
			}
			public void checkPermission(Permission perm, Object obj) {
			}
		});
		try {

			// Attach markers to this file
			fFile = aFile;
			try {
				fFile.deleteMarkers(null, true, IResource.DEPTH_INFINITE);
			} catch (CoreException e) {
				AntlrCorePlugin.log(e);
			}
			
			// Compile ANTLR grammar file
			AntlrTool tool = new AntlrTool();
			if (!tool.preprocess(
							(String[])args.toArray(new String[args.size()]))) {
			    try {
	    			aMonitor.worked(1);
	    			if (!tool.parse()) {
	    				aMonitor.worked(1);
	    				if (!tool.generate()) {
							aMonitor.worked(1);
							if (output != null && output.trim().length() > 0) {
								refreshFolder(tool,
									  ResourcesPlugin.getWorkspace().getRoot().
												 findMember(output), aMonitor);
							} else {
								refreshFolder(tool, folder, aMonitor);
							}
	    				} else {

							// If errors during generate then delete all
							// generated files
	    					deleteFiles(tool, folder, aMonitor);
	    				}
	    			}
				} catch (CoreException e) {
					AntlrCorePlugin.log(e);
			    }
			}

		} catch (Throwable e) {
			if (!(e instanceof SecurityException)) {
				AntlrCorePlugin.log(e);
			}
		} finally {
			System.setSecurityManager(originalSecurityManager);
	
			System.setOut(fOriginalOut);
			System.setErr(fOriginalErr);
			aMonitor.done();
		}
	}

	/**
	 * Converts given relative path to an absolute one.
	 */
	private String convertPath(String aPath) {
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		return root.findMember(aPath).getLocation().toOSString();
	}

	/**
	 * Converts given list of relative paths to a new list with absolute paths
	 * (delimited by ';').
	 */
	private String convertPathList(String aPathList) {
		StringBuffer list = new StringBuffer();
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		StringTokenizer tokenizer = new StringTokenizer(aPathList, ";");
		while (tokenizer.hasMoreTokens()) {
			IResource resource = root.findMember(tokenizer.nextToken());
			list.append(resource.getLocation().toOSString());
			if (tokenizer.hasMoreTokens()) {
				list.append(';');
			}
		}
		return list.toString();
	}

	private void deleteFiles(AntlrTool aTool, IContainer aFolder,
							  IProgressMonitor aMonitor) {
		Iterator files = aTool.files();
		while (files.hasNext()) {
			String fileName = (String)files.next();
	    	if (DEBUG) {
	    		fOriginalOut.println("Deleting ANTLR generated file '" +
		    						 fileName + "'");
	    	}
			IResource file = aFolder.findMember(fileName);
			if (file != null) {
				aMonitor.subTask(AntlrCorePlugin.getFormattedMessage(
										   "AntlrBuilder.deleting", fileName));
				try {
					file.delete(true, aMonitor);
				} catch (CoreException e) {
					AntlrCorePlugin.log(e);
				}
			}
		}
	}

	private void refreshFolder(AntlrTool aTool, IResource aFolder,
								IProgressMonitor aMonitor) {
		aMonitor.subTask(AntlrCorePlugin.getFormattedMessage(
				 "AntlrBuilder.refreshing", aFolder.getFullPath().toString()));
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		IContainer folder = root.getContainerForLocation(aFolder.getLocation());
    	if (DEBUG) {
    		fOriginalOut.println("Refreshing output folder '" + folder + "'");
    	}
		try {
			// Refresh workspace folder
			aFolder.refreshLocal(IResource.DEPTH_ONE, aMonitor);
			aMonitor.worked(1);

			// Mark all generated files as derived and set grammar property
			String grammar = new File(aTool.getGrammarFile()).getName();
			Iterator files = aTool.files();
			while (files.hasNext()) {
				String fileName = (String)files.next();
		    	if (DEBUG) {
		    		fOriginalOut.println("ANTLR generated file '" +
		    							 fileName + "'");
		    	}
				IResource file = folder.findMember(fileName);
				file.setDerived(true);
				file.setPersistentProperty(AntlrCorePlugin.GRAMMAR_PROPERTY,
										   grammar);
			}
			aMonitor.worked(1);
		} catch (CoreException e) {
		    AntlrCorePlugin.log(e);
		}
	}
}
