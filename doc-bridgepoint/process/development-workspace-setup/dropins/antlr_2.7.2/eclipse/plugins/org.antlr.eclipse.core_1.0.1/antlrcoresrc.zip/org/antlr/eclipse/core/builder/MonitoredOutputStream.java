package org.antlr.eclipse.core.builder;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Hashtable;

/**
 * Logs output content written by a thread to specified listener.
 *
 * @author Torsten Juergeleit
 */
public class MonitoredOutputStream extends OutputStream {
    private IStreamListener fListener;

    private static final int MAX_SIZE = 1024;
    private Hashtable fBuffers = new Hashtable();
    private boolean fSkip = false;

    /**
     * Creates a new instance of this class.
     */
    public MonitoredOutputStream(IStreamListener aListener) {
        fListener = aListener;
    }
    
    /**
     * Write the data to the buffer and flush the buffer, if a line separator
     * is detected.
     *
     * @param aByte  data to log
     * @see OutputStream#write(int)
     */
    public void write(int aByte) throws IOException {
        final byte c = (byte)aByte;
        if (c == '\n' || c == '\r') {
            if (!fSkip) {
                processBuffer();
            }
        } else {
            ByteArrayOutputStream buffer = getBuffer();
            buffer.write(aByte);
            if (buffer.size() > MAX_SIZE) {
                processBuffer();
            }
        }
        fSkip = (c == '\r');
    }

    /**
     * Writes all remaining data from buffer.
     * @see OutputStream#flush()
     */
    public void flush() throws IOException {
        if (getBuffer().size() > 0) {
            processBuffer();
        }
    }

    /**
     * Writes all remaining data from buffer.
     * @see OutputStream#close()
     */
    public void close() throws IOException {
        flush();
    }

    /**
     * Converts the buffer to a string and sends it to listener.
     * @see IStreamListener#(String, Object)
     */
    protected void processBuffer() {
        fListener.streamAppended(getBuffer().toString(), this);
        fBuffers.remove(Thread.currentThread());
    }

    private ByteArrayOutputStream getBuffer() {
        Thread current = Thread.currentThread();
        ByteArrayOutputStream buffer = (ByteArrayOutputStream)fBuffers.get(current);
        if (buffer == null) {
            buffer = new ByteArrayOutputStream();
            fBuffers.put(current, buffer);
        }
        return buffer;
    }
}
