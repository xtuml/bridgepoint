package org.antlr.eclipse.core.parser;

import java.util.Enumeration;
import java.util.Vector;

import antlr.Token;

public class Rule extends AbstractModel {
    public static final int PRIVATE = 1;
    public static final int PROTECTED = 2;
    public static final int PUBLIC = 3;
    
	private int fVisibility;
	private Block fOptions = null;
	private Block fMemberAction = null;
	private Vector fExceptions = new Vector();
	
	/** Indicates if rules is excluded from transformation (suffix "!") */
	private boolean fIsExcluded;
	
	public Rule(Grammar aGrammar, String aName, int aVisibility,
				 int aStartLine) {
		super(aName, aGrammar);
	    fVisibility = aVisibility;
	    setStartLine(aStartLine);
	    setEndLine(aStartLine);
	}
	
    /**
     * @see IModel#hasChildren()
     */
	public boolean hasChildren() {
	    return fOptions != null || fMemberAction != null ||
	    		!fExceptions.isEmpty();
	}

    /**
     * @see IModel#getChildren()
     */
	public Object[] getChildren() {
	    Vector childs = new Vector();
	    if (fOptions != null) {
	        childs.add(fOptions);
	    }
	    if (fMemberAction != null) {
	        childs.add(fMemberAction);
	    }
	    childs.addAll(fExceptions);
	    return childs.toArray();
	}
	
	/**
	 * @see ISegment#getUniqueID()
	 */
	public String getUniqueID() {
		return ((ISegment)getParent()).getUniqueID() + "/Rule:" + getName();
	}

	/**
	 * @see ISegment#accept(ISegmentVisitor)
	 */
	public boolean accept(ISegmentVisitor aVisitor) {
		boolean more = true;
		
		// At first visit all exceptions of this rule
		Enumeration exceptions = fExceptions.elements();
		while (exceptions.hasMoreElements() && more) {
			more = ((ISegment)exceptions.nextElement()).accept(aVisitor);
		}

		// Now visit this rule's options and memberaction
		if (more && fOptions != null) {
			more = aVisitor.visit(fOptions);
		}
		if (more && fMemberAction != null) {
			more = aVisitor.visit(fMemberAction);
		}

		// Finally visit this grammar
		if (more) {
			more = aVisitor.visit(this);
		}
		return more;
	}
	
	public int getVisibility() {
	    return fVisibility;
	}
	
	public void setIsExcluded(boolean anIsExcluded) {
	    fIsExcluded = anIsExcluded;
	}
	
	public boolean isExcluded() {
	    return fIsExcluded;
	}
	
	public void setOptions(Token aToken) {
	    fOptions = new Block(this, Block.OPTIONS, aToken.getLine(),
	    					 aToken.getColumn());
	}

	public Block getOptions() {
	    return fOptions;
	}
	
	public void setMemberAction(Token aToken) {
	    fMemberAction = new Block(this, Block.ACTION, aToken.getLine(),
	    						  aToken.getColumn());
	}

	public Block getMemberAction() {
	    return fMemberAction;
	}

	public void addException(Token aToken) {
		fExceptions.add(new Block(this, Block.EXCEPTION, aToken.getLine(),
								  getEndLine()));
	}

	public String toString() {
	    return getUniqueID() + " [" + getStartLine() + ":" +
	    		getEndLine() + "]";
	}
}
