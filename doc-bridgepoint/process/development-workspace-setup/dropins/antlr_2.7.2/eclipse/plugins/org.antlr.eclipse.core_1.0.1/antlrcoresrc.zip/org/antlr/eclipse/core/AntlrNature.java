package org.antlr.eclipse.core;

import org.antlr.eclipse.core.builder.AntlrBuilder;
import org.eclipse.core.resources.ICommand;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IProjectDescription;
import org.eclipse.core.resources.IProjectNature;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;

public class AntlrNature implements IProjectNature {
    public static final String ID = AntlrCorePlugin.PLUGIN_ID +
    														   ".antlrnature";
	public static final String DEBUG_OPTION = AntlrCorePlugin.PLUGIN_ID +
															  "/nature/debug";
	public static boolean DEBUG = false;

	private IProject fProject;

	public AntlrNature() {
		DEBUG = AntlrCorePlugin.isDebug(DEBUG_OPTION);
	}

    /**
     * @see IProjectNature#getProject()
     */
    public IProject getProject() {
        return fProject;
    }

    /**
     * @see IProjectNature#setProject(IProject)
     */
    public void setProject(IProject aProject) {
		fProject = aProject;
    }

    /**
     * @see IProjectNature#configure()
     */
    public void configure() throws CoreException {
    	if (DEBUG) {
    		System.out.println("configuring ANTLR nature");
    	}
    	IProject project = getProject();
    	IProjectDescription desc = project.getDescription();
    	ICommand builderCommand = getBuilderCommand(desc,
    												AntlrBuilder.BUILDER_ID);
    	if (builderCommand == null) {
    		// Add a new build spec
    		ICommand command = desc.newCommand();
    		command.setBuilderName(AntlrBuilder.BUILDER_ID);

			// Commit the spec change into the project
    		setBuilderCommand(desc, command);
			project.setDescription(desc, null);
    	}
    }

    /**
     * @see IProjectNature#deconfigure()
     */
    public void deconfigure() throws CoreException {
    	if (DEBUG) {
    		System.out.println("deconfiguring ANTLR nature");
    	}
    	IProject project = getProject();
    	IProjectDescription desc = project.getDescription();
    	ICommand[] commands = desc.getBuildSpec();
    	for (int i = commands.length - 1; i >= 0; i--) {
    		if (commands[i].getBuilderName().equals(AntlrBuilder.BUILDER_ID)) {
    			ICommand[] newCommands = new ICommand[commands.length - 1];
    			System.arraycopy(commands, 0, newCommands, 0, i);
    			System.arraycopy(commands, i + 1, newCommands, i,
    							 commands.length - i - 1);
				// Commit the spec change into the project
    			desc.setBuildSpec(newCommands);
				project.setDescription(desc, null);
    			break;
    		}
    	}
    }

	public static void addNature(IProject aProject,
								   IProgressMonitor aMonitor) {
		if (aProject != null) {
	    	if (DEBUG) {
	    		System.out.println("adding ANTLR nature to project '" +
	    						   aProject.getName() + "'");
	    	}
			try {
				if (!aProject.hasNature(ID)) {
					IProjectDescription desc = aProject.getDescription();
					String[] oldNatures = desc.getNatureIds();
					String[] newNatures = new String[oldNatures.length + 1];
					System.arraycopy(oldNatures, 0, newNatures, 0,
									 oldNatures.length);
					newNatures[oldNatures.length] = ID;
					desc.setNatureIds(newNatures);
					aProject.setDescription(desc, aMonitor);
				}
			} catch(CoreException e) {
				AntlrCorePlugin.log(e);
			}
		}
	}
	
	public static void removeNature(IProject aProject,
									  IProgressMonitor aMonitor) {
		if (aProject != null) {
	    	if (DEBUG) {
	    		System.out.println("removing ANTLR nature from project '" +
	    						   aProject.getName() + "'");
	    	}
			try {
				if (aProject.hasNature(ID)) {
					IProjectDescription desc = aProject.getDescription();
					String[] oldNatures = desc.getNatureIds();
					String[] newNatures = new String[oldNatures.length - 1];
					int newIndex = oldNatures.length - 2;
					for (int i =  oldNatures.length - 1; i >= 0; i--) {
						if (!oldNatures[i].equals(ID)) {
							newNatures[newIndex--] = oldNatures[i];
						}
					}
					desc.setNatureIds(newNatures);
					aProject.setDescription(desc, aMonitor);
				}
			} catch(CoreException e) {
				AntlrCorePlugin.log(e);
			}
		} 
	}

	/**
	 * Returns true if given project has an ANTLR project nature.
	 * @see IProject#hasNature(String)
	 */
	public static boolean hasNature(IProject aProject) {
	    boolean hasNature;
		try {
			hasNature = aProject.hasNature(ID);
		} catch (CoreException e) {
			AntlrCorePlugin.log(e);
			hasNature = false;
		}
		return hasNature;
	}

    private ICommand getBuilderCommand(IProjectDescription aDescription,
									 String aBuilderID) throws CoreException {
		ICommand command = null;
    	ICommand[] commands = aDescription.getBuildSpec();
    	for (int i = commands.length - 1; i >= 0 ; i--) {
    		if (commands[i].getBuilderName().equals(aBuilderID)) {
    			command = commands[i];
    			break;
    		}
    	}
    	return command;
    }

    private void setBuilderCommand(IProjectDescription aDescription,
									 ICommand aCommand) throws CoreException {
    	ICommand[] oldCommands = aDescription.getBuildSpec();
    	ICommand oldBuilderCommand = getBuilderCommand(aDescription,
    											   aCommand.getBuilderName());
    	ICommand[] newCommands;
    
    	if (oldBuilderCommand == null) {
    		// Add a build spec in front of other builders
    		newCommands = new ICommand[oldCommands.length + 1];
    		newCommands[0] = aCommand;
    		System.arraycopy(oldCommands, 0, newCommands, 1,
    						 oldCommands.length);
    	} else {
    		for (int i = 0, max = oldCommands.length; i < max; i++) {
    			if (oldCommands[i] == oldBuilderCommand) {
    				oldCommands[i] = aCommand;
    				break;
    			}
    		}
    		newCommands = oldCommands;
    	}
    
    	// Commit the spec change into the project
    	aDescription.setBuildSpec(newCommands);
    	getProject().setDescription(aDescription, null);
    }
}
