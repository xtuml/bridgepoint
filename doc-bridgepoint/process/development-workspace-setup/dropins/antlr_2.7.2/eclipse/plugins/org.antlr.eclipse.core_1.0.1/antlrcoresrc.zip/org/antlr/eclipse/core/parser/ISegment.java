package org.antlr.eclipse.core.parser;

public interface ISegment {

	String getUniqueID();
	
	int getStartLine();

	int getEndLine();

	/**
	 * Visitor design pattern.
	 * @see ISegmentVisitor#visit(ISegment)
	 */
	boolean accept(ISegmentVisitor aVisitor);
}
