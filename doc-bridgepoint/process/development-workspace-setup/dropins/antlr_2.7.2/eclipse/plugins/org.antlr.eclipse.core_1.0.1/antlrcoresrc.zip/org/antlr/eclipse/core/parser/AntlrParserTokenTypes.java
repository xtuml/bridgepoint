// $ANTLR : "C:/projects/Eclipse/runtime-workspace/org.antlr.eclipse.core/src/org/antlr/eclipse/core/parser/antlr.g" -> "AntlrParser.java"$

package org.antlr.eclipse.core.parser;

public interface AntlrParserTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int HEADER = 4;
	int OPTIONS = 5;
	int ACTION = 6;
	int LITERAL_class = 7;
	int ID = 8;
	int LITERAL_extends = 9;
	int SEMI = 10;
	int TOKENS = 11;
	int LITERAL_protected = 12;
	int LITERAL_private = 13;
	int LITERAL_public = 14;
	int BANG = 15;
	int ARG_ACTION = 16;
	int LITERAL_returns = 17;
	int LITERAL_throws = 18;
	int COMMA = 19;
	int RULE_BLOCK = 20;
	int LITERAL_exception = 21;
	int LITERAL_catch = 22;
	int SUBRULE_BLOCK = 23;
	int ALT = 24;
	int ELEMENT = 25;
	int RCURLY = 26;
	int ID_OR_KEYWORD = 27;
	int CURLY_BLOCK_SCARF = 28;
	int WS = 29;
	int NEWLINE = 30;
	int COMMENT = 31;
	int SL_COMMENT = 32;
	int ML_COMMENT = 33;
	int CHAR_LITERAL = 34;
	int STRING_LITERAL = 35;
	int ESC = 36;
	int DIGIT = 37;
	int XDIGIT = 38;
}
