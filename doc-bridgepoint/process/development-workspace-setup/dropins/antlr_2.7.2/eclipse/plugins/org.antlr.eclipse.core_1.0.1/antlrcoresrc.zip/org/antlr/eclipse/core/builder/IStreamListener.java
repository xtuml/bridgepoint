package org.antlr.eclipse.core.builder;

/**
 * A stream listener is notified of changes to a stream.
 */
public interface IStreamListener {

	/**
	 * Notifies this listener that text has been appended to the given stream.
	 *
	 * @param aText  the appended text
	 * @param aStream  the stream to which text was appended
	 */
	public void streamAppended(String aText, Object aStream);
}
