package org.antlr.eclipse.core.parser;

import java.util.Enumeration;
import java.util.Vector;

import antlr.Token;

public class Grammar extends AbstractModel {

	private String fSuperClass;
	private Block fPreamble = null;
	private Block fOptions = null;
	private Block fTokens = null;
	private Block fMemberAction = null;
	private Vector fRules = new Vector();

	public Grammar(Hierarchy aHierarchy, String aName, String aSuperClass,
					int aStartLine) {
		super(aName, aHierarchy);
		fSuperClass = aSuperClass;
		setStartLine(aStartLine);
		setEndLine(aStartLine);
	}
	
    /**
     * @see IModel#hasChildren()
     */
	public boolean hasChildren() {
	    return fPreamble != null || fOptions != null || fTokens != null ||
	    		fMemberAction != null || !fRules.isEmpty();
	}

    /**
     * @see IModel#getChildren()
     */
	public Object[] getChildren() {
	    Vector childs = new Vector();
	    if (fPreamble != null) {
	        childs.add(fPreamble);
	    }
	    if (fOptions != null) {
	        childs.add(fOptions);
	    }
	    if (fTokens != null) {
	        childs.add(fTokens);
	    }
	    if (fMemberAction != null) {
	        childs.add(fMemberAction);
	    }
	    childs.addAll(fRules);
	    return childs.toArray();
	}
	
	/**
	 * @see ISegment#getUniqueID()
	 */
	public String getUniqueID() {
		return ((ISegment)getParent()).getUniqueID() + "/Grammar:" + getName();
	}

	/**
	 * @see ISegment#accept(ISegmentVisitor)
	 */
	public boolean accept(ISegmentVisitor aVisitor) {
		boolean more = true;
		
		// At first visit all rules of this grammar
		Enumeration rules = fRules.elements();
		while (rules.hasMoreElements() && more) {
			more = ((ISegment)rules.nextElement()).accept(aVisitor);
		}

		// Now visit this grammar's preamble, options, tokens and memberaction
		if (more && fPreamble != null) {
			more = aVisitor.visit(fPreamble);
		}
		if (more && fOptions != null) {
			more = aVisitor.visit(fOptions);
		}
		if (more && fTokens != null) {
			more = aVisitor.visit(fTokens);
		}
		if (more && fMemberAction != null) {
			more = aVisitor.visit(fMemberAction);
		}

		// Finally visit this grammar
		if (more) {
			more = aVisitor.visit(this);
		}
		return more;
	}

	public	void setPreamble(Token aToken) {
	    fPreamble = new Block(this, Block.PREAMBLE, aToken.getLine(),
	    					  aToken.getColumn());
	}

	public Block getPreamble() {
	    return fPreamble;
	}
	
	public void setOptions(Token aToken) {
	    fOptions = new Block(this, Block.OPTIONS, aToken.getLine(),
	    					 aToken.getColumn());
	}

	public Block getOptions() {
	    return fOptions;
	}
	
	public void setTokens(Token aToken) {
	    fTokens = new Block(this, Block.TOKENS, aToken.getLine(),
	    					aToken.getColumn());
	}

	public Block getTokens() {
	    return fTokens;
	}
	
	public void setMemberAction(Token aToken) {
	    fMemberAction = new Block(this, Block.ACTION, aToken.getLine(),
	    						  aToken.getColumn());
	}

	public Block getMemberAction() {
	    return fMemberAction;
	}
	
	public void addRule(Rule aRule) {
	    fRules.add(aRule);
	}

	public Enumeration getRules() {
	    return fRules.elements();
	}

	public Rule getLastRule() {
	    return (fRules.isEmpty() ? null : (Rule)fRules.lastElement());
	}

	public String toString() {
	    return getUniqueID() + " [" + getStartLine() + ":" + getEndLine() +
	    		"] with rule(s) " + fRules;
	}
}
