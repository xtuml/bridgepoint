package org.antlr.eclipse.core.parser;

import java.util.Enumeration;
import java.util.Vector;

import antlr.Token;

public class Hierarchy extends AbstractModel {

	private Block fHeader = null;
	private Block fOptions = null;
	private Vector fGrammars = new Vector();
	private Exception fException = null;
	
	public Hierarchy(String aName) {
	    super(aName, null);
	    setStartLine(1);
	}
	
    /**
     * @see IModel#hasChildren()
     */
	public boolean hasChildren() {
	    return fHeader != null || fOptions != null || !fGrammars.isEmpty();
	}

    /**
     * @see IModel#getChildren()
     */
	public Object[] getChildren() {
	    Vector childs = new Vector();
	    if (fHeader != null) {
	        childs.add(fHeader);
	    }
	    if (fOptions != null) {
	        childs.add(fOptions);
	    }
	    childs.addAll(fGrammars);
	    return childs.toArray();
	}
	
	/**
	 * @see ISegment#getUniqueID()
	 */
	public String getUniqueID() {
		return getName();
	}
	/**
	 * @see ISegment#accept(ISegmentVisitor)
	 */
	public boolean accept(ISegmentVisitor aVisitor) {
		boolean more = true;
		
		// At first visit all grammars of this hierarchy
		Enumeration grammars = fGrammars.elements();
		while (grammars.hasMoreElements() && more) {
			more = ((ISegment)grammars.nextElement()).accept(aVisitor);
		}
		
		// Now visit this hierarchy's header and option segment
		if (more && fHeader != null) {
			more = aVisitor.visit(fHeader);
		}
		if (more && fOptions != null) {
			more = aVisitor.visit(fOptions);
		}
		return more;
	}
	
	public void setHeader(Token aToken) {
	    fHeader = new Block(this, Block.HEADER, aToken.getLine(),
	    					aToken.getColumn());
	}

	public Block getHeader() {
	    return fHeader;
	}
	
	public void setOptions(Token aToken) {
	    fOptions = new Block(this, Block.OPTIONS, aToken.getLine(),
	    					 aToken.getColumn());
	}

	public Block getOptions() {
	    return fOptions;
	}
	
	public void addGrammar(Grammar aGrammar) {
	    fGrammars.add(aGrammar);
	}
	
	public Enumeration getGrammars() {
	    return fGrammars.elements();
	}

	public Grammar getLastGrammar() {
	    return (fGrammars.isEmpty() ? null :
	    							   (Grammar)fGrammars.lastElement());
	}

	public void setException(Exception anException) {
		fException = anException;
	}

	public Exception getException() {
		return fException;
	}

	public String toString() {
	    return getUniqueID() + " [" + getStartLine() + ":" + getEndLine() +
	    		"] with grammar(s) " + fGrammars;
	}
}
