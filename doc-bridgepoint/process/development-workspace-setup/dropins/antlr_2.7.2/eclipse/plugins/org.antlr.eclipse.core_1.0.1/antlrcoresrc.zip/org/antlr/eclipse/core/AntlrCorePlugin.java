package org.antlr.eclipse.core;

import java.net.URL;
import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IPluginDescriptor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.MultiStatus;
import org.eclipse.core.runtime.Path;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Plugin;
import org.eclipse.core.runtime.Preferences;
import org.eclipse.core.runtime.QualifiedName;
import org.eclipse.core.runtime.Status;

/**
 * Central access point for the ANTLR Core plug-in
 * (id <code>"org.antlr.eclipse.core"</code>).
 *
 * @author Torsten Juergeleit
 */
public class AntlrCorePlugin extends Plugin {
    
	/** ID of the ANTLR core plugin
	 * (value <code>"org.antlr.eclipse.core"</code>) */	
	public static final String PLUGIN_ID = "org.antlr.eclipse.core";
	
	/** Name of the property holding the ANTLR grammar a file is generated
	 * from */
	public static final QualifiedName GRAMMAR_PROPERTY =
								  new QualifiedName(PLUGIN_ID, "AntlrGrammar");
	
	/** Name of the property holding the output path for generated files */
	public static final QualifiedName OUTPUT_PROPERTY =
								   new QualifiedName(PLUGIN_ID, "AntlrOutput");
	
	/** Name of the property holding a list of paths to super grammar files
	 * (delimited by ';') */
	public static final QualifiedName SUPER_GRAMMARS_PROPERTY =
							new QualifiedName(PLUGIN_ID, "AntlrSuperGrammars");
	/** Singleton instance of this plugin */
	private static AntlrCorePlugin fPlugin;

	private static final String RESOURCE_NAME = PLUGIN_ID + ".messages";
	private ResourceBundle fResourceBundle;

	private static final String JDT_BUILDER_FILTER_ID =
					"org.eclipse.jdt.core.builder.resourceCopyExclusionFilter";

	public AntlrCorePlugin(IPluginDescriptor aDescriptor) {
		super(aDescriptor);
		fPlugin = this;
		try {
			fResourceBundle = ResourceBundle.getBundle(RESOURCE_NAME);
		} catch (MissingResourceException e) {
			log(e);
			fResourceBundle = null;
		}
	}
	
	/**
	 * @see org.eclipse.core.runtime.Plugin#startup()
	 */
	public void startup() {
		
		// Add ANTLR grammar files to JDT builder's copy exclusion filter
		Plugin jdt = Platform.getPlugin("org.eclipse.jdt.core");
		if (jdt != null) {
			Preferences prefs = jdt.getPluginPreferences();
			String filter = prefs.getString(JDT_BUILDER_FILTER_ID);
			StringTokenizer st = new StringTokenizer(filter, ",");
			boolean found = false;
			while (st.hasMoreTokens()) {
				if (st.nextToken().equals("*.g")) {
					found = true;
					break;
				}
			}
			if (!found) {
				if (isDebug()) {
					System.out.println("Adding '*.g' to JDT builder's " +
									   "resource filter (" + filter + ")");
				}
				prefs.setValue(JDT_BUILDER_FILTER_ID, filter + ",*.g");
			}
		}
	}

	/**
	 * Returns the shared instance.
	 */
	public static AntlrCorePlugin getDefault() {
		return fPlugin;
	}

	public ResourceBundle getResourceBundle() {
		return fResourceBundle;
	}

	public static IWorkspace getWorkspace() {
		return ResourcesPlugin.getWorkspace();
	}
	
	public static String getPluginId() {
		return getDefault().getDescriptor().getUniqueIdentifier();
	}

	public static IPath getInstallLocation() {
		return new Path(getInstallURL().getFile());
	}

	public static URL getInstallURL() {
		return getDefault().getDescriptor().getInstallURL();
	}

	public static void log(IStatus aStatus) {
		getDefault().getLog().log(aStatus);
	}
	
	public static void log(Throwable aThrowable) {
		log(new Status(IStatus.ERROR, getPluginId(), Status.OK,
						getMessage("AntlrCorePlugin.internal_error"),
						aThrowable));
	}
	
	public static void logErrorMessage(String aMessage) {
		log(new Status(IStatus.ERROR, getPluginId(), Status.OK, aMessage,
			null));
	}

	public static void logErrorStatus(String aMessage, IStatus aStatus) {
		if (aStatus == null) {
			logErrorMessage(aMessage);
		} else {
			MultiStatus multi = new MultiStatus(getPluginId(), Status.OK,
											    aMessage, null);
			multi.add(aStatus);
			log(multi);
		}
	}
	
	public static boolean isDebug() {
		return getDefault().isDebugging();
	}

	public static boolean isDebug(String anOption) {
		boolean debug;
		if (isDebug()) {
			String value = Platform.getDebugOption(anOption);
			debug = (value != null && value.equalsIgnoreCase("true") ?
					 true : false);
		} else {
			debug = false;
		}
		return debug;
	}

	public static String getMessage(String aKey) {
	    String bundleString;
		ResourceBundle bundle = getDefault().getResourceBundle();
		if (bundle != null) {
			try {
				bundleString = bundle.getString(aKey);
			} catch (MissingResourceException e) {
			    log(e);
				bundleString = "!" + aKey + "!";
			}
		} else {
			bundleString = "!" + aKey + "!";
		}
		return bundleString;
	}

	public static String getFormattedMessage(String aKey, String anArg) {
		return getFormattedMessage(aKey, new String[] { anArg });
	}

	public static String getFormattedMessage(String aKey, String[] anArgs) {
		return MessageFormat.format(getMessage(aKey), anArgs);
	}
}
