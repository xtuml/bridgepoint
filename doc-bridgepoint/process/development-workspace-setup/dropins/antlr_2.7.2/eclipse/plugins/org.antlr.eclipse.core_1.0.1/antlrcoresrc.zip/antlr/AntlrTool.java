package antlr;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.Iterator;
import java.util.Vector;

import org.antlr.eclipse.core.AntlrCorePlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.Status;

public class AntlrTool extends Tool {
    private String[] fPreprocessedArgs = null;
	private LLkAnalyzer fAnalyzer = null;
	private MakeGrammar fBehavior = null;
    private ANTLRParser fParser = null;
    private Vector fFiles = new Vector();
    private Vector fWriters = new Vector();

	public AntlrTool() {
		setFileLineFormatter(new MarkerFormatter());
	}

	/**
	 * Returns iterator for all files created during last code generation.
	 */
	public Iterator files() {
		return fFiles.iterator();
	}

	/* (non-Javadoc)
	 * @see antlr.Tool#fatalError(java.lang.String)
	 */
	public void fatalError(String aMessage) {
		System.err.println(FileLineFormatter.getFormatter().
						   getFormatString(null, -1, -1) + aMessage);
		throw new IllegalStateException();
    }

	/* (non-Javadoc)
	 * @see antlr.Tool#error(java.lang.String)
	 */
    public void error(String aMessage) {
		System.err.println(FileLineFormatter.getFormatter().
						   getFormatString(null, -1, -1) + aMessage);
        hasError = true;
    }

	/* (non-Javadoc)
	 * @see antlr.Tool#warning(java.lang.String)
	 */
    public void warning(String aMessage) {
		System.err.println(FileLineFormatter.getFormatter().
						   getFormatString(null, -1, -1) + "warning: " +
						   aMessage);
    }

	/* (non-Javadoc)
	 * @see antlr.Tool#warning(java.lang.String[], java.lang.String, int, int)
	 */
	public void warning(String[] aMessageLines, String aFile, int aLine,
						 int aColumn) {
		if (aMessageLines != null && aMessageLines.length != 0) {
			StringBuffer message = new StringBuffer(aMessageLines[0]);
			for (int i = 1; i < aMessageLines.length; i++) {
				String line = aMessageLines[i];
				int pos = 0;
				while (Character.isWhitespace(line.charAt(pos))) {
					pos++;
				}
				message.append(" ");
				message.append(line.substring(pos));
			}
			System.err.println(FileLineFormatter.getFormatter().
							   getFormatString(aFile, aLine, aColumn) +
							   "warning: " + message.toString());
		}
    }

	/* (non-Javadoc)
	 * @see antlr.Tool#toolError(java.lang.String)
	 */
	public void toolError(String aMessage) {
		System.err.println(FileLineFormatter.getFormatter().
						   getFormatString(null, -1, -1) + aMessage);
	}

    /* (non-Javadoc)
	 * @see antlr.Tool#openOutputFile(java.lang.String)
	 */
    public PrintWriter openOutputFile(String aFileName) throws IOException {
		if (!fFiles.contains(aFileName)) {
			fFiles.add(aFileName);
		}
		PrintWriter writer = new PrintWriter(new FileWriter(outputDir +
							System.getProperty("file.separator") + aFileName));
		fWriters.add(writer);
		return writer;
    }

    /**
     * Perform preprocessing on the grammar file.
     * Can only be called from main().
     * @param anArgs  the command-line arguments passed to main()
     */
    public boolean preprocess(String[] anArgs) {

        // run the preprocessor to handle inheritance first.
        antlr.preprocessor.Tool preTool = new antlr.preprocessor.Tool(this,
        															  anArgs);
        if (preTool.preprocess()) {
			fPreprocessedArgs = preTool.preprocessedArgList();
        } else {
            fPreprocessedArgs = null;
            hasError = true;
        }
        return hasError;
    }

    /**
     * Parse the grammar file.
     * Can only be called after calling preprocess().
     */
    public boolean parse() throws CoreException {
        if (fPreprocessedArgs == null) {
            throw createException("AntlrTool.error.missingPreprocess");
        } else {
            // process arguments for the Tool
			processArguments(fPreprocessedArgs);
        }
		if (!hasError) {
			Reader reader = getGrammarReader();
			ANTLRLexer lexer = new ANTLRLexer(reader);
			TokenBuffer tokenBuf = new TokenBuffer(lexer);
			fAnalyzer = new LLkAnalyzer(this);
			fBehavior = new MakeGrammar(this, fPreprocessedArgs, fAnalyzer);
	        try {
	            fParser = new ANTLRParser(tokenBuf, fBehavior, this);
	            fParser.setFilename(grammarFile);
	            fParser.grammar();
            } catch (IllegalStateException e) {
            	// Thrown by AntlrTool.fatalError()
				hasError = true;
            } catch (RecognitionException e) {
				hasError = true;
            } catch (TokenStreamException e) {
            	hasError = true;
            } finally {

				// Close all writers opened during grammar inheritance
				// (expanded grammar files)
				Iterator writers = fWriters.iterator();
				while (writers.hasNext()) {
					PrintWriter writer = (PrintWriter)writers.next();
					writer.close();
				}

				// Close reader
            	try {
					reader.close();
            	} catch (IOException e) {
            		throw createException("AntlrTool.error.canNotCloseFile",
            							   grammarFile, e);
            	}
            }
        }
        return hasError;
    }

	public boolean generate() throws CoreException {
        if (fParser == null) {
            throw createException("AntlrTool.error.missingParse");
        } else if (!hasError) {
        	fFiles.clear();
        	fWriters.clear();

			// Create the right code generator according to the
            // "language" option
            String codeGenClassName = "antlr." + getLanguage(fBehavior) +
            						  "CodeGenerator";
            try {
                CodeGenerator codeGen = (CodeGenerator)
								 Class.forName(codeGenClassName).newInstance();
                codeGen.setBehavior(fBehavior);
                codeGen.setAnalyzer(fAnalyzer);
                codeGen.setTool(this);
                codeGen.gen();
            } catch (ClassNotFoundException e) {
                throw createException("AntlrTool.error.noCodeGenerator",
                					   codeGenClassName, e);
            } catch (InstantiationException e) {
                throw createException("AntlrTool.error.noCodeGenerator",
                					   codeGenClassName, e);
            } catch (IllegalArgumentException e) {
                throw createException("AntlrTool.error.noCodeGenerator",
                					   codeGenClassName, e);
            } catch (IllegalAccessException e) {
                throw createException("AntlrTool.error.noCodeGenerator",
                					   codeGenClassName, e);
            } catch (IllegalStateException e) {

				// Thrown in fatalError() - ignore
				hasError = true;
			} finally {

				// Close all writers opened during code generation
				Iterator writers = fWriters.iterator();
				while (writers.hasNext()) {
					PrintWriter writer = (PrintWriter)writers.next();
					writer.close();
				}
			}
        }
        return hasError;
	}

    private CoreException createException(String aKey) {
        return createException(aKey, (String[])null, null);
    }
    
    private CoreException createException(String aKey, String anArg,
    									   Throwable aThrowable) {
        return createException(aKey, new String[] { anArg }, aThrowable);
    }
    
    private CoreException createException(String aKey, String[] anArgs,
    									   Throwable aThrowable) {
    	String msg = (anArgs == null ? AntlrCorePlugin.getMessage(aKey) :
    						AntlrCorePlugin.getFormattedMessage(aKey, anArgs));
        return new CoreException(new Status(Status.ERROR,
					   AntlrCorePlugin.PLUGIN_ID, Status.OK, msg, aThrowable));
    }

	private class MarkerFormatter extends FileLineFormatter {
	
		/**
	     * Returns given information separated by a '|'.
	     * 
	     * @param aFileName  the file that should appear in the prefix (or null)
	     * @param aLine  the line (or -1)
	     * @param aColumn  the column (or -1)
		 * @see antlr.FileLineFormatter#getFormatString(java.lang.String, int, int)
	     */
	    public String getFormatString(String aFileName, int aLine,
	    							   int aColumn) {
	        StringBuffer buf = new StringBuffer();
	
	        if (aFileName != null) {
	            buf.append(aFileName);
	        } else {
	            buf.append("<noname>");
	        }
	        buf.append('|');
			buf.append(aLine);
	        buf.append('|');
			buf.append(aColumn);
	        buf.append('|');
	        return buf.toString();
	    }
	}
}